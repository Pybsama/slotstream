import json,os,time,statistics,hashlib
import mlx.core as mx
mx.set_cache_limit(128 << 20)
mx.random.seed(54)
print(json.dumps({'kind':'identity','mlx':mx.__version__,'device':mx.device_info(),'blocks_override':os.getenv('MLX_SDPA_BLOCKS'),'scope':'synthetic D256 GQA12 single-query attention; not a model or M4 Pro reproduction'}),flush=True)
q=mx.random.normal((1,24,1,256)).astype(mx.bfloat16)
k=mx.random.normal((1,2,33000,256)).astype(mx.bfloat16)
v=mx.random.normal((1,2,33000,256)).astype(mx.bfloat16)
mx.eval(q,k,v)
for round in range(4):
 for n in ([32000,32767,32768,32769,32800,33000] if round%2==0 else [33000,32800,32769,32768,32767,32000]):
  keys=mx.contiguous(k[:,:,:n,:]);values=mx.contiguous(v[:,:,:n,:])
  # Match production mask rank and cardinality without inventing router evidence.
  mask=((mx.arange(n)>=n-2048)).reshape(1,1,1,n)
  mx.eval(keys,values,mask)
  def work():return mx.fast.scaled_dot_product_attention(q,keys,values,scale=0.0625,mask=mask)
  for _ in range(5):mx.eval(work())
  elapsed=[]
  for _ in range(50):
   t=time.perf_counter_ns();out=work();mx.eval(out);elapsed.append((time.perf_counter_ns()-t)/1e6)
  print(json.dumps({'kind':'attention','round':round,'keys':n,'median_ms':statistics.median(elapsed),'p95_ms':sorted(elapsed)[47],'finite':bool(mx.all(mx.isfinite(out)).item()),'sum':float(mx.sum(out.astype(mx.float32)).item()),'peak_bytes':mx.get_peak_memory()}),flush=True)
