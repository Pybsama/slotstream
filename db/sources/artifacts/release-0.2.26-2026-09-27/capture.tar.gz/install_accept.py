#!/usr/bin/env python3
"""v0.2.26 publication and installed acceptance.

Adapted from the v0.2.25 install_accept.py preserved in
db/sources/artifacts/release-0.2.25-2026-09-24/capture.tar.gz: the public
release must carry the exact CI bytes qualified here, its attestation must
verify, the public installer must match the reviewed source, and the
installed executable must pass Tools/e2e_release.sh against its own server.
"""
import hashlib
import json
import os
import pathlib
import socket
import subprocess
import sys
import time

base = pathlib.Path(__file__).resolve().parent
root = pathlib.Path('/private/tmp/claude-502/-Users-carlos-Projects-command-center/'
                    '6eecb8fb-463c-437b-b499-d3d971308e0c/scratchpad/slotstream')
out = base / 'installed-acceptance'
out.mkdir(exist_ok=False)
repo = 'carloslfu/slotstream'
tag = 'v0.2.26'
receipt = {'passed': False, 'steps': []}
server = log = None


def save():
    (out / 'receipt.json').write_text(json.dumps(receipt, indent=2))


def step(name, cmd, timeout=900, env=None):
    print(name, flush=True)
    start = time.monotonic()
    with (out / (name + '.log')).open('w') as f:
        r = subprocess.run(cmd, cwd=root, stdout=f, stderr=subprocess.STDOUT, env=env, timeout=timeout)
    receipt['steps'].append({'name': name, 'command': cmd, 'exit_code': r.returncode,
                             'seconds': time.monotonic() - start})
    save()
    assert r.returncode == 0, (name, r.returncode)


try:
    step('public-download', ['gh', 'release', 'download', tag, '--repo', repo, '--dir', str(out / 'download')], 300)
    for name in ['slotstream-arm64.tar.gz', 'slotstream-arm64.tar.gz.sha256']:
        assert (out / 'download' / name).read_bytes() == (base / 'ci' / name).read_bytes(), name
    step('attestation', ['gh', 'attestation', 'verify', str(out / 'download/slotstream-arm64.tar.gz'),
                         '--repo', repo], 300)
    step('public-installer-fetch', ['curl', '-fsSL',
                                    'https://raw.githubusercontent.com/carloslfu/slotstream/main/install.sh',
                                    '-o', str(out / 'install.sh')], 120)
    assert (out / 'install.sh').read_bytes() == (root / 'install.sh').read_bytes(), \
        'public installer differs from reviewed release source'
    step('public-install', ['sh', str(out / 'install.sh')], 600)
    binary = (pathlib.Path.home() / '.slotstream/bin/slotstream').resolve()
    identity = json.loads((base / 'candidate/build-identity.json').read_text())
    assert hashlib.sha256(binary.read_bytes()).hexdigest() == identity['binary_sha256']
    assert hashlib.sha256((binary.parent / 'mlx.metallib').read_bytes()).hexdigest() == identity['metallib_sha256']
    assert subprocess.check_output([binary, '--version'], text=True).strip() == '0.2.26'
    receipt['installed_binary'] = str(binary)
    receipt['binary_sha256'] = identity['binary_sha256']
    receipt['archive_sha256'] = hashlib.sha256((out / 'download/slotstream-arm64.tar.gz').read_bytes()).hexdigest()
    sys.path.insert(0, str(root / 'Tools'))
    from prefill_bench import preflight
    from serve_bench import wait_ready, stop_server
    receipt['preflight'] = preflight(13)
    with socket.socket() as s:
        s.bind(('127.0.0.1', 0))
        port = s.getsockname()[1]
    command = [str(binary), 'serve', '--memory-gb', '10', '--max-context', '32768', '--mtp', 'on',
               '--vision', 'off', '--port', str(port), '--prefix-cache-dir', str(out / 'cache')]
    receipt['command'] = command
    log = (out / 'server.log').open('w')
    env = {k: v for k, v in os.environ.items() if not k.startswith(('SLOTSTREAM_', 'SS_DEBUG'))}
    server = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, env=env, start_new_session=True)
    wait_ready(server, port)
    step('installed-e2e', ['bash', 'Tools/e2e_release.sh', str(port)], 3600, dict(env, BIN=str(binary)))
    receipt['passed'] = True
except Exception as e:
    receipt['error'] = repr(e)
    print(e, flush=True)
finally:
    if server is not None:
        stop_server(server)
        receipt['server'] = {'pid': server.pid, 'exit_code': server.returncode, 'reaped': True}
    if log:
        log.close()
    save()
    print('Installed acceptance passed', receipt['passed'], flush=True)
sys.exit(0 if receipt['passed'] else 1)
