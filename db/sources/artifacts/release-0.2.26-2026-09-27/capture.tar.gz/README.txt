v0.2.26 release qualification, publication and installed acceptance, 2026-09-27.

qualify.py, install_accept.py, capture.py
                           The scripts that produced this capture. qualify.py
                           is 0.2.25's without its CI wait loop, with the
                           reference Python named explicitly.
ci/                        The CI candidate's checksum (archive excluded).
candidate/                 Build identity and source archive of the candidate.
ci-runs-at-tag.json,       CI state when the tag was pushed, and the receipt.
tag-receipt.json
qualification/             The full battery on the exact CI bytes: 33 passed,
                           1 counted failed because vision parity was skipped
                           (the scratch checkout had no .venv31). vision-
                           parity-rerun.log: both vision parity gates on the
                           same candidate with the reference .venv31: pass.
                           prefix-turn-writes*: one write per turn, 4/4.
                           persistent-prefix*: the disk tier restart gate at
                           the corrected commit, 12/12.
local-checks/              Before the candidate existed: a local build of the
                           release commit passed the weight-free catalogue; the
                           restart gate failed the same five file-count checks
                           on that build and on the released 0.2.25, with
                           byte-identical writes.
release-workflow.*,        The release workflow and the public release.
public-release.json
installed-acceptance/      Public download, attestation, public installer and
                           Tools/e2e_release.sh against the installed binary.
