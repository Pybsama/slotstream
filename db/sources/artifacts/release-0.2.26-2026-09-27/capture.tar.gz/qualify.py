#!/usr/bin/env python3
"""v0.2.26 release qualification on the exact CI candidate.

Adapted from the v0.2.25 qualify.py preserved in
db/sources/artifacts/release-0.2.25-2026-09-24/capture.tar.gz. Differences:
it does not wait for the CI artifact (run it once the artifact exists), it
passes the reference Python explicitly because the scratch checkout has no
.venv, and after the full battery it runs the live gate this release's main
fix is about (one prefix cache write per turn). The disk tier restart gate
runs separately: its file-count checks predate the system prompt's shared
prefix and fail identically on 0.2.25.
"""
import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import sys
import time

base = pathlib.Path(__file__).resolve().parent
root = pathlib.Path('/private/tmp/claude-502/-Users-carlos-Projects-command-center/'
                    '6eecb8fb-463c-437b-b499-d3d971308e0c/scratchpad/slotstream')
reference_python = pathlib.Path.home() / 'Projects/slotstream/.venv/bin/python'
repo = 'carloslfu/slotstream'
run = sys.argv[1]
commit = sys.argv[2]
out = base / 'qualification'
out.mkdir(exist_ok=False)
started = time.time()
receipt = {'started': started, 'ci_run': run, 'commit': commit, 'passed': False, 'steps': []}


def save():
    (out / 'receipt.json').write_text(json.dumps(receipt, indent=2))


def step(label, cmd, timeout=3600, env=None):
    print(label, flush=True)
    t = time.monotonic()
    with (out / (label + '.log')).open('w') as f:
        r = subprocess.run(cmd, cwd=root, stdout=f, stderr=subprocess.STDOUT, timeout=timeout, env=env)
    receipt['steps'].append({'label': label, 'command': cmd, 'exit_code': r.returncode,
                             'seconds': time.monotonic() - t})
    save()
    if r.returncode:
        raise RuntimeError(f'{label} failed: {r.returncode}')


try:
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
    dirty = subprocess.check_output(['git', 'status', '--porcelain'], cwd=root, text=True)
    assert head == commit and not dirty, ('checkout is not the clean release commit', head, dirty)
    step('download', ['gh', 'run', 'download', run, '--repo', repo, '--name', 'slotstream-ci-candidate',
                      '--dir', str(base / 'ci')], 300)
    step('verify-archive', ['python3', 'Tools/release_candidate.py', '--archive',
                            str(base / 'ci/slotstream-arm64.tar.gz'), '--output', str(base / 'candidate')], 300)
    identity = json.loads((base / 'candidate/build-identity.json').read_text())
    mismatch = [p for p, h in identity['source'].items()
                if hashlib.sha256((root / p).read_bytes()).hexdigest() != h]
    assert not mismatch, mismatch
    receipt['source_inputs_matched'] = len(identity['source'])
    receipt['build_identity'] = identity
    candidate = str(base / 'candidate/slotstream')
    version = subprocess.check_output([candidate, '--version'], text=True).strip()
    assert version == '0.2.26', version
    receipt['version'] = version
    sys.path.insert(0, str(root / 'Tools'))
    from prefill_bench import preflight
    receipt['preflight'] = preflight(20.5)
    save()
    env = {k: v for k, v in os.environ.items() if not k.startswith(('SLOTSTREAM_', 'SS_DEBUG'))}
    env.update(SLOTSTREAM_TEST_BINARY=candidate, SLOTSTREAM_VERIFY_OUT=str(out / 'native'),
               SLOTSTREAM_REFERENCE_PYTHON=str(reference_python))
    # The full battery, preserving each gate's output in its output directory.
    step('native-full', ['bash', 'Tools/verify.sh'], 18000, env)
    plain = {k: v for k, v in env.items() if k not in ('SLOTSTREAM_TEST_BINARY', 'SLOTSTREAM_VERIFY_OUT')}
    step('prefix-turn-writes', ['python3', 'Tools/prefix_turn_writes_e2e.py', '--binary', candidate,
                                '--work', str(out / 'prefix-turn-writes'),
                                '--out', str(out / 'prefix-turn-writes.json')], 3600, plain)
    receipt['passed'] = True
except Exception as e:
    receipt['error'] = repr(e)
    print('QUALIFICATION ERROR', e, flush=True)
finally:
    receipt['finished'] = time.time()
    capture = out / 'temporary-gate-output'
    capture.mkdir(exist_ok=True)
    for p in pathlib.Path('/tmp').glob('ssv*'):
        if p.is_file() and not p.is_symlink() and p.stat().st_mtime >= started:
            shutil.copy2(p, capture / p.name)
    save()
    print('Qualification passed:', receipt['passed'], flush=True)
sys.exit(0 if receipt['passed'] else 1)
