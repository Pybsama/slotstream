@spikezz This is now released in [v0.2.30](https://github.com/carloslfu/slotstream/releases/tag/v0.2.30). Thanks again for the contribution and all the testing!
