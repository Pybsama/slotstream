#!/usr/bin/env python3
"""Derive context-automatic-v2.json from v1: every tier plans with --model at an
absent directory, and each expected window is re-read from doctor, twice.
Run from the repository root: python3 make_fixture_automatic_v2.py <binary>."""
import json, subprocess, sys
binary = sys.argv[1]
v1 = json.load(open('Tools/fixtures/context-automatic-v1.json'))
v2 = dict(v1); v2['schema_version'] = 2
v2['schema_note'] = open(sys.argv[2]).read().strip() if len(sys.argv) > 2 else ''
tiers = []
for t in v1['tiers']:
    args = t['args'][:1] + ["--model", "/nonexistent/context-gate-no-model"] + t['args'][1:]
    runs = [json.loads(subprocess.run([binary] + args, capture_output=True, text=True, check=True).stdout) for _ in range(2)]
    assert runs[0] == runs[1] and runs[0]['context_window_source'] == 'automatic'
    tiers.append({**t, 'args': args, 'expected_window': runs[0]['max_context_tokens']})
    print(t['tier'], t['expected_window'], '->', runs[0]['max_context_tokens'])
v2['tiers'] = tiers
open('Tools/fixtures/context-automatic-v2.json', 'w').write(json.dumps(v2, indent=2) + "\n")
