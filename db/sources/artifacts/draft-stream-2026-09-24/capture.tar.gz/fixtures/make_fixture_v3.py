#!/usr/bin/env python3
"""Derive context-default-v3.json from v2 by re-running each tier's doctor
command on a given binary. Prints the per-field differences against v2."""
import json, subprocess, sys
from pathlib import Path
root = Path(sys.argv[1]); binary = sys.argv[2]; out = Path(sys.argv[3]); note = sys.argv[4]
v2 = json.loads((root / "Tools/fixtures/context-default-v2.json").read_text())
v3 = dict(v2)
v3["schema_version"] = 3
v3["allowed_additions"] = v2["allowed_additions"] + ["mtp_streamed_experts"]
v3["schema_note"] = note
tiers = []
for tier in v2["tiers"]:
    # Plan without an installed model so the lookahead's charge never depends
    # on whether the correction file happens to sit in the default directory.
    tier = {**tier, "args": tier["args"][:1] + ["--model", "/nonexistent/context-gate-no-model"] + tier["args"][1:]}
    runs = [json.loads(subprocess.run([binary] + tier["args"], capture_output=True, text=True, check=True).stdout)
            for _ in range(2)]
    projected = [{k: d[k] for k in v2["projection_fields"] if k in d} for d in runs]
    assert projected[0] == projected[1], "doctor projection is not repeatable"
    extra = set(runs[0]) - set(v2["projection_fields"]) - set(v3["allowed_additions"])
    assert not extra, f"undeclared additions: {sorted(extra)}"
    changed = {k: (tier["expected"].get(k), projected[0].get(k)) for k in v2["projection_fields"]
               if tier["expected"].get(k) != projected[0].get(k)}
    print(tier["tier"], "decode_lookahead", runs[0].get("decode_lookahead"), "changed:", changed)
    tiers.append({**tier, "expected": projected[0]})
v3["tiers"] = tiers
out.write_text(json.dumps(v3, indent=2) + "\n")
