"""The 10 GB diagnostic: the landed build and the environment-guarded prototype,
each with and without its plain-decode lookahead, interleaved in one session."""
import json, collections, math, sys
rows = [json.loads(l) for l in open(sys.argv[1])]
by = collections.defaultdict(dict)
for r in rows: by[(r["round"], r["prompt"])][r["arm"]] = r
def ok(r, screen):
    if r.get("rc") != 0 or not r.get("tok_s"): return False
    if screen == "lenient": return r.get("swapouts", 0) <= 200
    if r.get("swapouts", 0) != 0: return False
    return screen != "strict" or r.get("swapins", 0) == 0
for base, arm, label in [("nola", "la", "landed lookahead vs landed without"),
                         ("pkadd", "pkaddla", "prototype lookahead vs prototype without"),
                         ("pkaddla", "la", "landed vs prototype, both with the lookahead"),
                         ("pkadd", "nola", "landed vs prototype, both without")]:
    print(label)
    for s in ("lenient", "primary", "strict"):
        xs, mism = [], 0
        for k, d in sorted(by.items()):
            if arm in d and base in d and ok(d[arm], s) and ok(d[base], s):
                xs.append(d[arm]["tok_s"] / d[base]["tok_s"]); mism += d[arm].get("output_ids") != d[base].get("output_ids")
        if not xs: print(f"  {s:8s} none"); continue
        gm = math.exp(sum(map(math.log, xs)) / len(xs))
        print(f"  {s:8s} {gm:.3f} n={len(xs)} above1={sum(x > 1 for x in xs)} [{min(xs):.3f}-{max(xs):.3f}] ids-differ={mism}")
