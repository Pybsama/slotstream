"""Paired decode ratios for the land2 confirmation under the three swap screens
of the experiment record: lenient (swap-outs <= 200), primary (no swap-outs),
strict (no swap-outs and no swap-ins)."""
import json, collections, math, os, sys
R = sys.argv[1]
FAMILIES = [
    ("plain lookahead vs none, 10 GB (--mtp auto: head off)", "land2_la10", "nola", "la"),
    ("streamed head + lookahead vs plain + lookahead, 12 GB", "land2_head12", "plain", "head"),
    ("plain lookahead vs none, 22 GB --mtp off", "land2_la22off", "nola", "la"),
]
def ok(r, screen):
    if r.get("rc") != 0 or not r.get("tok_s"): return False
    if screen == "lenient": return r.get("swapouts", 0) <= 200
    if r.get("swapouts", 0) != 0: return False
    return screen != "strict" or r.get("swapins", 0) == 0
for label, d, base, arm in FAMILIES:
    p = os.path.join(R, d, "results.jsonl")
    if not os.path.exists(p): print(label, "missing"); continue
    rs = [json.loads(l) for l in open(p)]
    by = collections.defaultdict(dict)
    for r in rs: by[(r["round"], r["prompt"])][r["arm"]] = r
    print(label)
    for s in ("lenient", "primary", "strict"):
        xs, mism, above = [], 0, 0
        for k, dd in sorted(by.items()):
            if arm in dd and base in dd and ok(dd[arm], s) and ok(dd[base], s):
                x = dd[arm]["tok_s"] / dd[base]["tok_s"]; xs.append(x)
                mism += dd[arm].get("output_ids") != dd[base].get("output_ids")
        if not xs: print(f"  {s:8s} none"); continue
        gm = math.exp(sum(math.log(x) for x in xs) / len(xs))
        print(f"  {s:8s} {gm:.3f} n={len(xs)} above1={sum(x > 1 for x in xs)} [{min(xs):.3f}-{max(xs):.3f}] id-mismatch={mism}")
    for a in (base, arm):
        v = sorted(r["tok_s"] for r in rs if r["arm"] == a and r.get("tok_s"))
        slots = sorted({r.get("pool_slots") for r in rs if r["arm"] == a})
        if v: print(f"  {a}: n={len(v)} median {v[len(v)//2]:.3f} tok/s, slots {slots}")
