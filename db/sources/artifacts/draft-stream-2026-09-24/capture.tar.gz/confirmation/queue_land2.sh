#!/bin/bash
SCR=/private/tmp/claude-502/-Users-carlos-Projects-command-center/a278f41e-1481-4ec0-8aa8-fcdef58ba358/scratchpad
cd $SCR
B=$SCR/binland2/slotstream
P="$SCR/prompts/r0005.txt $SCR/prompts/r0206.txt $SCR/prompts/r0096.txt $SCR/prompts/r0074.txt"
# A: plain-decode lookahead at 10 GB (the head stays off below its floor)
python3 ab2.py --binary $B --arms '{"la": {}, "nola": {"SLOTSTREAM_OPT_EXPERT_PREFETCH": "0"}}' \
  --prompts $P --rounds 2 --max-tokens 192 --memory-gb 10 --mtp auto --out $SCR/runs/land2_la10 > $SCR/runs/land2_la10.log 2>&1
# B: streamed draft head with the lookahead against plain decode with it, 12 GB
python3 ab2.py --binary $B --arms '{"head": {}, "plain": {"__MTP": "off"}}' \
  --prompts $P --rounds 2 --max-tokens 192 --memory-gb 12 --mtp auto --out $SCR/runs/land2_head12 > $SCR/runs/land2_head12.log 2>&1
# C: plain-decode lookahead at a large cache, 22 GB with the head off
python3 ab2.py --binary $B --arms '{"la": {}, "nola": {"SLOTSTREAM_OPT_EXPERT_PREFETCH": "0"}}' \
  --prompts $P --rounds 2 --max-tokens 192 --memory-gb 22 --mtp off --out $SCR/runs/land2_la22off > $SCR/runs/land2_la22off.log 2>&1
echo land2-done
