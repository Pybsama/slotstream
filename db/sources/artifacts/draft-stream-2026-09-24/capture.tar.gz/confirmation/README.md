# Landed streamed draft head and plain-decode lookahead, 2026-09-24

Binaries, by SHA-256:

- landed timing build (`binland2/slotstream`): `353d99cf6c88d567051dea6821444a0a5373d60bf5fe3f581f382900cb087c94`,
  with `mlx.metallib` `dc59d1cceb1a5c7e578232e6e41e28e2c73c9463ac6dbc3886c3ee17ffc270ed`;
- environment-guarded prototype of the experiments (`binexp/slotstream`): `653c07ce52558b65…`, the build the
  experiment record's arms used, with `arms_la.json`'s `kadd` and `kaddla` environments.

`queue_land2.sh` ran three comparisons with `ab2.py`, one model process at a time, four public corpus
prompts (`prompts/`), 192 greedy tokens, two rounds, arms rotated each round, readiness waiting for the
target plus 6 GB of reclaimable memory:

- `land2_la10`: 10 GB, `--mtp auto` (the head stays off below its floor); `la` is the default,
  `nola` sets `SLOTSTREAM_OPT_EXPERT_PREFETCH=0`.
- `land2_head12`: 12 GB; `head` is automatic mode (streamed head and lookahead), `plain` is `--mtp off`
  (plain decode with the lookahead).
- `land2_la22off`: 22 GB, `--mtp off`; `la` against `nola` as above. Both arms chose the 65,536-token
  automatic window.

`queue_land2b.sh` then interleaved four arms at 10 GB (`arms_land2b.json`): the landed build with and
without its lookahead, and the prototype with `kaddla` and `kadd`, both prototype arms at `--mtp off`.

Every run completed. Every pair recorded global swap-ins, so no comparison has a pair free of swap
activity; these results confirm direction only. `../analysis/` holds the screens (`land2_screens.txt`,
`land2b_screens.txt`) and `analyze.py` output.
