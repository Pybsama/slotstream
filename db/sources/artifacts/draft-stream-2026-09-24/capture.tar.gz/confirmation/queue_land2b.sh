#!/bin/bash
SCR=/private/tmp/claude-502/-Users-carlos-Projects-command-center/a278f41e-1481-4ec0-8aa8-fcdef58ba358/scratchpad
cd $SCR
# One model process at a time: wait for the landed confirmation queue.
while pgrep -f "queue_land2.sh" >/dev/null; do sleep 10; done
P="$SCR/prompts/r0005.txt $SCR/prompts/r0206.txt $SCR/prompts/r0096.txt $SCR/prompts/r0074.txt"
python3 ab2.py --binary $SCR/binland2/slotstream --arms "$(cat arms_land2b.json)" \
  --prompts $P --rounds 2 --max-tokens 192 --memory-gb 10 --mtp auto --out $SCR/runs/land2b_proto10 > $SCR/runs/land2b_proto10.log 2>&1
echo land2b-done
