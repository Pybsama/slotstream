#!/usr/bin/env python3
"""Paired, interleaved A/B decode benchmark for slotstream `run`.

Each round runs every prompt under every arm in a rotated arm order, one
process at a time, with a memory preflight, swap counters and thermal state
recorded around each run. Results append to <out>/results.jsonl.
"""
import argparse, json, os, re, subprocess, sys, time, statistics

PAGE = 16384

def vm():
    out = subprocess.run(["vm_stat"], capture_output=True, text=True).stdout
    def g(name):
        m = re.search(name + r":\s+(\d+)", out)
        return int(m.group(1)) if m else 0
    return {
        "free": g("Pages free"), "purgeable": g("Pages purgeable"), "file": g("File-backed pages"),
        "swapins": g("Swapins"), "swapouts": g("Swapouts"), "pageouts": g("Pageouts"),
    }

def reclaimable_gb(v):
    return (v["free"] + v["purgeable"] + v["file"]) * PAGE / 1e9

def thermal():
    out = subprocess.run(["pmset", "-g", "therm"], capture_output=True, text=True).stdout
    return " ".join(out.split())[-160:]

def load_avg():
    return os.getloadavg()[0]

def others_running():
    out = subprocess.run(["pgrep", "-fl", "slotstream (run|serve|launch)"], capture_output=True, text=True).stdout.strip()
    return out

GROUPS = {
    "gpu": ["GPU_Energy"], "cpu": ["CPU_Energy"],
    "mem": ["DRAM", "AMCC", "DCS", "FAB"],
    "io": ["PCIe_Port_0_Energy", "PCIe_Port_1_Energy", "apciec0_Energy", "apciec1_Energy", "apciec2_Energy"],
}

def energy_summary(path, u0, u1, decode_s, request_s):
    """Integrate cumulative channel energy (mJ) over the process window and
    over the final request window (generation), by linear interpolation."""
    rows = [l.rstrip("\n").split("\t") for l in open(path)]
    head = rows[0][1:]; data = [(int(r[0]), [float(x) for x in r[1:]]) for r in rows[1:] if len(r) == len(rows[0])]
    idx = {n: i for i, n in enumerate(head)}
    def at(t, i):
        prev = None
        for (tt, vals) in data:
            if tt >= t:
                if prev is None: return vals[i]
                pt, pv = prev
                return pv[i] + (vals[i] - pv[i]) * (t - pt) / max(1, tt - pt)
            prev = (tt, vals)
        return data[-1][1][i]
    out = {}
    windows = {"proc": (u0, u1)}
    if request_s:
        windows["gen"] = (u1 - int((request_s + 0.25) * 1e9), u1 - int(0.25 * 1e9))
    for wname, (a, b) in windows.items():
        for g, names in GROUPS.items():
            tot = 0.0
            for n in names:
                if n in idx: tot += at(b, idx[n]) - at(a, idx[n])
            out[f"e_{wname}_{g}_j"] = round(tot / 1000, 3)
        out[f"e_{wname}_s"] = round((b - a) / 1e9, 3)
    return out

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--binary", required=True)
    ap.add_argument("--arms", required=True, help="JSON object name -> env dict")
    ap.add_argument("--prompts", required=True, nargs="+")
    ap.add_argument("--rounds", type=int, default=3)
    ap.add_argument("--max-tokens", type=int, default=128)
    ap.add_argument("--memory-gb", type=float, default=10)
    ap.add_argument("--mtp", default="off")
    ap.add_argument("--extra", default="", help="extra CLI args")
    ap.add_argument("--out", required=True)
    ap.add_argument("--margin-gb", type=float, default=6)
    ap.add_argument("--settle", type=float, default=3)
    ap.add_argument("--base-env", default="{}")
    ap.add_argument("--energy", default="", help="path to the iorep sampler; records SoC energy per run")
    args = ap.parse_args()
    arms = json.loads(args.arms)
    base_env = json.loads(args.base_env)
    names = list(arms.keys())
    os.makedirs(args.out, exist_ok=True)
    res_path = os.path.join(args.out, "results.jsonl")
    for r in range(args.rounds):
        for p in args.prompts:
            order = names[r % len(names):] + names[:r % len(names)]
            for arm in order:
                # readiness
                waited = 0
                while True:
                    v0 = vm()
                    busy = others_running()
                    need = max([args.memory_gb] + [float(a.get("__MEM", 0)) for a in arms.values()])
                    if reclaimable_gb(v0) >= need + args.margin_gb and not busy:
                        break
                    if waited > 300:
                        print(f"readiness timeout: reclaimable {reclaimable_gb(v0):.1f} busy={busy!r}", file=sys.stderr)
                        sys.exit(2)
                    time.sleep(5); waited += 5
                time.sleep(args.settle)
                v0 = vm(); th0 = thermal(); la0 = load_avg()
                tag = f"r{r}-{os.path.basename(p).split('.')[0]}-{arm}"
                stats = os.path.join(args.out, tag + ".json")
                env = dict(os.environ); env.update(base_env); env.update(arms[arm])
                mtp = env.pop("__MTP", args.mtp)
                mem = env.pop("__MEM", str(args.memory_gb))
                binary = env.pop("__BIN", args.binary)
                cmd = [binary, "run", "--memory-gb", mem, "--mtp", mtp, "--greedy",
                       "--max-tokens", str(args.max_tokens), "--prompt-file", p, "--stats-json", stats]
                if args.extra: cmd += args.extra.split()
                for attempt in range(6):
                    sampler = None
                    if args.energy:
                        efile = open(os.path.join(args.out, tag + ".energy.tsv"), "w")
                        sampler = subprocess.Popen([args.energy, "100"], stdout=efile)
                        time.sleep(0.5)
                    u0 = time.clock_gettime_ns(time.CLOCK_UPTIME_RAW)
                    t0 = time.time()
                    with open(os.path.join(args.out, tag + ".err"), "w") as ef, open(os.path.join(args.out, tag + ".out"), "w") as of:
                        rc = subprocess.run(cmd, env=env, stdout=of, stderr=ef, timeout=1800).returncode
                    wall = time.time() - t0
                    u1 = time.clock_gettime_ns(time.CLOCK_UPTIME_RAW)
                    if sampler:
                        time.sleep(0.4); sampler.terminate(); sampler.wait(); efile.close()
                    if rc != 0 and "already running for this user" in open(os.path.join(args.out, tag + ".err")).read():
                        print(f"{tag}: model lock held elsewhere, retrying in 30 s", flush=True)
                        time.sleep(30); v0 = vm(); th0 = thermal(); la0 = load_avg()
                        continue
                    break
                v1 = vm(); th1 = thermal()
                rec = {"round": r, "prompt": os.path.basename(p), "arm": arm, "rc": rc, "wall": wall,
                       "swapins": v1["swapins"] - v0["swapins"], "swapouts": v1["swapouts"] - v0["swapouts"],
                       "pageouts": v1["pageouts"] - v0["pageouts"], "reclaimable_gb_before": round(reclaimable_gb(v0), 2),
                       "load_before": la0, "thermal_before": th0, "thermal_after": th1, "env": arms[arm]}
                try:
                    d = json.load(open(stats))
                    s = d["stats"]
                    its = s.get("interTokenSeconds") or []
                    steady = its[4:]
                    rec.update({
                        "decode_tokens": s["decodeTokens"], "decode_seconds": s["decodeSeconds"],
                        "tok_s": s["decodeTokens"] / s["decodeSeconds"] if s["decodeSeconds"] else None,
                        "steady_tok_s": len(steady) / sum(steady) if steady else None,
                        "decode_io_s": s.get("decodeIOSeconds"), "decode_records": s.get("decodeRecords"),
                        "hit_rate": s.get("expertHitRate"), "prefill_seconds": s.get("prefillSeconds"),
                        "first_token_s": s.get("firstTokenSeconds"), "peak_gb": s.get("peakMemoryGB"),
                        "accepted": s.get("acceptedDrafts"), "drafted": s.get("draftedTokens"),
                        "passes": s.get("decodeForwardPasses"),
                        "output_ids": d.get("output_ids"),
                        "pool_slots": d.get("effective_pool_slots"),
                    })
                except Exception as e:
                    rec["error"] = repr(e)
                if args.energy:
                    try:
                        rec.update(energy_summary(os.path.join(args.out, tag + ".energy.tsv"), u0, u1, rec.get("decode_seconds"), s.get("requestSeconds")))
                    except Exception as e:
                        rec["energy_error"] = repr(e)
                with open(res_path, "a") as f:
                    f.write(json.dumps(rec) + "\n")
                print(f"{tag}: rc={rc} tok/s={rec.get('tok_s') and round(rec['tok_s'],3)} steady={rec.get('steady_tok_s') and round(rec['steady_tok_s'],3)} "
                      f"io={rec.get('decode_io_s') and round(rec['decode_io_s'],2)} hit={rec.get('hit_rate') and round(rec['hit_rate'],3)} "
                      f"swapin={rec['swapins']} swapout={rec['swapouts']} peak={rec.get('peak_gb') and round(rec['peak_gb'],2)} wall={wall:.1f}", flush=True)
    print("done")

if __name__ == "__main__":
    main()
