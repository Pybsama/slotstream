#!/usr/bin/env python3
"""Paired analysis of ab.py results: per-arm paired ratios against a base arm."""
import json, sys, statistics, math, collections, argparse

ap = argparse.ArgumentParser()
ap.add_argument("results")
ap.add_argument("--base", required=True)
ap.add_argument("--metric", default="tok_s")
ap.add_argument("--max-swapouts", type=int, default=0)
args = ap.parse_args()

rows = [json.loads(l) for l in open(args.results)]
by = collections.defaultdict(dict)
for r in rows:
    by[(r["round"], r["prompt"])][r["arm"]] = r

def ok(r):
    return r.get("rc") == 0 and r.get(args.metric) and r.get("swapouts", 0) <= args.max_swapouts

arms = sorted({r["arm"] for r in rows if r["arm"] != args.base})
print(f"metric={args.metric} base={args.base}  (pairs need both runs rc=0 and swapouts<={args.max_swapouts})")
for arm in arms:
    ratios, per_prompt, mism, excluded = [], collections.defaultdict(list), 0, 0
    for key, d in sorted(by.items()):
        if arm not in d or args.base not in d:
            continue
        a, b = d[arm], d[args.base]
        if not (ok(a) and ok(b)):
            excluded += 1
            continue
        if a.get("output_ids") != b.get("output_ids"):
            mism += 1
        x = a[args.metric] / b[args.metric]
        ratios.append(x); per_prompt[key[1]].append(x)
    if not ratios:
        print(f"  {arm}: no eligible pairs ({excluded} excluded)"); continue
    gm = math.exp(sum(math.log(x) for x in ratios) / len(ratios))
    above = sum(1 for x in ratios if x > 1)
    lr = [math.log(x) for x in ratios]
    se = statistics.stdev(lr) / math.sqrt(len(lr)) if len(lr) > 1 else float("nan")
    print(f"  {arm}: pairs={len(ratios)} median={statistics.median(ratios):.4f} geomean={gm:.4f} "
          f"(~95% {math.exp(math.log(gm)-1.96*se):.4f}..{math.exp(math.log(gm)+1.96*se):.4f}) above1={above}/{len(ratios)} "
          f"range={min(ratios):.3f}..{max(ratios):.3f} output_mismatch={mism} excluded={excluded}")
    for p, xs in sorted(per_prompt.items()):
        print(f"      {p}: " + " ".join(f"{x:.3f}" for x in xs))
# absolute medians
print("absolute medians:")
for arm in [args.base] + arms:
    vals = [r[args.metric] for r in rows if r["arm"] == arm and ok(r)]
    io = [r["decode_io_s"] / r["decode_seconds"] for r in rows if r["arm"] == arm and ok(r) and r.get("decode_io_s") is not None]
    hit = [r["hit_rate"] for r in rows if r["arm"] == arm and ok(r) and r.get("hit_rate") is not None]
    if vals:
        print(f"  {arm}: n={len(vals)} median {statistics.median(vals):.3f}  io-share {statistics.median(io) if io else float('nan'):.3f}  hit {statistics.median(hit) if hit else float('nan'):.3f}")
