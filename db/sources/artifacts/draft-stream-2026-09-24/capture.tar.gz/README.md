# Streamed draft head, its floor and the plain-decode lookahead, landed, 2026-09-24

- `confirmation/`: the landed build's timing runs and the prototype cross-check (README there).
- `analysis/`: paired ratios under the all-pairs, primary (no swap-out) and strict (no swap-in or
  swap-out) screens.
- `gates/`: `slotstream-checks --tier t0 --tier t1` (75 checks, 31,991 assertions),
  `Tools/planner_gates.sh` (97), `draft-stream-check` (23), `decode-overlap-check` (1,672),
  `Tools/context_gates.py` (130), the context proxy (965,028 contract assertions) and
  `Tools/static_gates.sh`, all on the gated build `9c43ad03e3df2354925c87da8e7db29a6e8b56d63f18715ae0f812c8b6a17e1d`
  of the committed source. It differs from the timing build only by a documentation comment, and both
  exactness checks also passed on the timing build before the timing runs.
- `fixtures/`: the scripts that derived `Tools/fixtures/context-default-v3.json` and
  `context-automatic-v2.json` from their earlier versions.
