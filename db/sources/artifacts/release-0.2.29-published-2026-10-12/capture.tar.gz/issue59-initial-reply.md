Thanks @dittsn, these outputs are useful. This is another report of severe stalls with GPU keepalive enabled, alongside #55. I'm removing keepalive entirely in v0.2.29, which is going through the full release tests now.

For the current release, keep using `--gpu-keepalive off`, or set `export SLOTSTREAM_GPU_KEEPALIVE=off` for all runs. I'll follow up here once the new release is published and checked.
