@dittsn, [v0.2.29 is now available](https://github.com/carloslfu/slotstream/releases/tag/v0.2.29) and removes GPU keepalive entirely. The full model tests and a fresh public installation passed.

Upgrade with:
```sh
curl -fsSL https://raw.githubusercontent.com/carloslfu/slotstream/main/install.sh | sh
slotstream --version
```
Check that it prints `0.2.29`, then remove `--gpu-keepalive off` from your saved run/server commands. The flag no longer exists, and `SLOTSTREAM_GPU_KEEPALIVE` can be unset.

Closing this alongside #55 because the problematic keepalive path is removed. I haven't tested on your M1 Max, so please reply if the new version still stalls. Thanks for reporting it!
