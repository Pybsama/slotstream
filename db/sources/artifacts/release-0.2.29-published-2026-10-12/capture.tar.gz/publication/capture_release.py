import hashlib, io, json, subprocess, tarfile
from pathlib import Path
ROOT=Path.cwd(); BASE=Path('/tmp/slotstream-release-0.2.29'); PUB=BASE/'publication'
publication=json.loads((PUB/'publication-verification.json').read_text())
installed=json.loads((PUB/'installed-acceptance/result.json').read_text())
native=json.loads((BASE/'native-acceptance-result.json').read_text())
assert native['exit_code']==installed['exit_code']==0 and installed['server_reaped']
assert publication['matches_ci_archive'] and publication['attestation_verified']
assert 'passed 35, failed 0' in (BASE/'native-acceptance.log').read_text()
assert not any(line.startswith(('SKIP  ','FAIL  ')) for line in (BASE/'native-acceptance.log').read_text().splitlines())
allowed={'.json','.jsonl','.log','.txt','.py','.sh','.md','.sha256'}
files=[]; excluded=[]
for folder in (BASE/'native-acceptance',PUB):
 for p in sorted(folder.rglob('*')):
  if not p.is_file() or p.is_symlink():continue
  if p.name.startswith('capture-') or p.name in ('measurement-body.md',):continue
  if p.suffix not in allowed:
   excluded.append({'path':str(p.relative_to(BASE)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()});continue
  try:p.read_text()
  except UnicodeDecodeError:continue
  files.append(p)
names=['native-acceptance.log','native-acceptance-protocol.json','native-acceptance-result.json','ci-candidate-verification.json','engine-ci-final.json','mac-ci-final.json','context-ci-final.json','all-issues-audit.json','issue55-resume.json','issue54-resume.json','issue59-before.json','issue59-initial-reply.md','issue59-initial-reply-url.txt']
files += [BASE/name for name in names]
files += [BASE/'ci-unpacked/build-identity.json', BASE/'ci-candidate/slotstream-arm64.tar.gz.sha256']
files=sorted(set(files))
inventory={'captured':[{'path':str(p.relative_to(BASE)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files],'excluded_generated_binary_fixtures':excluded}
archive=ROOT/'db/sources/artifacts/release-0.2.29-published-2026-10-12/capture.tar.gz'
archive.parent.mkdir(parents=True,exist_ok=False)
with tarfile.open(archive,'w:gz') as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(BASE)),recursive=False)
 data=(json.dumps(inventory,indent=2)+'\n').encode(); info=tarfile.TarInfo('inventory.json');info.size=len(data);tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
 for item in inventory['captured']:
  data=tar.extractfile(item['path']).read()
  assert hashlib.sha256(data).hexdigest()==item['sha256'] and len(data)==item['bytes']
archive_sha=hashlib.sha256(archive.read_bytes()).hexdigest()
report={'archive':str(archive.relative_to(ROOT)),'sha256':archive_sha,'captured_files':len(files),'roundtrip_verified':True}
(PUB/'capture-inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
(PUB/'capture-result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
