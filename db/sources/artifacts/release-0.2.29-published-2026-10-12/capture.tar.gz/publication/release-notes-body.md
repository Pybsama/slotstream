GPU keepalive has been removed completely after the severe decode stalls reported on a base-M5 MacBook Air (#55) and an M1 Max Mac Studio (#59). Generation no longer submits artificial GPU work or changes keepalive behavior based on AC power. Direct demand reads remain.

After upgrading, remove `--gpu-keepalive` from saved commands. You can also remove `SLOTSTREAM_GPU_KEEPALIVE` from your environment. Ollama's unrelated `keep_alive` field remains supported.

The full native release battery passed against the exact CI executable. This release does not claim to fix the separate long-context slowdown reported in #54.

The development Mac app also includes the Home switcher and refreshed startup recipe identities described in the [changelog](https://github.com/carloslfu/slotstream/blob/5728fc2d64d7d918f1c16c3f45538d6fd2b9e900/CHANGELOG.md). This is an engine release, not a public Desktop installer.
