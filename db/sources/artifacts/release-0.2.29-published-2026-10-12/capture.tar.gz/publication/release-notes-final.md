GPU keepalive has been removed completely after the severe decode stalls reported on a base-M5 MacBook Air (#55) and an M1 Max Mac Studio (#59). Generation no longer submits artificial GPU work or changes keepalive behavior based on AC power. Direct demand reads remain.

After upgrading, remove `--gpu-keepalive` from saved commands. You can also remove `SLOTSTREAM_GPU_KEEPALIVE` from your environment. Ollama's unrelated `keep_alive` field remains supported.

The full native release battery passed against the exact CI executable. This release does not claim to fix the separate long-context slowdown reported in #54.

The development Mac app also includes the Home switcher and refreshed startup recipe identities described in the [changelog](https://github.com/carloslfu/slotstream/blob/5728fc2d64d7d918f1c16c3f45538d6fd2b9e900/CHANGELOG.md). This is an engine release, not a public Desktop installer.

Built and tested by CI from commit 5728fc2d64d7d918f1c16c3f45538d6fd2b9e900 (build and complete CI log: https://github.com/carloslfu/slotstream/actions/runs/38279294771).

This release publishes that exact archive after source verification and signing (release log: https://github.com/carloslfu/slotstream/actions/runs/38342292014).


sha256: 6bb418c2fa477b15391a67d261eda65f9b45eea38c7594c39ae033c7d865afb6

Verify provenance: gh attestation verify slotstream-arm64.tar.gz --repo carloslfu/slotstream

Install or upgrade: curl -fsSL https://raw.githubusercontent.com/carloslfu/slotstream/main/install.sh | sh
