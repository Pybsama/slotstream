import hashlib, json, os, socket, subprocess, sys, time
from pathlib import Path
ROOT=Path.cwd(); BASE=Path('/tmp/slotstream-release-0.2.29/publication'); OUT=BASE/'installed-acceptance'
OUT.mkdir(exist_ok=False)
sys.path.insert(0,str(ROOT/'Tools'))
from context_qualification import quiet_preflight
from prefill_bench import run_child, vm_snapshot
from serve_bench import verified_build, wait_ready, stop_server
publication=json.loads((BASE/'publication-verification.json').read_text())
assert publication['matches_ci_archive'] and publication['attestation_verified']
installer=OUT/'install.sh'
installer.write_bytes(subprocess.check_output(['curl','-fsSL','https://raw.githubusercontent.com/carloslfu/slotstream/main/install.sh']))
assert installer.read_bytes()==(ROOT/'install.sh').read_bytes()
install_root=BASE/'install-root'; binary=install_root/'bin/slotstream'
env={k:v for k,v in os.environ.items() if not k.startswith(('SLOTSTREAM_','SS_DEBUG_')) and k!='BIN'}
env.update(SLOTSTREAM_ROOT_DIR=str(install_root),PATH=str(install_root/'bin')+os.pathsep+env['PATH'])
protected=[Path.home()/name for name in ('.zshrc','.zprofile','.bashrc','.bash_profile','.profile','.slotstream/bin/slotstream','.slotstream/bin/mlx.metallib','.slotstream/bin/build-identity.json','.local/bin/slotstream')]+[Path('/usr/local/bin/slotstream'),Path('/opt/homebrew/bin/slotstream')]
def protected_snapshot():
    return {str(p): {'exists':p.exists(),'symlink':str(p.readlink()) if p.is_symlink() else None,'sha256':hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None} for p in protected}
protected_before=protected_snapshot()
install=OUT/'installer'; install.mkdir()
assert run_child(['sh',str(installer)],env,install,300)==0
protected_after=protected_snapshot()
assert protected_before==protected_after, 'isolated installer changed a protected user file'
(OUT/'user-install-preservation.json').write_text(json.dumps({'checked_files':[str(p) for p in protected],'unchanged':True,'method':'SHA-256 and symlink-target comparison before and after the isolated installer'},indent=2)+'\n')
assert subprocess.check_output([str(binary),'--version'],text=True).strip()=='0.2.29'
identity=verified_build(binary)['identity']
assert identity['binary_sha256']==publication['binary_sha256']
with socket.socket() as sock:
    sock.bind(('127.0.0.1',0)); port=sock.getsockname()[1]
command=[str(binary),'serve','--port',str(port),'--quantization','auto','--memory-limit-gb','10','--max-context','32768','--mtp','on','--vision','off']
record={'command':command,'installer_command':['sh',str(installer)],'installer_sha256':hashlib.sha256(installer.read_bytes()).hexdigest(),
        'isolated_install_root':str(install_root),'binary_sha256':identity['binary_sha256'],'before':quiet_preflight(13),'started_at':time.time(),
        'suite':['bash','Tools/e2e_release.sh',str(port)],'suite_sha256':hashlib.sha256((ROOT/'Tools/e2e_release.sh').read_bytes()).hexdigest()}
(OUT/'protocol.json').write_text(json.dumps(record,indent=2)+'\n')
client=OUT/'client'; client.mkdir(); env['BIN']=str(binary)
print('Running the existing installed-release suite with Auto selection and a 10 GB adaptive ceiling.',flush=True)
with (OUT/'server.log').open('wb') as log:
    server=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    record['server_pid']=server.pid
    try:
        wait_ready(server,port)
        record['exit_code']=run_child(record['suite'],env,client,1800)
    except Exception as exc:
        record['exit_code']=1; record['error']=str(exc)
    finally:
        stop_server(server)
        record['server_reaped']=server.poll() is not None
        record['after']=vm_snapshot(); record['elapsed_seconds']=time.time()-record['started_at']
        (OUT/'result.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ['exit_code','server_reaped','elapsed_seconds']}),flush=True)
raise SystemExit(record['exit_code'])
