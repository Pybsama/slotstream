@Arsenitim, [v0.2.29 is available](https://github.com/carloslfu/slotstream/releases/tag/v0.2.29). GPU keepalive is completely removed. The exact release build passed the full model tests, and I checked the public installer and installed server.

Upgrade with:
```sh
curl -fsSL https://raw.githubusercontent.com/carloslfu/slotstream/main/install.sh | sh
slotstream --version
```
It should report `0.2.29`. Remove `--gpu-keepalive off` from saved commands after upgrading, since that option no longer exists. You can also unset `SLOTSTREAM_GPU_KEEPALIVE`.

Closing this because the problematic keepalive path is gone. I haven't rerun on a base M5, so please reply if you still see stalls on the new version. Thanks again for the careful comparison!
