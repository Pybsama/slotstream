"""Read-only five-second process and global memory observations; exits with owned server."""
import ctypes,ctypes.util,json,subprocess,sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
from prefill_bench import vm_snapshot
root=Path(sys.argv[1]);pid=json.loads((root/'reproduction-status.json').read_text())['pid']
lib=ctypes.CDLL(ctypes.util.find_library('proc'))
with (root/'memory-observations.jsonl').open('x') as f:
 for _ in range(1500):
  b=ctypes.create_string_buffer(296)
  if lib.proc_pid_rusage(pid,4,b)!=0: break
  pressure=int(subprocess.check_output(['sysctl','-n','kern.memorystatus_vm_pressure_level'],text=True))
  vm=vm_snapshot();vm.pop('raw',None)
  f.write(json.dumps({'unix_seconds':time.time(),'pid':pid,'physical_bytes':int.from_bytes(b.raw[72:80],'little'),'lifetime_peak_bytes':int.from_bytes(b.raw[240:248],'little'),'pressure':pressure,'vm':vm})+'\n');f.flush()
  if json.loads((root/'reproduction-status.json').read_text())['status']!='running':break
  time.sleep(5)
print('Observer exited')
