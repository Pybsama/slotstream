import hashlib,json,math,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parent
arms=['release-prefix','release-portable-guarded','release-portable-lookahead-guarded']
rows=[];identities={}
for arm in arms:
 r=root/arm;s=json.loads((r/'reproduction-status.json').read_text())
 assert s['status']=='completed' and s['child_reaped'] and s['child_exit']==0,(arm,s['status'])
 assert 'resource_stop' not in s and 'observer_error' not in s
 assert not subprocess.run(['ps','-p',str(s['pid']),'-o','comm='],capture_output=True,text=True).stdout.strip(),arm
 subprocess.run([sys.executable,str(root/'summarize.py'),str(r)],stdout=subprocess.DEVNULL,check=True)
 for record in json.loads((r/'summary.json').read_text()):
  d=json.loads((r/record['response']).read_text());b=d['slotstream_benchmark'];st=b['stats']
  assert record['prompt_tokens'] in [32320,32770] and record['output_tokens']==500
  assert d['done_reason']=='length' and st['decodeForwardPasses']==499
  assert b['effective_mtp'] is False and b['effective_prefill_chunk']==256
  slots=960 if 'lookahead' in arm else 640
  assert b['effective_pool_slots']==slots
  assert st['reusedPrefixTokens']==st['completePromptStores']==st['prefixCheckpointStores']==0
  if 'portable' in arm:
   assert b['optimizations']['fusedRoPE'] is False
   assert b['optimizations'].get('fusedPrefillAttention') is None
   assert b['optimizations'].get('fusedPrefillWorkspace') is None
   assert st['fusedRoPERotationsScheduled']==0
  if 'lookahead' in arm:
   p=st['expertPrefetch'];assert p['mode']=='on' and p['forecastTap']=='attention-corrected'
   assert p['passes']==499 and p['issued']>0 and p['adopted']>0 and p['failed']==0
  else:assert st.get('expertPrefetch') is None
  assert st['peakMemoryGB'] < (10 if 'lookahead' in arm else 9)
  vm0=st['generatorVMBefore'];vm1=st['generatorVMAfter']
  rows.append({'arm':arm,'prompt_tokens':record['prompt_tokens'],'output_tokens':record['output_tokens'],'decode_tps':record['decode_tps'],
   'prefill_seconds':st['prefillSeconds'],'below':record['below_all'],'above':record['above_all'],
   'near_below':record['near_below_32705_32768'],'near_above':record['near_above_32770_32819'],
   'peak_memory_gb':st['peakMemoryGB'],'swap_delta':{k:vm1[k]-vm0[k] for k in ['swapins','swapouts']},
   'operating_before':st['generatorSystemBefore'],'operating_after':st['generatorSystemAfter'],
   'clean_timing_eligible':False})
  identities[arm+'-'+str(record['prompt_tokens'])]={name:hashlib.sha256(json.dumps(b[name],separators=(',',':')).encode()).hexdigest() for name in ['prompt_ids','output_ids']}
 interrupted=json.loads((root/'release-portable-lookahead/reproduction-status.json').read_text())
 assert interrupted['status']=='failed' and interrupted['child_reaped']
helpers={name:hashlib.sha256((root/name).read_bytes()).hexdigest()==hashlib.sha256((Path('/Users/carlos/Projects/slotstream/Tools')/name).read_bytes()).hexdigest() for name in ['prefill_bench.py','serve_bench.py']}
assert all(helpers.values())
expected='4d7d4ed4d2a19b5991d47f4731198932cd616e5c2722fcf8b6e37612c232f051'
assert hashlib.sha256(Path('/tmp/slotstream-release-0.2.29/publication/install-root/bin/slotstream').read_bytes()).hexdigest()==expected
result={'completed_requests':len(rows),'output_tokens':sum(x['output_tokens'] for x in rows),'all_payload_and_runtime_checks_pass':True,'helpers_unchanged':helpers,'binary_sha256_after':expected,'rows':rows,'token_identities':identities,
 'claim_limit':'Exploratory functional reproduction. All timings excluded from clean performance qualification; no M4/large-pool reproduction or verified issue fix.'}
(root/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'completed_requests':len(rows),'output_tokens':result['output_tokens'],'checks':'passed'}))
