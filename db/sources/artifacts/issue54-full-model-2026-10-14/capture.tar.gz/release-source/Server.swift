// Minimal dependency-free HTTP/1.1 server exposing the Ollama API surface
// (/api/*) plus the OpenAI-compatible /v1/chat/completions. Localhost,
// single-flight generation, chunked streaming (NDJSON for /api, SSE for /v1).

import CoreFoundation
import Foundation
import MLX

public struct ServerError: Error, CustomStringConvertible {
    public let description: String
    public init(_ s: String) { description = s }
}

public final class Server {
    /// Explicit opt-in for local benchmark processes. Ordinary wire responses
    /// retain their existing schema and do not run the footprint sampler.
    private static let benchmarkDetailsEnabled = ProcessInfo.processInfo.environment["SLOTSTREAM_BENCH_DETAILS"] == "1"
    let engine: Engine
    let port: UInt16
    /// Total on-disk size of the weights, reported by /api/tags and /api/ps.
    /// Supplied by the caller so it can come from the pinned manifest rather
    /// than a second hand-maintained copy of the number.
    let weightsBytes: Int
    var listenFD: Int32 = -1
    /// Package-only observation for real-socket lifecycle diagnostics. Install
    /// before handling connections; it never changes queue limits or payloads.
    package var outputObserver: ((Int32, BoundedOutput) -> Void)?
    /// Requests in flight and the clients registered through
    /// `POST /slotstream/clients`; `/slotstream/status` reports both.
    public let activity = ServerActivity()
    /// Stop after this many seconds with no request and no registered client
    /// that is still running. `stop` runs once, on a watcher thread, after new
    /// requests are refused. Set before `run()`.
    public var idleExit: (seconds: Double, stop: () -> Void)?
    /// Local diagnostics contain request paths and phases, never prompt text.
    public var onDiagnostic: ((String) -> Void)?

    private func makeOutput(_ fd: Int32, streaming: Bool = true) -> BoundedOutput? {
        guard streaming, engine.model.optimizations.boundedOutputQueue else { return nil }
        let output = BoundedOutput(fd: fd)
        outputObserver?(fd, output)
        return output
    }

    private func finishOutput(_ output: BoundedOutput?) {
        guard let output else { return }
        if !output.finish() {
            let snapshot = output.snapshot
            onDiagnostic?("stream ended: \(snapshot.failureReason ?? "output failed"); "
                + "\(snapshot.writtenBytes)/\(snapshot.queuedBytes) accepted bytes written")
        }
    }

    private func requestRefusal(_ fd: Int32, _ error: Error, dialect: String, cors: String) {
        let failure = error as? RequestFailure
            ?? RequestFailure(.invalidConfiguration, String(describing: error))
        guard failure.code != .clientCancelled else { return }
        let body: [String: Any]
        if dialect == "anthropic" {
            // Claude Code compacts and retries when the message says the
            // prompt is too long, so an overflow found during preparation
            // carries those words too.
            let message = failure.code == .contextLengthExceeded
                ? "prompt is too long: " + failure.message : failure.message
            body = AnthropicDialect.errorBody(type: AnthropicDialect.errorType(httpStatus: failure.httpStatus),
                                              message: message)
        } else if dialect == "ollama" {
            body = ["error": failure.message, "code": failure.code.rawValue, "details": failure.json]
        } else if dialect == "gateway" {
            var gateway = GatewayDialect.Failure(failure.code.rawValue, failure.message).body
            gateway["details"] = failure.json
            body = gateway
        } else { body = ["error": failure.json] }
        respondJSON(fd, body, status: failure.httpStatus, cors: cors)
    }

    public init(engine: Engine, port: UInt16, weightsBytes: Int = 0, listenFD: Int32 = -1) {
        self.engine = engine
        self.port = port
        self.weightsBytes = weightsBytes
        self.listenFD = listenFD
        if Self.benchmarkDetailsEnabled { engine.generator.footprintSampling = true }
    }

    private func benchmarkMetadata(_ stats: GenStats, prompt: [Int], output: [Int]) -> [String: Any] {
        ["stats": try! JSONSerialization.jsonObject(with: JSONEncoder().encode(stats)),
         "prompt_ids": prompt, "output_ids": output,
         "effective_prefill_chunk": engine.generator.prefillChunk,
         "effective_pool_slots": engine.model.pool.slots,
         "effective_mtp": engine.model.mtpHead != nil && engine.generator.speculationEnabled,
         "optimizations": try! JSONSerialization.jsonObject(with: JSONEncoder().encode(engine.model.optimizations))]
    }

    /// Claim the port. Callers bind *before* loading the model so "address
    /// already in use" — running `serve` twice is the common case — costs a
    /// second and one sentence instead of a full load and a fatalError.
    public static func bindPort(_ port: UInt16) throws -> Int32 {
        let fd = socket(AF_INET, SOCK_STREAM, 0)
        guard fd >= 0 else {
            throw ServerError("cannot create a socket: \(String(cString: strerror(errno)))")
        }
        var yes: Int32 = 1
        setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &yes, socklen_t(MemoryLayout<Int32>.size))
        var addr = sockaddr_in()
        addr.sin_family = sa_family_t(AF_INET)
        addr.sin_port = port.bigEndian
        addr.sin_addr = in_addr(s_addr: inet_addr("127.0.0.1"))
        let rc = withUnsafePointer(to: &addr) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                bind(fd, $0, socklen_t(MemoryLayout<sockaddr_in>.size))
            }
        }
        guard rc == 0 else {
            let code = errno
            close(fd)
            throw ServerError(
                "cannot listen on 127.0.0.1:\(port): \(String(cString: strerror(code)))"
                    + (code == EADDRINUSE
                        ? ". Another server, such as Slotstream or Ollama, is already there; stop it or pass --port. "
                            + "`slotstream stop\(port == 11434 ? "" : " --port \(port)")` stops a Slotstream server, "
                            + "also one `slotstream launch` started in the background." : ""))
        }
        return fd
    }

    /// Bounded so a client that opens sockets and never speaks cannot exhaust
    /// the thread pool (each connection costs one thread). The accept loop
    /// never waits on this: a full pool answers 503 at once, because blocking
    /// the loop stops the server answering *anything* — a health check
    /// included — which a client cannot tell apart from a crash.
    static let maxConcurrentConnections = 32
    private let connSlots = DispatchSemaphore(value: maxConcurrentConnections)
    /// Unix time this process started serving; /v1/models reports it.
    private let startedAt = Int(Date().timeIntervalSince1970)

    public func run() throws -> Never {
        // A client that disappears mid-stream makes write() raise SIGPIPE, whose
        // default action kills the process. Ignoring it turns that into EPIPE,
        // which is what `send` already handles by returning false.
        signal(SIGPIPE, SIG_IGN)
        if listenFD < 0 { listenFD = try Self.bindPort(port) }
        listen(listenFD, 16)
        print("slotstream listening on http://127.0.0.1:\(port)")
        print("""
        try it:
          curl localhost:\(port)/api/chat -d '{"model": "\(engine.modelName)", "messages": [{"role": "user", "content": "hello"}]}'
        or point any Ollama or OpenAI client at http://localhost:\(port)
        """)
        fflush(stdout)  // visible immediately even when stdout is a file/pipe
        if let idleExit, idleExit.seconds > 0 {
            let interval = min(15, max(0.5, idleExit.seconds / 4))
            Thread.detachNewThread { [activity] in
                while true {
                    Thread.sleep(forTimeInterval: interval)
                    if activity.stopIfIdle(for: idleExit.seconds) {
                        idleExit.stop()
                        return
                    }
                }
            }
        }
        while true {
            let fd = accept(listenFD, nil, nil)
            if fd < 0 { continue }
            // A stalled client must not pin a thread forever: give reads a
            // deadline, and cap how many connections can be in flight.
            Self.setReadTimeout(fd, seconds: Self.readTimeoutSeconds)
            var st = timeval(tv_sec: 120, tv_usec: 0)
            setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &st, socklen_t(MemoryLayout<timeval>.size))
            var one: Int32 = 1
            setsockopt(fd, SOL_SOCKET, SO_NOSIGPIPE, &one, socklen_t(MemoryLayout<Int32>.size))
            // Never block the accept loop; see maxConcurrentConnections.
            guard connSlots.wait(timeout: .now()) == .success else {
                let body = Data(#"{"error":"server busy: too many open connections"}"#.utf8)
                let head = "HTTP/1.1 503 Service Unavailable\r\n"
                    + "Content-Type: application/json\r\nRetry-After: 1\r\n"
                    + "Content-Length: \(body.count)\r\nConnection: close\r\n\r\n"
                _ = self.send(fd, Data(head.utf8) + body)
                close(fd)
                continue
            }
            Thread.detachNewThread { [weak self] in
                defer { self?.connSlots.signal() }
                self?.handle(fd)
            }
        }
    }

    // MARK: connection handling

    package struct Request {
        package init() {}
        package var method = ""
        package var path = ""
        package var body = Data()
        package var headers: [String: String] = [:]
    }

    /// Largest request body accepted. Text prompts are tiny, but vision inputs
    /// (base64-encoded images) commonly reach several MB and must be served.
    /// The cap still exists to keep the read bounded against an unbounded
    /// attacker; requests past it get a 413 instead of a dropped connection.
    package static let maxBodyBytes = 32 << 20

    /// Why a request could not be read. `.closed` means the peer went away or
    /// timed out, so there is nobody left to tell; everything else gets a real
    /// status line, because dropping the connection reads as a crash.
    package enum ReadOutcome {
        case ok(Request)
        case closed
        /// `target` is the request line's target, when it was read, so the
        /// refusal can take the shape of the API the client called.
        case fail(status: String, message: String, target: String?)
    }

    /// The most an oversized upload is read and discarded before its 413, so
    /// the client, still sending, gets the answer instead of a reset. Read in
    /// fixed chunks and dropped; never held.
    static let maxDrainBytes = 256 << 20

    /// How long a connection may wait for the next thing a client sends.
    package static let readTimeoutSeconds = 30

    /// The discarding above waits only this long for each chunk, and never
    /// longer than `maxDrainSeconds` in total. A client that is still
    /// uploading keeps delivering, so these end the drain as soon as one
    /// stops: a client that declared a huge body and then went quiet gets its
    /// 413 now, instead of holding it until the connection's read deadline.
    package static let drainChunkSeconds = 2
    package static let maxDrainSeconds = 10.0

    /// Read and discard `left` bytes, in reads of at most `chunk`. Stops early
    /// when a read returns nothing or `expired` reports the deadline passed,
    /// and answers what was left unread.
    package static func drainBody(_ left: Int, chunk: Int,
                                  read: (Int) -> Int, expired: () -> Bool) -> Int {
        var left = left
        while left > 0, !expired() {
            let n = read(min(chunk, left))
            if n <= 0 { break }
            left -= n
        }
        return left
    }

    /// The deadline a connection's reads wait against.
    static func setReadTimeout(_ fd: Int32, seconds: Int) {
        var tv = timeval(tv_sec: seconds, tv_usec: 0)
        setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, socklen_t(MemoryLayout<timeval>.size))
    }

    /// The target of a request head's first line.
    package static func requestTarget(_ head: String) -> String? {
        let first = head.prefix { $0 != "\r" && $0 != "\n" }.split(separator: " ")
        return first.count >= 2 ? String(first[1]) : nil
    }

    package static func readRequest(_ fd: Int32) -> ReadOutcome {
        var buf = Data()
        var tmp = [UInt8](repeating: 0, count: 65536)
        var headerEnd: Range<Data.Index>? = nil
        while headerEnd == nil {
            let n = read(fd, &tmp, tmp.count)
            if n <= 0 { return .closed }
            buf.append(contentsOf: tmp[0 ..< n])
            headerEnd = buf.range(of: Data("\r\n\r\n".utf8))
            // Enforce the bound even when this read completes the head.
            // Count through CRLFCRLF, but not body bytes read alongside it.
            let headerBytes = headerEnd?.upperBound ?? buf.count
            if headerBytes > 64 << 10 {
                return .fail(
                    status: "431 Request Header Fields Too Large",
                    message: "request headers are larger than 64 KiB",
                    target: Self.requestTarget(String(decoding: buf.prefix(8192), as: UTF8.self)))
            }
        }
        let headData = buf[..<headerEnd!.lowerBound]
        let head = String(data: headData, encoding: .utf8) ?? ""
        let req: Request
        let contentLength: Int
        switch Self.parseHead(head) {
        case let .fail(status, message):
            if status.hasPrefix("413"), let declared = head.split(separator: "\r\n").lazy
                .compactMap({ line -> Int? in
                    let kv = line.split(separator: ":", maxSplits: 1)
                    guard kv.count == 2, kv[0].trimmingCharacters(in: .whitespaces).lowercased() == "content-length"
                    else { return nil }
                    return Int(kv[1].trimmingCharacters(in: .whitespaces))
                }).first {
                let left = min(declared, Self.maxDrainBytes) - (buf.count - headerEnd!.upperBound)
                if left > 0 {
                    Self.setReadTimeout(fd, seconds: Self.drainChunkSeconds)
                    let end = Date().addingTimeInterval(Self.maxDrainSeconds)
                    var sink = [UInt8](repeating: 0, count: tmp.count)
                    _ = Self.drainBody(left, chunk: sink.count,
                                       read: { read(fd, &sink, $0) }, expired: { Date() >= end })
                    Self.setReadTimeout(fd, seconds: Self.readTimeoutSeconds)
                }
            }
            return .fail(status: status, message: message, target: Self.requestTarget(head))
        case let .ok(parsed, length):
            req = parsed
            contentLength = length
        }
        var body = Data(buf[headerEnd!.upperBound...].prefix(contentLength))
        while body.count < contentLength {
            let n = read(fd, &tmp, min(tmp.count, contentLength - body.count))
            if n <= 0 { break }
            body.append(contentsOf: tmp[0 ..< n])
        }
        guard body.count == contentLength else { return .closed }
        var complete = req
        complete.body = body
        return .ok(complete)
    }

    /// What the head said, or why the request cannot be served. Split out of
    /// the socket read so every framing rule below is reachable from a test
    /// with a string instead of a live server and a real client.
    package enum HeadOutcome {
        case ok(Request, contentLength: Int)
        case fail(status: String, message: String)
    }

    package static func parseHead(_ head: String) -> HeadOutcome {
        var req = Request()
        let lines = head.split(separator: "\r\n", omittingEmptySubsequences: false)
        let parts = lines.first?.split(separator: " ") ?? []
        if parts.count >= 2 {
            req.method = String(parts[0])
            req.path = String(parts[1])
        }
        var contentLength = 0
        var sawContentLength = false
        var sawTransferEncoding = false
        for l in lines.dropFirst() {
            let kv = l.split(separator: ":", maxSplits: 1)
            if kv.count == 2 {
                let key = kv[0].trimmingCharacters(in: .whitespaces).lowercased()
                let value = kv[1].trimmingCharacters(in: .whitespaces)
                if key == "content-length" {
                    if sawContentLength {
                        return .fail(status: "400 Bad Request", message: "Content-Length appears more than once")
                    }
                    sawContentLength = true
                    // Framing accepts one ASCII decimal field, never a signed
                    // value or a comma-list assembled from multiple fields.
                    guard !value.isEmpty, value.utf8.allSatisfy({ $0 >= 48 && $0 <= 57 }),
                          let length = Int(value) else {
                        return .fail(status: "400 Bad Request", message: "Content-Length is not a number")
                    }
                    contentLength = length
                } else if key == "transfer-encoding" {
                    if sawTransferEncoding {
                        return .fail(status: "400 Bad Request", message: "Transfer-Encoding appears more than once")
                    }
                    sawTransferEncoding = true
                }
                req.headers[key] = value
            }
        }
        if sawTransferEncoding && sawContentLength {
            return .fail(status: "400 Bad Request", message: "Transfer-Encoding and Content-Length cannot be combined")
        }
        if let te = req.headers["transfer-encoding"] {
            // A chunked body carries no Content-Length, so it used to be read
            // as zero bytes and failed further in as "messages must be an array".
            if te.lowercased().split(separator: ",").last?.trimmingCharacters(in: .whitespaces) == "chunked" {
                return .fail(
                    status: "411 Length Required",
                    message: "chunked request bodies are not supported; send Content-Length")
            }
            return .fail(status: "400 Bad Request", message: "Transfer-Encoding is not supported")
        }
        if contentLength > maxBodyBytes {
            return .fail(
                status: "413 Content Too Large",
                message: "request body is larger than \(maxBodyBytes >> 20) MiB")
        }
        return .ok(req, contentLength: contentLength)
    }

    /// The path a request routes on: no query string, and no scheme or
    /// authority from the absolute-form target proxies send. Both are legal
    /// HTTP and both used to 404.
    package static func routePath(_ raw: String) -> String {
        var p = raw
        if let q = p.firstIndex(of: "?") { p = String(p[..<q]) }
        for scheme in ["http://", "https://"] where p.lowercased().hasPrefix(scheme) {
            let afterScheme = p.index(p.startIndex, offsetBy: scheme.count)
            if let slash = p[afterScheme...].firstIndex(of: "/") {
                p = String(p[slash...])
            } else {
                p = "/"
            }
        }
        return p.count > 1 && p.hasSuffix("/") ? String(p.dropLast()) : p
    }

    /// Whether a request counts as use of the server. A status check does
    /// not: `slotstream stop` and launch read it, and a status display may
    /// poll it.
    package static func countsAsActivity(_ path: String) -> Bool {
        routePath(path) != "/slotstream/status"
    }

    /// The 503 every request but the status gets once an idle stop is decided.
    package static let stoppingMessage = "the server is stopping; start it again, or run `slotstream launch`"

    /// `POST /slotstream/clients` with `{"pid": n}`: keep the server running
    /// while that process of this user runs.
    package static func registerClient(_ json: [String: Any],
                                       activity: ServerActivity) -> (status: String, body: [String: Any]) {
        guard let pid = int(json["pid"]), pid > 0, pid <= Int(Int32.max) else {
            return ("400 Bad Request", ["error": "pid must be a positive process id"])
        }
        guard activity.register(pid: Int32(pid)) else {
            return ("400 Bad Request", ["error": "no running process \(pid) of this user"])
        }
        return ("200 OK", ["clients": activity.snapshot().clients])
    }

    /// `GET /slotstream/status`: what `slotstream stop` and `slotstream
    /// launch` need to find this process and see whether it is in use.
    /// `memorySource` is what sized the memory plan (`--memory-gb`, `auto`,
    /// ...) and `memoryTargetGB` its whole-process target, when it has one.
    package static func statusBody(pid: Int32, port: Int, version: String, model: String, contextWindow: Int,
                                   startedAt: Int, activity: ServerActivity.Snapshot,
                                   idleExitSeconds: Double?, memorySource: String? = nil,
                                   memoryTargetGB: Double? = nil, memoryLimitGB: Double? = nil) -> [String: Any] {
        [
            "server": "slotstream",
            "version": version,
            "pid": Int(pid),
            "port": port,
            "model": model,
            "context_window": contextWindow,
            "started_at": startedAt,
            "active_requests": activity.activeRequests,
            "clients": activity.clients,
            "idle_seconds": (activity.idleSeconds * 10).rounded() / 10,
            "idle_exit_minutes": idleExitSeconds.map { $0 / 60 } ?? NSNull(),
            "memory_source": memorySource ?? NSNull(),
            "memory_target_gb": memoryTargetGB ?? NSNull(),
            "memory_limit_gb": memoryLimitGB ?? NSNull(),
        ]
    }

    private func send(_ fd: Int32, _ data: Data) -> Bool {
        var sent = 0
        return data.withUnsafeBytes { raw -> Bool in
            while sent < data.count {
                let n = write(fd, raw.baseAddress! + sent, data.count - sent)
                if n < 0 && errno == EINTR { continue }
                if n <= 0 { return false }
                sent += n
            }
            return true
        }
    }

    /// Browser clients need CORS, but a wildcard turns any website the user
    /// visits into an unauthenticated caller of this expensive local service.
    /// Echo only loopback origins, including their arbitrary development port.
    package static func corsHeaders(origin: String?) -> String? {
        guard let origin, !origin.isEmpty else { return "" }
        guard let u = URL(string: origin), let host = u.host?.lowercased(),
            u.scheme == "http" || u.scheme == "https",
            host == "localhost" || host == "127.0.0.1" || host == "0.0.0.0" || host == "::1"
        else { return nil }
        return "Access-Control-Allow-Origin: \(origin)\r\nVary: Origin\r\n"
    }

    private func respondJSON(
        _ fd: Int32, _ obj: Any, status: String = "200 OK", cors: String = ""
    ) {
        let body = (try? JSONSerialization.data(withJSONObject: obj)) ?? Data("{}".utf8)
        var head = "HTTP/1.1 \(status)\r\nContent-Type: application/json\r\n" + cors
        head += "Content-Length: \(body.count)\r\nConnection: close\r\n\r\n"
        _ = send(fd, Data(head.utf8) + body)
    }

    private func startChunked(_ fd: Int32, contentType: String, cors: String) -> Bool {
        let head = "HTTP/1.1 200 OK\r\nContent-Type: \(contentType)\r\n" + cors
            + "Transfer-Encoding: chunked\r\nConnection: close\r\n\r\n"
        return send(fd, Data(head.utf8))
    }

    @discardableResult
    private func chunk(_ fd: Int32, _ payload: Data, writer: BoundedOutput? = nil) -> Bool {
        var d = Data(String(format: "%x\r\n", payload.count).utf8)
        d += payload
        d += Data("\r\n".utf8)
        return writer?.enqueue(d) ?? send(fd, d)
    }

    private func endChunked(_ fd: Int32, writer: BoundedOutput? = nil) {
        let end = Data("0\r\n\r\n".utf8)
        if let writer { writer.enqueue(end) } else { _ = send(fd, end) }
    }

    /// A nonblocking peek distinguishes an idle connected peer (EAGAIN) from
    /// EOF. Generation checks it before every prefill chunk and decode token,
    /// including non-streaming requests that otherwise would not write until
    /// all work had already been done.
    private func peerAlive(_ fd: Int32) -> Bool {
        var byte: UInt8 = 0
        let n = recv(fd, &byte, 1, MSG_PEEK | MSG_DONTWAIT)
        if n == 0 { return false }
        if n > 0 { return true }
        return errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR
    }

    // MARK: routing

    package func handle(_ fd: Int32) {
        defer { close(fd) }
        let req: Request
        switch Self.readRequest(fd) {
        case .ok(let r): req = r
        case .closed: return
        case .fail(let status, let message, let target):
            // Claude Code reads the error type of a refused Messages request
            // to recover from it, so these answer in Anthropic's shape.
            if let target, Self.routePath(target).hasPrefix("/v1/messages") {
                respondJSON(fd, AnthropicDialect.errorBody(type: AnthropicDialect.errorType(httpStatus: status),
                                                           message: message), status: status)
            } else {
                respondJSON(fd, ["error": message], status: status)
            }
            return
        }
        let tracked = Self.countsAsActivity(req.path)
        if tracked, !activity.begin() {
            respondJSON(fd, ["error": Self.stoppingMessage], status: "503 Service Unavailable")
            return
        }
        defer { if tracked { activity.end() } }
        let origin = req.headers["origin"]
        guard let cors = Self.corsHeaders(origin: origin) else {
            respondJSON(
                fd, ["error": "browser origin is not allowed"],
                status: "403 Forbidden")
            return
        }
        if req.method == "OPTIONS" {  // CORS preflight
            let head = "HTTP/1.1 204 No Content\r\n" + cors
                + "Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS\r\n"
                + "Access-Control-Allow-Headers: Content-Type, Authorization\r\n"
                + "Access-Control-Allow-Private-Network: true\r\n"
                + "Access-Control-Max-Age: 86400\r\nConnection: close\r\n\r\n"
            _ = send(fd, Data(head.utf8))
            return
        }
        let path = Self.routePath(req.path)
        let inferencePaths = ["/api/chat", "/api/generate", "/v1/chat/completions", "/v1/responses",
                              "/v1/messages", "/v3/ai/language-model", "/v1/ai/language-model"]
        let control: RequestController?
        if req.method == "POST", inferencePaths.contains(path) {
            let dialect = path == "/v1/chat/completions" || path == "/v1/responses" ? "openai"
                : path == "/v1/messages" ? "anthropic"
                : path.hasSuffix("/language-model") ? "gateway" : "ollama"
            do {
                let accepted = try engine.beginRequest(connected: { self.peerAlive(fd) })
                // Upload is complete. Parsing, validation, templating and
                // queueing now share this one clock and allocation guard.
                try accepted.checkInputBytes(req.body.count)
                control = accepted
            } catch { requestRefusal(fd, error, dialect: dialect, cors: cors); return }
        } else { control = nil }
        let parsed = (try? JSONSerialization.jsonObject(with: req.body)) as? [String: Any]
        if req.method == "POST", !req.body.isEmpty, parsed == nil {
            let anthropic = path == "/v1/messages" || path == "/v1/messages/count_tokens"
            let body: [String: Any] = anthropic
                ? AnthropicDialect.errorBody(type: "invalid_request_error", message: "invalid JSON body")
                : ["error": "invalid JSON body"]
            respondJSON(fd, body, status: "400 Bad Request", cors: cors)
            return
        }
        let json = parsed ?? [:]
        if let control {
            let requestID = UUID().uuidString.prefix(8)
            onDiagnostic?("request \(requestID) \(path): accepted")
            let heartbeat = DispatchSource.makeTimerSource(queue: DispatchQueue(label: "slotstream.request-progress"))
            heartbeat.schedule(deadline: .now() + 15, repeating: 15)
            heartbeat.setEventHandler { [weak self] in
                self?.onDiagnostic?(String(format: "request %@ %@: %.0f s elapsed, %@", String(requestID), path,
                    control.elapsedSeconds, control.phase))
            }
            heartbeat.resume()
            defer {
                heartbeat.cancel()
                onDiagnostic?(String(format: "request %@ %@: ended after %.1f s%@", String(requestID), path,
                    control.elapsedSeconds, control.failure.map { ", " + $0.code.rawValue } ?? ""))
            }
            switch path {
            case "/api/chat": apiChat(fd, json, cors: cors, control: control)
            case "/api/generate": apiGenerate(fd, json, cors: cors, control: control)
            case "/v1/chat/completions": v1Chat(fd, json, cors: cors, control: control)
            case "/v1/responses": v1Responses(fd, json, cors: cors, control: control)
            case "/v1/messages": v1Messages(fd, json, cors: cors, control: control)
            default: gatewayChat(fd, json, headers: req.headers, cors: cors, control: control)
            }
            return
        }
        switch (req.method, path) {
        case ("GET", "/api/version"):
            respondJSON(fd, ["version": SlotstreamBuild.version], cors: cors)
        case ("GET", "/api/tags"), ("GET", "/api/tags/"):
            respondJSON(fd, ["models": [modelCard()]], cors: cors)
        case ("GET", "/api/ps"):
            respondJSON(fd, ["models": [modelCard(loaded: true)]], cors: cors)
        case ("POST", "/api/show"):
            // The Ollama CLI's ShowRequest serializes every field, so a plain
            // `ollama run` opens with empty name/system/template/options.
            // Accept the deprecated `name` alias and empty overrides; a
            // non-empty override asks for modelfile semantics this server
            // does not have and stays a 400 (showOverrideError).
            var show = json
            // `ollama run` puts the name in `model` and sends an empty `name`;
            // `ollama show` does the exact reverse, so an empty `model` has to
            // fall back to the alias too, not merely a missing one.
            let modelBlank = show["model"] == nil || show["model"] is NSNull
                || (show["model"] as? String)?.isEmpty == true
            if modelBlank, let alias = show["name"] as? String, !alias.isEmpty {
                show["model"] = alias
            }
            if let e = modelError(show) {
                respondJSON(fd, ["error": e], status: "404 Not Found", cors: cors)
                return
            }
            if let e = Self.unsupportedKey(
                show, allowed: ["model", "name", "verbose", "system", "template", "options"])
            {
                respondJSON(fd, ["error": e], status: "400 Bad Request", cors: cors)
                return
            }
            if let e = Self.showOverrideError(show) {
                respondJSON(fd, ["error": e], status: "400 Bad Request", cors: cors)
                return
            }
            if show["verbose"] != nil, Self.bool(show["verbose"]) == nil {
                respondJSON(
                    fd, ["error": "verbose must be true or false"],
                    status: "400 Bad Request", cors: cors)
                return
            }
            respondJSON(
                fd,
                [
                    "modelfile": "# slotstream: SSD-streamed qwen4_exp",
                    "parameters": "num_ctx \(engine.maxContextTokens)",
                    "capabilities": ["completion"]
                        + (engine.visionAllowed && engine.visionAvailable ? ["vision"] : []),
                    "template": "{{ .Prompt }}",
                    "details": modelDetails(live: true),
                    "context_policy": engine.contextPolicyJSON,
                    "model_info": [
                        "general.architecture": "qwen4_exp",
                        "general.parameter_count": 176_000_000_000,
                        "qwen4_exp.context_length": engine.maxContextTokens,
                    ],
                ], cors: cors)
        case ("GET", "/coding-agent/v1/models"):
            var catalog = GatewayDialect.catalog(modelID: gatewayModelID, contextCap: engine.maxContextTokens,
                vision: engine.visionAllowed && engine.visionAvailable)
            catalog["context_policy"] = engine.contextPolicyJSON
            respondJSON(fd, catalog, cors: cors)
        case ("GET", "/coding-agent/v1/credits"):
            // fx shows a balance for the gateway provider. A local model has no
            // billing; zero is the honest answer and keeps `fx credits` working.
            respondJSON(fd, ["balance": "0", "total_used": "0"], cors: cors)
        case ("GET", _) where path.hasPrefix("/v1/responses/"),
             ("DELETE", _) where path.hasPrefix("/v1/responses/"):
            // The API can retrieve, cancel and delete a stored response; this
            // server stores none, so there is nothing at any id.
            respondJSON(
                fd, ["error": ["message": "this server stores no responses; there is nothing at \(path)",
                               "type": "invalid_request_error", "code": "stored_state_unsupported"]],
                status: "404 Not Found", cors: cors)
        case ("GET", "/v1/models"):
            respondJSON(
                fd,
                [
                    "object": "list",
                    "data": [[
                        "id": engine.modelName, "object": "model",
                        "created": startedAt, "owned_by": "slotstream",
                        "context_length": engine.maxContextTokens,
                        "context_window": engine.maxContextTokens,
                        "context_policy": engine.contextPolicyJSON,
                        "max_output_tokens": GatewayDialect.outputBudget(contextCap: engine.maxContextTokens),
                    ]],
                ], cors: cors)
        case ("POST", "/v1/messages/count_tokens"):
            v1CountTokens(fd, json, cors: cors)
        case ("GET", "/slotstream/status"):
            let now = activity.snapshot(), plan = engine.currentPlan
            respondJSON(fd, Self.statusBody(
                pid: getpid(), port: Int(port), version: SlotstreamBuild.version, model: engine.modelName,
                contextWindow: engine.maxContextTokens, startedAt: startedAt, activity: now,
                idleExitSeconds: idleExit?.seconds, memorySource: plan?.source.rawValue,
                memoryTargetGB: plan?.targetGB, memoryLimitGB: plan?.memoryLimitGB), cors: cors)
        case ("POST", "/slotstream/clients"):
            let answer = Self.registerClient(json, activity: activity)
            respondJSON(fd, answer.body, status: answer.status, cors: cors)
        case ("POST", "/api/embed"), ("POST", "/api/embeddings"):
            respondJSON(
                fd, ["error": "model does not support embeddings"],
                status: "400 Bad Request", cors: cors)
        case ("POST", "/api/pull"), ("POST", "/api/create"):
            respondJSON(
                fd, ["error": "use `slotstream pull` on the host"],
                status: "501 Not Implemented", cors: cors)
        case ("HEAD", _):
            // A HEAD response carries headers only; sending a body is a
            // protocol error. It still has to answer for the resource asked
            // for — a blanket 200 told every client that every path existed.
            let known: Set<String> = [
                "/", "/api/version", "/api/tags", "/api/ps", "/v1/models",
                "/coding-agent/v1/models", "/coding-agent/v1/credits", "/slotstream/status",
            ]
            let status = known.contains(path) ? "200 OK" : "404 Not Found"
            let head = "HTTP/1.1 \(status)\r\nContent-Type: application/json\r\n" + cors
                + "Content-Length: 0\r\nConnection: close\r\n\r\n"
            _ = send(fd, Data(head.utf8))
        case ("GET", "/"):
            respondJSON(fd, ["status": "ok", "engine": "slotstream"], cors: cors)
        default:
            respondJSON(
                fd, ["error": "not found: \(req.method) \(req.path)"],
                status: "404 Not Found", cors: cors)
        }
    }

    /// `live: false` for /api/tags and /api/ps, which are *listings* — a
    /// client may cache or diff them, so per-request counters do not belong
    /// there. /api/show is the endpoint that reports runtime state.
    private func modelDetails(live: Bool = false) -> [String: Any] {
        let pool = engine.poolSnapshot()
        var d: [String: Any] = [
            "format": "safetensors", "family": "qwen4_exp",
            "parameter_size": "176B-A6B", "quantization_level": engine.modelQuantization,
            "expert_cache_per_layer": Int(pool.slotsPerLayer.rounded()),
            "experts_per_layer": engine.model.cfg.numExperts,
        ]
        if let plan = engine.currentPlan { d["memory_plan"] = plan.json() }
        if live { d["prefix_cache"] = engine.prefixCache.json() }
        return d
    }

    private func modelCard(loaded: Bool = false) -> [String: Any] {
        var c: [String: Any] = [
            "name": engine.modelName, "model": engine.modelName,
            "modified_at": iso(Date()), "size": weightsBytes,
            "digest": engine.modelDigest,
            "details": modelDetails(),
        ]
        if loaded {
            // Ollama reads these as "what this model costs right now" and
            // renders (size - size_vram) as a CPU share. Reporting 104 GB of
            // weights against a small pool made `ollama ps` claim ~98% CPU for
            // a model that runs on the GPU; resident memory is the honest
            // answer for a runtime that streams the rest from disk.
            let resident = Int(ProcessMemory.residentBytes())
            c["size"] = resident
            c["size_vram"] = resident
            c["expires_at"] = iso(Date().addingTimeInterval(3600))
        }
        return c
    }

    private func iso(_ d: Date) -> String {
        ISO8601DateFormatter().string(from: d)
    }

    // MARK: params

    /// OpenAI clients may send `content` as a string or as an array of typed
    /// parts. Taking `as? String` alone silently drops the whole message, so
    /// the text parts are joined here instead.
    static func contentText(_ v: Any?) -> String {
        if let s = v as? String { return s }
        if let parts = v as? [[String: Any]] {
            return parts.compactMap { part -> String? in
                if let t = part["text"] as? String { return t }
                return nil
            }.joined()
        }
        return ""
    }

    private static func messages(_ json: [String: Any]) -> [ChatMessage] {
        (json["messages"] as? [[String: Any]] ?? []).map {
            ChatMessage(role: $0["role"] as? String ?? "user", content: contentText($0["content"]))
        }
    }

    /// Messages reshaped for the Jinja template with vision content intact.
    /// OpenAI clients send content as an array of typed parts (text plus
    /// image_url); the tokenizer's render_content turns each image part into
    /// <|vision_start|><|image_pad|><|vision_end|>, so the array must reach it
    /// verbatim. Text-only part arrays are flattened back to a string, keeping
    /// the two paths behavior-identical. Ollama clients send base64 in the
    /// `images` field; it is synthesized into image_url parts here.
    public static func templateMessages(_ json: [String: Any]) -> [[String: Any]] {
        guard let raw = json["messages"] as? [[String: Any]] else { return [] }
        return raw.map { m in
            var out: [String: Any] = [:]
            out["role"] = m["role"] as? String ?? "user"
            if let c = m["content"] {
                if c is NSNull { out["content"] = "" }
                else if let s = c as? String { out["content"] = s }
                else if let parts = c as? [[String: Any]] {
                    let hasImage = parts.contains {
                        $0["image_url"] != nil || $0["image"] != nil
                            || ($0["type"] as? String) == "image_url"
                            || ($0["type"] as? String) == "image"
                    }
                    out["content"] = hasImage ? parts : contentText(parts as Any?)
                } else { out["content"] = "" }
            } else { out["content"] = "" }
            // Ollama's `images` array is per message and carries no order
            // relative to the text, so it is rendered the way Qwen's template
            // reads best and the way the typed path (`ChatMessage.images`)
            // does: pictures first, then the words about them. The bytes are
            // passed through exactly as they arrived — wrapping them in a
            // `data:image/jpeg` URL, as this once did, asserts a content type
            // nothing checked, and the decoder reads the real one from the
            // bytes anyway.
            if let images = m["images"] as? [String], !images.isEmpty {
                var parts: [[String: Any]] = images.map {
                    ["type": "image_url", "image_url": ["url": $0]]
                }
                if let s = out["content"] as? String, !s.isEmpty {
                    parts.append(["type": "text", "text": s])
                } else if let arr = out["content"] as? [[String: Any]] {
                    parts.append(contentsOf: arr)
                }
                out["content"] = parts
            }
            return out
        }
    }

    /// JSON numbers arrive as NSNumber; accept ints where a float is expected.
    private static func num(_ v: Any?) -> Double? {
        guard let n = v as? NSNumber,
            CFGetTypeID(n) != CFBooleanGetTypeID()
        else { return nil }
        let d = n.doubleValue
        // Every current numeric API field is ultimately stored as Float.
        // Accepting 1e300 only to turn it into infinity made a syntactically
        // valid request silently select a different sampler mode.
        guard d.isFinite, Float(d).isFinite else { return nil }
        return d
    }

    /// Swift's NSNumber bridge reports JSON `1` as `is Bool`, and JSON `true`
    /// as `as? Int == 1`. CoreFoundation's type id is the only reliable way to
    /// keep JSON booleans, integers, and ordinary numbers distinct here.
    private static func int(_ v: Any?) -> Int? {
        guard let n = v as? NSNumber,
            CFGetTypeID(n) != CFBooleanGetTypeID()
        else { return nil }
        return v as? Int
    }

    private static func bool(_ v: Any?) -> Bool? {
        guard let n = v as? NSNumber,
            CFGetTypeID(n) == CFBooleanGetTypeID()
        else { return nil }
        return n.boolValue
    }

    private static func stopList(_ v: Any?) -> [String]? {
        if let a = v as? [String] { return a.filter { !$0.isEmpty } }
        if let s = v as? String, !s.isEmpty { return [s] }
        return nil
    }

    private func modelError(_ json: [String: Any]) -> String? {
        guard let raw = json["model"] else { return nil }
        guard let requested = raw as? String else { return "model must be text" }
        guard !requested.isEmpty else { return "model must not be empty" }
        // Untagged and latest aliases name the active artifact. An explicit
        // quantization tag must never silently select a different artifact.
        return engine.acceptsModelName(requested)
            ? nil : "model '\(requested)' is not loaded; this server has only '\(engine.modelName)'"
    }

    /// JSON `null` means "not set" to every client SDK worth supporting: the
    /// OpenAI client serializes an unset `max_tokens` as null and the Ollama
    /// CLI sends a null `options`. Reading it as a present-but-wrong value
    /// turned a stock default request into a 400.
    static func withoutNulls(_ json: [String: Any]) -> [String: Any] {
        json.filter { !($0.value is NSNull) }
    }

    private static func unsupportedKey(
        _ json: [String: Any], allowed: Set<String>
    ) -> String? {
        let extras = Set(json.keys).subtracting(allowed).sorted()
        return extras.isEmpty ? nil
            : "unsupported request field(s): \(extras.joined(separator: ", "))"
    }

    private static func messageError(_ json: [String: Any]) -> String? {
        guard let raw = json["messages"] as? [[String: Any]] else {
            return "messages must be an array"
        }
        for (i, m) in raw.enumerated() {
            let extra = Set(m.keys).subtracting(["role", "content", "images", "tool_calls", "tool_call_id"])
            if !extra.isEmpty {
                return "messages[\(i)] has unsupported field(s): "
                    + extra.sorted().joined(separator: ", ")
            }
            if m["tool_calls"] != nil || m["tool_call_id"] != nil {
                return "messages[\(i)] uses tools, which this server does not support"
            }
            // Ollama's field. `[Any]` would accept `[1, 2, 3]` and then drop
            // it silently on the way to the template, answering as if no
            // picture had been sent.
            if let images = m["images"], !(images is NSNull) {
                guard let arr = images as? [Any], arr as? [String] != nil else {
                    return "messages[\(i)].images must be an array of base64 strings"
                }
            }
            guard let role = m["role"] as? String,
                ["system", "user", "assistant"].contains(role)
            else { return "messages[\(i)].role must be system, user, or assistant" }
            if let parts = m["content"] as? [[String: Any]] {
                for (j, part) in parts.enumerated() {
                    let extra = Set(part.keys).subtracting(["type", "text", "image_url", "image"])
                    if !extra.isEmpty {
                        return "messages[\(i)].content[\(j)] has unsupported field(s): "
                            + extra.sorted().joined(separator: ", ")
                    }
                    let kind = (part["type"] as? String) ?? "text"
                    if kind == "text" || kind == "input_text" {
                        if part["text"] as? String == nil {
                            return "messages[\(i)] has a text part without text"
                        }
                    } else if kind == "image_url" || kind == "image"
                        || part["image_url"] != nil || part["image"] != nil
                    {
                        // Accept both shapes OpenAI clients send —
                        // `image_url: {url: "..."}` and the bare string some
                        // SDKs still emit — and refuse anything else here,
                        // where the index is still known, rather than letting
                        // the part vanish before the template.
                        let value = part["image_url"] ?? part["image"]
                        let ok = value as? String != nil
                            || (value as? [String: Any])?["url"] as? String != nil
                        guard ok else {
                            return "messages[\(i)].content[\(j)] is an image part without a "
                                + "usable url (expected a string or {\"url\": \"data:...\"})"
                        }
                    } else {
                        return "messages[\(i)] contains unsupported content type '\(kind)'"
                    }
                }
            } else if m["content"] as? String == nil {
                return "messages[\(i)].content must be text or a content array"
            }
        }
        return nil
    }

    /// Ollama's ShowRequest carries `system`, `template`, and `options` as
    /// modelfile overrides. Empty ones are what every client sends by default
    /// and mean nothing; a non-empty one would have to be silently ignored
    /// here, so it is refused instead.
    private static func showOverrideError(_ json: [String: Any]) -> String? {
        for key in ["system", "template"] {
            guard let v = json[key], !(v is NSNull) else { continue }
            guard let s = v as? String else { return "\(key) must be text" }
            if !s.isEmpty { return "\(key) overrides are not supported on this server" }
        }
        if let v = json["options"], !(v is NSNull) {
            guard let o = v as? [String: Any] else { return "options must be an object" }
            if !o.isEmpty { return "options overrides are not supported on /api/show" }
        }
        return nil
    }

    private static func optionsError(_ json: [String: Any]) -> String? {
        // The Ollama CLI sends `"options": null` when none are set.
        guard let options = json["options"], !(options is NSNull) else { return nil }
        guard let o = options as? [String: Any] else { return "options must be an object" }
        let allowed: Set<String> = [
            "temperature", "top_p", "top_k", "min_p", "presence_penalty",
            "num_predict", "seed", "stop",
        ]
        let extras = Set(o.keys).subtracting(allowed).sorted()
        if !extras.isEmpty {
            return "unsupported options field(s): \(extras.joined(separator: ", "))"
        }
        for key in ["temperature", "top_p", "min_p", "presence_penalty"]
        where o[key] != nil && num(o[key]) == nil {
            return "options.\(key) must be a number"
        }
        for key in ["top_k", "num_predict", "seed"]
        where o[key] != nil && int(o[key]) == nil {
            return "options.\(key) must be an integer"
        }
        if let stop = o["stop"], !(stop is String) && !(stop is [String]) {
            return "options.stop must be text or an array of text"
        }
        return nil
    }

    private func ollamaValidationError(
        _ json: [String: Any], allowed: Set<String>, messages: Bool = false
    ) -> String? {
        if let e = modelError(json) { return e }
        if let e = Self.unsupportedKey(json, allowed: allowed) { return e }
        if let e = Self.optionsError(json) { return e }
        if json["think"] != nil, Self.bool(json["think"]) == nil {
            return "think must be true or false; named reasoning levels are not supported"
        }
        if json["stream"] != nil, Self.bool(json["stream"]) == nil {
            return "stream must be true or false"
        }
        return messages ? Self.messageError(json) : nil
    }

    /// Fields whose only supported value is the behaviour this server already
    /// has. A client sending the default is asking for exactly what it gets, so
    /// refusing it breaks stock SDKs for no semantic reason; any other value is
    /// a real feature and stays a 400. Nothing is silently dropped either way.
    package static func openAINoOpError(_ json: [String: Any]) -> String? {
        if json["n"] != nil, int(json["n"]) != 1 {
            return "n must be 1; this server returns a single choice"
        }
        if json["frequency_penalty"] != nil, num(json["frequency_penalty"]) != 0 {
            return "frequency_penalty is not supported (0 only); use presence_penalty"
        }
        if json["logprobs"] != nil, bool(json["logprobs"]) != false {
            return "logprobs are not supported"
        }
        if json["top_logprobs"] != nil { return "top_logprobs are not supported" }
        if let v = json["logit_bias"] {
            guard let map = v as? [String: Any], map.isEmpty else {
                return "logit_bias is not supported"
            }
        }
        if let v = json["response_format"] {
            guard let o = v as? [String: Any], (o["type"] as? String) == "text" else {
                return "response_format is not supported for constrained output; only {\"type\": \"text\"} is supported"
            }
        }
        if json["user"] != nil, json["user"] as? String == nil {
            return "user must be text"
        }
        // `store: false` is what Pi and the OpenAI SDKs send by default
        // (issue #19), so refusing it refused those clients outright. `true`
        // asks for a stored completion to fetch later, which this server
        // cannot give.
        if json["store"] != nil, let store = bool(json["store"]) {
            if store { return "store: true is not supported; this server keeps no completions" }
        } else if json["store"] != nil {
            return "store must be true or false"
        }
        if let v = json["metadata"] {
            guard let map = v as? [String: Any], map.values.allSatisfy({ $0 is String }) else {
                return "metadata must be an object of text values"
            }
        }
        for key in ["prompt_cache_key", "prompt_cache_retention", "safety_identifier", "service_tier"]
        where json[key] != nil && json[key] as? String == nil {
            return "\(key) must be text"
        }
        return nil
    }

    /// The top-level fields `/v1/chat/completions` reads; anything else is
    /// refused by name.
    package static let openAIChatFields: Set<String> = [
        "model", "messages", "stream", "temperature", "top_p", "top_k",
        "presence_penalty", "max_tokens", "max_completion_tokens", "seed",
        "stop", "stream_options", "min_p",
        // Accepted only at the value this server already implements; see
        // openAINoOpError. Stock SDKs send these on every call.
        "n", "frequency_penalty", "logprobs", "top_logprobs", "logit_bias",
        "response_format", "tools", "tool_choice", "parallel_tool_calls", "user",
        "reasoning_effort", "think", "options",
        // Accepted without effect; see openAINoOpError. Pi sends
        // `prompt_cache_retention` when told to keep its cache longer.
        "store", "metadata", "prompt_cache_key", "prompt_cache_retention", "safety_identifier", "service_tier",
    ]

    private func openAIValidationError(_ json: [String: Any]) -> String? {
        if let e = modelError(json) { return e }
        if let e = Self.unsupportedKey(json, allowed: Self.openAIChatFields) { return e }
        if let e = Self.openAINoOpError(json) { return e }
        do { _ = try OpenAIDialect.conversation(json, contextLimit: engine.maxContextTokens) }
        catch { return "\(error)" }
        for key in ["temperature", "top_p", "presence_penalty"]
        where json[key] != nil && Self.num(json[key]) == nil {
            return "\(key) must be a number"
        }
        for key in ["top_k", "max_tokens", "max_completion_tokens", "seed"]
        where json[key] != nil && Self.int(json[key]) == nil {
            return "\(key) must be an integer"
        }
        for key in ["max_tokens", "max_completion_tokens"] {
            if let value = Self.int(json[key]), value <= 0 {
                return "\(key) must be greater than zero"
            }
        }
        if let stop = json["stop"], !(stop is String) && !(stop is [String]) {
            return "stop must be text or an array of text"
        }
        if json["stream"] != nil, Self.bool(json["stream"]) == nil {
            return "stream must be true or false"
        }
        if json["stream_options"] != nil,
            json["stream_options"] as? [String: Any] == nil
        {
            return "stream_options must be an object"
        }
        if let o = json["stream_options"] as? [String: Any] {
            let extras = Set(o.keys).subtracting(["include_usage"])
            if !extras.isEmpty {
                return "unsupported stream_options field(s): \(extras.sorted().joined(separator: ", "))"
            }
            if o["include_usage"] != nil, Self.bool(o["include_usage"]) == nil {
                return "stream_options.include_usage must be true or false"
            }
        }
        return nil
    }

    private func sampleParams(_ json: [String: Any]) -> SampleParams {
        let thinking = Self.bool(json["think"]) ?? false
        var p: SampleParams = thinking ? .thinking : .instruct
        if let o = json["options"] as? [String: Any] {
            if let v = Self.num(o["temperature"]) { p.temperature = Float(v) }
            if let v = Self.num(o["top_p"]) { p.topP = Float(v) }
            if let v = Self.int(o["top_k"]) { p.topK = v }
            if let v = Self.num(o["min_p"]) { p.minP = Float(v) }
            if let v = Self.num(o["presence_penalty"]) { p.presencePenalty = Float(v) }
            if let v = Self.int(o["num_predict"]) { p.maxTokens = v }
            // Ollama uses -1 for "random seed"; UInt64(-1) would trap.
            if let v = Self.int(o["seed"]) { p.seed = v < 0 ? nil : UInt64(v) }
            if let s = Self.stopList(o["stop"]) { p.stop = s }
        }
        // No seed means a different reply every time, which is what the API
        // documents and what clients expect. The sampler's own default is a
        // fixed constant, so without this an unseeded request replayed the
        // same text after every restart.
        if p.seed == nil { p.seed = Self.randomSeed() }
        return p.sanitized()
    }

    /// A fresh seed for a request that did not name one.
    static func randomSeed() -> UInt64 { UInt64.random(in: 1 ... UInt64.max) }

    // MARK: /api/chat

    package static func ollamaToolError(_ json: [String: Any]) -> String? {
        let messages = json["messages"] as? [[String: Any]] ?? []
        if json["tools"] != nil || messages.contains(where: {
            $0["role"] as? String == "tool" || $0["tool_calls"] != nil || $0["tool_call_id"] != nil
        }) {
            return "tool calling is supported at /v1/chat/completions in OpenAI format; /api/chat does not implement Ollama tools"
        }
        return nil
    }

    private func apiChat(_ fd: Int32, _ rawJSON: [String: Any], cors: String, control: RequestController) {
        let json = Self.withoutNulls(rawJSON)
        if let error = Self.ollamaToolError(json) {
            respondJSON(fd, ["error": error], status: "400 Bad Request", cors: cors)
            return
        }
        if let e = ollamaValidationError(
            json, allowed: ["model", "messages", "stream", "think", "options", "keep_alive"],
            messages: true)
        {
            respondJSON(fd, ["error": e], status: "400 Bad Request", cors: cors)
            return
        }
        let msgs = Self.messages(json)
        let stream = Self.bool(json["stream"]) ?? true
        let thinking = Self.bool(json["think"]) ?? false
        let params = sampleParams(json)
        // Ollama's documented "load" request (see apiGenerate): no messages
        // means load the model and return. Acknowledged without touching the
        // engine.
        guard !msgs.isEmpty else {
            respondJSON(
                fd,
                [
                    "model": engine.modelName, "created_at": iso(Date()),
                    "message": ["role": "assistant", "content": ""],
                    "done": true, "done_reason": "load",
                ], cors: cors)
            return
        }
        // Vision content (image_url parts, or Ollama's `images` field) must
        // reach the Jinja template as structured parts, so render via
        // templateMessages + encodeWithVision; text-only requests take the
        // same path and come back with a nil vision embed.
        let templateMsgs = Self.templateMessages(json)
        let ids: [Int]
        let vision: VisionPrompt?
        do {
            (ids, vision) = try engine.encodeWithVision(
                messages: templateMsgs, tools: nil, thinking: thinking, request: control)
        } catch {
            requestRefusal(fd, error, dialect: "ollama", cors: cors)
            return
        }
        if let e = engine.contextError(promptTokens: ids.count) {
            requestRefusal(fd, RequestFailure(.contextLengthExceeded, e), dialect: "ollama", cors: cors)
            return
        }
        let t0 = RuntimeClock.now()
        var headersStarted = false
        // With think on, the model reasons first and closes with `</think>`.
        // Ollama carries that in message.thinking; leaving it in the answer
        // handed clients the reasoning and a stray closing tag.
        let splitter = thinking ? ThinkSplitter() : nil
        let output = makeOutput(fd, streaming: stream)
        defer { finishOutput(output) }
        @discardableResult func writeChunk(_ data: Data) -> Bool { self.chunk(fd, data, writer: output) }
        func endOutput() { self.endChunked(fd, writer: output) }
        var alive = true
        let callback: ((Int, String) -> Bool)? = stream ? { _, delta in
            if output?.alive == false { alive = false }
            guard alive, !delta.isEmpty else { return alive }
            var message: [String: Any] = ["role": "assistant"]
            if let sp = splitter {
                let (think, content) = sp.push(delta)
                if think.isEmpty, content.isEmpty { return alive }
                if !think.isEmpty { message["thinking"] = think }
                message["content"] = content
            } else {
                message["content"] = delta
            }
            let obj: [String: Any] = [
                "model": self.engine.modelName, "created_at": self.iso(Date()),
                "message": message, "done": false,
            ]
            alive = writeChunk((try! JSONSerialization.data(withJSONObject: obj)) + Data("\n".utf8))
            return alive
        } : nil
        let (text, benchmarkOutputIds, stats) = engine.generate(
            promptIds: ids, params: params, vision: vision,
            shouldContinue: { alive && (output?.alive ?? true) && self.peerAlive(fd) }, onToken: callback, request: control, onAdmitted: {
                guard stream else { return true }
                headersStarted = self.startChunked(fd, contentType: "application/x-ndjson", cors: cors)
                return headersStarted
            })
        if let error = stats.runtimeError {
            let failure: [String: Any] = ["error": error, "code": stats.requestFailure?.code.rawValue ?? "inference_error"]
            if headersStarted {
                if alive { writeChunk((try! JSONSerialization.data(withJSONObject: failure)) + Data("\n".utf8)) }
                endOutput()
            } else if alive { requestRefusal(fd, stats.requestFailure ?? RequestFailure(.inferenceError, error), dialect: "ollama", cors: cors) }
            return
        }
        var finalMessage: [String: Any] = ["role": "assistant"]
        if let sp = splitter {
            let (think, content) = stream ? sp.flush() : ThinkSplitter.split(text)
            if !think.isEmpty { finalMessage["thinking"] = think }
            finalMessage["content"] = content
        } else {
            finalMessage["content"] = stream ? "" : text
        }
        var final: [String: Any] = [
            "model": engine.modelName, "created_at": iso(Date()),
            "message": finalMessage,
            "done": true, "done_reason": stats.finishReason,
            "total_duration": Int(RuntimeClock.seconds(since: t0) * 1e9),
            "prompt_eval_count": stats.promptTokens,
            "prompt_eval_duration": Int(stats.prefillSeconds * 1e9),
            "eval_count": stats.decodeTokens,
            "eval_duration": Int(stats.decodeSeconds * 1e9),
        ]
        if Self.benchmarkDetailsEnabled {
            var details = benchmarkMetadata(stats, prompt: ids, output: benchmarkOutputIds)
            if let output {
                details["output_before_completion_frame"] = try! JSONSerialization.jsonObject(with: JSONEncoder().encode(output.snapshot))
            }
            final["slotstream_benchmark"] = details
        }
        if stream, alive {
            writeChunk((try! JSONSerialization.data(withJSONObject: final)) + Data("\n".utf8))
            endOutput()
        } else {
            if alive { respondJSON(fd, final, cors: cors) }
        }
    }

    // MARK: /api/generate

    private func apiGenerate(_ fd: Int32, _ rawJSON: [String: Any], cors: String, control: RequestController) {
        let json = Self.withoutNulls(rawJSON)
        if let e = ollamaValidationError(
            json,
            allowed: [
                "model", "prompt", "system", "raw", "stream", "think", "options", "keep_alive",
                "suffix", "template", "images",
            ])
        {
            respondJSON(fd, ["error": e], status: "400 Bad Request", cors: cors)
            return
        }
        // The Ollama CLI's one-shot `ollama run model "prompt"` uses this
        // endpoint and serializes empty suffix/template. A non-empty suffix
        // asks for fill-in-the-middle and a non-empty template for a modelfile
        // override; neither exists here, so those stay a 400.
        for key in ["suffix", "template"] {
            guard let v = json[key], !(v is NSNull) else { continue }
            guard let s = v as? String else {
                respondJSON(fd, ["error": "\(key) must be text"], status: "400 Bad Request", cors: cors)
                return
            }
            if !s.isEmpty {
                let why = key == "suffix"
                    ? "fill-in-the-middle (suffix) is not supported"
                    : "template overrides are not supported on this server"
                respondJSON(fd, ["error": why], status: "400 Bad Request", cors: cors)
                return
            }
        }
        if json["prompt"] != nil, json["prompt"] as? String == nil {
            respondJSON(
                fd, ["error": "prompt must be text"],
                status: "400 Bad Request", cors: cors)
            return
        }
        if json["system"] != nil, json["system"] as? String == nil {
            respondJSON(
                fd, ["error": "system must be text"],
                status: "400 Bad Request", cors: cors)
            return
        }
        if json["raw"] != nil, Self.bool(json["raw"]) == nil {
            respondJSON(
                fd, ["error": "raw must be true or false"],
                status: "400 Bad Request", cors: cors)
            return
        }
        // Ollama carries pictures on /api/generate in the same base64 array
        // /api/chat uses.
        var images: [String] = []
        if let v = json["images"], !(v is NSNull) {
            guard let arr = v as? [Any] else {
                respondJSON(
                    fd, ["error": "images must be an array of base64 strings"],
                    status: "400 Bad Request", cors: cors)
                return
            }
            guard let strs = arr as? [String] else {
                respondJSON(
                    fd, ["error": "images must be an array of base64 strings"],
                    status: "400 Bad Request", cors: cors)
                return
            }
            images = strs
        }
        let prompt = json["prompt"] as? String ?? ""
        let raw = Self.bool(json["raw"]) ?? false
        let stream = Self.bool(json["stream"]) ?? true
        let thinking = Self.bool(json["think"]) ?? false
        // Ollama's documented "load" request: an empty prompt asks the server
        // to load the model and return at once, and the CLI sends one when an
        // interactive session opens. The model is always loaded here, so this
        // is an acknowledgment; nothing reaches the engine (an empty prompt
        // would leave the first logits uninitialized).
        guard !prompt.isEmpty else {
            respondJSON(
                fd,
                [
                    "model": engine.modelName, "created_at": iso(Date()),
                    "response": "", "done": true, "done_reason": "load",
                ], cors: cors)
            return
        }
        // `raw` sends the prompt to the tokenizer untouched, so there is no
        // chat template to render a placeholder into and nowhere for the
        // tower's rows to go.
        if raw, !images.isEmpty {
            respondJSON(
                fd, ["error": "raw generation cannot carry images; remove raw or images"],
                status: "400 Bad Request", cors: cors)
            return
        }
        if raw, thinking || json["system"] != nil {
            respondJSON(
                fd, ["error": "raw generation cannot apply system or think; remove raw or those fields"],
                status: "400 Bad Request", cors: cors)
            return
        }
        let params = sampleParams(json)
        let ids: [Int]
        var vision: VisionPrompt?
        if raw {
            do { try control.checkInputBytes(prompt.utf8.count) }
            catch { requestRefusal(fd, error, dialect: "ollama", cors: cors); return }
            ids = engine.tokenizer.encode(text: prompt)
        } else {
            var messages: [[String: Any]] = []
            if let system = json["system"] as? String, !system.isEmpty {
                messages.append(["role": "system", "content": system])
            }
            var user: [String: Any] = ["role": "user", "content": prompt]
            if !images.isEmpty { user["images"] = images }
            messages.append(user)
            do {
                (ids, vision) = try engine.encodeWithVision(
                    messages: Self.templateMessages(["messages": messages]), tools: nil,
                    thinking: thinking, request: control)
            } catch {
                requestRefusal(fd, error, dialect: "ollama", cors: cors)
                return
            }
        }
        // An empty prompt would leave the first logits uninitialized and make
        // the sampler invent a token out of nothing.
        guard !ids.isEmpty else {
            respondJSON(
                fd, ["error": "prompt must not be empty"],
                status: "400 Bad Request", cors: cors)
            return
        }
        if let e = engine.contextError(promptTokens: ids.count) {
            requestRefusal(fd, RequestFailure(.contextLengthExceeded, e), dialect: "ollama", cors: cors)
            return
        }
        let t0 = RuntimeClock.now()
        var headersStarted = false
        let splitter = thinking ? ThinkSplitter() : nil
        let output = makeOutput(fd, streaming: stream)
        defer { finishOutput(output) }
        @discardableResult func writeChunk(_ data: Data) -> Bool { self.chunk(fd, data, writer: output) }
        func endOutput() { self.endChunked(fd, writer: output) }
        var alive = true
        let callback: ((Int, String) -> Bool)? = stream ? { _, delta in
            if output?.alive == false { alive = false }
            guard alive, !delta.isEmpty else { return alive }
            var obj: [String: Any] = [
                "model": self.engine.modelName, "created_at": self.iso(Date()),
                "done": false,
            ]
            if let sp = splitter {
                let (think, content) = sp.push(delta)
                if think.isEmpty, content.isEmpty { return alive }
                if !think.isEmpty { obj["thinking"] = think }
                obj["response"] = content
            } else {
                obj["response"] = delta
            }
            alive = writeChunk((try! JSONSerialization.data(withJSONObject: obj)) + Data("\n".utf8))
            return alive
        } : nil
        let (text, benchmarkOutputIds, stats) = engine.generate(
            promptIds: ids, params: params, vision: vision,
            shouldContinue: { alive && (output?.alive ?? true) && self.peerAlive(fd) }, onToken: callback, request: control, onAdmitted: {
                guard stream else { return true }
                headersStarted = self.startChunked(fd, contentType: "application/x-ndjson", cors: cors)
                return headersStarted
            })
        if let error = stats.runtimeError {
            let failure: [String: Any] = ["error": error, "code": stats.requestFailure?.code.rawValue ?? "inference_error"]
            if headersStarted {
                if alive { writeChunk((try! JSONSerialization.data(withJSONObject: failure)) + Data("\n".utf8)) }
                endOutput()
            } else if alive { requestRefusal(fd, stats.requestFailure ?? RequestFailure(.inferenceError, error), dialect: "ollama", cors: cors) }
            return
        }
        var finalResponse = stream ? "" : text
        var finalThinking = ""
        if let sp = splitter {
            let (think, content) = stream ? sp.flush() : ThinkSplitter.split(text)
            finalThinking = think
            finalResponse = content
        }
        var final: [String: Any] = [
            "model": engine.modelName, "created_at": iso(Date()),
            "response": finalResponse, "done": true, "done_reason": stats.finishReason,
            "total_duration": Int(RuntimeClock.seconds(since: t0) * 1e9),
            "prompt_eval_count": stats.promptTokens,
            "prompt_eval_duration": Int(stats.prefillSeconds * 1e9),
            "eval_count": stats.decodeTokens,
            "eval_duration": Int(stats.decodeSeconds * 1e9),
        ]
        if Self.benchmarkDetailsEnabled {
            var details = benchmarkMetadata(stats, prompt: ids, output: benchmarkOutputIds)
            if let output {
                details["output_before_completion_frame"] = try! JSONSerialization.jsonObject(with: JSONEncoder().encode(output.snapshot))
            }
            final["slotstream_benchmark"] = details
        }
        if !finalThinking.isEmpty { final["thinking"] = finalThinking }
        if stream, alive {
            writeChunk((try! JSONSerialization.data(withJSONObject: final)) + Data("\n".utf8))
            endOutput()
        } else {
            if alive { respondJSON(fd, final, cors: cors) }
        }
    }

    // MARK: /v3/ai/language-model (Vercel AI Gateway protocol 0.0.1, spec v4)

    /// The model id echoed back to fx. Any `ai-language-model-id` is accepted
    /// and resolves to the one served model, so fx's three fixed helper ids
    /// (reviewer, compactor, vision fallback) work without configuration.
    var gatewayModelID: String { "slotstream/" + engine.modelName }

    private func gatewayChat(
        _ fd: Int32, _ rawJSON: [String: Any], headers: [String: String], cors: String, control: RequestController
    ) {
        func fail(_ f: GatewayDialect.Failure) {
            respondJSON(fd, f.body, status: "400 Bad Request", cors: cors)
        }
        if let e = GatewayDialect.validateHeaders(headers) { return fail(e) }
        let json = Self.withoutNulls(rawJSON)
        let request: GatewayDialect.Request
        switch GatewayDialect.parse(json, modelID: gatewayModelID) {
        case .success(let r): request = r
        case .failure(let e): return fail(e)
        }

        // toolChoice `none` renders no <tools> block; the history still
        // renders, so a compaction call over a tool conversation still reads.
        var messages = request.messages
        let renderTools = request.toolChoice == .disabled ? [] : request.tools
        if case .tool(let name) = request.toolChoice {
            messages = Self.instructing(messages, "You must call the \(name) tool now.")
        } else if request.toolChoice == .required {
            messages = Self.instructing(messages, "You must call one of the available tools now.")
        }

        let ids: [Int]
        var vision: VisionPrompt?
        do {
            // The splice substitutes ids this server generated for assistant
            // turns it can prove it produced, which needs a cached prefix; the
            // prefix cache deliberately never offers a vision entry for that
            // (its placeholder ids carry no pixels). So a conversation with a
            // picture renders in full and reuses state the ordinary way, in
            // `PrefixCache.take`, where the image digests are checked.
            if messages.contains(where: { !$0.images.isEmpty }) {
                (ids, vision) = try engine.encodeChatWithVision(
                    messages, tools: renderTools, thinking: request.reasoning.thinking,
                    effort: request.reasoning.effort, request: control)
            } else {
                try control.checkInputBytes(ContextInputMemory.bytes(messages: messages, tools: renderTools))
                ids = try engine.encodeChatSpliced(
                    messages, tools: renderTools, thinking: request.reasoning.thinking,
                    effort: request.reasoning.effort, request: control)
            }
        } catch let failure as RequestFailure {
            requestRefusal(fd, failure, dialect: "gateway", cors: cors); return
        } catch let e as SlotstreamError {
            return fail(GatewayDialect.Failure("invalid_image", "\(e)"))
        } catch {
            return fail(GatewayDialect.Failure("template_error", "\(error)"))
        }
        guard !ids.isEmpty else {
            return fail(GatewayDialect.Failure("empty_prompt", "prompt must not be empty"))
        }
        if let e = engine.contextError(promptTokens: ids.count) {
            return fail(GatewayDialect.Failure("context_length_exceeded", e))
        }

        // Sampling. fx sends no limit on the agent step, so the default must be
        // the catalogue's advertised budget bounded by the room left in the
        // context — never the 512-token Ollama default, which truncates every
        // real edit.
        var params = SampleParams.agent
        if !renderTools.isEmpty { control.sharedPrefixRetention = .conversation }
        let room = max(1, engine.maxContextTokens - ids.count)
        params.maxTokens = min(
            request.maxOutputTokens ?? GatewayDialect.outputBudget(
                contextCap: engine.maxContextTokens), room)
        if let v = request.temperature { params.temperature = v }
        if let v = request.topP { params.topP = v }
        if let v = request.topK { params.topK = v }
        if let v = request.presencePenalty { params.presencePenalty = v }
        if let v = request.seed { params.seed = UInt64(bitPattern: Int64(v)) }
        params.stop = request.stopSequences
        if request.seed == nil { params.seed = UInt64.random(in: 0...UInt64.max) }

        // The head goes out before generation begins. fx allows 30 s for the
        // head and no time at all for the stream, and a cold 6k-token prefill
        // is minutes; every failure that can be detected has been by now.
        var headersStarted = false
        let output = makeOutput(fd)
        defer { finishOutput(output) }
        @discardableResult func writeChunk(_ data: Data) -> Bool { self.chunk(fd, data, writer: output) }
        func endOutput() { self.endChunked(fd, writer: output) }
        var alive = true
        func emit(_ text: String) {
            guard alive else { return }
            alive = writeChunk(Data(text.utf8))
        }


        let thinkSplitter = request.reasoning.thinking ? ThinkSplitter() : nil
        let toolSplitter = ToolCallSplitter(tools: renderTools.map { $0.schema })
        let gatewayOutput = GatewayOutput(tools: renderTools, choice: request.toolChoice)
        var reasoningOpen = false
        var reasoningTokens = 0
        var lastKeepalive = RuntimeClock.now()
        var produced = false

        func flushEvents(_ events: [ToolStreamEvent]) {
            for part in gatewayOutput.consume(events) { emit(GatewayDialect.frame(part)) }
        }

        let callback: (Int, String) -> Bool = { _, delta in
            if output?.alive == false { alive = false }
            guard alive, gatewayOutput.error == nil, !delta.isEmpty else {
                return alive && gatewayOutput.error == nil
            }
            produced = true
            var body = delta
            if let ts = thinkSplitter {
                let (think, content) = ts.push(delta)
                if !think.isEmpty {
                    reasoningTokens += 1
                    if !reasoningOpen {
                        emit(GatewayDialect.frame(["type": "reasoning-start", "id": "r0"]))
                        reasoningOpen = true
                    }
                    emit(
                        GatewayDialect.frame([
                            "type": "reasoning-delta", "id": "r0", "delta": think,
                        ]))
                }
                if reasoningOpen, !content.isEmpty {
                    emit(GatewayDialect.frame(["type": "reasoning-end", "id": "r0"]))
                    reasoningOpen = false
                }
                body = content
            }
            if !body.isEmpty {
                flushEvents(gatewayOutput.acceptsToolCalls ? toolSplitter.push(body) : [.text(body)])
            }
            return alive && gatewayOutput.error == nil
        }

        let (_, _, stats) = engine.generate(
            promptIds: ids, params: params, vision: vision,
            shouldContinue: {
                guard gatewayOutput.error == nil else { return false }
                // The one hook that runs during prefill. A multi-minute cold
                // prompt would otherwise send no bytes at all and trip this
                // server's own 120 s send timeout; fx skips comment lines by
                // design, so the keepalive costs the client nothing.
                if headersStarted, !produced, RuntimeClock.seconds(since: lastKeepalive) >= 10 {
                    lastKeepalive = RuntimeClock.now()
                    alive = writeChunk(Data(GatewayDialect.keepalive.utf8))
                }
                return alive && (output?.alive ?? true) && self.peerAlive(fd)
            }, onToken: callback, request: control, onAdmitted: {
                headersStarted = self.startChunked(fd, contentType: "text/event-stream", cors: cors)
                guard headersStarted else { return false }
        emit(GatewayDialect.frame(["type": "stream-start", "warnings": []]))
        emit(
            GatewayDialect.frame([
                "type": "response-metadata",
                "id": "gen_" + String(format: "%08x", UInt32.random(in: 0...UInt32.max)),
                "modelId": self.gatewayModelID, "timestamp": self.iso(Date()),
            ]))
                return alive
            })

        // Selection errors already emitted exactly one terminal part. A
        // cancelled engine request must not append another error or success.
        if gatewayOutput.error != nil {
            if alive { endOutput() }
            return
        }
        if let error = stats.runtimeError {
            if headersStarted {
                emit(GatewayDialect.frame(["type": "error", "error": stats.requestFailure?.json
                    ?? ["message": error, "type": "inference_error"]]))
                endOutput()
            } else { requestRefusal(fd, stats.requestFailure ?? RequestFailure(.inferenceError, error), dialect: "gateway", cors: cors) }
            return
        }
        if let ts = thinkSplitter {
            let (think, content) = ts.flush()
            if !think.isEmpty, reasoningOpen {
                emit(
                    GatewayDialect.frame([
                        "type": "reasoning-delta", "id": "r0", "delta": think,
                    ]))
            }
            if reasoningOpen {
                emit(GatewayDialect.frame(["type": "reasoning-end", "id": "r0"]))
                reasoningOpen = false
            }
            if !content.isEmpty {
                flushEvents(gatewayOutput.acceptsToolCalls ? toolSplitter.push(content) : [.text(content)])
            }
        }
        if gatewayOutput.acceptsToolCalls { flushEvents(toolSplitter.flush()) }
        for part in gatewayOutput.finish() { emit(GatewayDialect.frame(part)) }
        if gatewayOutput.error != nil {
            if alive { endOutput() }
            return
        }
        let (unified, raw) = GatewayDialect.unifiedFinish(stats.finishReason, hasToolCall: gatewayOutput.hasToolCall)
        emit(
            GatewayDialect.finishFrame(
                reason: unified, rawReason: raw, inputTokens: stats.promptTokens,
                cachedTokens: stats.reusedPrefixTokens,
                outputText: max(0, stats.decodeTokens - reasoningTokens),
                outputReasoning: reasoningTokens))
        emit("data: [DONE]\n\n")
        if alive { endOutput() }
    }

    /// Append a one-line instruction to the system turn, adding one if the
    /// conversation has none. Used only for `toolChoice` `required` and `tool`,
    /// which fx sends on the reviewer and web-search calls.
    static func instructing(_ messages: [ChatMessage], _ line: String) -> [ChatMessage] {
        var out = messages
        if let i = out.firstIndex(where: { $0.role == "system" }) {
            out[i].content += "\n\n" + line
        } else {
            out.insert(ChatMessage(role: "system", content: line), at: 0)
        }
        return out
    }

    // MARK: /v1/chat/completions (OpenAI, SSE streaming)

    private func v1Chat(_ fd: Int32, _ rawJSON: [String: Any], cors: String, control: RequestController) {
        let json = Self.withoutNulls(rawJSON)
        func fail(_ message: String, status: String = "400 Bad Request", code: String = "invalid_request_error") {
            respondJSON(fd, ["error": ["message": message, "type": code, "code": code]], status: status, cors: cors)
        }
        if let error = openAIValidationError(json) { return fail(error) }
        let request: OpenAIDialect.Conversation
        do { request = try OpenAIDialect.conversation(json, contextLimit: engine.maxContextTokens) }
        catch { return fail("\(error)") }
        let stream = Self.bool(json["stream"]) ?? false
        let renderTools = request.choice == .disabled ? [] : request.tools
        var messages = request.messages
        if case .tool(let name) = request.choice {
            messages = Self.instructing(messages, "You must call the \(name) tool now.")
        } else if request.choice == .required {
            messages = Self.instructing(messages, "You must call one of the available tools now.")
        }
        if !request.parallel && !renderTools.isEmpty {
            messages = Self.instructing(messages, "Call at most one tool in this response.")
        }
        let extended = !renderTools.isEmpty || request.thinking
            || messages.contains { $0.role == "tool" || !$0.toolCalls.isEmpty || $0.reasoning != nil }
            || (json["messages"] as? [[String: Any]] ?? []).contains { $0["role"] as? String == "developer" }
            || (json["messages"] as? [[String: Any]] ?? []).filter { $0["role"] as? String == "system" }.count > 1
        let ids: [Int]
        var vision: VisionPrompt?
        do {
            if !extended {
                // Preserve existing plain-chat/vision templating and sampling.
                (ids, vision) = try engine.encodeWithVision(messages: Self.templateMessages(json), tools: nil, thinking: false, request: control)
            } else if messages.contains(where: { !$0.images.isEmpty }) {
                (ids, vision) = try engine.encodeChatWithVision(messages, tools: renderTools,
                    thinking: request.thinking, effort: request.effort, request: control)
            } else {
                try control.checkInputBytes(ContextInputMemory.bytes(messages: messages, tools: renderTools))
                ids = try engine.encodeChatSpliced(messages, tools: renderTools,
                    thinking: request.thinking, effort: request.effort, request: control)
            }
        } catch { requestRefusal(fd, error, dialect: "openai", cors: cors); return }
        if let error = engine.contextError(promptTokens: ids.count) { return fail(error, code: "context_length_exceeded") }
        guard ids.count < request.contextLimit else {
            return fail("prompt is \(ids.count) tokens, leaving no reply room in the requested context limit \(request.contextLimit)", code: "context_length_exceeded")
        }
        var params = renderTools.isEmpty ? (request.thinking ? SampleParams.thinking : .instruct) : .agent
        if !renderTools.isEmpty { control.sharedPrefixRetention = .conversation }
        if let v = Self.num(json["temperature"]) { params.temperature = Float(v) }
        if let v = Self.num(json["top_p"]) { params.topP = Float(v) }
        if let v = Self.int(json["top_k"]) { params.topK = v }
        if let v = Self.num(json["presence_penalty"]) { params.presencePenalty = Float(v) }
        if let v = Self.num(json["min_p"]) { params.minP = Float(v) }
        // Without a limit the reply gets the budget `/v1/models` advertises,
        // as on /v1/responses: agents' summary requests often send none, and
        // the 512-token chat default cut them off.
        params.maxTokens = GatewayDialect.outputBudget(contextCap: engine.maxContextTokens)
        if let v = Self.int(json["max_tokens"]) { params.maxTokens = v }
        if let v = Self.int(json["max_completion_tokens"]) { params.maxTokens = v }
        if let v = Self.int(json["seed"]) { params.seed = UInt64(bitPattern: Int64(v)) }
        if let v = Self.stopList(json["stop"]) { params.stop = v }
        if params.seed == nil { params.seed = Self.randomSeed() }
        params = params.sanitized()
        params.maxTokens = min(params.maxTokens, request.contextLimit - ids.count)
        let wantUsage = Self.bool((json["stream_options"] as? [String: Any])?["include_usage"]) ?? false
        let rid = "chatcmpl-\(UUID().uuidString)"
        let created = Int(Date().timeIntervalSince1970)
        var headersStarted = false
        let output = makeOutput(fd, streaming: stream)
        defer { finishOutput(output) }
        @discardableResult func writeChunk(_ data: Data) -> Bool { self.chunk(fd, data, writer: output) }
        func endOutput() { self.endChunked(fd, writer: output) }
        var alive = true
        var sentRole = false
        func emit(_ object: [String: Any]) {
            guard stream, alive else { return }
            let data = try! JSONSerialization.data(withJSONObject: object)
            alive = writeChunk(Data("data: ".utf8) + data + Data("\n\n".utf8))
        }
        func emitDelta(_ delta: [String: Any]) {
            var delta = delta
            if !sentRole { delta["role"] = "assistant"; sentRole = true }
            emit(["id": rid, "object": "chat.completion.chunk", "created": created, "model": engine.modelName,
                  "choices": [["index": 0, "delta": delta, "finish_reason": NSNull()]]])
        }
        let accumulated = OpenAIOutput(tools: renderTools, choice: request.choice, parallel: request.parallel,
            streamToolArguments: true, allowLengthTruncation: true)
        let thinker = request.thinking ? ThinkSplitter() : nil
        let parser = renderTools.isEmpty ? nil : ToolCallSplitter(tools: renderTools.map { $0.schema },
            idFactory: { "call_" + UUID().uuidString.replacingOccurrences(of: "-", with: "") })
        func consume(_ delta: String) {
            var body = delta
            if let thinker {
                let (reasoning, content) = thinker.push(delta)
                if !reasoning.isEmpty { emitDelta(accumulated.reasoningDelta(reasoning)) }
                body = content
            }
            if !body.isEmpty {
                for event in accumulated.consume(parser?.push(body) ?? [.text(body)]) { emitDelta(event) }
            }
        }
        let incremental = stream || (!request.parallel && !renderTools.isEmpty)
        let callback: ((Int, String) -> Bool)? = incremental ? { _, delta in
            if output?.alive == false { alive = false }
            guard alive else { return false }
            consume(delta)
            return accumulated.error == nil && !accumulated.finishedSingleCall && alive
        } : nil
        var lastKeepalive = RuntimeClock.now()
        let (text, _, stats) = engine.generate(promptIds: ids, params: params, vision: vision,
            shouldContinue: {
                if headersStarted && RuntimeClock.seconds(since: lastKeepalive) >= 10 {
                    lastKeepalive = RuntimeClock.now()
                    alive = writeChunk(Data(": keepalive\n\n".utf8))
                }
                return alive && (output?.alive ?? true) && self.peerAlive(fd)
                    && accumulated.error == nil && !accumulated.finishedSingleCall
            }, onToken: callback, request: control, onAdmitted: {
                guard stream else { return true }
                headersStarted = self.startChunked(fd, contentType: "text/event-stream", cors: cors)
                return headersStarted
            })
        if let error = stats.runtimeError {
            if headersStarted {
                emit(["error": stats.requestFailure?.json ?? RequestFailure(.inferenceError, error).json])
                endOutput()
            } else { requestRefusal(fd, stats.requestFailure ?? RequestFailure(.inferenceError, error), dialect: "openai", cors: cors) }
            return
        }
        if !incremental { consume(text) }
        if let thinker {
            let (reasoning, body) = thinker.flush()
            if !reasoning.isEmpty { emitDelta(accumulated.reasoningDelta(reasoning)) }
            if !body.isEmpty {
                for event in accumulated.consume(parser?.push(body) ?? [.text(body)]) { emitDelta(event) }
            }
        }
        if let parser {
            for event in accumulated.consume(parser.flush()) { emitDelta(event) }
        }
        let finish = accumulated.finishReason(stats.finishReason)
        if let error = stats.runtimeError ?? accumulated.error {
            if stream {
                emit(["error": ["message": error, "type": "server_error", "code": "inference_error"]])
                endOutput()
            } else if alive { fail(error, status: "500 Internal Server Error", code: "server_error") }
            return
        }
        let usage: [String: Any] = ["prompt_tokens": stats.promptTokens, "completion_tokens": stats.decodeTokens,
                                    "total_tokens": stats.promptTokens + stats.decodeTokens,
                                    "prompt_tokens_details": ["cached_tokens": stats.reusedPrefixTokens]]
        if stream, alive {
            var final: [String: Any] = ["id": rid, "object": "chat.completion.chunk", "created": created,
                "model": engine.modelName, "choices": [["index": 0, "delta": [:], "finish_reason": finish]]]
            // Keep the existing final-choice usage shape for current clients.
            if wantUsage { final["usage"] = usage }
            emit(final)
            if alive { writeChunk(Data("data: [DONE]\n\n".utf8)) }
            endOutput()
        } else if !stream, alive {
            respondJSON(fd, ["id": rid, "object": "chat.completion", "created": created, "model": engine.modelName,
                "choices": [["index": 0, "finish_reason": finish, "message": accumulated.message]], "usage": usage], cors: cors)
        }
    }

    // MARK: /v1/responses (OpenAI Responses API, SSE streaming)

    /// The Responses API, which is what Codex speaks. The wire contract lives in
    /// `ResponsesDialect`; this function wires it to the engine the way `v1Chat`
    /// wires Chat Completions, sharing the template, the splice, the vision
    /// path, the native tool parser and the OpenAI output rules.
    private func v1Responses(_ fd: Int32, _ rawJSON: [String: Any], cors: String, control: RequestController) {
        let json = Self.withoutNulls(rawJSON)
        func fail(_ failure: ResponsesDialect.Failure, status: String = "400 Bad Request") {
            respondJSON(fd, failure.body, status: status, cors: cors)
        }
        if let e = modelError(json) { return fail(ResponsesDialect.Failure("model_not_found", e)) }
        let request: ResponsesDialect.Request
        do { request = try ResponsesDialect.parse(json) }
        catch let failure as ResponsesDialect.Failure { return fail(failure) }
        catch { return fail(ResponsesDialect.Failure("invalid_request", "\(error)")) }

        let renderTools = request.choice == .disabled ? [] : request.tools
        var messages = request.messages
        if case .tool(let name) = request.choice {
            messages = Self.instructing(messages, "You must call the \(name) tool now.")
        } else if request.choice == .required {
            messages = Self.instructing(messages, "You must call one of the available tools now.")
        }
        if !request.parallel && !renderTools.isEmpty {
            messages = Self.instructing(messages, "Call at most one tool in this response.")
        }

        let ids: [Int]
        var vision: VisionPrompt?
        do {
            if request.hasImages {
                (ids, vision) = try engine.encodeChatWithVision(
                    messages, tools: renderTools, thinking: request.thinking, effort: request.effort, request: control)
            } else {
                try control.checkInputBytes(ContextInputMemory.bytes(messages: messages, tools: renderTools))
                ids = try engine.encodeChatSpliced(
                    messages, tools: renderTools, thinking: request.thinking, effort: request.effort, request: control)
            }
        } catch let failure as RequestFailure {
            requestRefusal(fd, failure, dialect: "openai", cors: cors)
            return
        } catch let e as SlotstreamError {
            return fail(ResponsesDialect.Failure("invalid_image", "\(e)"))
        } catch {
            return fail(ResponsesDialect.Failure("template_error", "\(error)"))
        }
        guard !ids.isEmpty else { return fail(ResponsesDialect.Failure("empty_prompt", "input must not be empty")) }
        if let e = engine.contextError(promptTokens: ids.count) {
            return fail(ResponsesDialect.Failure("context_length_exceeded", e))
        }
        guard ids.count < engine.maxContextTokens else {
            return fail(ResponsesDialect.Failure("context_length_exceeded",
                "prompt is \(ids.count) tokens, leaving no reply room in the \(engine.maxContextTokens)-token window"))
        }

        // Sampling. Codex sends no output limit, so the default is the
        // gateway's advertised budget bounded by the room left in the window,
        // never the 512-token chat default, which truncates every real edit.
        var params = renderTools.isEmpty ? (request.thinking ? SampleParams.thinking : .instruct) : .agent
        if !renderTools.isEmpty { control.sharedPrefixRetention = .conversation }
        let room = max(1, engine.maxContextTokens - ids.count)
        params.maxTokens = min(
            request.maxOutputTokens ?? GatewayDialect.outputBudget(contextCap: engine.maxContextTokens), room)
        if let v = request.temperature { params.temperature = v }
        if let v = request.topP { params.topP = v }
        params.seed = Self.randomSeed()
        params = params.sanitized()
        params.maxTokens = min(params.maxTokens, room)

        let stream = request.stream
        let response = ResponsesDialect.ResponseStream(model: engine.modelName, namespaces: request.namespaces,
                                                       freeform: request.freeform, echo: request.echo)
        var headersStarted = false
        let output = makeOutput(fd, streaming: stream)
        defer { finishOutput(output) }
        @discardableResult func writeChunk(_ data: Data) -> Bool { self.chunk(fd, data, writer: output) }
        func endOutput() { self.endChunked(fd, writer: output) }
        var alive = true
        func emit(_ frames: [String]) {
            guard stream, alive else { return }
            for f in frames {
                alive = writeChunk(Data(f.utf8))
                if !alive { break }
            }
        }
        let accumulated = OpenAIOutput(tools: renderTools, choice: request.choice, parallel: request.parallel)
        let thinker = request.thinking ? ThinkSplitter() : nil
        let parser = renderTools.isEmpty ? nil : ToolCallSplitter(tools: renderTools.map { $0.schema },
            idFactory: { "call_" + UUID().uuidString.replacingOccurrences(of: "-", with: "") })
        var reasoningTokens = 0
        var publishedCalls = 0
        // The accumulator applies the OpenAI rules (declared names, a forced
        // choice, malformed calls) and hands back chat-shaped deltas; they are
        // re-expressed as Responses items here, in the order they happened.
        func publish(_ deltas: [[String: Any]]) {
            for delta in deltas {
                if let t = delta["content"] as? String { emit(response.text(t)) }
                if delta["tool_calls"] != nil, publishedCalls < accumulated.calls.count {
                    emit(response.functionCall(accumulated.calls[publishedCalls]))
                    publishedCalls += 1
                }
            }
        }
        func consume(_ delta: String) {
            var body = delta
            if let thinker {
                let (thought, content) = thinker.push(delta)
                if !thought.isEmpty {
                    reasoningTokens += 1
                    _ = accumulated.reasoningDelta(thought)
                    emit(response.reasoning(thought))
                }
                body = content
            }
            if !body.isEmpty { publish(accumulated.consume(parser?.push(body) ?? [.text(body)])) }
        }
        let incremental = stream || (!request.parallel && !renderTools.isEmpty)
        let callback: ((Int, String) -> Bool)? = incremental ? { _, delta in
            if output?.alive == false { alive = false }
            guard alive else { return false }
            consume(delta)
            return accumulated.error == nil && !accumulated.finishedSingleCall && alive
        } : nil
        var lastKeepalive = RuntimeClock.now()
        let (text, _, stats) = engine.generate(promptIds: ids, params: params, vision: vision,
            shouldContinue: {
                // The one hook that runs during prefill. Codex allows 300 s of
                // silence by default and counts events, not bytes, so the
                // keepalive is a real in_progress event rather than a comment.
                if headersStarted && RuntimeClock.seconds(since: lastKeepalive) >= 10 {
                    lastKeepalive = RuntimeClock.now()
                    emit([response.keepalive()])
                }
                return alive && (output?.alive ?? true) && self.peerAlive(fd)
                    && accumulated.error == nil && !accumulated.finishedSingleCall
            }, onToken: callback, request: control, onAdmitted: {
                guard stream else { return true }
                headersStarted = self.startChunked(fd, contentType: "text/event-stream", cors: cors)
                guard headersStarted else { return false }
                emit(response.created())
                return alive
            })
        if let error = stats.runtimeError {
            let failure = stats.requestFailure ?? RequestFailure(.inferenceError, error)
            if headersStarted {
                emit(response.fail(code: failure.code.rawValue, message: failure.message))
                endOutput()
            } else { requestRefusal(fd, failure, dialect: "openai", cors: cors) }
            return
        }
        if !incremental { consume(text) }
        if let thinker {
            let (thought, body) = thinker.flush()
            if !thought.isEmpty {
                reasoningTokens += 1
                _ = accumulated.reasoningDelta(thought)
                emit(response.reasoning(thought))
            }
            if !body.isEmpty { publish(accumulated.consume(parser?.push(body) ?? [.text(body)])) }
        }
        if let parser { publish(accumulated.consume(parser.flush())) }
        _ = accumulated.finishReason(stats.finishReason)
        if let error = accumulated.error {
            if stream {
                emit(response.fail(code: "inference_error", message: error))
                endOutput()
            } else if alive {
                fail(ResponsesDialect.Failure("inference_error", error), status: "500 Internal Server Error")
            }
            return
        }
        let usage = ResponsesDialect.Usage(input: stats.promptTokens, cached: stats.reusedPrefixTokens,
                                           output: stats.decodeTokens, reasoning: reasoningTokens)
        if stream {
            if alive {
                emit(response.finish(engineReason: stats.finishReason, usage: usage))
                endOutput()
            }
        } else if alive {
            respondJSON(fd, response.finished(engineReason: stats.finishReason, usage: usage), cors: cors)
        }
    }

    // MARK: /v1/messages

    /// Field names unknown to the Anthropic dialect that were already logged,
    /// so a client that sends one on every request logs it once.
    private static var loggedIgnoredFields = Set<String>()
    private static let ignoredFieldsLock = NSLock()

    /// Names safe to repeat in a header and a log line. They come from the
    /// client's JSON, so anything but a plain identifier is left out.
    package static func headerSafeFieldNames(_ names: [String]) -> [String] {
        Array(names.filter { name in
            !name.isEmpty && name.count <= 64
                && name.unicodeScalars.allSatisfy { $0.isASCII && (CharacterSet.alphanumerics.contains($0) || "_-.".unicodeScalars.contains($0)) }
        }.prefix(16))
    }

    /// The conversation and tools a Messages request renders, with the tool
    /// choice written into the system prompt as the other dialects do.
    private func anthropicPrompt(_ request: AnthropicDialect.Request) -> ([ChatMessage], [ToolDefinition]) {
        let renderTools = request.choice == .disabled ? [] : request.tools
        var messages = request.messages
        if case .tool(let name) = request.choice {
            messages = Self.instructing(messages, "You must call the \(name) tool now.")
        } else if request.choice == .required {
            messages = Self.instructing(messages, "You must call one of the available tools now.")
        }
        if !request.parallel && !renderTools.isEmpty {
            messages = Self.instructing(messages, "Call at most one tool in this response.")
        }
        return (messages, renderTools)
    }

    private func v1Messages(_ fd: Int32, _ rawJSON: [String: Any], cors baseCors: String, control: RequestController) {
        var cors = baseCors
        func fail(_ failure: AnthropicDialect.Failure) {
            respondJSON(fd, failure.body, status: failure.status, cors: cors)
        }
        if let e = modelError(rawJSON) {
            return fail(AnthropicDialect.Failure("model: \(e)", type: "not_found_error", status: "404 Not Found"))
        }
        let request: AnthropicDialect.Request
        do { request = try AnthropicDialect.parse(rawJSON) }
        catch let failure as AnthropicDialect.Failure { return fail(failure) }
        catch { return fail(AnthropicDialect.Failure("\(error)")) }
        let ignored = Self.headerSafeFieldNames(request.ignored)
        if !ignored.isEmpty {
            cors += "X-Slotstream-Ignored-Fields: \(ignored.joined(separator: ", "))\r\n"
            let fresh = Self.ignoredFieldsLock.withLock { () -> [String] in
                // Bounded: a client inventing names cannot grow it forever.
                guard Self.loggedIgnoredFields.count < 256 else { return [] }
                let new = ignored.filter { !Self.loggedIgnoredFields.contains($0) }
                Self.loggedIgnoredFields.formUnion(new)
                return new
            }
            if !fresh.isEmpty {
                print("/v1/messages: ignoring request field(s) this server does not know: \(fresh.joined(separator: ", "))")
                fflush(stdout)
            }
        }
        let (messages, renderTools) = anthropicPrompt(request)

        let ids: [Int]
        var vision: VisionPrompt?
        do {
            if request.hasImages {
                (ids, vision) = try engine.encodeChatWithVision(
                    messages, tools: renderTools, thinking: request.thinking, effort: request.effort, request: control)
            } else {
                try control.checkInputBytes(ContextInputMemory.bytes(messages: messages, tools: renderTools))
                ids = try engine.encodeChatSpliced(
                    messages, tools: renderTools, thinking: request.thinking, effort: request.effort, request: control)
            }
        } catch let failure as RequestFailure {
            requestRefusal(fd, failure, dialect: "anthropic", cors: cors)
            return
        } catch let e as SlotstreamError {
            // Claude Code removes the pictures and retries on these words;
            // any other wording repeats the failure on every later turn.
            return fail(AnthropicDialect.Failure("Could not process image: \(e)"))
        } catch {
            return fail(AnthropicDialect.Failure("the conversation could not be rendered: \(error)"))
        }
        guard !ids.isEmpty else { return fail(AnthropicDialect.Failure("messages: the prompt is empty")) }
        let window = engine.maxContextTokens
        if ids.count >= window {
            return fail(AnthropicDialect.Failure(AnthropicDialect.promptTooLong(tokens: ids.count, maximum: window - 1)))
        }
        if let e = engine.contextError(promptTokens: ids.count) {
            return fail(AnthropicDialect.Failure(e))
        }

        // `max_tokens` is a ceiling, and Claude Code asks for 32,000 whatever
        // the window; the reply gets what the window has left, and a reply
        // that reaches that point ends with `max_tokens`.
        var params = renderTools.isEmpty ? (request.thinking ? SampleParams.thinking : .instruct) : .agent
        if !renderTools.isEmpty { control.sharedPrefixRetention = .conversation }
        let room = max(1, window - ids.count)
        params.maxTokens = request.maxTokens
        if let v = request.temperature { params.temperature = v }
        if let v = request.topP { params.topP = v }
        if let v = request.topK { params.topK = v }
        params.stop = request.stopSequences
        params.seed = Self.randomSeed()
        params = params.sanitized()
        // A reply the window cuts short ends with
        // `model_context_window_exceeded`, not `max_tokens`.
        let windowLimited = params.maxTokens > room
        params.maxTokens = min(params.maxTokens, room)

        let stream = request.stream
        let message = AnthropicDialect.MessageStream(model: engine.modelName, showThinking: request.showThinking)
        var headersStarted = false
        let output = makeOutput(fd, streaming: stream)
        defer { finishOutput(output) }
        @discardableResult func writeChunk(_ data: Data) -> Bool { self.chunk(fd, data, writer: output) }
        func endOutput() { self.endChunked(fd, writer: output) }
        var alive = true
        // The frames are built whether or not they are written: the
        // non-streaming reply is the message the stream would have described.
        func emit(_ frames: [String]) {
            guard stream, alive else { return }
            for f in frames {
                alive = writeChunk(Data(f.utf8))
                if !alive { break }
            }
        }
        let accumulated = OpenAIOutput(tools: renderTools, choice: request.choice, parallel: request.parallel)
        let thinker = request.thinking ? ThinkSplitter() : nil
        let parser = renderTools.isEmpty ? nil : ToolCallSplitter(tools: renderTools.map { $0.schema },
            idFactory: { AnthropicDialect.toolUseID() })
        var publishedCalls = 0
        func publish(_ deltas: [[String: Any]]) {
            for delta in deltas {
                if let t = delta["content"] as? String { emit(message.text(t)) }
                if delta["tool_calls"] != nil, publishedCalls < accumulated.calls.count {
                    emit(message.toolUse(accumulated.calls[publishedCalls]))
                    publishedCalls += 1
                }
            }
        }
        func think(_ thought: String) {
            guard !thought.isEmpty else { return }
            _ = accumulated.reasoningDelta(thought)
            emit(message.thinking(thought))
        }
        func consume(_ delta: String) {
            var body = delta
            if let thinker {
                let (thought, content) = thinker.push(delta)
                think(thought)
                body = content
            }
            if !body.isEmpty { publish(accumulated.consume(parser?.push(body) ?? [.text(body)])) }
        }
        let incremental = stream || (!request.parallel && !renderTools.isEmpty)
        let callback: ((Int, String) -> Bool)? = incremental ? { _, delta in
            if output?.alive == false { alive = false }
            guard alive else { return false }
            consume(delta)
            return accumulated.error == nil && !accumulated.finishedSingleCall && alive
        } : nil
        var lastKeepalive = RuntimeClock.now()
        let (text, _, stats) = engine.generate(promptIds: ids, params: params, vision: vision,
            shouldContinue: {
                // The hook that runs during prefill. A cold prompt is read for
                // minutes; a ping every ten seconds keeps the stream visibly
                // alive for Claude Code's idle abort and for any proxy.
                if headersStarted && RuntimeClock.seconds(since: lastKeepalive) >= 10 {
                    lastKeepalive = RuntimeClock.now()
                    emit([message.keepalive()])
                }
                return alive && (output?.alive ?? true) && self.peerAlive(fd)
                    && accumulated.error == nil && !accumulated.finishedSingleCall
            }, onToken: callback, request: control, onAdmitted: {
                guard stream else { return true }
                headersStarted = self.startChunked(fd, contentType: "text/event-stream", cors: cors)
                guard headersStarted else { return false }
                emit(message.start(promptTokens: ids.count, reused: control.admittedReusedTokens ?? 0))
                return alive
            })
        if let error = stats.runtimeError {
            let failure = stats.requestFailure ?? RequestFailure(.inferenceError, error)
            if headersStarted {
                emit(message.fail(type: AnthropicDialect.errorType(httpStatus: failure.httpStatus), message: failure.message))
                endOutput()
            } else { requestRefusal(fd, failure, dialect: "anthropic", cors: cors) }
            return
        }
        if !incremental { consume(text) }
        if let thinker {
            let (thought, body) = thinker.flush()
            think(thought)
            if !body.isEmpty { publish(accumulated.consume(parser?.push(body) ?? [.text(body)])) }
        }
        if let parser { publish(accumulated.consume(parser.flush())) }
        _ = accumulated.finishReason(stats.finishReason)
        if let error = accumulated.error {
            // A reply that ran out of room inside a call, or before the call
            // a tool choice demanded, stopped for length: the partial call is
            // withheld and the client sees `max_tokens`, which Claude Code
            // knows how to continue from. Anything else is a failure.
            let truncated = stats.finishReason == "length"
                && (error.hasPrefix("model produced an incomplete") || error.hasPrefix("model did not satisfy tool_choice"))
            if !truncated {
                if stream {
                    emit(message.fail(type: "api_error", message: error))
                    endOutput()
                } else if alive {
                    fail(AnthropicDialect.Failure(error, type: "api_error", status: "500 Internal Server Error"))
                }
                return
            }
        }
        let usage = AnthropicDialect.Usage(prompt: stats.promptTokens, cached: stats.reusedPrefixTokens,
                                           output: stats.decodeTokens)
        if stream {
            if alive {
                emit(message.finish(engineReason: stats.finishReason, stopSequence: stats.stopSequence, usage: usage,
                                    windowLimited: windowLimited))
                endOutput()
            }
        } else if alive {
            respondJSON(fd, message.message(engineReason: stats.finishReason, stopSequence: stats.stopSequence,
                                            usage: usage, windowLimited: windowLimited), cors: cors)
        }
    }

    /// `POST /v1/messages/count_tokens`: the prompt length a Messages request
    /// renders to, with no request admitted and nothing generated.
    private func v1CountTokens(_ fd: Int32, _ rawJSON: [String: Any], cors: String) {
        func fail(_ failure: AnthropicDialect.Failure) {
            respondJSON(fd, failure.body, status: failure.status, cors: cors)
        }
        if let e = modelError(rawJSON) {
            return fail(AnthropicDialect.Failure("model: \(e)", type: "not_found_error", status: "404 Not Found"))
        }
        let request: AnthropicDialect.Request
        do { request = try AnthropicDialect.parse(rawJSON, counting: true) }
        catch let failure as AnthropicDialect.Failure { return fail(failure) }
        catch { return fail(AnthropicDialect.Failure("\(error)")) }
        let (messages, renderTools) = anthropicPrompt(request)
        do {
            let count = try engine.countChatTokens(messages, tools: renderTools, thinking: request.thinking,
                                                   effort: request.effort)
            respondJSON(fd, ["input_tokens": count], cors: cors)
        } catch let e as SlotstreamError {
            fail(AnthropicDialect.Failure("Could not process image: \(e)"))
        } catch {
            fail(AnthropicDialect.Failure("the conversation could not be rendered: \(error)"))
        }
    }
}


/// Qwen emits its reasoning first and closes it with `</think>`. Ollama's
/// protocol carries that in `message.thinking` (`thinking` on /api/generate),
/// never in the answer. One instance follows one response.
package final class ThinkSplitter {
    private static let tag = "</think>"
    private var buf = ""
    private var closed = false
    private var answered = false

    package init() {}

    /// Splits one delta into (thinking, content). Until the tag arrives the
    /// last few characters are withheld, so a tag straddling two deltas is
    /// never emitted as reasoning text.
    package func push(_ s: String) -> (String, String) {
        if closed { return ("", answer(s)) }
        buf += s
        if let r = buf.range(of: Self.tag) {
            let think = String(buf[..<r.lowerBound])
            let rest = String(buf[r.upperBound...])
            buf = ""
            closed = true
            return (think, answer(rest))
        }
        let keep = min(buf.count, Self.tag.count - 1)
        let emit = String(buf.dropLast(keep))
        buf = String(buf.suffix(keep))
        return (emit, "")
    }

    /// The answer without the newlines the model puts after `</think>`,
    /// which can arrive in the deltas after the tag; `split` drops them too.
    private func answer(_ s: String) -> String {
        if answered { return s }
        let rest = s.drop { $0 == "\n" }
        if !rest.isEmpty { answered = true }
        return String(rest)
    }

    /// Whatever is still withheld when generation ends. A response that never
    /// closed its reasoning is all thinking and no answer, and says so.
    package func flush() -> (String, String) {
        let rest = buf
        buf = ""
        return closed ? ("", answer(rest)) : (rest, "")
    }

    /// The same split over a whole non-streamed response.
    package static func split(_ text: String) -> (String, String) {
        guard let r = text.range(of: tag) else { return (text, "") }
        var content = String(text[r.upperBound...])
        while content.hasPrefix("\n") { content.removeFirst() }
        return (String(text[..<r.lowerBound]), content)
    }
}
