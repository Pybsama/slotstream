@joshirio, I've now run full-model tests on the exact public v0.2.29 release using your two prompts at 32,320 and 32,770 tokens, with `--mtp off` and 500 generated tokens each.

I tested three configurations: the normal M5 path, the rotation/prefill fallback paths used on M4, and those fallback paths with automatic expert read-ahead enabled. All six requests completed. Per-token timings showed no sustained cliff while crossing 32,768, and the requests that started above it did not enter a slower regime either.

These were on my M5 Pro with smaller caches and 256-token prefill, so they don't reproduce your M4/40 GB configuration. They are diagnostic observations on a live desktop, not clean speed benchmarks. Selecting the M4 code paths also doesn't emulate its GPU or driver.

Your reported drop is still unexpected, and I'm keeping this open. The internal attention-work split and cache growth near that boundary are real, but neither has been established as the cause of your slowdown. I also can't yet say whether removing keepalive fixed it on your machine.

The v0.2.29 comparison on your M4, with the same settings as your original report, is still the missing check. If the cliff remains, please also include your macOS version and the matching `slotstream doctor` output so we can pin down the remaining hardware and memory differences.
