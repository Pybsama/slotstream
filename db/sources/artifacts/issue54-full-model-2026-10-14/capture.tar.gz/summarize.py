"""Validate completed API payloads and expose interval costs across 32768 active keys."""
import json,math,statistics,sys,hashlib
from pathlib import Path

def summary(values):
 if not values:return None
 ordered=sorted(values)
 return {'count':len(values),'mean_ms':statistics.mean(values)*1000,'median_ms':statistics.median(values)*1000,'p95_ms':ordered[math.ceil(.95*len(values))-1]*1000,'max_ms':max(values)*1000}

root=Path(sys.argv[1]);results=[]
for path in sorted(root.glob('response-*.json')):
 d=json.loads(path.read_text());b=d['slotstream_benchmark'];s=b['stats'];p=d['prompt_eval_count'];n=d['eval_count'];intervals=s['interTokenSeconds']
 assert d.get('done') is True and 'error' not in d and not s.get('runtimeError')
 assert len(b['output_ids'])==n==s['decodeTokens']==500
 assert len(b['prompt_ids'])==p==s['promptTokens']
 assert len(intervals)==n-1 and all(math.isfinite(x) and x>0 for x in intervals)
 assert sum(s['prefillPasses'])==s['prefillTokens']
 # First output is sampled from prefill logits. Interval i advances a one-row
 # forward to prompt+i+1 active keys, plus sampling/callback overhead.
 rows=[{'active_keys':p+i+1,'seconds':v} for i,v in enumerate(intervals)]
 result={'response':path.name,'prompt_tokens':p,'output_tokens':n,'decode_tps':n/(d['eval_duration']/1e9),'intervals':summary(intervals),
  'below_all':summary([r['seconds'] for r in rows if r['active_keys']<=32768]),
  'above_all':summary([r['seconds'] for r in rows if r['active_keys']>32768]),
  'near_below_32705_32768':summary([r['seconds'] for r in rows if 32705<=r['active_keys']<=32768]),
  'near_above_32770_32819':summary([r['seconds'] for r in rows if 32770<=r['active_keys']<=32819]),
  'boundary_rows':[r for r in rows if 32764<=r['active_keys']<=32776],
  'effective_mtp':b['effective_mtp'],'effective_pool_slots':b['effective_pool_slots'],'effective_prefill_chunk':b['effective_prefill_chunk'],'optimizations':b['optimizations'],
  'stats':{k:v for k,v in s.items() if k not in ['interTokenSeconds','prefillPasses','prefillComputePasses']}}
 results.append(result)
(root/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
for r in results:
 print(json.dumps({k:v for k,v in r.items() if k not in ['stats','optimizations']}))
