import hashlib,json,tarfile
from pathlib import Path
root=Path(__file__).resolve().parent
excluded={'analysis-draft.md','source-wrapper-draft.md','measurement-body.md','source-body.md','archive-receipt.json','inventory.json'}
files=[p for p in sorted(root.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.name not in excluded]
items={str(p.relative_to(root)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files}
(root/'inventory.json').write_text(json.dumps(items,indent=2)+'\n')
output=Path('/Users/carlos/Projects/slotstream/db/sources/artifacts/issue54-full-model-2026-10-14/capture.tar.gz')
output.parent.mkdir(parents=True,exist_ok=False)
with tarfile.open(output,'w:gz') as tar:
 for p in [*files,root/'inventory.json']:tar.add(p,arcname=str(p.relative_to(root)))
with tarfile.open(output,'r:gz') as tar:
 assert len(tar.getmembers())==len(items)+1
 for name,meta in items.items():
  data=tar.extractfile(name).read();assert len(data)==meta['bytes'] and hashlib.sha256(data).hexdigest()==meta['sha256'],name
receipt={'artifact':str(output),'bytes':output.stat().st_size,'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'verified_inventory_members':len(items),'total_members':len(items)+1}
(root/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
