import json,re,statistics,sys
from pathlib import Path
p=Path(sys.argv[1]);x=json.loads(p.read_text());m=x['measurements']
result={'passed':x['passed'],'assertions':len(x['items']),'failures':[r for r in x['items'] if not r['passed']],
        'memory':{k:v for k,v in m.items() if 'Bytes' in k and not k.startswith('layer')},'layers':{}}
for layer in [3,47]:
 rounds=[]
 for rnd in range(4):
  base=f'layer{layer}.round{rnd}.keys'
  row={'round':rnd,'instrumented':rnd==3}
  for metric in ['seconds','readoutSeconds']:
   vals={int(re.search(r'keys(\d+)\.',k)[1]):v for k,v in m.items() if k.startswith(base) and k.endswith('.'+metric)}
   # Exclude initial 32 warmup steps and the growth/sort transition from steady buckets.
   below=[v for n,v in vals.items() if 32737<=n<=32768]
   above=[v for n,v in vals.items() if 32777<=n<=32832]
   row[metric]={'below_median_ms':1000*statistics.median(below),'above_median_ms':1000*statistics.median(above),
     'above_over_below':statistics.median(above)/statistics.median(below),
     'below_mean_ms':1000*statistics.mean(below),'above_mean_ms':1000*statistics.mean(above),
     'below_p95_ms':1000*sorted(below)[int(.95*(len(below)-1))],'above_p95_ms':1000*sorted(above)[int(.95*(len(above)-1))],
     'transition_ms':{n:vals[n]*1000 for n in range(32767,32777)}}
  row['growth_bytes']=m[base+'32769.cacheBytes']-m[base+'32768.cacheBytes']
  rounds.append(row)
 result['layers'][layer]=rounds
print(json.dumps(result,indent=2))
