import json,os,subprocess,sys,time
from pathlib import Path
sys.path.insert(0,'/Users/carlos/Projects/slotstream/Tools')
from prefill_bench import preflight,vm_snapshot,host_conditions,digest
from serve_bench import verified_build
root=Path(sys.argv[1]).resolve();root.mkdir(parents=True,exist_ok=False)
binary=Path('/tmp/issue54-native-2026-10-13/build-portable/candidate/slotstream')
meta={'scope':'native trained first/last attention-layer probes; synthetic layer history, not model generation',
      'before':preflight(4),'build':verified_build(binary),'host_before':host_conditions()}
if int(subprocess.check_output(['sysctl','-n','kern.memorystatus_vm_pressure_level'],text=True))!=1:raise RuntimeError('OS pressure not normal')
env={k:v for k,v in os.environ.items() if not k.startswith(('SLOTSTREAM_','MLX_'))}
if len(sys.argv)>2:
 env['SLOTSTREAM_OPT_FUSED_ROPE']=sys.argv[2]
meta['explicit_overrides']={k:v for k,v in env.items() if k.startswith(('SLOTSTREAM_','MLX_'))}
cmd=[str(binary),'optimization-state-check','--model',str(Path.home()/'.slotstream/models/qwen38-flash-next-mlx-4bit'),
     '--variant','context-boundary-component','--json']
meta['command']=cmd
started=time.monotonic()
try:
 with (root/'native.json').open('w') as out,(root/'native.stderr').open('w') as err:
  run=subprocess.run(cmd,env=env,stdout=out,stderr=err,timeout=600)
 meta['exit_code']=run.returncode
finally:
 meta['elapsed_seconds']=time.monotonic()-started;meta['after']=vm_snapshot();meta['host_after']=host_conditions()
 (root/'native-manifest.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps({k:v for k,v in meta.items() if k in ['exit_code','elapsed_seconds']}),flush=True)
