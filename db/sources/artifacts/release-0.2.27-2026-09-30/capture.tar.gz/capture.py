#!/usr/bin/env python3
"""Package the v0.2.27 release evidence the way v0.2.26's was packaged.

One addition: generated tensor dumps are excluded with their SHA-256 kept
in the manifest, since their comparisons are in the gate logs.

    capture.py <evidence-dir> <artifact-dir> <commit> <note>

Writes capture.tar.gz (normalized metadata), manifest.json (every included
file's size and SHA-256, every excluded file's size and reason) and
receipt.json, then reads every included file back from the archive and checks
it against the manifest.
"""
import hashlib
import io
import json
import pathlib
import sys
import tarfile

src, dst, commit, note = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2]), sys.argv[3], sys.argv[4]
dst.mkdir(parents=True, exist_ok=False)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def exclusion(rel, path):
    name = path.name
    if name in ('slotstream', 'mlx.metallib') and rel.startswith(('candidate/',)):
        return ('CI candidate binary identified by build-identity.json' if name == 'slotstream'
                else 'Metal library identified by build-identity.json')
    if name == 'slotstream-arm64.tar.gz':
        return 'release archive identified by its SHA-256 in the retained receipts'
    if name.endswith(('.slotprefix', '.slotseg')):
        return 'disposable generated tensor cache'
    if name.endswith(('.bin', '.safetensors')) and any(
            part in rel for part in ('/vision-parity/', '/current-layers/', '/current-mtp/')):
        return 'generated tensor dump; its comparison is in the gate log'
    if path.stat().st_size > 64 * 1024 * 1024:
        return 'larger than 64 MB; identified by size only'
    return None


files, excluded = [], []
for path in sorted(p for p in src.rglob('*') if p.is_file() and not p.is_symlink()):
    rel = path.relative_to(src).as_posix()
    if rel.startswith('capture/'):
        continue
    reason = exclusion(rel, path)
    if reason:
        entry = {'path': rel, 'bytes': path.stat().st_size, 'reason': reason}
        if reason.startswith('generated tensor dump'):
            entry['sha256'] = digest(path.read_bytes())
        excluded.append(entry)
    else:
        data = path.read_bytes()
        files.append({'path': rel, 'bytes': len(data), 'sha256': digest(data)})

buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w:gz', format=tarfile.PAX_FORMAT) as archive:
    for entry in files:
        data = (src / entry['path']).read_bytes()
        info = tarfile.TarInfo(entry['path'])
        info.size, info.mtime, info.mode = len(data), 0, 0o644
        info.uid = info.gid = 0
        info.uname = info.gname = ''
        archive.addfile(info, io.BytesIO(data))
archive_bytes = buffer.getvalue()
(dst / 'capture.tar.gz').write_bytes(archive_bytes)
manifest = {'format': 1, 'commit': commit, 'files': files, 'excluded': excluded, 'note': note}
manifest_bytes = (json.dumps(manifest, indent=1) + '\n').encode()
(dst / 'manifest.json').write_bytes(manifest_bytes)

with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode='r:gz') as archive:
    members = {m.name: archive.extractfile(m).read() for m in archive.getmembers()}
verified = (set(members) == {f['path'] for f in files}
            and all(digest(members[f['path']]) == f['sha256'] for f in files))
receipt = {'files': len(files), 'uncompressed_bytes': sum(f['bytes'] for f in files),
           'archive_bytes': len(archive_bytes), 'archive_sha256': digest(archive_bytes),
           'manifest_sha256': digest(manifest_bytes),
           'excluded_bytes': sum(e['bytes'] for e in excluded), 'verified': verified}
(dst / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
sys.exit(0 if verified else 1)
