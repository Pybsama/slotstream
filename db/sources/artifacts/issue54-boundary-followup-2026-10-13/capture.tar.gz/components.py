import json, math, statistics, sys, time
from pathlib import Path
sys.path.insert(0, '/Users/carlos/Projects/slotstream/Tools')
from prefill_bench import vm_snapshot, host_conditions
import mlx.core as mx
mx.set_cache_limit(128 << 20)
mx.random.seed(54)
lengths=[32320,32767,32768,32769,32771,32772,32776,33070]
# Float32 indexer operands, BF16 attention operands, exact production shapes.
# Synthetic data and Python orchestration: component evidence only.
q=mx.random.normal((1,24,1,256)).astype(mx.bfloat16)
k=mx.random.normal((1,2,33792,256)).astype(mx.bfloat16)
v=mx.random.normal((1,2,33792,256)).astype(mx.bfloat16)
iq=mx.random.normal((1,1,4,128))
pooled=mx.random.normal((1,8448,128))
mx.eval(q,k,v,iq,pooled)
print(json.dumps({'kind':'identity','mlx':mx.__version__,'device':mx.device_info(),
 'scope':'synthetic production-shaped score/partition/mask/attention; no model weights, M5 Pro, no M4 reproduction',
 'lengths':lengths,'rounds':4,'repeats':30,'host_before':host_conditions(),'vm_before':vm_snapshot()}),flush=True)

def timed(fn):
 for _ in range(5): mx.eval(fn())
 times=[]
 for _ in range(30):
  t=time.perf_counter_ns();out=fn();mx.eval(out);times.append((time.perf_counter_ns()-t)/1e6)
 return {'median_ms':statistics.median(times),'samples_ms':times},out

for rnd in range(4):
 for n in lengths if rnd%2==0 else reversed(lengths):
  blocks=n//4
  cap=math.ceil(n/1024)*1024
  # Reproduce capacity-backed noncontiguous KV views; underlying heads separated by capacity.
  keys=mx.contiguous(k[:,:,:cap,:])[:,:,:n,:]
  values=mx.contiguous(v[:,:,:cap,:])[:,:,:n,:]
  ip=mx.contiguous(pooled[:,:blocks,:])
  mx.eval(keys,values,ip)
  def scores_fn():
   return mx.maximum(mx.einsum('bshd,bnd->bsnh',iq,ip),0).sum(axis=-1)/math.sqrt(128)
  scores=scores_fn();mx.eval(scores)
  def partition_fn():return mx.argpartition(-scores,kth=511,axis=-1)[...,:512]
  def mask_fn():
   scores2=scores_fn()
   top=mx.argpartition(-scores2,kth=511,axis=-1)[...,:512].astype(mx.int32)
   storage=mx.zeros((1,1,blocks+1),dtype=mx.bool_)
   keep_block=mx.put_along_axis(storage,top,mx.array(True),axis=-1)[...,:blocks]
   keep=mx.repeat(keep_block,4,axis=-1)
   if n%4:keep=mx.concatenate([keep,mx.zeros((1,1,n%4),dtype=mx.bool_)],axis=-1)
   # Last query: all complete blocks visible; own partial block always visible.
   keep=mx.logical_or(keep,mx.arange(n).reshape(1,1,n)>=blocks*4)
   return keep.reshape(1,1,1,n)
  mask=mask_fn();mx.eval(mask)
  def attention_fn():return mx.fast.scaled_dot_product_attention(q,keys,values,scale=.0625,mask=mask)
  def combined_fn():return mx.fast.scaled_dot_product_attention(q,keys,values,scale=.0625,mask=mask_fn())
  row={'kind':'component','round':rnd,'keys':n,'capacity':cap,'blocks':blocks}
  for name,fn in [('scores',scores_fn),('partition',partition_fn),('score_mask',mask_fn),('attention',attention_fn),('combined',combined_fn)]:
   row[name],out=timed(fn)
   row[name]['finite']=bool(mx.all(mx.isfinite(out)).item())
  row['mask_count']=int(mask.sum().item());row['expected_mask_count']=2048+n%4
  row['peak_bytes']=mx.get_peak_memory()
  print(json.dumps(row),flush=True)
print(json.dumps({'kind':'end','vm_after':vm_snapshot(),'host_after':host_conditions()}),flush=True)
