"""Bounded exploratory issue-54 reproduction against exact public v0.2.29.
Not a same-hardware performance qualification. Never waives the memory gate.
"""
import hashlib, json, os, socket, subprocess, sys, time, urllib.request
from pathlib import Path
sys.path.insert(0, '/Users/carlos/Projects/slotstream/Tools')
from prefill_bench import preflight, vm_snapshot, host_conditions, digest
from serve_bench import stop_server, wait_ready
root=Path(__file__).resolve().parent
binary=Path('/tmp/slotstream-release-0.2.29/publication/install-root/bin/slotstream')
expected='4d7d4ed4d2a19b5991d47f4731198932cd616e5c2722fcf8b6e37612c232f051'
protocol={'schema':1,'scope':'exploratory public release boundary reproduction; M5 Pro, smaller cache than reporter',
 'binary_sha256':expected,'release':'v0.2.29','release_source':'5728fc2d64d7d918f1c16c3f45538d6fd2b9e900',
 'memory_gb':9,'required_reclaimable_gb':12,'max_context':36864,'mtp':'off','vision':'off',
 'words':[10750,10900],'num_predict':500,'temperature':0,'think':True,'stream':False,
 'prefix_cache':'default in-memory only; no persistent directory','prefill_chunk':256,
 'timing_claim_policy':'No cross-hardware ratio or release fix conclusion. Global paging or nonnominal state excludes clean timings.'}
(root/'reproduction-protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
result={'status':'preflight','protocol_sha256':digest(root/'reproduction-protocol.json'),'before':vm_snapshot(),'host_before':host_conditions()}
child=None
try:
 assert digest(binary)==expected,'public executable identity changed'
 pressure=int(subprocess.check_output(['sysctl','-n','kern.memorystatus_vm_pressure_level'],text=True))
 if pressure!=1:raise RuntimeError(f'OS pressure not normal: {pressure}')
 result['preflight']=preflight(12)
 with socket.socket() as sock:
  sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
 env={k:v for k,v in os.environ.items() if not k.startswith(('SLOTSTREAM_','MLX_'))}
 env.update(SLOTSTREAM_BENCH_DETAILS='1',SLOTSTREAM_PREFILL_CHUNK='256')
 command=[str(binary),'serve','--model',str(Path.home()/'.slotstream/models/qwen38-flash-next-mlx-4bit'),
  '--port',str(port),'--memory-gb','9','--max-context','36864','--mtp','off','--vision','off']
 result['command']=command
 with (root/'server.log').open('w') as log:
  child=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True)
  result['pid']=child.pid
  wait_ready(child,port)
  result['status']='running';(root/'reproduction-status.json').write_text(json.dumps(result,indent=2)+'\n')
  for words in protocol['words']:
   prompt='Kontextwort '*words+'\nBeantworte nun ausführlich:\nWarum ist der Himmel blau?\n'
   payload={'model':'qwen3.8-flash-next:4bit','prompt':prompt,'think':True,'stream':False,
      'options':{'num_predict':500,'temperature':0}}
   (root/f'request-{words}.json').write_text(json.dumps(payload,ensure_ascii=False)+'\n')
   before=vm_snapshot();started=time.monotonic()
   print(json.dumps({'started_words':words}),flush=True)
   req=urllib.request.Request(f'http://127.0.0.1:{port}/api/generate',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
   with urllib.request.urlopen(req,timeout=2400) as response: data=response.read(8<<20)
   (root/f'response-{words}.json').write_bytes(data)
   parsed=json.loads(data)
   if parsed.get('done') is not True or 'error' in parsed:raise RuntimeError('incomplete model response')
   metrics=parsed['slotstream_benchmark'];stats=metrics['stats']
   observation={'words':words,'before':before,'after':vm_snapshot(),'client_seconds':time.monotonic()-started,
      'prompt_tokens':parsed['prompt_eval_count'],'output_tokens':parsed['eval_count'],
      'decode_seconds':parsed['eval_duration']/1e9,'decode_tps':parsed['eval_count']/(parsed['eval_duration']/1e9)}
   (root/f'observation-{words}.json').write_text(json.dumps(observation,indent=2)+'\n')
   print(json.dumps({k:v for k,v in observation.items() if k not in ['before','after']}),flush=True)
   if stats.get('runtimeError'):raise RuntimeError(stats['runtimeError'])
  result['status']='completed'
except Exception as e:
 result['status']='refused_before_launch' if child is None else 'failed'
 result['error']=f'{type(e).__name__}: {e}'
 print(json.dumps({'status':result['status'],'error':result['error']}),flush=True)
finally:
 if child is not None:
  stop_server(child);result['child_reaped']=child.poll() is not None;result['child_exit']=child.returncode
 result['after']=vm_snapshot()
 (root/'reproduction-status.json').write_text(json.dumps(result,indent=2)+'\n')
