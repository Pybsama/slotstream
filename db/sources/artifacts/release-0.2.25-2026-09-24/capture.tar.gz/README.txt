v0.2.25 release qualification, publication and installed acceptance, 2026-09-24.

source-build-attempt-stopped/  First battery attempt on a local build of 5a54b68.
                               Stopped by hand during the planner gates: its
                               scratch checkout lacked the reference Python
                               environments, so the two current-backend layer
                               gates could not run (checks 4 and 5).
first-candidate-5a54b68/       Full battery on the exact CI candidate of 5a54b68:
                               33 passed, 2 failed (both elastic drills). The
                               drill predicted the governor without the decode
                               lookahead's reserve. Not tagged.
drill-fix-a0cca84/             Both drills on a local build of the fix commit
                               a0cca84 before it was pushed: both pass.
release/                       The released candidate (a0cca84): CI results,
                               verified CI archive identity, full battery on the
                               exact CI bytes (35 passed, 0 failed), tag receipt,
                               release workflow, public release, attestation,
                               public installer and installed serving (31/31).
