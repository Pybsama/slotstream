import Foundation
import AppKit
import CoreText
import ImageIO
import UniformTypeIdentifiers
import SevraRuntime
import Slotstream

let root = URL(fileURLWithPath: "/tmp/sevra-capability-audit-20261014")
func draw(_ text: String, _ context: CGContext, _ box: CGRect, _ size: CGFloat) {
    let attributes = [NSAttributedString.Key(kCTFontAttributeName as String): CTFontCreateWithName("Helvetica" as CFString, size, nil)]
    let setter = CTFramesetterCreateWithAttributedString(NSAttributedString(string: text, attributes: attributes))
    CTFrameDraw(CTFramesetterCreateFrame(setter, CFRange(location: 0, length: 0), CGPath(rect: box, transform: nil), nil), context)
}
func pdf(_ pages: [String]) -> Data {
    let data = NSMutableData(); var box = CGRect(x: 0, y: 0, width: 612, height: 792)
    let context = CGContext(consumer: CGDataConsumer(data: data as CFMutableData)!, mediaBox: &box, nil)!
    for page in pages { context.beginPDFPage(nil); draw(page, context, box.insetBy(dx: 60, dy: 60), 18); context.endPDFPage() }
    context.closePDF(); return data as Data
}
func receiptImage() -> Data {
    let context = CGContext(data: nil, width: 1400, height: 600, bitsPerComponent: 8, bytesPerRow: 0, space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)!
    context.setFillColor(CGColor(gray: 1, alpha: 1)); context.fill(CGRect(x: 0, y: 0, width: 1400, height: 600)); context.setFillColor(CGColor(gray: 0, alpha: 1))
    draw("NARANJO STORE\nReceipt: R-4826\nDate: 2026-10-14\nTotal: USD 47.35", context, CGRect(x: 60, y: 60, width: 1280, height: 480), 54)
    let data = NSMutableData(); let destination = CGImageDestinationCreateWithData(data, UTType.png.identifier as CFString, 1, nil)!
    CGImageDestinationAddImage(destination, context.makeImage()!, nil); CGImageDestinationFinalize(destination); return data as Data
}
let sem = DispatchSemaphore(value: 0)
var result: Int32 = 0
Task {
    defer { sem.signal() }
    var runtime: SevraRuntime?
    do {
        let available = Machine.current().availableGB ?? 0
        guard available >= 12 else { throw SevraError.refused("9 GB test requires 3 GB headroom; available \(available)") }
        let home = root.appendingPathComponent("Home")
        guard !FileManager.default.fileExists(atPath: home.path) else { throw SevraError.refused("Refusing to reuse the audit Home") }
        let sources = root.appendingPathComponent("Sources")
        try FileManager.default.createDirectory(at: sources, withIntermediateDirectories: true)
        try pdf(["Naranjo pilot. Historical draft budget: 6200 dollars. This draft is superseded; consult the approved budget on the following page.", "Approved Naranjo pilot budget: 8450 dollars. Owner: Lina. Approval date: October 14, 2026. The historical draft budget is no longer valid."]).write(to: sources.appendingPathComponent("pilot.pdf"))
        try receiptImage().write(to: sources.appendingPathComponent("receipt.png"))
        let code = "def sum_to(n):\n    \"\"\"Return the sum of integers from 1 through n inclusive.\"\"\"\n    return sum(range(n))\n"
        try Data(code.utf8).write(to: sources.appendingPathComponent("sum_to.py"))
        let csv = "id,status,amount_usd\nA,paid,12.50\nB,paid,38.75\nC,refunded,12.50\nD,paid,9.99\nE,pending,100.00\nF,paid,6.10\n"
        try Data(csv.utf8).write(to: sources.appendingPathComponent("payments.csv"))
        let dbmd = URL(fileURLWithPath: NSHomeDirectory() + "/.dbmd/bin/dbmd")
        let helper = URL(fileURLWithPath: "/Users/carlos/Projects/slotstream/apps/macos/.build/release/sevra-extract")
        runtime = try SevraRuntime(homeURL: home, dbmd: dbmd, inference: LocalInference(memoryGB: 9), helper: helper)
        var rows: [[String: Any]] = []
        func save() throws { try JSONSerialization.data(withJSONObject: ["budget_gb": 9, "thinking": false, "initial_available_gb": available, "runs": rows], options: [.sortedKeys, .prettyPrinted]).write(to: root.appendingPathComponent("results.json"), options: .atomic) }
        func run(_ name: String, _ prompt: String, source: URL? = nil, editable: Bool = false) async throws -> WorkThread {
            let id = try await runtime!.newThread(title: name)
            if let source { let attachment = try await runtime!.attach(threadID: id, folder: source); if editable { try await runtime!.setAccess(threadID: id, attachmentID: attachment.id, access: .change) } }
            let start = Date(); print("START " + name); fflush(stdout)
            let runID = try await runtime!.submit(threadID: id, text: prompt, nonce: "audit-" + name)
            for _ in 0..<900 {
                let snapshot = await runtime!.snapshot()
                if let thread = snapshot.home.threads.first(where: { $0.id == id }), let job = thread.run, job.state.terminal || job.state == .needsYou {
                    let answer = thread.messages.last(where: { $0.role == "assistant" && $0.runID == runID })?.text ?? ""
                    var row: [String: Any] = ["name": name, "prompt": prompt, "state": job.state.rawValue, "status": job.status, "answer": answer, "seconds": Date().timeIntervalSince(start), "trace": job.trace, "excerpts": (job.excerpts ?? []).map { ["path": $0.path, "method": $0.method ?? "", "content": $0.content ?? ""] }, "changes": (job.changes?.changes ?? []).map { ["path": $0.display, "content": $0.content] }]
                    if let metrics = job.metrics { row["metrics"] = try JSONSerialization.jsonObject(with: JSONEncoder().encode(metrics)) }
                    rows.append(row); try save()
                    print("FINISH \(name) \(job.state.rawValue) \(Int(Date().timeIntervalSince(start)))s\n\(answer)"); fflush(stdout)
                    return thread
                }
                try await Task.sleep(nanoseconds: 500_000_000)
            }
            try await runtime!.stop(threadID: id)
            throw SevraError.refused("Audit deadline exceeded for " + name)
        }
        let writing = try await run("writing", "Rewrite this as a polite email under 50 words. Preserve the facts and do not invent any: 'Lina, send the Naranjo pilot report by October 18 at 3 pm. The project code is NARANJO-4826. I need the figures checked.'")
        if let message = writing.messages.first(where: { $0.role == "user" }) { try await runtime!.remember(threadID: writing.id, messageID: message.id, text: "The Naranjo pilot project code is NARANJO-4826. Lina must send its report by October 18 at 3 pm.", admitted: true) }
        _ = try await run("translation", "Translate into natural Colombian Spanish. Return only the translation: 'Please send the revised invoice by Thursday at 3 pm. Do not change the bank details.'")
        _ = try await run("learning", "Explain why a cache can make reading from a slow disk faster, and why it stops helping when nearly every request needs new data. Use an everyday analogy, under 80 words.")
        _ = try await run("decision", "Which plan meets my constraints? I need at least 20 GB storage, must work offline, and can spend at most 12 dollars per month. Plan A: 25 GB, offline, 10 dollars. Plan B: 100 GB, online only, 8 dollars. Plan C: 50 GB, offline, 15 dollars. Give the choice and why each other option fails, under 60 words.")
        _ = try await run("creative", "Write a complete gentle story under 70 words. Begin exactly with 'At dawn,' and include a lost map, a baker, and a surprising but happy ending.")
        _ = try await run("memory", "What is the project code for the Naranjo pilot, and when must Lina send its report? Answer from my saved memory, in one sentence.")
        _ = try await run("web_limit", "Open https://www.python.org/downloads/ and tell me the latest Python release listed right now. If you cannot access the live website, say so plainly rather than guessing a version. Keep it under 40 words.")
        _ = try await run("pdf", "Read this PDF. What is the currently approved Naranjo pilot budget and who owns it? Distinguish the old draft amount. Name the page and cite what you actually read. Keep it under 70 words.", source: sources.appendingPathComponent("pilot.pdf"))
        _ = try await run("ocr_receipt", "Read this receipt image. Return a JSON object with merchant, receipt_id, date, currency, total. Copy the values exactly; no extra text.", source: sources.appendingPathComponent("receipt.png"))
        _ = try await run("csv", "Read payments.csv. Count only rows whose status is paid, sum their amount_usd values, and give the selected IDs. Do not subtract or include refunded or pending rows. Keep it under 60 words and cite the file.", source: sources.appendingPathComponent("payments.csv"))
        let edit = try await run("code_edit", "Read sum_to.py. Fix its off-by-one bug so sum_to(1) is 1 and sum_to(5) is 15. Propose the smallest edit for my review, preserve the function name and docstring, and explain it in one sentence. Do not claim to have executed tests.", source: sources.appendingPathComponent("sum_to.py"), editable: true)
        if let changes = edit.run?.changes, changes.changes.count == 1 {
            let before = try String(contentsOf: sources.appendingPathComponent("sum_to.py"), encoding: .utf8)
            guard before == code else { throw SevraError.refused("Source changed before review") }
            let proposed = changes.changes[0].content
            let expected = code.replacingOccurrences(of: "range(n)", with: "range(n + 1)")
            if proposed == expected || proposed == expected.replacingOccurrences(of: "n + 1", with: "n+1") {
                _ = try await runtime!.approveChanges(threadID: edit.id, changeSetID: changes.id, digest: changes.digest)
                let after = try String(contentsOf: sources.appendingPathComponent("sum_to.py"), encoding: .utf8)
                print("EXACT_REVIEWED_EDIT \(after == proposed)")
            } else { print("EDIT_REQUIRES_MANUAL_REVIEW") }
        }
        try await runtime!.shutdown(); runtime = nil
        print("AUDIT_COMPLETE"); fflush(stdout)
    } catch { try? await runtime?.shutdown(); fputs("AUDIT_FAILED: \(error.localizedDescription)\n", stderr); result = 1 }
}
sem.wait(); exit(result)
