import Foundation
import AppKit
import SevraPresentation
let data = try Data(contentsOf: URL(fileURLWithPath: "/tmp/sevra-capability-audit-20261014/tool-probe/results.json"))
let object = try JSONSerialization.jsonObject(with: data) as! [String: Any]
let rows = object["runs"] as! [[String: Any]]
let answer = rows.first(where: { $0["name"] as? String == "pdf" })!["answer"] as! String
for (name, text) in [("actual_model_answer", answer), ("canonical_control", "The budget is 8450 [S1].")] {
    let r = MarkdownDocumentRenderer().render([DocumentSection(id: "audit", source: text, citationIDs: ["S1"])], style: DocumentStyle())
    var links = 0
    r.text.enumerateAttribute(.link, in: NSRange(location: 0, length: r.text.length)) { value, _, _ in
        if let url = value as? URL, url.scheme == "sevra-citation" { links += 1 }
    }
    print("\(name) clickable_source_links=\(links)")
}
