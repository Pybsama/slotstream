from pathlib import Path
import subprocess,re,json
root=Path('/Users/carlos/Projects/slotstream')
audit=Path('/tmp/sevra-capability-audit-20261014/tool-probe')
bin=(root/'apps/macos/.build/release').resolve()
manifest=(root/'apps/macos/.build/release.yaml').read_text()
start=manifest.find('\n  "C.SevraMacChecks-arm64-apple-macosx-release.module":')
assert start>=0
end=manifest.find('\n  "',start+5)
args=json.loads('['+re.search(r'\n    args: \[(.*?)\]\n',manifest[start:end],re.S).group(1)+']')
xcc=[]
for i,arg in enumerate(args):
    if arg=='-Xcc': xcc.extend([arg,args[i+1]])
objects=(bin/'sevra-mac-checks.product/Objects.LinkFileList').read_text().splitlines()
objects=[x for x in objects if '/SevraMacChecks.build/' not in x]
(audit/'objects.txt').write_text('\n'.join(objects)+'\n')
sdk=subprocess.check_output(['xcrun','--show-sdk-path'],text=True).strip()
cmd=['swiftc','-module-name','SevraCapabilityAudit','-swift-version','5','-I',str(bin/'Modules'),'-target','arm64-apple-macosx14.0','-O','-sdk',sdk,*xcc,'-c',str(audit/'Audit.swift'),'-o',str(audit/'audit.o')]
subprocess.run(cmd,check=True)
cmd=['swiftc','-lc++','-L',str(bin),'-o',str(audit/'audit'),'-emit-executable','-Xlinker','-no_warn_duplicate_libraries','@'+str(audit/'objects.txt'),str(audit/'audit.o'),'-target','arm64-apple-macosx14.0','-framework','Foundation','-framework','AppKit','-framework','Metal','-framework','Accelerate','-framework','Vision','-sdk',sdk]
subprocess.run(cmd,check=True)
(audit/'mlx.metallib').symlink_to(root/'Tools/lib/mlx-0.32.2.metallib')
print('Built temporary harness against current production modules')
