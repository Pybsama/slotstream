#!/bin/zsh
# Decode A/B on one prompt: plain (mtp off), speculative stock, speculative with
# the ship flags. Outputs are compared byte for byte; tok/s from --stats-json.
# Arms are interleaved (plain, stock, ship, plain, stock, ship, ...).
set -u
BIN=~/Projects/slotstream/.build/release/slotstream
S=/private/tmp/claude-502/-Users-carlos-Projects-command-center/feaf9fde-de0a-4056-840e-9d376cff840f/scratchpad
MEM=${MEM:-13}
WIN=${WIN:-32768}
TOK=${TOK:-128}
ROUNDS=${ROUNDS:-2}
PROMPT=${PROMPT:-$S/prompt_16384.txt}
TAG=${TAG:-ab16k}
LOG=$S/${TAG}.log
reclaimable() { vm_stat | awk '/free|purgeable|File-backed/ {gsub(/\./,""); p[$1$2]=$NF} END {printf "%.1f", (p["Pagesfree:"]+p["Pagespurgeable:"]+p["File-backedpages:"])*16384/1073741824}'; }
run_arm() { # name, mtp, env...
  local name=$1 mtp=$2; shift 2
  local R=$(reclaimable)
  echo "== $name round $ROUND $(date +%H:%M:%S) reclaimable $R GB" | tee -a $LOG
  if (( $(echo "$R < $MEM + 3" | bc -l) )); then echo "not enough reclaimable memory; stop" | tee -a $LOG; exit 1; fi
  if pgrep -f "slotstream (serve|run|mtp-|context-check|prefix-check|sweep-check)" >/dev/null; then echo "another model process; stop" | tee -a $LOG; exit 1; fi
  env "$@" $BIN run --memory-gb $MEM --max-context $WIN --mtp $mtp --greedy --max-tokens $TOK \
      --prompt-file $PROMPT --stats-json $S/${TAG}_${name}_$ROUND.json > $S/${TAG}_${name}_$ROUND.txt 2> $S/${TAG}_${name}_$ROUND.err
  echo "exit $? $(date +%H:%M:%S)" | tee -a $LOG
  grep -o '"decode[a-z_]*": *[0-9.]*' $S/${TAG}_${name}_$ROUND.json | tr '\n' ' ' | tee -a $LOG; echo | tee -a $LOG
}
for ROUND in $(seq 1 $ROUNDS); do
  run_arm plain off SLOTSTREAM_AB=1
  run_arm stock on SLOTSTREAM_AB=1
  run_arm ship on SLOTSTREAM_OPT_VERIFY_SPLIT=1 SLOTSTREAM_OPT_ROW_INVARIANT=1
done
echo "== outputs:" | tee -a $LOG
for ROUND in $(seq 1 $ROUNDS); do
  for a in stock ship; do
    if cmp -s $S/${TAG}_plain_$ROUND.txt $S/${TAG}_${a}_$ROUND.txt; then echo "round $ROUND: $a == plain" | tee -a $LOG; else echo "round $ROUND: $a != plain ($(diff $S/${TAG}_plain_$ROUND.txt $S/${TAG}_${a}_$ROUND.txt | grep -c '^[<>]') differing lines)" | tee -a $LOG; fi
  done
done
