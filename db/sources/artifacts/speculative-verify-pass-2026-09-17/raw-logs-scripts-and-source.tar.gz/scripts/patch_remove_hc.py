"""Remove the fused hyper-connection read experiment (kept only in the records)."""
from pathlib import Path
root = Path.home() / "Projects/slotstream"
def edit(path, pairs):
    p = root / path; s = p.read_text()
    for old, new in pairs:
        assert s.count(old) == 1, (path, s.count(old), old[:90])
        s = s.replace(old, new)
    p.write_text(s); print("patched", path)

(root / "Sources/Slotstream/CompiledHyperRead.swift").unlink()
print("removed CompiledHyperRead.swift")

edit("Sources/Slotstream/Layers.swift", [
("""    private(set) var compiledFinishes = 0
    /// Fused pointwise read (`CompiledHyperRead`); nil keeps the eager chain.
    var compiledRead: CompiledHyperRead? = nil
    private(set) var compiledReads = 0
""", """    private(set) var compiledFinishes = 0
"""),
("""        let shape = Array(downOut.shape.dropLast()) + [cfg.hcCount, cfg.hiddenSize]
        if let fused = compiledRead, debugName == nil {
            // Same matmuls, reshapes and rounding boundaries; the pointwise
            // work between them is one kernel per stage instead of two to four.
            compiledReads += 1
            let upOut = up(fused.gate(downOut), minimumRows: minimumProjectionRows)
            let mixed = fused.mix(upOut.reshaped(shape), normed.reshaped(shape))
            guard let injW = inject else { return (mixed, nil) }
            let projected = QLinear.withReferenceRows(normed, minimumRows: minimumProjectionRows) { RowInvariantMatmul.rows($0, injW.transposed()) }
            return (mixed, fused.inject(projected))
        }
        var w = MLXNN.silu(downOut / Float(cfg.hcCount))
        w = sigmoid(up(w, minimumRows: minimumProjectionRows))
        if let n = debugName { Qwen4ExpModel.debugDump(n + "_wup", w) }
        let mixed""", """        var w = MLXNN.silu(downOut / Float(cfg.hcCount))
        w = sigmoid(up(w, minimumRows: minimumProjectionRows))
        if let n = debugName { Qwen4ExpModel.debugDump(n + "_wup", w) }
        let shape = Array(w.shape.dropLast()) + [cfg.hcCount, cfg.hiddenSize]
        let mixed"""),
])

edit("Sources/Slotstream/Model.swift", [
("""    /// Hyper-connection reads that took the fused pointwise path.
    public var compiledHyperReads: Int {
        (attnHC + mlpHC + [mixer]).reduce(0) { $0 + $1.compiledReads }
            + (mtpHead.map { $0.attnHC.compiledReads + $0.mlpHC.compiledReads + $0.mixer.compiledReads } ?? 0)
    }
    private var compiledHyperRead: CompiledHyperRead? = nil
    private var compiledHyperReadTried = false
    private var compiledHyperReadConfigured = false
""", ""),
("""        RowInvariantMatmul.enabled = optimizations.rowInvariantProjection == true
        if optimizations.compiledHyperRead == true, !compiledHyperReadTried {
            compiledHyperReadTried = true
            compiledHyperRead = CompiledHyperRead.prepared(hcCount: cfg.hcCount, lowRank: cfg.hcLowrank, hiddenSize: cfg.hiddenSize)
        }
        let fusedRead = optimizations.compiledHyperRead == true ? compiledHyperRead : nil
        if (fusedRead != nil) != compiledHyperReadConfigured {
            for unit in attnHC + mlpHC + [mixer] { unit.compiledRead = fusedRead }
            compiledHyperReadConfigured = fusedRead != nil
        }
        mtpHead?.attnHC.compiledRead = fusedRead
        mtpHead?.mlpHC.compiledRead = fusedRead
        mtpHead?.mixer.compiledRead = fusedRead
""", """        RowInvariantMatmul.enabled = optimizations.rowInvariantProjection == true
"""),
])

edit("Sources/Slotstream/Optimizations.swift", [
("""    /// Fused pointwise hyper-connection read (experiment; priced by dispatch count).
    public var compiledHyperRead: Bool? = nil
""", ""),
("""        result.compiledHyperRead = try flag("SLOTSTREAM_OPT_COMPILED_HC", fallback: result.compiledHyperRead ?? false) ? true : nil
""", ""),
])

edit("Sources/SlotstreamDiagnostics/Diagnostics+Runtime.swift", [
("""                && reference.rowInvariantProjection == nil && reference.compiledHyperRead == nil)""",
 """                && reference.rowInvariantProjection == nil)"""),
])

edit("Sources/slotstream-cli/MTPCommands.swift", [
("""/// One timed configuration of the verify pass: its multi-row attention and
/// whether the hyper-connection read runs fused (`-hc`).
struct PassVariant: Hashable {
    let attention: MultiRowAttention.Mode
    let fusedRead: Bool
    static let stock = PassVariant(attention: .stock, fusedRead: false)
    var name: String { attention.rawValue + (fusedRead ? "-hc" : "") }
    init(attention: MultiRowAttention.Mode, fusedRead: Bool) {
        self.attention = attention
        self.fusedRead = fusedRead
    }
    init?(name: String) {
        let fused = name.hasSuffix("-hc")
        guard let mode = MultiRowAttention.Mode(rawValue: fused ? String(name.dropLast(3)) : name) else { return nil }
        self.init(attention: mode, fusedRead: fused)
    }
}
""", """/// One timed configuration of the verify pass: its multi-row attention.
struct PassVariant: Hashable {
    let attention: MultiRowAttention.Mode
    static let stock = PassVariant(attention: .stock)
    var name: String { attention.rawValue }
    init(attention: MultiRowAttention.Mode) { self.attention = attention }
    init?(name: String) {
        guard let mode = MultiRowAttention.Mode(rawValue: name) else { return nil }
        self.init(attention: mode)
    }
}
"""),
("""    @Option(help: "Comma-separated pass variants to time (stock, split, and either with -hc for the fused hyper-connection read); stock is always the reference and rebuild timings are skipped")""",
 """    @Option(help: "Comma-separated multi-row attention modes to time per pass (stock,split); stock is always the reference and rebuild timings are skipped")"""),
("""                    throw ModelError("unknown pass variant '\\(name)': use stock, split, stock-hc or split-hc")""",
 """                    throw ModelError("unknown attention mode '\\(name)': use stock or split")"""),
("""                    m.optimizations.compiledHyperRead = mode.fusedRead ? true : nil
""", ""),
("""; fused hyper-connection read \\(m.compiledHyperReads) calls")""", """)")"""),
])
