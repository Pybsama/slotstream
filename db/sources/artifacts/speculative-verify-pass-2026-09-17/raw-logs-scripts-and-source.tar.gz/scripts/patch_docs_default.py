"""Docs and changelog for the split verify attention default and the exact mode.
argv: speedup16 (e.g. 1.079), tps_spec16, tps_split16, exact_tokens (e.g. 128),
extra32 (sentence or empty)."""
import sys
from pathlib import Path
import os
root = Path(os.environ.get("DOCS_ROOT", str(Path.home() / "Projects/slotstream")))
speedup16, spec16, split16, exact_tokens = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]
extra32 = sys.argv[5] if len(sys.argv) > 5 else ""
import textwrap
def reflow(block, width=78):
    """Rewrap '- ' bullets (continuation lines indented two spaces)."""
    out, cur = [], None
    for line in block.splitlines():
        if line.startswith("- "):
            if cur is not None: out.append(cur)
            cur = line[2:].strip()
        elif line.startswith("  ") and cur is not None:
            cur += " " + line.strip()
        else:
            if cur is not None: out.append(cur); cur = None
            out.append(None if not line.strip() else ("RAW", line))
    if cur is not None: out.append(cur)
    lines = []
    for item in out:
        if item is None: lines.append("")
        elif isinstance(item, tuple): lines.append(item[1])
        else:
            lines += textwrap.wrap(item, width=width, initial_indent="- ", subsequent_indent="  ",
                                   break_long_words=False, break_on_hyphens=False)
    return "\n".join(lines) + "\n"
def edit(path, pairs):
    p = root / path; s = p.read_text()
    for old, new in pairs:
        assert s.count(old) == 1, (path, s.count(old), old[:90])
        s = s.replace(old, new)
    p.write_text(s); print("patched", path)

edit("docs/CLI.md", [
("""controls retain their precedence and validation. With the draft head, the
[decode lookahead](#decode-lookahead) is on by default too.
""",
"""controls retain their precedence and validation. With the draft head, the
[decode lookahead](#decode-lookahead) is on by default too, and so is the
[split verify attention](#speculative-decode) from 6,144 tokens of context.
"""),
("""| `SLOTSTREAM_OPT_ROUTER_WEIGHTS` | engine | `0` or `1` overrides the FP32 router weight cache that the decode lookahead turns on. |
""",
"""| `SLOTSTREAM_OPT_ROUTER_WEIGHTS` | engine | `0` or `1` overrides the FP32 router weight cache that the decode lookahead turns on. |
| `SLOTSTREAM_OPT_VERIFY_SPLIT` | engine | `0` runs the speculative verify pass through the dense attention kernel at every context, the previous behavior. The default splits it into two-row vector-kernel calls from 6,144 tokens of context. |
| `SLOTSTREAM_OPT_VERIFY_SPLIT_CONTEXT` | engine | Context, in tokens, from which the verify pass splits (default 6144, the measured crossover on the development Mac); `0` splits at every context. |
| `SLOTSTREAM_OPT_ROW_INVARIANT` | engine | `1` selects the exact mode: the model's small dense matmuls run through one kernel at every row count, and the split verify attention makes one call per row. With `SLOTSTREAM_OPT_VERIFY_SPLIT_CONTEXT=0`, speculative and plain decode give identical output for draft depths up to 4. It changes plain decode's rounding, so it is off by default. |
"""),
("""- `SLOTSTREAM_DRAFT_DEPTH`: draft chain depth, 1–16 (default 2).
""",
reflow("""- The verify pass checks the drafts in one pass of draft depth plus one
  rows. The backend's vector attention kernel takes at most two such rows at
  this model's head layout, so a three-row pass used to fall to the dense
  kernel, which reads every cached key and whose cost grows with the context.
  From 6,144 tokens of context the pass now runs two rows at a time through
  the vector kernel, the kernel plain decode's attention uses. At a
  22 GB target with a 16,356-token prompt, speculative decode measured
  """ + split16 + """ against """ + spec16 + """ tok/s (x""" + speedup16 + """).""" + (" " + extra32 if extra32 else "") + """
  The fetch-free pass is 32% cheaper at 32,740 tokens and 45% at 65,508.
  `SLOTSTREAM_OPT_VERIFY_SPLIT=0` restores the dense pass. Below the
  threshold the dense kernel is faster
  ([measurement](../db/records/measurements/speculative-verify-pass-split-attention-2026-09-17.md)).
- Exact mode: a multi-row pass rounds a little differently from one-row
  passes, so speculative and plain decode can pick different tokens at near
  ties. `SLOTSTREAM_OPT_ROW_INVARIANT=1` with
  `SLOTSTREAM_OPT_VERIFY_SPLIT_CONTEXT=0` removes the difference for draft
  depths up to 4. The small dense matmuls use one kernel at every row count,
  and each verify row attends in its own call over the keys plain decode
  reads, so the backend picks the same attention kernel. Every row of a
  verify pass then equals plain decode in the same mode, and a speculative
  run's output equals a plain run's. The mode changes plain decode's rounding
  too and costs speed, so it is off by default; `mtp-rowcheck` gates it.
- `SLOTSTREAM_DRAFT_DEPTH`: draft chain depth, 1–16 (default 2).
""")),
])

p = root / "CHANGELOG.md"; s = p.read_text()
anchor = "## 0.2.20 - 2026-09-16\n"
assert s.count(anchor) == 1
unreleased = "## Unreleased\n" if "## Unreleased" not in s else None
entry = """- Faster speculative decode on long prompts. The three-row verify pass of
  draft depth 2 no longer falls to the dense attention kernel, whose cost grows
  with the context: from 6,144 tokens it runs two rows at a time through the
  vector kernel, the kernel plain decode's attention uses. At a 22 GB
  target with a 16,356-token prompt, speculative decode measured """ + split16 + """ against
  """ + spec16 + """ tok/s (x""" + speedup16 + """).""" + (" " + extra32 if extra32 else "") + """ The fetch-free verify pass is 32%
  cheaper at 32,740 tokens and 45% at 65,508. `SLOTSTREAM_OPT_VERIFY_SPLIT=0`
  restores the previous pass.
- Exact mode, off by default: `SLOTSTREAM_OPT_ROW_INVARIANT=1` with
  `SLOTSTREAM_OPT_VERIFY_SPLIT_CONTEXT=0` makes a speculative run's output
  identical to a plain run's in the same mode for draft depths up to 4
  (""" + exact_tokens + """ of """ + exact_tokens + """ tokens in the 16k comparison). The model's small dense
  matmuls run through one kernel at every row count, which changes plain
  decode's rounding as well, and each verify row attends in its own call over
  the keys plain decode reads, so the backend picks the same attention
  kernel.
- New gate `mtp-rowcheck` in `Tools/verify.sh`: in exact mode, every row of a
  two-row and a three-row verify pass, and the state a three-row pass leaves,
  must equal the one-row passes bit for bit, on a prompt whose positions
  cross 1,024 keys, where the attention kernel changes, and one above the
  indexer budget. The weights-free `verify-pass-rows` catalogue check holds
  the kernels in CI, at every key count where the backend changes attention
  kernels. `mtp-bench --arms` compares plain, shipped, split and exact
  decode on one warm engine; `mtp-passcost` gains `--prompt-file`,
  `--max-context` and `--attention-modes` (stock, split, exact).

"""
entry = reflow(entry.rstrip("\n")) + "\n"
if unreleased:
    s = s.replace(anchor, unreleased + "\n" + entry + anchor)
else:
    i = s.index("## Unreleased\n") + len("## Unreleased\n")
    s = s[:i] + "\n" + entry + s[i:]
p.write_text(s); print("patched CHANGELOG.md")

edit("llms.txt", [
("""`mtp-parity`, `mtp-accept`, `mtp-check`. The battery""",
 """`mtp-parity`, `mtp-accept`, `mtp-check`, `mtp-rowcheck`. The battery"""),
("""`SLOTSTREAM_DECODE_BARRIER_LAYERS`, `SLOTSTREAM_DRAFT_DEPTH`; installer:""",
 """`SLOTSTREAM_DECODE_BARRIER_LAYERS`, `SLOTSTREAM_DRAFT_DEPTH`, `SLOTSTREAM_OPT_VERIFY_SPLIT`, `SLOTSTREAM_OPT_VERIFY_SPLIT_CONTEXT`, `SLOTSTREAM_OPT_ROW_INVARIANT`; installer:"""),
("""they are not new two-draft measurements. See db/records/decisions/draft-head-auto-floor-76-per-layer.md,""",
 """they are not new two-draft measurements. The three-row verify pass runs two rows at a time through the vector attention kernel from 6,144 tokens of context instead of the dense kernel, whose cost grows with the context: """ + split16 + """ against """ + spec16 + """ tok/s (x""" + speedup16 + """) at a 22 GB target with a 16,356-token prompt, and a fetch-free pass 32% cheaper at 32,740 tokens and 45% at 65,508; `SLOTSTREAM_OPT_VERIFY_SPLIT=0` restores the dense pass. `SLOTSTREAM_OPT_ROW_INVARIANT=1` with `SLOTSTREAM_OPT_VERIFY_SPLIT_CONTEXT=0` is an exact mode, off by default, in which a speculative run's output equals a plain run's for draft depths up to 4; `mtp-rowcheck` gates it. See db/records/decisions/verify-pass-split-attention-default.md, db/records/decisions/draft-head-auto-floor-76-per-layer.md,"""),
])
