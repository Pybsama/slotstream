#!/bin/zsh
source /private/tmp/claude-502/-Users-carlos-Projects-command-center/feaf9fde-de0a-4056-840e-9d376cff840f/scratchpad/qsteps2.sh
BIN=~/Projects/slotstream/.build/release/slotstream
echo "#### seq7 start $(date +%H:%M:%S); binary $(shasum -a 256 $BIN | cut -c1-16)" | tee -a $LOG
step "rung 8192 row-invariant" 13 env SLOTSTREAM_OPT_ROW_INVARIANT=1 $BIN mtp-passcost --memory-gb 13 --max-context 16384 \
  --prompt-file $S/prompt_8192.txt --positions 4 --max-batch 3 --max-tokens 48 --attention-modes stock,split
step "fused read A/B 4096" 13 $BIN mtp-passcost --memory-gb 13 --max-context 8192 \
  --prompt-file $S/prompt_4096.txt --positions 8 --max-batch 3 --max-tokens 64 --attention-modes stock,stock-hc,split,split-hc
step "fused read A/B 16384" 13 $BIN mtp-passcost --memory-gb 13 --max-context 32768 \
  --prompt-file $S/prompt_16384.txt --positions 8 --max-batch 3 --max-tokens 64 --attention-modes stock,stock-hc,split,split-hc
step "gate mtp-rowcheck two legs 10 GB" 10 $BIN mtp-rowcheck --memory-gb 10
R=$(reclaimable); MEM=18; MTP=on
if (( $(echo "$R >= 25" | bc -l) )); then MEM=22; MTP=auto; elif (( $(echo "$R >= 23" | bc -l) )); then MEM=20; MTP=on; fi
echo "#### decode A/B target $MEM GB (--mtp $MTP), reclaimable $R GB" | tee -a $LOG
step "decode A/B 16k at $MEM GB" $MEM $BIN mtp-bench --memory-gb $MEM --mtp $MTP --max-context 32768 \
  --prompt-file $S/prompt_16384.txt --max-tokens 128 --pairs 2 --arms plain,spec,split,exact,plain-exact
for arm in off on off on; do
  if [ $arm = on ]; then E=SLOTSTREAM_OPT_ROW_INVARIANT=1; else E=SLOTSTREAM_OPT_ROW_INVARIANT=0; fi
  step "rung 4096 row-invariant $arm" 13 env $E $BIN mtp-passcost --memory-gb 13 --max-context 8192 \
    --prompt-file $S/prompt_4096.txt --positions 6 --max-batch 3 --max-tokens 64 --attention-modes stock,split
done
step "python dense matmul row invariance" 2 zsh -c "cd ~/Projects/slotstream && for f in matmul_rows_shapes2 matmul_rows_shapes3 matmul_rows_shapes4; do echo \"-- \$f\"; .venv31/bin/python $S/\$f.py; done"
step "catalogue t0 t1" 2 ~/Projects/slotstream/.build/release/slotstream-checks --tier t0 --tier t1
echo "#### seq7 done $(date +%H:%M:%S)" | tee -a $LOG
