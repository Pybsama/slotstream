"""Deterministic varied prose of about N tokens for long-context timing runs.
Usage: make_prompt.py N out.txt   (uses the model's tokenizer to cut to N tokens)"""
import random, sys
from tokenizers import Tokenizer
n = int(sys.argv[1]); out = sys.argv[2]
tok = Tokenizer.from_file("/Users/carlos/.slotstream/models/qwen38-flash-next-mlx-4bit/tokenizer.json")
rng = random.Random(20260916 + n)
subjects = "the river a committee our neighbour the old bridge a quiet engineer the harbour town the archive a small orchard the night train a borrowed map the lighthouse keeper a stubborn mule the second violin a rusted gate the market square a patient teacher the last ferry a paper kite the glass factory".split(" the ")
subjects = [("the " + s).strip() if not s.startswith(("a ", "our ")) else s for s in subjects]
verbs = ["remembered", "measured", "rebuilt", "described", "ignored", "protected", "sketched", "questioned", "carried", "counted", "repaired", "followed", "traded", "recorded", "weighed", "delayed", "mapped", "welcomed", "tested", "returned"]
objects = ["the winter schedule", "a broken compass", "three copper coins", "the flooded cellar", "an unfinished letter", "the eastern road", "a chorus of gulls", "the tax ledger", "a jar of honey", "the morning fog", "twelve wooden crates", "the missing key", "a faded photograph", "the tide tables", "an argument about salt", "the northern fields", "a borrowed lantern", "the census of 1911", "a promise made in spring", "the sound of the mill"]
tails = ["before the rain came.", "without telling anyone.", "while the town slept.", "for reasons nobody wrote down.", "until the bell rang twice.", "as the ice began to move.", "in the year the well ran dry.", "and then changed its mind.", "because the ledger said so.", "after the second harvest.", "long after the debt was paid.", "though the map was wrong."]
def sentence():
    s = f"{rng.choice(subjects)} {rng.choice(verbs)} {rng.choice(objects)} {rng.choice(tails)}"
    return s[0].upper() + s[1:]
paras, count = [], 0
while count < n * 6:  # chars, generous
    p = " ".join(sentence() for _ in range(rng.randint(4, 9)))
    paras.append(p); count += len(p) + 2
text = "\n\n".join(paras)
ids = tok.encode(text, add_special_tokens=False).ids
cut = ids[: max(1, n - 40)]  # leave room for the chat template
final = tok.decode(cut)
open(out, "w").write(final)
print(f"requested {n}: wrote {len(tok.encode(final, add_special_tokens=False).ids)} tokens, {len(final)} chars to {out}")
