"""Create the claim records for the verify-pass change with dbmd write.
argv: split16 spec16 speedup16 exact_tokens [needle32 surfaces32 title32]"""
import subprocess, sys, tempfile, os
split16, spec16, speedup16, exact_tokens = sys.argv[1:5]
extra = sys.argv[5:8] if len(sys.argv) >= 8 else None
M = "[[records/measurements/speculative-verify-pass-split-attention-2026-09-17]]"
surfaces = "docs/CLI.md, CHANGELOG.md, llms.txt"
claims = [
    ("verify-split-from-6144-tokens",
     "The speculative verify pass splits its attention from 6,144 tokens of context by default",
     "from 6,144 tokens", surfaces, "measured",
     "slotstream-checks --tier t0 --filter runtime-check",
     "The threshold sits above the measured crossover near 5,700 tokens at k=3 on the development Mac (split minus dense +6.1 to +6.8 ms at 4,068 tokens, -1.7 at 6,116, -3.9 at 8,183); the T0 runtime check pins the constant and the deployment default."),
    ("verify-split-16k-decode-%s-tok-s" % split16.replace(".", "-"),
     "Speculative decode with the split verify attention measured %s against %s tok/s (x%s) at a 22 GB target with a 16,356-token prompt" % (split16, spec16, speedup16),
     "%s against %s tok/s (x%s)" % (split16, spec16, speedup16), surfaces, "measured", "none",
     "Medians of two interleaved rounds on one warm engine, 128 greedy tokens, dense verify pass against the split; the arms decode slightly different texts, so the ratio includes their acceptance difference."),
    ("verify-split-fetch-free-pass-32-and-45-percent",
     "The fetch-free three-row verify pass is 32% cheaper split at 32,740 tokens and 45% at 65,508",
     "32% cheaper at 32,740 tokens and 45% at 65,508", surfaces, "measured", "none",
     "Warm, median of four positions: 123.6 against 84.3 ms at 32,740 tokens (17 GB) and 180.6 against 99.2 ms at 65,508 (19 GB), dense against split."),
    ("exact-mode-%s-of-%s-tokens" % (exact_tokens, exact_tokens),
     "In the exact mode a speculative run matched a plain run on %s of %s tokens in the 16k comparison" % (exact_tokens, exact_tokens),
     "%s of %s tokens in the 16k comparison" % (exact_tokens, exact_tokens), "CHANGELOG.md", "measured",
     "Tools/verify.sh (mtp-rowcheck) and slotstream-checks verify-pass-rows",
     "The exact speculative arm and the exact plain arm of the 16k decode comparison produced identical greedy output; the gates hold the row-level equality that implies it."),
    ("exact-mode-draft-depths-up-to-4",
     "The exact mode's equality holds for draft depths up to 4",
     "draft depths up to 4", "docs/CLI.md, CHANGELOG.md, llms.txt", "derived",
     "slotstream-checks verify-pass-rows (quantized products of 1 to 5 rows)",
     "Derived from the pinned backend's quantized batch-limit table, whose smallest limit is 6 rows (M1 and M2 below Ultra, outputs wider than 4,096): below the limit each row is computed alone. The catalogue check holds 1 to 5 row products on the machine it runs on."),
]
if extra:
    needle32, surfaces32, title32 = extra
    claims.append(("verify-split-32k-decode", title32, needle32, surfaces32, "measured", "none",
                   "Medians of two interleaved rounds on one warm engine at a 22 GB target, 32,740-token prompt, dense verify pass against the split."))
for slug, title, needle, surf, basis, gate, body in claims:
    with tempfile.NamedTemporaryFile("w", suffix=".md", delete=False) as f:
        f.write(body + "\n"); path = f.name
    cmd = ["dbmd", "write", "records/claims/%s.md" % slug, "--type", "claim", "--summary", title,
           "--fm", "title=" + title, "--fm", "needle=" + needle, "--fm", "surfaces=" + surf,
           "--fm", "basis=" + basis, "--fm", "status=current", "--fm", "supported_by=" + M,
           "--fm", "gate=" + gate, "--body-file", path]
    print(" ".join(cmd[:4]))
    r = subprocess.run(cmd, cwd=os.path.expanduser("~/Projects/slotstream/db"), capture_output=True, text=True)
    print(r.stdout.strip(), r.stderr.strip())
    os.unlink(path)
    if r.returncode != 0:
        sys.exit(r.returncode)
