#!/bin/zsh
S=/private/tmp/claude-502/-Users-carlos-Projects-command-center/feaf9fde-de0a-4056-840e-9d376cff840f/scratchpad
export LOG=$S/rungs2.log MEM=13 POS=4 MODES=stock,split
echo "#### phase B resumed $(date +%H:%M:%S) (8k and 12k prompts carry an appended summary request so the plain continuation is long enough)" >> $LOG
SLOTSTREAM_OPT_ROW_INVARIANT=1 RUNGS="8192 12288 16384" $S/run_rungs2.sh || { echo "#### phase B failed" >> $LOG; exit 1; }
echo "#### phase C $(date +%H:%M:%S)" >> $LOG
SLOTSTREAM_OPT_ROW_INVARIANT=1 SLOTSTREAM_OPT_COMPILED_HC=1 RUNGS="4096 16384" $S/run_rungs2.sh || { echo "#### phase C failed" >> $LOG; exit 1; }
echo "#### all phases done $(date +%H:%M:%S)" >> $LOG
