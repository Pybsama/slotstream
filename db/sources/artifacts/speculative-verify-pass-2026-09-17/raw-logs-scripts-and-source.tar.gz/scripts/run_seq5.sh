#!/bin/zsh
# Runs after seq4: the two-leg gate at the battery's target, then the decode
# comparison on one warm engine at the largest target memory allows (22, 20 or 18 GB).
LOG=/private/tmp/claude-502/-Users-carlos-Projects-command-center/feaf9fde-de0a-4056-840e-9d376cff840f/scratchpad/seq5.log
source /private/tmp/claude-502/-Users-carlos-Projects-command-center/feaf9fde-de0a-4056-840e-9d376cff840f/scratchpad/qsteps.sh
BIN=~/Projects/slotstream/.build/release/slotstream
while pgrep -f run_seq4.sh >/dev/null; do sleep 30; done
echo "#### seq5 start $(date +%H:%M:%S); binary $(shasum -a 256 $BIN | cut -c1-16)" | tee -a $LOG
step "gate mtp-rowcheck two legs 10 GB" 10 $BIN mtp-rowcheck --memory-gb 10 || exit 1
wait_quiet
R=$(reclaimable)
MEM=18; MTP=on
if (( $(echo "$R >= 25" | bc -l) )); then MEM=22; MTP=auto; elif (( $(echo "$R >= 23" | bc -l) )); then MEM=20; MTP=on; fi
echo "#### decode A/B target $MEM GB (--mtp $MTP), reclaimable $R GB" | tee -a $LOG
step "decode A/B 16k at $MEM GB" $MEM $BIN mtp-bench --memory-gb $MEM --mtp $MTP --max-context 32768 \
  --prompt-file $S/prompt_16384.txt --max-tokens 128 --pairs 2 --arms plain,spec,split,exact,plain-exact || exit 1
echo "#### seq5 done $(date +%H:%M:%S)" | tee -a $LOG
