"""Write run records with dbmd write. argv: names of entries to write (or 'all' for the first batch)."""
import os, subprocess, sys
S = os.path.dirname(os.path.abspath(__file__))
R = os.path.join(S, "records")
M = "[[records/machines/macbook-pro-m5-pro-48gb]]"
F9 = "f9e23f6cf3e31b29a1c83a9aec5bc64a8b0cf1543e1eb0ca9cdf3ce86536d9a8"
A7 = "7a581747832566258100703d14d9d90c8275269efefc1e93a36ca6e6cd02121e"
runs = {
 "passcost": dict(path="sources/runs/2026-09-16-verify-attention-modes-passcost.md",
   title="Verify pass cost by attention mode from 4k to 65k tokens: dense, split and gathered keys",
   tool="slotstream mtp-passcost with the multi-row attention probes (development builds)",
   command="slotstream mtp-passcost --memory-gb 15|17|19 --max-context 32768|65536|70000 --prompt-file prompt_N.txt --positions 4 --max-batch 3 --max-tokens 48 --attention-modes stock,split,gather; later rungs with the row-0, cold-versus-warm and row-exact readings",
   binary="development builds of 4d66b10 plus the verify-pass diff (diff sha256 prefix 66d14635779d4696): 16:22 build for the length rungs; 21:28, 22:40, 22:48 and 22:52 builds (d991d71911ac242c) for the later rungs; earlier identities not captured",
   captured="2026-09-16", discarded="false", body="run-verify-attention-modes-passcost.md"),
 "microbench": dict(path="sources/runs/2026-09-16-small-row-matmul-and-attention-microbench.md",
   title="Small-row quantized matmul and multi-row attention microbenchmarks under Python MLX",
   tool="Python mlx 0.31.1 (.venv31) scripts qmv_rows_bench.py and verify_pass_bench.py, synthetic weights",
   command=".venv31/bin/python qmv_rows_bench.py; .venv31/bin/python verify_pass_bench.py",
   binary="Python mlx 0.31.1 wheel; no slotstream binary",
   captured="2026-09-16", discarded="false", body="run-small-m-matmul-and-attention-microbench.md"),
 "census": dict(path="sources/runs/2026-09-16-verify-pass-dispatch-census.md",
   title="Metal dispatch census of plain and speculative decode",
   tool="slotstream run with an injected Metal counting library (census.m)",
   command="slotstream run --memory-gb 15 --greedy --max-tokens 1|129 [--mtp on] --prompt \"Explain how a transistor works, in about 300 words.\" with the census library injected",
   binary="d991d71911ac242c (22:52 development build; the first pair ran the 21:28 build with the same compute paths)",
   captured="2026-09-16", discarded="false", body="run-dispatch-census.md"),
 "crossover": dict(path="sources/runs/2026-09-17-verify-pass-split-crossover-rungs.md",
   title="Split verify attention crossover rungs at 13 GB, 4k to 16k tokens",
   tool="slotstream mtp-passcost --attention-modes stock,split under a quiet-machine runner",
   command="slotstream mtp-passcost --memory-gb 13 --max-context 8192|16384|32768 --prompt-file prompt_N.txt --positions 4 --max-batch 3 --max-tokens 48 --attention-modes stock,split, with SLOTSTREAM_OPT_ROW_INVARIANT and SLOTSTREAM_OPT_COMPILED_HC per phase",
   binary="60820d93c83f871f (00:06 development build) for the night rungs; " + F9 + " for the 8,192-token rung",
   captured="2026-09-17", discarded="false", body="run-verify-pass-crossover-rungs-13gb.md"),
 "gate": dict(path="sources/runs/2026-09-17-mtp-rowcheck-gate.md",
   title="Row-equality gate mtp-rowcheck, four versions at 10 GB",
   tool="slotstream mtp-rowcheck",
   command="slotstream mtp-rowcheck --memory-gb 10",
   binary="60820d93c83f871f, 1bf06185fb7d721b and " + F9 + " for versions 1 to 3; " + A7 + " for version 4",
   captured="2026-09-17", discarded="false", body="run-mtp-rowcheck-gate.md"),
 "fused": dict(path="sources/runs/2026-09-17-fused-hyper-connection-read.md",
   title="Fused hyper-connection read against the eager read at 16k and 4k tokens",
   tool="slotstream mtp-passcost --attention-modes stock,stock-hc,split,split-hc",
   command="slotstream mtp-passcost --memory-gb 13 --max-context 32768|8192 --prompt-file prompt_16384.txt|prompt_4096b.txt --positions 8 --max-batch 3 --attention-modes stock,stock-hc,split,split-hc",
   binary=F9, captured="2026-09-17", discarded="false", body="run-fused-hyper-connection-read.md"),
 "decode16first": dict(path="sources/runs/2026-09-17-verify-pass-decode-16k-first-build.md",
   title="Decode comparison at 16k on the first build: plain, dense, split and exact",
   tool="slotstream mtp-bench --arms",
   command="slotstream mtp-bench --memory-gb 22 --mtp auto --max-context 32768 --prompt-file prompt_16384.txt --max-tokens 128 --pairs 2 --arms plain,spec,split,exact,plain-exact",
   binary=F9, captured="2026-09-17", discarded="false", body="run-verify-pass-decode-ab-16k-22gb.md"),
 "decode32discarded": dict(path="sources/runs/2026-09-17-verify-pass-decode-32k-loaded-machine.md",
   title="Decode comparison at 32k on a loaded machine, discarded for timing",
   tool="slotstream mtp-bench --arms",
   command="slotstream mtp-bench --memory-gb 22 --max-context 33024 --prompt-file prompt_32768.txt --max-tokens 128 --pairs 2 --arms spec,split",
   binary=F9, captured="2026-09-17", discarded="true", body="run-verify-pass-decode-ab-32k-discarded.md"),
 "rowscheck": dict(path="sources/runs/2026-09-17-verify-pass-rows-check.md",
   title="Verify-pass kernel self-check verify-pass-rows on the first and final builds",
   tool="slotstream-checks (T1) verify-pass-rows",
   command=".build/release/slotstream-checks --tier t1 --filter verify-pass-rows --json",
   binary=F9 + " (first form); " + A7 + " and the final build 8d86f10f5b6696d4 (final form, identical results)",
   captured="2026-09-17", discarded="false", body="run-verify-pass-rows-check.md"),
}
D8 = "8d86f10f5b6696d444769308c07d678447b80a531476b48fb70a50988102dbc6"
runs.update({
 "decodefinal": dict(path="sources/runs/2026-09-17-verify-pass-decode-final-build.md",
   title="Decode comparisons at 16k and 32k on the final build: dense, split and exact",
   tool="slotstream mtp-bench --arms under a quiet-machine runner",
   command="SLOTSTREAM_OPT_VERIFY_SPLIT=0 slotstream mtp-bench --memory-gb 22 [--mtp auto] --max-context 32768|33024 --prompt-file prompt_16384.txt|prompt_32768.txt --max-tokens 128 --pairs 2 --arms plain,spec,split,exact,plain-exact|spec,split",
   binary=A7 + " (16k); " + D8 + " (32k)",
   captured="2026-09-17", discarded="false", body="run-verify-pass-decode-final.md"),
 "pricing": dict(path="sources/runs/2026-09-17-verify-pass-mode-pricing.md",
   title="Fetch-free verify pass cost of the stock, split and exact modes at 4k and 16k tokens",
   tool="slotstream mtp-passcost --attention-modes stock,split,exact under a quiet-machine runner",
   command="slotstream mtp-passcost --memory-gb 13 --max-context 8192|32768 --prompt-file prompt_4096b.txt|prompt_16384b.txt --positions 6 --max-batch 3 --max-tokens 64 --attention-modes stock,split,exact",
   binary=D8, captured="2026-09-17", discarded="false", body="run-verify-pass-mode-pricing.md"),
 "python": dict(path="sources/runs/2026-09-17-dense-matmul-row-invariance-python.md",
   title="Dense matmul row invariance under Python MLX: stock, gathered and one-row kernels",
   tool="Python mlx 0.31.1 (.venv31) scripts matmul_rows_shapes2.py, matmul_rows_shapes3.py and matmul_rows_shapes4.py",
   command=".venv31/bin/python matmul_rows_shapes2.py; .venv31/bin/python matmul_rows_shapes3.py; .venv31/bin/python matmul_rows_shapes4.py",
   binary="Python mlx 0.31.1 wheel; no slotstream binary",
   captured="2026-09-17", discarded="false", body="run-dense-matmul-row-invariance-python.md"),
 "checks": dict(path="sources/runs/2026-09-17-verify-pass-checks-and-battery.md",
   title="Check catalogue, static gates and verify battery on the final verify-pass build",
   tool="slotstream-checks, Tools/static_gates.sh and Tools/verify.sh",
   command=".build/release/slotstream-checks --tier t0 --tier t1; Tools/static_gates.sh; Tools/verify.sh",
   binary=D8, captured="2026-09-17", discarded="false", body="run-verify-pass-checks-and-battery.md"),
})
names = list(runs)[:9] if sys.argv[1:] == ["all"] else sys.argv[1:]
for n in names:
    r = runs[n]
    cmd = ["dbmd", "write", r["path"], "--type", "run", "--summary", r["title"],
           "--fm", "title=" + r["title"], "--fm", "tool=" + r["tool"], "--fm", "command=" + r["command"],
           "--fm", "binary=" + r["binary"], "--fm", "machines=" + M, "--fm", "captured_at=" + r["captured"],
           "--fm", "discarded=" + r["discarded"], "--body-file", os.path.join(R, r["body"])]
    db = os.path.expanduser("~/Projects/slotstream/db")
    p = subprocess.run(cmd, cwd=db, capture_output=True, text=True)
    print(n, p.returncode, p.stdout.strip()[:200], p.stderr.strip()[:300])
    if p.returncode: sys.exit(1)
    got = p.stdout.strip().split()[-1]
    want = "sources/runs/2026/09/" + os.path.basename(r["path"])
    if got != want:
        q = subprocess.run(["dbmd", "rename", got, want], cwd=db, capture_output=True, text=True)
        print("  moved:", q.returncode, q.stdout.strip()[:160], q.stderr.strip()[:200])
        if q.returncode: sys.exit(1)
        stray = os.path.join(db, "records", "run")
        if os.path.isdir(stray) and not any(f for _, _, fs in os.walk(stray) for f in fs if not f.startswith(".")):
            import shutil; shutil.rmtree(stray)
