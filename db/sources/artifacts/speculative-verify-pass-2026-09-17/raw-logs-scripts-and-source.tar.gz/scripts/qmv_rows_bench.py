"""Does a 3-row verify pass re-read every dense 4-bit projection three times?

The pinned backend (mlx-swift 0.31.6, backend/metal/quantized.cpp) routes
quantized_matmul with M < get_qmv_batch_limit(K, N) rows to `qmv`, whose grid
is (M, N/bn, B): one threadgroup per (row, column block), so each row reloads
the weight block. On a G17-class GPU with K=2560 and N<=4096 the limit is 12,
so M in 1..11 pays M x weight traffic; M >= 12 takes the tiled `qmm` path that
reads weights once. This script measures that directly on synthetic weights of
Flash-Next's dense shapes. Run it only on a quiet GPU (no slotstream process):

    ~/Projects/slotstream/.venv31/bin/python qmv_rows_bench.py

Memory: well under 1 GB. No model is loaded.
"""
import time

import mlx.core as mx

GROUP, BITS = 64, 4
SHAPES = {
    "qsa q (2560->6144)": (2560, 6144),
    "qsa kv (2560->512)": (2560, 512),
    "gdn in_proj-like (2560->16384)": (2560, 16384),
    "hyper/mixer (2560->2560)": (2560, 2560),
    "lm_head (2560->248320)": (2560, 248320),
}
ROWS = [1, 2, 3, 4, 6, 8, 11, 12, 16, 32]
REPS = 30


def bench(w, s, b, x):
    # warmup
    for _ in range(5):
        mx.eval(mx.quantized_matmul(x, w, s, b, transpose=True, group_size=GROUP, bits=BITS))
    mx.synchronize()
    t0 = time.perf_counter()
    for _ in range(REPS):
        y = mx.quantized_matmul(x, w, s, b, transpose=True, group_size=GROUP, bits=BITS)
        mx.eval(y)
    mx.synchronize()
    return (time.perf_counter() - t0) / REPS


def main():
    print(f"device {mx.metal.device_info()['architecture']}  mlx {mx.__version__}")
    print("shape | M | ms/call | weight bytes | GB/s if read once | GB/s if read M times")
    for name, (K, N) in SHAPES.items():
        wf = mx.random.normal((N, K)).astype(mx.bfloat16)
        w, s, b = mx.quantize(wf, group_size=GROUP, bits=BITS)
        mx.eval(w, s, b)
        wbytes = w.nbytes + s.nbytes + b.nbytes
        base = None
        for M in ROWS:
            x = mx.random.normal((M, K)).astype(mx.bfloat16)
            mx.eval(x)
            dt = bench(w, s, b, x)
            if base is None:
                base = dt
            once = wbytes / dt / 1e9
            mtimes = wbytes * M / dt / 1e9
            print(f"{name:32s} | {M:3d} | {dt*1e3:8.3f} | {wbytes/1e6:8.1f} MB | {once:7.1f} | {mtimes:7.1f}   (x{dt/base:4.2f} vs M=1)")
        print()
    print("Reading: if ms/call grows ~linearly with M up to 11 and drops at 12,")
    print("the verify pass's dense projections re-read their weights per row, and")
    print("either padding verify rows to the qmm threshold or a weight-reusing")
    print("small-M kernel (MTPLX's verify_qmv idea) is the fix. Compare the M=3")
    print("row against the M=12 row: that ratio is the available win per projection.")


if __name__ == "__main__":
    main()
