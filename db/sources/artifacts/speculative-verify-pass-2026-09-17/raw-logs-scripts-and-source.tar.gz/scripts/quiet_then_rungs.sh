#!/bin/zsh
# Wait until no build/model process runs and the 1-minute load average stays
# under 2.5 for 90 seconds, then run the rung sequence. Gives up after 3 hours.
S=/private/tmp/claude-502/-Users-carlos-Projects-command-center/feaf9fde-de0a-4056-840e-9d376cff840f/scratchpad
LOG=$S/rungs2.log
quiet=0; waited=0
while (( quiet < 3 )); do
  load=$(sysctl -n vm.loadavg | awk '{print $2}')
  if pgrep -f "swift-build|swift-frontend|clang|xcodebuild|slotstream (serve|run|mtp-|context-check|prefix-check|sweep-check)" >/dev/null || (( $(echo "$load >= 2.5" | bc -l) )); then
    quiet=0
  else
    quiet=$((quiet+1))
  fi
  sleep 30; waited=$((waited+30))
  if (( waited >= 10800 )); then echo "#### gave up waiting for a quiet machine after 3 h (load $load)" >> $LOG; exit 1; fi
done
echo "#### machine quiet (load $load) after ${waited}s; starting rungs $(date +%H:%M:%S)" >> $LOG
exec ${1:-$S/run_all_rungs.sh}
