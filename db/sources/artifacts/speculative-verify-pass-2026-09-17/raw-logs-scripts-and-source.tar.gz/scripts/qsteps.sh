#!/bin/zsh
# Quiet-gated steps. Busy means: a build, any process holding the Slotstream
# model lock, a Sevra check run, or a 1-minute load at or above 3.0. Each step
# waits for three consecutive quiet 30 s checks (gives up after 3 h), refuses
# without target + 3 GB reclaimable, and logs any build that starts mid-step.
set -u
set -o pipefail
S=/private/tmp/claude-502/-Users-carlos-Projects-command-center/feaf9fde-de0a-4056-840e-9d376cff840f/scratchpad
LOG=${LOG:-$S/seq4.log}
LOCK=/tmp/slotstream-model-$(id -u).lock
reclaimable() { vm_stat | awk '/free|purgeable|File-backed/ {gsub(/\./,""); p[$1$2]=$NF} END {printf "%.1f", (p["Pagesfree:"]+p["Pagespurgeable:"]+p["File-backedpages:"])*16384/1073741824}'; }
busy() {
  pgrep -f "swift-build|swift-frontend|clang|xcodebuild|sevra-mac-checks|slotstream (serve|run|mtp-|context-check|prefix-check|sweep-check|optimization)" >/dev/null && return 0
  [ -n "$(lsof -t $LOCK 2>/dev/null)" ] && return 0
  return 1
}
wait_quiet() {
  local quiet=0 waited=0 load
  while (( quiet < 3 )); do
    load=$(sysctl -n vm.loadavg | awk '{print $2}')
    if busy || (( $(echo "$load >= 3.0" | bc -l) )); then quiet=0; else quiet=$((quiet+1)); fi
    sleep 30; waited=$((waited+30))
    if (( waited >= 10800 )); then echo "#### no quiet machine after 3 h (load $load); stop" | tee -a $LOG; exit 1; fi
  done
  echo "#### quiet (load $load) after ${waited}s at $(date +%H:%M:%S)" | tee -a $LOG
}
step() { # label, target GB, command...
  local label=$1 mem=$2; shift 2
  wait_quiet
  local R=$(reclaimable)
  echo "== $label $(date +%H:%M:%S) reclaimable $R GB target $mem GB load $(sysctl -n vm.loadavg) $(sysctl -n vm.swapusage)" | tee -a $LOG
  if (( $(echo "$R < $mem + 3" | bc -l) )); then echo "not enough reclaimable memory; stop" | tee -a $LOG; exit 1; fi
  ( while true; do
      local who=$(pgrep -fl "swift-build|swift-frontend|clang|xcodebuild|sevra-mac-checks" | head -1 | cut -c1-80)
      [ -n "$who" ] && echo "#### interference during $label at $(date +%H:%M:%S): $who" >> $LOG
      sleep 5
    done ) &
  local watcher=$!
  "$@" 2>&1 | tee -a $LOG
  local rc=${pipestatus[1]}
  kill $watcher 2>/dev/null
  echo "== $label exit $rc $(date +%H:%M:%S) load $(sysctl -n vm.loadavg)" | tee -a $LOG
  return $rc
}
