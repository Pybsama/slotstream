#!/bin/zsh
# After seq5: the final row-invariant form priced at 4k (off and on in one
# process is not possible, so two rungs back to back), the Python kernel
# measurements saved for the record, and the full weights-free catalogue.
LOG=/private/tmp/claude-502/-Users-carlos-Projects-command-center/feaf9fde-de0a-4056-840e-9d376cff840f/scratchpad/seq6.log
source /private/tmp/claude-502/-Users-carlos-Projects-command-center/feaf9fde-de0a-4056-840e-9d376cff840f/scratchpad/qsteps.sh
BIN=~/Projects/slotstream/.build/release/slotstream
while pgrep -f "run_seq4.sh|run_seq5.sh" >/dev/null; do sleep 30; done
echo "#### seq6 start $(date +%H:%M:%S); binary $(shasum -a 256 $BIN | cut -c1-16)" | tee -a $LOG
for arm in off on off on; do
  if [ $arm = on ]; then E=SLOTSTREAM_OPT_ROW_INVARIANT=1; else E=SLOTSTREAM_OPT_ROW_INVARIANT=0; fi
  step "rung 4096 row-invariant $arm" 13 env $E $BIN mtp-passcost --memory-gb 13 --max-context 8192 \
    --prompt-file $S/prompt_4096.txt --positions 6 --max-batch 3 --max-tokens 64 --attention-modes stock,split || exit 1
done
step "python dense matmul row invariance" 2 zsh -c "cd ~/Projects/slotstream && for f in matmul_rows_shapes2 matmul_rows_shapes3 matmul_rows_shapes4; do echo \"-- \$f\"; .venv31/bin/python $S/\$f.py; done"
step "catalogue t0 t1" 2 ~/Projects/slotstream/.build/release/slotstream-checks --tier t0 --tier t1
echo "#### seq6 done $(date +%H:%M:%S)" | tee -a $LOG
