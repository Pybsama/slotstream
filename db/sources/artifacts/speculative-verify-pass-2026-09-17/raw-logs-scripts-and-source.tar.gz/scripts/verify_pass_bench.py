"""Two follow-ups to qmv_rows_bench.py, batched 8 calls per eval so the
per-call submit/sync floor of a Python loop does not dominate small kernels.

A. Re-measure the qmv M-scaling at the two biggest dense shapes with batching.
B. Expert path of a 3-row verify: 30 (row, expert) pairs at M=1 (Slotstream's
   pool path, one matvec per pair) versus 22 unique experts at M=3 (each
   unique expert gets all three rows; unrouted rows are discarded), versus the
   10-pair single-row pass. Full gate/up/silu*mul/down chain, 4-bit g64,
   Flash-Next expert geometry (2560 <-> 640), E=128 experts in the bank.
C. Verify attention at long context: fused SDPA with a [1,1,S,T] bool mask
   selecting 2052 keys per row (S=1,2 vector kernel; S=3 dense fallback)
   versus a rows-gather (take 2052 K/V rows per query row, broadcast matmul,
   softmax) as MTPLX does, at T = 4k..131k. Also reports max|diff| of the
   gather output against the masked SDPA output.
Run only on a quiet GPU. Memory well under 1.5 GB. No model is loaded.
"""
import time
import mlx.core as mx

G, BITS, CALLS, REPS = 64, 4, 8, 12

def timed(make):
    for _ in range(3):
        mx.eval(make())
    mx.synchronize()
    t0 = time.perf_counter()
    for _ in range(REPS):
        mx.eval(make())
    mx.synchronize()
    return (time.perf_counter() - t0) / REPS / CALLS * 1e3  # ms per call

print(f"device {mx.device_info()['architecture']}  mlx {mx.__version__}")

# ---- A: qmv M-scaling, batched ----
print("\nA. dense projections, ms/call (8 calls per eval)")
for name, (K, N) in {"gdn in_proj-like 2560->16384": (2560, 16384), "lm_head 2560->248320": (2560, 248320), "qsa q 2560->6144": (2560, 6144)}.items():
    w, s, b = mx.quantize(mx.random.normal((N, K)).astype(mx.bfloat16), group_size=G, bits=BITS)
    mx.eval(w, s, b)
    base = None
    row = []
    for M in [1, 2, 3, 4, 6, 12]:
        xs = [mx.random.normal((M, K)).astype(mx.bfloat16) for _ in range(CALLS)]
        mx.eval(*xs)
        ms = timed(lambda: [mx.quantized_matmul(x, w, s, b, transpose=True, group_size=G, bits=BITS) for x in xs])
        base = base or ms
        row.append(f"M={M}: {ms:.3f} (x{ms/base:.2f})")
    print(f"  {name:30s} " + "  ".join(row))

# ---- B: expert chain ----
print("\nB. expert chain gate/up/silu*mul/down, ms per layer-call (8 calls per eval)")
E, K, I = 128, 2560, 640
def bank(n, k):
    qs = [mx.quantize(mx.random.normal((n, k)).astype(mx.bfloat16), group_size=G, bits=BITS) for _ in range(E)]
    return tuple(mx.stack([q[i] for q in qs]) for i in range(3))
gate, up, down = bank(I, K), bank(I, K), bank(K, I)
mx.eval(*gate, *up, *down)
rows = [list(range(0, 10)), list(range(6, 16)), list(range(12, 22))]   # 30 pairs, 22 unique
uniq = sorted({e for r in rows for e in r}); assert len(uniq) == 22
def chain(x, idx):
    g = mx.gather_qmm(x, *gate, rhs_indices=idx, transpose=True, group_size=G, bits=BITS)
    u = mx.gather_qmm(x, *up, rhs_indices=idx, transpose=True, group_size=G, bits=BITS)
    h = mx.multiply(g * mx.sigmoid(g), u)
    return mx.gather_qmm(h, *down, rhs_indices=idx, transpose=True, group_size=G, bits=BITS)
x3 = mx.random.normal((3, K)).astype(mx.bfloat16); mx.eval(x3)
# current pool path: x [1, S, 1, 1, K] with indices [1, S, 10]  -> one matvec per (row, expert)
idx_pairs = mx.array([rows], dtype=mx.uint32)                      # [1, 3, 10]
xa = [x3.reshape(1, 3, 1, 1, K) for _ in range(CALLS)]
ms_pairs = timed(lambda: [chain(x, idx_pairs) for x in xa])
# unique experts, M=3 rows each: x [1, 22, 3, K], indices [1, 22]
idx_uniq = mx.array([uniq], dtype=mx.uint32)                       # [1, 22]
xb = [mx.broadcast_to(x3.reshape(1, 1, 3, K), (1, 22, 3, K)) for _ in range(CALLS)]
mx.eval(*xb)
ms_uniq = timed(lambda: [chain(x, idx_uniq) for x in xb])
# single-row pass reference: 10 pairs
idx_one = mx.array([[rows[0]]], dtype=mx.uint32)                   # [1, 1, 10]
xc = [x3[0:1].reshape(1, 1, 1, 1, K) for _ in range(CALLS)]
ms_one = timed(lambda: [chain(x, idx_one) for x in xc])
print(f"  1-row pass, 10 pairs M=1        : {ms_one:.3f} ms")
print(f"  3-row pass, 30 pairs M=1 (now)  : {ms_pairs:.3f} ms  (x{ms_pairs/ms_one:.2f} vs 1-row)")
print(f"  3-row pass, 22 unique x M=3     : {ms_uniq:.3f} ms  (x{ms_uniq/ms_one:.2f} vs 1-row, x{ms_uniq/ms_pairs:.2f} vs pairs)")
# exactness of the unique-expert form against the pair form, per (row, expert)
ya = chain(xa[0], idx_pairs).reshape(3, 10, K)
yb = chain(xb[0], idx_uniq).reshape(22, 3, K)
pos = {e: i for i, e in enumerate(uniq)}
sel = mx.stack([mx.stack([yb[pos[e], r] for e in rows[r]]) for r in range(3)])
mx.eval(ya, sel)
print(f"  max|pairs - unique| over the 30 routed outputs: {mx.max(mx.abs(ya.astype(mx.float32) - sel.astype(mx.float32))).item():.3e}  (0 means bit-identical rows)")

# ---- C: verify attention at long context ----
print("\nC. 12-layer-equivalent? no: per-layer ms, one attention call (8 calls per eval); 2052 selected keys per row")
H, HK, D, SEL = 24, 2, 256, 2052
scale = 1.0 / 16.0
for T in [4096, 16384, 32768, 65536, 131072]:
    k = mx.random.normal((1, HK, T, D)).astype(mx.bfloat16)
    v = mx.random.normal((1, HK, T, D)).astype(mx.bfloat16)
    mx.eval(k, v)
    line = [f"T={T:6d}"]
    for S in [1, 2, 3]:
        q = mx.random.normal((1, H, S, D)).astype(mx.bfloat16); mx.eval(q)
        # selected token ids per row: SEL-1 spread over history plus the row's own position
        ids = []
        for r in range(S):
            last = T - S + r
            n = min(SEL - 1, last)
            step = max(1, last // max(1, n))
            chosen = list(range(0, last, step))[:n] + [last]
            chosen += [chosen[-1]] * (SEL - len(chosen))
            ids.append(chosen)
        ids_arr = mx.array(ids, dtype=mx.int32)                      # [S, SEL]
        mask = mx.zeros((S, T), dtype=mx.bool_)
        for r in range(S):
            mask[r, ids_arr[r]] = True
        mask = mask.reshape(1, 1, S, T); mx.eval(mask, ids_arr)
        ms_dense = timed(lambda: [mx.fast.scaled_dot_product_attention(q, k, v, scale=scale, mask=mask) for _ in range(CALLS)])
        def gather():
            ksel = mx.take(k, ids_arr.reshape(-1), axis=2).reshape(1, HK, 1, S, SEL, D)
            vsel = mx.take(v, ids_arr.reshape(-1), axis=2).reshape(1, HK, 1, S, SEL, D)
            qv = q.reshape(1, HK, H // HK, S, 1, D)
            sc = (mx.matmul(qv, ksel.swapaxes(-1, -2)).astype(mx.float32) * scale)
            p = mx.softmax(sc, axis=-1).astype(mx.bfloat16)
            return mx.matmul(p, vsel).reshape(1, H, S, D)
        ms_gather = timed(lambda: [gather() for _ in range(CALLS)])
        ref = mx.fast.scaled_dot_product_attention(q, k, v, scale=scale, mask=mask)
        diff = mx.max(mx.abs(ref.astype(mx.float32) - gather().astype(mx.float32))).item()
        line.append(f"S={S}: masked {ms_dense:.3f} / gather {ms_gather:.3f} ms (diff {diff:.1e})")
    print("  " + " | ".join(line))
print("\nReading: S=1,2 use the vector kernel (skips masked keys); S=3 is the dense fallback. If the S=3 masked")
print("column grows with T and the gather column does not, the 3-row verify pays an O(context) attention read that")
print("either a 2+1 row split or a rows-gather removes. The diff column shows the numerical class of the gather.")
