"""Make the split verify attention a deployment default (threshold given as argv[1])."""
import sys
from pathlib import Path
threshold = int(sys.argv[1])
root = Path.home() / "Projects/slotstream"

def edit(path, pairs):
    p = root / path; s = p.read_text()
    for old, new in pairs:
        assert s.count(old) == 1, (path, s.count(old), old[:80])
        s = s.replace(old, new)
    p.write_text(s); print("patched", path)

edit("Sources/Slotstream/Optimizations.swift", [
("""        result.sharedRoPE = true
        result.fusedRoPE = true
        return result
    }
""",
"""        result.sharedRoPE = true
        result.fusedRoPE = true
        result.verifySplitAttention = true
        return result
    }
"""),
("""    /// Speculative verify attention: the three-to-eight-row pass goes through
    /// the vector kernel two rows at a time above the measured context
    /// crossover instead of the dense kernel, whose cost grows with the
    /// context. `verifySplitMinContext` overrides the measured threshold (keys;
    /// zero engages at any context). Optional so control sets saved before
    /// the path decode unchanged.
""",
"""    /// Speculative verify attention: the three-to-eight-row pass goes through
    /// the vector kernel two rows at a time from the measured context
    /// crossover instead of the dense kernel, whose cost grows with the
    /// context. In the deployment family. `verifySplitMinContext` overrides
    /// the measured threshold (keys; zero engages at any context). Optional so
    /// control sets saved before the path decode unchanged.
"""),
])

edit("Sources/Slotstream/Layers.swift", [
]) if False else None
p = root / "Sources/Slotstream/Layers.swift"; s = p.read_text()
import re
m = re.search(r"    public static let defaultMinContext = \d+\n", s)
assert m, "defaultMinContext not found"
s = s[:m.start()] + f"    public static let defaultMinContext = {threshold}\n" + s[m.end():]
p.write_text(s); print("threshold", threshold)

edit("Sources/SlotstreamDiagnostics/Diagnostics+Runtime.swift", [
("""        var referenceOverrides = Dictionary(uniqueKeysWithValues: candidateFlags.map { ($0.0, "0") })
""",
"""        c.expect("combined candidate splits the speculative verify attention", candidate.verifySplitAttention == true)
        var noSplit = candidate; noSplit.verifySplitAttention = nil
        c.equal("explicit zero disables only SLOTSTREAM_OPT_VERIFY_SPLIT",
            try InferenceOptimizations.resolving(environment: ["SLOTSTREAM_OPT_VERIFY_SPLIT": "0"], defaults: candidate), noSplit)
        c.equal("explicit one restores only SLOTSTREAM_OPT_VERIFY_SPLIT",
            try InferenceOptimizations.resolving(environment: ["SLOTSTREAM_OPT_VERIFY_SPLIT": "1"], defaults: noSplit), candidate)
        var anyContext = candidate; anyContext.verifySplitMinContext = 0
        c.equal("the verify split threshold override leaves the family intact",
            try InferenceOptimizations.resolving(environment: ["SLOTSTREAM_OPT_VERIFY_SPLIT_CONTEXT": "0"], defaults: candidate), anyContext)
        var referenceOverrides = Dictionary(uniqueKeysWithValues: candidateFlags.map { ($0.0, "0") })
        referenceOverrides["SLOTSTREAM_OPT_VERIFY_SPLIT"] = "0"
"""),
])
