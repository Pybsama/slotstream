import mlx.core as mx
shapes = [("router fp32 2560x512", mx.float32, 2560, 512),
          ("gdn in_proj bf16 2560x48", mx.bfloat16, 2560, 48),
          ("shared gate bf16 2560x1", mx.bfloat16, 2560, 1),
          ("indexer qk bf16 2560x640", mx.bfloat16, 2560, 640),
          ("inject bf16 10240x4", mx.bfloat16, 10240, 4)]
def heavy(shape, key):
    a, b = mx.random.split(key)
    return mx.random.normal(shape, key=a) * mx.exp(mx.random.normal(shape, key=b) * 1.5)
def g(x, wt, rows, k, n):
    return mx.gather_mm(x.reshape(rows, 1, k), wt.reshape(1, k, n),
                        mx.arange(rows, dtype=mx.uint32), mx.zeros(rows, dtype=mx.uint32)).reshape(1, rows, n)
for label, dt, k, n in shapes:
    for kind in ["normal", "heavy"]:
        bad = 0; trials = 0
        for seed in range(25):
            kw, kx = mx.random.split(mx.random.key(seed))
            gen = (lambda s, kk: mx.random.normal(s, key=kk)) if kind == "normal" else heavy
            w = (gen((n, k), kw) * 0.05).astype(dt); wt = w.T
            for rows in [2, 3, 5, 8]:
                x = gen((1, rows, k), mx.random.key(1000 * seed + rows)).astype(dt)
                many = g(x, wt, rows, k, n)
                ones = mx.concatenate([g(x[:, r:r+1], wt, 1, k, n) for r in range(rows)], axis=1)
                mx.eval(many, ones)
                trials += 1
                bad += int(not mx.array_equal(many, ones).item())
        print(f"{label:26s} {kind:6s} {trials} trials: gathered k rows differ from gathered one row in {bad}")
