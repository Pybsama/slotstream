"""Exact mode: every row of a 2-8 row pass attends alone over exactly the keys,
mask and indexer shapes a one-row pass at its position uses."""
from pathlib import Path
root = Path.home() / "Projects/slotstream"
def edit(path, pairs):
    p = root / path; s = p.read_text()
    for old, new in pairs:
        assert s.count(old) == 1, (path, s.count(old), old[:100])
        s = s.replace(old, new)
    p.write_text(s); print("patched", path)

edit("Sources/Slotstream/Layers.swift", [
# 1. QSASelection.row
("""    package func mask(lo: Int, hi: Int, keyEnd: Int) -> MLXArray {
        let (B, S, nBlocks) = (q.dim(0), hi - lo, pooled.dim(1))""",
"""    /// The selection a one-row pass at position `offset + r` would prepare
    /// from the same indexer state: that row's query, the blocks complete at
    /// its position and its key count, so the scores, the partition and the
    /// mask run at that pass's shapes. Nil where that pass has none (its keys
    /// fit the budget). A multi-row pass's own scores run at other shapes, and
    /// near-tied blocks could then rank differently.
    package func row(_ r: Int, budget: Int) -> QSASelection? {
        let keys = offset + r + 1
        guard keys > budget, ratio > 0 else { return nil }
        let blocks = keys / ratio
        return QSASelection(
            q: q[0..., r ..< r + 1, 0..., 0...], pooled: pooled[0..., 0 ..< blocks, 0...],
            blockStarts: blockStarts[0 ..< blocks], offset: offset + r, kvLen: keys, ratio: ratio,
            blockTopK: blockTopK, headDim: headDim, denseBypass: denseBypass,
            specializedSelector: specializedSelector, onSpecialized: onSpecialized)
    }

    package func mask(lo: Int, hi: Int, keyEnd: Int) -> MLXArray {
        let (B, S, nBlocks) = (q.dim(0), hi - lo, pooled.dim(1))"""),
# 2. layer property doc
("""    /// The short multi-row pass (the speculative verify pass): `.split` keeps
    /// it on the vector kernel once the context holds `multiRowMinContext`
    /// keys; see `MultiRowAttention`.""",
"""    /// The short multi-row pass (the speculative verify pass): `.split` and
    /// `.exact` keep it on the vector kernel once the context holds
    /// `multiRowMinContext` keys; see `MultiRowAttention`."""),
# 3. engagement in callAsFunction
("""        let splitRows = multiRowMode == .split && !pruneLastQuery
            && MultiRowAttention.engages(rows: S, context: offset + S, minContext: multiRowMinContext)
        let sparse = boundedIndexer || useSelected || pruneLastQuery ? nil : selection?.mask(lo: 0, hi: S, keyEnd: offset + S)""",
"""        let multiRow = !pruneLastQuery && MultiRowAttention.engages(
            mode: multiRowMode, rows: S, context: offset + S, minContext: multiRowMinContext)
        let exactRows = multiRow && multiRowMode == .exact
        let splitRows = multiRow && multiRowMode == .split
        let sparse = boundedIndexer || useSelected || pruneLastQuery || exactRows
            ? nil : selection?.mask(lo: 0, hi: S, keyEnd: offset + S)"""),
# 4. exact branch before the general attend call
("""        var out = Self.attend(
            q: q, k: k, v: v, sparse: sparse, base: offset, scale: scale,
            block: boundedIndexer && selection != nil""",
"""        if exactRows {
            let budget = cfg.indexerBudget
            let masks = (0 ..< S).map { r in
                selection?.row(r, budget: budget)?.mask(lo: 0, hi: 1, keyEnd: offset + r + 1)
            }
            var out = MultiRowAttention.exactRows(q: q, k: k, v: v, base: offset, scale: scale, masks: masks)
            multiRowSplits += 1
            debugSink?("sdpaOut", out)
            out = out.transposed(0, 2, 1, 3).reshaped([B, S, H * D])
            return oProj(out * sigmoid(gate), minimumRows: minimumProjectionRows)
        }
        var out = Self.attend(
            q: q, k: k, v: v, sparse: sparse, base: offset, scale: scale,
            block: boundedIndexer && selection != nil"""),
# 5. enum
("""/// dense kernel, 10 to 18 ms split). `.split` runs the rows through the
/// vector kernel two at a time over the same mask and concatenates: row r
/// sees exactly the keys a one-row pass at that position sees, so together
/// with `RowInvariantMatmul` the pass reproduces the one-row passes of the
/// same mode bit for bit.
/// `mtp-passcost --attention-modes` times the modes; `mtp-rowcheck` gates
/// the equality.
public enum MultiRowAttention {
    public enum Mode: String { case stock, split }""",
"""/// dense kernel, 10 to 18 ms split). `.split` runs the rows through the
/// vector kernel two at a time over the pass's keys and mask and
/// concatenates. A row's visible keys are those of a one-row pass at its
/// position, but the backend picks the kernel variant and its block layout
/// from the key count (on this Mac the two-pass variant from 1,024 keys, new
/// block counts above 1,024, 8,192, 32,768 and 65,536 keys), so near those
/// counts a split row can round differently from the one-row pass.
/// `.exact`, the mode `RowInvariantMatmul` selects, runs each row alone over
/// exactly the keys and mask a one-row pass at its position uses, with that
/// pass's indexer shapes, from two rows up: every call is then the call plain
/// decode makes, and together with the row-invariant matmuls a pass of up to
/// `exactMaxRows` rows reproduces the one-row passes bit for bit.
/// `mtp-passcost --attention-modes` times the modes; `mtp-rowcheck` gates
/// the equality and `verify-pass-rows` the kernels.
public enum MultiRowAttention {
    public enum Mode: String { case stock, split, exact }"""),
("""    public static let minRows = 3
    public static let maxRows = 8""",
"""    public static let minRows = 3
    public static let maxRows = 8
    /// Rows up to which the exact mode's equality holds on every Apple GPU in
    /// the pinned backend's table: a quantized matmul of fewer rows than its
    /// batch limit runs each row alone, and the smallest limit is 6 (M1 and
    /// M2 below Ultra, outputs wider than 4,096 such as the output head).
    public static let exactMaxRows = 5"""),
("""    static func engages(rows: Int, context: Int, minContext: Int) -> Bool {
        rows >= minRows && rows <= maxRows && context >= minContext
    }""",
"""    static func engages(mode: Mode, rows: Int, context: Int, minContext: Int) -> Bool {
        switch mode {
        case .stock: return false
        case .split: return rows >= minRows && rows <= maxRows && context >= minContext
        // Two rows already take the vector kernel, but over one more key than
        // the first row's one-row pass, which can change the variant.
        case .exact: return rows >= 2 && rows <= maxRows && context >= minContext
        }
    }
    /// The exact mode's attention: row r alone over keys `[0, base + r + 1)`
    /// with its one-row pass's mask, `.none` where that pass has no selection.
    static func exactRows(
        q: MLXArray, k: MLXArray, v: MLXArray, base: Int, scale: Float, masks: [MLXArray?]
    ) -> MLXArray {
        var outs: [MLXArray] = []
        outs.reserveCapacity(q.dim(2))
        for r in 0 ..< q.dim(2) {
            let end = base + r + 1
            let mask: MLXFast.ScaledDotProductAttentionMaskMode
            if let m = masks[r] { mask = .array(m) } else { mask = .none }
            outs.append(MLXFast.scaledDotProductAttention(
                queries: q[0..., 0..., r ..< r + 1, 0...],
                keys: k[0..., 0..., 0 ..< end, 0...], values: v[0..., 0..., 0 ..< end, 0...],
                scale: scale, mask: mask))
        }
        return concatenated(outs, axis: 2)
    }"""),
# 6. RowInvariantMatmul doc: mention attention mode
("""/// therefore changes plain decode's rounding too; its contract is that a
/// multi-row pass equals the one-row passes of the same mode. The dense""",
"""/// therefore changes plain decode's rounding too; its contract is that a
/// multi-row pass equals the one-row passes of the same mode. With the split
/// verify attention on, it also selects `MultiRowAttention.Mode.exact`. The dense"""),
])

edit("Sources/Slotstream/Model.swift", [
("""        let multiRow: MultiRowAttention.Mode = optimizations.verifySplitAttention == true ? .split : .stock""",
"""        let multiRow: MultiRowAttention.Mode = optimizations.verifySplitAttention != true ? .stock
            : optimizations.rowInvariantProjection == true ? .exact : .split"""),
])
