#!/bin/zsh
# After seq14: the 32k decode comparison on the final binary, whose seq14
# attempt met another session's model process at launch.
LOG=/private/tmp/claude-502/-Users-carlos-Projects-command-center/feaf9fde-de0a-4056-840e-9d376cff840f/scratchpad/seq15.log
source /private/tmp/claude-502/-Users-carlos-Projects-command-center/feaf9fde-de0a-4056-840e-9d376cff840f/scratchpad/qsteps2.sh
REPO=~/Projects/slotstream
BIN=$REPO/.build/release/slotstream
therm() { echo "#### therm $(pmset -g therm 2>/dev/null | grep -i 'level' | tr '\n' ' ')" | tee -a $LOG; }
while pgrep -f "run_seq14.sh" >/dev/null; do sleep 20; done
echo "#### seq15 start $(date +%H:%M:%S); binary $(shasum -a 256 $BIN | cut -c1-16)" | tee -a $LOG
therm
for attempt in 1 2 3; do
  step "decode A/B 32k at 22 GB, dense spec" 22 env SLOTSTREAM_OPT_VERIFY_SPLIT=0 $BIN mtp-bench --memory-gb 22 \
    --max-context 33024 --prompt-file $S/prompt_32768.txt --max-tokens 128 --pairs 2 --arms spec,split && break
  echo "#### 32k step failed (attempt $attempt); waiting before the next" | tee -a $LOG
  sleep 120
done
therm
echo "#### seq15 done $(date +%H:%M:%S)" | tee -a $LOG
