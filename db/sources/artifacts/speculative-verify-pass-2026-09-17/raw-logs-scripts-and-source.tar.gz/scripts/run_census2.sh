#!/bin/zsh
# Dispatch census of greedy decode with the draft head on, 129 tokens, for one
# switch set; the counts and timeline files carry the TAG. Env switches pass through.
set -u
BIN=~/Projects/slotstream/.build/release/slotstream
S=/private/tmp/claude-502/-Users-carlos-Projects-command-center/feaf9fde-de0a-4056-840e-9d376cff840f/scratchpad
C=$S/census
MEM=${MEM:-13}
TAG=${TAG:-ship}
PROMPT="Explain how a transistor works, in about 300 words."
echo "== census $TAG max-tokens 129 $(date +%H:%M:%S) env VERIFY_SPLIT=${SLOTSTREAM_OPT_VERIFY_SPLIT:-unset} ROW_INVARIANT=${SLOTSTREAM_OPT_ROW_INVARIANT:-unset} COMPILED_HC=${SLOTSTREAM_OPT_COMPILED_HC:-unset}"
DYLD_INSERT_LIBRARIES=$C/census_mrc.dylib SLOTSTREAM_CENSUS_OUT=$C/counts_${TAG}_129.txt SLOTSTREAM_CENSUS_TIMELINE=$C/timeline_${TAG}_129.txt \
  $BIN run --memory-gb $MEM --mtp on --greedy --max-tokens 129 --prompt "$PROMPT" --stats-json $C/stats_${TAG}_129.json 2>&1 | grep -v "^\s*$" | tail -8
