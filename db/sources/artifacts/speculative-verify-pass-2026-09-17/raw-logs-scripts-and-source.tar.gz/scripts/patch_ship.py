"""Ship patch: split verify attention behind an optimization flag with a
context threshold, row-invariant small matmuls as an optimization flag, the
fused hyper-connection read experiment, gather removed."""
import re, sys
from pathlib import Path

root = Path.home() / "Projects/slotstream"

def edit(path, pairs):
    p = root / path
    s = p.read_text()
    for old, new in pairs:
        n = s.count(old)
        assert n == 1, f"{path}: expected 1 match, found {n} for:\n{old[:120]}"
        s = s.replace(old, new)
    p.write_text(s)
    print("patched", path)

def cut(path, start_marker, end_marker, replacement, must_contain=None):
    p = root / path
    s = p.read_text()
    i = s.index(start_marker); j = s.index(end_marker, i)
    chunk = s[i:j]
    if must_contain: assert must_contain in chunk, f"{path}: cut chunk lacks {must_contain}"
    s = s[:i] + replacement + s[j:]
    p.write_text(s)
    print("cut", path, len(chunk), "chars")

# ---------------------------------------------------------------- Layers.swift
L = "Sources/Slotstream/Layers.swift"
edit(L, [
("""    var boundedIndexer = false
    var selectedAttention = false
    private(set) var selectedAttentionTiles = 0
""",
"""    var boundedIndexer = false
    var selectedAttention = false
    private(set) var selectedAttentionTiles = 0
    /// The short multi-row pass (the speculative verify pass): `.split` keeps
    /// it on the vector kernel once the context holds `multiRowMinContext`
    /// keys; see `MultiRowAttention`.
    var multiRowMode: MultiRowAttention.Mode = .stock
    var multiRowMinContext = MultiRowAttention.defaultMinContext
    private(set) var multiRowSplits = 0
"""),
("""        let gatherMode = MultiRowAttention.mode == .gather && S >= MultiRowAttention.minRows && S <= 8
            && !pruneLastQuery && selection.map { MultiRowAttention.gatherEligible(selection: $0, context: offset + S) } == true
        let sparse = boundedIndexer || useSelected || pruneLastQuery || gatherMode ? nil : selection?.mask(lo: 0, hi: S, keyEnd: offset + S)
""",
"""        let splitRows = multiRowMode == .split && !pruneLastQuery
            && MultiRowAttention.engages(rows: S, context: offset + S, minContext: multiRowMinContext)
        let sparse = boundedIndexer || useSelected || pruneLastQuery ? nil : selection?.mask(lo: 0, hi: S, keyEnd: offset + S)
"""),
("""            selection: boundedIndexer || useSelected || gatherMode ? selection : nil,
            selectedAttention: useSelected,
            onSelected: { [weak self] in self?.selectedAttentionTiles += 1 })
""",
"""            selection: boundedIndexer || useSelected ? selection : nil,
            selectedAttention: useSelected,
            onSelected: { [weak self] in self?.selectedAttentionTiles += 1 },
            splitRows: splitRows,
            onSplit: { [weak self] in self?.multiRowSplits += 1 })
"""),
("""        scale: Float, block: Int, selection: QSASelection? = nil,
        selectedAttention: Bool = false, onSelected: (() -> Void)? = nil
    ) -> MLXArray {
""",
"""        scale: Float, block: Int, selection: QSASelection? = nil,
        selectedAttention: Bool = false, onSelected: (() -> Void)? = nil,
        splitRows: Bool = false, onSplit: (() -> Void)? = nil
    ) -> MLXArray {
"""),
])

# remove gatherRows (its doc comment through the end of its body)
cut(L, "    /// Attention for a few rows over each row's selected keys alone:", "    static func attend(", "",
    must_contain="static func gatherRows(")

# the multi-row branch of attend
cut(L, "        if block >= S {\n            if S >= MultiRowAttention.minRows",
       "        var outs: [MLXArray] = []\n        outs.reserveCapacity(",
"""        if block >= S {
            if splitRows {
                // Two rows at GQA 12 is the largest chunk the vector kernel
                // admits; every row keeps its full key domain, so row r sees
                // exactly the keys a one-row pass at its position sees.
                let rows = selection?.mask(lo: 0, hi: S, keyEnd: base + S) ?? sparse
                    ?? MultiRowAttention.causalRows(rows: S, keyEnd: base + S)
                let chunk = max(1, MultiRowAttention.vectorKernelRows / max(1, q.dim(1) / k.dim(1)))
                var outs: [MLXArray] = []
                var lo = 0
                while lo < S {
                    let hi = min(S, lo + chunk)
                    outs.append(MLXFast.scaledDotProductAttention(
                        queries: q[0..., 0..., lo ..< hi, 0...], keys: k, values: v, scale: scale,
                        mask: .array(rows[0..., 0..., lo ..< hi, 0...])))
                    lo = hi
                }
                onSplit?()
                return concatenated(outs, axis: 2)
            }
            return MLXFast.scaledDotProductAttention(
                queries: q, keys: k, values: v, scale: scale, mask: mask(selection?.mask(lo: 0, hi: S, keyEnd: base + S) ?? sparse, queries: S))
        }
""", must_contain="case .gather:")

# the MultiRowAttention enum with its doc comment, and RowExactMatmul
s = (root / L).read_text()
enum_at = s.index("public enum MultiRowAttention {")
doc_start = s.rfind("\n\n", 0, enum_at) + 2
assert s[doc_start:doc_start+3] == "///", s[doc_start:doc_start+40]
rem_start = s.index("/// A plain dense matmul whose per-row arithmetic")
rem_end = s.index("\n}\n", s.index("return out.reshaped(Array(x.shape.dropLast()) + [w.dim(-1)])", rem_start)) + 3
new_enums = '''/// How the short multi-row pass, the speculative verify pass of three to
/// eight rows, attends. The pinned backend keeps a pass on the vector SDPA
/// kernel only while query rows times the GQA factor stay within 32; at
/// GQA 12 that is two rows, so the three-row depth-2 verify pass falls to the
/// dense kernel, which reads every key and value and materializes a score row
/// per query, a cost that grows with the context (measured 2026-09-16 on the
/// real engine: the third row costs 12 ms at 4k and 99 ms at 65k keys on the
/// dense kernel, 10 to 18 ms split). `.split` runs the rows through the
/// vector kernel two at a time over the same mask and concatenates: row r
/// sees exactly the keys a one-row pass at that position sees, so together
/// with `RowInvariantMatmul` the pass reproduces plain decode bit for bit.
/// `mtp-passcost --attention-modes` times the modes; `mtp-rowcheck` gates
/// the equality.
public enum MultiRowAttention {
    public enum Mode: String { case stock, split }
    /// Query rows times the GQA factor the vector kernel admits.
    static let vectorKernelRows = 32
    /// Rows at or above which the split matters; one and two rows already
    /// take the vector kernel. Longer passes are prefill, not verify.
    public static let minRows = 3
    public static let maxRows = 8
    /// Keys at or above which the split beats the dense kernel: the measured
    /// crossover (the 4k rung favors the dense kernel by 7 ms, the 16k rung
    /// the split by 15 ms; the 6k to 12k rungs place the threshold).
    public static let defaultMinContext = 8192
    static func engages(rows: Int, context: Int, minContext: Int) -> Bool {
        rows >= minRows && rows <= maxRows && context >= minContext
    }
    /// A causal boolean mask for the last `rows` queries over `keyEnd` keys,
    /// for a pass below the indexer budget where no selection mask exists.
    static func causalRows(rows: Int, keyEnd: Int) -> MLXArray {
        let keys = MLXArray((0 ..< keyEnd).map { Int32($0) })
        let last = MLXArray((0 ..< rows).map { Int32(keyEnd - rows + $0) })
        return (keys.expandedDimensions(axis: 0) .<= last.expandedDimensions(axis: 1)).reshaped([1, 1, rows, keyEnd])
    }
}

/// A small dense matmul whose per-row arithmetic does not depend on the row
/// count. The pinned backend runs one activation row as a GEMV and two or
/// more as a split-K GEMM, whose partial sums land in a different order, so
/// the bf16 or fp32 result of the same row differs between a one-row decode
/// pass and a multi-row verify pass (measured 2026-09-16: row 0 of a two-row
/// pass sits about 3% of the logit spread from the one-row pass, from the
/// router projection and the hyper-connection matmuls alone). Enabled by
/// `InferenceOptimizations.rowInvariantProjection`, passes of two to eight
/// rows go through `gatherMM` with one row per index: the GEMV runs once per
/// row inside one dispatch and reproduces the one-row result bit for bit
/// (checked on the router and hyper-connection shapes; a contiguous batch of
/// one-row matmuls does not, the backend collapses it into the GEMM). Small
/// weights only: the router and inject weights, and QLinear's dense fallback.
public enum RowInvariantMatmul {
    /// Set from the resolved optimizations at every forward pass.
    public internal(set) static var enabled = false
    /// The verify regime. A prefill chunk keeps the stock GEMM: its rows are
    /// never compared against a one-row pass, and its own numerics are gated
    /// by the prefix-check band.
    public static let maxRows = 8
    public private(set) static var calls = 0
    static func rows(_ x: MLXArray, _ w: MLXArray) -> MLXArray {
        let rows = x.size / x.dim(-1)
        guard enabled, rows > 1, rows <= maxRows else { return matmul(x, w) }
        calls += 1
        let k = x.dim(-1)
        let out = gatherMM(
            x.reshaped([rows, 1, k]), w.reshaped([1, k, w.dim(-1)]),
            lhsIndices: MLXArray((0 ..< rows).map { UInt32($0) }),
            rhsIndices: MLXArray([UInt32](repeating: 0, count: rows)))
        return out.reshaped(Array(x.shape.dropLast()) + [w.dim(-1)])
    }
}
'''
s = s[:doc_start] + new_enums + s[rem_end:]
(root / L).write_text(s)
print("replaced enums")

edit(L, [
("""final class GatedResidual {
    var minimumProjectionRows = 0
    var compiledNormFinish = false
    private(set) var compiledFinishes = 0
""",
"""final class GatedResidual {
    var minimumProjectionRows = 0
    var compiledNormFinish = false
    private(set) var compiledFinishes = 0
    /// Fused pointwise read (`CompiledHyperRead`); nil keeps the eager chain.
    var compiledRead: CompiledHyperRead? = nil
    private(set) var compiledReads = 0
"""),
("""        let downOut = down(normed, minimumRows: minimumProjectionRows)
        if let n = debugName { Qwen4ExpModel.debugDump(n + "_down", downOut) }
        var w = MLXNN.silu(downOut / Float(cfg.hcCount))
        w = sigmoid(up(w, minimumRows: minimumProjectionRows))
        if let n = debugName { Qwen4ExpModel.debugDump(n + "_wup", w) }
        let shape = Array(w.shape.dropLast()) + [cfg.hcCount, cfg.hiddenSize]
        let mixed = (w.reshaped(shape) * normed.reshaped(shape)).mean(axis: -2)
        guard let injW = inject else { return (mixed, nil) }
        let projected = QLinear.withReferenceRows(normed, minimumRows: minimumProjectionRows) { RowExactMatmul.rows($0, injW.transposed()) }
        let injected = 2 * sigmoid(projected / Float(cfg.hcCount))
        return (mixed, injected)
""",
"""        let downOut = down(normed, minimumRows: minimumProjectionRows)
        if let n = debugName { Qwen4ExpModel.debugDump(n + "_down", downOut) }
        let shape = Array(downOut.shape.dropLast()) + [cfg.hcCount, cfg.hiddenSize]
        if let fused = compiledRead, debugName == nil {
            // Same matmuls, reshapes and rounding boundaries; the pointwise
            // work between them is one kernel per stage instead of two to four.
            compiledReads += 1
            let upOut = up(fused.gate(downOut), minimumRows: minimumProjectionRows)
            let mixed = fused.mix(upOut.reshaped(shape), normed.reshaped(shape))
            guard let injW = inject else { return (mixed, nil) }
            let projected = QLinear.withReferenceRows(normed, minimumRows: minimumProjectionRows) { RowInvariantMatmul.rows($0, injW.transposed()) }
            return (mixed, fused.inject(projected))
        }
        var w = MLXNN.silu(downOut / Float(cfg.hcCount))
        w = sigmoid(up(w, minimumRows: minimumProjectionRows))
        if let n = debugName { Qwen4ExpModel.debugDump(n + "_wup", w) }
        let mixed = (w.reshaped(shape) * normed.reshaped(shape)).mean(axis: -2)
        guard let injW = inject else { return (mixed, nil) }
        let projected = QLinear.withReferenceRows(normed, minimumRows: minimumProjectionRows) { RowInvariantMatmul.rows($0, injW.transposed()) }
        let injected = 2 * sigmoid(projected / Float(cfg.hcCount))
        return (mixed, injected)
"""),
])
s = (root / L).read_text()
assert "RowExactMatmul" not in s and "gather" not in s.split("public enum MultiRowAttention")[1].split("public enum RowInvariantMatmul")[0]
assert s.count("Self.attend(") == 1 and s.count("return attend(") == 1

# ------------------------------------------------------------ small matmuls
edit("Sources/Slotstream/Weights.swift", [("return RowExactMatmul.rows(x, w.transposed())", "return RowInvariantMatmul.rows(x, w.transposed())")])
edit("Sources/Slotstream/RouterProjection.swift", [("return RowExactMatmul.rows(x.asType(.float32), (promoted ?? original).transposed())",
                                                    "return RowInvariantMatmul.rows(x.asType(.float32), (promoted ?? original).transposed())")])

# ------------------------------------------------------------ Optimizations
edit("Sources/Slotstream/Optimizations.swift", [
("""    public var expertPrefetch: Bool? = nil
    public var expertPrefetchShadow: Bool? = nil
""",
"""    public var expertPrefetch: Bool? = nil
    public var expertPrefetchShadow: Bool? = nil
    /// Speculative verify attention: the three-to-eight-row pass goes through
    /// the vector kernel two rows at a time above the measured context
    /// crossover instead of the dense kernel, whose cost grows with the
    /// context. `verifySplitMinContext` overrides the measured threshold (keys;
    /// zero engages at any context). Optional so control sets saved before
    /// the path decode unchanged.
    public var verifySplitAttention: Bool? = nil
    public var verifySplitMinContext: Int? = nil
    /// Row-invariant small dense matmuls (router projection, hyper-connection
    /// inject, dense fallbacks) for passes of two to eight rows, so a
    /// multi-row verify pass reproduces the one-row arithmetic bit for bit.
    public var rowInvariantProjection: Bool? = nil
    /// Fused pointwise hyper-connection read (experiment; priced by dispatch count).
    public var compiledHyperRead: Bool? = nil
"""),
("""        guard !(result.expertPrefetch == true && result.expertPrefetchShadow == true) else {
            throw ModelError("EXPERT_PREFETCH and EXPERT_PREFETCH_SHADOW are mutually exclusive")
        }
""",
"""        guard !(result.expertPrefetch == true && result.expertPrefetchShadow == true) else {
            throw ModelError("EXPERT_PREFETCH and EXPERT_PREFETCH_SHADOW are mutually exclusive")
        }
        result.verifySplitAttention = try flag("SLOTSTREAM_OPT_VERIFY_SPLIT", fallback: result.verifySplitAttention ?? false) ? true : nil
        let splitContextKey = "SLOTSTREAM_OPT_VERIFY_SPLIT_CONTEXT"
        recognized.insert(splitContextKey)
        if let value = env[splitContextKey] {
            guard let n = Int(value), n >= 0, n <= ContextPolicy.modelLimit else {
                throw ModelError("\\(splitContextKey) must be a key count from 0 to \\(ContextPolicy.modelLimit)")
            }
            result.verifySplitMinContext = n
        }
        result.rowInvariantProjection = try flag("SLOTSTREAM_OPT_ROW_INVARIANT", fallback: result.rowInvariantProjection ?? false) ? true : nil
        result.compiledHyperRead = try flag("SLOTSTREAM_OPT_COMPILED_HC", fallback: result.compiledHyperRead ?? false) ? true : nil
"""),
])

# ------------------------------------------------------------------- Model
edit("Sources/Slotstream/Model.swift", [
("""    public var selectedAttentionTiles: Int {
        qsa.values.reduce(0) { $0 + $1.selectedAttentionTiles } + (mtpHead?.attn.selectedAttentionTiles ?? 0)
    }
""",
"""    public var selectedAttentionTiles: Int {
        qsa.values.reduce(0) { $0 + $1.selectedAttentionTiles } + (mtpHead?.attn.selectedAttentionTiles ?? 0)
    }
    /// Multi-row verify passes (per attention layer) that took the split vector-kernel path.
    public var multiRowSplits: Int {
        qsa.values.reduce(0) { $0 + $1.multiRowSplits } + (mtpHead?.attn.multiRowSplits ?? 0)
    }
    /// Hyper-connection reads that took the fused pointwise path.
    public var compiledHyperReads: Int {
        (attnHC + mlpHC + [mixer]).reduce(0) { $0 + $1.compiledReads }
            + (mtpHead.map { $0.attnHC.compiledReads + $0.mlpHC.compiledReads + $0.mixer.compiledReads } ?? 0)
    }
    private var compiledHyperRead: CompiledHyperRead? = nil
    private var compiledHyperReadTried = false
    private var compiledHyperReadConfigured = false
"""),
("""        mtpHead?.attnHC.compiledNormFinish = compiledNorm
        mtpHead?.mlpHC.compiledNormFinish = compiledNorm
        mtpHead?.mixer.compiledNormFinish = compiledNorm
""",
"""        mtpHead?.attnHC.compiledNormFinish = compiledNorm
        mtpHead?.mlpHC.compiledNormFinish = compiledNorm
        mtpHead?.mixer.compiledNormFinish = compiledNorm
        let multiRow: MultiRowAttention.Mode = optimizations.verifySplitAttention == true ? .split : .stock
        let multiRowContext = optimizations.verifySplitMinContext ?? MultiRowAttention.defaultMinContext
        for layer in qsa.values { layer.multiRowMode = multiRow; layer.multiRowMinContext = multiRowContext }
        mtpHead?.attn.multiRowMode = multiRow
        mtpHead?.attn.multiRowMinContext = multiRowContext
        RowInvariantMatmul.enabled = optimizations.rowInvariantProjection == true
        if optimizations.compiledHyperRead == true, !compiledHyperReadTried {
            compiledHyperReadTried = true
            compiledHyperRead = CompiledHyperRead.prepared(hcCount: cfg.hcCount, lowRank: cfg.hcLowrank, hiddenSize: cfg.hiddenSize)
        }
        let fusedRead = optimizations.compiledHyperRead == true ? compiledHyperRead : nil
        if (fusedRead != nil) != compiledHyperReadConfigured {
            for unit in attnHC + mlpHC + [mixer] { unit.compiledRead = fusedRead }
            compiledHyperReadConfigured = fusedRead != nil
        }
        mtpHead?.attnHC.compiledRead = fusedRead
        mtpHead?.mlpHC.compiledRead = fusedRead
        mtpHead?.mixer.compiledRead = fusedRead
"""),
])

# ------------------------------------------------------------- CompiledHyperRead
(root / "Sources/Slotstream/CompiledHyperRead.swift").write_text('''import MLX
import MLXNN

/// Fused pointwise work around the hyper-connection read's two small matmuls:
/// the gate input `silu(down / hc)`, the stream mix `sigmoid(up) * normed`
/// reduced over the streams, and the inject `2 * sigmoid(p / hc)`. Each stage
/// is one kernel instead of two to four (the dispatch census of 2026-09-16
/// counted about 1,500 sigmoid, multiply, add and divide launches per verify
/// pass, a large share of them here). The matmuls, the reshapes and the bf16
/// rounding boundaries stay where the eager path has them; the reshapes stay
/// outside the compiled functions, which are shapeless. An instance exists
/// only after every stage reproduces the eager arithmetic bit for bit.
package final class CompiledHyperRead {
    private let gateFn: ([MLXArray]) -> [MLXArray]
    private let mixFn: ([MLXArray]) -> [MLXArray]
    private let injectFn: ([MLXArray]) -> [MLXArray]

    private init(hcCount: Int) {
        let hc = Float(hcCount)
        gateFn = compile(shapeless: true) { (v: [MLXArray]) -> [MLXArray] in
            let t = v[0] / hc
            return [t * sigmoid(t)]
        }
        mixFn = compile(shapeless: true) { (v: [MLXArray]) -> [MLXArray] in
            [(sigmoid(v[0]) * v[1]).mean(axis: -2)]
        }
        injectFn = compile(shapeless: true) { (v: [MLXArray]) -> [MLXArray] in
            [2 * sigmoid(v[0] / hc)]
        }
    }

    /// `silu(downOut / hc)`, the input of the up projection.
    func gate(_ downOut: MLXArray) -> MLXArray { gateFn([downOut]).first ?? MLXArray(0) }
    /// `(sigmoid(upOut) * normed).mean(axis: -2)` over `[..., hc, hidden]` inputs.
    func mix(_ upOut: MLXArray, _ normed: MLXArray) -> MLXArray { mixFn([upOut, normed]).first ?? MLXArray(0) }
    /// `2 * sigmoid(projected / hc)`.
    func inject(_ projected: MLXArray) -> MLXArray { injectFn([projected]).first ?? MLXArray(0) }

    static func referenceGate(_ downOut: MLXArray, hc: Float) -> MLXArray { MLXNN.silu(downOut / hc) }
    static func referenceMix(_ upOut: MLXArray, _ normed: MLXArray) -> MLXArray { (sigmoid(upOut) * normed).mean(axis: -2) }
    static func referenceInject(_ projected: MLXArray, hc: Float) -> MLXArray { 2 * sigmoid(projected / hc) }

    /// Deterministic bf16 test values a few units wide.
    private static func values(_ shape: [Int], phase: Float) -> MLXArray {
        let count = shape.reduce(1, *)
        let ramp = MLXArray((0 ..< count).map { Float($0) })
        return (sin(ramp * 0.37 + phase) * 2.5).reshaped(shape).asType(.bfloat16)
    }

    /// The fused read for this model's stream count, or nil when any stage
    /// differs from the eager arithmetic by a single bit (the caller then
    /// keeps the eager chain, as `CompiledArithmetic` does).
    package static func prepared(hcCount: Int, lowRank: Int, hiddenSize: Int) -> CompiledHyperRead? {
        let fused = CompiledHyperRead(hcCount: hcCount)
        let hc = Float(hcCount)
        do {
            let exact = try withError { _ -> Bool in
                let downOut = values([1, 3, lowRank], phase: 0.1)
                let upOut = values([1, 3, hcCount, hiddenSize], phase: 0.7)
                let normed = values([1, 3, hcCount, hiddenSize], phase: 1.9)
                let projected = values([1, 3, hcCount], phase: 2.3)
                let gate = fused.gate(downOut), mix = fused.mix(upOut, normed), inject = fused.inject(projected)
                eval(gate, mix, inject)
                return gate.dtype == .bfloat16 && mix.dtype == .bfloat16 && inject.dtype == .bfloat16
                    && (gate .== referenceGate(downOut, hc: hc)).all().item(Bool.self)
                    && (mix .== referenceMix(upOut, normed)).all().item(Bool.self)
                    && (inject .== referenceInject(projected, hc: hc)).all().item(Bool.self)
            }
            return exact ? fused : nil
        } catch { return nil }
    }
}
''')
print("wrote CompiledHyperRead.swift")

# ----------------------------------------------------------------- CLI
C = "Sources/slotstream-cli/MTPCommands.swift"
edit(C, [
('''    @Option(help: "Comma-separated multi-row attention modes to time per pass (stock,split,gather); stock is always the reference and rebuild timings are skipped")''',
 '''    @Option(help: "Comma-separated multi-row attention modes to time per pass (stock,split); stock is always the reference and rebuild timings are skipped")'''),
('''                    throw ModelError("unknown attention mode '\\(name)': use stock, split or gather")''',
 '''                    throw ModelError("unknown attention mode '\\(name)': use stock or split")'''),
('''                func key(_ mode: MultiRowAttention.Mode, _ k: Int) -> String { "\\(mode.rawValue)/\\(k)" }
''',
 '''                func key(_ mode: MultiRowAttention.Mode, _ k: Int) -> String { "\\(mode.rawValue)/\\(k)" }
                // Modes are timed at every context, so the split's threshold is lifted here.
                func setMode(_ mode: MultiRowAttention.Mode) {
                    m.optimizations.verifySplitAttention = mode == .split ? true : nil
                    m.optimizations.verifySplitMinContext = mode == .split ? 0 : nil
                }
'''),
('''                        MultiRowAttention.mode = .stock
                        m.pool.resetStats()
                        var coldLogits: MLXArray? = nil
''',
 '''                        setMode(.stock)
                        m.pool.resetStats()
                        var coldLogits: MLXArray? = nil
'''),
('''                                MultiRowAttention.mode = mode
                                m.pool.resetStats()
''',
 '''                                setMode(mode)
                                m.pool.resetStats()
'''),
('''                            MultiRowAttention.mode = .stock
                            if k == 1 { plainRef = logitsByMode[.stock]?.asType(.float32) }
''',
 '''                            setMode(.stock)
                            if k == 1 { plainRef = logitsByMode[.stock]?.asType(.float32) }
'''),
('''                    print("  engaged: split \\(MultiRowAttention.splitCalls) calls, gather \\(MultiRowAttention.gatherCalls) calls (attention layers x passes); row-exact matmul \\(RowExactMatmul.enabled ? "on" : "off"), \\(RowExactMatmul.calls) calls")''',
 '''                    print("  engaged: split \\(m.multiRowSplits) layer passes; row-invariant matmul \\(m.optimizations.rowInvariantProjection == true ? "on" : "off"), \\(RowInvariantMatmul.calls) calls; fused hyper-connection read \\(m.compiledHyperReads) calls")'''),
])
s = (root / C).read_text()
assert "MultiRowAttention.mode" not in s and "RowExactMatmul" not in s
s += '''
/// Gate: with the split verify attention and row-invariant projections on,
/// row 0 of a k-row verify pass equals the one-row pass at that position bit
/// for bit, so speculative decode cannot say anything plain decode would not.
/// The stock deviation is reported alongside, the size of what the two
/// controls remove. The prompt is synthesized above the indexer budget so a
/// real block selection is active, the case the shipping threshold engages.
struct MTPRowCheck: ParsableCommand {
    static let configuration = CommandConfiguration(
        commandName: "mtp-rowcheck",
        abstract: "Gate: multi-row verify passes reproduce one-row decode bit for bit")
    @OptionGroup var model: ModelOptions
    @Option(help: "Prompt length to synthesize, in tokens (above the indexer budget)") var promptTokens: Int = 2600
    @Option(help: "Positions compared (after one warm-up position)") var positions: Int = 4
    @Option(help: "Largest pass compared (the verify pass is draft depth + 1)") var maxBatch: Int = 3
    @Option(help: "Prompt plus reply context window: auto or tokens") var maxContext: ContextWindowArgument = .automatic

    /// Deterministic prose: distinct entries, no repetition the indexer could collapse.
    static func prose(entries: Int) -> String {
        let subjects = ["The archive", "A courier", "The harbor office", "Every ledger", "The night clerk",
                        "An old survey", "The lighthouse keeper", "The tram depot", "A visiting auditor"]
        let verbs = ["recorded", "questioned", "measured", "misplaced", "compared", "reported", "restored", "counted"]
        let objects = ["the winter inventory", "a set of brass keys", "the tide tables", "three sealed crates",
                       "the eastern fence line", "a damaged pump", "the morning manifest", "the reservoir gauges",
                       "the granary receipts", "two borrowed lanterns", "the ferry schedule"]
        let tails = ["before the first frost.", "without telling the council.", "against last year's totals.",
                     "while the bridge was closed.", "under a borrowed lamp.", "as the ferry came in.",
                     "after the audit ended.", "for the third time that month.", "despite the storm warning."]
        var text = ""
        for i in 0 ..< entries {
            var sentences: [String] = []
            for j in 0 ..< 5 {
                let n = i * 5 + j
                sentences.append("\\(subjects[(n * 7 + i) % subjects.count]) \\(verbs[(n * 3 + j) % verbs.count]) "
                    + "\\(objects[(n * 5 + i * 2) % objects.count]) \\(tails[(n * 11 + j * 3) % tails.count])")
            }
            text += "Entry \\(i + 1). " + sentences.joined(separator: " ") + "\\n\\n"
        }
        return text + "Summarize these entries in detail, one paragraph per entry."
    }

    func run() throws {
        let plan: MemoryPlan
        if let tokens = maxContext.tokens {
            plan = try model.announcedPlan(maxContext: tokens, requireMTP: true)
        } else {
            plan = try model.announcedPlan(requireMTP: true)
        }
        guard maxBatch >= 2, positions >= 1 else { throw ModelError("--max-batch must be at least 2 and --positions at least 1") }
        let sem = DispatchSemaphore(value: 0)
        var result: Result<Void, Error> = .success(())
        Task {
            do {
                let engine = try await Engine(modelDir: model.modelURL, plan: plan)
                let m = engine.model
                guard let head = m.mtpHead else { throw ModelError("draft head not loaded") }
                var entries = max(8, promptTokens / 60)
                var ids: [Int] = []
                while true {
                    ids = try engine.encodeChat(
                        [ChatMessage(role: "user", content: Self.prose(entries: entries))], thinking: false)
                    if ids.count >= promptTokens || entries > 4096 { break }
                    entries = entries * 3 / 2 + 1
                }
                guard ids.count > m.cfg.indexerBudget else {
                    throw ModelError("prompt of \\(ids.count) tokens is not above the indexer budget of \\(m.cfg.indexerBudget)")
                }
                print("prompt: \\(ids.count) tokens; context window \\(plan.maxContextTokens); indexer budget \\(m.cfg.indexerBudget)")
                var params = SampleParams.greedy
                params.maxTokens = maxBatch * (positions + 1) + 16
                engine.generator.speculationEnabled = false
                let (out, _) = engine.generator.generate(promptIds: ids, params: params, eosIds: engine.eosIds)
                let seq = ids + out
                let need = ids.count + maxBatch * (positions + 1) + 1
                guard seq.count >= need else {
                    throw ModelError("continuation too short: \\(out.count) tokens; lower --positions")
                }

                let state = m.makeState()
                let mtpState = MTPState()
                state.mtp = mtpState
                let prefix = Array(seq[0 ..< ids.count])
                let (_, pm) = m.hiddenStatesWithMulti(prefix, state: state)
                eval(pm)
                state.lastMulti = head.consume(
                    chunk: prefix, chunkMulti: pm, prevMulti: nil,
                    resident: m.resident, rope: m.sharedRope, state: mtpState)

                func configure(split: Bool, invariant: Bool) {
                    m.optimizations.verifySplitAttention = split ? true : nil
                    m.optimizations.verifySplitMinContext = split ? 0 : nil
                    m.optimizations.rowInvariantProjection = invariant ? true : nil
                }
                func logits(_ chunk: [Int], from checkpoint: ModelState.Checkpoint) -> MLXArray {
                    let (l, mu) = m.allLogitsWithMulti(chunk, state: state)
                    eval(l, mu)
                    state.restore(checkpoint)
                    return l.asType(.float32)
                }
                // per k: worst row-0 deviation from the one-row pass (of the logit spread) and top-1 flips
                var exactDiff: [Int: Double] = [:], exactFlips: [Int: Int] = [:]
                var stockDiff: [Int: Double] = [:], stockFlips: [Int: Int] = [:]
                var p = ids.count
                for pos in 0 ... positions {  // position 0 is the warm-up (kernel compiles)
                    let record = pos > 0
                    let ck = state.checkpoint()
                    configure(split: false, invariant: false)
                    let plain = logits(Array(seq[p ..< p + 1]), from: ck)
                    let spread = (plain.max() - plain.min()).item(Float.self)
                    let plainTop = argMax(plain, axis: -1)
                    for k in 2 ... maxBatch {
                        let chunk = Array(seq[p ..< p + k])
                        configure(split: true, invariant: true)
                        let exact = logits(chunk, from: ck)
                        configure(split: false, invariant: false)
                        let stock = logits(chunk, from: ck)
                        guard record else { continue }
                        for (l, isExact) in [(exact, true), (stock, false)] {
                            let row0 = l[0..., 0 ..< 1, 0...]
                            let d = spread > 0 ? Double(abs(row0 - plain).max().item(Float.self) / spread) : 0
                            let f = Int((argMax(row0, axis: -1) .!= plainTop).asType(.int32).sum().item(Int32.self))
                            if isExact {
                                exactDiff[k] = max(exactDiff[k] ?? 0, d); exactFlips[k, default: 0] += f
                            } else {
                                stockDiff[k] = max(stockDiff[k] ?? 0, d); stockFlips[k, default: 0] += f
                            }
                        }
                    }
                    // Advance for real by maxBatch tokens so the next position is fresh.
                    let step = Array(seq[p ..< p + maxBatch])
                    let (_, mu) = m.hiddenStatesWithMulti(step, state: state)
                    eval(mu)
                    state.lastMulti = head.consume(
                        chunk: step, chunkMulti: mu, prevMulti: state.lastMulti,
                        resident: m.resident, rope: m.sharedRope, state: mtpState)
                    p += maxBatch
                }

                var failures: [String] = []
                func check(_ name: String, _ ok: Bool) {
                    print(ok ? "PASS  \\(name)" : "FAIL  \\(name)")
                    if !ok { failures.append(name) }
                }
                if maxBatch >= MultiRowAttention.minRows {
                    check("split verify attention engaged (\\(m.multiRowSplits) layer passes)", m.multiRowSplits > 0)
                }
                check("row-invariant projections engaged (\\(RowInvariantMatmul.calls) matmuls)", RowInvariantMatmul.calls > 0)
                for k in 2 ... maxBatch {
                    let d = exactDiff[k] ?? .infinity, f = exactFlips[k] ?? -1
                    check(String(format: "k=%d row 0 equals the one-row pass bit for bit over %d positions "
                        + "(max deviation %.3g of the logit spread, %d top-1 flips; stock %.3g, %d flips)",
                        k, positions, d, f, stockDiff[k] ?? 0, stockFlips[k] ?? 0), d == 0 && f == 0)
                }
                if failures.isEmpty { print("MTP ROWCHECK PASS") }
                else { throw ModelError("MTP ROWCHECK FAIL: " + failures.joined(separator: "; ")) }
            } catch { result = .failure(error) }
            sem.signal()
        }
        sem.wait()
        try result.get()
    }
}
'''
(root / C).write_text(s)
print("appended MTPRowCheck")

edit("Sources/slotstream-cli/main.swift", [
("MTPParity.self, MTPAccept.self, MTPCheck.self, MTPFixtureInputs.self, MTPBench.self, MTPPassCost.self,",
 "MTPParity.self, MTPAccept.self, MTPCheck.self, MTPRowCheck.self, MTPFixtureInputs.self, MTPBench.self, MTPPassCost.self,"),
])

edit("Tools/verify.sh", [
('''  then
    echo "PASS  speculative decode gates (determinism, state integrity, accept sanity)"; PASS=$((PASS+1))
  else
    echo "FAIL  speculative decode gates"; tail -5 "$VERIFY_OUT/mtp.txt"; FAIL=$((FAIL+1))
  fi
''',
'''  then
    echo "PASS  speculative decode gates (determinism, state integrity, accept sanity)"; PASS=$((PASS+1))
  else
    echo "FAIL  speculative decode gates"; tail -5 "$VERIFY_OUT/mtp.txt"; FAIL=$((FAIL+1))
  fi
  # With the split verify attention and row-invariant projections on, a
  # multi-row verify pass must reproduce the one-row pass bit for bit (the
  # stock deviation is reported alongside). The prompt sits above the indexer
  # budget so a real block selection is active.
  check "verify pass rows equal plain decode bit for bit (mtp-rowcheck)" \\
        "run_binary mtp-rowcheck --memory-gb $BIG_MEMORY"
'''),
])
print("done")
