#!/bin/zsh
# Dispatch census of greedy decode with the draft head: prefill-only baseline, then 128 tokens.
set -u
BIN=~/Projects/slotstream/.build/release/slotstream
S=/private/tmp/claude-502/-Users-carlos-Projects-command-center/feaf9fde-de0a-4056-840e-9d376cff840f/scratchpad
C=$S/census
MEM=${MEM:-15}
PROMPT="Explain how a transistor works, in about 300 words."
for T in 1 129; do
  echo "== census max-tokens $T $(date +%H:%M:%S)"
  DYLD_INSERT_LIBRARIES=$C/census_mrc.dylib SLOTSTREAM_CENSUS_OUT=$C/counts_$T.txt SLOTSTREAM_CENSUS_TIMELINE=$C/timeline_$T.txt \
    $BIN run --memory-gb $MEM --greedy --max-tokens $T --prompt "$PROMPT" --stats-json $C/stats_${TAG:-}$T.json 2>&1 | grep -v "^\s*$" | tail -12
done
