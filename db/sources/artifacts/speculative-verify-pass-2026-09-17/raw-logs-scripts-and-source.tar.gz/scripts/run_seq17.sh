#!/bin/zsh
# After seq16: the full verification battery on the frozen final build.
# Starts on a quiet machine; yields only to other sessions' model-using gates
# (a build beside it slows it but cannot change its equality checks).
LOG=/private/tmp/claude-502/-Users-carlos-Projects-command-center/feaf9fde-de0a-4056-840e-9d376cff840f/scratchpad/seq17.log
source /private/tmp/claude-502/-Users-carlos-Projects-command-center/feaf9fde-de0a-4056-840e-9d376cff840f/scratchpad/qsteps2.sh
REPO=~/Projects/slotstream
FROZEN=$REPO/.build/frozen-verify-pass-8d86f10f/slotstream
while pgrep -f "run_seq16.sh" >/dev/null; do sleep 20; done
echo "#### seq17 start $(date +%H:%M:%S); frozen binary $(shasum -a 256 $FROZEN | cut -c1-16)" | tee -a $LOG
other() { pgrep -fl "sevra-mac-checks|check_sevra|launch_start_gate|coding_agents_gate" | head -1 | cut -c1-80; }
step "verify battery" 21 zsh -c "cd $REPO && SLOTSTREAM_TEST_BINARY=$FROZEN SLOTSTREAM_VERIFY_OUT=$REPO/.build/verification-verify-pass-final Tools/verify.sh; echo battery-exit \$?"
echo "#### seq17 done $(date +%H:%M:%S)" | tee -a $LOG
