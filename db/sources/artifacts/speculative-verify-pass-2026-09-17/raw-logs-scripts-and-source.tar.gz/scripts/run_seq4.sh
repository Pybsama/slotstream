#!/bin/zsh
source /private/tmp/claude-502/-Users-carlos-Projects-command-center/feaf9fde-de0a-4056-840e-9d376cff840f/scratchpad/qsteps.sh
BIN=~/Projects/slotstream/.build/release/slotstream
step "rung 8192 row-invariant" 13 env SLOTSTREAM_OPT_ROW_INVARIANT=1 $BIN mtp-passcost --memory-gb 13 --max-context 16384 \
  --prompt-file $S/prompt_8192.txt --positions 4 --max-batch 3 --max-tokens 48 --attention-modes stock,split || exit 1
step "fused read A/B 4096" 13 $BIN mtp-passcost --memory-gb 13 --max-context 8192 \
  --prompt-file $S/prompt_4096.txt --positions 8 --max-batch 3 --max-tokens 64 --attention-modes stock,stock-hc,split,split-hc || exit 1
step "fused read A/B 16384" 13 $BIN mtp-passcost --memory-gb 13 --max-context 32768 \
  --prompt-file $S/prompt_16384.txt --positions 8 --max-batch 3 --max-tokens 64 --attention-modes stock,stock-hc,split,split-hc || exit 1
echo "#### seq4 done $(date +%H:%M:%S)" | tee -a $LOG
