#!/bin/zsh
# Battery first on the frozen final build, then the remaining pricing rungs
# and the 32k decode comparison. The battery yields only to other sessions'
# model-using gates; the timed rungs also yield to builds.
LOG=/private/tmp/claude-502/-Users-carlos-Projects-command-center/feaf9fde-de0a-4056-840e-9d376cff840f/scratchpad/seq18.log
source /private/tmp/claude-502/-Users-carlos-Projects-command-center/feaf9fde-de0a-4056-840e-9d376cff840f/scratchpad/qsteps2.sh
REPO=~/Projects/slotstream
BIN=$REPO/.build/release/slotstream
FROZEN=$REPO/.build/frozen-verify-pass-8d86f10f/slotstream
therm() { echo "#### therm $(pmset -g therm 2>/dev/null | grep -i 'level' | tr '\n' ' ')" | tee -a $LOG; }
echo "#### seq18 start $(date +%H:%M:%S); frozen binary $(shasum -a 256 $FROZEN | cut -c1-16)" | tee -a $LOG
strict() { pgrep -fl "swift-build|swift-frontend|xcodebuild|sevra-mac-checks|check_sevra|launch_start_gate|coding_agents_gate" | head -1 | cut -c1-80; }
gates() { pgrep -fl "sevra-mac-checks|check_sevra|launch_start_gate|coding_agents_gate" | head -1 | cut -c1-80; }
other() { gates; }
step "verify battery" 21 zsh -c "cd $REPO && SLOTSTREAM_TEST_BINARY=$FROZEN SLOTSTREAM_VERIFY_OUT=$REPO/.build/verification-verify-pass-final Tools/verify.sh; echo battery-exit \$?"
therm
other() { strict; }
step "pricing 4096b modes run 2" 13 $BIN mtp-passcost --memory-gb 13 --max-context 8192 \
  --prompt-file $S/prompt_4096b.txt --positions 6 --max-batch 3 --max-tokens 64 --attention-modes stock,split,exact
step "pricing 16384b modes" 13 $BIN mtp-passcost --memory-gb 13 --max-context 32768 \
  --prompt-file $S/prompt_16384b.txt --positions 6 --max-batch 3 --max-tokens 64 --attention-modes stock,split,exact
therm
step "decode A/B 32k at 22 GB, dense spec" 22 env SLOTSTREAM_OPT_VERIFY_SPLIT=0 $BIN mtp-bench --memory-gb 22 \
  --max-context 33024 --prompt-file $S/prompt_32768.txt --max-tokens 128 --pairs 2 --arms spec,split
therm
echo "#### seq18 done $(date +%H:%M:%S)" | tee -a $LOG
