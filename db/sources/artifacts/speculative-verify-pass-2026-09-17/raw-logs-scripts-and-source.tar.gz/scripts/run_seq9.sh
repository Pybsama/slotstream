#!/bin/zsh
# After seq7 and seq8: the decode comparison at 32k, shipped verify pass
# against the split, at the default 22 GB profile with a window just above
# the prompt (draft head on, 76 experts per layer).
LOG=/private/tmp/claude-502/-Users-carlos-Projects-command-center/feaf9fde-de0a-4056-840e-9d376cff840f/scratchpad/seq9.log
source /private/tmp/claude-502/-Users-carlos-Projects-command-center/feaf9fde-de0a-4056-840e-9d376cff840f/scratchpad/qsteps2.sh
BIN=~/Projects/slotstream/.build/release/slotstream
while pgrep -f "run_seq7.sh|run_seq8.sh" >/dev/null; do sleep 30; done
echo "#### seq9 start $(date +%H:%M:%S); binary $(shasum -a 256 $BIN | cut -c1-16)" | tee -a $LOG
step "decode A/B 32k at 22 GB" 22 $BIN mtp-bench --memory-gb 22 --max-context 33024 \
  --prompt-file $S/prompt_32768.txt --max-tokens 128 --pairs 2 --arms spec,split
echo "#### seq9 done $(date +%H:%M:%S)" | tee -a $LOG
