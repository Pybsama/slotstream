#!/bin/zsh
# Wait until no slotstream model process and no swift build has been seen for QUIET seconds, then run
# the dispatch census and the row-0 consistency rung. Never touches another task's process.
set -u
S=/private/tmp/claude-502/-Users-carlos-Projects-command-center/feaf9fde-de0a-4056-840e-9d376cff840f/scratchpad
QUIET=${QUIET:-900}
LOG=$S/quiet_then_run.log
last_busy=$(date +%s)
echo "watcher start $(date +%H:%M:%S), quiet window $QUIET s" | tee -a $LOG
while true; do
  if pgrep -f "slotstream (serve|run|mtp-|prefix-check|context-check|sweep-check|parity|optimization-state-check|elastic|verify)" >/dev/null || pgrep -f "swift-build|swift-frontend" >/dev/null || [ -n "$(lsof /private/tmp/slotstream-model-502.lock 2>/dev/null | tail -n +2)" ]; then
    last_busy=$(date +%s)
  fi
  if (( $(date +%s) - last_busy >= QUIET )); then break; fi
  sleep 20
done
echo "quiet since $(date -r $last_busy +%H:%M:%S); starting at $(date +%H:%M:%S)" | tee -a $LOG
R=$(vm_stat | awk '/free|purgeable|File-backed/ {gsub(/\./,""); p[$1$2]=$NF} END {printf "%.1f", (p["Pagesfree:"]+p["Pagespurgeable:"]+p["File-backedpages:"])*16384/1073741824}')
echo "reclaimable $R GB" | tee -a $LOG
if (( $(echo "$R < 18" | bc -l) )); then echo "too little reclaimable memory; not starting" | tee -a $LOG; exit 1; fi
MEM=15 $S/run_census.sh > $S/census/run_census.log 2>&1; echo "census exit $?" | tee -a $LOG
MEM=15 POS=4 RUNGS="4096 16384" $S/run_passcost_rungs.sh > $S/row0_rungs.log 2>&1; echo "row0 rungs exit $?" | tee -a $LOG
echo "done $(date +%H:%M:%S)" | tee -a $LOG
