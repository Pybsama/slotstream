#!/bin/zsh
# After seq9: the final row-invariant form priced at 4k, off and on twice,
# with the prompt whose reply is long enough for six positions.
LOG=/private/tmp/claude-502/-Users-carlos-Projects-command-center/feaf9fde-de0a-4056-840e-9d376cff840f/scratchpad/seq10.log
source /private/tmp/claude-502/-Users-carlos-Projects-command-center/feaf9fde-de0a-4056-840e-9d376cff840f/scratchpad/qsteps2.sh
BIN=~/Projects/slotstream/.build/release/slotstream
while pgrep -f "run_seq7.sh|run_seq8.sh|run_seq9.sh" >/dev/null; do sleep 30; done
echo "#### seq10 start $(date +%H:%M:%S); binary $(shasum -a 256 $BIN | cut -c1-16)" | tee -a $LOG
for arm in off on off on; do
  if [ $arm = on ]; then E=SLOTSTREAM_OPT_ROW_INVARIANT=1; else E=SLOTSTREAM_OPT_ROW_INVARIANT=0; fi
  step "rung 4096b row-invariant $arm" 13 env $E $BIN mtp-passcost --memory-gb 13 --max-context 8192 \
    --prompt-file $S/prompt_4096b.txt --positions 6 --max-batch 3 --max-tokens 64 --attention-modes stock,split
done
echo "#### seq10 done $(date +%H:%M:%S)" | tee -a $LOG
