#!/bin/zsh
# Quiet-gated, yielding steps. Busy: a build, a Sevra Mac check, any process
# holding the Slotstream model lock, or a 1-minute load at or above 3.0. A
# step starts after three consecutive quiet 30 s checks and refuses without
# target + 3 GB reclaimable. If a build or a Sevra Mac check starts while a
# step runs, the step's process is stopped at once (its timings would be
# contaminated and it would hold the model lock the other check needs) and the
# step is retried after the next quiet window, up to six attempts.
set -u
S=/private/tmp/claude-502/-Users-carlos-Projects-command-center/feaf9fde-de0a-4056-840e-9d376cff840f/scratchpad
LOG=${LOG:-$S/seq7.log}
LOCK=/tmp/slotstream-model-$(id -u).lock
reclaimable() { vm_stat | awk '/free|purgeable|File-backed/ {gsub(/\./,""); p[$1$2]=$NF} END {printf "%.1f", (p["Pagesfree:"]+p["Pagespurgeable:"]+p["File-backedpages:"])*16384/1073741824}'; }
other() { pgrep -fl "swift-build|swift-frontend|xcodebuild|sevra-mac-checks|check_sevra|launch_start_gate|coding_agents_gate|verify.sh" | head -1 | cut -c1-80; }
busy() {
  [ -n "$(other)" ] && return 0
  pgrep -f "clang|slotstream (serve|run|mtp-|context-check|prefix-check|sweep-check|optimization)" >/dev/null && return 0
  [ -n "$(lsof -t $LOCK 2>/dev/null)" ] && return 0
  return 1
}
wait_quiet() {
  local quiet=0 waited=0 load
  while (( quiet < 3 )); do
    load=$(sysctl -n vm.loadavg | awk '{print $2}')
    if busy || (( $(echo "$load >= 3.0" | bc -l) )); then quiet=0; else quiet=$((quiet+1)); fi
    sleep 30; waited=$((waited+30))
    if (( waited >= 14400 )); then echo "#### no quiet machine after 4 h (load $load); stop" | tee -a $LOG; exit 1; fi
  done
  echo "#### quiet (load $load) after ${waited}s at $(date +%H:%M:%S)" | tee -a $LOG
}
step() { # label, target GB, command...
  local label=$1 mem=$2; shift 2
  local attempt=0 rc=0
  while (( attempt < 6 )); do
    attempt=$((attempt+1))
    wait_quiet
    local R=$(reclaimable)
    echo "== $label (attempt $attempt) $(date +%H:%M:%S) reclaimable $R GB target $mem GB load $(sysctl -n vm.loadavg) $(sysctl -n vm.swapusage)" | tee -a $LOG
    if (( $(echo "$R < $mem + 3" | bc -l) )); then echo "not enough reclaimable memory; waiting again" | tee -a $LOG; sleep 300; continue; fi
    "$@" >> $LOG 2>&1 &
    local pid=$! yielded=""
    while kill -0 $pid 2>/dev/null; do
      local who=$(other)
      if [ -n "$who" ]; then
        yielded=$who
        pkill -TERM -P $pid 2>/dev/null; kill -TERM $pid 2>/dev/null
        break
      fi
      sleep 2
    done
    wait $pid 2>/dev/null; rc=$?
    # Another session took the model slot between the quiet check and launch.
    if [ $rc -ne 0 ] && tail -5 $LOG | grep -q "another Slotstream model process is already running"; then
      yielded="model lock taken at launch"
    fi
    if [ -n "$yielded" ]; then
      # make sure nothing of this step still holds the model lock
      for i in $(seq 1 30); do [ -z "$(lsof -t $LOCK 2>/dev/null | xargs -I{} ps -o command= -p {} | grep -F "$S" )" ] && break; sleep 1; done
      echo "#### yielded $label at $(date +%H:%M:%S) to: $yielded; discarded, will retry" | tee -a $LOG
      continue
    fi
    echo "== $label exit $rc $(date +%H:%M:%S) load $(sysctl -n vm.loadavg)" | tee -a $LOG
    return $rc
  done
  echo "#### $label: gave up after $attempt attempts" | tee -a $LOG
  return 1
}
