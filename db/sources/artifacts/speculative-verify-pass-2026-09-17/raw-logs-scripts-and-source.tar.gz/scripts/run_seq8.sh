#!/bin/zsh
# After seq7: the fused-read comparison at 4k with a prompt whose reply is long
# enough for eight positions, and at 16k again if seq7's 16k step failed.
LOG=/private/tmp/claude-502/-Users-carlos-Projects-command-center/feaf9fde-de0a-4056-840e-9d376cff840f/scratchpad/seq8.log
source /private/tmp/claude-502/-Users-carlos-Projects-command-center/feaf9fde-de0a-4056-840e-9d376cff840f/scratchpad/qsteps2.sh
BIN=~/Projects/slotstream/.build/release/slotstream
while pgrep -f run_seq7.sh >/dev/null; do sleep 30; done
echo "#### seq8 start $(date +%H:%M:%S); binary $(shasum -a 256 $BIN | cut -c1-16)" | tee -a $LOG
step "fused read A/B 4096b" 13 $BIN mtp-passcost --memory-gb 13 --max-context 8192 \
  --prompt-file $S/prompt_4096b.txt --positions 8 --max-batch 3 --max-tokens 64 --attention-modes stock,stock-hc,split,split-hc
if ! grep -q "== fused read A/B 16384 exit 0" $S/seq7.log; then
  step "fused read A/B 16384b" 13 $BIN mtp-passcost --memory-gb 13 --max-context 32768 \
    --prompt-file $S/prompt_16384b.txt --positions 8 --max-batch 3 --max-tokens 64 --attention-modes stock,stock-hc,split,split-hc
fi
echo "#### seq8 done $(date +%H:%M:%S)" | tee -a $LOG
