#!/bin/zsh
# Verify-pass cost by context and multi-row attention mode, one rung per context.
# Preflight: no other model process, reclaimable memory >= target + 4 GB.
set -u
set -o pipefail
BIN=~/Projects/slotstream/.build/release/slotstream
S=/private/tmp/claude-502/-Users-carlos-Projects-command-center/feaf9fde-de0a-4056-840e-9d376cff840f/scratchpad
MEM=${MEM:-16}
POS=${POS:-4}
MODES=${MODES:-stock,split,gather}
LOG=${LOG:-$S/passcost_rungs.log}
reclaimable() { vm_stat | awk '/free|purgeable|File-backed/ {gsub(/\./,""); p[$1$2]=$NF} END {printf "%.1f", (p["Pagesfree:"]+p["Pagespurgeable:"]+p["File-backedpages:"])*16384/1073741824}'; }
for N in ${=RUNGS:-4096 16384 32768 65536}; do
  if pgrep -f "slotstream (serve|run|mtp-|context-check)" >/dev/null; then echo "another model process is running; stop" | tee -a $LOG; exit 1; fi
  R=$(reclaimable)
  echo "== rung $N tokens, $(date +%H:%M:%S), reclaimable $R GB, target $MEM GB" | tee -a $LOG
  if (( $(echo "$R < $MEM + 3" | bc -l) )); then echo "not enough reclaimable memory; stop" | tee -a $LOG; exit 1; fi
  WIN=32768; (( N > 30000 )) && WIN=65536; (( N > 62000 )) && WIN=70000
  $BIN mtp-passcost --memory-gb $MEM --max-context $WIN --prompt-file $S/prompt_$N.txt \
       --positions $POS --max-batch 3 --max-tokens 48 --attention-modes $MODES 2>&1 | tee -a $LOG
  if [[ ${pipestatus[1]} -ne 0 ]]; then echo "rung $N failed; stop" | tee -a $LOG; exit 1; fi
  echo "== rung $N done $(date +%H:%M:%S)" | tee -a $LOG
done
