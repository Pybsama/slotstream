#!/bin/zsh
# Each step waits for a quiet machine (no build or model process, 1-minute load
# under 2.5 for three consecutive 30 s checks; gives up after 60 min).
set -u
set -o pipefail
BIN=~/Projects/slotstream/.build/release/slotstream
S=/private/tmp/claude-502/-Users-carlos-Projects-command-center/feaf9fde-de0a-4056-840e-9d376cff840f/scratchpad
LOG=$S/seq3.log
reclaimable() { vm_stat | awk '/free|purgeable|File-backed/ {gsub(/\./,""); p[$1$2]=$NF} END {printf "%.1f", (p["Pagesfree:"]+p["Pagespurgeable:"]+p["File-backedpages:"])*16384/1073741824}'; }
busy() { pgrep -f "swift-build|swift-frontend|clang|xcodebuild|slotstream (serve|run|mtp-|context-check|prefix-check|sweep-check|optimization)" >/dev/null; }
wait_quiet() {
  local quiet=0 waited=0 load
  while (( quiet < 3 )); do
    load=$(sysctl -n vm.loadavg | awk '{print $2}')
    if busy || (( $(echo "$load >= 3.0" | bc -l) )); then quiet=0; else quiet=$((quiet+1)); fi
    sleep 30; waited=$((waited+30))
    if (( waited >= 3600 )); then echo "#### no quiet machine after 60 min (load $load); stop" | tee -a $LOG; exit 1; fi
  done
  echo "#### quiet (load $load) after ${waited}s at $(date +%H:%M:%S)" | tee -a $LOG
}
step() { # label, target GB, command...
  local label=$1 mem=$2; shift 2
  wait_quiet
  local R=$(reclaimable)
  echo "== $label $(date +%H:%M:%S) reclaimable $R GB target $mem GB load $(sysctl -n vm.loadavg) $(sysctl -n vm.swapusage)" | tee -a $LOG
  if (( $(echo "$R < $mem + 3" | bc -l) )); then echo "not enough reclaimable memory; stop" | tee -a $LOG; exit 1; fi
  ( while true; do
      local who=$(pgrep -fl "swift-build|swift-frontend|clang|xcodebuild" | head -1 | cut -c1-80)
      [ -n "$who" ] && echo "#### interference during $label at $(date +%H:%M:%S): $who" >> $LOG
      sleep 5
    done ) &
  local watcher=$!
  "$@" 2>&1 | tee -a $LOG
  local rc=${pipestatus[1]}
  kill $watcher 2>/dev/null
  echo "== $label exit $rc $(date +%H:%M:%S) load $(sysctl -n vm.loadavg)" | tee -a $LOG
  return $rc
}
step "gate mtp-rowcheck 10 GB" 10 $BIN mtp-rowcheck --memory-gb 10 || exit 1
step "rung 8192 row-invariant" 13 env SLOTSTREAM_OPT_ROW_INVARIANT=1 $BIN mtp-passcost --memory-gb 13 --max-context 16384 \
  --prompt-file $S/prompt_8192.txt --positions 4 --max-batch 3 --max-tokens 48 --attention-modes stock,split || exit 1
step "fused read A/B 4096" 13 $BIN mtp-passcost --memory-gb 13 --max-context 8192 \
  --prompt-file $S/prompt_4096.txt --positions 8 --max-batch 3 --max-tokens 64 --attention-modes stock,stock-hc,split,split-hc || exit 1
step "fused read A/B 16384" 13 $BIN mtp-passcost --memory-gb 13 --max-context 32768 \
  --prompt-file $S/prompt_16384.txt --positions 8 --max-batch 3 --max-tokens 64 --attention-modes stock,stock-hc,split,split-hc || exit 1
echo "#### seq3 done $(date +%H:%M:%S)" | tee -a $LOG
