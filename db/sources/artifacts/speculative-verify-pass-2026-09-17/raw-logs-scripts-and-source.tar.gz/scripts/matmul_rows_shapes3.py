import mlx.core as mx
shapes = [("gdn in_proj bf16 2560x48", mx.bfloat16, 2560, 48),
          ("inject bf16 10240x4", mx.bfloat16, 10240, 4),
          ("indexer qk bf16 2560x640", mx.bfloat16, 2560, 640),
          ("router fp32 2560x512", mx.float32, 2560, 512)]
def heavy(shape, key):
    a, b = mx.random.split(key)
    return mx.random.normal(shape, key=a) * mx.exp(mx.random.normal(shape, key=b) * 1.5)
for label, dt, k, n in shapes:
    for kind in ["normal", "heavy"]:
        counts = {"stock": 0, "gather": 0, "gather_vs_sliced": 0, "sliced_vs_contig": 0}
        trials = 0
        for seed in range(20):
            kw, kx = mx.random.split(mx.random.key(seed))
            gen = (lambda s, kk: mx.random.normal(s, key=kk)) if kind == "normal" else heavy
            w = (gen((n, k), kw) * 0.05).astype(dt)
            wt = w.T
            for rows in [2, 3, 4, 8]:
                rows_list = [gen((1, 1, k), mx.random.key(1000 * seed + 10 * rows + r)).astype(dt) for r in range(rows)]
                x = mx.concatenate(rows_list, axis=1)
                mx.eval(x, w)
                contig = mx.concatenate([rr @ wt for rr in rows_list], axis=1)          # engine-like one-row inputs
                sliced = mx.concatenate([x[:, r:r+1] @ wt for r in range(rows)], axis=1)
                many = x @ wt
                gm = mx.gather_mm(x.reshape(rows, 1, k), wt.reshape(1, k, n),
                                  mx.arange(rows, dtype=mx.uint32), mx.zeros(rows, dtype=mx.uint32)).reshape(1, rows, n)
                mx.eval(contig, sliced, many, gm)
                trials += 1
                counts["stock"] += int(not mx.array_equal(many, contig).item())
                counts["gather"] += int(not mx.array_equal(gm, contig).item())
                counts["gather_vs_sliced"] += int(not mx.array_equal(gm, sliced).item())
                counts["sliced_vs_contig"] += int(not mx.array_equal(sliced, contig).item())
        print(f"{label:26s} {kind:6s} {trials} trials, rows differing from contiguous one-row passes: " + ", ".join(f"{k} {v}" for k, v in counts.items()))
