#!/bin/zsh
LOG=/private/tmp/claude-502/-Users-carlos-Projects-command-center/feaf9fde-de0a-4056-840e-9d376cff840f/scratchpad/seq11.log
source /private/tmp/claude-502/-Users-carlos-Projects-command-center/feaf9fde-de0a-4056-840e-9d376cff840f/scratchpad/qsteps2.sh
while pgrep -f "run_seq7.sh|run_seq8.sh|run_seq9.sh|run_seq10.sh" >/dev/null; do sleep 30; done
echo "#### seq11 start $(date +%H:%M:%S)" | tee -a $LOG
step "python dense matmul row invariance" 2 zsh -c "cd ~/Projects/slotstream && for f in matmul_rows_shapes2 matmul_rows_shapes3 matmul_rows_shapes4; do echo \"-- \$f\"; .venv31/bin/python $S/\$f.py; done"
echo "#### seq11 done $(date +%H:%M:%S)" | tee -a $LOG
