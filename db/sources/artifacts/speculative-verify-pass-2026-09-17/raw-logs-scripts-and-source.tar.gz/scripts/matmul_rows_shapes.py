"""Which small dense matmuls change bits between one row and several rows?
Shapes of the engine's router (fp32 2560->512) and hyper-connection
projections (bf16 10240->320, 320->10240, 10240->4). Values: normal, and
heavy-tailed (normal times a log-normal scale, like residual streams)."""
import mlx.core as mx
mx.random.seed(7)
shapes = [("router fp32 2560x512", mx.float32, 2560, 512),
          ("hc down bf16 10240x320", mx.bfloat16, 10240, 320),
          ("hc up bf16 320x10240", mx.bfloat16, 320, 10240),
          ("hc inject bf16 10240x4", mx.bfloat16, 10240, 4)]
def heavy(shape):
    return mx.random.normal(shape) * mx.exp(mx.random.normal(shape) * 1.5)
for label, dt, k, n in shapes:
    for kind, gen in [("normal", mx.random.normal), ("heavy", heavy)]:
        w = (gen((n, k)) * 0.05).astype(dt)
        worst = {}
        for rows in [2, 3, 8]:
            x = gen((1, rows, k)).astype(dt)
            many = x @ w.T
            one = mx.concatenate([x[:, r:r+1] @ w.T for r in range(rows)], axis=1)
            gm = mx.gather_mm(x.reshape(rows, 1, k), w.T.reshape(1, k, n),
                              mx.arange(rows, dtype=mx.uint32), mx.zeros(rows, dtype=mx.uint32)).reshape(1, rows, n)
            mx.eval(many, one, gm)
            worst[rows] = (mx.abs(many.astype(mx.float32) - one.astype(mx.float32)).max().item(),
                           mx.abs(gm.astype(mx.float32) - one.astype(mx.float32)).max().item())
        print(f"{label:24s} {kind:6s} " + "  ".join(f"rows {r}: stock {a:.3g} row-path {b:.3g}" for r, (a, b) in worst.items()))
