import mlx.core as mx
shapes = [("router fp32 2560x512", mx.float32, 2560, 512),
          ("gdn in_proj_a/b bf16 2560x48", mx.bfloat16, 2560, 48),
          ("shared gate bf16 2560x1", mx.bfloat16, 2560, 1),
          ("indexer qk bf16 2560x640", mx.bfloat16, 2560, 640),
          ("inject bf16 10240x4", mx.bfloat16, 10240, 4)]
def heavy(shape, key):
    a, b = mx.random.split(key)
    return mx.random.normal(shape, key=a) * mx.exp(mx.random.normal(shape, key=b) * 1.5)
def normal(shape, key):
    return mx.random.normal(shape, key=key)
for label, dt, k, n in shapes:
    for kind, gen in [("normal", normal), ("heavy", heavy)]:
        stock_bad = row_bad = 0; stock_max = row_max = 0.0; trials = 0
        for seed in range(20):
            key = mx.random.key(seed)
            kw, kx = mx.random.split(key)
            w = (gen((n, k), kw) * 0.05).astype(dt)
            for rows in [2, 3, 4, 8]:
                x = gen((1, rows, k), mx.random.fold_in(kx, rows) if hasattr(mx.random, "fold_in") else mx.random.key(seed * 31 + rows)).astype(dt)
                many = x @ w.T
                one = mx.concatenate([x[:, r:r+1] @ w.T for r in range(rows)], axis=1)
                gm = mx.gather_mm(x.reshape(rows, 1, k), w.T.reshape(1, k, n),
                                  mx.arange(rows, dtype=mx.uint32), mx.zeros(rows, dtype=mx.uint32)).reshape(1, rows, n)
                a = mx.abs(many.astype(mx.float32) - one.astype(mx.float32)).max().item()
                b = mx.abs(gm.astype(mx.float32) - one.astype(mx.float32)).max().item()
                trials += 1
                stock_bad += a > 0; row_bad += b > 0
                stock_max = max(stock_max, a); row_max = max(row_max, b)
        print(f"{label:30s} {kind:6s} trials {trials}: stock differs {stock_bad} (max {stock_max:.3g}); row path differs {row_bad} (max {row_max:.3g})")
