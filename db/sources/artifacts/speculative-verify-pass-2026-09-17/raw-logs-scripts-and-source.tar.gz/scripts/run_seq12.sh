#!/bin/zsh
# After seq9: build the final binary once nothing else builds or checks, save
# its identity, then (1) price the row-invariant mode at 4k, off and on twice,
# (2) run the Python dense-matmul invariance scripts, (3) run the T0/T1 check
# catalogue on the final binary. Every model step is quiet-gated and yields.
LOG=/private/tmp/claude-502/-Users-carlos-Projects-command-center/feaf9fde-de0a-4056-840e-9d376cff840f/scratchpad/seq12.log
source /private/tmp/claude-502/-Users-carlos-Projects-command-center/feaf9fde-de0a-4056-840e-9d376cff840f/scratchpad/qsteps2.sh
REPO=~/Projects/slotstream
BIN=$REPO/.build/release/slotstream
while pgrep -f "run_seq9.sh" >/dev/null; do sleep 15; done
echo "#### seq12 start $(date +%H:%M:%S)" | tee -a $LOG
# the build: wait only for other builds, checks and model-lock holders
while [ -n "$(other)" ] || [ -n "$(lsof -t $LOCK 2>/dev/null)" ]; do sleep 20; done
echo "== final build $(date +%H:%M:%S) load $(sysctl -n vm.loadavg)" | tee -a $LOG
(cd $REPO && SLOTSTREAM_BUILD_JOBS=4 make build) > $S/build_final.log 2>&1
rc=$?
echo "== final build exit $rc $(date +%H:%M:%S)" | tee -a $LOG
tail -3 $S/build_final.log | tee -a $LOG
if [ $rc -ne 0 ]; then echo "#### build failed; stop" | tee -a $LOG; exit 1; fi
SHA=$(shasum -a 256 $BIN | cut -c1-16)
REL=$(cd $REPO && swift build -c release --show-bin-path)
D=$S/identities/$SHA; mkdir -p $D
cp $REL/build-identity.json $REL/build-source.tar.gz $D/
(cd $REPO && git diff > $D/working-tree.diff && git ls-files --others --exclude-standard -z | xargs -0 tar czf $D/untracked.tar.gz)
echo "#### final binary $SHA; identity saved to identities/$SHA" | tee -a $LOG
for arm in off on off on; do
  if [ $arm = on ]; then E=SLOTSTREAM_OPT_ROW_INVARIANT=1; else E=SLOTSTREAM_OPT_ROW_INVARIANT=0; fi
  step "rung 4096b row-invariant $arm" 13 env $E $BIN mtp-passcost --memory-gb 13 --max-context 8192 \
    --prompt-file $S/prompt_4096b.txt --positions 6 --max-batch 3 --max-tokens 64 --attention-modes stock,split
done
step "python dense matmul row invariance" 2 zsh -c "cd $REPO && for f in matmul_rows_shapes2 matmul_rows_shapes3 matmul_rows_shapes4; do echo \"-- \$f\"; .venv31/bin/python $S/\$f.py; done"
step "check catalogue t0+t1 on $SHA" 2 zsh -c "cd $REPO && .build/release/slotstream-checks --tier t0 --tier t1; echo catalogue-exit \$?"
echo "#### seq12 done $(date +%H:%M:%S)" | tee -a $LOG
