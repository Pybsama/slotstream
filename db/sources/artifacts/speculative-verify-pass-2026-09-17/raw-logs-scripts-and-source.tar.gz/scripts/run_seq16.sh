#!/bin/zsh
# Final binary 8d86f10f: pricing of the stock, split and exact passes at 4k
# (twice) and 16k, the Python kernel scripts, the T0/T1 catalogue, then the
# 32k decode comparison. Every model step waits for a quiet machine and for
# other sessions' builds, app checks and serve gates, and yields to them.
LOG=/private/tmp/claude-502/-Users-carlos-Projects-command-center/feaf9fde-de0a-4056-840e-9d376cff840f/scratchpad/seq16.log
source /private/tmp/claude-502/-Users-carlos-Projects-command-center/feaf9fde-de0a-4056-840e-9d376cff840f/scratchpad/qsteps2.sh
REPO=~/Projects/slotstream
BIN=$REPO/.build/release/slotstream
therm() { echo "#### therm $(pmset -g therm 2>/dev/null | grep -i 'level' | tr '\n' ' ')" | tee -a $LOG; }
echo "#### seq16 start $(date +%H:%M:%S); binary $(shasum -a 256 $BIN | cut -c1-16)" | tee -a $LOG
therm
for i in 1 2; do
  step "pricing 4096b modes run $i" 13 $BIN mtp-passcost --memory-gb 13 --max-context 8192 \
    --prompt-file $S/prompt_4096b.txt --positions 6 --max-batch 3 --max-tokens 64 --attention-modes stock,split,exact
done
step "pricing 16384b modes" 13 $BIN mtp-passcost --memory-gb 13 --max-context 32768 \
  --prompt-file $S/prompt_16384b.txt --positions 6 --max-batch 3 --max-tokens 64 --attention-modes stock,split,exact
therm
step "python dense matmul row invariance" 2 zsh -c "cd $REPO && for f in matmul_rows_shapes2 matmul_rows_shapes3 matmul_rows_shapes4; do echo \"-- \$f\"; .venv31/bin/python $S/\$f.py; done"
step "check catalogue t0+t1" 2 zsh -c "cd $REPO && .build/release/slotstream-checks --tier t0 --tier t1; echo catalogue-exit \$?"
step "decode A/B 32k at 22 GB, dense spec" 22 env SLOTSTREAM_OPT_VERIFY_SPLIT=0 $BIN mtp-bench --memory-gb 22 \
  --max-context 33024 --prompt-file $S/prompt_32768.txt --max-tokens 128 --pairs 2 --arms spec,split
therm
echo "#### seq16 done $(date +%H:%M:%S)" | tee -a $LOG
