#!/bin/zsh
# Phase A: 4k with the row-invariant path off (baseline at this target/window).
# Phase B: crossover rungs with the row-invariant path on.
# Phase C: 4k and 16k with the fused hyper-connection read on top.
set -u
S=/private/tmp/claude-502/-Users-carlos-Projects-command-center/feaf9fde-de0a-4056-840e-9d376cff840f/scratchpad
export LOG=$S/rungs2.log MEM=13 POS=4 MODES=stock,split
echo "#### phase A $(date +%H:%M:%S)" >> $LOG
RUNGS="4096" $S/run_rungs2.sh || { echo "#### phase A failed" >> $LOG; exit 1; }
echo "#### phase B $(date +%H:%M:%S)" >> $LOG
SLOTSTREAM_OPT_ROW_INVARIANT=1 RUNGS="4096 6144 8192 12288 16384" $S/run_rungs2.sh || { echo "#### phase B failed" >> $LOG; exit 1; }
echo "#### phase C $(date +%H:%M:%S)" >> $LOG
SLOTSTREAM_OPT_ROW_INVARIANT=1 SLOTSTREAM_OPT_COMPILED_HC=1 RUNGS="4096 16384" $S/run_rungs2.sh || { echo "#### phase C failed" >> $LOG; exit 1; }
echo "#### all phases done $(date +%H:%M:%S)" >> $LOG
