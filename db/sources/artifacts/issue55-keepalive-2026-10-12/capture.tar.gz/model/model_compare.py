#!/usr/bin/env python3
"""Issue 55: exact installed binary, fresh processes, paired keepalive A/B.

Memory 8.1 GB, 64 greedy tokens, MTP/vision off, 8192 context. This is
deliberately smaller than the reporter's auto plan. No page-cache purge.
Six pairs (three rounds, two report prompts), rotated AB/BA. Preserve all
runs, exclude paging, non-nominal thermals, incomplete or unequal outputs.
"""
import sys, os, json, time, subprocess, shutil, statistics
from pathlib import Path
ROOT = Path('/Users/carlos/Projects/slotstream')
sys.path.insert(0, str(ROOT/'Tools'))
from prefill_bench import digest, vm_snapshot, preflight, host_conditions, model_identity, terminate_child_tree, validate_metrics
from thermal_readiness import observe

BASE = Path(__file__).resolve().parent
OUT = BASE/'model'
BINARY = Path.home()/'.slotstream/bin/slotstream'
MODEL = Path.home()/'.slotstream/models/qwen38-flash-next-mlx-4bit'
PROMPTS = {'sky': 'Why is the sky blue?', 'hashmap': 'Explain how a hash map works, in about 200 words.'}

def main():
    OUT.mkdir(exist_ok=False)
    receipt = json.loads((BINARY.parent/'build-identity.json').read_text())
    for file, key in [('slotstream','binary_sha256'), ('mlx.metallib','metallib_sha256'), ('build-source.tar.gz','source_archive_sha256')]:
        assert digest(BINARY.parent/file) == receipt[key], f'Identity mismatch: {file}'
    shutil.copyfile(BINARY.parent/'build-source.tar.gz', OUT/'build-source.tar.gz')
    (OUT/'build-identity.json').write_text(json.dumps(receipt,indent=2)+'\n')
    assert digest(ROOT/'Sources/Slotstream/GPUKeepAlive.swift') == receipt['source']['Sources/Slotstream/GPUKeepAlive.swift']
    (OUT/'manifest.json').write_text(json.dumps({
        'protocol': __doc__, 'binary': str(BINARY.resolve()), 'model': model_identity(MODEL),
        'prompts': PROMPTS, 'head': subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
        'source_sha256': digest(Path(__file__)), 'thermal_observation': 'NSProcessInfo every second and before/after'},indent=2)+'\n')
    env = {k:v for k,v in os.environ.items() if not k.startswith(('SLOTSTREAM_', 'SS_DEBUG', 'MLX_'))}
    rows=[]
    for round_number in range(3):
        for prompt_index, (name,prompt) in enumerate(PROMPTS.items()):
            for arm in (['off','on'] if (round_number+prompt_index)%2==0 else ['on','off']):
                cell=OUT/f'{round_number+1}-{name}-{arm}'; cell.mkdir()
                row={'round':round_number+1,'prompt':name,'arm':arm,'valid':False}
                command=[str(BINARY),'run','--model',str(MODEL),'--memory-gb','8.1','--mtp','off','--vision','off',
                         '--max-context','8192','--max-tokens','64','--greedy','--seed','7',
                         '--gpu-keepalive',arm,'--prompt',prompt,'--stats-json',str(cell/'metrics.json')]
                row['command']=command
                child=None
                try:
                    row['host_before']=host_conditions()
                    row['before']=preflight(11.1)
                    row['thermal']=[observe()]
                    if not row['thermal'][0]['ready']: raise RuntimeError('non-nominal before launch')
                    start=time.monotonic()
                    with (cell/'stdout.txt').open('wb') as out, (cell/'stderr.txt').open('wb') as err:
                        child=subprocess.Popen(command,cwd=ROOT,env=env,stdout=out,stderr=err,start_new_session=True)
                        while child.poll() is None:
                            if time.monotonic()-start>600: raise RuntimeError('600s timeout')
                            try: child.wait(timeout=1)
                            except subprocess.TimeoutExpired: row['thermal'].append(observe())
                    row['wall_seconds']=time.monotonic()-start; row['exit_code']=child.returncode
                    row['after']=vm_snapshot(); row['thermal'].append(observe())
                    row['host_after']=host_conditions()
                    if child.returncode: raise RuntimeError('nonzero exit')
                    d=json.loads((cell/'metrics.json').read_text()); validate_metrics(d)
                    row['metrics']=d
                    if d['effective_mtp'] or d['stats']['decodeTokens']!=64 or d['stats']['gpuKeptAwake']!=(arm=='on'):
                        raise RuntimeError('effective configuration/output count mismatch')
                    if any(row['after'][k]!=row['before'][k] for k in ['swapins','swapouts']):
                        raise RuntimeError('paging during cell: excluded from clean timing')
                    if not all(t['ready'] for t in row['thermal']): raise RuntimeError('non-nominal thermals')
                    row['valid']=True
                except Exception as error: row['exclusion']=str(error)
                finally:
                    if child is not None and child.poll() is None: terminate_child_tree(child)
                (cell/'result.json').write_text(json.dumps(row,indent=2)+'\n')
                with (OUT/'results.jsonl').open('a') as f: f.write(json.dumps(row)+'\n')
                rows.append(row)
                print(json.dumps({k:v for k,v in row.items() if k in ['round','prompt','arm','valid','exclusion','wall_seconds']}
                                 | {'decode_seconds':row.get('metrics',{}).get('stats',{}).get('decodeSeconds')}),flush=True)
                if child is None: return 75
    pairs=[]
    for r in range(1,4):
        for name in PROMPTS:
            off,on=[next(x for x in rows if x['round']==r and x['prompt']==name and x['arm']==a) for a in ['off','on']]
            exact='metrics' in off and 'metrics' in on and off['metrics']['output_ids']==on['metrics']['output_ids']
            config='metrics' in off and 'metrics' in on and all(off['metrics'][k]==on['metrics'][k] for k in ['prompt_ids','effective_pool_slots','effective_mtp','effective_prefill_chunk'])
            pair={'round':r,'prompt':name,'clean':off['valid'] and on['valid'] and exact and config,'exact':exact,'same_config':config}
            if 'metrics' in off and 'metrics' in on:
                pair['decode_ratio_on_over_off']=off['metrics']['stats']['decodeSeconds']/on['metrics']['stats']['decodeSeconds']
            pairs.append(pair)
    (OUT/'paired-summary.json').write_text(json.dumps(pairs,indent=2)+'\n')
    print(json.dumps(pairs,indent=2))
    return 0
if __name__=='__main__': sys.exit(main())
