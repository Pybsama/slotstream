import pathlib,json,hashlib,tarfile,io,statistics
P=pathlib.Path(__file__).resolve().parent;R=P.parents[1]
n=json.loads((P/'final-v17-warm16.json').read_text());s=json.loads((P/'final-splash-warm16.json').read_text())
audit={'native_sha256':n['binary_sha256'],'native_slots':n['status_ready']['models'][0]['details']['memory_plan']['pool_slots'],'splash_slots':s['status_ready']['streamed_experts']['slots'],'native':[{'decode_tps':r['tps'],'swapins_delta':r['after']['swapins']-r['before']['swapins'],'swapouts_delta':r['after']['swapouts']-r['before']['swapouts'],'thermal_before':r['thermal_before'],'thermal_after':r['thermal_after']}for r in n['runs']],'splash':[{'decode_tps':r['timings']['predicted_per_second'],'cached_prompt_tokens':r['timings']['cache_n'],'swapins_delta':r['swapins_delta'],'swapouts_delta':r['swapouts_delta']}for r in s['runs']],'scope':'Diagnostic warm-server series, not an eligible paired benchmark. Same target/draft, context, physical budget and expert slots; Splash reuses 64 prompt tokens after its first request while native disables prefix caching. Global paging excluded most request intervals. Native retains its gap after repeated requests; no causal ratio is claimed.','v18_adopted':False,'v18_replays':[]}
assert n['complete'] and s['complete'] and audit['native_slots']==audit['splash_slots']==4968
for label in ['0-v17','1-v18']:
 d=json.loads((P/f'v18-replay-{label}.json').read_text());audit['v18_replays'].append({'arm':label,'width8_median_ms':statistics.median(r['seconds'] for r in d['runs'] if r['width']==8 and not r['traced'] and r['round']>0)*1000,'timed_rows_have_no_paging_or_io':all(r['swapins_delta']==r['swapouts_delta']==r['io_seconds']==0 for r in d['runs'] if r['round']>0),'scope':'fixed-forward replay, not full-request speed; process lifetime includes paging'})
(P/'followup-audit.json').write_text(json.dumps(audit,indent=2))
files={f.name:f for f in P.iterdir() if f.is_file() and (f.name.startswith(('final-v17-warm16','final-splash-warm16','v18-','packed-v18-')) or f.name in ['native_warm_final.py','final-warm-cases.json','followup-audit.json','capture_followup.py'])}
for name in ['build-identity.json','build-source.tar.gz']:files['native-packed-v18/'+name]=P/'native-packed-v18'/name
out=R/'db/sources/runs/2026/10/native-q2-execution-followup-2026-10-22.tar.gz';assert not out.exists()
manifest={name:{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}for name,f in files.items()}
with tarfile.open(out,'w:gz')as t:
 b=json.dumps(manifest,indent=2).encode();i=tarfile.TarInfo('MANIFEST.json');i.size=len(b);t.addfile(i,io.BytesIO(b))
 for name,f in files.items():t.add(f,arcname=name,recursive=False)
with tarfile.open(out)as t:
 for name,m in manifest.items():
  b=t.extractfile(name).read();assert len(b)==m['bytes'] and hashlib.sha256(b).hexdigest()==m['sha256']
r={'path':str(out.relative_to(R)),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'payloads':len(files),'all_payloads_verified':True}
(P/'followup-archive-receipt.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
