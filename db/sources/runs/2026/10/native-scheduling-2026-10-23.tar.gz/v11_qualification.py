import json, subprocess, sys
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];B=P/'v11/slotstream';rows=[]
def run(label,cmd):
 print('START',label,flush=True)
 with (P/(label+'-driver.log')).open('x')as log:r=subprocess.run(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT)
 rows.append(dict(label=label,command=cmd,exit_code=r.returncode))
 (P/'v11-qualification-ledger.json').write_text(json.dumps(rows,indent=2)+'\n')
 print('END',label,r.returncode,flush=True)
run('v11-q2-splash12',[sys.executable,str(P/'q2_ahead_splash_compare.py'),'--label','v11-q2-splash12','--native',str(B),'--ahead','on','--budget','12','--cases',str(P/'short-warm-cases.json')])
run('v11-fast-splash12',[sys.executable,str(P/'warm_compare.py'),'--label','v11-fast-splash12','--native',str(B),'--budget','12','--cases',str(P/'short-warm-cases.json')])
run('v11-plain',[sys.executable,str(P/'plain_equivalence.py')])
run('v11-quality',[sys.executable,str(P/'quality_final.py')])
run('v11-bounded',[sys.executable,str(P/'guarded_run.py'),'--label','v11-bounded-guard','--budget','10','--',sys.executable,str(R/'Tools/fast_smart_acceptance.py'),'--binary',str(B),'--out',str(P/'v11-bounded')])
prompt='Return only a JSON object with keys code and amount. Copy them from this record: code is MAPLE-9261 and amount is 47.25. Use a JSON number for amount. Do not add other keys or text.'
run('v11-q2-production',[sys.executable,str(P/'guarded_run.py'),'--label','v11-q2-production','--budget','10','--',str(B),'run','--model','smart-q2','--memory-gb','10','--max-context','32768','--prompt',prompt,'--max-tokens','96','--greedy','--stats-json',str(P/'v11-q2-production.json')])
raise SystemExit(int(any(x['exit_code'] for x in rows)))
