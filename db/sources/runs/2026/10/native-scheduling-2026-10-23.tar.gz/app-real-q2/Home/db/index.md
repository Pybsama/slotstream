---
type: index
scope: root
updated: 2026-10-23T18:17:04.216300Z
---

# Knowledge base index

## Sources (78)
- [[sources/conversations/index|Conversations]] (74)
- [[sources/excerpts/index|Excerpts]] (4)

## Records (13)
- [[records/drafts/index|Drafts]] (6)
- [[records/state/index|State]] (1)
- [[records/threads/index|Threads]] (6)
