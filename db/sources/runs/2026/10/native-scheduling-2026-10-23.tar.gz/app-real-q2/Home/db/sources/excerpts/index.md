---
type: index
scope: type-folder
folder: sources/excerpts
updated: 2026-10-23T18:15:34.267543Z
---

# sources/excerpts

- [[sources/excerpts/2026/10/c8a3e622-b858-493c-86da-6236e06ace26-S1-99b3f474908f242ea05dae14]] — Immutable conversation event
- [[sources/excerpts/2026/10/d9837ba7-186b-4709-aa1f-e2dbe858e056-S1-bbc1014b0c8c88d5a662503e]] — Immutable conversation event
- [[sources/excerpts/2026/10/e89e4c3b-44ba-4887-a582-42183140fb71-S1-283f6b91d0c0d54720f92dcb]] — Immutable conversation event
- [[sources/excerpts/2026/10/4ef9c170-2e84-44c7-9ba6-ba821535a1c8-S1-8f367caa78d7ab4e03f5291e]] — Immutable conversation event
