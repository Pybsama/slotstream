import json, statistics
from pathlib import Path
P=Path(__file__).resolve().parent
labels=['baseline-q213','v8-fast13','v9-ahead13','v10-buffers13','v11-fast-ahead13','v11-q2-splash13','v11-fast-splash12','v11-q2-splash12']
results={}
for label in labels:
 path=P/(label+'-ledger.json')
 if not path.exists():continue
 events=json.loads(path.read_text())
 if len(events)!=4:continue
 out=dict(label=label,eligible=all(x['eligible']for x in events),slots=json.loads((P/(label+'-cache.json')).read_text())['slots'],arms=[dict(label=x['label'],eligible=x['eligible'],thermal_nominal=x['thermal_nominal'],runs=x['runs'])for x in events],medians={})
 for arm in ['A','B']:
  out['medians'][arm]={}
  for case in ['timed-2','timed-3']:
   rows=[r for e in events if e['arm']==arm for r in e['runs']if r['id']==case]
   out['medians'][arm][case]={k:statistics.median(r[k] for r in rows)for k in ['tps','request_seconds','prefill_seconds','peak_gb']}
 results[label]=out
 print(label,'eligible',out['eligible'],'slots',out['slots'],'medians',out['medians'])
(P/'comparisons-summary.json').write_text(json.dumps(results,indent=2)+'\n')
