import hashlib,json,shutil,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];out=P/'v10';out.mkdir()
build=R/'.build/release'
for name in ['slotstream','slotstream-checks','mlx.metallib','build-identity.json','build-source.tar.gz','build-source-before.json']:
 shutil.copy2(build/name,out/name)
(out/'sha256.json').write_text(json.dumps({f.name:hashlib.sha256(f.read_bytes()).hexdigest()for f in out.iterdir()if f.is_file()},indent=2))
for label,cmd in [('v10-kernels',[str(out/'slotstream'),'q2-experts-check']),('v10-catalogue',[str(out/'slotstream-checks'),'--tier','t0','--tier','t1','--json'])]:
 print('START',label,flush=True)
 with (P/(label+'.log')).open('x')as log: r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 print('END',label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
