import json,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1]
assert 'STATIC GATES PASS' in (P/'static-gates.log').read_text()
body=P/'measurement-body.md'
body.write_text(body.read_text().replace('Static-gate results are appended after their raw receipts complete.',
 'The complete repository static gates pass against the frozen v11 binary.\nAll 339 engine build inputs still match the tested source manifest.'))
subprocess.run([sys.executable,str(P/'archive_schedule.py')],cwd=R,check=True)
receipt=json.loads((P/'archive-receipt.json').read_text())
binary=json.loads((P/'v11/build-identity.json').read_text())['binary_sha256']
def dbmd(*args):subprocess.run(['dbmd',*args],cwd=R,check=True)
dbmd('index','rebuild','--dir','db')
link=f"[Verified raw archive](native-scheduling-2026-10-23.tar.gz), SHA-256 `{receipt['sha256']}`. Its internal manifest binds {receipt['files']} files and passed readback verification."
main=P/'run-body.md';main.write_text(link+'\n\n'+
 'The clean 13 GB baseline, Q2 read-ahead ablation, rejected buffer reuse and rejected Fast read-ahead experiment retain independent verdicts. The final v11 engine passes the native kernels, all 108 catalogue checks, exact plain-output comparisons and the complete static gates. The frozen quality suite retains its prior scores and failure identities; both targets pass the request-behavior checks. Production startup and bounded memory checks pass. The rebuilt app signature and source inputs verify. Q2 passes all six real app jobs; Fast retains its code-edit staging and history-retrieval failures. These failures are not hidden by the passing integration checks.\n\n'+
 'The archive also preserves excluded timing attempts, preflight refusals, complete source snapshots and the removed v10 buffer-pool experiment. The [excluded comparisons](2026-10-23-native-scheduling-excluded-comparisons.md) must not be used as clean speed claims. Frozen v11 is the final source; standalone Swift files at the archive root include intermediate experiments. Executables, model weights, metallibs and disposable prefix caches are omitted, with identities and source reconstruction retained. No public release or Smart promotion is claimed.\n')
excluded=P/'excluded-run-body.md';excluded.write_text(link+'\n\n'+
 'Discard the following complete aggregates for clean timing claims: v8-fast13 (timed global paging), v11-q2-splash13 (timed global paging and a non-nominal thermal reading), v11-q2-splash12 (timed paging in both engines), and v11-fast-splash12 (timed paging and a non-nominal thermal reading). Keep every request, cooldown, observer and eligibility verdict in the archive. Clean individual requests do not rescue a failed aggregate.\n\n'+
 'The 12 GB protocols were frozen after the 13 GB failure and still match actual cache capacity, exact prompt IDs, sampling, KV precision, context, warmups and ABBA order. The smaller budget did not remove global paging. Their observed medians are diagnostic only; no parity ratio is qualified. Ordinary functional, quality and process-memory checks remain separately valid when their own gates pass.\n')
for name,title,file,discarded in [
 ('2026-10-23-native-scheduling','Native scheduling ablations and qualification',main,'false'),
 ('2026-10-23-native-scheduling-excluded-comparisons','Excluded final native and Splash timing comparisons',excluded,'true')]:
 dbmd('write','sources/runs/2026/10/'+name+'.md','--type','run','--dir','db','--summary',title,
  '--fm','title='+title,'--fm','captured_at=2026-10-23','--fm','command=Exact frozen commands and protocols in the linked archive',
  '--fm','tool=Native Swift MLX Metal and guarded reference harnesses','--fm','binary='+binary,
  '--fm','machines=[[records/machines/macbook-pro-m5-pro-48gb]]','--fm','discarded='+discarded,'--body-file',str(file))
dbmd('write','records/measurements/native-fast-q2-scheduling.md','--type','measurement','--dir','db',
 '--summary','Bounded Q2 read-ahead improves clean native comparisons; Fast read-ahead and buffer reuse are rejected, with full app and timing limits retained',
 '--fm','title=Native Fast and Q2 scheduling','--fm','doc=measurements','--fm','order=1879','--fm','level=2','--fm','date=2026-10-23','--fm','status=measured',
 '--fm','machines=[[records/machines/macbook-pro-m5-pro-48gb]]',
 '--fm','runs=[[sources/runs/2026/10/2026-10-23-native-scheduling]], [[sources/runs/2026/10/2026-10-23-native-scheduling-excluded-comparisons]]','--body-file',str(body))
dbmd('write','records/decisions/native-input-read-ahead.md','--type','decision','--dir','db',
 '--summary','Keep measured bounded Q2 input read-ahead, reject its Fast default and buffer reuse, and require actual app recipe and branch evidence',
 '--fm','title=Native input read-ahead','--fm','decided_on=2026-10-23','--fm','status=standing',
 '--fm','reversible_if=Complete-request, hardware or resource evidence shows a regression or a simpler schedule performs better','--body-file',str(P/'decision-body.md'))
followup=P/'kernel-followup.md';followup.write_text('\n## Scheduling follow-up, October 23\n\nThe [native scheduling study](native-fast-q2-scheduling.md) adds bounded page-aligned reads, shared Q2 input preparation and next-input read-ahead with private staging. Its clean ablation supports Q2; a clean Fast regression and slower buffer-reuse experiment are retained and rejected. Final matched comparisons remain excluded for paging or thermal failures. The full app and quality checks retain their prior capability limits. This later schedule does not rewrite the unsuccessful earlier read-ahead experiments or establish complete Splash parity.\n')
dbmd('body','append','db/records/measurements/native-fast-q2-execution-kernels.md','--body-file',str(followup))
followup=P/'decision-followup.md';followup.write_text('\n## Native scheduling follow-up, October 23\n\nFollow [[records/decisions/native-input-read-ahead]] and [[records/measurements/native-fast-q2-scheduling]]. The Q2 engineering candidate gains bounded input read-ahead with a new startup identity; Fast retains its existing recipe because the same schedule regresses prose. The actual app startup recipe and complete jobs are checked alongside the CLI. Maintained aliases and the new-install default remain unchanged, and Q2 is not promoted to Smart.\n')
dbmd('body','append','db/records/decisions/fast-and-smart.md','--body-file',str(followup))
