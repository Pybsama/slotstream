---
type: index
scope: type-folder
folder: records/state
updated: 2026-10-23T18:12:37.327256Z
---

# records/state

- [[records/state/home]] — Slotstream Home state and conversation history
