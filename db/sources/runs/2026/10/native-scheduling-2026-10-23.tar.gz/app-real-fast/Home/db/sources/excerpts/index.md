---
type: index
scope: type-folder
folder: sources/excerpts
updated: 2026-10-23T18:12:10.480922Z
---

# sources/excerpts

- [[sources/excerpts/2026/10/97e6d82b-f928-4ee0-a375-cb001ca1d1ff-S1-99b3f474908f242ea05dae14]] — Immutable conversation event
- [[sources/excerpts/2026/10/8c1d96e6-aa8d-4c8a-8ded-1505109a39dd-S1-bbc1014b0c8c88d5a662503e]] — Immutable conversation event
- [[sources/excerpts/2026/10/64581aee-cd3d-4bad-9585-ce38f180d623-S1-283f6b91d0c0d54720f92dcb]] — Immutable conversation event
- [[sources/excerpts/2026/10/4300347b-5ab5-40ca-9b47-72b61d5fe103-S1-8f367caa78d7ab4e03f5291e]] — Immutable conversation event
