import json,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1]
commands=[
 ('v11-fast-ahead13',[sys.executable,str(P/'fast_ahead_compare.py'),'--label','v11-fast-ahead13','--native',str(P/'v11/slotstream'),'--budget','13','--cases',str(P/'short-warm-cases.json')]),
 ('v11-q2-splash13',[sys.executable,str(P/'q2_ahead_splash_compare.py'),'--label','v11-q2-splash13','--native',str(P/'v11/slotstream'),'--ahead','on','--budget','13','--cases',str(P/'short-warm-cases.json')]),
]
for label,cmd in commands:
 print('START',label,flush=True)
 with (P/(label+'-driver.log')).open('x')as log:r=subprocess.run(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT)
 print('END',label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
