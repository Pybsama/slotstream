from pathlib import Path
import csv,json,collections,statistics,bisect
P=Path(__file__).resolve().parent;arms=json.loads((P/'readiness-ledger.json').read_text());details=[];summaries=[]
def readcsv(p):
 lines=p.read_text().splitlines();assert lines[-1].startswith('# total=')
 parts=dict(x.split('=')for x in lines[-1][2:].split());assert int(parts['total'])<int(parts['cap']),p
 return list(csv.DictReader(l for l in lines if not l.startswith('#')))
def unionlength(xs):
 out=[]
 for a,b in sorted(xs):
  if b<=a:continue
  if out and a<=out[-1][1]:out[-1][1]=max(b,out[-1][1])
  else:out.append([a,b])
 return sum(b-a for a,b in out)
for a in arms:
 label=a['label'];cp=next(p for p in P.glob(label+'-commands*.csv')if '.events.'not in p.name);ep=next(P.glob(label+'-commands*.events.csv'))
 commands=[{k:float(v)for k,v in c.items()}for c in readcsv(cp)]
 events=[dict(kind=e['kind'],stamp=float(e['stamp']),buffer=int(e['buffer']),event=int(e['event']),value=int(e['value']))for e in readcsv(ep)]
 buffers=collections.defaultdict(list);signals=collections.defaultdict(list);returned=collections.defaultdict(list)
 for e in events:
  if e['kind'] in ['W','E']:buffers[e['buffer']].append(e)
  elif e['kind']=='S':signals[(e['event'],e['value'])].append(e['stamp'])
  elif e['kind']=='R':returned[(e['event'],e['value'])].append(e['stamp'])
 for b in buffers.values():b.sort(key=lambda e:e['stamp'])
 for xs in list(signals.values())+list(returned.values()):xs.sort()
 previous={};matches=[]
 for c in sorted(commands,key=lambda c:c['submitted']):
  b=int(c['buffer']);lo=previous.get(b,0);previous[b]=c['submitted']
  es=[e for e in buffers[b] if lo<e['stamp']<=c['submitted']]
  for w in [e for e in es if e['kind']=='W']:
   key=(w['event'],w['value']);ss=signals.get(key,[])
   index=bisect.bisect_left(ss,w['stamp'])
   if index<len(ss)and ss[index]<=c['end']:s=ss[index]
   elif index and ss[index-1]>=lo:s=ss[index-1]
   else:continue
   rr=returned.get(key,[]);i=bisect.bisect_left(rr,s);end=rr[i]if i<len(rr) else s
   first=not any(e['kind']=='E' and e['stamp']<w['stamp']for e in es)
   matches.append(dict(command_index=int(c['index']),submitted=c['submitted'],gpu_start=c['start'],gpu_end=c['end'],wait_encoded=w['stamp'],signal=s,signal_return=end,first_compute_wait=first,event=key[0],value=key[1],setter_ms=(end-s)*1000,pre_signal_ms=max(0,min(s,c['end'])-c['start'])*1000,resume_ms=max(0,c['start']-end)*1000))
 rows=[]
 ends=sorted(c['end']for c in commands)
 for r in a['runs']:
  if r['round']<2:continue
  lo,hi=(r['start_ns']/1e9,r['end_ns']/1e9)if a['arm']=='N'else(r['start'],r['end'])
  cs=[c for c in commands if lo<=c['submitted']<hi];ms=[m for m in matches if lo<=m['submitted']<hi]
  gpu=unionlength([(max(lo,c['start']),min(hi,c['end']))for c in commands if c['end']>lo and c['start']<hi])*1000
  row=dict(condition=r['condition'],round=r['round'],wall_ms=(hi-lo)*1000,gpu_ms=gpu,commands=len(cs),cpu_ready_waits=len(ms),first_compute_waits=sum(m['first_compute_wait']for m in ms),pre_signal_first_ms=sum(m['pre_signal_ms']for m in ms if m['first_compute_wait']),pre_signal_mid_ms=sum(m['pre_signal_ms']for m in ms if not m['first_compute_wait']),resume_first_ms=sum(m['resume_ms']for m in ms if m['first_compute_wait']),setter_ms=sum(m['setter_ms']for m in ms))
  if a['arm']=='N':
   pickup=[]
   for e in r['trace']:
    if e['kind']=='route_ready':
     ready=e['ns']/1e9;i=bisect.bisect_right(ends,ready)-1
     if i>=0:pickup.append((ready-ends[i])*1000)
   row['route_readback_tail_ms']=sum(pickup)
  else:row.update(pickup_ms=r['pickup_seconds']*1000,read_work_ms=r['read_work_seconds']*1000,resume_ms=r['resume_seconds']*1000)
  rows.append(row)
  details.append(dict(label=label,condition=r['condition'],round=r['round'],waits=ms))
 conditions={c:{k:statistics.median(r[k]for r in rows if r['condition']==c)for k in rows[0]if k not in ['condition','round']}for c in sorted(set(r['condition']for r in rows))}
 summaries.append(dict(label=label,arm=a['arm'],eligible=a['eligible'],conditions=conditions))
(P/'readiness-detail.json').write_text(json.dumps(details,indent=2));(P/'readiness-analysis.json').write_text(json.dumps(summaries,indent=2))
out={c:{arm:{k:statistics.mean(a['conditions'][c][k]for a in summaries if a['arm']==arm)for k in next(a['conditions'][c]for a in summaries if a['arm']==arm)}for arm in ['N','S']}for c in ['cached_off','partial_off','cached_on','partial_on']}
(P/'readiness-summary.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
