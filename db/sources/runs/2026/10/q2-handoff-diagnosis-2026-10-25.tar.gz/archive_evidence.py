from pathlib import Path
import hashlib,io,json,tarfile,re,importlib.util,subprocess
P=Path(__file__).resolve().parent;R=P.parents[1];OLD=P.parent/'native-replay-20261023';PREV=P.parent/'q2-typical-20261025'
spec=importlib.util.spec_from_file_location('identity',R/'Tools/build_identity.py');identity=importlib.util.module_from_spec(spec);spec.loader.exec_module(identity)
expected=json.loads((OLD/'v68/build-identity.json').read_text());current={str(f.relative_to(R)):identity.sha(f)for f in identity.source_files(R)}
assert current==expected['source']
names=['slotstream','slotstream-checks','mlx.metallib','build-identity.json','build-source.tar.gz'];artifacts={n:identity.sha(R/'.build/release'/n)==identity.sha(OLD/'v68'/n)for n in names};assert all(artifacts.values())
(P/'runtime-restoration-check.json').write_text(json.dumps(dict(source_files=len(current),all_source_hashes_equal_v68=True,default_artifacts=artifacts,binary_sha256=identity.sha(R/'.build/release/slotstream'),git_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),production_changes_retained=False,fast_changed=False),indent=2))
files={}
for f in P.rglob('*'):
 if f.is_file()and f.suffix in ['.json','.py','.log','.swift','.cpp','.hpp','.h','.mm','.metal','.patch','.txt','.csv']and f.name not in ['archive-receipt.json','archive-privacy-check.json']:
  files[str(f.relative_to(P))]=f
references={
 'v68-build-identity.json':OLD/'v68/build-identity.json',
 'native-fixed-build-identity.json':PREV/'replay-build/candidate/build-identity.json',
 'Splash-fixed-build-identity.json':PREV/'upstream/identity.json',
 'Splash-fixed-build-ledger.json':PREV/'upstream/build-ledger.json',
 'Splash-fixed-build.py':PREV/'build_upstream.py',
 'Splash-CPU-poll-summary.json':OLD/'splash-host-wait-q215-summary.json',
 'Splash-CPU-poll-ledger.json':OLD/'splash-host-wait-q215-ledger.json',
 'Splash-CPU-poll-build.py':OLD/'build_splash_host_ablation.py',
 'Splash-original-MetalBackend.mm':Path('/tmp/slotstream-splash-review.EJTswU/splash/runtime/metal/MetalBackend.mm'),
 'Splash-LICENSE.txt':Path('/tmp/slotstream-splash-review.EJTswU/splash/LICENSE'),
 'q2_upstream_bench_io.py':OLD/'q2_upstream_bench_io.py',
 'short-warm-384-cases.json':OLD/'short-warm-384-cases.json',
 'metal_qos_probe_b.mm':OLD/'metal_qos_probe_b.mm',
 'thermal.py':R/'.build/native-q2-20261021/thermal.py'}
for name,f in references.items():assert f.exists(),f;files['reference/'+name]=f
logits={};seen={}
for f in P.glob('*.f32'):
 h=identity.sha(f);logits[f.name]=dict(bytes=f.stat().st_size,sha256=h,stored_as=seen.setdefault(h,'logits/'+f.name));files[seen[h]]=f
(P/'logits-file-map.json').write_text(json.dumps(logits,indent=2));files['logits-file-map.json']=P/'logits-file-map.json'
# Do not embed model weights or executables; bind every local diagnostic artifact by hash.
binaries={str(f.relative_to(P)):dict(bytes=f.stat().st_size,sha256=identity.sha(f))for f in P.rglob('*')if f.is_file()and(f.suffix in ['.dylib','.o','.metallib']or f.name in ['slotstream','slotstream-checks','counter_capabilities'])}
(P/'binary-file-map.json').write_text(json.dumps(binaries,indent=2));files['binary-file-map.json']=P/'binary-file-map.json'
secret=re.compile(rb'(?:ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{25,}|sk-(?:proj-)?[A-Za-z0-9_-]{30,}|AIza[A-Za-z0-9_-]{30,}|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----)')
for name,f in files.items():
 if f.suffix!='.f32':assert not secret.search(f.read_bytes()),name
privacy=dict(files_scanned=len(files),credential_pattern_matches=0,scope='Task-local benchmark inputs/code/results only; no chat exports, messages, credentials or model weights included.')
(P/'archive-privacy-check.json').write_text(json.dumps(privacy,indent=2));files['archive-privacy-check.json']=P/'archive-privacy-check.json'
manifest={name:dict(bytes=f.stat().st_size,sha256=identity.sha(f))for name,f in files.items()};raw=json.dumps(manifest,indent=2).encode()+b'\n'
dest=R/'db/sources/runs/2026/10/q2-handoff-diagnosis-2026-10-25.tar.gz';assert not dest.exists()
with tarfile.open(dest,'w:gz')as tar:
 for name,f in sorted(files.items()):tar.add(f,arcname=name,recursive=False)
 info=tarfile.TarInfo('archive-manifest.json');info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
with tarfile.open(dest)as tar:
 for name,m in manifest.items():
  raw=tar.extractfile(name).read();assert len(raw)==m['bytes']and hashlib.sha256(raw).hexdigest()==m['sha256']
receipt=dict(path=str(dest.relative_to(R)),files=len(manifest),bytes=dest.stat().st_size,sha256=identity.sha(dest),readback_verified=True,unique_logits_files=len(seen));assert receipt['bytes']<95_000_000
(P/'archive-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
