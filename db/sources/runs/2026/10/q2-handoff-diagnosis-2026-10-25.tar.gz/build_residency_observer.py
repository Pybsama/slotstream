from pathlib import Path
import subprocess,json
P=Path(__file__).resolve().parent
s=(P/'stage_observer.mm').read_text().replace('#include <unistd.h>','#include <unistd.h>\n#include <dlfcn.h>')
anchor='void dump() {'
extra=r'''
std::once_flag wireOnce;
using WireFunction=int(*)(size_t*,size_t);
WireFunction wireFunction=nullptr;
size_t previousWire=0,requestedWire=0;
int wireResult=-999;
void restoreWire(const char* prefix);
void configureWire(){
  std::call_once(wireOnce,[]{
    const char* limit=getenv("SLOTSTREAM_DIAGNOSTIC_WIRED_BYTES");
    if(!limit)return;
    char* end=nullptr;requestedWire=strtoull(limit,&end,10);
    if(!end || *end || requestedWire>15000000000ULL){fprintf(stderr,"WIRE_PROBE_INVALID_LIMIT\n");abort();}
    wireFunction=(WireFunction)dlsym(RTLD_DEFAULT,"mlx_set_wired_limit");
    if(!wireFunction){fprintf(stderr,"WIRE_PROBE_MISSING_SYMBOL\n");abort();}
    wireResult=wireFunction(&previousWire,requestedWire);
    fprintf(stderr,"WIRE_PROBE requested=%zu previous=%zu result=%d\n",requestedWire,previousWire,wireResult);
    if(wireResult || previousWire!=0)abort();
    atexit([]{restoreWire(getenv("SLOTSTREAM_METAL_OBSERVER"));});
  });
}
void restoreWire(const char* prefix){
  if(!wireFunction)return;
  size_t restoredFrom=0;int result=wireFunction(&restoredFrom,previousWire);
  char path[4096];snprintf(path,sizeof(path),"%s.%d.wired.json",prefix,getpid());FILE*f=fopen(path,"wx");if(!f)return;
  fprintf(f,"{\"requested\":%zu,\"previous\":%zu,\"start_result\":%d,\"restored_from\":%zu,\"end_result\":%d}\n",requestedWire,previousWire,wireResult,restoredFrom,result);fclose(f);
}
'''
assert s.count(anchor)==1;s=s.replace(anchor,extra+'\n'+anchor)
anchor='    const size_t i=next.fetch_add(1);'
assert s.count(anchor)==1;s=s.replace(anchor,'    configureWire();\n'+anchor)
s=s.replace('// production. Does not commit, wait, change encoding or manufacture GPU work.','// production. This diagnostic optionally sets the MLX residency ceiling before\n// the first ordinary command commit and restores it at exit. No added GPU work.\n// The isolated CLI has no WiredMemoryManager users; production must use tickets.')
(P/'residency_observer.mm').write_text(s)
r=subprocess.run(['xcrun','clang++','-std=c++17','-O2','-dynamiclib','-fblocks','-fno-objc-arc','-framework','Foundation','-framework','Metal',str(P/'residency_observer.mm'),'-o',str(P/'residency_observer.dylib')],capture_output=True,text=True)
(P/'residency-observer-build.json').write_text(json.dumps(dict(exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr),indent=2));print(r.stderr);raise SystemExit(r.returncode)
