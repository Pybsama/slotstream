from pathlib import Path
import sys,json,hashlib,difflib,shutil
P=Path(__file__).resolve().parent;R=P.parents[1];PREV=R/'.build/q2-typical-20261025';OLD=R/'.build/native-replay-20261023'
sys.path.insert(0,str(R/'Tools'));from optimization_build import build
paths=['Sources/Slotstream/NativeExpertSchedule.swift','Sources/Slotstream/ExpertStore.swift','Sources/Slotstream/Layers.swift','Sources/slotstream-cli/Q2ProfileCommand.swift'];original={p:(R/p).read_bytes()for p in paths}
s=original[paths[0]].decode();anchor='if awaitingReads || Self.earlySubmission { asyncEval(value) }';assert s.count(anchor)==1;s=s.replace(anchor,'if affine && (awaitingReads || Self.earlySubmission) { asyncEval(value) }')
(P/'coalesce-NativeExpertSchedule.swift').write_text(s);(P/'coalesce.patch').write_text(''.join(difflib.unified_diff(original[paths[0]].decode().splitlines(True),s.splitlines(True),fromfile='a/'+paths[0],tofile='b/'+paths[0])))
(P/'coalesce-plan.json').write_text(json.dumps({'hypothesis':'Direct host phase profile finds async expert submission dominates expert setup:1.36ms versus0.25ms native prepare and0.27ms grouping forpartial/on. Q2 can leave expert work lazy after publishing its complete bytes so following MLX graph evaluation coalesces it, instead of a separate async submission perlayer. This differs from rejected late-submit candidate, which still created a separate submission. Existing events, owners, cancellation and cache pins remain; Fast affine schedule unchanged.', 'protocol':'Capturedwidth4/393 misses,15GB ABBA baseline/candidate, same frozen source except1 Q2-only condition and identical diagnostic instrumentation. No per-read traces; oldpassive commandobserver. Exactlogits required. If promising, relevant correctness and uninstrumented full-request ABCCBA vsfrozenv68 andSplash. Retain only repeatable complete-request benefit and aimwithin5%upstream onboth tasks.'},indent=2))
try:
 (R/paths[0]).write_text(s);(R/paths[1]).write_bytes((PREV/'replay-ExpertStore.swift').read_bytes());(R/paths[2]).write_bytes((PREV/'Layers.swift').read_bytes());(R/paths[3]).write_bytes((PREV/'replay-Q2ProfileCommand.swift').read_bytes())
 result=build(R,P/'coalesce-replay-build',required_gb=10,jobs=4);print({k:v for k,v in result.items()if k in ['passed','error','elapsed_seconds']},flush=True)
finally:
 for p,b in original.items():(R/p).write_bytes(b)
 (P/'coalesce-restored-after-build.json').write_text(json.dumps({p:hashlib.sha256((R/p).read_bytes()).hexdigest()for p in paths},indent=2))
 for name in ['slotstream','slotstream-checks','mlx.metallib','build-identity.json','build-source.tar.gz']:shutil.copy2(OLD/'v68'/name,R/'.build/release'/name)
if not result['passed']:raise SystemExit(1)
