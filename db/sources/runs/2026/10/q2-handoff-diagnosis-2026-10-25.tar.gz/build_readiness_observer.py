from pathlib import Path
import subprocess,json,os,fcntl
P=Path(__file__).resolve().parent;R=P.parents[1]
s=(R/'.build/native-replay-20261023/metal_command_observer.mm').read_text()
s=s.replace('unsigned status=0; };','unsigned status=0; uintptr_t buffer=0; };')
s=s.replace('std::set<Class> devices, queues, commands;','''std::set<Class> devices, queues, commands, sharedEvents;
constexpr size_t eventLimit=1048576;
struct EventRecord { char kind=0; double stamp=0; uintptr_t buffer=0,event=0; uint64_t value=0; };
EventRecord eventRecords[eventLimit]; std::atomic<size_t> nextEvent{0};''')
anchor='void dump() {'
addition='''void recordEvent(char kind, id buffer, id event, uint64_t value) {
  const size_t i=nextEvent.fetch_add(1);
  if(i<eventLimit) eventRecords[i]={kind,now(),(uintptr_t)buffer,(uintptr_t)event,value};
}
void sharedEvent(id<MTLSharedEvent> object) {
  if(!object)return;
  std::lock_guard lock(hooksMutex); Class cls=object_getClass(object);
  if(!sharedEvents.insert(cls).second)return;
  SEL sel=@selector(setSignaledValue:); Method method=class_getInstanceMethod(cls,sel);
  if(!method)return;
  const IMP original=method_getImplementation(method);
  IMP wrapped=imp_implementationWithBlock(^(id event,uint64_t value) {
    recordEvent('S',nil,event,value);
    reinterpret_cast<void(*)(id,SEL,uint64_t)>(original)(event,sel,value);
    recordEvent('R',nil,event,value);
  });
  class_replaceMethod(cls,sel,wrapped,method_getTypeEncoding(method));
}
'''
assert s.count(anchor)==1;s=s.replace(anchor,addition+anchor)
s=s.replace('index,submitted,start,end,completed,status\\n','index,submitted,start,end,completed,status,buffer\\n')
s=s.replace('%.9f,%u\\n",i,r.submitted,r.start,r.end,r.completed,r.status);','%.9f,%u,%llu\\n",i,r.submitted,r.start,r.end,r.completed,r.status,(unsigned long long)r.buffer);')
anchor='fprintf(f,"# total=%zu cap=%zu\\n",count,limit); fclose(f);'
replace=anchor+'''
  snprintf(output,sizeof(output),"%s.%d.events.csv",path,getpid());
  f=fopen(output,"wx"); if(!f)return;
  fprintf(f,"kind,stamp,buffer,event,value\\n");
  const size_t events=nextEvent.load();
  for(size_t i=0;i<std::min(events,eventLimit);++i){const auto&r=eventRecords[i];
    fprintf(f,"%c,%.9f,%llu,%llu,%llu\\n",r.kind,r.stamp,(unsigned long long)r.buffer,(unsigned long long)r.event,(unsigned long long)r.value);}
  fprintf(f,"# total=%zu cap=%zu\\n",events,eventLimit);fclose(f);'''
assert s.count(anchor)==1;s=s.replace(anchor,replace)
s=s.replace('records[i].submitted=now();','records[i].submitted=now(); records[i].buffer=(uintptr_t)buffer;')
anchor='  if(!commands.insert(cls).second) return;'
addition='''
  {
    SEL waitSel=@selector(encodeWaitForEvent:value:);Method waitMethod=class_getInstanceMethod(cls,waitSel);
    if(waitMethod){const IMP originalWait=method_getImplementation(waitMethod);
      IMP wrappedWait=imp_implementationWithBlock(^(id buffer,id<MTLSharedEvent> event,uint64_t value){
        sharedEvent(event);recordEvent('W',buffer,event,value);
        reinterpret_cast<void(*)(id,SEL,id,uint64_t)>(originalWait)(buffer,waitSel,event,value);
      });class_replaceMethod(cls,waitSel,wrappedWait,method_getTypeEncoding(waitMethod));}
    SEL simple=@selector(computeCommandEncoder);Method m=class_getInstanceMethod(cls,simple);
    if(m){const IMP orig=method_getImplementation(m);IMP wrap=imp_implementationWithBlock(^id(id buffer){
      recordEvent('E',buffer,nil,0);return reinterpret_cast<id(*)(id,SEL)>(orig)(buffer,simple);
    });class_replaceMethod(cls,simple,wrap,method_getTypeEncoding(m));}
    SEL typed=@selector(computeCommandEncoderWithDispatchType:);m=class_getInstanceMethod(cls,typed);
    if(m){const IMP orig=method_getImplementation(m);IMP wrap=imp_implementationWithBlock(^id(id buffer,NSUInteger type){
      recordEvent('E',buffer,nil,0);return reinterpret_cast<id(*)(id,SEL,NSUInteger)>(orig)(buffer,typed,type);
    });class_replaceMethod(cls,typed,wrap,method_getTypeEncoding(m));}
    SEL described=@selector(computeCommandEncoderWithDescriptor:);m=class_getInstanceMethod(cls,described);
    if(m){const IMP orig=method_getImplementation(m);IMP wrap=imp_implementationWithBlock(^id(id buffer,id descriptor){
      recordEvent('E',buffer,nil,0);return reinterpret_cast<id(*)(id,SEL,id)>(orig)(buffer,described,descriptor);
    });class_replaceMethod(cls,described,wrap,method_getTypeEncoding(m));}
  }
'''
# Hook installation holds hooksMutex but callbacks run only after it unlocks.
assert s.count(anchor)==1;s=s.replace(anchor,anchor+addition)
(P/'readiness_observer.mm').write_text(s)
command=['xcrun','clang++','-std=c++17','-O2','-dynamiclib','-fblocks','-framework','Foundation','-framework','Metal',str(P/'readiness_observer.mm'),'-o',str(P/'readiness_observer.dylib')]
with open(f'/tmp/slotstream-model-{os.getuid()}.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 result=subprocess.run(command,cwd=R,capture_output=True,text=True)
(P/'readiness-observer-build.json').write_text(json.dumps({'command':command,'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr},indent=2));print(result.stderr);raise SystemExit(result.returncode)
