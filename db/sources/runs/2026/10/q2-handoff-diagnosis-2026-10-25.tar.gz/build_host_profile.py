from pathlib import Path
import sys,json,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1];PREV=R/'.build/q2-typical-20261025'
sys.path.insert(0,str(R/'Tools'));from optimization_build import build
paths=['Sources/Slotstream/NativeExpertSchedule.swift','Sources/Slotstream/ExpertStore.swift','Sources/Slotstream/Layers.swift','Sources/slotstream-cli/Q2ProfileCommand.swift'];original={p:(R/p).read_bytes()for p in paths}
s=original[paths[0]].decode()
profile='''
package enum Q2SubmissionProfile {
    package struct Entry { let rows: Int; let staged: Int; let t0,t1,t2,t3,t4,t5,t6: UInt64 }
    package static var enabled=false
    private static var values: [Entry]=[]
    package static func reset() { enabled=true; values.removeAll(keepingCapacity:true); values.reserveCapacity(64) }
    package static func record(_ entry: Entry) { values.append(entry) }
    package static func take() -> [[String:Any]] {
        enabled=false
        return values.map { ["rows":$0.rows,"staged":$0.staged,"times":[$0.t0,$0.t1,$0.t2,$0.t3,$0.t4,$0.t5,$0.t6]] }
    }
}
'''
s+=profile
anchor='''        try autoreleasepool {
            guard !ids.isEmpty''';assert s.count(anchor)==1;s=s.replace(anchor,'''        try autoreleasepool {
            let profiling=Q2SubmissionProfile.enabled
            let t0=profiling ? RuntimeClock.now() : 0
            guard !ids.isEmpty''')
anchor='            let grouping = NativeExpertTiles.Grouping(ids: ids)';assert s.count(anchor)==1;s=s.replace(anchor,'''            let t1=profiling ? RuntimeClock.now() : 0
'''+anchor)
anchor='            let x = contiguous(input)';assert s.count(anchor)==1;s=s.replace(anchor,'''            let t2=profiling ? RuntimeClock.now() : 0
'''+anchor)
anchor='            let result = withExtendedLifetime((x, weightOwners, prerequisite, forecastArena, stream)) {';assert s.count(anchor)==1;s=s.replace(anchor,'''            let t3=profiling ? RuntimeClock.now() : 0
'''+anchor)
anchor='            guard result == 0, let output, let job else';assert s.count(anchor)==1;s=s.replace(anchor,'''            let t4=profiling ? RuntimeClock.now() : 0
'''+anchor)
anchor='            if awaitingReads || Self.earlySubmission { asyncEval(value) }';assert s.count(anchor)==1;s=s.replace(anchor,'''            let t5=profiling ? RuntimeClock.now() : 0
'''+anchor+'''
            let t6=profiling ? RuntimeClock.now() : 0
            if profiling { Q2SubmissionProfile.record(.init(rows:count,staged:stagedSlots.count,t0:t0,t1:t1,t2:t2,t3:t3,t4:t4,t5:t5,t6:t6)) }''')
cli=(PREV/'replay-Q2ProfileCommand.swift').read_text().replace('Q2TypicalTrace.reset(enabled:true)','Q2TypicalTrace.reset(enabled:true)\n                        Q2SubmissionProfile.reset()').replace('"read_intervals":Q2DiagnosticReads.take(),','"submission_profile":Q2SubmissionProfile.take(),"read_intervals":Q2DiagnosticReads.take(),')
(P/'host-profile-NativeExpertSchedule.swift').write_text(s);(P/'host-profile-Q2ProfileCommand.swift').write_text(cli)
(P/'host-profile-plan.json').write_text(json.dumps({'purpose':'Attribute native expert host preparation before selecting another optimization. Fixed captured width4 pass,393evictions,15GB; same cached/partial read-ahead controls. Seven monotonic timestamps per layer split validation, grouping, shared input creation, native bridge preparation, pending/staging ownership and async submission. Preallocated value storage, serialization after timed work. No per-read recording; no performance qualification from instrumented run.', 'prior_result':'Clean readiness NSSN: all CPU-ready waits precede first compute, GPU timestamps start after publication. Native resumed3.70ms/pass versus Splash4.04ms with partial misses/read-ahead. GPU intervals43.18vs44.73ms, walls83.33vs79.27ms under extra observer. Event wake-up is not the main demonstrated delay; native per-layer host preparation deserves attribution.'},indent=2))
try:
 (R/paths[0]).write_text(s);(R/paths[1]).write_bytes((PREV/'replay-ExpertStore.swift').read_bytes());(R/paths[2]).write_bytes((PREV/'Layers.swift').read_bytes());(R/paths[3]).write_text(cli)
 result=build(R,P/'host-profile-build',required_gb=10,jobs=4);print({k:v for k,v in result.items()if k in ['passed','error','elapsed_seconds']},flush=True)
finally:
 for p,b in original.items():(R/p).write_bytes(b)
 (P/'host-profile-restored-after-build.json').write_text(json.dumps({p:hashlib.sha256((R/p).read_bytes()).hexdigest()for p in paths},indent=2))
if not result['passed']:raise SystemExit(1)
