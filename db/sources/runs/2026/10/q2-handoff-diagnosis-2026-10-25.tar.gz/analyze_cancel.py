from pathlib import Path
import json,csv,statistics,collections
P=Path(__file__).resolve().parent
arms=json.loads((P/'cancel-ledger.json').read_text());result=[]
def total(xs):
 ys=[]
 for a,b in sorted(xs):
  if b<=a:continue
  if ys and a<=ys[-1][1]:ys[-1][1]=max(b,ys[-1][1])
  else:ys.append([a,b])
 return sum(b-a for a,b in ys)
for a in arms:
 cs=[{k:float(v) for k,v in r.items()} for r in csv.DictReader(l for l in next(P.glob(a['label']+'-commands*.csv')).open() if not l.startswith('#'))]
 rows=[]
 for r in a['runs']:
  if r['round']<2:continue
  lo,hi=r['start_ns']/1e9,r['end_ns']/1e9
  gpu=[(max(lo,c['start']),min(hi,c['end'])) for c in cs if c['end']>lo and c['start']<hi]
  es=collections.defaultdict(dict)
  for e in r['trace']:es[e['layer']][e['kind']]=e
  row={'condition':r['condition'],'round':r['round'],'wall_ms':r['seconds']*1000,'gpu_intervals_ms':total(gpu)*1000,'commands':len(gpu),'demand':r['records_fetched'],'adopted':r['records_adopted']}
  for name,b,e in [('prepare_ms','prepare_start','prepare_end'),('read_wait_ms','prepare_end','reads_ready'),('route_wait_ms','route_start','route_ready')]:
   row[name]=sum((x[e]['ns']-x[b]['ns'])/1e6 for x in es.values() if b in x and e in x)
  rows.append(row)
 cs={c:{k:statistics.median(r[k] for r in rows if r['condition']==c) for k in rows[0] if k not in ['condition','round']} for c in sorted(set(r['condition'] for r in rows))}
 result.append(dict(label=a['label'],arm=a['arm'],eligible=a['eligible'],conditions=cs))
(P/'cancel-analysis.json').write_text(json.dumps(result,indent=2))
summary={}
for c in ['cached_off','partial_off','cached_on','partial_on']:
 summary[c]={arm:{k:statistics.mean(a['conditions'][c][k] for a in result if a['arm']==arm) for k in result[0]['conditions'][c]} for arm in ['A','B']}
(P/'cancel-attribution-summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
