from pathlib import Path
import csv,json,collections,statistics
P=Path(__file__).resolve().parent
ledger=json.loads((P/'read-work-reserved-ledger.json').read_text());out=[]
def parse(path):
 lines=path.read_text().splitlines();footer=dict(x.split('=')for x in lines[-1][2:].split());assert int(footer['total'])<int(footer['cap']);return list(csv.DictReader(l for l in lines if not l.startswith('#')))
def union(xs):
 total=0;end=0
 for a,b in sorted(xs):
  if b<=a:continue
  if a>=end:total+=b-a;end=b
  elif b>end:total+=b-end;end=b
 return total
for arm in ledger:
 if arm['exit_code']:continue
 label=arm['label'];reads=[{k:(float(v)if k in ['start','end']else int(v))for k,v in r.items()}for r in parse(next(P.glob(label+'-reads.*.csv')))];assert reads
 commands=[{k:float(v)for k,v in r.items()}for r in parse(next(P.glob(label+'-commands.*.csv')))];rows=[]
 for r in arm['runs']:
  if r['round']<2:continue
  lo,hi=(r['start_ns']/1e9,r['end_ns']/1e9)if arm['arm']=='N'else(r['start'],r['end'])
  rs=[x for x in reads if lo<=x['start']<hi and x['bytes']>4096];read_union=union([(x['start'],min(hi,x['end']))for x in rs]);events=sorted([(t,d)for x in rs for t,d in [(x['start'],1),(x['end'],-1)] ]);active=0;max_active=0
  for t,d in events:active+=d;max_active=max(active,max_active)
  gpu=union([(max(lo,x['start']),min(hi,x['end']))for x in commands if x['end']>lo and x['start']<hi]);cs=[c for c in commands if c['end']>lo and c['start']<hi];both=union([(max(x['start'],c['start'],lo),min(x['end'],c['end'],hi))for x in rs for c in cs if c['end']>lo and c['start']<hi and x['end']>c['start']and x['start']<c['end']])
  row=dict(condition=r['condition'],round=r['round'],wall_ms=(hi-lo)*1000,gpu_ms=gpu*1000,read_union_ms=read_union*1000,read_gpu_overlap_ms=both*1000,neither_ms=((hi-lo)-gpu-read_union+both)*1000,bytes=sum(x['bytes']for x in rs),reads=len(rs),max_concurrency=max_active,mean_concurrency=sum(x['end']-x['start']for x in rs)/max(read_union,1e-9),threads=len(set(x['thread']for x in rs)),median_read_us=statistics.median((x['end']-x['start'])*1e6 for x in rs)if rs else 0,qos_counts=dict(collections.Counter(x['qos']for x in rs)),byte_counts=dict(collections.Counter(x['bytes']for x in rs)),errors=sum(x['error']!=0 or x['result']!=x['bytes']for x in rs))
  if arm['arm']=='N':
   spans=[]
   for layer in range(48):
    es={e['kind']:e['ns']/1e9 for e in r['trace']if e['layer']==layer};a,b=es['prepare_end'],es['reads_ready'];work=[x for x in rs if a<=x['start']<b];local_union=union([(max(a,x['start']),min(b,x['end']))for x in rs if x['end']>a and x['start']<b]);spans.append(dict(layer=layer,host_ms=(b-a)*1000,read_union_ms=local_union*1000,first_start_us=(min(x['start']for x in work)-a)*1e6 if work else 0,last_end_to_ready_us=(b-max(x['end']for x in work))*1e6 if work else 0,reads=len(work),wall_gap_ms=(b-a-local_union)*1000))
   row['native_read_wait_without_pread_ms']=sum(x['wall_gap_ms']for x in spans);row['native_read_wait_first_start_ms']=sum(x['first_start_us']for x in spans)/1000;row['native_read_wait_tail_ms']=sum(x['last_end_to_ready_us']for x in spans)/1000;row['layer_spans']=spans
  rows.append(row)
 summary={c:{k:statistics.median(r[k]for r in rows if r['condition']==c)for k in rows[0]if k not in ['condition','round','qos_counts','byte_counts','layer_spans']}for c in sorted(set(r['condition']for r in rows))}
 out.append(dict(label=label,arm=arm['arm'],eligible=arm['eligible'],conditions=summary,rows=rows))
(P/'read-work-reserved-analysis.json').write_text(json.dumps(out,indent=2))
summary={c:{arm:{k:statistics.mean(a['conditions'][c][k]for a in out if a['arm']==arm)for k in next(a['conditions'][c]for a in out if a['arm']==arm)}for arm in sorted(set(a['arm']for a in out))}for c in ['cached_off','partial_off','cached_on','partial_on']}
(P/'read-work-reserved-summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
