from pathlib import Path
import subprocess,json
P=Path(__file__).resolve().parent
s=(P/'stage_observer.mm').read_text()
s=s.replace('struct StageRecord { double encoded=0; uintptr_t buffer=0,encoder=0; };','struct StageRecord { double encoded=0; uintptr_t buffer=0,encoder=0; unsigned requested=0,actual=0; };')
s=s.replace('MTLComputePassDescriptor* desc=[input copy];','MTLComputePassDescriptor* desc=[input copy];\n  if(getenv("SLOTSTREAM_DIAGNOSTIC_SERIAL_ENCODER"))desc.dispatchType=MTLDispatchTypeSerial;')
s=s.replace('stages[i]={now(),(uintptr_t)buffer,(uintptr_t)encoder};','stages[i]={now(),(uintptr_t)buffer,(uintptr_t)encoder,(unsigned)input.dispatchType,(unsigned)desc.dispatchType};')
s=s.replace('encoder,gpu_start,gpu_end\\n','encoder,gpu_start,gpu_end,requested,actual\\n')
s=s.replace('%zu,%.9f,%llu,%llu,%llu,%llu\\n','%zu,%.9f,%llu,%llu,%llu,%llu,%u,%u\\n')
s=s.replace('(unsigned long long)data[2*j].timestamp,(unsigned long long)data[2*j+1].timestamp);','(unsigned long long)data[2*j].timestamp,(unsigned long long)data[2*j+1].timestamp,stages[i].requested,stages[i].actual);')
(P/'encoder_mode_observer.mm').write_text(s)
r=subprocess.run(['xcrun','clang++','-std=c++17','-O2','-dynamiclib','-fblocks','-fno-objc-arc','-framework','Foundation','-framework','Metal',str(P/'encoder_mode_observer.mm'),'-o',str(P/'encoder_mode_observer.dylib')],capture_output=True,text=True)
(P/'encoder-mode-observer-build.json').write_text(json.dumps(dict(exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr),indent=2));print(r.stderr);raise SystemExit(r.returncode)
