// Diagnostic-only public Metal command-buffer timestamps. Never linked into
// production. Does not commit, wait, change encoding or manufacture GPU work.
#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#import <objc/runtime.h>
#include <mach/mach_time.h>
#include <atomic>
#include <cstdio>
#include <cstdlib>
#include <mutex>
#include <set>
#include <unistd.h>

namespace {
constexpr size_t limit = 262144;
struct Record { double submitted=0, start=0, end=0, completed=0; unsigned status=0; uintptr_t buffer=0; };
Record records[limit];
std::atomic<size_t> next{0};
std::mutex hooksMutex;
std::set<Class> devices, queues, commands, sharedEvents;
constexpr size_t eventLimit=1048576;
struct EventRecord { char kind=0; double stamp=0; uintptr_t buffer=0,event=0; uint64_t value=0; };
EventRecord eventRecords[eventLimit]; std::atomic<size_t> nextEvent{0};
double now() { static mach_timebase_info_data_t t=[] { mach_timebase_info_data_t v; mach_timebase_info(&v); return v; }();
  return double(mach_absolute_time()) * t.numer / t.denom / 1e9; }
void recordEvent(char kind, id buffer, id event, uint64_t value) {
  const size_t i=nextEvent.fetch_add(1);
  if(i<eventLimit) eventRecords[i]={kind,now(),(uintptr_t)buffer,(uintptr_t)event,value};
}
void sharedEvent(id<MTLSharedEvent> object) {
  if(!object)return;
  std::lock_guard lock(hooksMutex); Class cls=object_getClass(object);
  if(!sharedEvents.insert(cls).second)return;
  SEL sel=@selector(setSignaledValue:); Method method=class_getInstanceMethod(cls,sel);
  if(!method)return;
  const IMP original=method_getImplementation(method);
  IMP wrapped=imp_implementationWithBlock(^(id event,uint64_t value) {
    recordEvent('S',nil,event,value);
    reinterpret_cast<void(*)(id,SEL,uint64_t)>(original)(event,sel,value);
    recordEvent('R',nil,event,value);
  });
  class_replaceMethod(cls,sel,wrapped,method_getTypeEncoding(method));
}

constexpr size_t stageLimit=65536;
struct StageRecord { double encoded=0; uintptr_t buffer=0,encoder=0; unsigned requested=0,actual=0; };
StageRecord stages[stageLimit]; std::atomic<size_t> nextStage{0};
constexpr size_t stagesPerBuffer=2048;
std::mutex counterMutex; id<MTLCounterSampleBuffer> counterBuffers[stageLimit/stagesPerBuffer]={}; id<MTLDevice> counterDevice=nil;
MTLTimestamp initialCPU=0,initialGPU=0;
void initializeCounters(id<MTLDevice> d){
  std::lock_guard lock(counterMutex);if(counterDevice)return;
  if(![d supportsCounterSampling:MTLCounterSamplingPointAtStageBoundary])return;
  for(id<MTLCounterSet> set in d.counterSets)if([set.name isEqualToString:MTLCommonCounterSetTimestamp]){
    auto desc=[MTLCounterSampleBufferDescriptor new];desc.counterSet=set;desc.storageMode=MTLStorageModeShared;desc.sampleCount=stagesPerBuffer*2;
    for(size_t i=0;i<stageLimit/stagesPerBuffer;++i){
      NSError* error=nil;counterBuffers[i]=[d newCounterSampleBufferWithDescriptor:desc error:&error];
      if(!counterBuffers[i]){fprintf(stderr,"STAGE_COUNTER_ERROR %s\n",error.description.UTF8String);[desc release];return;}
    }
    [desc release];
    counterDevice=[d retain];[d sampleTimestamps:&initialCPU gpuTimestamp:&initialGPU];return;
  }
}
id stageEncoder(id buffer,MTLComputePassDescriptor* input,IMP original){
  SEL selector=@selector(computeCommandEncoderWithDescriptor:);
  const size_t i=nextStage.fetch_add(1);
  if(!counterDevice || i>=stageLimit || input.sampleBufferAttachments[0].sampleBuffer)
    return reinterpret_cast<id(*)(id,SEL,id)>(original)(buffer,selector,input);
  MTLComputePassDescriptor* desc=[input copy];
  if(getenv("SLOTSTREAM_DIAGNOSTIC_SERIAL_ENCODER"))desc.dispatchType=MTLDispatchTypeSerial;
  auto attachment=desc.sampleBufferAttachments[0];attachment.sampleBuffer=counterBuffers[i/stagesPerBuffer];
  attachment.startOfEncoderSampleIndex=(i%stagesPerBuffer)*2;attachment.endOfEncoderSampleIndex=(i%stagesPerBuffer)*2+1;
  id encoder=reinterpret_cast<id(*)(id,SEL,id)>(original)(buffer,selector,desc);
  stages[i]={now(),(uintptr_t)buffer,(uintptr_t)encoder,(unsigned)input.dispatchType,(unsigned)desc.dispatchType};[desc release];return encoder;
}
void dumpStages(const char* prefix){
  if(!counterDevice)return;
  @autoreleasepool {
    const size_t count=std::min(nextStage.load(),stageLimit);
    MTLTimestamp finalCPU=0,finalGPU=0;[counterDevice sampleTimestamps:&finalCPU gpuTimestamp:&finalGPU];
    char path[4096];snprintf(path,sizeof(path),"%s.%d.stages.csv",prefix,getpid());FILE*f=fopen(path,"wx");if(!f)return;
    fprintf(f,"index,encoded,buffer,encoder,gpu_start,gpu_end,requested,actual\n");
    for(size_t base=0;base<count;base+=stagesPerBuffer){
      size_t n=std::min(stagesPerBuffer,count-base);
      NSData* values=[counterBuffers[base/stagesPerBuffer] resolveCounterRange:NSMakeRange(0,n*2)];
      if(!values || values.length!=n*2*sizeof(MTLCounterResultTimestamp)){
        fprintf(stderr,"STAGE_COUNTER_RESOLVE_ERROR\n");fclose(f);return;
      }
      auto data=(const MTLCounterResultTimestamp*)values.bytes;
      for(size_t j=0;j<n;++j){size_t i=base+j;fprintf(f,"%zu,%.9f,%llu,%llu,%llu,%llu,%u,%u\n",i,stages[i].encoded,
        (unsigned long long)stages[i].buffer,(unsigned long long)stages[i].encoder,
        (unsigned long long)data[2*j].timestamp,(unsigned long long)data[2*j+1].timestamp,stages[i].requested,stages[i].actual);}
    }
    fprintf(f,"# total=%zu cap=%zu cpu_initial=%llu gpu_initial=%llu cpu_final=%llu gpu_final=%llu\n",nextStage.load(),stageLimit,
      (unsigned long long)initialCPU,(unsigned long long)initialGPU,(unsigned long long)finalCPU,(unsigned long long)finalGPU);fclose(f);
  }
}

void dump() {
  const char* path=getenv("SLOTSTREAM_METAL_OBSERVER"); if(!path) return;
  dumpStages(path);
  if(next.load()==0) return;
  char output[4096]; snprintf(output,sizeof(output),"%s.%d.csv",path,getpid());
  FILE* f=fopen(output,"wx"); if(!f) return;
  fprintf(f,"index,submitted,start,end,completed,status,buffer\n");
  const size_t count=next.load();
  for(size_t i=0;i<std::min(count,limit);++i) {const auto& r=records[i];
    fprintf(f,"%zu,%.9f,%.9f,%.9f,%.9f,%u,%llu\n",i,r.submitted,r.start,r.end,r.completed,r.status,(unsigned long long)r.buffer);}
  fprintf(f,"# total=%zu cap=%zu\n",count,limit); fclose(f);
  snprintf(output,sizeof(output),"%s.%d.events.csv",path,getpid());
  f=fopen(output,"wx"); if(!f)return;
  fprintf(f,"kind,stamp,buffer,event,value\n");
  const size_t events=nextEvent.load();
  for(size_t i=0;i<std::min(events,eventLimit);++i){const auto&r=eventRecords[i];
    fprintf(f,"%c,%.9f,%llu,%llu,%llu\n",r.kind,r.stamp,(unsigned long long)r.buffer,(unsigned long long)r.event,(unsigned long long)r.value);}
  fprintf(f,"# total=%zu cap=%zu\n",events,eventLimit);fclose(f);
}
void command(id<MTLCommandBuffer> object) {
  if(!object || !getenv("SLOTSTREAM_METAL_OBSERVER")) return;
  std::lock_guard lock(hooksMutex); Class cls=object_getClass(object);
  if(!commands.insert(cls).second) return;
  {
    SEL waitSel=@selector(encodeWaitForEvent:value:);Method waitMethod=class_getInstanceMethod(cls,waitSel);
    if(waitMethod){const IMP originalWait=method_getImplementation(waitMethod);
      IMP wrappedWait=imp_implementationWithBlock(^(id buffer,id<MTLSharedEvent> event,uint64_t value){
        sharedEvent(event);recordEvent('W',buffer,event,value);
        reinterpret_cast<void(*)(id,SEL,id,uint64_t)>(originalWait)(buffer,waitSel,event,value);
      });class_replaceMethod(cls,waitSel,wrappedWait,method_getTypeEncoding(waitMethod));}
    const IMP descriptorOriginal=method_getImplementation(class_getInstanceMethod(cls,@selector(computeCommandEncoderWithDescriptor:)));
    SEL simple=@selector(computeCommandEncoder);Method m=class_getInstanceMethod(cls,simple);
    if(m){const IMP orig=method_getImplementation(m);IMP wrap=imp_implementationWithBlock(^id(id buffer){
      recordEvent('E',buffer,nil,0);auto desc=[MTLComputePassDescriptor computePassDescriptor];desc.dispatchType=MTLDispatchTypeSerial;return stageEncoder(buffer,desc,descriptorOriginal);
    });class_replaceMethod(cls,simple,wrap,method_getTypeEncoding(m));}
    SEL typed=@selector(computeCommandEncoderWithDispatchType:);m=class_getInstanceMethod(cls,typed);
    if(m){const IMP orig=method_getImplementation(m);IMP wrap=imp_implementationWithBlock(^id(id buffer,NSUInteger type){
      recordEvent('E',buffer,nil,0);auto desc=[MTLComputePassDescriptor computePassDescriptor];desc.dispatchType=(MTLDispatchType)type;return stageEncoder(buffer,desc,descriptorOriginal);
    });class_replaceMethod(cls,typed,wrap,method_getTypeEncoding(m));}
    SEL described=@selector(computeCommandEncoderWithDescriptor:);m=class_getInstanceMethod(cls,described);
    if(m){const IMP orig=method_getImplementation(m);IMP wrap=imp_implementationWithBlock(^id(id buffer,id descriptor){
      recordEvent('E',buffer,nil,0);return stageEncoder(buffer,descriptor,orig);
    });class_replaceMethod(cls,described,wrap,method_getTypeEncoding(m));}
  }

  SEL sel=@selector(commit); Method method=class_getInstanceMethod(cls,sel);
  const IMP original=method_getImplementation(method);
  IMP wrapped=imp_implementationWithBlock(^(id<MTLCommandBuffer> buffer) {
    const size_t i=next.fetch_add(1);
    if(i<limit) {
      records[i].submitted=now(); records[i].buffer=(uintptr_t)buffer;
      [buffer addCompletedHandler:^(id<MTLCommandBuffer> done) {
        records[i].start=done.GPUStartTime; records[i].end=done.GPUEndTime;
        records[i].completed=now(); records[i].status=unsigned(done.status);
      }];
    }
    reinterpret_cast<void(*)(id,SEL)>(original)(buffer,sel);
  });
  class_replaceMethod(cls,sel,wrapped,method_getTypeEncoding(method));
}
void queue(id<MTLCommandQueue> object) {
  if(!object || !getenv("SLOTSTREAM_METAL_OBSERVER")) return;
  std::lock_guard lock(hooksMutex); Class cls=object_getClass(object);
  if(!queues.insert(cls).second) return;
  for(SEL sel: { @selector(commandBuffer), @selector(commandBufferWithUnretainedReferences) }) {
    Method method=class_getInstanceMethod(cls,sel); if(!method) continue;
    const IMP original=method_getImplementation(method);
    IMP wrapped=imp_implementationWithBlock(^id(id q) {
      id result=reinterpret_cast<id(*)(id,SEL)>(original)(q,sel); command(result); return result;
    });
    class_replaceMethod(cls,sel,wrapped,method_getTypeEncoding(method));
  }
  SEL sel=@selector(commandBufferWithDescriptor:);
  Method method=class_getInstanceMethod(cls,sel);
  if(method) {
    const IMP original=method_getImplementation(method);
    IMP wrapped=imp_implementationWithBlock(^id(id q,id descriptor) {
      id result=reinterpret_cast<id(*)(id,SEL,id)>(original)(q,sel,descriptor); command(result); return result;
    });
    class_replaceMethod(cls,sel,wrapped,method_getTypeEncoding(method));
  }
}
void device(id<MTLDevice> object) {
  if(object && getenv("SLOTSTREAM_METAL_OBSERVER")) initializeCounters(object);
  if(!object || !getenv("SLOTSTREAM_METAL_OBSERVER")) return;
  std::lock_guard lock(hooksMutex); Class cls=object_getClass(object);
  if(!devices.insert(cls).second) return;
  SEL sel=@selector(newCommandQueue); Method method=class_getInstanceMethod(cls,sel);
  const IMP original=method_getImplementation(method);
  IMP wrapped=imp_implementationWithBlock(^id(id d) {
    id result=reinterpret_cast<id(*)(id,SEL)>(original)(d,sel); queue(result); return result;
  });
  class_replaceMethod(cls,sel,wrapped,method_getTypeEncoding(method));
  SEL other=@selector(newCommandQueueWithMaxCommandBufferCount:);
  Method otherMethod=class_getInstanceMethod(cls,other);
  if(otherMethod) {
    const IMP originalOther=method_getImplementation(otherMethod);
    IMP otherWrapped=imp_implementationWithBlock(^id(id d,NSUInteger count) {
      id result=reinterpret_cast<id(*)(id,SEL,NSUInteger)>(originalOther)(d,other,count); queue(result); return result;
    });
    class_replaceMethod(cls,other,otherWrapped,method_getTypeEncoding(otherMethod));
  }
}
__attribute__((constructor)) void initialize() { atexit(dump); }
}

extern "C" id<MTLDevice> observedDevice() {
  id<MTLDevice> result=MTLCreateSystemDefaultDevice(); device(result); return result;
}
extern "C" NSArray<id<MTLDevice>>* observedDevices() {
  NSArray<id<MTLDevice>>* result=MTLCopyAllDevices(); for(id<MTLDevice> d in result) device(d); return result;
}
__attribute__((used)) static const struct { const void* replacement; const void* original; }
interposers[] __attribute__((section("__DATA,__interpose"))) = {
  {(const void*)&observedDevice,(const void*)&MTLCreateSystemDefaultDevice},
  {(const void*)&observedDevices,(const void*)&MTLCopyAllDevices}
};
