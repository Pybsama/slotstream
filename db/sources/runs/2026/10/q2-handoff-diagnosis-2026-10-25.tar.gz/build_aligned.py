from pathlib import Path
import sys,json,hashlib,difflib,shutil
P=Path(__file__).resolve().parent;R=P.parents[1];PREV=R/'.build/q2-typical-20261025';OLD=R/'.build/native-replay-20261023'
sys.path.insert(0,str(R/'Tools'));from optimization_build import build
paths=['Sources/Slotstream/NativeForecastArena.swift','Sources/Slotstream/NativeExpertSchedule.swift','Sources/CNativeSchedule/NativeSchedule.cpp','Sources/CNativeSchedule/include/NativeSchedule.h','Sources/Slotstream/ExpertPrefetch.swift','Sources/Slotstream/ExpertStore.swift','Sources/Slotstream/Checkpoint.swift','Sources/Slotstream/Layers.swift','Sources/slotstream-cli/Q2ProfileCommand.swift']
original={p:(R/p).read_bytes()for p in paths};changed={}
s=(P/'padded-NativeForecastArena.swift').read_text()
s=s.replace('    package func acquire() -> Lease? {','    package var pageAligned: Bool { bases.allSatisfy { Int(bitPattern: $0) % 16384 == 0 } }\n    package var strideBytes: Int { pieceStrides.max() ?? 0 }\n\n    package func acquire(offsets: [Int] = [0, 0, 0]) -> Lease? {')
s=s.replace('            guard let index = free.popLast() else { return nil }','            guard offsets.count == 3, offsets.enumerated().allSatisfy({ $0.element >= 0 && $0.element < 16384 && $0.element + pieceBytes[$0.offset] <= pieceStrides[$0.offset] }),\n                  let index = free.popLast() else { return nil }')
s=s.replace('return Lease(arena: self, index: index)','return Lease(arena: self, index: index, offsets: offsets)').replace('        private var released = false','        private var released = false\n        package let offsets: [Int]')
s=s.replace('fileprivate init(arena: NativeForecastArena, index: Int) { self.arena = arena; self.index = index }','fileprivate init(arena: NativeForecastArena, index: Int, offsets: [Int]) { self.arena = arena; self.index = index; self.offsets = offsets }')
s=s.replace('zip(arena.bases, arena.pieceStrides).map { $0 + index * $1 }','arena.bases.indices.map { arena.bases[$0] + index * arena.pieceStrides[$0] + offsets[$0] }');changed[paths[0]]=s
s=(P/'padded-NativeExpertSchedule.swift').read_text().replace('device const uchar* forecast, device const int* sources, uint2 position)', 'device const uchar* forecast, device const int* sources, uint piece, uint2 position)')
s=s.replace('size_t source=predicted?size_t(sources[expert])*forecast_stride:size_t(expert)*raw_stride;','size_t source=predicted?size_t(sources[expert*4])*forecast_stride+size_t(sources[expert*4+piece+1]):size_t(expert)*raw_stride;')
s=s.replace('ready,forecast_down,sources,position.xy);','ready,forecast_down,sources,piece,position.xy);').replace('piece==0?forecast_gate:forecast_up,sources,position.xy);','piece==0?forecast_gate:forecast_up,sources,piece,position.xy);')
s=s.replace('Int32(source), Int32(lease.index),\n                owner.toOpaque()', 'Int32(source), Int32(lease.index), lease.offsets.map(Int32.init),\n                owner.toOpaque()');changed[paths[1]]=s
s=(P/'padded-NativeSchedule.cpp').read_text().replace('sources.emplace(allocator::malloc(size_t(count) * sizeof(int32_t)), Shape{count}, int32);','sources.emplace(allocator::malloc(size_t(count) * 4 * sizeof(int32_t)), Shape{count, 4}, int32);').replace('std::fill_n(sources->data<int32_t>(), count, 0);','std::fill_n(sources->data<int32_t>(), count * 4, 0);')
s=s.replace('int ss_schedule_stage_forecast(void *j, int index, int source, void *context,', 'int ss_schedule_stage_forecast(void *j, int index, int source, const int32_t *offsets, void *context,')
s=s.replace('if (!j || !context || !release) throw std::invalid_argument("Missing forecast lease");','if (!j || !offsets || !context || !release) throw std::invalid_argument("Missing forecast lease");\n    for(int piece=0;piece<3;++piece) if(offsets[piece]<0 || offsets[piece]>=16384) throw std::invalid_argument("Invalid forecast payload offset");')
s=s.replace('work.sources->data<int32_t>()[index] = source;', 'work.sources->data<int32_t>()[index * 4] = source;\n    std::copy_n(offsets,3,work.sources->data<int32_t>()+index*4+1);');changed[paths[2]]=s
s=original[paths[3]].decode().replace('int ss_schedule_stage_forecast(void *job, int index, int source, void *context,','int ss_schedule_stage_forecast(void *job, int index, int source, const int32_t *offsets, void *context,');changed[paths[3]]=s
s=original[paths[6]].decode();anchor='    package func readPageAlignedChecked(into dst: UnsafeMutableRawPointer, capacity: Int,';assert s.count(anchor)==1
s=s.replace(anchor,'''    package func pageAlignedPayloadOffset(offset: Int, count: Int, capacity: Int) throws -> Int {
        let span = try ExactRead.pageSpan(base: base, length: length, offset: offset, count: count, capacity: capacity)
        return verifiedFile == nil ? span.skip : 0
    }

'''+anchor);changed[paths[6]]=s
methods='''    package func forecastPayloadOffsets(_ key: ExpertKey, capacity: Int) throws -> [Int] {
        guard isQ2, !supportsRecordReads, key.layer >= 0, key.layer < cfg.numLayers,
              key.expert >= 0, key.expert < cfg.numExperts else { throw SlotPoolError.invalidKey(key) }
        return try pieceRowBytes.indices.map { piece in
            let handle = readHandles?[key.layer][piece] ?? index.readHandle(for: refs[key.layer][piece])
            return try handle.pageAlignedPayloadOffset(offset: key.expert * pieceRowBytes[piece],
                count: pieceRowBytes[piece], capacity: capacity)
        }
    }

    /// Private unpublished forecast storage, never a live expert-cache slot.
    package func readForecastPage(into destination: UnsafeMutableRawPointer, key: ExpertKey, piece: Int,
                                  capacity: Int, shouldContinue: () -> Bool) throws {
        guard isQ2, !supportsRecordReads, piece >= 0, piece < pieceRowBytes.count,
              key.layer >= 0, key.layer < cfg.numLayers, key.expert >= 0, key.expert < cfg.numExperts else {
            throw SlotPoolError.invalidKey(key)
        }
        guard shouldContinue() else { throw CheckpointReadError.cancelled }
        try readFault?.beforeRead()
        let bytes = pieceRowBytes[piece]
        let handle = readHandles?[key.layer][piece] ?? index.readHandle(for: refs[key.layer][piece])
        let skip = try handle.pageAlignedPayloadOffset(offset: key.expert * bytes, count: bytes, capacity: capacity)
        let base = destination - skip
        guard Int(bitPattern: base) % ExactRead.pageBytes == 0 else { throw CheckpointReadError.invalidRange }
        let payload = try handle.readPageAlignedChecked(into: base, capacity: capacity,
            offset: key.expert * bytes, count: bytes, shouldContinue: shouldContinue)
        guard payload == UnsafeRawPointer(destination) else { throw CheckpointReadError.invalidRange }
        guard shouldContinue() else { throw CheckpointReadError.cancelled }
    }

'''
anchor='    /// Whole-record speculative reads exist only on the packed layout,'
assert original[paths[5]].decode().count(anchor)==1
changed[paths[5]]=original[paths[5]].decode().replace(anchor,methods+anchor)
s=original[paths[4]].decode().replace('arena: NativeForecastArena? = nil) {','arena: NativeForecastArena? = nil, payloadOffsets: [Int] = [0, 0, 0]) {').replace('let acquired = arena.acquire()', 'let acquired = arena.acquire(offsets: payloadOffsets)')
s=s.replace('    package private(set) var nativeForecastArena: NativeForecastArena?', '    package private(set) var nativeForecastArena: NativeForecastArena?\n    private var forecastPageReader: ExpertPieceReader?\n    private var forecastOffsets: ((ExpertKey) -> [Int]?)?')
s=s.replace('            nativeForecastArena = try? NativeForecastArena(pieceBytes: store.pieceRowBytes)','''            nativeForecastArena = try? NativeForecastArena(pieceBytes: store.pieceRowBytes)
            if let arena = nativeForecastArena, arena.pageAligned {
                let capacity = arena.strideBytes
                forecastOffsets = { try? store.forecastPayloadOffsets($0, capacity: capacity) }
                forecastPageReader = { key, piece, destination, shouldContinue in
                    try store.readForecastPage(into: destination, key: key, piece: piece,
                        capacity: capacity, shouldContinue: shouldContinue)
                }
            }''')
a='''                guard let allocated = ExpertPrefetchTicket(key: key, pass: currentPass, revision: revision,
                    pieceBytes: pieceBytes, accounting: accounting, arena: nativeForecastArena) else {'''
b='''                let offsets: [Int]
                if let forecastOffsets {
                    guard let value = forecastOffsets(key) else { continue }
                    offsets = value
                } else { offsets = [0, 0, 0] }
                guard let allocated = ExpertPrefetchTicket(key: key, pass: currentPass, revision: revision,
                    pieceBytes: pieceBytes, accounting: accounting, arena: nativeForecastArena,
                    payloadOffsets: offsets) else {'''
assert s.count(a)==1;s=s.replace(a,b)
s=s.replace('ticket.startPieces(reader: reader, lanes: lanes, queues: orderedReaderQueues,','ticket.startPieces(reader: forecastPageReader ?? reader, lanes: lanes, queues: orderedReaderQueues,');changed[paths[4]]=s
for f,s in changed.items():(P/('aligned-'+Path(f).name)).write_text(s)
(P/'aligned.patch').write_text(''.join(''.join(difflib.unified_diff(original[f].decode().splitlines(True),s.splitlines(True),fromfile='a/'+f,tofile='b/'+f))for f,s in changed.items()))
(P/'aligned-plan.json').write_text(json.dumps({'hypothesis':'Native partial-miss GPU interval penalty with forecasts remains unexplained. Splash reads whole pages directly into owned staging. Native copies private page-aligned scratch into its forecast arena. Earlier failed exact direct reads kept unaligned tight rows, so did not test the page-rounded path. Test aligned forecast reads carrying exact payload offsets into the GPU. Existing 128MiB reservation, 64 leases, 4067 cache slots, strict tensor/verified bounds, cancellation/faults and GPU-completion ownership remain. Padded-only control is separately rejected.','protocol':'15GB width4/393missingkeys ABBA with global model reservation and exact logits. If beneficial, original-byte/state/fault checks and uninstrumented complete ABCCBA versus v68 and Splash. Fast unchanged. Physical15GB guard,1GB headroom,600sec timeout.'},indent=2))
try:
 for f,s in changed.items():(R/f).write_text(s)
 (R/paths[5]).write_text((PREV/'replay-ExpertStore.swift').read_text().replace(anchor,methods+anchor))
 (R/paths[7]).write_bytes((PREV/'Layers.swift').read_bytes());(R/paths[8]).write_bytes((PREV/'replay-Q2ProfileCommand.swift').read_bytes())
 result=build(R,P/'aligned-replay-build',required_gb=10,jobs=4,wait_seconds=600)
 print({k:v for k,v in result.items()if k in ['passed','error','elapsed_seconds']},flush=True)
finally:
 for f,b in original.items():(R/f).write_bytes(b)
 (P/'aligned-restored-after-build.json').write_text(json.dumps({f:hashlib.sha256((R/f).read_bytes()).hexdigest()for f in paths},indent=2))
 for name in ['slotstream','slotstream-checks','mlx.metallib','build-identity.json','build-source.tar.gz']:shutil.copy2(OLD/'v68'/name,R/'.build/release'/name)
if not result['passed']:raise SystemExit(1)
