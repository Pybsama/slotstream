from pathlib import Path
import subprocess,json
P=Path(__file__).resolve().parent
s=(P/'readiness_observer.mm').read_text()
anchor='void dump() {'
extra=r'''
constexpr size_t stageLimit=65536;
struct StageRecord { double encoded=0; uintptr_t buffer=0,encoder=0; };
StageRecord stages[stageLimit]; std::atomic<size_t> nextStage{0};
constexpr size_t stagesPerBuffer=2048;
std::mutex counterMutex; id<MTLCounterSampleBuffer> counterBuffers[stageLimit/stagesPerBuffer]={}; id<MTLDevice> counterDevice=nil;
MTLTimestamp initialCPU=0,initialGPU=0;
void initializeCounters(id<MTLDevice> d){
  std::lock_guard lock(counterMutex);if(counterDevice)return;
  if(![d supportsCounterSampling:MTLCounterSamplingPointAtStageBoundary])return;
  for(id<MTLCounterSet> set in d.counterSets)if([set.name isEqualToString:MTLCommonCounterSetTimestamp]){
    auto desc=[MTLCounterSampleBufferDescriptor new];desc.counterSet=set;desc.storageMode=MTLStorageModeShared;desc.sampleCount=stagesPerBuffer*2;
    for(size_t i=0;i<stageLimit/stagesPerBuffer;++i){
      NSError* error=nil;counterBuffers[i]=[d newCounterSampleBufferWithDescriptor:desc error:&error];
      if(!counterBuffers[i]){fprintf(stderr,"STAGE_COUNTER_ERROR %s\n",error.description.UTF8String);[desc release];return;}
    }
    [desc release];
    counterDevice=[d retain];[d sampleTimestamps:&initialCPU gpuTimestamp:&initialGPU];return;
  }
}
id stageEncoder(id buffer,MTLComputePassDescriptor* input,IMP original){
  SEL selector=@selector(computeCommandEncoderWithDescriptor:);
  const size_t i=nextStage.fetch_add(1);
  if(!counterDevice || i>=stageLimit || input.sampleBufferAttachments[0].sampleBuffer)
    return reinterpret_cast<id(*)(id,SEL,id)>(original)(buffer,selector,input);
  MTLComputePassDescriptor* desc=[input copy];
  auto attachment=desc.sampleBufferAttachments[0];attachment.sampleBuffer=counterBuffers[i/stagesPerBuffer];
  attachment.startOfEncoderSampleIndex=(i%stagesPerBuffer)*2;attachment.endOfEncoderSampleIndex=(i%stagesPerBuffer)*2+1;
  id encoder=reinterpret_cast<id(*)(id,SEL,id)>(original)(buffer,selector,desc);
  stages[i]={now(),(uintptr_t)buffer,(uintptr_t)encoder};[desc release];return encoder;
}
void dumpStages(const char* prefix){
  if(!counterDevice)return;
  @autoreleasepool {
    const size_t count=std::min(nextStage.load(),stageLimit);
    MTLTimestamp finalCPU=0,finalGPU=0;[counterDevice sampleTimestamps:&finalCPU gpuTimestamp:&finalGPU];
    char path[4096];snprintf(path,sizeof(path),"%s.%d.stages.csv",prefix,getpid());FILE*f=fopen(path,"wx");if(!f)return;
    fprintf(f,"index,encoded,buffer,encoder,gpu_start,gpu_end\n");
    for(size_t base=0;base<count;base+=stagesPerBuffer){
      size_t n=std::min(stagesPerBuffer,count-base);
      NSData* values=[counterBuffers[base/stagesPerBuffer] resolveCounterRange:NSMakeRange(0,n*2)];
      if(!values || values.length!=n*2*sizeof(MTLCounterResultTimestamp)){
        fprintf(stderr,"STAGE_COUNTER_RESOLVE_ERROR\n");fclose(f);return;
      }
      auto data=(const MTLCounterResultTimestamp*)values.bytes;
      for(size_t j=0;j<n;++j){size_t i=base+j;fprintf(f,"%zu,%.9f,%llu,%llu,%llu,%llu\n",i,stages[i].encoded,
        (unsigned long long)stages[i].buffer,(unsigned long long)stages[i].encoder,
        (unsigned long long)data[2*j].timestamp,(unsigned long long)data[2*j+1].timestamp);}
    }
    fprintf(f,"# total=%zu cap=%zu cpu_initial=%llu gpu_initial=%llu cpu_final=%llu gpu_final=%llu\n",nextStage.load(),stageLimit,
      (unsigned long long)initialCPU,(unsigned long long)initialGPU,(unsigned long long)finalCPU,(unsigned long long)finalGPU);fclose(f);
  }
}
'''
assert s.count(anchor)==1;s=s.replace(anchor,extra+'\n'+anchor)
s=s.replace('const char* path=getenv("SLOTSTREAM_METAL_OBSERVER"); if(!path) return;','const char* path=getenv("SLOTSTREAM_METAL_OBSERVER"); if(!path) return;\n  dumpStages(path);')
anchor='    SEL simple=@selector(computeCommandEncoder);Method m=class_getInstanceMethod(cls,simple);'
assert s.count(anchor)==1
s=s.replace(anchor,'    const IMP descriptorOriginal=method_getImplementation(class_getInstanceMethod(cls,@selector(computeCommandEncoderWithDescriptor:)));\n'+anchor)
s=s.replace('recordEvent(\'E\',buffer,nil,0);return reinterpret_cast<id(*)(id,SEL)>(orig)(buffer,simple);',"recordEvent('E',buffer,nil,0);auto desc=[MTLComputePassDescriptor computePassDescriptor];desc.dispatchType=MTLDispatchTypeSerial;return stageEncoder(buffer,desc,descriptorOriginal);")
s=s.replace('recordEvent(\'E\',buffer,nil,0);return reinterpret_cast<id(*)(id,SEL,NSUInteger)>(orig)(buffer,typed,type);',"recordEvent('E',buffer,nil,0);auto desc=[MTLComputePassDescriptor computePassDescriptor];desc.dispatchType=(MTLDispatchType)type;return stageEncoder(buffer,desc,descriptorOriginal);")
s=s.replace('recordEvent(\'E\',buffer,nil,0);return reinterpret_cast<id(*)(id,SEL,id)>(orig)(buffer,described,descriptor);',"recordEvent('E',buffer,nil,0);return stageEncoder(buffer,descriptor,orig);")
s=s.replace('void device(id<MTLDevice> object) {','void device(id<MTLDevice> object) {\n  if(object && getenv("SLOTSTREAM_METAL_OBSERVER")) initializeCounters(object);')
(P/'stage_observer.mm').write_text(s)
r=subprocess.run(['xcrun','clang++','-std=c++17','-O2','-dynamiclib','-fblocks','-fno-objc-arc','-framework','Foundation','-framework','Metal',str(P/'stage_observer.mm'),'-o',str(P/'stage_observer.dylib')],capture_output=True,text=True)
(P/'stage-observer-build.json').write_text(json.dumps(dict(exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr),indent=2));print(r.stderr);raise SystemExit(r.returncode)
