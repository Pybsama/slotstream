from pathlib import Path
import json,subprocess,sys,hashlib,fcntl,os,time
P=Path(__file__).resolve().parent;R=P.parents[1];PREV=P.parent/'q2-typical-20261025/upstream'
S=Path('/var/folders/d4/t1c8ltbx5s3_11cs9y6gjh8m0000gp/T/slotstream-splash-host-ugnf26pi/source')
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
preflight(10)
lock=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
U=P/'cpu-poll-upstream';U.mkdir(exist_ok=False)
fixed=(PREV/'fixed_verify.mm').read_text().replace('#include <fstream>','#include <fstream>\n#include <sys/resource.h>')
fixed=fixed.replace('          const auto timing=model::RuntimeInstrumentation::fixedVerify(executor,item,tokens);','''          struct rusage cpuBefore{},cpuAfter{};getrusage(RUSAGE_SELF,&cpuBefore);
          const auto timing=model::RuntimeInstrumentation::fixedVerify(executor,item,tokens);
          getrusage(RUSAGE_SELF,&cpuAfter);
          const auto elapsedCPU=[](timeval a,timeval b){return double(b.tv_sec-a.tv_sec)+double(b.tv_usec-a.tv_usec)/1e6;};
          std::printf("CPU %s %u %.9f %.9f\\n",condition,round,elapsedCPU(cpuBefore.ru_utime,cpuAfter.ru_utime),elapsedCPU(cpuBefore.ru_stime,cpuAfter.ru_stime));''')
(U/'fixed_verify.mm').write_text(fixed)
original=(S/'runtime/metal/MetalBackend.mm').read_text();(U/'MetalBackend-original.mm').write_text(original)
needle='static constexpr auto kHostStepSpin = std::chrono::milliseconds(5);';assert original.count(needle)==1
ledger=[]
for arm,ms in [('A',5),('B',0)]:
 source=U/f'MetalBackend-{arm}.mm';source.write_text(original.replace(needle,f'static constexpr auto kHostStepSpin = std::chrono::milliseconds({ms});'))
 object=U/f'MetalBackend-{arm}.o'
 compile=['xcrun','-sdk','macosx','clang++','-std=c++20','-O3','-Wall','-Wextra','-Werror','-mmacosx-version-min=26.4','-fobjc-arc','-I'+str(S/'runtime'),'-DSPLASH_BACKEND_INSTRUMENTATION=1','-c',str(source),'-o',str(object)]
 old=json.loads((PREV/'build-ledger.json').read_text())[-1]['command']
 link=[str(U/'fixed_verify.mm')if x==str(PREV/'fixed_verify.mm')else str(object)if x.endswith('/MetalBackendInstrumented.o')else str(U/f'fixed-verify-{arm}')if x==str(PREV/'fixed-verify')else x for x in old]
 for name,command in [('compile-'+arm,compile),('link-'+arm,link)]:
  started=time.monotonic()
  with(U/(name+'.log')).open('x')as log:rc=subprocess.run(command,cwd=R,stdout=log,stderr=subprocess.STDOUT).returncode
  ledger.append(dict(command=command,exit_code=rc,seconds=time.monotonic()-started));(U/'build-ledger.json').write_text(json.dumps(ledger,indent=2));print(name,rc,flush=True)
  if rc:raise SystemExit(rc)
(U/'identity.json').write_text(json.dumps({str(f.relative_to(U)):hashlib.sha256(f.read_bytes()).hexdigest()for f in U.iterdir()if f.is_file()},indent=2))
(P/'cpu-poll-plan.json').write_text(json.dumps(dict(scope='Splash fixed target only,ABBA,15GB,4067slots,BF16/FP32,exactwidth4evictions. Both builds same sourceflags and fixed verifier; only host runner polling limit differs 5ms A,0ms B. GPUspinlibrary absent both. NativeFast andQ2productionunchanged.',question='Does upstream CPU busy waiting explain a meaningful part of its advantage? Capture perpass totalprocess user/systemCPU,command/event/stagetimestamps. All full output bytes must match originalSplash fixture. No parity claim against deliberately slowed upstream.',required='Wholeclean protocol,matched cache andexactoutputs. Diagnosticresultonly; no nativepoll implementation before evidence andUX tradeoff review.'),indent=2))
