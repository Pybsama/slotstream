#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <cstdio>
int main(){ @autoreleasepool { id<MTLDevice>d=MTLCreateSystemDefaultDevice();if(!d)return 1;printf("device=%s\n",d.name.UTF8String);for(NSUInteger i=0;i<5;++i)printf("sampling_%lu=%d\n",(unsigned long)i,[d supportsCounterSampling:(MTLCounterSamplingPoint)i]);for(id<MTLCounterSet>s in d.counterSets){printf("set=%s\n",s.name.UTF8String);for(id<MTLCounter>c in s.counters)printf(" counter=%s\n",c.name.UTF8String);} }return 0;}
