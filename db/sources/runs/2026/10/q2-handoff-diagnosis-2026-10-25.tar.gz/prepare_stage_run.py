from pathlib import Path
P=Path(__file__).resolve().parent
s=(P/'reserved_guarded_run.py').read_text()
s=s.replace("start=time.monotonic()", "receipt['external_build_samples']=[]\nstart=time.monotonic()")
anchor="now=time.monotonic();vm=vm_snapshot();receipt['peak_combined_bytes']=max(receipt['peak_combined_bytes'],total)"
replacement="""now=time.monotonic();vm=vm_snapshot();receipt['peak_combined_bytes']=max(receipt['peak_combined_bytes'],total)
   processes=subprocess.check_output(['ps','-axo','pid=,ppid=,%cpu=,comm='],text=True)
   busy=[]
   for line in processes.splitlines():
    fields=line.split(None,3)
    if len(fields)!=4:continue
    name=Path(fields[3]).name
    if name in ['swift-frontend','clang','clang++','ld','metal','air-lld','rustc','xcodebuild','swift-build','cargo','ninja']:
     busy.append(dict(pid=int(fields[0]),ppid=int(fields[1]),cpu=float(fields[2]),name=name))
   if busy:receipt['external_build_samples'].append(dict(seconds=now-start,processes=busy))"""
assert anchor in s;s=s.replace(anchor,replacement)
(P/'quiet_guarded_run.py').write_text(s)
s=(P/'run_read_work_reserved.py').read_text()
s=s.replace("observer=OLD/'metal_command_observer_mrc.dylib'", "observer=P/'stage_observer.dylib'")
s=s.replace("phase='read-work-reserved'", "phase='stage-profile'")
s=s.replace("inner=P/'read-work-reserved-child.lock'", "inner=P/'stage-profile-child.lock'")
s=s.replace("+':'+str(P/'read_observer.dylib')", "")
s=s.replace("['untraced','readiness','read-work','read-work-reserved']", "['untraced','readiness','read-work','read-work-reserved','stage-profile']")
s=s.replace("str(P/'reserved_guarded_run.py')", "str(P/'quiet_guarded_run.py')")
s=s.replace("row['eligible']=not guard['paging']", "row['eligible']=not guard['external_build_samples'] and not guard['paging']")
s=s.replace("while True:\n try:fcntl", "deadline=time.monotonic()+600\nwhile True:\n if time.monotonic()>deadline:raise SystemExit('Model reservation wait exceeded ten minutes')\n try:fcntl")
anchor="phase='stage-profile';assert"
check="""check=[sys.executable,str(P/'quiet_guarded_run.py'),'--label','stage-counter-check','--budget','3','--timeout','180','--env','SLOTSTREAM_MODEL_LOCK_PATH='+str(inner),'--env','DYLD_INSERT_LIBRARIES='+str(observer),'--env','SLOTSTREAM_METAL_OBSERVER='+str(P/'stage-counter-check'),'--',str(OLD/'v68/slotstream'),'q2-experts-check','--pool-model','smart-q2']
print('CHECK counter observer',flush=True)
subprocess.run(check,cwd=R,check=True)
counter_files=list(P.glob('stage-counter-check.*.stages.csv'))
assert len(counter_files)==1
import csv
samples=list(csv.DictReader(x for x in counter_files[0].read_text().splitlines() if not x.startswith('#')))
assert samples and all(int(x['gpu_start'])>0 and int(x['gpu_end'])>int(x['gpu_start']) for x in samples), 'Invalid GPU stage samples'
phase='stage-profile';assert"""
assert anchor in s;s=s.replace(anchor,check)
(P/'run_stage_profile.py').write_text(s)
