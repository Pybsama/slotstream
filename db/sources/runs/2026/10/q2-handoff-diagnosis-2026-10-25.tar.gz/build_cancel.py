from pathlib import Path
import sys,json,hashlib,difflib
P=Path(__file__).resolve().parent;R=P.parents[1];PREV=R/'.build/q2-typical-20261025'
sys.path.insert(0,str(R/'Tools'));from optimization_build import build
paths=['Sources/Slotstream/ExpertPrefetch.swift','Sources/Slotstream/ExpertStore.swift','Sources/Slotstream/Layers.swift','Sources/slotstream-cli/Q2ProfileCommand.swift']
original={p:(R/p).read_bytes() for p in paths}
prefetch=original[paths[0]].decode();layer=original[paths[2]].decode()
anchor='    package func claimSplit(_ misses: [ExpertKey]) -> ClaimResult {'
addition='''    /// Once true routing is available, Q2 input forecasts for other experts
    /// cannot serve this layer. Cancel queued pieces before demand begins;
    /// in-flight pieces retain ownership and drain through normal retirement.
    package func narrowInputForecast(layer: Int, ids: [Int32]) {
        guard stagesRawQ2, configuration.inputForecast, !closed, currentPass >= 0 else { return }
        let demanded = Set(ids.map(Int.init))
        for (key, ticket) in tickets where key.layer == layer && !demanded.contains(key.expert) {
            retire(ticket, key: key)
        }
    }

'''
assert prefetch.count(anchor)==1;prefetch=prefetch.replace(anchor,addition+anchor)
anchor2='        routerObserver?(layer, expertIds)\n        if let q2SharedWeight {'
replace2='''        routerObserver?(layer, expertIds)
        if pool.expertStore.isQ2 {
            inputForecastScheduler?.narrowInputForecast(layer: layer, ids: expertIds)
        }
        if let q2SharedWeight {'''
assert layer.count(anchor2)==1;layer=layer.replace(anchor2,replace2)
(P/'cancel-ExpertPrefetch.swift').write_text(prefetch);(P/'cancel-Layers.swift').write_text(layer)
patch=''
for path,value in [(paths[0],prefetch),(paths[2],layer)]:patch+=''.join(difflib.unified_diff(original[path].decode().splitlines(True),value.splitlines(True),fromfile='a/'+path,tofile='b/'+path))
(P/'cancel.patch').write_text(patch)
plan={'hypothesis':'Splash halts read-ahead when true demand arrives. Native queued pieces for non-routed experts survive until layer completion; demand priority pauses them only while a demand batch is active. Cancel demonstrably unused Q2 input forecasts at routing readback so they cannot occupy queues, scratch or issue irrelevant reads during preparation and demand completion. Do not alter Fast or shared worker architecture.', 'protocol':'Same clean matched width4/393-miss ABBA as handoff experiment, exact logits required. Preserve all arms. If repeatable partial-miss benefit, run correctness and normal complete requests against v68 and Splash. No source changes retained without complete-request benefit.'}
(P/'cancel-plan.json').write_text(json.dumps(plan,indent=2))
try:
 (R/paths[0]).write_text(prefetch)
 (R/paths[1]).write_bytes((PREV/'replay-ExpertStore.swift').read_bytes())
 traced=(PREV/'Layers.swift').read_text();assert traced.count(anchor2)==1
 (R/paths[2]).write_text(traced.replace(anchor2,replace2))
 (R/paths[3]).write_bytes((PREV/'replay-Q2ProfileCommand.swift').read_bytes())
 result=build(R,P/'cancel-replay-build',required_gb=10,jobs=4)
 print({k:v for k,v in result.items() if k in ['passed','error','elapsed_seconds']},flush=True)
finally:
 for p,b in original.items():(R/p).write_bytes(b)
 (P/'cancel-restored-after-build.json').write_text(json.dumps({p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in paths},indent=2))
if not result['passed']:raise SystemExit(1)
