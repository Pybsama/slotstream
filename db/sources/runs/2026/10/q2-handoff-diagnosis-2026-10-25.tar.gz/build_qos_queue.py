from pathlib import Path
import sys,json,hashlib,shutil
P=Path(__file__).resolve().parent;R=P.parents[1];PREV=R/'.build/q2-typical-20261025';OLD=R/'.build/native-replay-20261023'
sys.path.insert(0,str(R/'Tools'));from optimization_build import build
paths=['Sources/Slotstream/ExpertStore.swift','Sources/Slotstream/Layers.swift','Sources/slotstream-cli/Q2ProfileCommand.swift']
original={p:(R/p).read_bytes()for p in paths}
s=(PREV/'replay-Q2ProfileCommand.swift').read_text().replace('import Foundation','import Foundation\nimport Darwin')
start='''                let model=engine.model, state=model.makeState()'''
replacement='''                let queueClass=ProcessInfo.processInfo.environment["SLOTSTREAM_DIAGNOSTIC_QUEUE_QOS"] ?? "25"
                guard ["25","33"].contains(queueClass) else { throw ModelError("Invalid diagnostic queue QoS") }
                try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
                    DispatchQueue(label:"slotstream.diagnostic-verification",qos:queueClass == "33" ? .userInteractive : .userInitiated).async {
                    do {
                guard qos_class_self().rawValue == UInt32(queueClass)! else { throw ModelError("Diagnostic queue priority did not apply") }
                let model=engine.model, state=model.makeState()'''
assert s.count(start)==1;s=s.replace(start,replacement)
end='''                model.lookahead?.requestFinished()
            } catch { outcome = .failure(error) }'''
newend='''                model.lookahead?.requestFinished()
                        continuation.resume()
                    } catch { continuation.resume(throwing:error) }
                    }
                }
            } catch { outcome = .failure(error) }'''
assert s.count(end)==1;s=s.replace(end,newend)
s=s.replace('"plan":plan.json(),"prompt_ids":prefix,','"execution_qos":qos_class_self().rawValue,"plan":plan.json(),"prompt_ids":prefix,')
(P/'qos-queue-Q2ProfileCommand.swift').write_text(s)
(P/'qos-queue-plan.json').write_text(json.dumps(dict(scope='Diagnostic command only. Same model and callback body on one explicitly classified serial DispatchQueue. A25userInitiated,B33userInteractive; await continuation instead of mutating a shared Swift executor thread. Require runtimeqos_class_self and passivecommandobserver proof of selectedclass. No production priority policy.',reason='Recoveredv48d showed pthread self-set fails12631times on managed Swift threads. Stopped new invalid attempt before candidate. Passive currentNSaudit confirmsactualnative25,Splash33.',controls='Both arms same freshly built diagnostic binary. Existing20passes/prefix/cache/precision/logit equality and15GBphysical ceiling remain. Fast untouched.'),indent=2))
result={}
try:
 (R/paths[0]).write_bytes((PREV/'replay-ExpertStore.swift').read_bytes())
 (R/paths[1]).write_bytes((PREV/'Layers.swift').read_bytes())
 (R/paths[2]).write_text(s)
 result=build(R,P/'qos-queue-build',required_gb=10,jobs=4,wait_seconds=600)
 print({k:v for k,v in result.items()if k in ['passed','error','elapsed_seconds']},flush=True)
finally:
 for path,data in original.items():(R/path).write_bytes(data)
 for name in ['slotstream','slotstream-checks','mlx.metallib','build-identity.json','build-source.tar.gz']:
  shutil.copy2(OLD/'v68'/name,R/'.build/release'/name)
 (P/'qos-queue-restored.json').write_text(json.dumps({path:hashlib.sha256((R/path).read_bytes()).hexdigest()for path in paths},indent=2))
if not result.get('passed'):raise SystemExit(1)
