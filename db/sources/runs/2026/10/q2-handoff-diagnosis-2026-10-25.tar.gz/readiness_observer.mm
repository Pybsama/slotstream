// Diagnostic-only public Metal command-buffer timestamps. Never linked into
// production. Does not commit, wait, change encoding or manufacture GPU work.
#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#import <objc/runtime.h>
#include <mach/mach_time.h>
#include <atomic>
#include <cstdio>
#include <cstdlib>
#include <mutex>
#include <set>
#include <unistd.h>

namespace {
constexpr size_t limit = 262144;
struct Record { double submitted=0, start=0, end=0, completed=0; unsigned status=0; uintptr_t buffer=0; };
Record records[limit];
std::atomic<size_t> next{0};
std::mutex hooksMutex;
std::set<Class> devices, queues, commands, sharedEvents;
constexpr size_t eventLimit=1048576;
struct EventRecord { char kind=0; double stamp=0; uintptr_t buffer=0,event=0; uint64_t value=0; };
EventRecord eventRecords[eventLimit]; std::atomic<size_t> nextEvent{0};
double now() { static mach_timebase_info_data_t t=[] { mach_timebase_info_data_t v; mach_timebase_info(&v); return v; }();
  return double(mach_absolute_time()) * t.numer / t.denom / 1e9; }
void recordEvent(char kind, id buffer, id event, uint64_t value) {
  const size_t i=nextEvent.fetch_add(1);
  if(i<eventLimit) eventRecords[i]={kind,now(),(uintptr_t)buffer,(uintptr_t)event,value};
}
void sharedEvent(id<MTLSharedEvent> object) {
  if(!object)return;
  std::lock_guard lock(hooksMutex); Class cls=object_getClass(object);
  if(!sharedEvents.insert(cls).second)return;
  SEL sel=@selector(setSignaledValue:); Method method=class_getInstanceMethod(cls,sel);
  if(!method)return;
  const IMP original=method_getImplementation(method);
  IMP wrapped=imp_implementationWithBlock(^(id event,uint64_t value) {
    recordEvent('S',nil,event,value);
    reinterpret_cast<void(*)(id,SEL,uint64_t)>(original)(event,sel,value);
    recordEvent('R',nil,event,value);
  });
  class_replaceMethod(cls,sel,wrapped,method_getTypeEncoding(method));
}
void dump() {
  const char* path=getenv("SLOTSTREAM_METAL_OBSERVER"); if(!path) return;
  if(next.load()==0) return;
  char output[4096]; snprintf(output,sizeof(output),"%s.%d.csv",path,getpid());
  FILE* f=fopen(output,"wx"); if(!f) return;
  fprintf(f,"index,submitted,start,end,completed,status,buffer\n");
  const size_t count=next.load();
  for(size_t i=0;i<std::min(count,limit);++i) {const auto& r=records[i];
    fprintf(f,"%zu,%.9f,%.9f,%.9f,%.9f,%u,%llu\n",i,r.submitted,r.start,r.end,r.completed,r.status,(unsigned long long)r.buffer);}
  fprintf(f,"# total=%zu cap=%zu\n",count,limit); fclose(f);
  snprintf(output,sizeof(output),"%s.%d.events.csv",path,getpid());
  f=fopen(output,"wx"); if(!f)return;
  fprintf(f,"kind,stamp,buffer,event,value\n");
  const size_t events=nextEvent.load();
  for(size_t i=0;i<std::min(events,eventLimit);++i){const auto&r=eventRecords[i];
    fprintf(f,"%c,%.9f,%llu,%llu,%llu\n",r.kind,r.stamp,(unsigned long long)r.buffer,(unsigned long long)r.event,(unsigned long long)r.value);}
  fprintf(f,"# total=%zu cap=%zu\n",events,eventLimit);fclose(f);
}
void command(id<MTLCommandBuffer> object) {
  if(!object || !getenv("SLOTSTREAM_METAL_OBSERVER")) return;
  std::lock_guard lock(hooksMutex); Class cls=object_getClass(object);
  if(!commands.insert(cls).second) return;
  {
    SEL waitSel=@selector(encodeWaitForEvent:value:);Method waitMethod=class_getInstanceMethod(cls,waitSel);
    if(waitMethod){const IMP originalWait=method_getImplementation(waitMethod);
      IMP wrappedWait=imp_implementationWithBlock(^(id buffer,id<MTLSharedEvent> event,uint64_t value){
        sharedEvent(event);recordEvent('W',buffer,event,value);
        reinterpret_cast<void(*)(id,SEL,id,uint64_t)>(originalWait)(buffer,waitSel,event,value);
      });class_replaceMethod(cls,waitSel,wrappedWait,method_getTypeEncoding(waitMethod));}
    SEL simple=@selector(computeCommandEncoder);Method m=class_getInstanceMethod(cls,simple);
    if(m){const IMP orig=method_getImplementation(m);IMP wrap=imp_implementationWithBlock(^id(id buffer){
      recordEvent('E',buffer,nil,0);return reinterpret_cast<id(*)(id,SEL)>(orig)(buffer,simple);
    });class_replaceMethod(cls,simple,wrap,method_getTypeEncoding(m));}
    SEL typed=@selector(computeCommandEncoderWithDispatchType:);m=class_getInstanceMethod(cls,typed);
    if(m){const IMP orig=method_getImplementation(m);IMP wrap=imp_implementationWithBlock(^id(id buffer,NSUInteger type){
      recordEvent('E',buffer,nil,0);return reinterpret_cast<id(*)(id,SEL,NSUInteger)>(orig)(buffer,typed,type);
    });class_replaceMethod(cls,typed,wrap,method_getTypeEncoding(m));}
    SEL described=@selector(computeCommandEncoderWithDescriptor:);m=class_getInstanceMethod(cls,described);
    if(m){const IMP orig=method_getImplementation(m);IMP wrap=imp_implementationWithBlock(^id(id buffer,id descriptor){
      recordEvent('E',buffer,nil,0);return reinterpret_cast<id(*)(id,SEL,id)>(orig)(buffer,described,descriptor);
    });class_replaceMethod(cls,described,wrap,method_getTypeEncoding(m));}
  }

  SEL sel=@selector(commit); Method method=class_getInstanceMethod(cls,sel);
  const IMP original=method_getImplementation(method);
  IMP wrapped=imp_implementationWithBlock(^(id<MTLCommandBuffer> buffer) {
    const size_t i=next.fetch_add(1);
    if(i<limit) {
      records[i].submitted=now(); records[i].buffer=(uintptr_t)buffer;
      [buffer addCompletedHandler:^(id<MTLCommandBuffer> done) {
        records[i].start=done.GPUStartTime; records[i].end=done.GPUEndTime;
        records[i].completed=now(); records[i].status=unsigned(done.status);
      }];
    }
    reinterpret_cast<void(*)(id,SEL)>(original)(buffer,sel);
  });
  class_replaceMethod(cls,sel,wrapped,method_getTypeEncoding(method));
}
void queue(id<MTLCommandQueue> object) {
  if(!object || !getenv("SLOTSTREAM_METAL_OBSERVER")) return;
  std::lock_guard lock(hooksMutex); Class cls=object_getClass(object);
  if(!queues.insert(cls).second) return;
  for(SEL sel: { @selector(commandBuffer), @selector(commandBufferWithUnretainedReferences) }) {
    Method method=class_getInstanceMethod(cls,sel); if(!method) continue;
    const IMP original=method_getImplementation(method);
    IMP wrapped=imp_implementationWithBlock(^id(id q) {
      id result=reinterpret_cast<id(*)(id,SEL)>(original)(q,sel); command(result); return result;
    });
    class_replaceMethod(cls,sel,wrapped,method_getTypeEncoding(method));
  }
  SEL sel=@selector(commandBufferWithDescriptor:);
  Method method=class_getInstanceMethod(cls,sel);
  if(method) {
    const IMP original=method_getImplementation(method);
    IMP wrapped=imp_implementationWithBlock(^id(id q,id descriptor) {
      id result=reinterpret_cast<id(*)(id,SEL,id)>(original)(q,sel,descriptor); command(result); return result;
    });
    class_replaceMethod(cls,sel,wrapped,method_getTypeEncoding(method));
  }
}
void device(id<MTLDevice> object) {
  if(!object || !getenv("SLOTSTREAM_METAL_OBSERVER")) return;
  std::lock_guard lock(hooksMutex); Class cls=object_getClass(object);
  if(!devices.insert(cls).second) return;
  SEL sel=@selector(newCommandQueue); Method method=class_getInstanceMethod(cls,sel);
  const IMP original=method_getImplementation(method);
  IMP wrapped=imp_implementationWithBlock(^id(id d) {
    id result=reinterpret_cast<id(*)(id,SEL)>(original)(d,sel); queue(result); return result;
  });
  class_replaceMethod(cls,sel,wrapped,method_getTypeEncoding(method));
  SEL other=@selector(newCommandQueueWithMaxCommandBufferCount:);
  Method otherMethod=class_getInstanceMethod(cls,other);
  if(otherMethod) {
    const IMP originalOther=method_getImplementation(otherMethod);
    IMP otherWrapped=imp_implementationWithBlock(^id(id d,NSUInteger count) {
      id result=reinterpret_cast<id(*)(id,SEL,NSUInteger)>(originalOther)(d,other,count); queue(result); return result;
    });
    class_replaceMethod(cls,other,otherWrapped,method_getTypeEncoding(otherMethod));
  }
}
__attribute__((constructor)) void initialize() { atexit(dump); }
}

extern "C" id<MTLDevice> observedDevice() {
  id<MTLDevice> result=MTLCreateSystemDefaultDevice(); device(result); return result;
}
extern "C" NSArray<id<MTLDevice>>* observedDevices() {
  NSArray<id<MTLDevice>>* result=MTLCopyAllDevices(); for(id<MTLDevice> d in result) device(d); return result;
}
__attribute__((used)) static const struct { const void* replacement; const void* original; }
interposers[] __attribute__((section("__DATA,__interpose"))) = {
  {(const void*)&observedDevice,(const void*)&MTLCreateSystemDefaultDevice},
  {(const void*)&observedDevices,(const void*)&MTLCopyAllDevices}
};
