from pathlib import Path
import json,csv,statistics,collections,sys
P=Path(__file__).resolve().parent
phase=sys.argv[1] if len(sys.argv)>1 else 'stage-profile'
arms=json.loads((P/(phase+'-ledger.json')).read_text())
def csvread(p):
 lines=p.read_text().splitlines();meta=dict(x.split('=')for x in lines[-1][2:].split())
 assert int(meta['total'])<int(meta['cap'])
 return list(csv.DictReader(x for x in lines if not x.startswith('#'))),meta
def union(xs):
 merged=[]
 for a,b in sorted(xs):
  if b<=a:continue
  if merged and a<=merged[-1][1]:merged[-1][1]=max(b,merged[-1][1])
  else:merged.append([a,b])
 return sum(b-a for a,b in merged)
details=[];summaries=[]
for a in arms:
 label=a['label'];stages,meta=csvread(next(P.glob(label+'-commands*.stages.csv')))
 commands,_=csvread(next(p for p in P.glob(label+'-commands*.csv') if '.stages.'not in p.name and '.events.'not in p.name))
 # Device timestamp samples independently show identical CPU/GPU nanosecond clocks.
 assert meta['cpu_initial']==meta['gpu_initial'] and meta['cpu_final']==meta['gpu_final'],meta
 mode_counts=dict(collections.Counter((s.get('requested','unrecorded')+'->'+s.get('actual','unrecorded'))for s in stages))
 if phase=='encoder-mode':
  assert mode_counts==({'1->0':len(stages)} if a['arm']=='B' else {'1->1':len(stages)}),mode_counts
 stages=[dict(index=int(s['index']),encoded=float(s['encoded']),buffer=int(s['buffer']),start=int(s['gpu_start'])/1e9,end=int(s['gpu_end'])/1e9)for s in stages]
 commands=[{k:float(v)for k,v in c.items()}for c in commands]
 unavailable=[s for s in stages if not s['end']>s['start']>0]
 stages=[s for s in stages if s['end']>s['start']>0]
 matched=0
 for s in stages:
  cs=[c for c in commands if int(c['buffer'])==s['buffer'] and s['encoded']<=c['submitted'] and c['start']-1e-6<=s['start']<=s['end']<=c['end']+1e-6]
  assert len(cs)==1,(s,cs)
  matched+=1
 for r in a['runs']:
  if r['round']<2:continue
  lo,hi=(r['start_ns']/1e9,r['end_ns']/1e9)if a['arm']!='S'else(r['start'],r['end'])
  assert not any(lo<=s['encoded']<hi for s in unavailable), 'Missing samples in measured pass'
  ss=[s for s in stages if lo<=s['encoded']<hi];cs=[c for c in commands if lo<=c['submitted']<hi]
  row=dict(label=label,arm=a['arm'],eligible=a['eligible'],condition=r['condition'],round=r['round'],wall_ms=(hi-lo)*1000,stages=len(ss),commands=len(cs),stage_sum_ms=sum(s['end']-s['start']for s in ss)*1000,stage_union_ms=union([(s['start'],s['end'])for s in ss])*1000,command_union_ms=union([(c['start'],c['end'])for c in cs])*1000)
  if a['arm']!='S':
   assert len(ss)==147
   row.update(resident_block_ms=sum(ss[i]['end']-ss[i]['start']for i in range(0,144,3))*1000,route_ms=sum(ss[i]['end']-ss[i]['start']for i in range(1,144,3))*1000,expert_ms=sum(ss[i]['end']-ss[i]['start']for i in range(2,144,3))*1000,tail_ms=sum(s['end']-s['start']for s in ss[144:])*1000)
  details.append(row)
 rows=[r for r in details if r['label']==label]
 conditions={c:{k:statistics.median(r[k]for r in rows if r['condition']==c)for k in rows[0]if k not in ['label','arm','eligible','condition','round']}for c in sorted({r['condition']for r in rows})}
 summaries.append(dict(label=label,arm=a['arm'],eligible=a['eligible'],all_stages_match_command_intervals=matched,unavailable_outside_measured_passes=len(unavailable),mode_counts=mode_counts,conditions=conditions))
(P/(phase+'-stage-analysis.json')).write_text(json.dumps(dict(details=details,summaries=summaries),indent=2))
print(json.dumps(summaries,indent=2))
