from pathlib import Path
import sys,json,hashlib,difflib
P=Path(__file__).resolve().parent;R=P.parents[1];PREV=R/'.build/q2-typical-20261025'
sys.path.insert(0,str(R/'Tools'));from optimization_build import build
paths=['Sources/Slotstream/NativeExpertSchedule.swift','Sources/Slotstream/ExpertStore.swift','Sources/Slotstream/Layers.swift','Sources/slotstream-cli/Q2ProfileCommand.swift']
original={p:(R/p).read_bytes() for p in paths}
s=original[paths[0]].decode()
s=s.replace('let pending = try Pending(output: value, job: job, stagedSlots: stagedSlots, forecastArena: forecastArena,','let submitAfterReads = !affine && awaitingReads && prerequisite == nil\n            let pending = try Pending(output: value, job: job, stagedSlots: stagedSlots, forecastArena: forecastArena,')
s=s.replace('inverse: groupedOutput ? grouping.inverse : nil, sharedRows: mixedShared ? count : 0)','inverse: groupedOutput ? grouping.inverse : nil, sharedRows: mixedShared ? count : 0,\n                submitAfterReads: submitAfterReads)')
s=s.replace('if awaitingReads || Self.earlySubmission { asyncEval(value) }','if !submitAfterReads && (awaitingReads || Self.earlySubmission) { asyncEval(value) }')
s=s.replace('private let sharedRows: Int\n','private let sharedRows: Int\n        private let submitAfterReads: Bool\n')
s=s.replace('forecastArena: NativeForecastArena?, inverse: [Int32]?, sharedRows: Int = 0) throws {','forecastArena: NativeForecastArena?, inverse: [Int32]?, sharedRows: Int = 0,\n                         submitAfterReads: Bool = false) throws {')
s=s.replace('self.output = output; self.inverse = inverse; self.sharedRows = sharedRows; ticket = Ticket(job)','self.output = output; self.inverse = inverse; self.sharedRows = sharedRows; ticket = Ticket(job)\n            self.submitAfterReads = submitAfterReads')
s=s.replace('ss_schedule_publish(job, true); finished = true\n            afterRelease?()','ss_schedule_publish(job, true); finished = true\n            if submitAfterReads { asyncEval(output) }\n            afterRelease?()')
assert s.count('submitAfterReads')==9,s.count('submitAfterReads')
(P/'handoff.patch').write_text(''.join(difflib.unified_diff(original[paths[0]].decode().splitlines(True),s.splitlines(True),fromfile='a/'+paths[0],tofile='b/'+paths[0])))
(P/'NativeExpertSchedule.swift').write_text(s)
plan={'hypothesis':'Q2 has no useful expert work before expert-read completion when its shared expert is fused. Early async submission adds a host-ready GPU event wait and encoder split. Splash resumes after its host read step. Test submitting this Q2 graph just after publication, before starting forecasts; keep Fast and prerequisite overlap unchanged.', 'protocol':'Captured width4/393 common missing keys, 15GB, same 4067 slots and precision. A baseline replay and B delayed Q2 submission in ABBA, 2 warm and 3 timed cached/partial passes with read-ahead off/on. Per-read tracing disabled; passive GPU observer and sparse host traces retained. Require exact native logits. If promising, original-byte/state checks and uninstrumented ABCCBA baseline/candidate/Splash full requests. Preserve all runs; no favorable subsets. Speed target within5% Splash complete-request and decode rate for both tasks.'}
(P/'plan.json').write_text(json.dumps(plan,indent=2))
try:
 (R/paths[0]).write_text(s)
 (R/paths[1]).write_bytes((PREV/'replay-ExpertStore.swift').read_bytes())
 (R/paths[2]).write_bytes((PREV/'Layers.swift').read_bytes())
 (R/paths[3]).write_bytes((PREV/'replay-Q2ProfileCommand.swift').read_bytes())
 result=build(R,P/'handoff-replay-build',required_gb=10,jobs=4)
 print({k:v for k,v in result.items() if k in ['passed','error','elapsed_seconds']},flush=True)
finally:
 for p,b in original.items():(R/p).write_bytes(b)
 (P/'restored-after-build.json').write_text(json.dumps({p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in paths},indent=2))
if not result['passed']:raise SystemExit(1)
