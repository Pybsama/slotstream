from pathlib import Path
import sys,json,subprocess,os,fcntl,time
P=Path(__file__).resolve().parent;R=P.parents[1];OLD=P.parent/'native-replay-20261023'
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight,vm_snapshot,terminate_child_tree
sys.path.insert(0,str(R/'.build/native-q2-20261021'));from thermal import wait_nominal,state
observer=OLD/'metal_qos_probe_b.dylib';model=R/'.build/smart-dflash-eval/upstream-prepared/.resolved/938d6d6879dac79e95a5eae858867e0af230dc252a18266c6aefb6732b65dee7'
reservation=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a')
deadline=time.monotonic()+600
while True:
 if time.monotonic()>deadline:raise SystemExit('Model reservation wait exceeded ten minutes')
 try:fcntl.flock(reservation,fcntl.LOCK_EX|fcntl.LOCK_NB);break
 except BlockingIOError:print('WAIT existing model lock owner',flush=True);time.sleep(10)
inner=P/'qos-queue-child.lock';os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(inner)
phase='qos-queue';assert len(sys.argv)==1;ledger=P/(phase+'-ledger.json');assert not ledger.exists();records=[];slots=4067
expert_memory=3*(slots*409600+((slots*51200+16383)//16384)*16384)+471859200+98304+14336+16+32*(512+22)*4
for width in [4]:
 for index,arm in enumerate('ABCCBA'):
  label=f'{phase}-{width}-{index}-{arm}';fixture=P/f'fixture-{width}.json';drops=P/f'evictions-{width}.json';out=P/(label+'.json')
  wait_nominal(P/(label+'-cooldown.json'));preflight(18)
  env=['--env','SLOTSTREAM_MODEL_LOCK_PATH='+str(inner),'--env','DYLD_INSERT_LIBRARIES='+str(observer),'--env','SLOTSTREAM_METAL_OBSERVER='+str(P/(label+'-commands'))]
  if arm in ['B','C']:env+=['--env','SLOTSTREAM_DIAGNOSTIC_QUEUE_QOS='+('33' if arm=='C' else '25')]
  if arm in ['A','B','C']:
   cmd=[str(P.parent/'q2-typical-20261025/replay-build/candidate/slotstream') if arm=='A' else str(P/'qos-queue-build/candidate/slotstream'),'q2-profile','--fixture',str(fixture),'--output',str(out),'--memory-gb','15','--width',str(width)]
   # All read traces disabled for causal candidate comparison
   if phase!='probe':cmd+=['--evictions',str(drops)]
  else:
   cmd=[str(P/'upstream/fixed-verify'),str(P/'upstream/splash.metallib'),str(model),'--prompt-tokens',str(len(json.loads(fixture.read_text())['prompt_ids'])),'--cycles','3','--kv-format','bf16','--state-format','fp32','--expert-memory',str(expert_memory),'--ple-memory','51200000','--dispatch-list',str(P/label)]
   env+=['--env','Q2_DIAGNOSTIC_FIXTURE='+str(fixture)]
   if phase!='untraced':env+=['--env','Q2_DIAGNOSTIC_READS=1']
   if phase!='probe':env+=['--env','Q2_DIAGNOSTIC_EVICTIONS='+str(drops)]
  full=[sys.executable,str(P/'quiet_guarded_run.py'),'--label',label,'--budget','15','--timeout','600',*env,'--',*cmd]
  print('START',label,flush=True)
  with(P/(label+'-launcher.log')).open('x')as f:
   child=subprocess.Popen(full,cwd=R,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
   try:rc=child.wait(timeout=660)
   finally:
    if child.poll()is None:terminate_child_tree(child)
  guard=json.loads((P/(label+'.observer.json')).read_text());row=dict(label=label,arm=arm,width=width,command=full,exit_code=rc,guard=guard)
  if rc==0:
   if arm in ['A','B','C']:
    result=json.loads(out.read_text());assert result['plan']['pool_slots']==slots;row['runs']=result['runs']
    if arm!='A':assert result['execution_qos']==(33 if arm=='C' else 25),result['execution_qos']
   else:
    rows=[];routes={};reads={};observed=None
    for line in(P/(label+'.log')).read_text().splitlines():
     x=line.split()
     if line.startswith('CONFIG '):observed=int(dict(s.split('=',1)for s in x[1:])['slots'])
     if line.startswith('ROUTES '):routes[(x[1],int(x[2]))]=list(map(int,x[3:]))
     if line.startswith('READ '):reads.setdefault((x[1],int(x[2])),[]).append(dict(kind='read',start_ns=int(x[3]),end_ns=int(x[4]),bytes=int(x[5])))
     if not line.startswith('ROW '):continue
     keys=['start','prepared','submitted','end','gpu_seconds','host_seconds','records_read','records_prefetched','read_bytes','pickup_seconds','read_work_seconds','resume_seconds','max_logit_difference']
     r=dict(zip(keys,map(float,x[3:])));r.update(condition=x[1],round=int(x[2]));r['seconds']=r['end']-r['start'];r['routes']=routes[(x[1],int(x[2]))];rows.append(r)
    for r in rows:r['read_intervals']=reads.get((r['condition'],r['round']),[])
    assert observed==slots and len(rows)==20,(observed,len(rows))
    result=dict(slots=slots,expert_memory=expert_memory,runs=rows);out.write_text(json.dumps(result,indent=2));row['runs']=rows
   row['eligible']=not guard['external_build_samples'] and not guard['paging']and guard['thermal_before']==guard['thermal_after']==0 and guard['peak_combined_bytes']<=15e9
   for r in row['runs']:
    if r['condition'].startswith('cached')and r['round']>=2:assert r.get('records_fetched',r.get('records_read',-1))==0
  qos_files=list(P.glob(label+'-commands.*.qos.json'))
  if rc==0:
   assert len(qos_files)==1
   q=__import__('json').loads(qos_files[0].read_text());assert q['errors']==0
   row['qos']=q
   assert all(r['logits_sha256']=='c6cc487735173af3198566071fbc3a2016f3e970a1f576523f046386cea94d22' for r in row['runs'])
  records.append(row);ledger.write_text(json.dumps(records,indent=2));print('END',label,rc,'eligible',row.get('eligible'),flush=True)
  if rc:raise SystemExit(rc)
