import json,subprocess,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];B=P/'v46/slotstream';rows=[]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
preflight(12)
def run(label,cmd):
 print('START',label,flush=True)
 start=time.monotonic()
 with(P/(label+'-driver.log')).open('x')as log:r=subprocess.run(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT)
 rows.append(dict(label=label,command=cmd,exit_code=r.returncode,seconds=time.monotonic()-start));(P/'v46-core-ledger.json').write_text(json.dumps(rows,indent=2)+'\n')
 print('END',label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
run('v46-build',['make','build','SLOTSTREAM_BUILD_JOBS=4'])
run('v46-freeze',[sys.executable,str(P/'freeze.py'),'v46'])
for model in ['smart-q2','fast']:
 label='v46-pool-'+model
 run(label,[sys.executable,str(P/'guarded_run.py'),'--label',label,'--budget','3','--timeout','900','--',str(B),'q2-experts-check','--pool-model',model])
run('v46-shared-validated',[sys.executable,str(P/'guarded_run.py'),'--label','v46-shared-validated','--budget','3','--timeout','900','--env','MTL_DEBUG_LAYER=1','--env','MTL_SHADER_VALIDATION=1','--',str(B),'q2-experts-check','--pool-model','smart-q2','--shared-only'])
run('v46-formats',[sys.executable,str(P/'guarded_run.py'),'--label','v46-formats','--budget','3','--timeout','240','--env','MTL_DEBUG_LAYER=1','--',str(B),'q2-format-check','--fixtures','bench/q2/formats.json','--policy-fixtures','bench/q2/verify-budget.json','--policy-fixtures','bench/q2/verify-budget-complete.json','--mix-fixtures','bench/q2/mix-quantization.json'])
run('v46-catalogue',[sys.executable,str(P/'guarded_run.py'),'--label','v46-catalogue','--budget','4','--timeout','300','--',str(P/'v46/slotstream-checks'),'--tier','t0','--tier','t1'])
run('v46-plain',[sys.executable,str(P/'v46_plain.py')])
run('v46-quality',[sys.executable,str(P/'v46_native_quality.py')])
