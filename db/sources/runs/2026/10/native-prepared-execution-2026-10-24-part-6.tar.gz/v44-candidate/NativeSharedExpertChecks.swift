import ArgumentParser
import Foundation
import MLX
import Slotstream

/// Use actual pinned checkpoint bytes and their three different GGUF formats.
/// The existing individual projections have independent format arithmetic
/// checks; this catches schedule, split, activation and precision changes.
func checkNativeSharedExperts(index: CheckpointIndex) throws {
    guard NativeProjectionSchedule.enabled, Q2PackedExperts.enabled,
          NativeProjectionPolicy.device.apple10, let checkpoint = index.q2 else { return }
    func projection(_ layer: Int, _ name: String) throws -> Q2GGUFLinear {
        guard let tensor = checkpoint.mapped["model.layers.\(layer).mlp.shared_expert.\(name)_proj.weight"] else {
            throw ValidationError("Shared expert fixture is missing")
        }
        let data = try tensor.read()
        var value = Q2GGUFLinear(bytes: MLXArray(data, [data.count], dtype: .uint8),
            format: tensor.format, rows: tensor.rows, columns: tensor.columns, prepare: true)
        value.inputType = .bfloat16; value.outputType = .bfloat16
        return value
    }
    let before = NativeProjectionSchedule.sharedCallCount
    var formats = Set<[UInt32]>()
    for layer in 0..<48 {
        let kinds = try ["gate", "up", "down"].map { name -> UInt32 in
            guard let tensor = checkpoint.mapped["model.layers.\(layer).mlp.shared_expert.\(name)_proj.weight"] else {
                throw ValidationError("Shared format coverage is incomplete")
            }
            return tensor.format.rawValue
        }
        guard formats.insert(kinds).inserted else { continue }
        try autoreleasepool {
            let gate = try projection(layer, "gate")
            let up = try projection(layer, "up")
            let down = try projection(layer, "down")
            for count in [1, 2, 3, 8] {
                let values: [Float] = (0..<(count * 2560)).map { i in
                    sin(Float(i) * Float(0.037)) * Float(i % 5 + 1)
                }
                let input = MLXArray(values, [1, count, 2560]).asType(.bfloat16)
                guard let pair = Q2GGUFLinear.pair(input, gate, up),
                      let actual = NativeProjectionSchedule.shared(input, gate: gate, up: up, down: down) else {
                    throw ValidationError("Maintained shared expert bypassed its prepared graph")
                }
                let expected = down(Q2HyperConnection.targetSwiGLU([pair.0, pair.1])[0])
                guard actual.shape == expected.shape, (actual .== expected).all().item(Bool.self) else {
                    throw ValidationError("Prepared shared expert changed BF16 output at layer \(layer), \(count) rows")
                }
            }
        }
    }
    guard formats.count == 36, NativeProjectionSchedule.sharedCallCount == before + formats.count * 4 else {
        throw ValidationError("Shared expert checks used a fallback")
    }
    print("Prepared Q2 shared expert: all 36 actual format combinations exact at 1/2/3/8 rows PASS")
}
