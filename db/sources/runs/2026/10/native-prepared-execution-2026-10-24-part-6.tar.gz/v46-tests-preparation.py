from pathlib import Path
P=Path(__file__).resolve().parent
p=P/'prepare_v46_mixed.py';s=p.read_text();s=s[:s.index("(P/'v46-candidate-manifest.json')")]+'''
# Both original and combined schedules must survive the same real cache lifecycle.
s=base('Sources/slotstream-cli/NativeSchedulePoolChecks.swift').decode()
s=rep(s,'func checkNativeSchedulePool(model: String) throws {','func checkNativeSchedulePool(model: String, mixed: Bool = false) throws {')
s=rep(s,'if model == "smart-q2" {','if model == "smart-q2" && !mixed {')
s=rep(s,'    let cfg = index.config','''+repr('''    var shared: NativeExpertSchedule.SharedBindings?
    var sharedLinears: [Q2GGUFLinear] = []
    if mixed, let checkpoint=index.q2 {
        sharedLinears = try ["gate","up","down"].map { name in
            let tensor=checkpoint.mapped["model.layers.0.mlp.shared_expert.\\(name)_proj.weight"]!
            let data=try tensor.read()
            var value=Q2GGUFLinear(bytes: MLXArray(data,[data.count],dtype:.uint8), format:tensor.format,
                rows:tensor.rows, columns:tensor.columns, prepare:true)
            value.inputType = .bfloat16; value.outputType = .bfloat16
            return value
        }
        shared=NativeExpertSchedule.SharedBindings(gate:sharedLinears[0],up:sharedLinears[1],down:sharedLinears[2])
        guard shared != nil else { throw ValidationError("Mixed schedule fixture unavailable") }
    }
    let cfg = index.config''')+''')
s=rep(s,'affine: store.nativeAffineTiles)\\n    let input','affine: store.nativeAffineTiles, mixedShared: mixed)\\n    let input')
s=rep(s,'repeatInput: keys.count, awaitingReads: awaitingReads,','repeatInput: keys.count, awaitingReads: awaitingReads, groupedOutput: mixed,')
s=rep(s,'forecastArena: pool.lookahead?.prefetch?.nativeForecastArena)','forecastArena: pool.lookahead?.prefetch?.nativeForecastArena, shared: shared)')
s=rep(s,'        return (value, slots.map(Int32.init))','''+repr('''        if mixed {
            guard let actualShared=pending.sharedValue,
                  let expectedShared=NativeProjectionSchedule.sharedStaged(input,
                    gate:sharedLinears[0],up:sharedLinears[1],down:sharedLinears[2]),
                  let inverse=pending.inverse,
                  (actualShared.reshaped(expectedShared.shape) .== expectedShared).all().item(Bool.self) else {
                throw ValidationError("Mixed shared output differs after cache transition")
            }
            return (take(value,MLXArray(inverse),axis:0),slots.map(Int32.init))
        }
        return (value, slots.map(Int32.init))''')+''')
s=rep(s,'ids: [0], repeatInput: 1, awaitingReads: true, stagedSlots: [0, 0])','ids: [0], repeatInput: 1, awaitingReads: true, groupedOutput: mixed, stagedSlots: [0, 0], shared: shared)')
s=s.rsplit('\\n}',1)[0]+''' +repr('''
    if model == "smart-q2" && !mixed { try checkNativeSchedulePool(model:model,mixed:true) }
    if mixed { print("Mixed shared/routed grids: actual cache hit/miss/cancel/resize/forecast lifecycle PASS") }
}
''')+'''
put('Sources/slotstream-cli/NativeSchedulePoolChecks.swift',s)
# Exercise all 36 real format triples and changing inputs on one immutable
# mixed plan, against the independently checked separate arithmetic.
s=base('Sources/slotstream-cli/NativeSharedExpertChecks.swift').decode()
anchor='    var checked = 0\\n'
s=rep(s,anchor,anchor+'''+repr('''    let store=try ExpertStore(index:index)
    store.usePackedLayout=false
    let routed=try store.readBatchChecked([ExpertKey(0,0),ExpertKey(0,1)])
    let mixedPlan=try NativeExpertSchedule.plan(hidden:2560,intermediate:640,affine:false,mixedShared:true)
    let routedBindings=try mixedPlan.bind(routed)
''')+''')
anchor='                checked += 1'
s=rep(s,anchor,'''+repr('''                guard let mixed=NativeExpertSchedule.SharedBindings(gate:linears[0],up:linears[1],down:linears[2]) else {
                    throw ValidationError("Missing shared tile fixture")
                }
                let ids=(0..<(count*2)).map { Int32($0%2) }
                for (input,reference) in [(x,down.asType(.bfloat16)),(-x,cd)] {
                    let pending=try mixedPlan.submit(input,bindings:routedBindings,ids:ids,repeatInput:2,
                        awaitingReads:false,groupedOutput:true,shared:mixed)
                    let all=try pending.value()
                    let expectedRouted=NativeExpertTiles.apply(input,weights:routed,ids:ids,repeatInput:2,
                        hidden:2560,intermediate:640,affine:false)
                    guard let shared=pending.sharedValue,let inverse=pending.inverse,
                        (shared.reshaped(reference.shape) .== reference).all().item(Bool.self),
                        (take(all,MLXArray(inverse),axis:0) .== expectedRouted).all().item(Bool.self) else {
                        throw ValidationError("Mixed shared/routed grid differs at layer \\(layer), rows \\(count)")
                    }
                }
                checked += 1''')+''')
put('Sources/slotstream-cli/NativeSharedExpertChecks.swift',s)
# Per-request telemetry proves production is actually using the mixed grid.
path='Sources/Slotstream/NativeExpertSchedule.swift';s=(D/Path(path).name).read_text()
s=rep(s,'private static var groupedSubmissions = 0','private static var groupedSubmissions = 0\\n    private static var mixedSubmissions = 0\\n    package static var mixedSubmissionCount: Int { lock.withLock { mixedSubmissions } }')
s=rep(s,'if groupedOutput { Self.lock.withLock { Self.groupedSubmissions += 1 } }','if groupedOutput { Self.lock.withLock { Self.groupedSubmissions += 1; if mixedShared { Self.mixedSubmissions += 1 } } }')
manifest=[r for r in manifest if r['path']!=path];put(path,s)
s=base('Sources/slotstream-cli/SmartDFlashCommand.swift').decode()
anchor='"native_projection_schedule_plans": NativeProjectionSchedule.planCount,'
s=rep(s,anchor,anchor+'\\n                        "native_mixed_expert_submissions": NativeExpertSchedule.mixedSubmissionCount,')
put('Sources/slotstream-cli/SmartDFlashCommand.swift',s)
(P/'v46-candidate-manifest.json').write_text(json.dumps(manifest,indent=2)+'\\n')
(P/'v46-design.json').write_text(json.dumps(dict(status='Prepared, not installed or qualified',base='v45',mechanism='Shared expert is the final live tile of the existing routed gate/up and down grids. Per-invocation resident bindings and metadata, one additional immutable Q2 plan, same host-publication and cancellation gate.',tests='All 36 original-byte shared format triples, exact separate versus mixed routed/shared outputs with changed inputs, repeated full real cache lifecycle on mixed plan; original goldens and both complete quality suites. Whole matched serving timing required.'),indent=2)+'\\n')
print('Prepared',len(manifest),'files; production unchanged')
'''
p.write_text(s)
