import json,subprocess,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];B=P/'v45d/slotstream';rows=[]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
preflight(12)
def run(label,cmd):
 print('START',label,flush=True)
 start=time.monotonic()
 with(P/(label+'-driver.log')).open('x')as log:r=subprocess.run(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT)
 rows.append(dict(label=label,command=cmd,exit_code=r.returncode,seconds=time.monotonic()-start));(P/'v45d-core-ledger.json').write_text(json.dumps(rows,indent=2)+'\n')
 print('END',label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
run('v45d-build',['make','build','SLOTSTREAM_BUILD_JOBS=4'])
run('v45d-freeze',[sys.executable,str(P/'freeze.py'),'v45d'])
for model in ['smart-q2','fast']:
 label='v45d-pool-'+model
 run(label,[sys.executable,str(P/'guarded_run.py'),'--label',label,'--budget','3','--timeout','600','--',str(B),'q2-experts-check','--pool-model',model])
run('v45d-shared-validated',[sys.executable,str(P/'guarded_run.py'),'--label','v45d-shared-validated','--budget','3','--timeout','900','--env','MTL_DEBUG_LAYER=1','--env','MTL_SHADER_VALIDATION=1','--',str(B),'q2-experts-check','--pool-model','smart-q2','--shared-only'])
run('v45d-formats',[sys.executable,str(P/'guarded_run.py'),'--label','v45d-formats','--budget','3','--timeout','240','--env','MTL_DEBUG_LAYER=1','--',str(B),'q2-format-check','--fixtures','bench/q2/formats.json','--policy-fixtures','bench/q2/verify-budget.json','--policy-fixtures','bench/q2/verify-budget-complete.json','--mix-fixtures','bench/q2/mix-quantization.json'])
run('v45d-catalogue',[sys.executable,str(P/'guarded_run.py'),'--label','v45d-catalogue','--budget','4','--timeout','300','--',str(P/'v45d/slotstream-checks'),'--tier','t0','--tier','t1'])
run('v45d-plain',[sys.executable,str(P/'v45d_plain.py')])
run('v45d-quality',[sys.executable,str(P/'v45d_native_quality.py')])
