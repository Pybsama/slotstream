from pathlib import Path
import json,statistics
P=Path(__file__).resolve().parent
d=json.loads((P/'demand-shape-15-0-N.json').read_text())
events=[dict(width=r['width'],demand=len(e['misses'])-len(e['adopted']),seconds=(e['end_ns']-e['start_ns'])/1e9)for r in d['runs']if r['round']==1 for e in r['demand_events']]
result=dict(scope='Upper bound only. Host demand event spans include adoption and synchronization, overlap GPU work, and do not establish queue imbalance. Q2 has three pieces per expert and32 demand lanes. Static per-lane striding differs from Splash atomic next-job claims; the earlier dedicated-worker test retained the static lane body.',thresholds=[])
for n in [1,11,22,33]:
 selected=[e for e in events if e['demand']>=n]
 result['thresholds'].append(dict(minimum_demand_records=n,layer_events=len(selected),host_span_seconds=sum(e['seconds']for e in selected),median_records=statistics.median(e['demand']for e in selected)))
result['next_gate']='Quantify actual idle-lane tail after short jobs finish in multi-job batches before implementing shared/dynamic demand work. No reader architecture rewrite from this upper bound.'
(P/'demand-lane-shape.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
