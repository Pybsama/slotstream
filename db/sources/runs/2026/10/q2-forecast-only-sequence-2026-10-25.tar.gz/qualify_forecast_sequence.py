from pathlib import Path
import json,subprocess,sys
P=Path(__file__).resolve().parent;R=P.parents[1]
manifest=json.loads((P/'native-forecast-sequence-build/manifest.json').read_text());assert manifest['passed']
cmd=[sys.executable,str(P/'quiet_guarded_run.py'),'--label','forecast-sequence-check','--budget','15','--timeout','600','--env','MTL_DEBUG_LAYER=1','--',str(P/'native-forecast-sequence-build/candidate/slotstream'),'q2-experts-check','--pool-model','smart-q2']
r=subprocess.run(cmd,cwd=R);assert r.returncode==0
p=P/'forecast-sequence-check.log';log=p.read_text();assert 'FAIL'not in log and 'error:'not in log.lower()
cmd=[sys.executable,str(P/'run_forecast_sequence.py'),'--label','forecast-sequence','--order','ABSSBA','--rounds','2']
raise SystemExit(subprocess.run(cmd,cwd=R).returncode)
