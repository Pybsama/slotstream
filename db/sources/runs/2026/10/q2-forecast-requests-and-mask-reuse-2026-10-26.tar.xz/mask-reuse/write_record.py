from pathlib import Path
import json,subprocess
P=Path(__file__).resolve().parent;R=P.parents[1];DB=R/'db';tool='/Users/carlos/.dbmd/bin/dbmd'
def write(path,kind,title,fields,body):
 f=P/(Path(path).name+'.body.md');f.write_text(body.strip()+'\n')
 cmd=[tool,'write',path,'--dir',str(DB),'--json','--type',kind,'--summary',title,'--fm','title='+title,'--body-file',str(f)]
 for k,v in fields.items():cmd+=['--fm',k+'='+str(v)]
 print(subprocess.run(cmd,check=True,capture_output=True,text=True).stdout.strip())
 if not(DB/path).exists():
  found=list(DB.rglob(Path(path).name));assert len(found)==1
  print(subprocess.run([tool,'rename',str(found[0].relative_to(DB)),path,'--dir',str(DB),'--json'],check=True,capture_output=True,text=True).stdout.strip())
a=json.loads((P/'archive-receipt.json').read_text());m=json.loads((P/'request-analysis.json').read_text());t=json.loads((P.parent/'q2-started-request-20261026/analysis.json').read_text())
assert not m['retention_passed'], 'A retained candidate needs its own implementation and final qualification, not this rejected-experiment note'
reader='sources/runs/2026/10/2026-10-26-q2-started-forecast-requests.md';mask='sources/runs/2026/10/2026-10-26-q2-mask-reuse.md'
archive=f"[Raw archive]({Path(a['path']).name}): {a['files']} members, {a['bytes']} bytes, SHA-256 `{a['sha256']}`. Every member is read back and hash-checked; credential-pattern matches are zero. Executables and weights are excluded."
common=dict(tool='Isolated native build, exact arithmetic checks and guarded ABCCBA complete requests',command='Archived prepare/build/check/run/analyze scripts',binary='v68 timestamp-only baseline, isolated candidates and published Splash 1.4.0; build identities and sources archived',captured_at='2026-10-26',machines='[[records/machines/macbook-pro-m5-pro-48gb]]')
write(reader,'run','Started forecast complete-request evidence',dict(**common,discarded='true'),f"""
{archive}

The `started-forecast-requests/` directory contains the separate normal-request
qualification of the already exact-checked started-forecast candidate. The
frozen plan explicitly preserves the prior failed component gate and declares
this independent complete-request experiment before execution. It is not a
retry or a claim that the prior ABBA qualified.

The whole six-arm protocol is excluded for 12 global swap-in pages in the first
candidate and four in the first Splash arm, with zero swap-outs. All streams,
physical ceilings, cache identities and sampled thermal/build guards pass.
Functional evidence remains valid. No timing retry or candidate retention follows.
Raw times, tokens, read/join counters, source identities and guards remain.
""")
eligible=m['environment_eligible']
timing='All six arms pass the declared environment guards. The candidate fails the repeatable complete-request improvement gate.' if eligible else 'The whole six-arm timing protocol is excluded for its recorded environment failures. No clean-arm selection or timing retry follows.'
write(mask,'run','Immutable Q2 draft-mask reuse evidence',dict(**common,discarded=str(not eligible).lower()),f"""
{archive}

The `mask-reuse/` directory preserves the isolated candidate, explicit 16 KiB
reserve, build, exact embedding tests, 111-pass full-logit/proposal/token
validation, one normal-request ABCCBA and all observers. The original-row
embedding checks run under Metal API validation; their component timings are
not normal-request performance evidence. {timing}

Every candidate request reports 5,120 cached payload bytes and the same 4,067
expert slots as baseline and Splash. Candidate code is not retained. All 509
production inputs and five default artifacts remain v68. Fast is unchanged.
""")
table='| Arm | Code s | Prose s | Environment eligible |\n| --- | ---: | ---: | --- |\n'
for row in m['arms']:
 vals={r['id']:r['request_seconds']for r in row['runs']}
 table+=f"| {row['label']} | {vals['timed-2']:.3f} | {vals['timed-3']:.3f} | {row['eligible']} |\n"
baseline_gaps={n:(r['baseline_over_splash_pooled']-1)*100 for n,r in m['ratios'].items()}
peaks={arm:max(e['peak_combined_bytes'] for e in m['arms'] if e['arm']==arm)/1e9 for arm in 'ABC'}
ratios='\n'.join(f"- {name}: candidate/baseline forward and reverse {r['candidate_over_baseline_directions'][0]:.6f}/{r['candidate_over_baseline_directions'][1]:.6f}; pooled {r['candidate_over_baseline_pooled']:.6f}. Candidate/Splash {r['candidate_over_splash_directions'][0]:.6f}/{r['candidate_over_splash_directions'][1]:.6f}." for name,r in m['ratios'].items())
body=f"""
Neither follow-up earns a production change. The started-forecast request
comparison is excluded for paging; the immutable-mask candidate does not pass
the complete-request retention gate. Keep v68 and Fast unchanged. Consistent
Q2 request performance within five percent of Splash remains unproven.

This follows [[records/measurements/q2-started-forecast-reuse]] and
[[records/measurements/q2-small-work-and-readiness]]. Raw evidence is
[[{reader[:-3]}]] and [[{mask[:-3]}]].

## Started forecasts in complete requests

The prior candidate demonstrably eliminates the observed duplicate reads and
preserves all frozen logits. A separate, predeclared normal-request ABCCBA tests
whether that mechanism helps the actual workload. It does not rewrite the
earlier failed component gate. The whole protocol is excluded for 12/4 global
swap-in pages in its first candidate/Splash arms. No arm selection or retry is
used, and no speed or slowdown is qualified from those times.

All requests complete 384 tokens, use 4,067 slots and pass physical memory
checks. Candidate forecast joins total 55–81 ms per timed request versus
5–8 ms for baseline. These waits do not establish the main remaining gap.
Baseline itself first differs between repetitions at token 152 for code and
284 for prose. Published Splash explicitly documents output variation with
adaptive verification widths, including greedy decoding. Preserve those
variations and the separate exact-width arithmetic controls; do not infer a
new corruption bug from candidate text variation alone.

## Reusing a fixed draft mask

Native Q2 reads and decodes the anchor plus seven identical mask rows on every
draft proposal. The earlier per-lookup read deduplication still decoded all
eight rows and was rejected. This different candidate retains one decoded
BF16 mask row inside its immutable checkpoint, reads/decodes only the anchor,
and broadcasts/concatenates the mask into the original eight-row block. Fast
and non-Q2 lookups keep the original expression. There is no reader, controller,
expert-cache or arithmetic change.

The persistent payload is 5,120 bytes, with an additional 16 KiB planner reserve.
Clearing embedding storage releases the cached owner; a different checkpoint
has independent state. The diagnostic tests 18 exact original-row cases,
changing masks and anchors, clear/reload and four invalid IDs. All pass.
All 111 full-logit hashes, real proposals and selected tokens match the frozen
native reference. Validation retains 4,067 slots and passes its 15 GB ceiling.

The synchronous 512-lookup component control takes 0.312/0.309 s baseline and
0.111/0.105 s candidate under Metal API validation. That proves a local effect
in that diagnostic, not a complete-request improvement. Extra tensor assembly
and changed execution timing still have to earn their complexity in production.

## Complete-request result

One ABCCBA uses ordinary production adaptation, identical prompt IDs, two
warmups, 384-token code/prose requests, BF16 activations/KV, FP32 recurrent
state, 8,192 context and a 15 GB physical ceiling. A is the timestamp-only v68
baseline; B is only the mask candidate; C is published Splash 1.4.0 with its
normal CPU polling and no GPU spin. Actual cache capacity is 4,067 everywhere.
The predeclared retention gate requires improvement in both directions and
at least one percent pooled improvement for each fixture. Parity separately
requires candidate/Splash no greater than 1.05 in both directions.

{timing}

{table}
{ratios}

These are {'clean observed' if eligible else 'excluded raw'} request times.
The baseline/Splash pooled gaps are {baseline_gaps['timed-2']:.2f}% for code and
{baseline_gaps['timed-3']:.2f}% for prose in this protocol. Maximum combined
footprints are {peaks['A']:.3f} GB baseline, {peaks['B']:.3f} GB candidate and
{peaks['C']:.3f} GB Splash, all below the configured ceiling.
The candidate is not retained and there is no favorable retry. Throughput
completion is not task-quality success: these 384-token fixtures are capped
before necessarily finishing the requested code or prose. The known Fast
recall and Q2 strict-format failures remain separate. No release, Smart
promotion or app-readiness claim follows.

## Next diagnosis

Avoid another embedding-cache or shared-reader rewrite from local savings.
The next bounded lead is command construction and completion bookkeeping in
the MLX execution adapter: its GPU primitive path registers buffer-lifetime
handlers per operation. This differs from the already tested empty-signal
command count and submission-threshold changes in
[[records/measurements/q2-ordinary-request-and-submission-diagnosis]].
It is source evidence of a mechanism, not evidence
that it causes the gap. Measure its contribution on the existing real-cycle
work, aligned with read and GPU intervals, before proposing a change. Preserve
buffer ownership, error cleanup and Fast's path. Do not replay these rejected
timing protocols or promise parity from native language choice.
"""
write('records/measurements/q2-forecast-requests-and-mask-reuse.md','measurement','Q2 forecast requests and immutable draft-mask reuse',dict(date='2026-10-26',doc='measurements',level='2',machines='[[records/machines/macbook-pro-m5-pro-48gb]]',order='1911',runs='[['+reader[:-3]+']], [['+mask[:-3]+']]',status='measured'),body)
