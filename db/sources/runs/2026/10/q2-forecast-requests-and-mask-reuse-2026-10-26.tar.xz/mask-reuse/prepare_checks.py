from pathlib import Path
import shutil
P=Path(__file__).resolve().parent;R=P.parents[1];Q=P.parent/'q2-started-forecast-20261026';T=P.parent/'q2-started-request-20261026'
s=(Q/'check_pool.py').read_text().replace('candidate-pool','candidate-mask').replace("preflight(13)","preflight(6)").replace("'--budget','10'","'--budget','6'").replace("'--pool-model','smart-q2'","'--mask-only'")
(P/'check_mask.py').write_text(s)
for n in ['q2_upstream_bench_io.py','cases.json']:shutil.copy2(T/n,P/n)
s=(T/'run.py').read_text().replace('Independent complete-request qualification: A v68, B retain actually started Q2 forecasts, C published Splash. Earlier fixed-cycle ABBA remains wholly excluded for paging and does not satisfy its advance gate; this protocol is motivated by separate clean evidence of eliminated duplicate reads and exact correctness, not by selecting its favorable timings.','One complete-request qualification: A v68, B Q2 immutable draft-mask reuse with16KiB reserve, C published Splash. No reader/controller/expert schedule change.')
(P/'request_run.py').write_text(s)
