from pathlib import Path
import hashlib,io,json,re,tarfile,subprocess
P=Path(__file__).resolve().parent;R=P.parents[1];T=P.parent/'q2-started-request-20261026';files={};sha=lambda b:hashlib.sha256(b).hexdigest()
assert (P/'request-analysis.json').exists()
for prefix,root in [('started-forecast-requests',T),('mask-reuse',P)]:
 for f in root.rglob('*'):
  if not f.is_file()or'__pycache__'in f.parts or f.name in ['archive-receipt.json']:continue
  if f.suffix not in ['.py','.swift','.json','.jsonl','.csv','.log','.stderr','.txt']:continue
  files[prefix+'/'+str(f.relative_to(root))]=f
for n in ['DFlashDraft.swift','PackMemoryProfile.swift','Q2Checkpoint.swift','Weights.swift']:
 files['baseline/'+n]=R/'Sources/Slotstream'/n
files['baseline/LICENSE']=R/'LICENSE'
mlx=R/'.build/checkouts/mlx-swift/Source/Cmlx/mlx'
for n in ['mlx/transforms.cpp','mlx/backend/metal/eval.cpp','mlx/backend/metal/device.cpp','LICENSE']:
 files['reference/actual-mlx/'+n]=mlx/n
for name,path in [('v68',R/'.build/native-replay-20261023/v68'),('request-baseline',R/'.build/q2-request-profile-20261025/native-build/candidate'),('started-forecast',R/'.build/q2-started-forecast-20261026/native-build/candidate')]:files['reference/'+name+'-build-identity.json']=path/'build-identity.json'
W=Path('/var/folders/d4/t1c8ltbx5s3_11cs9y6gjh8m0000gp/T/slotstream-splash-host-ugnf26pi/source')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()=='1482f6bbc2abf12375332725302019594150b6cb'
for n in ['runtime/model/QwenTarget.cpp','runtime/ops/Embedding.cpp','LICENSE']:
 f=P/('reference-'+Path(n).name);f.write_bytes(subprocess.check_output(['git','show','HEAD:'+n],cwd=W));files['reference/splash/'+n]=f
secret=re.compile(rb'(?:ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{25,}|sk-(?:proj-)?[A-Za-z0-9_-]{30,}|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----)');manifest={}
for n,f in files.items():
 b=f.read_bytes();assert not secret.search(b),n;manifest[n]=dict(bytes=len(b),sha256=sha(b))
dest=R/'db/sources/runs/2026/10/q2-forecast-requests-and-mask-reuse-2026-10-26.tar.xz';assert not dest.exists();raw=json.dumps(manifest,indent=2).encode()
with tarfile.open(dest,'w:xz',preset=3)as t:
 for n,f in sorted(files.items()):t.add(f,arcname=n,recursive=False)
 info=tarfile.TarInfo('archive-manifest.json');info.size=len(raw);t.addfile(info,io.BytesIO(raw))
seen={}
with tarfile.open(dest,'r|xz')as t:
 for m in t:
  b=t.extractfile(m).read()
  if m.name=='archive-manifest.json':assert json.loads(b)==manifest
  else:seen[m.name]=dict(bytes=len(b),sha256=sha(b))
assert seen==manifest
receipt=dict(path=str(dest.relative_to(R)),files=len(manifest),bytes=dest.stat().st_size,sha256=sha(dest.read_bytes()),readback_verified=True,credential_pattern_matches=0,excluded='Executables, libraries, model weights, pycache, duplicate full-source archives. Prior exact-cycle references retained in the linked full-cycle archive.')
(P/'archive-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt,indent=2))
