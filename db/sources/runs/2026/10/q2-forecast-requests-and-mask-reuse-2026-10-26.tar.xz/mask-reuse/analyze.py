from pathlib import Path
import json,statistics,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1]
guard=json.loads((P/'candidate-mask.observer.json').read_text())
samples=[dict(arm=x.split()[1],seconds=float(x.split()[2])) for x in (P/'candidate-mask.log').read_text().splitlines() if x.startswith('MASK_COMPONENT')]
a=[x['seconds']for x in samples if x['arm']=='A'];b=[x['seconds']for x in samples if x['arm']=='B']
component=dict(exact_cases=18,invalid_cases=4,physical_peak_gb=guard['peak_combined_bytes']/1e9,paging=guard['paging'],samples=samples,candidate_over_baseline=[b[0]/a[0],b[1]/a[1]],scope='512 synchronous embedding-only lookups per arm under Metal API validation. Includes reads, graph setup, submit and completion. Not request speed, no wall-time extrapolation.')
(P/'mask-check-analysis.json').write_text(json.dumps(component,indent=2))
events=json.loads((P/'mask-15-ledger.json').read_text());assert [e['arm']for e in events]==list('ABCCBA')
rows=[];native={}
for event in events:
 d=json.loads((P/(event['label']+'.json')).read_text())
 row=dict(label=event['label'],arm=event['arm'],eligible=event['eligible'],swapins=event['after']['vm']['swapins']-event['before']['vm']['swapins'],swapouts=event['after']['vm']['swapouts']-event['before']['vm']['swapouts'],runs=[])
 memory=d if event['arm']=='C'else json.loads((P/(event['label']+'-guard.observer.json')).read_text())
 row['peak_combined_bytes']=memory['peak_combined_bytes']
 for run in d['runs']:
  if event['arm']=='B':assert run['stats']['embeddingCachedPayloadBytes']==5120
  if not run['id'].startswith('timed'):continue
  r=dict(id=run['id'],request_seconds=run['elapsed_seconds'])
  if event['arm']!='C':
   s=run['stats'];r.update(cycles=s['expertPrefetch']['passes'],embedding_payload_bytes=s['embeddingCachedPayloadBytes'],decode_seconds=s['decodeSeconds'])
   native[(event['label'],run['id'])]=run['tokens']
  row['runs'].append(r)
 rows.append(row)
ratios={}
for ident in ['timed-2','timed-3']:
 t=[next(r['request_seconds']for r in e['runs']if r['id']==ident)for e in rows]
 ab=[t[1]/t[0],t[4]/t[5]];bc=[t[1]/t[2],t[4]/t[3]]
 pooled=statistics.mean([t[1],t[4]])/statistics.mean([t[0],t[5]])
 ratios[ident]=dict(times=t,candidate_over_baseline_directions=ab,candidate_over_baseline_pooled=pooled,candidate_over_splash_directions=bc,baseline_over_splash_pooled=statistics.mean([t[0],t[5]])/statistics.mean([t[2],t[3]]),candidate_gate=all(v<1 for v in ab)and pooled<=.99,parity_gate=all(v<=1.05 for v in bc))
variation=[]
for ident in ['timed-2','timed-3']:
 base=native[(events[0]['label'],ident)]
 for i in [1,4,5]:
  other=native[(events[i]['label'],ident)]
  variation.append(dict(fixture=ident,reference=events[0]['label'],other=events[i]['label'],first_difference=next((j for j,(a,b)in enumerate(zip(base,other))if a!=b),None)))
eligible=all(e['eligible']for e in events)
out=dict(environment_eligible=eligible,retention_passed=eligible and all(r['candidate_gate']for r in ratios.values()),parity_passed=eligible and all(r['parity_gate']for r in ratios.values()),arms=rows,ratios=ratios,token_variation=variation,correctness=json.loads((P/'candidate-validation-result.json').read_text()),component=component,scope='Ordinary full requests with adaptive widths. All arms count; any paging excludes aggregate. Capped throughput outputs do not qualify task quality. Exact111-pass arithmetic remains a separate check.')
(P/'request-analysis.json').write_text(json.dumps(out,indent=2))
print(json.dumps({k:out[k]for k in ['environment_eligible','retention_passed','parity_passed','ratios']},indent=2))
