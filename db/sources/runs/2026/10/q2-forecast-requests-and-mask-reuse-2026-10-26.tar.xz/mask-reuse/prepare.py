from pathlib import Path
import json, shutil, hashlib
P=Path(__file__).resolve().parent; R=P.parents[1]; F=P.parent/'q2-full-cycle-20261025'; Q=P.parent/'q2-started-forecast-20261026'
replacements={}
def save(name,s):
 out=Path(name).name; (P/out).write_text(s); replacements[name]=out
s=(R/'Sources/Slotstream/Q2Checkpoint.swift').read_text()
s=s.replace('    let config: ModelConfig\n','''    let config: ModelConfig
    // One immutable decoded draft mask, owned by this exact checkpoint.
    private var draftMask: (id: Int, row: MLXArray)?
    package var draftMaskPayloadBytes: Int { draftMask == nil ? 0 : config.hiddenSize * 2 }
    package func clearDraftMask() { draftMask = nil }

    package func draftEmbedding(anchor: Int, mask: Int) throws -> MLXArray {
        // Validate the anchor before allocating or retaining a mask.
        let anchorRow = try embedding([anchor], shape: [1, 1])
        if draftMask?.id != mask {
            let row = try embedding([mask], shape: [1, 1])
            eval(row)
            draftMask = (mask, row)
        }
        let masks = broadcast(draftMask!.row, to: [1, 7, config.hiddenSize])
        return concatenated([anchorRow, masks], axis: 1)
    }
''')
# Expose unchanged row lookup to the isolated diagnostic command only.
s=s.replace('    func embedding(_ ids:', '    package func embedding(_ ids:')
save('Sources/Slotstream/Q2Checkpoint.swift',s)
s=(R/'Sources/Slotstream/Weights.swift').read_text()
s=s.replace('package var embeddingCachedPayloadBytes: Int { embeddingRows?.cachedPayloadBytes ?? 0 }','package var embeddingCachedPayloadBytes: Int { (embeddingRows?.cachedPayloadBytes ?? 0) + (q2?.draftMaskPayloadBytes ?? 0) }')
s=s.replace('package func clearEmbeddingRows() { embeddingRows?.clear() }','package func clearEmbeddingRows() { embeddingRows?.clear(); q2?.clearDraftMask() }')
needle='    private func gatherEmbeddingRows('
assert s.count(needle)==1
s=s.replace(needle,'''    package func draftNoiseEmbedding(anchor: Int, mask: Int) throws -> MLXArray {
        if let q2 { return try q2.draftEmbedding(anchor: anchor, mask: mask) }
        return try embedChecked([anchor] + Array(repeating: mask, count: 7), shape: [1, 8]).asType(.bfloat16)
    }

'''+needle)
save('Sources/Slotstream/Weights.swift',s)
s=(R/'Sources/Slotstream/DFlashDraft.swift').read_text();old='try target.resident.embedChecked([anchor] + Array(repeating: maskToken, count: 7), shape: [1, 8]).asType(.bfloat16)'
assert s.count(old)==1;s=s.replace(old,'try target.resident.draftNoiseEmbedding(anchor: anchor, mask: maskToken)');save('Sources/Slotstream/DFlashDraft.swift',s)
s=(R/'Sources/Slotstream/PackMemoryProfile.swift').read_text();old='expertRecordBytes: 1_382_400, residentReserveBytes: 1_600_000_000'
assert s.count(old)==1;s=s.replace(old,old+' + 16_384 // One decoded Q2 draft-mask allocation.');save('Sources/Slotstream/PackMemoryProfile.swift',s)
s=(R/'Sources/slotstream-cli/Q2ExpertsCheck.swift').read_text();needle='    func run() throws {\n'
assert s.count(needle)==1
s=s.replace(needle,'''    @Flag var maskOnly = false
    func run() throws {
        if maskOnly {
            guard (Machine.current().availableGB ?? 0) >= 6 else { throw ValidationError("6 GB reclaimable required") }
            try ModelProcessGuard.acquire()
            MLX.Memory.cacheLimit = 128 << 20
            let index = try CheckpointIndex(q2Directory: ModelLocator.resolve("smart-q2"))
            let checkpoint = index.q2!
            var checked = 0
            for mask in [248077, 42, 248077] {
                for anchor in [0, 42, 248077, 248319, 512, 42] {
                    let actual = try checkpoint.draftEmbedding(anchor: anchor, mask: mask)
                    let reference = try checkpoint.embedding([anchor] + Array(repeating: mask, count: 7), shape: [1, 8])
                    guard actual.shape == reference.shape, actual.dtype == .bfloat16,
                        (actual .== reference).all().item(Bool.self), checkpoint.draftMaskPayloadBytes == 5120 else {
                        throw ValidationError("Draft mask differs from original-row decode")
                    }
                    checked += 1
                }
                checkpoint.clearDraftMask()
                guard checkpoint.draftMaskPayloadBytes == 0 else { throw ValidationError("Draft mask did not clear") }
            }
            for pair in [(-1,248077),(248320,248077),(42,-1),(42,248320)] {
                do {
                    _ = try checkpoint.draftEmbedding(anchor: pair.0, mask: pair.1)
                    throw ValidationError("Invalid embedding ID admitted")
                } catch is ModelError { }
            }
            // Alternating component control includes reads, graph preparation,
            // submission and synchronous completion. It is not request speed.
            for arm in ["A", "B", "B", "A"] {
                let start = RuntimeClock.now()
                for i in 0..<512 {
                    let anchor = (i * 71 + 31) % 248320
                    let noise = try arm == "A" ? checkpoint.embedding([anchor] + Array(repeating: 248077, count: 7), shape: [1, 8]) : checkpoint.draftEmbedding(anchor: anchor, mask: 248077)
                    eval(noise)
                }
                print("MASK_COMPONENT \\(arm) \\(Double(RuntimeClock.now()-start)/1e9)")
            }
            print("Q2 mask reuse: \\(checked) exact original-row cases, clear/reload, changing mask, four invalid IDs PASS")
            return
        }
''')
save('Sources/slotstream-cli/Q2ExpertsCheck.swift',s)
for dst,src in [('Sources/slotstream-cli/Q2ProfileCommand.swift',F/'Q2ProfileCommand.swift'),('Sources/slotstream-cli/SmartDFlashCommand.swift',P.parent/'q2-request-profile-20261025/SmartDFlashCommand-request-clock.swift')]:save(dst,src.read_text())
(P/'replacements.json').write_text(json.dumps(replacements,indent=2))
for name in ['build.py','run.py','validate.py','quiet_guarded_run.py','check_restoration.py']:shutil.copy2(Q/name,P/name)
shutil.copy2(F/'timed-2.json',P/'timed-2.json')
s=(P/'validate.py').read_text().replace('Q2 preserves already-started forecasts even before first piece completion; queued-only forecasts remain demand misses.','Q2 reuses one immutable decoded draft mask row; no reader scheduling change.');(P/'validate.py').write_text(s)
(P/'plan.json').write_text(json.dumps(dict(scope='Q2-only immutable mask reuse, owned by checkpoint, explicit16KiB reserve and payload reporting. Fast retains same lookup expression. No reader, controller or expert schedule changes.',hypothesis='Repeated mask row reads and GPU decoding may be removable work. Concatenation adds an operation and could negate the saving. Earlier per-lookup compressed-read dedup did not qualify.',gates=dict(correctness='18 exact original-row cases, clear/reload/identity changes, invalid IDs; then111 full logits, proposals and selected tokens. 4067slots and physical15GB ceiling must remain.',component='ABBA512lookups each is diagnostic only, not request performance. Includes first preparation; no timing retries.',request='One ABCCBA normal15GB4067slot8192context comparison vs v68 and Splash, two warmups and384-token code/prose. Each fixture must improve in both directions and pooled>=1%; parity<=5%inbothdirections. Any paging/competingbuild/thermal failure excludes whole protocol. No retry.',retention='Only after repeatable complete-request gain and exact correctness. Defaults remain v68 otherwise.'),sources={n:hashlib.sha256((P/f).read_bytes()).hexdigest()for n,f in replacements.items()}),indent=2))
print('prepared isolated candidate')
