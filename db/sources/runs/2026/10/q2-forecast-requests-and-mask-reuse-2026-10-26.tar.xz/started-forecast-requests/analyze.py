from pathlib import Path
import json, statistics
P=Path(__file__).resolve().parent
events=json.loads((P/'ordinary-started-15-ledger.json').read_text())
assert [e['arm'] for e in events]==list('ABCCBA')
arms=[]; native={}
for e in events:
 d=json.loads((P/(e['label']+'.json')).read_text())
 arm=dict(label=e['label'],eligible=e['eligible'],swapins=e['after']['vm']['swapins']-e['before']['vm']['swapins'],swapouts=e['after']['vm']['swapouts']-e['before']['vm']['swapouts'],runs=[])
 for r in d['runs']:
  if not r['id'].startswith('timed'):continue
  row=dict(id=r['id'],request_seconds=r['elapsed_seconds'])
  if e['arm']!='C':
   s=r['stats'];p=s['expertPrefetch'];row.update(cycles=p['passes'],join_seconds=p['joinSeconds'],promoted=p['promoted'],adopted=p['adopted'],demand_misses=p['demandMisses'],issued=p['issued'],decode_io_seconds=s['decodeIOSeconds'],calibration_cycles_before=s['dflashCalibrationCyclesBefore'])
   native[(e['label'],r['id'])]=r['tokens']
  arm['runs'].append(row)
 arms.append(arm)
ratios={}
for ident in ['timed-2','timed-3']:
 t=[next(r['request_seconds']for r in a['runs']if r['id']==ident)for a in arms]
 ratios[ident]=dict(times=t,candidate_over_baseline_forward=t[1]/t[0],candidate_over_baseline_reverse=t[4]/t[5],candidate_over_baseline_pooled=statistics.mean([t[1],t[4]])/statistics.mean([t[0],t[5]]),candidate_over_splash_forward=t[1]/t[2],candidate_over_splash_reverse=t[4]/t[3])
variation=[]
for ident in ['timed-2','timed-3']:
 reference=native[(events[0]['label'],ident)]
 for index in [1,4,5]:
  actual=native[(events[index]['label'],ident)]
  variation.append(dict(reference=events[0]['label'],actual=events[index]['label'],fixture=ident,first_differing_token=next((i for i,(a,b)in enumerate(zip(reference,actual))if a!=b),None),lengths=[len(reference),len(actual)]))
out=dict(qualified=False,reason='Whole six-arm protocol excluded:12swap-in pages inB1 and4inC2. No retries or favorable-arm selection.',arms=arms,excluded_raw_ratios=ratios,token_variation=variation,interpretation='Candidate not retained. Baseline itself varies with adaptive widths; fixed111cycle full-logit/proposal/token equality remains valid. Splash explicitly documents greedy output variation with auto verification widths. Join waits increase to55–81ms/request, too small to establish the main gap. Capped384-token outputs are not task-quality passes.',next='Separate small Q2 immutable-mask reuse experiment; reader rewrite remains unsupported.')
(P/'analysis.json').write_text(json.dumps(out,indent=2))
print(json.dumps({k:out[k]for k in ['qualified','reason','excluded_raw_ratios','token_variation']},indent=2))
