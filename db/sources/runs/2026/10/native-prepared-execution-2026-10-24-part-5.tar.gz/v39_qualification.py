import json,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];events=[]
def run(label,cmd):
 print('START',label,flush=True)
 with(P/(label+'-driver.log')).open('x')as log:r=subprocess.run(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT)
 events.append(dict(label=label,command=cmd,exit_code=r.returncode));(P/'v39-qualification-ledger.json').write_text(json.dumps(events,indent=2)+'\n')
 print('END',label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
run('v39-core',[sys.executable,str(P/'v39_core.py')])
for model,budget in [('smart-q2',15)]:
 label='v39-default-'+model+str(budget)+'-splash'
 run(label,[sys.executable,str(P/'native_splash_compare_v39.py'),'--cases',str(P/'short-warm-384-cases.json'),'--label',label,'--native',str(P/'v39/slotstream'),'--model',model,'--budget',str(budget)])
 run(label+'-summary',[sys.executable,str(P/'comparison_summary.py'),label])
