from pathlib import Path
import hashlib,json,shutil,subprocess
P=Path(__file__).resolve().parent;R=P.parents[1];F=P.parent/'q2-full-cycle-20261025';O=P.parent/'q2-graph-owner-20261026';W=P/'source-reference';D=P/'upstream';D.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()=='1482f6bbc2abf12375332725302019594150b6cb'
def replace(s,old,new):
    assert s.count(old)==1,(old,s.count(old));return s.replace(old,new)
s=(R/'Sources/CNativeSchedule/NativeSchedule.cpp').read_text();(P/'NativeSchedule-original.cpp').write_text(s)
s='#include "DependencyProbe.hpp"\n'+s
s=replace(s,'struct Job {','struct Job {\n  uint64_t dep_id=ssdep::next_id();\n  std::array<uint64_t,3> dep_forecast{};')
s=replace(s,'    ready.data<uint32_t>()[0] = success ? 1 : 2;','''    ssdep::emit(2,dep_id,lease?reinterpret_cast<uint64_t>(lease->event.cast<metal::EventImpl>().mtl_event()):0,success,lease?lease->next:0);
    if(ssdep::prefix && success && staged) {
      const auto* flags=mask->data<int32_t>();const auto* from=sources->data<int32_t>();
      for(int i=0;i<staged;++i)for(int p=0;p<3;++p){
        const uint64_t bytes=raw[p].shape(1);
        const uint64_t base=flags[i]==2?dep_forecast[p]:reinterpret_cast<uint64_t>(raw[p].data<uint8_t>());
        const uint64_t offset=uint64_t(flags[i]==2?from[i]:i)*bytes;
        ssdep::emit(4,dep_id,base+offset,bytes,flags[i],i,p);
      }
    }
    ready.data<uint32_t>()[0] = success ? 1 : 2;''')
s=replace(s,'    published.store(true, std::memory_order_release);','    published.store(true, std::memory_order_release);\n    ssdep::emit(3,dep_id,lease?reinterpret_cast<uint64_t>(lease->event.cast<metal::EventImpl>().mtl_event()):0,success,lease?lease->next:0);')
s=replace(s,'          inputs.push_back(a); work->forecast_records = a.shape(0);','          inputs.push_back(a); work->forecast_records = a.shape(0);\n          work->dep_forecast[piece]=reinterpret_cast<uint64_t>(a.data<uint8_t>());')
s=replace(s,'    *output = value.release(); *job = ticket.release(); return 0;','''    ssdep::emit(1,work->dep_id,work->lease?reinterpret_cast<uint64_t>(work->lease->event.cast<metal::EventImpl>().mtl_event()):0,staged_count,work->lease?work->lease->next:0,rows);
    *output = value.release(); *job = ticket.release(); return 0;''')
(P/'NativeSchedule-probe.cpp').write_text(s)
rep={'Sources/CNativeSchedule/NativeSchedule.cpp':'NativeSchedule-probe.cpp','Sources/CNativeSchedule/DependencyProbe.hpp':'DependencyProbe.hpp','Sources/slotstream-cli/Q2ProfileCommand.swift':'Q2ProfileCommand.swift'}
for n in ['Q2ProfileCommand.swift','quiet_guarded_run.py','timed-2.json','check_restoration.py']:shutil.copy2(F/n,P/n)
(P/'replacements.json').write_text(json.dumps(rep,indent=2))
identity=json.loads((F/'upstream/identity.json').read_text())
for n in ['Runtime.cpp','MetalBackend.mm','full_cycle.mm','include/model/RuntimeInstrumentation.hpp']:
    source=F/'upstream'/n;assert sha(source.read_bytes())==identity[str(source)],n
    dest=D/n;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,dest)
shutil.copy2(P/'DependencyProbe.hpp',D/'DependencyProbe.hpp')
s=subprocess.check_output(['git','show','HEAD:runtime/model/ExpertStore.cpp'],cwd=W,text=True);(D/'ExpertStore-original.cpp').write_text(s)
s='#include "DependencyProbe.hpp"\n'+s
needle='''  std::lock_guard lock(mutex);
  // No job runs until the round's are staged; the last round's ran.'''
s=replace(s,needle,'''  ssdep::LoadScope dep_scope(index,rows,round,static_cast<uint32_t>(phase));
'''+needle)
s=replace(s,'    for (uint32_t z = 0; z < 3; ++z) jobSources[3 * job + z] = expertAt(group, k, z);','''    for (uint32_t z = 0; z < 3; ++z) {
      jobSources[3 * job + z] = expertAt(group, k, z);
      ssdep::emit(12,ssdep::last_load,reinterpret_cast<uint64_t>(staging.contents())+expertAt(group,k,z),sizes[blocks[index].size].layout[z].nativeBytes(),expert,index,z);
    }''')
(D/'ExpertStore.cpp').write_text(s)
s=(D/'MetalBackend.mm').read_text();s='#include "DependencyProbe.hpp"\n'+s
s=replace(s,'                        step.work();','                        ssdep::last_load=0;\n                        step.work();')
s=replace(s,'                steps.ranEvent.signaledValue = step.ready;','''                ssdep::emit(13,ssdep::last_load,reinterpret_cast<uint64_t>((__bridge void*)steps.ranEvent),step.ready);
                steps.ranEvent.signaledValue = step.ready;
                ssdep::emit(14,ssdep::last_load,reinterpret_cast<uint64_t>((__bridge void*)steps.ranEvent),step.ready);''')
(D/'MetalBackend.mm').write_text(s)
plan=dict(scope='Required expert dependency identities, not an optimization. Link each actual expert payload to its host-ready event and the read/copy histories. Same frozen111realcycles and existing native/source-Splash arithmetic. Never infer critical delay from all background-read overlap.',configuration='15GBphysical,4067slots,native8192context,existingSplashboundedfixturearena,BF16activation/KV,FP32recurrence. Globalmodelreservation;18GBpreflight;1GBremaining;nominalthermal;noheavyanalysis/build during model protocols.',validation='Both engines:111full-logithashes/proposals/selectedtokens equal their own archived reference underMetalvalidation. Bounded records complete; match payload coverage to positive reads/copies and readiness to actual observed event IDs/values. Fail missing/ambiguous dependencies, do not silently match nearest unrelated read.',timing='Separate fixed N-off,N-on,S-on,S-off diagnostic; one warmup plus one observed round each. All read/copy/GPU observers identical except dependency markers. Two percent control sensitivity; no product speed claim or favorable retries. New markers must not change computation or scheduling.',fields={'1':'native job creation:address=event,bytes=stagedcount,aux0=eventvalue,aux1=rows','2':'native publication begins:address=event,bytes=success,aux0=value','3':'native publication returns','4':'native required payload:address,bytes,aux0=copy1/forecast2,aux1=stageindex,index=piece','10':'Splash load begins:address=block,bytes=rows,aux0=round,aux1=phase','11':'Splash load returns','12':'Splash required payload:address,bytes,aux0=expert,aux1=block,index=piece','13':'Splash event publication begins:address=event,bytes=value','14':'Splash event publication returns'},source_revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),upstream_revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip(),native_sources={n:sha((P/f).read_bytes())for n,f in rep.items()},upstream_sources={str(f.relative_to(D)):sha(f.read_bytes())for f in D.rglob('*')if f.is_file()})
(P/'plan.json').write_text(json.dumps(plan,indent=2));print('prepared native and Splash dependency mappings')
