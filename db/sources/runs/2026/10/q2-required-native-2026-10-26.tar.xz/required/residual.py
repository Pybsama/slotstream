from pathlib import Path
import ast,bisect,collections,csv,json
P=Path(__file__).resolve().parent
scope={'bisect':bisect,'collections':collections,'csv':csv,'PAGE':65536}
exec(compile(ast.Module(body=[n for n in ast.parse((P/'analyze_dependencies.py').read_text()).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))],type_ignores=[]),'analysis-defs','exec'),scope)
union,inter,length,Coverage,rows,footer=map(scope.get,['union','inter','length','Coverage','csv_rows','footer'])
def subtract(left,right):
 out=[];j=0
 for a,b in left:
  while j<len(right)and right[j][1]<=a:j+=1
  k=j
  while k<len(right)and right[k][0]<b:
   c,d=right[k]
   if c>a:out.append([a,min(b,c)])
   a=max(a,d)
   if a>=b:break
   k+=1
  if a<b:out.append([a,b])
 return out
report=[]
for label in ['trace-1-N','trace-2-S']:
 native=label.endswith('N');d=json.loads((P/(label+'-dependency-analysis.json')).read_text());raw=json.loads((P/(label+'.json')).read_text())
 paths={kind:next(P.glob(label+'-commands.*.'+kind+'.csv'))for kind in ['stages','pipelines','assignments']}
 for path in paths.values():footer(path)
 stages=list(rows(paths['stages']));byenc=collections.defaultdict(list);pipelines=collections.defaultdict(list)
 for s in stages:
  s.update(encoded=float(s['encoded']),start=int(s['gpu_start'])/1e9,end=int(s['gpu_end'])/1e9,names=[])
  byenc[s['encoder']].append(s)
 for v in byenc.values():v.sort(key=lambda s:s['encoded'])
 encoded={k:[s['encoded']for s in v]for k,v in byenc.items()}
 for r in rows(paths['pipelines']):pipelines[r['pipeline']].append((float(r['stamp']),r['name']))
 for v in pipelines.values():v.sort()
 for r in rows(paths['assignments']):
  t=float(r['stamp']);i=bisect.bisect_right(encoded[r['encoder']],t)-1;assert i>=0
  v=pipelines[r['pipeline']];k=bisect.bisect_right(v,(t,chr(0x10ffff)))-1;assert k>=0
  byenc[r['encoder']][i]['names'].append(v[k][1])
 cp=next(p for p in P.glob(label+'-commands.*.csv')if not any(n in p.name for n in ['events','stages','assignments','pipelines']));footer(cp)
 commands=collections.defaultdict(list)
 for r in rows(cp):commands[r['buffer']].append(float(r['submitted']))
 for v in commands.values():v.sort()
 missing=[s for s in stages if not s['end']>s['start']>0]
 measured=[(s['start_ns']/1e9,s['end_ns']/1e9)if native else(s['start'],s['end'])for rd in raw['rounds'][1:]for s in rd['steps']]
 assert not any(a<=s['encoded']<b for s in missing for a,b in measured)
 stages=[s for s in stages if s['end']>s['start']>0]
 for s in stages:
  v=commands[s['buffer']];i=bisect.bisect_left(v,s['encoded']);assert i<len(v)
  s['submitted']=v[i];assert s['encoded']<=s['submitted']<=s['start']+1e-6
 stages.sort(key=lambda s:s['start']);gaps=[];edge=0.
 for s in stages:
  if s['start']>edge:gaps.append(dict(a=edge,b=s['start'],stage=s))
  edge=max(edge,s['end'])
 for rd in (1,2):
  steps=raw['rounds'][rd]['steps'];windows=union([(s['start_ns']/1e9,s['end_ns']/1e9)if native else(s['start'],s['end'])for s in steps])
  jobs=[x for x in d['jobs']if x['round']==rd]
  covered=union([(s['start'],s['end'])for s in stages]+[(x['begin'],max(x['begin'],x.get('gpu_start',x['published'])))for x in jobs])
  residual=subtract(windows,covered);cov=Coverage(residual);groups=collections.defaultdict(lambda:collections.Counter());segments=[]
  for gap in gaps:
   a,b=gap['a'],gap['b'];seconds=cov.between(a,b)
   if seconds<1e-10:continue
   s=gap['stage'];sig=' | '.join(s['names']);before_encode=cov.between(a,min(b,max(a,s['encoded'])));before_submit=cov.between(a,min(b,max(a,s['submitted'])))
   groups[sig].update(seconds=seconds,before_encoder=before_encode,encoding_to_submit=before_submit-before_encode,after_submit=seconds-before_submit,count=1)
   segments.append(dict(start=a,end=b,seconds=seconds,before_encoder=before_encode,before_submit=before_submit,signature=sig,stage_index=int(s['index'])))
  phases={}
  if native:
   for key in ['draft_seconds','verify_seconds','sample_seconds','commit_seconds']:phases[key]=0.
   for step in steps:
    a=step['start_ns']/1e9
    for key in phases:b=a+step[key];phases[key]+=cov.between(a,b);a=b
  result=dict(label=label,round=rd,missing_stage_timestamps_outside_measured_windows=len(missing),residual_seconds=length(residual),classified_seconds=sum(s['seconds']for s in segments),phases=phases,groups=sorted([dict(signature=k,**v)for k,v in groups.items()],key=lambda x:-x['seconds']),segments=segments)
  report.append(result);print(json.dumps({**{k:v for k,v in result.items()if k not in ['groups','segments']},'top_groups':result['groups'][:10]},indent=2),flush=True)
(P/'residual-analysis.json').write_text(json.dumps(dict(scope='Observed GPU gaps outside exact expert job creation-to-first-consumer intervals, including zero-payload job publication. GPU activity and other host work can exist outside these encoder scopes. Following-encoder signatures classify location, not causal cost or guaranteed recoverable time.',arms=report),indent=2))
