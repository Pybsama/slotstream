from pathlib import Path
import bisect,collections,csv,json,statistics,struct,subprocess
P=Path(__file__).resolve().parent
assert not subprocess.run(['pgrep','-f',str(P/'native-build/candidate/slotstream')+'|'+str(P/'upstream/full-cycle')],capture_output=True,text=True).stdout.strip()
PAGE=65536
def csv_rows(path):
    with path.open()as f:
        for row in csv.DictReader(f):
            first=next(iter(row.values()))
            if first.startswith('# '):continue
            yield row
def footer(path):
    with path.open('rb')as f:
        f.seek(max(0,path.stat().st_size-1024));last=f.read().decode().splitlines()[-1]
    assert last.startswith('# '),(path,last)
    d=dict(x.split('=',1)for x in last[2:].split());assert int(d['total'])<int(d['cap']),(path,d);return d
def union(xs):
    out=[]
    for a,b in sorted(xs,key=lambda v:(v[0],v[1])):
        if b<=a:continue
        if not out or a>out[-1][1]:out.append([a,b])
        else:out[-1][1]=max(out[-1][1],b)
    return out
def inter(a,b):
    out=[];i=j=0
    while i<len(a)and j<len(b):
        lo,hi=max(a[i][0],b[j][0]),min(a[i][1],b[j][1])
        if hi>lo:out.append([lo,hi])
        if a[i][1]<b[j][1]:i+=1
        else:j+=1
    return out
def length(xs):return sum(b-a for a,b in xs)
class Coverage:
    def __init__(self,xs):
        self.xs=union(xs);self.starts=[a for a,b in self.xs];self.prefix=[0.]
        for a,b in self.xs:self.prefix.append(self.prefix[-1]+b-a)
    def until(self,t):
        i=bisect.bisect_right(self.starts,t)-1
        return 0. if i<0 else self.prefix[i]+min(t,self.xs[i][1])-self.xs[i][0]
    def between(self,a,b):return max(0.,self.until(b)-self.until(a))
class Writes:
    # (end time,start time,destination,end address,source,kind,fd,offset)
    def __init__(self,read_path,copy_path):
        self.rows=[]
        for r in csv_rows(read_path):
            n=int(r['result'])
            if n>0:self.rows.append((float(r['end']),float(r['start']),int(r['destination']),int(r['destination'])+n,0,'read',int(r['fd']),int(r['offset'])))
        for r in csv_rows(copy_path):
            n=int(r['bytes'])
            if n>0:self.rows.append((float(r['end']),float(r['start']),int(r['destination']),int(r['destination'])+n,int(r['source']),'copy',0,0))
        self.rows.sort();self.ends=[r[0]for r in self.rows];self.pages=collections.defaultdict(list)
        for i,r in enumerate(self.rows):
            for page in range(r[2]//PAGE,(r[3]-1)//PAGE+1):self.pages[page].append(i)
    def latest(self,lo,hi,cutoff):
        limit=bisect.bisect_right(self.ends,cutoff)-1;selected=[]
        for page in range(lo//PAGE,(hi-1)//PAGE+1):
            remaining=[(max(lo,page*PAGE),min(hi,(page+1)*PAGE))];ids=self.pages.get(page,[]);k=bisect.bisect_right(ids,limit)-1
            while remaining and k>=0:
                i=ids[k];r=self.rows[i];left=[]
                for a,b in remaining:
                    l,h=max(a,r[2]),min(b,r[3])
                    if h<=l:left.append((a,b));continue
                    selected.append((l,h,i))
                    if a<l:left.append((a,l))
                    if h<b:left.append((h,b))
                remaining=left;k-=1
            if remaining:raise ValueError(('uncovered required bytes',lo,hi,cutoff,remaining))
        # Coalesce page fragments of one actual read or copy.
        merged=[]
        for a,b,i in sorted(selected):
            if merged and merged[-1][2]==i and merged[-1][1]==a:merged[-1]=(merged[-1][0],b,i)
            else:merged.append((a,b,i))
        assert sum(b-a for a,b,i in merged)==hi-lo
        return merged
    def ancestry(self,lo,hi,cutoff,depth=0):
        assert depth<8
        roots=self.latest(lo,hi,cutoff);reads=set();copies=set()
        for a,b,i in roots:
            r=self.rows[i]
            if r[5]=='read':reads.add(i)
            else:
                copies.add(i);aa=r[4]+a-r[2];bb=r[4]+b-r[2]
                rr,cc,_=self.ancestry(aa,bb,r[1],depth+1);reads|=rr;copies|=cc
        return reads,copies,{i for a,b,i in roots}
def analyze(event):
    label=event['label'];native=event['arm']=='N';d=json.loads((P/(label+'.json')).read_text())
    windows=[]
    for rd in d['rounds']:
        for s in rd['steps']:
            a,b=(s['start_ns']/1e9,s['end_ns']/1e9)if native else(s['start'],s['end'])
            windows.append((a,b,rd['round'],s['step']))
    starts=[w[0]for w in windows]
    meta=json.loads(next(P.glob(label+'-dependencies.*.json')).read_text());assert 0<meta['rows']==meta['written']<meta['cap']and meta['row_bytes']==64
    raw=next(P.glob(label+'-dependencies.*.bin')).read_bytes();assert len(raw)==64*meta['rows'];scale=meta['numer']/meta['denom']/1e9
    nodes=collections.defaultdict(lambda:dict(dependencies=[]))
    for stamp,tid,id,address,size,a0,a1,kind,index in struct.iter_unpack('<7Q2I',raw):
        row=dict(time=stamp*scale,thread=tid,address=address,bytes=size,aux0=a0,aux1=a1,index=index)
        node=nodes[id]
        if kind in (4,12):node['dependencies'].append(row)
        else:assert kind not in node,(label,id,kind);node[kind]=row
    read_path=next(P.glob(label+'-reads.*.csv'));copy_path=next(P.glob(label+'-copies.*.csv'))
    stage_path=next(P.glob(label+'-commands.*.stages.csv'));event_path=next(P.glob(label+'-commands.*.events.csv'))
    feet={n:footer(path)for n,path in [('reads',read_path),('copies',copy_path),('stages',stage_path),('events',event_path)]}
    sf=feet['stages'];assert sf['cpu_initial']==sf['gpu_initial']and sf['cpu_final']==sf['gpu_final']
    stage_by_buffer=collections.defaultdict(list);gpu=[]
    for r in csv_rows(stage_path):
        st=dict(encoded=float(r['encoded']),start=int(r['gpu_start'])/1e9,end=int(r['gpu_end'])/1e9)
        stage_by_buffer[int(r['buffer'])].append(st)
        if st['end']>st['start']>0:gpu.append((st['start'],st['end']))
    gpu=union(gpu);coverage=Coverage(gpu);ev=collections.defaultdict(lambda:collections.defaultdict(list))
    for r in csv_rows(event_path):ev[(int(r['event']),int(r['value']))][r['kind']].append(dict(stamp=float(r['stamp']),buffer=int(r['buffer']),kind=r['kind']))
    print('INDEX',label,flush=True);writes=Writes(read_path,copy_path);print('INDEXED',label,len(writes.rows),flush=True)
    results=[];failures=[]
    for id,node in sorted(nodes.items()):
        if id%1000==0:print('PROGRESS',label,id,'resolved',len(results),'failures',len(failures),flush=True)
        begin=node.get(1 if native else 10)
        if not begin:failures.append(dict(id=id,error='missing creation/load marker'));continue
        wi=bisect.bisect_right(starts,begin['time'])-1
        if wi<0 or begin['time']>=windows[wi][1]or windows[wi][2]==0:continue
        rd,step=windows[wi][2:];base=dict(id=id,round=rd,step=step,native=native)
        try:
            pb,pe=(node[2],node[3])if native else(node[13],node[14])
            assert begin['time']<=pb['time']<=pe['time']
            if native:
                assert pb['bytes']==pe['bytes']==1 and len(node['dependencies'])==begin['bytes']*3
                assert all(x['aux0']in (1,2)and x['bytes']>0 for x in node['dependencies'])
            else:assert node[10]['time']<=node[11]['time']<=pb['time']
            if not node['dependencies']:
                results.append(dict(**base,payloads=0,begin=begin['time'],published=pe['time']));continue
            key=(pb['address'],pb['aux0']if native else pb['bytes']);events=ev[key]
            # Exact event identity and monotonically leased value, not nearest event.
            # Splash releases and recreates events; pointer/value pairs may repeat
            # in later lifetimes. The actual publication marker bounds select
            # exactly one signal/return. A wait in that lifetime lies after the
            # previous return for this key and before this signal.
            signals=[x for x in events['S']if pb['time']-1e-6<=x['stamp']<=pe['time']+1e-6]
            returns=[x for x in events['R']if pb['time']-1e-6<=x['stamp']<=pe['time']+1e-6]
            assert len(signals)==len(returns)==1,(key,'publication count',len(signals),len(returns))
            signal,returned=signals[0],returns[0]
            previous=max((x['stamp']for x in events['R']if x['stamp']<pb['time']-1e-6),default=0)
            waits=[x for x in events['W']if previous<x['stamp']<=signal['stamp']]
            assert len(waits)==1,(key,'wait count',len(waits))
            wait=waits[0]
            assert pb['time']-1e-6<=signal['stamp']<=returned['stamp']<=pe['time']+1e-6
            following=[x for x in stage_by_buffer[wait['buffer']]if x['encoded']>=wait['stamp']-1e-9]
            assert following
            stage=min(following,key=lambda x:x['encoded']);assert stage['end']>stage['start']>0
            assert stage['start']>=signal['stamp']-1e-6,(stage,signal)
            rr=set();cc=set();roots=set()
            for dep in node['dependencies']:
                a,b,c=writes.ancestry(dep['address'],dep['address']+dep['bytes'],signal['stamp']);rr|=a;cc|=b;roots|=c
            assert rr and roots
            last_read=max(writes.rows[i][0]for i in rr);last_write=max(writes.rows[i][0]for i in roots)
            assert last_write<=signal['stamp']+1e-9
            new_reads=[i for i in rr if writes.rows[i][1]>=begin['time']]
            intervals={'last_read_to_required_write':(last_read,last_write),'required_write_to_publication':(last_write,signal['stamp']),'required_write_to_publication_entry':(last_write,pb['time']),'publication_return_to_gpu':(min(returned['stamp'],stage['start']),stage['start'])}
            timings={k:dict(seconds=max(0,b-a),outside_observed_gpu_seconds=max(0,b-a)-coverage.between(a,b))for k,(a,b)in intervals.items()}
            results.append(dict(**base,payloads=len(node['dependencies']),required_bytes=sum(x['bytes']for x in node['dependencies']),begin=begin['time'],publish_begin=pb['time'],published=returned['stamp'],gpu_start=stage['start'],last_read=last_read,last_write=last_write,required_reads=len(rr),required_copies=len(cc),new_required_reads=len(new_reads),first_new_required_read=min((writes.rows[i][1]for i in new_reads),default=None),fully_read_before_begin=last_read<=begin['time'],timings=timings,required_read_ids=sorted(rr),required_copy_ids=sorted(cc),event=key,marker_publication_seconds=pe['time']-pb['time']))
        except(Exception)as error:
            failures.append(dict(**base,error=str(error),dependencies=len(node['dependencies'])))
            if len(failures)<=5:print('UNRESOLVED',failures[-1],flush=True)
    per_round=[]
    for rd in [r['round']for r in d['rounds']if r['round']>0]:
        chosen=[x for x in results if x['round']==rd];needed=[x for x in chosen if x['payloads']]
        per_round.append(dict(round=rd,seconds=d['rounds'][rd]['seconds'],jobs=len(chosen),jobs_with_dependencies=len(needed),payloads=sum(x['payloads']for x in needed),timings={k:{m:sum(x['timings'][k][m]for x in needed)for m in ['seconds','outside_observed_gpu_seconds']}for k in ['last_read_to_required_write','required_write_to_publication','publication_return_to_gpu']},new_read_start_after_creation_sum_seconds=sum(max(0,x['first_new_required_read']-x['begin'])for x in needed if x['first_new_required_read']is not None),fully_read_before_creation=sum(x['fully_read_before_begin']for x in needed),marker_publication_seconds=sum(x['marker_publication_seconds']for x in needed)))
    out=dict(label=label,scope='Actual expert payload ancestry and exact readiness-event/first-encoder identities. Latest completed recorded writes cover every payload byte; copies recurse to pread sources at copy start. This assumes the traced read/copy paths are the actual CPU writers, as checked in source. Durations overlap other work and are not pure CPU/GPU idle time or guaranteed removable delay. No matching by nearest unrelated event.',environment_eligible=event['eligible'],metadata=meta,footers=feet,missing_or_ambiguous_dependencies=failures,rounds=per_round,jobs=results)
    (P/(label+'-dependency-analysis.json')).write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items()if k not in ['jobs','footers','missing_or_ambiguous_dependencies']},indent=2),flush=True);print('FAILURES',label,len(failures),flush=True)
    return {k:v for k,v in out.items()if k not in ['jobs','footers']}
ledger=json.loads((P/'trace-ledger.json').read_text());assert len(ledger)==4
summaries=[analyze(e)for e in ledger if e['dependencies']]
controls={}
for arm in ['N','S']:
    es=[e for e in ledger if e['arm']==arm];med={e['dependencies']:statistics.median(r['seconds']for r in e['rounds']if r['round']>0)for e in es};ratio=med[True]/med[False]
    controls[arm]=dict(on=med[True],off=med[False],ratio=ratio,within_two_percent=abs(ratio-1)<=.02)
(P/'analysis.json').write_text(json.dumps(dict(scope='Required dependency attribution only. No product speed claim; complete-request qualification remains required.',environment_eligible=all(e['eligible']for e in ledger),control_sensitivity=controls,arms=summaries),indent=2));print('CONTROLS',controls,flush=True)
