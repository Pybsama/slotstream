from pathlib import Path
import json,ast,bisect,collections,csv
P=Path(__file__).resolve().parent
scope={'bisect':bisect,'collections':collections,'csv':csv,'PAGE':65536}
exec(compile(ast.Module(body=[n for n in ast.parse((P/'analyze_dependencies.py').read_text()).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))],type_ignores=[]),'analysis-defs','exec'),scope)
union,inter,length=map(scope.get,['union','inter','length']);out={}
for label in ['trace-1-N','trace-2-S']:
 d=json.loads((P/(label+'-dependency-analysis.json')).read_text());j=d['jobs'];raw=json.loads((P/(label+'.json')).read_text());native=label.endswith('N')
 gpu=union([(int(r['gpu_start'])/1e9,int(r['gpu_end'])/1e9)for r in scope['csv_rows'](next(P.glob(label+'-commands.*.stages.csv')))if int(r['gpu_end'])>int(r['gpu_start'])>0]);rows=[]
 for rd in (1,2):
  steps=raw['rounds'][rd]['steps'];windows=union([(s['start_ns']/1e9,s['end_ns']/1e9)if native else(s['start'],s['end'])for s in steps]);jobs=[x for x in j if x['round']==rd and x['payloads']];w=length(windows);g=length(inter(windows,gpu));phases={
   'creation_until_required_reads_done':[(x['begin'],max(x['begin'],x['last_read']))for x in jobs],
   'required_read_to_write':[(max(x['begin'],x['last_read']),max(x['begin'],x['last_write']))for x in jobs],
   'required_write_to_publish_entry':[(max(x['begin'],x['last_write']),x['publish_begin'])for x in jobs],
   'publication':[(x['publish_begin'],x['published'])for x in jobs],
   'publication_to_gpu':[(min(x['published'],x['gpu_start']),x['gpu_start'])for x in jobs]}
  sums={k:dict(union_seconds=length(inter(union(v),windows)),outside_gpu=length(inter(union(v),windows))-length(inter(inter(union(v),windows),gpu)))for k,v in phases.items()}
  covered=union([pair for v in phases.values()for pair in v]);exposed=length(inter(covered,windows))-length(inter(inter(covered,windows),gpu))
  rows.append(dict(round=rd,cycle_seconds=w,gpu_seconds=g,non_gpu_seconds=w-g,phases=sums,not_gpu_or_dependency_phases=w-g-exposed))
 out[label]=rows
(P/'phase-decomposition.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
