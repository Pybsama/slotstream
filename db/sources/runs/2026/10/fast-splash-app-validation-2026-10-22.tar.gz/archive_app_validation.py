import hashlib
import io
import json
import tarfile
from pathlib import Path

P = Path(__file__).resolve().parent
ROOT = P.parents[1]
destination = ROOT / 'db/sources/runs/2026/10/fast-splash-app-validation-2026-10-22.tar.gz'
assert not destination.exists()
names = [
    'archive_app_validation.py', 'app-bench-fast-final.py',
    'app-checks-final.log', 'app-scripted-audit.json',
    'app-bundle-final.log', 'app-final-identity.json', 'app-final-source.tar.gz',
    'app-real-final-launcher.log', 'app-real-fast-final.log',
    'app-real-fast-final-observer.json', 'app-real-fast-final/results.json',
    'app-real-audit.json', 'quality-comparison-audit.json',
    'app-real-fast-baseline-control.log', 'app-real-fast-baseline-control-observer.json',
    'app-baseline/hashes.json', 'app-baseline/app-build-inputs.json',
    'static-gates-final.log', 'static-gates-receipt.json',
    'brain-gates-initial.log', 'docs-build.log',
]
names += [str(x.relative_to(P)) for x in P.glob('app-baseline-control*') if x.is_file()]
baseline_results = P / 'app-real-fast-baseline-control/results.json'
if baseline_results.exists(): names.append(str(baseline_results.relative_to(P)))
names += [str(x.relative_to(P)) for x in (P / 'app-real-fast-final/Sources').rglob('*') if x.is_file()]
payloads = {name: (P / name).read_bytes() for name in names}
payloads['harness-dependencies/prefill_bench.py'] = (ROOT / 'Tools/prefill_bench.py').read_bytes()
manifest = {
    'scope': 'Synthetic app qualification, build identity and repository gates. No user Home included.',
    'files': {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
              for name, data in sorted(payloads.items())}
}
payloads['manifest.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
with tarfile.open(destination, 'x:gz') as archive:
    for name, data in sorted(payloads.items()):
        entry = tarfile.TarInfo(name)
        entry.size = len(data)
        archive.addfile(entry, io.BytesIO(data))
with tarfile.open(destination, 'r:gz') as archive:
    for name, expected in manifest['files'].items():
        data = archive.extractfile(name).read()
        assert len(data) == expected['bytes']
        assert hashlib.sha256(data).hexdigest() == expected['sha256']
receipt = dict(path=str(destination.relative_to(ROOT)), payloads=len(manifest['files']),
               bytes=destination.stat().st_size, sha256=hashlib.sha256(destination.read_bytes()).hexdigest(),
               readback_verified=True)
(P / 'app-archive-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
