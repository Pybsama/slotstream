import json,sys,subprocess,os,time,hashlib
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight,vm_snapshot,terminate_child_tree
p=P/'baseline-quality';p.mkdir(exist_ok=False)
cases=json.loads((R/'.build/native-q2-20261021/quality-cases.json').read_text());out=P/'baseline-quality.json';assert not out.exists();receipt=dict(binary_sha256=hashlib.sha256((P/'baseline/slotstream').read_bytes()).hexdigest(),runs=[],complete=False)
for c in cases:
 before=preflight(15);raw=p/(c['id']+'.json');prompt=p/(c['id']+'.txt');prompt.write_text(c['prompt'])
 cmd=[str(P/'baseline/slotstream'),'run','--model','fast','--memory-gb','12','--max-context','32768','--prompt-file',str(prompt),'--max-tokens',str(c['maxTokens']),'--greedy','--sample-footprint','--stats-json',str(raw)]
 with (p/(c['id']+'.log')).open('x') as log:
  child=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,env={k:v for k,v in os.environ.items() if not k.startswith(('SLOTSTREAM_','MLX_'))},start_new_session=True)
  try:rc=child.wait(timeout=600)
  finally:
   if child.poll() is None:terminate_child_tree(child)
 assert rc==0;d=json.loads(raw.read_text());s=d['stats'];assert s['peakMemoryGB']<=12 and not s['memoryPressureCancelled'] and not s.get('runtimeError')
 receipt['runs'].append(dict(id=c['id'],text=d['text'],stats=s,prompt_ids=d['prompt_ids'],tokens=d['output_ids'],command=cmd,vm_before=before,vm_after=vm_snapshot()));out.write_text(json.dumps(receipt,indent=2));print(c['id'],s['finishReason'],flush=True)
receipt['complete']=True;out.write_text(json.dumps(receipt,indent=2))
