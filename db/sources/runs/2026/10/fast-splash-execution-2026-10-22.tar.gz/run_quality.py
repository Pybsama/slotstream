import json,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1]
def run(args,label):
 with (P/(label+'.launcher.log')).open('x') as log:
  result=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT)
 print(label,result.returncode,flush=True)
 if result.returncode: raise SystemExit(result.returncode)
run([sys.executable,str(P/'guarded_run.py'),'--label','final-quality-guard','--budget','12','--',str(P/'final/slotstream'),'smart-dflash-check','--method','fast','--memory-gb','12','--cases',str(P/'quality-and-functional-cases.json'),'--output',str(P/'final-quality.json')],'final-quality')
d=json.loads((P/'final-quality.json').read_text());slots=d['plan']['pool_slots'];expert=slots*1769472+465567744+40960+7168+16+32*(257+18)*4+4096
run([sys.executable,str(P/'baseline_quality.py')],'baseline-quality')
run([sys.executable,str(P/'upstream_bench.py'),'--memory-gb','12','--verify','auto','--kv','bf16','--context','32768','--expert-memory',str(expert),'--cases',str(P/'final-quality-cases.json'),'--tokens',str(P/'final-quality.json'),'--output',str(P/'splash-quality.json')],'splash-quality')
s=json.loads((P/'splash-quality.json').read_text());assert s['complete'] and s['status_ready']['streamed_experts']['slots']==slots
run([sys.executable,str(R/'.build/native-q2-20261021/grade_v2.py'),str(P/'baseline-quality.json'),str(P/'final-quality.json'),str(P/'splash-quality.json')],'quality-grade')
