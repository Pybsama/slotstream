from pathlib import Path
import subprocess,sys,json
P=Path(__file__).resolve().parent;R=P.parents[1];B=P/'final/slotstream';results=[]
def run(label,cmd):
 with (P/(label+'.log')).open('x') as log:
  r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 results.append(dict(label=label,command=cmd,exit_code=r.returncode));(P/'native-checks-results.json').write_text(json.dumps(results,indent=2));print(label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
run('final-t1',[str(P/'final/slotstream-checks'),'--tier','t1','--json'])
run('final-gdn-kernel',[str(B),'optimization-state-check','--variant','gdn-kernel','--json'])
run('final-arithmetic-control',[sys.executable,str(P/'guarded_run.py'),'--label','final-arithmetic-control-guard','--budget','12','--',str(B),'smart-dflash-check','--method','fast','--disable-draft','--memory-gb','12','--cases',str(P/'arithmetic-control-cases.json'),'--output',str(P/'final-arithmetic-control.json')])
run('final-q2-regression',[sys.executable,str(P/'guarded_run.py'),'--label','final-q2-regression-guard','--budget','10','--',str(B),'smart-dflash-check','--method','q2','--model','smart-q2','--memory-gb','10','--cases',str(R/'.build/native-q2-20261021/functional-cases.json'),'--output',str(P/'final-q2-regression.json')])
run('final-fast-smart-acceptance',[sys.executable,str(R/'Tools/fast_smart_acceptance.py'),'--binary',str(B),'--out',str(P/'final-fast-smart-acceptance')])
