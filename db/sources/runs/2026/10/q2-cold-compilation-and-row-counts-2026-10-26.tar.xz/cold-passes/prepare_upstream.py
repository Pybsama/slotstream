from pathlib import Path
import shutil,json,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1];F=R/'.build/q2-full-cycle-20261025';D=P/'upstream';S=R/'.build/q2-required-dependencies-20261026/source-reference';T=R/'.build/q2-typical-20261025/upstream'
(D/'include/model').mkdir(parents=True,exist_ok=True)
for n in ['Runtime.cpp','MetalBackend.mm','full_cycle.mm','include/model/RuntimeInstrumentation.hpp']:shutil.copy2(F/'upstream'/n,D/n)
source=(S/'runtime/model/ExpertStore.cpp').read_text();old=(T/'ExpertStore.cpp').read_text();method=old[old.index('void ExpertStore::diagnosticClearResidency()'):old.rindex('} // namespace splash::model')]
source=source.replace('} // namespace splash::model',method+'} // namespace splash::model');(D/'ExpertStore.cpp').write_text(source)
head=(S/'runtime/model/ExpertStore.hpp').read_text();assert head.count('  ~ExpertStore() override;')==1;head=head.replace('  ~ExpertStore() override;','  ~ExpertStore() override;\n  void diagnosticClearResidency();');(D/'include/model/ExpertStore.hpp').write_text(head)
p=D/'full_cycle.mm';s=p.read_text();old='''        prefill(executor,lanes[0],prompt);
        uint32_t step=0;std::ostringstream output;''';new='''        store->diagnosticClearResidency();
        const auto prefillStart=std::chrono::steady_clock::now();
        const auto prefillBefore=store->stats().uses[0];
        prefill(executor,lanes[0],prompt);
        const auto prefillEnd=std::chrono::steady_clock::now();
        const auto prefillAfter=store->stats().uses[0];
        uint32_t step=0;std::ostringstream output;
        output<<std::setprecision(12)<<"PREFILL "<<round<<' '
          <<std::chrono::duration<double>(prefillStart.time_since_epoch()).count()<<' '
          <<std::chrono::duration<double>(prefillEnd.time_since_epoch()).count()<<' '
          <<prefillAfter.read-prefillBefore.read<<' '<<prefillAfter.prefetched-prefillBefore.prefetched<<'\\n';''';assert s.count(old)==1;s=s.replace(old,new);s=s.replace('#include <sstream>','#include <sstream>\n#include <mach/mach_time.h>');s=s.replace('      const bool validate=', '      mach_timebase_info_data_t tb{};mach_timebase_info(&tb);const uint64_t machNs=mach_absolute_time()*uint64_t(tb.numer)/tb.denom;const auto steadyNs=std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();std::printf("CLOCK %llu %llu\\n",(unsigned long long)machNs,(unsigned long long)steadyNs);\n      const bool validate=');p.write_text(s)
s=(F/'build_upstream.py').read_text();s=s.replace("preflight(10)\n",'');s=s.replace(" fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)"," fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)\n os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(P/'upstream-build-inner.lock');preflight(10)")
s=s.replace('commands=[common+','commands=[common+[\'-c\',str(D/\'ExpertStore.cpp\'),\'-o\',str(D/\'ExpertStore.o\')],common+',1)
s=s.replace("str(D/'MetalBackend.o'),str(W/'build/engine/libsplash.a')","str(D/'MetalBackend.o'),str(D/'ExpertStore.o'),str(W/'build/engine/libsplash.a')")
s=s.replace("paths=[D/'Runtime.cpp'","paths=[D/'ExpertStore.cpp',D/'include/model/ExpertStore.hpp',D/'ExpertStore.o',D/'Runtime.o',D/'MetalBackend.o',D/'Runtime.cpp'")
(P/'build_upstream.py').write_text(s)
(P/'upstream-source-identity.json').write_text(json.dumps({str(p.relative_to(P)):hashlib.sha256(p.read_bytes()).hexdigest()for p in D.rglob('*')if p.is_file()},indent=2))
print('Prepared clean pinned expert reset and existing fullcycle instrumentation')
