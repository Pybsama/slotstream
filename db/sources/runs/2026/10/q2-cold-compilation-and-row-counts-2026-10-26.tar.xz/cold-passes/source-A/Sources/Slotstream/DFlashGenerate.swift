import Foundation
import MLX

extension Generator {
    /// The target sampler makes every output decision. Draft guesses only
    /// select which target rows can share a pass. Rejected recurrent and KV
    /// state is rolled back through the same checked path as MTP.
    func dflashDecode(draft: DFlashDraft, state: Qwen4ExpModel.State, logits: MLXArray,
        params: SampleParams, eosIds: Set<Int>, shouldContinue: () -> Bool, contextLimit: Int,
        checkAllocation: (Int, Int, String) throws -> Void, onToken: (Int) -> Bool,
        out: inout [Int], generated: inout Set<Int>, reason: inout String,
        consumed: inout [Int], stats: inout GenStats) throws {
        state.invalidateMTP()
        let context = DFlashDraft.Context()
        model.accumulatingDraftPrefill = false
        if let features = model.draftPrefillFeatures ?? model.draftFeatures, features.end == state.tokenCount {
            draft.append(features.rows, endingAt: features.end, to: context)
        }
        model.draftPrefillFeatures = nil
        var policy = AdaptiveSpeculationPolicy(maximumDepth: 7)
        let environment = ProcessInfo.processInfo.environment
        let costTracePath = model.pool.expertStore.isQ2 ? environment["SLOTSTREAM_Q2_COST_TRACE"] : nil
        struct CostCycle: Encodable {
            let cycle: Int
            let context: Int
            let input: [Int]
            let kept: Int
            let decision: DFlashVerifyBudget.Diagnostic
            let confidence: [Float]
            let chosen: Int
            let accepted: Int
            let emitted: Int
            let bonus: Bool?
            let labelsValid: Bool
            let prepared: Bool
            let seconds: Double
            let selectSeconds: Double
            let observeSeconds: Double
            let draftSeconds: Double
            let verifySeconds: Double
            let hits: Int
            let misses: Int
        }
        struct CostTrace: Encodable {
            let prompt_ids: [Int]
            let cycles: [CostCycle]
            let truncated: Bool
        }
        let tracePrompt = costTracePath == nil ? [] : consumed
        var costCycles: [CostCycle] = []
        if costTracePath != nil { costCycles.reserveCapacity(min(params.maxTokens, 8192)) }

        // Diagnostic-only: replay actual adaptive choices without changing
        // target inputs, sampling, rollback, streaming or proposal generation.
        struct FrozenChoice: Decodable { let prompt_ids: [Int]; let depths: [Int] }
        let replayDepths: [Int]?
        if model.pool.expertStore.isQ2, let path = environment["SLOTSTREAM_Q2_DIAGNOSTIC_CHOICES"] {
            let choices = try JSONDecoder().decode([FrozenChoice].self, from: Data(contentsOf: URL(fileURLWithPath: path)))
            let matching = choices.filter { $0.prompt_ids == consumed }
            guard matching.count == 1, !matching[0].depths.isEmpty,
                matching[0].depths.allSatisfy({ (0...7).contains($0) }) else {
                throw ModelError("Diagnostic choices require one exact prompt match")
            }
            replayDepths = matching[0].depths
        } else { replayDepths = nil }

        let useVerifyBudget = model.cfg.isFast
            ? environment["SLOTSTREAM_DFLASH_VERIFY_BUDGET"] != "0"
            : model.pool.expertStore.isQ2 && environment["SLOTSTREAM_Q2_VERIFY_BUDGET"] != "0"
        // Q2 keeps the bounded fit across ordinary engine requests and labels
        // the already evaluated bonus prediction, matching Splash's useful
        // batch selection for the explicit engineering candidate. Qualification
        // belongs to each declared complete-request protocol, including failed
        // comparisons at other cache sizes. Fast keeps its separately
        // measured request-local policy. Engine.dropPrefixCache clears the fit at
        // privacy/ownership transitions. Explicit 0/1 values are ablation
        // controls, not user-facing performance modes. See the prepared
        // execution measurement before changing either operating default.
        let q2Calibration = model.pool.expertStore.isQ2
        let reuseCalibration = environment["SLOTSTREAM_DFLASH_PERSISTENT_CALIBRATION"]
            .map { $0 == "1" } ?? q2Calibration
        let observeBonus = environment["SLOTSTREAM_DFLASH_BONUS_CALIBRATION"]
            .map { $0 == "1" } ?? q2Calibration
        var verifyBudget: DFlashVerifyBudget? = useVerifyBudget
            ? (reuseCalibration ? dflashVerifyCalibration ?? .init() : .init()) : nil
        stats.dflashCalibrationCyclesBefore = verifyBudget?.cycleCount
        defer {
            stats.dflashCalibrationCyclesAfter = verifyBudget?.cycleCount
            if reuseCalibration { dflashVerifyCalibration = verifyBudget }
        }
        guard params.maxTokens > 0, shouldContinue() else { reason = "stop"; return }
        let first = sample(logits, params: params, generated: generated)
        if eosIds.contains(first) { reason = "stop"; return }
        out.append(first); generated.insert(first)
        guard onToken(first) else { reason = "stop"; return }
        var pending: Int? = first
        while let token = pending, out.count < params.maxTokens {
            guard shouldContinue() else { reason = "stop"; break }
            let action = policy.action(contextTokens: state.tokenCount)
            let requestedDepth: Int
            if verifyBudget != nil, context.end == state.tokenCount { requestedDepth = 7 }
            else if case .draft(let depth) = action, context.end == state.tokenCount { requestedDepth = depth }
            else { requestedDepth = 0 }
            let depth = min(requestedDepth, params.maxTokens - out.count,
                max(0, contextLimit - state.tokenCount - 1))
            if depth == 0 {
                if action == .plain {
                    model.capturesDraftFeatures = false
                    stats.adaptiveDisabledAtOutput = stats.adaptiveDisabledAtOutput ?? out.count
                }
                try checkAllocation(state.tokenCount + 1, 1_300_000, "plain target decode")
                let started = RuntimeClock.now()
                model.lookahead?.beginPass(phase: .mainPlain, tokens: [token], features: [])
                let next = try model.lastLogitsChecked([token], state: state)
                eval(next)
                model.lookahead?.endPass()
                consumed.append(token)
                stats.decodeForwardPasses += 1; stats.decodeModelTokens += 1
                let sampled = sample(next, params: params, generated: generated)
                policy.observePlain(seconds: RuntimeClock.seconds(since: started), contextTokens: state.tokenCount)
                stats.adaptivePlainTokens += 1
                if action != .plain, let features = model.draftFeatures, features.end == state.tokenCount {
                    draft.append(features.rows, endingAt: features.end, to: context)
                }
                if eosIds.contains(sampled) { reason = "stop"; break }
                out.append(sampled); generated.insert(sampled)
                guard onToken(sampled) else { reason = "stop"; break }
                pending = sampled
                continue
            }
            let decision = costTracePath == nil ? nil : verifyBudget?.diagnosticSnapshot()
            let traceContext = state.tokenCount
            let traceHits = costTracePath == nil ? 0 : model.pool.hits
            let traceMisses = costTracePath == nil ? 0 : model.pool.misses
            let traceDraft = stats.draftSeconds, traceVerify = stats.verifySeconds
            let pipelinesBefore = q2Calibration ? NativeProjectionSchedule.pipelineCount : 0
            let started = RuntimeClock.now(), emittedBefore = out.count
            try checkAllocation(state.tokenCount, 64_000_000, "DFlash proposal workspace")
            let draftStart = RuntimeClock.now()
            let guesses = try draft.propose(anchor: token, depth: depth, target: model, context: context,
                captureConfidence: verifyBudget != nil)
            let selectStart = costTracePath == nil ? UInt64(0) : RuntimeClock.now()
            let chosen: Int
            if let replayDepths {
                guard stats.verifyPasses < replayDepths.count else { throw ModelError("Diagnostic choices exhausted") }
                chosen = replayDepths[stats.verifyPasses]
                guard chosen <= guesses.count else { throw ModelError("Diagnostic choices exceed proposal extent") }
            } else {
                chosen = verifyBudget.map { $0.depth(confidence: draft.proposalConfidence) } ?? guesses.count
            }
            let selectSeconds = costTracePath == nil ? 0 : RuntimeClock.seconds(since: selectStart)
            let proposals = Array(guesses.prefix(chosen))
            stats.draftSeconds += RuntimeClock.seconds(since: draftStart)
            stats.draftedTokens += proposals.count
            guard shouldContinue() else { reason = "stop"; break }
            let checkpoint = state.checkpoint(), input = [token] + proposals
            try checkAllocation(state.tokenCount + input.count,
                ContextWorkspace.prefillBytes(pass: input.count, context: state.tokenCount + input.count), "DFlash target verification")
            state.setRecording(true)
            let verifyStart = RuntimeClock.now()
            model.lookahead?.beginPass(phase: .mainVerify, tokens: input, features: [])
            let result = try model.allLogitsWithMultiChecked(input, state: state)
            eval(result.logits)
            stats.verifySeconds += RuntimeClock.seconds(since: verifyStart)
            stats.verifyPasses += 1; stats.decodeForwardPasses += 1; stats.decodeModelTokens += input.count
            let captured = model.draftFeatures
            var accepted = 0
            var bonusAccepted: Bool?
            pending = nil
            for position in 0...proposals.count {
                guard out.count < params.maxTokens else { break }
                guard shouldContinue() else { reason = "stop"; break }
                let sampled = sample(result.logits[0..., position..<(position + 1), 0...], params: params, generated: generated)
                if eosIds.contains(sampled) { reason = "stop"; break }
                if observeBonus, position == proposals.count, position < guesses.count {
                    bonusAccepted = sampled == guesses[position]
                }
                out.append(sampled); generated.insert(sampled)
                guard onToken(sampled) else { reason = "stop"; break }
                if position < proposals.count, sampled == proposals[position] { accepted += 1 }
                else { pending = sampled; break }
            }
            let reconcileStart = RuntimeClock.now()
            let kept = [token] + Array(proposals.prefix(accepted))
            try state.rollbackChecked(keeping: kept.count, of: input, from: checkpoint, ngramWindow: model.cfg.ngramSize - 1)
            model.lookahead?.passReconciled(kept: kept.count)
            model.lookahead?.endPass()
            consumed.append(contentsOf: kept)
            if let captured {
                draft.append(captured.rows[0..., 0..<kept.count, 0...], endingAt: state.tokenCount, to: context)
            }
            stats.reconciliationSeconds += RuntimeClock.seconds(since: reconcileStart)
            stats.acceptedDrafts += accepted; stats.adaptiveDraftDepths.append(proposals.count)
            let labelsValid = pending != nil && shouldContinue()
            if bonusAccepted != nil && labelsValid {
                stats.dflashBonusObservations = (stats.dflashBonusObservations ?? 0) + 1
            }
            let preparedPipelines = q2Calibration
                && NativeProjectionSchedule.pipelineCount > pipelinesBefore
            if preparedPipelines {
                stats.dflashPreparationCycles = (stats.dflashPreparationCycles ?? 0) + 1
            }
            let cycleSeconds = RuntimeClock.seconds(since: started)
            let observeStart = costTracePath == nil ? UInt64(0) : RuntimeClock.now()
            verifyBudget?.observe(confidence: draft.proposalConfidence, verified: proposals.count,
                accepted: accepted, seconds: cycleSeconds,
                labelsValid: labelsValid, bonusAccepted: bonusAccepted)
            let observeSeconds = costTracePath == nil ? 0 : RuntimeClock.seconds(since: observeStart)
            if let decision, costCycles.count < 8192 {
                costCycles.append(CostCycle(cycle: stats.verifyPasses - 1, context: traceContext, input: input, kept: kept.count,
                    decision: decision, confidence: draft.proposalConfidence, chosen: proposals.count,
                    accepted: accepted, emitted: out.count - emittedBefore, bonus: bonusAccepted,
                    labelsValid: labelsValid, prepared: preparedPipelines, seconds: cycleSeconds,
                    selectSeconds: selectSeconds, observeSeconds: observeSeconds,
                    draftSeconds: stats.draftSeconds - traceDraft,
                    verifySeconds: stats.verifySeconds - traceVerify,
                    hits: model.pool.hits - traceHits, misses: model.pool.misses - traceMisses))
            }
            // The confidence/cost controller already selects the useful
            // prefix, including an anchor-only target pass. A second controller
            // permanently halving its proposal horizon confounds its cost fit
            // and prevents its scheduled exploration from recovering.
            if verifyBudget == nil {
                policy.observeDraft(seconds: RuntimeClock.seconds(since: started), emitted: out.count - emittedBefore,
                    drafted: proposals.count, accepted: accepted)
            }
        }
        if let costTracePath {
            let trace = CostTrace(prompt_ids: tracePrompt, cycles: costCycles,
                truncated: stats.verifyPasses > costCycles.count)
            var bytes = try JSONEncoder().encode(trace); bytes.append(0x0a)
            if !FileManager.default.fileExists(atPath: costTracePath) {
                guard FileManager.default.createFile(atPath: costTracePath, contents: nil) else {
                    throw ModelError("Cannot create diagnostic cost trace")
                }
            }
            let file = try FileHandle(forWritingTo: URL(fileURLWithPath: costTracePath))
            defer { try? file.close() }
            try file.seekToEnd(); try file.write(contentsOf: bytes)
        }
    }
}
