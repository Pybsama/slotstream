#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#import <objc/runtime.h>
#include <atomic>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <mach/mach_time.h>
#include <pthread.h>
namespace {
constexpr unsigned limit=16384;
struct Row { std::atomic<unsigned> done{0}; unsigned kind; uint64_t start,end,thread; bool main,ok; char name[160]; };
Row rows[limit]; std::atomic<unsigned> next{0}; const char *path=nullptr; mach_timebase_info_data_t scale{};
using Lib=id<MTLLibrary>(*)(id,SEL,NSString*,MTLCompileOptions*,NSError**);
using Pipe=id<MTLComputePipelineState>(*)(id,SEL,id<MTLFunction>,NSError**);
using Desc=id<MTLComputePipelineState>(*)(id,SEL,MTLComputePipelineDescriptor*,MTLPipelineOption,MTLComputePipelineReflection**,NSError**);
Lib originalLibrary=nullptr; Pipe originalPipeline=nullptr; Desc originalDescriptor=nullptr;
uint64_t now(){return mach_absolute_time()*uint64_t(scale.numer)/scale.denom;}
Row *begin(unsigned kind,NSString *name){unsigned i=next.fetch_add(1,std::memory_order_relaxed);if(i>=limit)return nullptr;auto *r=&rows[i];r->kind=kind;r->main=pthread_main_np();pthread_threadid_np(nullptr,&r->thread);const char *n=name?[name UTF8String]:"";std::snprintf(r->name,sizeof(r->name),"%s",n?n:"");r->start=now();return r;}
void end(Row*r,bool ok){if(!r)return;r->end=now();r->ok=ok;r->done.store(1,std::memory_order_release);}
id<MTLLibrary> library(id self,SEL cmd,NSString *source,MTLCompileOptions *options,NSError **error){auto*r=begin(0,@"source-library");auto v=originalLibrary(self,cmd,source,options,error);end(r,v!=nil);return v;}
id<MTLComputePipelineState> pipeline(id self,SEL cmd,id<MTLFunction>function,NSError**error){auto*r=begin(1,[function name]);auto v=originalPipeline(self,cmd,function,error);end(r,v!=nil);return v;}
id<MTLComputePipelineState> descriptor(id self,SEL cmd,MTLComputePipelineDescriptor *desc,MTLPipelineOption opts,MTLComputePipelineReflection **reflection,NSError**error){auto*r=begin(2,[[desc computeFunction]name]);auto v=originalDescriptor(self,cmd,desc,opts,reflection,error);end(r,v!=nil);return v;}
IMP hook(Class cls,SEL sel,IMP replacement){Method m=class_getInstanceMethod(cls,sel);if(!m)return nullptr;IMP original=method_getImplementation(m);const char *types=method_getTypeEncoding(m);if(!class_addMethod(cls,sel,replacement,types))class_replaceMethod(cls,sel,replacement,types);return original;}
void quoted(FILE*f,const char*s){fputc('"',f);for(;*s;++s){unsigned char c=*s;if(c=='"'||c=='\\')fputc('\\',f);if(c>=32)fputc(c,f);else fprintf(f,"\\u%04x",c);}fputc('"',f);}
__attribute__((constructor))void setup(){path=getenv("Q2_COMPILE_TRACE");if(!path||!*path){path=nullptr;return;}mach_timebase_info(&scale);@autoreleasepool{id<MTLDevice>d=MTLCreateSystemDefaultDevice();Class cls=object_getClass(d);originalLibrary=reinterpret_cast<Lib>(hook(cls,@selector(newLibraryWithSource:options:error:),reinterpret_cast<IMP>(library)));originalPipeline=reinterpret_cast<Pipe>(hook(cls,@selector(newComputePipelineStateWithFunction:error:),reinterpret_cast<IMP>(pipeline)));originalDescriptor=reinterpret_cast<Desc>(hook(cls,@selector(newComputePipelineStateWithDescriptor:options:reflection:error:),reinterpret_cast<IMP>(descriptor)));[d release];}}
__attribute__((destructor))void dump(){if(!path)return;FILE*f=fopen(path,"wx");if(!f)return;unsigned n=next.load();fprintf(f,"{\"summary\":true,\"count\":%u,\"capacity\":%u,\"overflow\":%s,\"library_hook\":%s,\"pipeline_hook\":%s,\"descriptor_hook\":%s}\n",n,limit,n>limit?"true":"false",originalLibrary?"true":"false",originalPipeline?"true":"false",originalDescriptor?"true":"false");for(unsigned i=0;i<n&&i<limit;++i){auto&r=rows[i];bool done=r.done.load(std::memory_order_acquire);fprintf(f,"{\"index\":%u,\"done\":%s,\"kind\":%u,\"start_ns\":%llu,\"end_ns\":%llu,\"thread\":%llu,\"main\":%s,\"ok\":%s,\"name\":",i,done?"true":"false",r.kind,(unsigned long long)r.start,(unsigned long long)r.end,(unsigned long long)r.thread,r.main?"true":"false",r.ok?"true":"false");quoted(f,r.name);fputs("}\n",f);}fclose(f);}
}
