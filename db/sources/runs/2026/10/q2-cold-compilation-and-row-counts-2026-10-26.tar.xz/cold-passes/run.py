from pathlib import Path
import json,sys,subprocess,fcntl,os,argparse,hashlib,signal
P=Path(__file__).resolve().parent;R=P.parents[1]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight,terminate_child_tree
sys.path.insert(0,str(R/'.build/native-q2-20261021'));from thermal import wait_nominal
ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['validation','timing','control']);a=ap.parse_args()
reservation=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(reservation,fcntl.LOCK_EX|fcntl.LOCK_NB)
inner=P/(a.mode+'-child.lock');os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(inner)
frozen=json.loads((P/'frozen-identity.json').read_text());assert all(hashlib.sha256(Path(n).read_bytes()).hexdigest()==h for n,h in frozen.items())
ledger=P/(a.mode+'-ledger.json');assert not ledger.exists();events=[]
fixture=P/'first-24.json';data=json.loads(fixture.read_text());validation=a.mode=='validation';rounds=3
if not validation:assert json.loads((P/'validation-result.json').read_text())['passed']
model=R/'.build/smart-dflash-eval/upstream-prepared/.resolved/938d6d6879dac79e95a5eae858867e0af230dc252a18266c6aefb6732b65dee7'
sequence=[(x,False)for x in 'ABS']if validation else ([('A',False),('A',True),('A',True),('A',False)]if a.mode=='control'else [(x,True)for x in 'ABSSBA'])
for i,(arm,probe) in enumerate(sequence):
 label=f'{a.mode}-{i}-{arm}';out=P/(label+'.json');assert not out.exists()
 wait_nominal(P/(label+'-cooldown.json'));preflight(18)
 env=['--env','SLOTSTREAM_MODEL_LOCK_PATH='+str(inner),'--env','DYLD_INSERT_LIBRARIES='+ (str(P/'compile_observer.dylib')if probe else '')]
 if probe:env+=['--env','Q2_COMPILE_TRACE='+str(P/(label+'-compile.jsonl'))]
 if arm in 'AB':
  cmd=[str(P/('build-'+arm)/'candidate/slotstream'),'q2-profile','--fixture',str(fixture),'--output',str(out),'--memory-gb','15','--rounds',str(rounds)]
  if validation:cmd+=['--validate']
 else:
  cmd=[str(P/'upstream/full-cycle'),str(P/'upstream/splash.metallib'),str(model),'--prompt-tokens',str(len(data['prompt_ids'])),'--cycles',str(rounds),'--kv-format','bf16','--state-format','fp32','--expert-memory','6094291728','--ple-memory','51200000']
  env+=['--env','Q2_DIAGNOSTIC_FIXTURE='+str(fixture)]
  if validation:env+=['--env','Q2_CYCLE_VALIDATE=1']
 if validation:env+=['--env','MTL_DEBUG_LAYER=1']
 full=[sys.executable,str(P/'quiet_guarded_run.py'),'--label',label,'--budget','15','--timeout','600',*env,'--',*cmd]
 print('START',label,'probe',probe,flush=True);monitor=None
 with(P/(label+'-launcher.log')).open('x')as log,(P/(label+'-frequency.jsonl')).open('x')as freq,(P/(label+'-frequency.stderr')).open('x')as ferr:
  if not validation:monitor=subprocess.Popen([str(R/'.build/native-monitor/macmon'),'pipe','-s','3300','-i','200','--soc-info'],stdout=freq,stderr=ferr,start_new_session=True)
  child=subprocess.Popen(full,cwd=R,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:rc=child.wait(timeout=660)
  finally:
   try:
    if child.poll()is None:terminate_child_tree(child)
   finally:
    if monitor and monitor.poll()is None:
     try:os.killpg(monitor.pid,signal.SIGTERM)
     except ProcessLookupError:pass
     try:monitor.wait(timeout=5)
     except subprocess.TimeoutExpired:
      try:os.killpg(monitor.pid,signal.SIGKILL)
      except ProcessLookupError:pass
      monitor.wait(timeout=5)
 guard=json.loads((P/(label+'.observer.json')).read_text());event=dict(label=label,arm=arm,probe=probe,exit_code=rc,command=full,eligible=not guard['external_build_samples']and not guard['paging']and guard['thermal_before']==guard['thermal_after']==0 and guard['peak_combined_bytes']<=15e9 and rc==0)
 events.append(event);ledger.write_text(json.dumps(events,indent=2));assert rc==0
 if arm in 'AB':
  d=json.loads(out.read_text());assert d['complete']and d['plan']['pool_slots']==4067
  rows=[row for rd in d['rounds']for row in rd['steps']]
 else:
  rows=[];guesses={};selected={};rds=[];prefills={};slots=None
  for line in(P/(label+'.log')).read_text().splitlines():
   x=line.split()
   if not x:continue
   if x[0]=='CONFIG':slots=int(dict(s.split('=',1)for s in x[1:])['slots'])
   elif x[0]=='CLOCK':event['source_clock_mach_ns']=int(x[1]);event['source_clock_steady_ns']=int(x[2])
   elif x[0]=='PREFILL':prefills[int(x[1])]=dict(prefill_start_ns=round(float(x[2])*1e9),prefill_end_ns=round(float(x[3])*1e9),prefill_records=int(x[4]),prefill_adopted=int(x[5]),expert_cache_reset=True)
   elif x[0]in('DRAFT','SELECTED'):(guesses if x[0]=='DRAFT'else selected)[(int(x[1]),int(x[2]))]=list(map(int,x[3:]))
   elif x[0]=='ROUND':rds.append(dict(round=int(x[1]),seconds=float(x[2])))
   elif x[0]=='ROW':
    assert len(x)==(16 if validation else 15),(len(x),x)
    row=dict(zip(['round','step','width','kept'],map(int,x[1:5])))
    row.update(zip(['start','prepared','submitted','end','gpu_seconds','host_seconds'],map(float,x[5:11])))
    row.update(zip(['records_read','records_adopted','read_bytes','layer_loads'],map(int,x[11:15])))
    row.update(seconds=row['end']-row['start'],start_ns=round(row['start']*1e9),end_ns=round(row['end']*1e9),records_fetched=row['records_read']-row['records_adopted'])
    if validation:row['logits_sha256']=x[15]
    rows.append(row)
  assert slots==4067
  for row in rows:row.update(actual_guesses=guesses[(row['round'],row['step'])],actual_selected=selected[(row['round'],row['step'])])
  for rd in rds:rd.update(prefills[rd['round']]);rd['steps']=[r for r in rows if r['round']==rd['round']];rd['start_ns']=rd['steps'][0]['start_ns'];rd['end_ns']=rd['steps'][-1]['end_ns']
  d=dict(complete=True,slots=slots,rounds=rds);out.write_text(json.dumps(d,indent=2))
 assert len(rows)==rounds*24
 for row in rows:
  step=data['steps'][row['step']];assert row['width']==len(step['tokens'])and row['kept']==step['kept'];assert len(row['actual_guesses'])==7 and len(row['actual_selected'])==step['kept'];assert all(0<=t<248320 for t in row['actual_guesses']+row['actual_selected'])
 if not validation:
  ref=json.loads((P/('validation-'+str('ABS'.index(arm))+'-'+arm+'.json')).read_text())['rounds'][0]['steps']
  for row in rows:
   for k in ['actual_guesses','actual_selected']:assert row[k]==ref[row['step']][k],(label,row['round'],row['step'],k)
 if probe:
  tr=[json.loads(s)for s in(P/(label+'-compile.jsonl')).read_text().splitlines()];assert not tr[0]['overflow']and all(tr[0][k]for k in ['library_hook','pipeline_hook','descriptor_hook']);assert len(tr)-1==tr[0]['count']and all(r['done']and r['ok']for r in tr[1:]);event['compile_calls']=tr[0]['count']
 event['checks_passed']=True;event['rounds']=[dict(round=rd['round'],seconds=rd['seconds'],prefill_seconds=(rd['prefill_end_ns']-rd['prefill_start_ns'])/1e9,prefill_records=rd['prefill_records'],cycle_seconds=sum(r['seconds']for r in rd['steps']),demand=sum(r['records_fetched']for r in rd['steps']),adopted=sum(r['records_adopted']for r in rd['steps']))for rd in d['rounds']]
 ledger.write_text(json.dumps(events,indent=2));print('END',label,event['eligible'],event['rounds'],flush=True)
print('PROTOCOL FINISHED',flush=True)
