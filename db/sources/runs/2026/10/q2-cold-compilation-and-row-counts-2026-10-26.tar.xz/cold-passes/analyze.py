from pathlib import Path
import json,statistics,fcntl,os
P=Path(__file__).resolve().parent
lock=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
def union_ns(pairs):
 total=0;last=None
 for s,e in sorted(pairs):
  if last is None:last=[s,e]
  elif s>last[1]:total+=last[1]-last[0];last=[s,e]
  else:last[1]=max(last[1],e)
 return (total+(last[1]-last[0]if last else 0))/1e9
def inside(rows,start,end):
 rs=[r for r in rows if r['start_ns']<end and r['end_ns']>start]
 return dict(count=len(rs),calls_wall_sum=sum(max(0,min(r['end_ns'],end)-max(r['start_ns'],start))for r in rs)/1e9,calls_wall_union=union_ns((max(r['start_ns'],start),min(r['end_ns'],end))for r in rs),library_count=sum(r['kind']==0 for r in rs),pipeline_count=sum(r['kind']!=0 for r in rs))
result=dict(scope='Fixed first24passes; source arena reservation differs; CPU creation intervals can overlap GPU/reads. Report unions, not exposed GPU idle or additive request attribution.',arms=[])
for event in json.loads((P/'timing-ledger.json').read_text()):
 name=event['label'];d=json.loads((P/(name+'.json')).read_text());tr=[json.loads(s)for s in(P/(name+'-compile.jsonl')).read_text().splitlines()][1:];delta=event.get('source_clock_mach_ns',0)-event.get('source_clock_steady_ns',0)
 arm=dict(label=name,arm=event['arm'],eligible=event['eligible'],source_clock_offset_ns=delta,rounds=[])
 for rd in d['rounds']:
  bounds=lambda s,e:inside(tr,s+delta,e+delta)
  row=dict(round=rd['round'],seconds=rd['seconds'],prefill_seconds=(rd['prefill_end_ns']-rd['prefill_start_ns'])/1e9,prefill_records=rd['prefill_records'],required=sum(r['records_fetched']+r['records_adopted']for r in rd['steps']),fetched=sum(r['records_fetched']for r in rd['steps']),adopted=sum(r['records_adopted']for r in rd['steps']),compile=bounds(rd['start_ns'],rd['end_ns']),prefill_compile=bounds(rd['prefill_start_ns'],rd['prefill_end_ns']),steps=[])
  for s in rd['steps']:
   row['steps'].append(dict(step=s['step'],width=s['width'],seconds=s['seconds'],required=s['records_fetched']+s['records_adopted'],compile=bounds(s['start_ns'],s['end_ns']),**{k:s[k]for k in ['draft_seconds','verify_seconds','sample_seconds','commit_seconds']if k in s}))
  arm['rounds'].append(row)
 arm['logical_misses_repeat']=len(set(r['required']for r in arm['rounds']))==1
 result['arms'].append(arm)
result['clean']=all(a['eligible']for a in result['arms']);result['logical_misses_repeat']=all(a['logical_misses_repeat']for a in result['arms'])
controls=json.loads((P/'control-ledger.json').read_text());control=dict(clean=all(e['eligible']for e in controls),rounds=[])
for rnd in range(3):
 times=[e['rounds'][rnd]['seconds']for e in controls];ratios=[times[1]/times[0],times[2]/times[3]];pooled=(times[1]+times[2])/(times[0]+times[3]);control['rounds'].append(dict(round=rnd,times=times,ratios=ratios,pooled=pooled,within_two_percent=all(abs(v-1)<=.02 for v in ratios+[pooled])))
control['passed']=control['clean']and all(r['within_two_percent']for r in control['rounds']);result['control']=control
(P/'analysis.json').write_text(json.dumps(result,indent=2))
for a in result['arms']:
 print(a['label'],'clean',a['eligible'],'logical',a['logical_misses_repeat'])
 for r in a['rounds']:print(' ROUND',r['round'],'prefill',round(r['prefill_seconds'],5),'cycles',round(r['seconds'],5),'misses',r['required'],'compile',r['compile'],'prefillcompile',r['prefill_compile'],'FIRST',r['steps'][0])
print('CONTROL',json.dumps(control));print('CLEAN',result['clean'])
