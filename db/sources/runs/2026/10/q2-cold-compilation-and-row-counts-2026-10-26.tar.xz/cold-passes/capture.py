from pathlib import Path
import json,sys,subprocess,fcntl,os,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
sys.path.insert(0,str(R/'.build/native-q2-20261021'));from thermal import wait_nominal
lock=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
inner=P/'capture-inner.lock';os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(inner)
assert not(P/'capture.json').exists()
wait_nominal(P/'capture-cooldown.json');preflight(18)
cmd=[sys.executable,str(P/'quiet_guarded_run.py'),'--label','capture','--budget','15','--timeout','600','--env','SLOTSTREAM_MODEL_LOCK_PATH='+str(inner),'--env','SLOTSTREAM_Q2_COST_TRACE='+str(P/'capture-trace.jsonl'),'--env','DYLD_INSERT_LIBRARIES='+str(P/'compile_observer.dylib'),'--env','Q2_COMPILE_TRACE='+str(P/'capture-compile.jsonl'),'--',str(P/'build-A/candidate/slotstream'),'smart-dflash-check','--native-read-ahead','on','--method','q2','--model','smart-q2','--memory-gb','15','--max-context','8192','--cases',str(P/'capture-cases.json'),'--output',str(P/'capture.json')]
with(P/'capture-launcher.log').open('x')as f:r=subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT)
assert r.returncode==0
run=json.loads((P/'capture.json').read_text())['runs'][0];traces=[json.loads(s)for s in(P/'capture-trace.jsonl').read_text().splitlines()];assert len(traces)==1
trace=traces[0];assert trace['prompt_ids']==run['prompt_ids']and not trace['truncated']and len(run['tokens'])==384
steps=[];pos=len(run['prompt_ids'])
for c in trace['cycles'][:24]:
 assert len(c['input'])==c['chosen']+1 and 1<=c['kept']<=len(c['input'])
 steps.append(dict(position=pos,tokens=c['input'],kept=c['kept']));pos+=c['kept']
assert len(steps)==24
fixture=dict(prompt_ids=run['prompt_ids'],output_ids=run['tokens'],steps=steps,selection='First24actualverificationpassesbyordinal;frozenbeforetiming',capture_source_sha256=hashlib.sha256((P/'capture-trace.jsonl').read_bytes()).hexdigest())
(P/'first-24.json').write_text(json.dumps(fixture,indent=2))
g=json.loads((P/'capture.observer.json').read_text());(P/'capture-result.json').write_text(json.dumps(dict(command=cmd,passed=True,diagnostic_only=True,steps=24,widths=[len(s['tokens'])for s in steps],kept=[s['kept']for s in steps],guard_clean=not g['external_build_samples']and not g['paging']and g['thermal_before']==g['thermal_after']==0),indent=2));print('Captured first24passes, fixture frozen',flush=True)
