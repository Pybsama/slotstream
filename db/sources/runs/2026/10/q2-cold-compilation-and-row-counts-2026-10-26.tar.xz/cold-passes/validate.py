from pathlib import Path
import json
P=Path(__file__).resolve().parent;result=dict(passed=True,engines=[],scope='Fresh own-engine full-logit references; all three rounds reset expert metadata and repeat the identical first24 actual target inputs and retained prefixes. Full hashes are validation only. NativeA/B must match exactly. Cross-engine arithmetic is not claimed bit-identical.')
refs={}
for i,arm in enumerate('ABS'):
 name=f'validation-{i}-{arm}';d=json.loads((P/(name+'.json')).read_text());rds=d['rounds'];ref=rds[0]['steps'];refs[arm]=ref;assert len(rds)==3 and len(ref)==24
 mismatches=[]
 for rd in rds:
  for row in rd['steps']:
   for k in ['logits_sha256','actual_guesses','actual_selected']:
    if row[k]!=ref[row['step']][k]:mismatches.append([rd['round'],row['step'],k])
 logical=[sum(r['records_fetched']+r['records_adopted']for r in rd['steps'])for rd in rds]
 g=json.loads((P/(name+'.observer.json')).read_text());result['engines'].append(dict(arm=arm,mismatches=mismatches,logical_required_misses=logical,logical_misses_repeat=len(set(logical))==1,prefill_records=[rd['prefill_records']for rd in rds],metal_validation=True,peak_gb=g['peak_combined_bytes']/1e9,exit_code=g['exit_code'],guard_clean=not g['external_build_samples']and not g['paging']and g['thermal_before']==g['thermal_after']==0))
result['ab_mismatches']=[[a['step'],k]for a,b in zip(refs['A'],refs['B'])for k in ['logits_sha256','actual_guesses','actual_selected']if a[k]!=b[k]]
result['passed']=not result['ab_mismatches']and all(not r['mismatches']and r['logical_misses_repeat']and r['exit_code']==0 for r in result['engines'])
(P/'validation-result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2));assert result['passed']
