from pathlib import Path
import json,shutil,difflib
P=Path(__file__).resolve().parent;R=P.parents[1];D=R/'.build/q2-adaptive-decisions-20261026';F=R/'.build/q2-full-cycle-20261025';Q=R/'.build/q2-aligned-forecast-request-20261026'
assert not(P/'plan.json').exists()
base={n:(D/'source-A'/n).read_text()for n in json.loads((D/'A-paths.json').read_text())}
n='Sources/Slotstream/DFlashGenerate.swift';s=base[n];s=s.replace('            let context: Int\n','            let context: Int\n            let input: [Int]\n            let kept: Int\n',1);s=s.replace('CostCycle(cycle: stats.verifyPasses - 1, context: traceContext,','CostCycle(cycle: stats.verifyPasses - 1, context: traceContext, input: input, kept: kept.count,',1);base[n]=s
s=(R/'.build/q2-request-profile-20261025/SmartDFlashCommand-request-clock.swift').read_text();base['Sources/slotstream-cli/SmartDFlashCommand.swift']=s
s=(F/'Q2ProfileCommand.swift').read_text();s=s.replace('                    model.beginDraftCapture()','''                    model.pool.unpinAll()
                    try model.pool.diagnosticDiscardResidency()
                    let prefillStarted=RuntimeClock.now()
                    let prefillFetched=model.pool.recordsFetched
                    model.beginDraftCapture()''',1)
s=s.replace('                    var rows:[[String:Any]]=[]','''                    let prefillEnded=RuntimeClock.now()
                    let prefillRecords=model.pool.recordsFetched-prefillFetched
                    var rows:[[String:Any]]=[]''',1)
s=s.replace('reports.append(["round":round,"start_ns":requestStart,','reports.append(["round":round,"prefill_start_ns":prefillStarted,"prefill_end_ns":prefillEnded,"prefill_records":prefillRecords,"expert_cache_reset":true,"start_ns":requestStart,',1)
s=s.replace('Fresh','Fresh');base['Sources/slotstream-cli/Q2ProfileCommand.swift']=s
copy=json.loads((Q/'candidate-identity.json').read_text())['source'];old=json.loads((Q/'baseline-identity.json').read_text())['source'];changes=[n for n,h in copy.items()if old[n]!=h and n!='Sources/slotstream-cli/Q2ProfileCommand.swift'];assert len(changes)==7
for a in ['A','B']:
 files=base.copy()
 if a=='B':files.update({n:(Q/'candidate-source'/n).read_text()for n in changes})
 for n,s in files.items():
  f=P/('source-'+a)/n;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(s)
 (P/(a+'-paths.json')).write_text(json.dumps(list(files),indent=2));(P/(a+'.patch')).write_text(''.join(''.join(difflib.unified_diff((R/n).read_text().splitlines(True),s.splitlines(True),fromfile='a/'+n,tofile='b/'+n))for n,s in files.items()))
shutil.copy2(D/'build.py',P/'build.py');shutil.copy2(D/'quiet_guarded_run.py',P/'quiet_guarded_run.py')
c=json.loads((Q/'cases.json').read_text())[0];c['id']='cold-first';(P/'capture-cases.json').write_text(json.dumps([c],indent=2))
(P/'plan.json').write_text(json.dumps(dict(purpose='Isolate first cold Q2 passes: actual one-time compilation, repeated execution and expert-cache work, after clean first-request regression and rejected prepared-cost omission.',capture='One original384-token firstrequest using v68 plus bounded decision/input trace and requesttimestamps. Capture-only, no speedclaim. Retain exact targetinputs and keptprefixes for first24verificationpasses, selected by ordinal before looking at timing. Do not substitute fastest/slowest passes. Float/confidence/sampler unchanged.',fixed='NativeA and copy-onlyB add only same diagnosticCLI and disabled decisiontrace. PinnedSplash1482f6b adds only expertmetadata reset and fullcycleinstrument. Before everyround clear expertresidency and retirepredictions, preserveallocatedslots. Re-prefill identicalprompt then replay first24actualinput/width/kept tuples with realdraft,target,greedy,rollback/commit. Three rounds perprocess; firstprocess-use pipelines versus reusedpipelines, all with expertcachecleared beforeprefill. OSfilecache,embeddings/PLE and compiledpipelines are not reset and must not be called all-caches-cold. Source/native routes may differ; check ownreferences and reportrequiredmisscounts.',probe='Bounded synchronous Metal library/pipeline creation observer, labels and CPUwall intervals only, no read trace or GPUcounterinjection. Counts/bytes validated with small genuinekernel selfcheck. Compilecall durations may overlapGPU/reads; never sum them as exposedrequesttime. Controlled reset/work comparison and timestamp intersections required. Add symmetric trace-disabled sensitivity control if probe timing is used quantitatively.',memory='15GB physical,>=18GBpreflight,>=1GBheadroom,4067slots, native8192context,sourceexistingboundedfixturearena; BF16activationKV,FP32state. No claimmatchedsourcecontextreservation. Oneglobalmodelreservation acrosswholeprotocol. No heavy builds/analysis duringruns. NoGPUspin/priority/power changes. Any paging/thermal/externalbuild disqualifies timing aggregate.',validation='Fresh nativeA/B full-logit/proposal/selection references onfirst24steps; ownSplash fullreference. Allrepeatedrounds must matchownreference. Assertcache-reset logicalrequiredmisscounts repeat withinengine, report where read-ahead adoption differs. Metadata reset preserves storage and existingcheckedownership. No candidateoptimization/default/Fastchange.',limits='Diagnostic firstpass study, not new warmed parity claim. First-request failures from priorprotocol stand. Existingsemanticqualitylimits remain. Investigate attributable preparation/read/feedback differences before anotherfix.'),indent=2))
print('Prepared capture and controlled expert-cache reset harnesses')
