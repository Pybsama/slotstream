from pathlib import Path
import json,hashlib
P=Path(__file__).resolve().parent
paths=[P/n for n in ['plan.json','capture.py','capture-cases.json','first-24.json','run.py','validate.py','quiet_guarded_run.py','build.py','build_upstream.py','prepare.py','prepare_upstream.py','compile_observer.mm','compile_observer.dylib','observer-check-result.json']]
for arm in 'AB':
 assert json.loads((P/(arm+'-restoration.json')).read_text())['sources_exact']
 paths.extend(p for p in(P/('source-'+arm)).rglob('*')if p.is_file());paths.extend(P/('build-'+arm)/'candidate'/n for n in ['slotstream','mlx.metallib','build-identity.json','build-source.tar.gz'])
paths.extend(Path(n)for n in json.loads((P/'upstream/identity.json').read_text()))
assert not(P/'frozen-identity.json').exists();(P/'frozen-identity.json').write_text(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in paths},indent=2));print('Frozen',len(paths),'inputs/artifacts')
