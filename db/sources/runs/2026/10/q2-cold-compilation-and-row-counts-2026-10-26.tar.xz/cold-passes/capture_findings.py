from pathlib import Path
import json
P=Path(__file__).resolve().parent
request=json.loads((P/'capture.json').read_text())['runs'][0];trace=json.loads((P/'capture-trace.jsonl').read_text());rows=[json.loads(s)for s in(P/'capture-compile.jsonl').read_text().splitlines()][1:]
s=request['request_started_mach_ns'];e=request['request_ended_mach_ns'];inside=[r for r in rows if s<=r['start_ns']and r['end_ns']<=e]
result=dict(request_seconds=request['elapsed_seconds'],prefill_seconds=request['stats']['prefillSeconds'],decode_seconds=request['stats']['decodeSeconds'],passes=request['stats']['verifyPasses'],anchors=request['stats']['adaptiveDraftDepths'].count(0),first24widths=[c['chosen']+1 for c in trace['cycles'][:24]],first4cycles=[{k:c[k]for k in ['cycle','chosen','seconds','prepared','misses','hits']}for c in trace['cycles'][:4]],metal_creation_calls=len(inside),source_library_calls=sum(r['kind']==0 for r in inside),pipeline_calls=sum(r['kind']!=0 for r in inside),creation_wall_seconds=sum(r['end_ns']-r['start_ns']for r in inside)/1e9,scope='One actual first-request capture, with decision tracing and the compiler observer. Captures exact target work for fixed replay. It is not a new uninstrumented product-speed measurement, and CPU creation wall time can overlap GPU/reads.')
(P/'capture-findings.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
