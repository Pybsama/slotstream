from pathlib import Path
import subprocess,sys,fcntl,os,json,hashlib,shutil
P=Path(__file__).resolve().parent;R=P.parents[1];D=P/'upstream'
W=Path('/var/folders/d4/t1c8ltbx5s3_11cs9y6gjh8m0000gp/T/slotstream-splash-host-ugnf26pi/source')
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
with open(f'/tmp/slotstream-model-{os.getuid()}.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(P/'upstream-build-inner.lock');preflight(10)
 common=['xcrun','-sdk','macosx','clang++','-std=c++20','-O2','-mmacosx-version-min=26.4','-I'+str(D/'include'),'-I'+str(W/'runtime'),'-I'+str(W/'dev'),'-I'+str(W/'runtime/metal')]
 commands=[common+['-c',str(D/'ExpertStore.cpp'),'-o',str(D/'ExpertStore.o')],common+['-DSPLASH_RUNTIME_INSTRUMENTATION','-c',str(D/'Runtime.cpp'),'-o',str(D/'Runtime.o')],common+['-fobjc-arc','-DSPLASH_BACKEND_INSTRUMENTATION','-c',str(D/'MetalBackend.mm'),'-o',str(D/'MetalBackend.o')],common+['-fobjc-arc',str(D/'full_cycle.mm'),str(D/'Runtime.o'),str(D/'MetalBackend.o'),str(D/'ExpertStore.o'),str(W/'build/engine/libsplash.a'),'-framework','Foundation','-framework','Metal','-framework','IOKit','-framework','IOSurface','-o',str(D/'full-cycle')]]
 ledger=[]
 for i,cmd in enumerate(commands):
  with(D/f'build-{i}.log').open('w')as log:r=subprocess.run(cmd,cwd=W,stdout=log,stderr=subprocess.STDOUT)
  ledger.append(dict(command=cmd,exit_code=r.returncode));(D/'build-ledger.json').write_text(json.dumps(ledger,indent=2))
  if r.returncode:raise SystemExit(r.returncode)
 shutil.copy2(R/'.build/smart-dflash-eval/upstream/splash-1.4.0-arm64-macos26/engine/splash.metallib',D/'splash.metallib')
 paths=[D/'ExpertStore.cpp',D/'include/model/ExpertStore.hpp',D/'ExpertStore.o',D/'Runtime.o',D/'MetalBackend.o',D/'Runtime.cpp',D/'MetalBackend.mm',D/'full_cycle.mm',D/'include/model/RuntimeInstrumentation.hpp',D/'full-cycle',D/'splash.metallib',W/'build/engine/libsplash.a']
 (D/'identity.json').write_text(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in paths},indent=2));print('Built full-cycle diagnostic')
