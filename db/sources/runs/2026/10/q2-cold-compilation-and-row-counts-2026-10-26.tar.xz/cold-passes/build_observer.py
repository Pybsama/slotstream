from pathlib import Path
import subprocess,fcntl,os,sys,json,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1];sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
lock=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(P/'observer-inner.lock');preflight(7)
flags=['xcrun','clang++','-std=c++17','-O2','-fno-objc-arc','-framework','Foundation','-framework','Metal']
cmds=[flags+['-dynamiclib',str(P/'compile_observer.mm'),'-o',str(P/'compile_observer.dylib')],flags+[str(P/'compile_check.mm'),'-o',str(P/'compile-check')]]
for i,cmd in enumerate(cmds):
 r=subprocess.run(cmd,capture_output=True,text=True);(P/f'observer-build-{i}.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stderr
base={k:v for k,v in os.environ.items()if not k.startswith(('SLOTSTREAM_','DYLD_','Q2_','MLX_'))}
for enabled in [False,True]:
 env=base.copy()
 if enabled:env.update(DYLD_INSERT_LIBRARIES=str(P/'compile_observer.dylib'),Q2_COMPILE_TRACE=str(P/'observer-check.jsonl'))
 r=subprocess.run([str(P/'compile-check')],env=env,capture_output=True,text=True);(P/f'observer-check-{int(enabled)}.log').write_text(r.stdout+r.stderr);assert r.returncode==0 and 'EXACT_PASS'in r.stdout
rows=[json.loads(s)for s in(P/'observer-check.jsonl').read_text().splitlines()];assert rows[0]['count']==3 and not rows[0]['overflow']and all(rows[0][k]for k in ['library_hook','pipeline_hook','descriptor_hook']);assert [r['kind']for r in rows[1:]]==[0,1,2];assert all(r['done']and r['ok']and r['start_ns']<=r['end_ns']for r in rows[1:])
(P/'observer-check-result.json').write_text(json.dumps(dict(passed=True,commands=cmds,rows=3,output_exact=True,ownership='Compiled without ARC so wrappers forward retained return pointers without ownership changes',files={n:hashlib.sha256((P/n).read_bytes()).hexdigest()for n in ['compile_observer.mm','compile_observer.dylib','compile_check.mm','compile-check']}),indent=2));print('Compilation observer hooks and genuine kernel result passed')
