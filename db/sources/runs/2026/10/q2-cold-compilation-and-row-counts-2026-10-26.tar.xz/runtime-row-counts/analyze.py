from pathlib import Path
import json,statistics,hashlib
P=Path(__file__).resolve().parent
ledger=json.loads((P/'fourway-15-ledger.json').read_text());assert ''.join(e['arm']for e in ledger)=='ABCSSCBA'
allruns=[json.loads((P/(e['label']+'.json')).read_text())for e in ledger]
result=dict(clean=all(e['eligible']for e in ledger),arms=[],tasks=[],first_requests=[],scope='Uninstrumented four-way actual complete requests. Same prompts/precision/requested context/cache/budgets, but own automatic choices and generated text. Source output token IDs unavailable; do not infer token equivalence. All arms and exclusions preserved.')
for e,d in zip(ledger,allruns):
 rows=[]
 for r in d['runs']:
  s=r.get('stats');native=s is not None
  row=dict(id=r['id'],total=r['elapsed_seconds'],prefill=s['prefillSeconds']if native else r['timings']['prompt_ms']/1000,decode=s['decodeSeconds']if native else r['timings']['predicted_ms']/1000,text_sha256=hashlib.sha256(r['text'].encode()).hexdigest()if'text'in r else None)
  if native:row.update(passes=s['verifyPasses'],rows=s['decodeModelTokens'],anchors=s['adaptiveDraftDepths'].count(0),accepted=s['acceptedDrafts'],prepared=s.get('dflashPreparationCycles',0),calibration_before=s.get('dflashCalibrationCyclesBefore'),calibration_after=s.get('dflashCalibrationCyclesAfter'),peak_gb=s['peakMemoryGB'])
  else:row.update(source_metrics=r.get('metrics'),peak_gb=d['peak_combined_bytes']/1e9)
  rows.append(row)
 result['arms'].append(dict(label=e['label'],arm=e['arm'],eligible=e['eligible'],runs=rows))
for t in range(4):
 times=[d['runs'][t]['elapsed_seconds']for d in allruns];C_A=[times[2]/times[0],times[5]/times[7]];C_B=[times[2]/times[1],times[5]/times[6]];C_S=[times[2]/times[3],times[5]/times[4]];B_A=[times[1]/times[0],times[6]/times[7]];B_S=[times[1]/times[3],times[6]/times[4]]
 row=dict(id=allruns[0]['runs'][t]['id'],times=times,C_over_A=C_A,C_over_B=C_B,C_over_S=C_S,B_over_A=B_A,B_over_S=B_S,pooled=dict(C_over_A=(times[2]+times[5])/(times[0]+times[7]),C_over_B=(times[2]+times[5])/(times[1]+times[6]),C_over_S=(times[2]+times[5])/(times[3]+times[4]),B_over_A=(times[1]+times[6])/(times[0]+times[7]),B_over_S=(times[1]+times[6])/(times[3]+times[4])),targeted_fix_both_orders_improve=all(v<1 for v in C_A+C_B),within_five_percent_source_both_orders=all(v<=1.05 for v in C_S))
 (result['tasks']if t>=2 else result['first_requests']).append(row)
alltasks=result['first_requests']+result['tasks']
result['targeted_fix_retention_gate']=result['clean']and all(v<=.95 for v in alltasks[0]['C_over_B'])and all(v<=1.02 for r in alltasks for v in r['C_over_A'])and all(all(v<=1.02 for v in r['C_over_B'])and r['pooled']['C_over_B']<=1.01 for r in alltasks[1:])
result['source_timing_gate']=result['clean']and all(r['within_five_percent_source_both_orders']for r in alltasks)
result['product_ready']=False;result['quality_limits']='Known Fast recall and Q2 strict-format failures unchanged. Passing token-count/termination/memory/integration checks does not imply semantic quality or app readiness.'
(P/'analysis.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items()if k!='arms'},indent=2))
