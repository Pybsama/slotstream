from pathlib import Path
import fcntl,hashlib,io,json,os,re,sys,tarfile
P=Path(__file__).resolve().parent;R=P.parents[1];N=R/'.build/q2-cold-passes-20261026'
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
lock=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(P/'archive-inner.lock');preflight(4)
sha=lambda b:hashlib.sha256(b).hexdigest();allowed={'.py','.swift','.cpp','.h','.hpp','.mm','.json','.jsonl','.log','.stderr','.txt','.patch'};files={}
for prefix,root in [('cold-passes',N),('runtime-row-counts',P)]:
 for f in root.rglob('*'):
  if not f.is_file()or '__pycache__'in f.parts or f.suffix not in allowed or f.name.startswith('archive-receipt')or(f.name.startswith('archive')and f.suffix=='.log'):continue
  files[prefix+'/'+str(f.relative_to(root))]=f
for n,f in [('LICENSE',R/'LICENSE'),('splash-NOTICE.txt',R/'Licenses/splash-NOTICE.txt'),('MLX-LICENSE.txt',R/'.build/checkouts/mlx-swift/LICENSE'),('THIRD_PARTY_NOTICES.md',R/'THIRD_PARTY_NOTICES.md'),('v68-identity.json',R/'.build/native-replay-20261023/v68/build-identity.json'),('prior-preparation-analysis.json',R/'.build/q2-preparation-cost-20261026/analysis.json'),('prior-decision-findings.json',R/'.build/q2-adaptive-decisions-20261026/findings.json'),('MLX-custom_kernel.cpp',R/'.build/checkouts/mlx-swift/Source/Cmlx/mlx/mlx/backend/metal/custom_kernel.cpp'),('MLX-metal_kernel.cpp',R/'.build/checkouts/mlx-swift/Source/Cmlx/mlx/mlx/backend/common/metal_kernel.cpp')]:files['reference/'+n]=f
pattern=re.compile(rb'(?:ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{25,}|sk-(?:proj-)?[A-Za-z0-9_-]{30,}|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----)');manifest={}
for n,f in files.items():
 b=f.read_bytes();assert not pattern.search(b),n;manifest[n]=dict(bytes=len(b),sha256=sha(b))
dest=R/'db/sources/runs/2026/10/q2-cold-compilation-and-row-counts-2026-10-26.tar.xz';assert not dest.exists()
with tarfile.open(dest,'w:xz',preset=3)as t:
 for n,f in sorted(files.items()):t.add(f,arcname=n,recursive=False)
 data=json.dumps(manifest,indent=2).encode();info=tarfile.TarInfo('archive-manifest.json');info.size=len(data);t.addfile(info,io.BytesIO(data))
seen={}
with tarfile.open(dest,'r|xz')as t:
 for m in t:
  b=t.extractfile(m).read()
  if m.name=='archive-manifest.json':assert json.loads(b)==manifest
  else:seen[m.name]=dict(bytes=len(b),sha256=sha(b))
assert seen==manifest and dest.stat().st_size<100_000_000
receipt=dict(path=str(dest.relative_to(R)),files=len(manifest),bytes=dest.stat().st_size,sha256=sha(dest.read_bytes()),readback_verified=True,credential_pattern_matches=0,excluded='Executables, libraries, objects, model weights, pycache and live archive output. Changed sources, patches, exact identities, all arms and failures, probes, checks, guards, references and restoration included.')
(P/'archive-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt,indent=2))
