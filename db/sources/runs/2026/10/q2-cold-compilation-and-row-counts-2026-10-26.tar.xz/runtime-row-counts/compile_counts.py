from pathlib import Path
import json,collections
P=Path(__file__).resolve().parent;N=P.parent/'q2-cold-passes-20261026';families=['slotstream_gguf_decode_','slotstream_q2_ple_conv','slotstream_q2_attention_prepare'];result=[]
for name,root,trace,out in [('nativeA',N,'timing-0-A-compile.jsonl','timing-0-A.json'),('copyB',N,'timing-1-B-compile.jsonl','timing-1-B.json'),('rowCountsC',P,'fixed-compile-compile.jsonl','fixed-compile.json')]:
 rows=[json.loads(s)for s in(root/trace).read_text().splitlines()][1:];rd=json.loads((root/out).read_text())['rounds'][0];counts={}
 for family in families:
  items=[r for r in rows if family in r['name']];counts[family]=dict(total=len(items),prefill=sum(rd['prefill_start_ns']<=r['start_ns']<rd['prefill_end_ns']for r in items),first24=sum(rd['start_ns']<=r['start_ns']<rd['end_ns']for r in items),names=[r['name']for r in items])
 result.append(dict(arm=name,counts=counts))
(P/'compile-counts.json').write_text(json.dumps(dict(arms=result,scope='Counts only: each named pipeline creation is observed directly. The C run proves mechanism and exact own reference; it is not a matched timing arm against A/B.'),indent=2));print(json.dumps([{**r,'counts':{k:{f:v for f,v in val.items()if f!='names'}for k,val in r['counts'].items()}}for r in result],indent=2))
