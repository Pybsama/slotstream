from pathlib import Path
import shutil,json,difflib
P=Path(__file__).resolve().parent;R=P.parents[1];N=R/'.build/q2-cold-passes-20261026';Q=R/'.build/q2-aligned-forecast-request-20261026'
paths=json.loads((Q/'runtime-paths.json').read_text()) if (Q/'runtime-paths.json').exists()else [str(p.relative_to(Q/'candidate-source'))for p in(Q/'candidate-source').rglob('*')if p.is_file()and p.suffix in ['.swift','.cpp','.h']and 'Q2Profile'not in p.name]
assert len(paths)==7,paths
source={n:(Q/'candidate-source'/n).read_text()for n in paths}
for n in ['Sources/Slotstream/Q2Attention.swift','Sources/Slotstream/Q2PLE.swift','Sources/Slotstream/Q2GGUFLinear.swift','Sources/slotstream-cli/Q2AttentionChecks.swift']:source[n]=(R/n).read_text()
source['Sources/slotstream-cli/Q2ProfileCommand.swift']=(N/'source-A/Sources/slotstream-cli/Q2ProfileCommand.swift').read_text()
source['Sources/slotstream-cli/SmartDFlashCommand.swift']=(N/'source-A/Sources/slotstream-cli/SmartDFlashCommand.swift').read_text()
def change(n,old,new):
 assert source[n].count(old)==1,(n,old);source[n]=source[n].replace(old,new)
change('Sources/Slotstream/Q2Attention.swift','("HK",hk),("S",s),("ROT",rot)','("HK",hk),("ROT",rot)')
change('Sources/Slotstream/Q2Attention.swift','        uint task=threadgroup_position_in_grid.x,tid=thread_index_in_threadgroup;','        // Token count is dispatch data, not a new Metal program.\n        uint S=q_shape[1];\n        uint task=threadgroup_position_in_grid.x,tid=thread_index_in_threadgroup;')
change('Sources/Slotstream/Q2PLE.swift','("W",width),("N",rows),("TAPS",count)','("W",width),("TAPS",count)')
change('Sources/Slotstream/Q2PLE.swift','if(c>=W || row>=N)return;','if(c>=W || row>=threads_per_grid.y)return;')
change('Sources/Slotstream/Q2GGUFLinear.swift','template: [("T", dtype), ("N", count)], grid: (count, 1, 1)','template: [("T", dtype)], grid: (count, 1, 1)')
change('Sources/Slotstream/Q2GGUFLinear.swift','if (col >= N) return;','if (col >= threads_per_grid.x) return;')
# Expand the existing independent oracle and width/state checks, without changing its arithmetic.
n='Sources/slotstream-cli/Q2AttentionChecks.swift';change(n,'    let rows=9,hq=4,hk=2,d=256,rot=64','    for rows in [1,2,3,4,5,6,7,8,9,33,84,129] {\n    let hq=4,hk=2,d=256,rot=64');change(n,'    for r in [0,1,4,8] {','    for r in [0,1,4,8] where r<rows {')
change(n,'    let value=MLXArray(vals(1024,43,128))','''    let batch=Q2Attention.prepare(q:concatenated([q,q],axis:0),k:concatenated([k,k],axis:0),
        qNorm:qw,kNorm:kw,cosine:concatenated([c,c],axis:0),sine:concatenated([s,s],axis:0))
    for b in 0..<2 {
        guard (batch.0[b..<(b+1)] .== actual.0).all().item(Bool.self),
              (batch.1[b..<(b+1)] .== actual.1).all().item(Bool.self) else {
            throw ValidationError("Q2 attention runtime row count broke batch addressing")
        }
    }
    let value=MLXArray(vals(1024,43,128))''')
source[n]=source[n].rstrip()+'\n}\n'
n='Sources/slotstream-cli/SmartDFlashCommand.swift';change(n,'            let linear = Q2GGUFLinear(bytes: bytes, format: format, rows: f.rows, columns: f.columns)','''            // Partial and non-threadgroup-aligned counts must decode exactly
            // the requested prefix without a specialized count in the shader.
            for count in Set([1,31,32,33,255,256,257,f.expected.count]).sorted() where count<=decoded.count {
                for dtype in [DType.float32,.bfloat16] {
                    let prefix=Q2GGUFLinear.decode(bytes,format:format,count:count,dtype:dtype)
                    let reference=MLXArray(Array(decoded.prefix(count))).asType(dtype)
                    guard (prefix .== reference).all().item(Bool.self) else {
                        throw ValidationError("Q2 partial decode changed with runtime count \\(count)")
                    }
                }
            }
            let linear = Q2GGUFLinear(bytes: bytes, format: format, rows: f.rows, columns: f.columns)''')
root=P/'source-C';patch=[]
for n,s in source.items():
 f=root/n;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(s);patch.extend(difflib.unified_diff((R/n).read_text().splitlines(True),s.splitlines(True),fromfile='a/'+n,tofile='b/'+n))
(P/'C-paths.json').write_text(json.dumps(list(source),indent=2));(P/'C.patch').write_text(''.join(patch))
s=(N/'build.py').read_text().replace("assert arm in ['A','B']","assert arm in ['C']");(P/'build.py').write_text(s)
shutil.copy2(N/'quiet_guarded_run.py',P/'quiet_guarded_run.py')
(P/'plan.json').write_text(json.dumps(dict(hypothesis='Three Q2 kernels specialize runtime token counts, creating new libraries during adaptive verification. Share one program across counts using existing input shape or Metal threads_per_grid; no arithmetic, precision, cache, batching-policy or Fast changes.',evidence='Cold first24 fixture: identical per-engine required misses, all native logits exact; new width3/2/1 triggers library creation even after native-projection prepared flag clears. Actual call counts/captured wall intervals are evidence; probe sensitivity and overlap limit precise exposed-time attribution.',candidate='Seven unchanged aligned-forecast changes plus Q2Attention S=q_shape[1], Q2PLE N=threads_per_grid.y and GGUF decode N=threads_per_grid.x. Native baseline and copy-only remain controls. Diagnostic CLI and expanded existing independent oracle checks only.',gates='Expanded all-format partial-prefix and BF16/FP32 checks; attention allwidths1..9,33,84,129 and batch2; PLE existing FP64/all32rollbackcuts; first24 full-logit/proposal/selection exact against frozenNativeA all3rounds. Then ABCSSCBA complete384token requests at15GB/4067slots/8192context with2warmups and code/prose. Assess firstrequest and later tasks separately. Retain only repeatable benefit without regressions, no speedparity claim from fixedwork.',environment='One heavy process/global lock;18GBpreflight,15GBphysical,1GBheadroom;preserve allarms and failures. NoGPUspin/priority/powerchanges. Compiler/filecaches not forcibly purged.'),indent=2))
print('Prepared',len(source),'files; three runtime row-count changes, seven unchanged copy changes, three diagnostic/check files')
