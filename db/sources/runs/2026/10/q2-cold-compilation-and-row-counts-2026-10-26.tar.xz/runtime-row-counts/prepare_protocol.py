from pathlib import Path
import shutil
P=Path(__file__).resolve().parent;R=P.parents[1];OLD=R/'.build/q2-preparation-cost-20261026'
for n in ['cases.json','q2_upstream_bench_io.py']:shutil.copy2(OLD/n,P/n)
s=(OLD/'request_run.py').read_text().replace('C alignedforecast plus Q2 prepared-cycle cost omission','C alignedforecast plus runtime row counts in three Q2 kernels').replace('C alone omits recurring-cost observation for actual prepared Q2 pipeline passes while retaining acceptance labels and cycle/exploration state.','C removes shader token-count specialization without changing the controller or arithmetic.')
(P/'request_run.py').write_text(s)
s=(OLD/'freeze.py').read_text().replace("'prepare_controls.py',",'').replace("'BudgetControl.swift','budget-control.log',", "'validate_candidate.py',").replace("assert 'PASS 320 observations' in(P/'budget-control.log').read_text()", "assert json.loads((P/'candidate-validation.json').read_text())['passed']").replace('controller_check_passed=True','candidate_checks_passed=True')
(P/'freeze.py').write_text(s)
