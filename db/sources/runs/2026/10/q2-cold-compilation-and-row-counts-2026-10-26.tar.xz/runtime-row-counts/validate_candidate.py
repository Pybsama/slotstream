from pathlib import Path
import json,subprocess,sys,os,fcntl,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1];N=R/'.build/q2-cold-passes-20261026';binary=P/'build-C/candidate/slotstream'
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
sys.path.insert(0,str(R/'.build/native-q2-20261021'));from thermal import wait_nominal
lock=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);inner=P/'validation-inner.lock';os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(inner)
events=[]
def run(label,args,budget,probe=False):
 wait_nominal(P/(label+'-cooldown.json'));preflight(budget+3)
 env=['--env','SLOTSTREAM_MODEL_LOCK_PATH='+str(inner),'--env','DYLD_INSERT_LIBRARIES='+(str(N/'compile_observer.dylib')if probe else '')]
 if probe:env+=['--env','Q2_COMPILE_TRACE='+str(P/(label+'-compile.jsonl'))]
 else:env+=['--env','MTL_DEBUG_LAYER=1']
 cmd=[sys.executable,str(P/'quiet_guarded_run.py'),'--label',label,'--budget',str(budget),'--timeout','600',*env,'--',str(binary),*args]
 print('START',label,flush=True)
 with(P/(label+'-launcher.log')).open('x')as f:r=subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT)
 g=json.loads((P/(label+'.observer.json')).read_text());events.append(dict(label=label,command=cmd,exit_code=r.returncode,clean=not g['external_build_samples']and not g['paging']and g['thermal_before']==g['thermal_after']==0,peak_bytes=g['peak_combined_bytes']));(P/'candidate-validation-ledger.json').write_text(json.dumps(events,indent=2));assert r.returncode==0
 print('END',label,events[-1],flush=True)
run('formats',['q2-format-check','--fixtures','bench/q2/formats.json','--policy-fixtures','bench/q2/verify-budget.json','--policy-fixtures','bench/q2/verify-budget-complete.json','--mix-fixtures','bench/q2/mix-quantization.json'],7)
run('kernels',['q2-experts-check','--pool-model','smart-q2'],7)
run('fixed-validation',['q2-profile','--fixture',str(N/'first-24.json'),'--output',str(P/'fixed-validation.json'),'--memory-gb','15','--rounds','3','--validate'],15)
ref=json.loads((N/'validation-0-A.json').read_text())['rounds'][0]['steps'];d=json.loads((P/'fixed-validation.json').read_text());bad=[]
for rd in d['rounds']:
 for row in rd['steps']:
  for k in ['logits_sha256','actual_guesses','actual_selected']:
   if row[k]!=ref[row['step']][k]:bad.append([rd['round'],row['step'],k])
assert not bad,bad
run('fixed-compile',['q2-profile','--fixture',str(N/'first-24.json'),'--output',str(P/'fixed-compile.json'),'--memory-gb','15','--rounds','3'],15,True)
d=json.loads((P/'fixed-compile.json').read_text());tr=[json.loads(s)for s in(P/'fixed-compile-compile.jsonl').read_text().splitlines()];assert not tr[0]['overflow']and all(x['done']and x['ok']for x in tr[1:]);families=['slotstream_gguf_decode_','slotstream_q2_ple_conv','slotstream_q2_attention_prepare'];counts=[]
for rd in d['rounds']:
 for row in rd['steps']:
  for k in ['actual_guesses','actual_selected']:assert row[k]==ref[row['step']][k]
 hits=[x for x in tr[1:]if rd['start_ns']<=x['start_ns']<rd['end_ns']and any(n in x['name']for n in families)]
 counts.append(dict(round=rd['round'],redundant_row_family_pipeline_creations=len(hits),names=[x['name']for x in hits]))
assert all(c['redundant_row_family_pipeline_creations']==0 for c in counts),counts
result=dict(passed=True,source_restored=json.loads((P/'C-restoration.json').read_text()),full_logit_passes=72,full_logit_mismatches=bad,compile_rounds=counts,events=events,scope='Expanded independent arithmetic, all-format prefix/partial/bf16/fp32, attention widths and batch2, allPLErollbackcuts, exact first24 frozen passes in3rounds against nativev68. Compile-count followup is mechanism verification, not ordinary timing qualification.')
(P/'candidate-validation.json').write_text(json.dumps(result,indent=2));print('ALL CANDIDATE CHECKS PASSED',flush=True)
