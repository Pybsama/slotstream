from pathlib import Path
import json,sys,shutil,hashlib,subprocess,stat
P=Path(__file__).resolve().parent;R=P.parents[1];B=R/'.build/native-replay-20261023/v68';M=R/'.build/checkouts/mlx-swift'
sys.path.insert(0,str(R/'Tools'));from optimization_build import build
rep=json.loads((P/'replacements.json').read_text());old={n:(R/n).read_bytes()for n in rep};modes={n:stat.S_IMODE((R/n).stat().st_mode)for n in rep};result={}
assert not subprocess.check_output(['git','status','--porcelain'],cwd=M,text=True).strip()
try:
 for n,f in rep.items():
  (R/n).chmod(modes[n] | stat.S_IWUSR);(R/n).write_bytes((P/f).read_bytes())
 result=build(R,P/'native-build',required_gb=10,jobs=4,wait_seconds=0);print(json.dumps({k:v for k,v in result.items()if k in ['passed','error','elapsed_seconds']}),flush=True)
finally:
 for n,b in old.items():
  (R/n).chmod(modes[n] | stat.S_IWUSR);(R/n).write_bytes(b);(R/n).chmod(modes[n])
 for n in ['slotstream','slotstream-checks','mlx.metallib','build-identity.json','build-source.tar.gz']:shutil.copy2(B/n,R/'.build/release'/n)
 status=subprocess.check_output(['git','status','--porcelain'],cwd=M,text=True).strip();assert not status,status
 (P/'restored-probe.json').write_text(json.dumps(dict(sources={n:hashlib.sha256((R/n).read_bytes()).hexdigest()for n in old},dependency_clean=True,restored_modes={n:stat.S_IMODE((R/n).stat().st_mode)for n in rep},default_binary=hashlib.sha256((R/'.build/release/slotstream').read_bytes()).hexdigest()),indent=2))
if not result.get('passed'):raise SystemExit(1)
identity=json.loads((P/'native-build/candidate/build-identity.json').read_text());name='.build/checkouts/mlx-swift/Source/Cmlx/mlx/mlx/backend/metal/eval.cpp'
assert identity['source'][name]==hashlib.sha256((P/'eval-probe.cpp').read_bytes()).hexdigest()
print('modified dependency source is bound to the diagnostic executable')
