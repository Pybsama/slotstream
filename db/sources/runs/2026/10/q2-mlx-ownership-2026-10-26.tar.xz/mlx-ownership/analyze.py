from pathlib import Path
import bisect,collections,csv,json,struct,subprocess
P=Path(__file__).resolve().parent
# Never analyze large traces while the model protocol is active.
active=subprocess.run(['pgrep','-f',str(P/'native-build/candidate/slotstream')],capture_output=True,text=True)
assert not active.stdout.strip(),active.stdout
def read(path):
    lines=path.read_text().splitlines()
    foot=dict(x.split('=',1)for x in lines[-1][2:].split())
    assert int(foot['total'])<int(foot['cap']),(path,foot)
    return list(csv.DictReader(x for x in lines if not x.startswith('#'))),foot
def union(xs):
    out=[]
    for a,b in sorted(xs):
        if b<=a:continue
        if not out or a>out[-1][1]:out.append([a,b])
        else:out[-1][1]=max(out[-1][1],b)
    return out
def inter(a,b):
    out=[];i=j=0
    while i<len(a)and j<len(b):
        lo,hi=max(a[i][0],b[j][0]),min(a[i][1],b[j][1])
        if hi>lo:out.append([lo,hi])
        if a[i][1]<b[j][1]:i+=1
        else:j+=1
    return out
def length(xs):return sum(b-a for a,b in xs)
ledger=json.loads((P/'trace-ledger.json').read_text())
assert len(ledger)==2
on=next(e for e in ledger if e['probe']);off=next(e for e in ledger if not e['probe'])
label=on['label'];d=json.loads((P/(label+'.json')).read_text());steps=d['rounds'][-1]['steps']
windows=union((r['start_ns']/1e9,r['end_ns']/1e9)for r in steps)
meta=json.loads((P/(label+'.json.mlx-host.json')).read_text())
data=(P/(label+'.json.mlx-host.bin')).read_bytes();assert len(data)==meta['rows']*80
assert 0<meta['rows']<meta['cap'] and meta['foreign_calls']==0
scale=meta['numer']/meta['denom']/1e9
fields={k:[]for k in ['total','front','primitive','between_primitive_hold','hold','between_hold_registration','registration','tail']}
branches=collections.Counter();previous_end=0;overlaps=0
for row in struct.iter_unpack('<9Q2I',data):
    times=row[:8]
    assert all(a<=b for a,b in zip(times,times[1:])) and times[0]>0,(row,)
    assert row[8]==meta['owner'] and row[9]in(0,1)and row[10]==0
    overlaps+=int(times[0]<previous_end);previous_end=max(previous_end,times[-1]);branches[row[9]]+=1
    t=[x*scale for x in times]
    fields['total'].append((t[0],t[7]))
    for name,i in [('front',0),('primitive',1),('between_primitive_hold',2),('hold',3),('between_hold_registration',4),('registration',5),('tail',6)]:fields[name].append((t[i],t[i+1]))
assert overlaps==0,overlaps
stages,sfoot=read(next(P.glob(label+'-commands.*.stages.csv')))
assert sfoot['cpu_initial']==sfoot['gpu_initial'] and sfoot['cpu_final']==sfoot['gpu_final']
reads,rfoot=read(next(P.glob(label+'-reads.*.csv')))
gpu=union((int(s['gpu_start'])/1e9,int(s['gpu_end'])/1e9)for s in stages if int(s['gpu_end'])>int(s['gpu_start'])>0)
rd=union((float(r['start']),float(r['end']))for r in reads if int(r['result'])>0)
busy=union(gpu+rd)
# Attribute the existing primitive intervals to actual observed pipeline
# assignments. This is a pipeline signature, not a C++ primitive type.
pipelines,pfoot=read(next(P.glob(label+'-commands.*.pipelines.csv')))
assignments,afoot=read(next(P.glob(label+'-commands.*.assignments.csv')))
names={p['pipeline']:p['name']for p in pipelines}
assignments=sorted((float(a['stamp']),names.get(a['pipeline'],'unknown'))for a in assignments)
stamps=[a[0]for a in assignments];busy_ends=[b for a,b in busy]
def exposed(a,b):
    i=bisect.bisect_right(busy_ends,a);overlap=0
    while i<len(busy)and busy[i][0]<b:
        overlap+=max(0,min(b,busy[i][1])-max(a,busy[i][0]));i+=1
    return max(0,b-a-overlap)
by_signature=collections.defaultdict(lambda:dict(calls=0,primitive_seconds=0,primitive_outside_gpu_and_reads_seconds=0,total_seconds=0,total_outside_gpu_and_reads_seconds=0))
for (a,b),(lo,hi) in zip(fields['primitive'],fields['total']):
    first,last=bisect.bisect_left(stamps,a),bisect.bisect_right(stamps,b)
    signature=' + '.join(dict.fromkeys(n for t,n in assignments[first:last]))or'(no pipeline assignment)'
    v=by_signature[signature];v['calls']+=1;v['primitive_seconds']+=b-a;v['primitive_outside_gpu_and_reads_seconds']+=exposed(a,b);v['total_seconds']+=hi-lo;v['total_outside_gpu_and_reads_seconds']+=exposed(lo,hi)
signature_rows=[dict(signature=k,**v)for k,v in by_signature.items()]
signature_rows.sort(key=lambda v:v['primitive_outside_gpu_and_reads_seconds'],reverse=True)
def metrics(xs,window):
    xs=inter(union(xs),window)
    return dict(union_seconds=length(xs),overlap_gpu_seconds=length(inter(xs,gpu)),overlap_reads_seconds=length(inter(xs,rd)),outside_gpu_and_reads_seconds=length(xs)-length(inter(xs,busy)))
all_metrics={name:metrics(xs,windows)for name,xs in fields.items()}
phases={}
for name in ['draft_seconds','verify_seconds','sample_seconds','commit_seconds']:
    w=[]
    for r in steps:
        lo=r['start_ns']/1e9
        for part in ['draft_seconds','verify_seconds','sample_seconds','commit_seconds']:
            hi=lo+r[part]
            if part==name:w.append((lo,hi));break
            lo=hi
    phases[name]={key:metrics(xs,union(w))for key,xs in fields.items()}
copies,cfoot=read(next(P.glob(label+'-copies.*.csv')))
ratio=on['round_seconds'][-1]/off['round_seconds'][-1]
result=dict(scope='Direct temporary MLX gpu::eval observation during the last real111-cycle round after one warmup. Intervals exclude observed GPU encoder work and successful expert reads, but this uncovered subset is not a removable-delay estimate; unrelated overlapping forecast reads can hide critical host work. Primitive includes host-side allocation/binding/dispatch. Tail includes local destruction and autorelease pool cleanup, but not later GPU completion destruction. No production speed qualification.',metadata=meta,rows_nonoverlapping=True,branches=dict(branches),environment_eligible=all(e['eligible']for e in ledger),control=dict(off_rounds=off['round_seconds'],on_rounds=on['round_seconds'],observed_ratio=ratio,within_two_percent=abs(ratio-1)<=.02),round_seconds=d['rounds'][-1]['seconds'],cycle_seconds=length(windows),gpu_union_seconds=length(inter(gpu,windows)),read_union_seconds=length(inter(rd,windows)),outside_gpu_and_reads_seconds=length(windows)-length(inter(windows,busy)),missing_gpu_intervals=sum(windows[0][0]<=float(s['encoded'])<=windows[-1][1]and not(int(s['gpu_end'])>int(s['gpu_start'])>0)for s in stages),fields=all_metrics,phases=phases,footers=dict(stages=sfoot,reads=rfoot,copies=cfoot))
(P/'analysis.json').write_text(json.dumps(result,indent=2))
(P/'pipeline-attribution.json').write_text(json.dumps(dict(scope='Each MLX gpu::eval primitive interval joined to actual Metal pipeline assignments in that interval. No assignment includes non-dispatch views or unknown work; signatures are not semantic primitive identities. Summed non-overlapping intervals are observed service, not removable delay. Full final-round scope.',rows=signature_rows,footers=dict(pipelines=pfoot,assignments=afoot)),indent=2))
print(json.dumps({k:v for k,v in result.items()if k not in ['phases','footers']},indent=2))
print('TOP PIPELINE SIGNATURES',json.dumps(signature_rows[:15],indent=2))
