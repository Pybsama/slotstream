from pathlib import Path
import hashlib,json,shutil,subprocess
P=Path(__file__).resolve().parent;R=P.parents[1];F=P.parent/'q2-full-cycle-20261025';M=R/'.build/checkouts/mlx-swift'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=M,text=True).strip()
backend='.build/checkouts/mlx-swift/Source/Cmlx/mlx/mlx/backend/metal/eval.cpp'
s=(R/backend).read_text();(P/'eval-original.cpp').write_text(s)
s=s.replace('namespace mlx::core::gpu {',(P/'probe.hpp.txt').read_text()+'\nnamespace mlx::core::gpu {')
replacements=[('void eval(array& arr) {','void eval(array& arr) {\n  SSProbe probe;'),('  auto outputs = arr.outputs();\n  {','  auto outputs = arr.outputs();\n  probe.primitive_begin();\n  {'),('  std::unordered_set<std::shared_ptr<array::Data>> buffers;','  probe.primitive_end();\n  probe.hold_begin();\n  std::unordered_set<std::shared_ptr<array::Data>> buffers;'),('  if (encoder.needs_commit()) {','  probe.hold_end();\n  probe.register_begin();\n  if (encoder.needs_commit()) {\n    probe.split();'),('        [buffers = std::move(buffers)](MTL::CommandBuffer* cbuf) {});\n  }\n}','        [buffers = std::move(buffers)](MTL::CommandBuffer* cbuf) {});\n  }\n  probe.register_end();\n}')]
for old,new in replacements:assert s.count(old)==1,(old,s.count(old));s=s.replace(old,new)
(P/'eval-probe.cpp').write_text(s)
rep={backend:'eval-probe.cpp'}
s=(R/'Tools/build_identity.py').read_text();needle='    if any(p.is_symlink() for p in candidates):';assert s.count(needle)==1;s=s.replace(needle,"    # Explicit diagnostic dependency override, included in the source archive.\n    candidates.append(root/"+repr(backend)+")\n"+needle);(P/'build_identity-probe.py').write_text(s);rep['Tools/build_identity.py']='build_identity-probe.py'
s=(R/'Sources/CNativeSchedule/include/CNativeSchedule.h').read_text()+'''\n// Temporary MLX host-evaluation diagnostic API, not a production interface.
#ifdef __cplusplus
extern "C" {
#endif
void ss_mlx_eval_probe_begin(void);
int ss_mlx_eval_probe_end(const char* prefix);
#ifdef __cplusplus
}
#endif
''';(P/'CNativeSchedule-probe.h').write_text(s);rep['Sources/CNativeSchedule/include/CNativeSchedule.h']='CNativeSchedule-probe.h'
s=(F/'Q2ProfileCommand.swift').read_text().replace('import Slotstream','import Slotstream\nimport CNativeSchedule').replace('    @Flag var validate = false','    @Flag var validate = false\n    @Flag var mlxProbe = false')
s=s.replace('                    let requestStart=RuntimeClock.now()','                    if mlxProbe && round == rounds - 1 { ss_mlx_eval_probe_begin() }\n                    let requestStart=RuntimeClock.now()')
s=s.replace('                    let requestEnd=RuntimeClock.now()','''                    let requestEnd=RuntimeClock.now()
                    if mlxProbe && round == rounds - 1 {
                        let path = output + ".mlx-host"
                        guard path.withCString({ ss_mlx_eval_probe_end($0) }) == 0 else { throw ModelError("MLX host probe overflow, foreign caller or write failure") }
                    }''')
(P/'Q2ProfileCommand-probe.swift').write_text(s);rep['Sources/slotstream-cli/Q2ProfileCommand.swift']='Q2ProfileCommand-probe.swift'
(P/'replacements.json').write_text(json.dumps(rep,indent=2))
for n in ['quiet_guarded_run.py','timed-2.json','check_restoration.py']:shutil.copy2(F/n,P/n)
plan=dict(scope='Temporary MLX gpu::eval attribution. Bracket only the final real111-cycle round, retain every operation/lifetime/commit. Separate exact validation, then one warmup plus one observed round in each counter-off/on process. No Fast or production optimization.',provenance='The one modified dependency source is explicitly included in build identity and source archive; restore its original bytes and clean dependency Git state after building, plus all509 production inputs and five v68 artifacts.',fields=dict(total='gpu::eval entry through autorelease-pool and local cleanup',primitive='Primitive host eval, including tracer-input owners and debug labels',hold='Construct captured input/sibling data owners and remove donated output',registration='Move captures and register cleanup, or split/end/notify/commit',residual='Other front/tail work; nested scopes are never summed with total'),gates=dict(correctness='111 full FP32 logit hashes, real proposals and selected tokens match v68, Metal validation enabled. Row monotonicity, byte size, capacity and one owner checked.',profile='One warmup plus one measured round for off/on. No heavy analysis while any model/build is alive. Match4067slots15GB8192context and BF16/FP32 recipe. Only diagnose contribution outside actual reads/GPU; no candidate from high call counts alone.',limits='Probe stamping and writes can perturb scheduling. Control comparison checks sensitivity; no product speed claim and no retry on exclusion. Pure registration was already small; this measures preceding C++ ownership and primitive encoding separately.'),dependency_revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=M,text=True).strip(),hashes={n:hashlib.sha256((P/f).read_bytes()).hexdigest()for n,f in rep.items()})
(P/'plan.json').write_text(json.dumps(plan,indent=2));print('prepared explicit archived MLX source override')
