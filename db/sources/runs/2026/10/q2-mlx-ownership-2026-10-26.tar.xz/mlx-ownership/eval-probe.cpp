// Copyright © 2023-2024 Apple Inc.
#include <memory>

#include "mlx/backend/gpu/eval.h"
#include "mlx/backend/metal/device.h"
#include "mlx/backend/metal/utils.h"
#include "mlx/primitives.h"
#include "mlx/scheduler.h"
#include "mlx/utils.h"

// Temporary diagnostic only, archived with the actual modified MLX source.
// No operation, lifetime or submission is changed. The model owner brackets
// one synchronous host-evaluation epoch; other callers are counted and rejected.
#include <atomic>
#include <cstdio>
#include <cstdint>
#include <mach/mach_time.h>
#include <pthread.h>
namespace {
constexpr size_t ss_probe_cap=1048576;
struct SSProbeRow {
  uint64_t begin=0,primitive_begin=0,primitive_end=0,hold_begin=0,hold_end=0;
  uint64_t register_begin=0,register_end=0,end=0,thread=0;
  uint32_t branch=0,reserved=0;
};
static_assert(sizeof(SSProbeRow)==80);
SSProbeRow ss_probe_rows[ss_probe_cap];
std::atomic<bool> ss_probe_recording{false};
std::atomic<size_t> ss_probe_next{0},ss_probe_foreign{0};
uint64_t ss_probe_owner=0;
uint64_t ss_probe_thread(){static thread_local uint64_t tid=[] {uint64_t v=0;pthread_threadid_np(nullptr,&v);return v;}();return tid;}
struct SSProbe {
  SSProbeRow* row=nullptr;
  SSProbe(){
    if(!ss_probe_recording.load(std::memory_order_acquire))return;
    const auto tid=ss_probe_thread();
    if(tid!=ss_probe_owner){ss_probe_foreign.fetch_add(1);return;}
    const size_t i=ss_probe_next.fetch_add(1);
    if(i>=ss_probe_cap)return;
    row=&ss_probe_rows[i];*row={};row->thread=tid;row->begin=mach_absolute_time();
  }
  ~SSProbe(){if(row)row->end=mach_absolute_time();}
  void primitive_begin(){if(row)row->primitive_begin=mach_absolute_time();}
  void primitive_end(){if(row)row->primitive_end=mach_absolute_time();}
  void hold_begin(){if(row)row->hold_begin=mach_absolute_time();}
  void hold_end(){if(row)row->hold_end=mach_absolute_time();}
  void register_begin(){if(row)row->register_begin=mach_absolute_time();}
  void register_end(){if(row)row->register_end=mach_absolute_time();}
  void split(){if(row)row->branch=1;}
};
}
extern "C" void ss_mlx_eval_probe_begin(){
  ss_probe_next.store(0);ss_probe_foreign.store(0);ss_probe_owner=ss_probe_thread();
  ss_probe_recording.store(true,std::memory_order_release);
}
extern "C" int ss_mlx_eval_probe_end(const char* prefix){
  ss_probe_recording.store(false,std::memory_order_release);
  if(ss_probe_thread()!=ss_probe_owner)return -2;
  const size_t n=ss_probe_next.load();const size_t foreign=ss_probe_foreign.load();
  if(n>=ss_probe_cap || foreign)return -3;
  char path[4096];int length=snprintf(path,sizeof(path),"%s.bin",prefix);
  if(length<0 || size_t(length)>=sizeof(path))return -4;
  FILE*f=fopen(path,"wbx");if(!f)return -5;
  const bool okay=fwrite(ss_probe_rows,sizeof(SSProbeRow),n,f)==n;fclose(f);if(!okay)return -6;
  length=snprintf(path,sizeof(path),"%s.json",prefix);if(length<0 || size_t(length)>=sizeof(path))return -7;
  f=fopen(path,"wx");if(!f)return -8;
  mach_timebase_info_data_t time;mach_timebase_info(&time);
  fprintf(f,"{\"rows\":%zu,\"cap\":%zu,\"row_bytes\":80,\"numer\":%u,\"denom\":%u,\"owner\":%llu,\"foreign_calls\":%zu,\"layout\":\"little-endian9uint64+2uint32:begin,primitive_begin,primitive_end,hold_begin,hold_end,register_begin,register_end,end,thread,branch,reserved\"}\n",n,ss_probe_cap,time.numer,time.denom,(unsigned long long)ss_probe_owner,foreign);
  fclose(f);return 0;
}

namespace mlx::core::gpu {

void init() {}

void new_stream(Stream s) {
  assert(s.device == Device::gpu);
  auto& encoders = metal::get_command_encoders();
  auto& d = metal::device(s.device);
  encoders.try_emplace(s.index, d, s.index, d.residency_sets());
}

void new_thread_unsafe_stream(Stream s) {
  assert(s.device == Device::gpu);
  auto& encoders = metal::get_global_command_encoders();
  auto& d = metal::device(s.device);
  encoders.try_emplace(s.index, d, s.index, d.residency_sets());
}

void eval(array& arr) {
  SSProbe probe;
  auto pool = metal::new_scoped_memory_pool();
  auto s = arr.primitive().stream();
  auto& encoder = metal::get_command_encoder(s);
  auto* command_buffer = encoder.get_command_buffer();

  auto outputs = arr.outputs();
  probe.primitive_begin();
  {
    // If the array is a tracer hold a reference
    // to its inputs so they don't get donated
    std::vector<array> inputs;
    if (arr.is_tracer()) {
      inputs = arr.inputs();
    }

    debug_set_primitive_buffer_label(command_buffer, arr.primitive());
    arr.primitive().eval_gpu(arr.inputs(), outputs);
  }
  probe.primitive_end();
  probe.hold_begin();
  std::unordered_set<std::shared_ptr<array::Data>> buffers;
  for (auto& in : arr.inputs()) {
    buffers.insert(in.data_shared_ptr());
  }
  for (auto& s : arr.siblings()) {
    buffers.insert(s.data_shared_ptr());
  }
  // Remove the output if it was donated to by an input
  if (auto it = buffers.find(arr.data_shared_ptr()); it != buffers.end()) {
    buffers.erase(it);
  }

  probe.hold_end();
  probe.register_begin();
  if (encoder.needs_commit()) {
    probe.split();
    encoder.end_encoding();
    scheduler::notify_new_task(s);
    encoder.commit([s, buffers = std::move(buffers)]() {
      scheduler::notify_task_completion(s);
    });
  } else {
    command_buffer->addCompletedHandler(
        [buffers = std::move(buffers)](MTL::CommandBuffer* cbuf) {});
  }
  probe.register_end();
}

void finalize(Stream s) {
  auto pool = metal::new_scoped_memory_pool();
  auto& encoder = metal::get_command_encoder(s);
  auto* cb = encoder.get_command_buffer();
  encoder.end_encoding();
  encoder.commit();
}

void synchronize(Stream s) {
  metal::get_command_encoder(s).synchronize();
}

void clear_streams() {
  metal::get_command_encoders().clear();
  if (is_main_thread()) {
    metal::get_global_command_encoders().clear();
  }
}

} // namespace mlx::core::gpu
