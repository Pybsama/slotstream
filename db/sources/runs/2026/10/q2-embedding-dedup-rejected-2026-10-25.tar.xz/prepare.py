from pathlib import Path
import json,shutil,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1];O=P.parent/'q2-request-profile-20261025'
s=(R/'Sources/Slotstream/Q2Checkpoint.swift').read_text()
s=s.replace('    func embedding(_ ids:', '    package func embedding(_ ids:')
old='''        var data = Data(); data.reserveCapacity(ids.count * tensor.rowBytes)
        for id in ids { data.append(try tensor.read(offset: id * tensor.rowBytes, count: tensor.rowBytes)) }'''
new='''        // Repeated IDs share a row within this lookup only. Read order,
        // compressed bytes and dequantization are unchanged; no rows persist.
        var data = Data(count: ids.count * tensor.rowBytes)
        var firstRow: [Int: Int] = [:]
        try data.withUnsafeMutableBytes { output in
            for (position, id) in ids.enumerated() {
                let destination = output.baseAddress! + position * tensor.rowBytes
                if let first = firstRow[id] {
                    destination.copyMemory(from: output.baseAddress! + first * tensor.rowBytes,
                        byteCount: tensor.rowBytes)
                } else {
                    let row = try tensor.read(offset: id * tensor.rowBytes, count: tensor.rowBytes)
                    row.withUnsafeBytes { destination.copyMemory(from: $0.baseAddress!, byteCount: tensor.rowBytes) }
                    firstRow[id] = position
                }
            }
        }'''
assert s.count(old)==1;s=s.replace(old,new);(P/'Q2Checkpoint-candidate.swift').write_text(s)
s=(R/'Sources/slotstream-cli/Q2ExpertsCheck.swift').read_text();s=s.replace('''    func run() throws {
        if pieceOnly {''','''    @Flag(help: "Check Q2 embedding lookup row order against original packed rows")
    var embeddingOnly = false
    func run() throws {
        if embeddingOnly {
            guard !draftOnly, !sharedOnly, !pieceOnly, poolModel == nil else { throw ValidationError("Embedding checks do not load expert pools") }
            guard (Machine.current().availableGB ?? 0) >= 6 else { throw ValidationError("Embedding checks require 6 GB reclaimable") }
            try ModelProcessGuard.acquire()
            MLX.Memory.cacheLimit = 128 << 20
            let index = try CheckpointIndex(q2Directory: ModelLocator.resolve("smart-q2"))
            let checkpoint = index.q2!
            let tensor = checkpoint.mapped["model.embed_tokens.weight"]!
            var checked = 0
            for count in [1, 2, 7, 8, 17, 64, 512] {
                for mode in 0..<4 {
                    let ids = (0..<count).map { i in mode == 0 ? 248077 : mode == 1 ? (i == 0 ? 42 : 248077) : mode == 2 ? i % 5 : (i * 71 + 31) % tensor.rows }
                    var referenceBytes = Data()
                    for id in ids { referenceBytes.append(try tensor.read(offset: id * tensor.rowBytes, count: tensor.rowBytes)) }
                    let reference = Q2GGUFLinear.decode(MLXArray(referenceBytes, [referenceBytes.count], dtype: .uint8), format: tensor.format,
                        count: ids.count * tensor.columns, dtype: .bfloat16).reshaped([1, count, tensor.columns])
                    let actual = try checkpoint.embedding(ids, shape: [1, count])
                    guard actual.shape == reference.shape, actual.dtype == reference.dtype,
                          (actual .== reference).all().item(Bool.self) else { throw ValidationError("Embedding rows changed at count \\(count), mode \\(mode)") }
                    checked += 1
                }
            }
            for ids in [[-1], [tensor.rows], [42, -1, 42]] {
                do {
                    _ = try checkpoint.embedding(ids, shape: [1, ids.count])
                    throw ValidationError("Invalid embedding ID admitted")
                } catch is ModelError { }
            }
            print("Q2 embedding: \\(checked) original-byte equality cases, repeated/unique/reordered IDs, and invalid-ID rejection PASS")
            return
        }
        if pieceOnly {''');(P/'Q2ExpertsCheck-candidate.swift').write_text(s)
shutil.copy2(O/'SmartDFlashCommand-request-clock.swift',P/'SmartDFlashCommand-request-clock.swift')
for n in ['quiet_guarded_run.py','q2_upstream_bench_io.py','cases.json','check_restoration.py']:
 shutil.copy2(O/n,P/n)
s=(O/'run.py').read_text().replace("a.order=='ACCA'","a.order=='ABCCBA'").replace("scope='Ordinary complete requests", "scope='One ABCCBA test: A v68, B per-lookup duplicate embedding read elimination, C published Splash. No retry or observer injection. Retain only repeatable per-fixture forward/reverse improvement. Ordinary complete requests")
(P/'run.py').write_text(s)
s=(P.parent/'q2-graph-profile-20261025/build.py').read_text();begin=s.index('replacements=');end=s.index('\noriginals=',begin)
s=s[:begin]+"replacements={'Sources/Slotstream/Q2Checkpoint.swift':'Q2Checkpoint-candidate.swift','Sources/slotstream-cli/Q2ExpertsCheck.swift':'Q2ExpertsCheck-candidate.swift','Sources/slotstream-cli/SmartDFlashCommand.swift':'SmartDFlashCommand-request-clock.swift'}"+s[end:]
s=s.replace("P/'native-host-build'","P/'native-build'");(P/'build.py').write_text(s)
(P/'plan.json').write_text(json.dumps(dict(scope='Q2-only per-lookup repeated-ID elimination; no persistent cache, no schedule/precision/quantization changes; Fast unchanged.',evidence='Clean graph profile found 1100-byte token row reads outside expert read/GPU work. 1478/1609 reads cover only209unique offsets; draft lookup repeatedly reads7identicalmaskrows. Graphconstruction34/39msdoesnotjustifycompileport.',qualification='28 actual installed embedding cases against original-row reads, invalid IDs; one complete ABCCBA15GB4067slots8192context384tokens with production controller and full guards. No retries. No parity/quality claim from successful throughput alone.',sources={n:hashlib.sha256((P/n).read_bytes()).hexdigest()for n in ['Q2Checkpoint-candidate.swift','Q2ExpertsCheck-candidate.swift','SmartDFlashCommand-request-clock.swift']}),indent=2))
