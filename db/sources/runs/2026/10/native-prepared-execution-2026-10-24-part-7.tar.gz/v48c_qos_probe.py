from pathlib import Path
import json,statistics,subprocess,sys,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1]
assert json.loads((P/'v49-controller-result.json').read_text())['exit_code']==0
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
sys.path.insert(0,str(R/'.build/native-q2-20261021'));from thermal import wait_nominal
events=[]
def run(label,cmd):
 print('START',label,flush=True)
 with(P/(label+'-driver.log')).open('x')as f:r=subprocess.run(list(map(str,cmd)),cwd=R,stdout=f,stderr=subprocess.STDOUT)
 events.append(dict(label=label,command=list(map(str,cmd)),exit_code=r.returncode))
 (P/'v48c-qos-probe-ledger.json').write_text(json.dumps(events,indent=2)+'\n')
 print('END',label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
preflight(12)
run('v48c-qos-observer-build',['xcrun','clang++','-std=c++20','-O2','-fno-objc-arc','-framework','Foundation','-framework','Metal','-dynamiclib',P/'metal_qos_probe_b.mm','-o',P/'metal_qos_probe_b.dylib'])
def guarded(label,budget,args,boost):
 cmd=[sys.executable,str(P/'guarded_run.py'),'--label',label,'--budget',str(budget),'--timeout','600',
 '--env','SLOTSTREAM_NATIVE_DEFERRED_ROUTES=0','--env','DYLD_INSERT_LIBRARIES='+str(P/'metal_qos_probe_b.dylib'),
 '--env','SLOTSTREAM_METAL_OBSERVER='+str(P/label)]
 if boost:cmd+=['--env','SLOTSTREAM_QOS_PROBE_CLASS=25']
 return cmd+['--']+list(map(str,args))
def qos(label):
 fs=list(P.glob(label+'.*.qos.json'));assert len(fs)==1
 d=json.loads(fs[0].read_text());assert d['errors']==0
 return {str(r['qos']):dict(before=r['before'],after=r['after'])for r in d['classes']if r['before']or r['after']}
label='v48c-qos-component'
run(label,guarded(label,1,[P/'metal_command_observer_check'],True));assert sum(row['after'] for cls,row in qos(label).items() if int(cls)>=25)>=4
component=list(P.glob(label+'.*.csv'));assert len(component)==1
assert len([line for line in component[0].read_text().splitlines()if not line.startswith('#')])-1==4
arms=[]
for index,arm in enumerate('ABBA'):
 label=f'v48c-qos-cached-{index}-{arm}'
 wait_nominal(P/(label+'-cooldown.json'))
 run(label,guarded(label,15,[P/'v48/slotstream','q2-profile','--model','smart-q2','--memory-gb','15','--rounds','3',
 '--fixture',P/'v29-profile-smart-q2-fixture.json','--output',P/(label+'.json')],arm=='B'))
 d=json.loads((P/(label+'.json')).read_text());obs=json.loads((P/(label+'.observer.json')).read_text());classes=qos(label)
 assert all(r['max_logit_difference']==0 and r['argmax_equal']for r in d['runs'])
 clean=not obs['paging']and obs['thermal_before']==obs['thermal_after']==0
 row=dict(label=label,arm=arm,clean=clean,qos=classes,medians={})
 for w in [1,2,4,8]:
  rs=[r for r in d['runs']if r['width']==w and r['round']>0 and not r['traced']]
  assert len(rs)==3 and all(r['io_seconds']==0 for r in rs)
  row['medians'][str(w)]=statistics.median(r['seconds']for r in rs)
 arms.append(row)
 summary=dict(complete=len(arms)==4,all_arms_eligible=all(a['clean']for a in arms),arms=arms,scope='Frozen v48 cached target only. A timestamp/QoS observer; B same observer plus public user-initiated QoS on threads creating Metal commands. No spin, sysctl or system-wide policy. Diagnostic only, not production or serving parity.')
 if len(arms)==4:summary['boost_over_ordinary']={str(w):statistics.median(a['medians'][str(w)]for a in arms if a['arm']=='B')/statistics.median(a['medians'][str(w)]for a in arms if a['arm']=='A')for w in [1,2,4,8]}
 summary['identity']={f:hashlib.sha256((P/f).read_bytes()).hexdigest()for f in ['metal_qos_probe_b.mm','metal_qos_probe_b.dylib','v48/slotstream']}
 (P/'v48c-qos-probe-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary),flush=True)
