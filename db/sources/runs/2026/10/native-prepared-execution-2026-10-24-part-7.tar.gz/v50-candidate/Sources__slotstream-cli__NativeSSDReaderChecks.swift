import ArgumentParser
import Foundation
import Slotstream

func checkNativeSSDReaders() throws {
    let before = NativeSSDReaders.batches
    for count in [0, 1, 31, 32, 33, 96, 257, 1536] {
        let lock = NSLock()
        var seen = [Int](repeating: 0, count: count), active = 0, peak = 0
        try NativeSSDReaders.run(count) { index in
            lock.lock()
            active += 1; peak = max(peak, active)
            if seen.indices.contains(index) { seen[index] += 1 }
            lock.unlock()
            Thread.sleep(forTimeInterval: 0.00005)
            lock.lock(); active -= 1; lock.unlock()
        }
        guard seen.allSatisfy({ $0 == 1 }), active == 0, peak <= min(count, 33) else {
            throw ValidationError("Native reader batch lost, duplicated or outlived work")
        }
    }
    guard NativeSSDReaders.batches - before == 7 else {
        throw ValidationError("Native reader batch accounting differs")
    }
    for invalid in [-1, 1537] {
        var called = false
        do {
            try NativeSSDReaders.run(invalid) { _ in called = true }
            throw ValidationError("Native reader accepted an invalid batch")
        } catch is ModelError {} // A refused batch never invokes its callback.
        guard !called else { throw ValidationError("Invalid reader batch ran work") }
    }
    print("Native SSD readers: exact-once indices, joined callbacks, 33-active bound, invalid batch rejection PASS")
}
