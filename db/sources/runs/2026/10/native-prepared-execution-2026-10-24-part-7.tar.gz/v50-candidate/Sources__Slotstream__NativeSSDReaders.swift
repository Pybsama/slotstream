import Foundation
import CNativeSchedule

/// Splash's unchanged native SSD work queue, with Swift-owned checked reads.
/// The synchronous batch joins every callback before releasing its context.
/// One process-wide pool has 32 reusable readers plus the calling thread;
/// no task retains model memory after the batch. This does not change the
/// file-read, fault-publication, cache-admission or GPU-completion contracts.
package enum NativeSSDReaders {
    package static let enabled = ProcessInfo.processInfo.environment["SLOTSTREAM_NATIVE_SSD_READERS"] != "0"
    package static var batches: UInt64 { ss_readers_batches() }
    private final class Context {
        let body: (Int) -> Void
        init(_ body: @escaping (Int) -> Void) { self.body = body }
    }
    package static func run(_ count: Int, _ body: @escaping (Int) -> Void) throws {
        guard (0...1536).contains(count) else { throw ModelError("Native reader batch exceeds its bound") }
        let context = Context(body)
        let handle = Unmanaged.passUnretained(context).toOpaque()
        let code = withExtendedLifetime(context) {
            ss_readers_run(Int32(count), { pointer, index in
                Unmanaged<Context>.fromOpaque(pointer!).takeUnretainedValue().body(Int(index))
            }, handle)
        }
        guard code == 0 else { throw ModelError(String(cString: ss_readers_error())) }
    }
}
