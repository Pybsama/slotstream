#include "NativeSSDReaders.h"
#include "model/SsdReaders.hpp"
#include <atomic>
#include <string>
#include <stdexcept>
namespace {
thread_local std::string error;
std::atomic<uint64_t> batches{0};
splash::model::SsdReaders& readers() {
  // Same bounded native pool as Splash. It is shared by sequential model
  // lifetimes and owns no checkpoint, Swift object, buffer or request.
  static splash::model::SsdReaders pool(splash::model::kSsdReaders);
  return pool;
}
}
extern "C" {
int ss_readers_run(int32_t count, void (*task)(void *, int32_t), void *context) {
  try {
    // Three pieces for every expert in the existing 512-record override.
    if (count < 0 || count > 1536 || !task || !context)
      throw std::invalid_argument("Invalid bounded native read batch");
    if (count == 0) return 0;
    // Swift records checked-I/O failures itself. No C++ exception crosses the
    // callback, so upstream's retry-on-exception never hides a Swift failure.
    readers().run(size_t(count), [task, context](size_t i) { task(context, int32_t(i)); });
    ++batches;
    return 0;
  } catch (const std::exception& e) { error = e.what(); return 1; }
}
const char *ss_readers_error(void) { return error.c_str(); }
uint64_t ss_readers_batches(void) { return batches.load(); }
}
