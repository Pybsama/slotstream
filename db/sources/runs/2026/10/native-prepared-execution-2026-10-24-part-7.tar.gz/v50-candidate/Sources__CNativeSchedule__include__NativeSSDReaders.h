#pragma once
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
// Synchronous join: context remains caller-owned until this returns. Each
// index is delivered exactly once; callbacks must not throw across the ABI.
int ss_readers_run(int32_t count, void (*task)(void *, int32_t), void *context);
const char *ss_readers_error(void);
uint64_t ss_readers_batches(void);
#ifdef __cplusplus
}
#endif
