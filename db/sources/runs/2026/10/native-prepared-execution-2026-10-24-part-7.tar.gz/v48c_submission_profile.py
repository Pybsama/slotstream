from pathlib import Path
import csv, hashlib, json, statistics, subprocess, sys
P=Path(__file__).resolve().parent;R=P.parents[1]
assert json.loads((P/'v48-controller-result.json').read_text())['exit_code']==0
B=P/'v48/slotstream';events=[]
def run(label,cmd):
    print('START',label,flush=True)
    with(P/(label+'-driver.log')).open('x')as log:
        result=subprocess.run(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT)
    events.append(dict(label=label,command=cmd,exit_code=result.returncode))
    (P/'v48c-large-submission-profile-ledger.json').write_text(json.dumps(events,indent=2)+'\n')
    print('END',label,result.returncode,flush=True)
    if result.returncode:raise SystemExit(result.returncode)
def guarded(label,budget,env,cmd):
    out=[sys.executable,str(P/'guarded_run.py'),'--label',label,'--budget',str(budget),'--timeout','600']
    for k,v in env.items():out+=['--env',k+'='+str(v)]
    return out+['--']+list(map(str,cmd))
def observation(label):
    return dict(DYLD_INSERT_LIBRARIES=P/'metal_command_observer_mrc.dylib',SLOTSTREAM_METAL_OBSERVER=P/label)
def records(label):
    paths=list(P.glob(label+'.*.csv'));assert len(paths)==1,paths
    with paths[0].open()as f:
        rows=[{k:float(v)for k,v in row.items()}for row in csv.DictReader(line for line in f if not line.startswith('#'))]
    assert rows and len(rows)<262144
    assert all(row['status']==4 and 0<row['start']<=row['end']<=row['completed'] for row in rows)
    assert len({(r['start'],r['end'])for r in rows})==len(rows),'Duplicate command observations'
    return rows
identity={f:hashlib.sha256((P/f).read_bytes()).hexdigest()for f in ['metal_command_observer.mm','metal_command_observer_mrc.dylib','metal_command_observer_check.mm','metal_command_observer_check','v48/slotstream']}
results=[]
for arm in ['observed']:
    label='v48c-large-submission-profile-'+arm
    env=dict(SLOTSTREAM_NATIVE_DEFERRED_ROUTES='0',MLX_MAX_MB_PER_BUFFER='65536',MLX_MAX_OPS_PER_BUFFER='4096')
    if arm=='observed':env.update(observation(label))
    run(label,guarded(label,15,env,[B,'q2-profile','--model','smart-q2','--memory-gb','15','--rounds','3',
        '--fixture',P/'v29-profile-smart-q2-fixture.json','--output',P/(label+'.json')]))
    receipt=json.loads((P/(label+'.json')).read_text())
    assert all(r['max_logit_difference']==0 and r['argmax_equal']for r in receipt['runs'])
    commandRows=records(label)if arm=='observed'else []
    for row in receipt['runs']:
        if not row['round'] or row['traced']:continue
        start=row['started_uptime_ns']/1e9;end=row['ended_uptime_ns']/1e9
        intervals=sorted((max(start,c['start']),min(end,c['end']))for c in commandRows if c['end']>start and c['start']<end)
        union=0;last=start
        for a,b in intervals:
            union+=max(0,b-max(a,last));last=max(last,b)
        results.append(dict(arm=arm,width=row['width'],round=row['round'],seconds=row['seconds'],
            io_seconds=row['io_seconds'],commands=len(intervals),command_gpu_interval_union=union,
            outside_command_intervals=max(0,end-start-union),paging=bool(row['swapins_delta']or row['swapouts_delta'])))
    (P/'v48c-large-submission-profile-summary.json').write_text(json.dumps(dict(identity=identity,rows=results,
        scope='Diagnostic fixed-token ordinary target replay with logical submission thresholds 65536 MiB/4096 ops. Physical budget remains 15 GB. Earlier ordinary probe used 4096 MiB, below total expert bindings. No production settings changed. Command-buffer GPU intervals include in-command waits and do not measure ALU utilization. Outside-interval time is not itself proof of GPU idle. Instrumented runs are never serving-speed evidence.'),indent=2)+'\n')
print(json.dumps(results),flush=True)
