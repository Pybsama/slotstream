from pathlib import Path
import hashlib,json,statistics,subprocess,sys
P=Path(__file__).resolve().parent;R=P.parents[1]
assert json.loads((P/'v48-controller-result.json').read_text())['exit_code']==0
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
sys.path.insert(0,str(R/'.build/native-q2-20261021'));from thermal import wait_nominal
events=[]
def run(label,cmd):
 print('START',label,flush=True)
 with(P/(label+'-driver.log')).open('x')as f:r=subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT)
 events.append(dict(label=label,command=list(map(str,cmd)),exit_code=r.returncode))
 (P/'v48b-serial-probe-ledger.json').write_text(json.dumps(events,indent=2)+'\n')
 print('END',label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
preflight(12)
for name,dylib in [('metal_serial_encoder_probe',True),('metal_serial_encoder_check',False)]:
 cmd=['xcrun','clang++','-std=c++20','-O2','-fno-objc-arc','-framework','Foundation','-framework','Metal']
 if dylib:cmd+=['-dynamiclib']
 run(name+'-b-build',cmd+[str(P/(name+'.mm')),'-o',str(P/(name+('.dylib'if dylib else'')))])
def command(label,budget,args,serial):
 result=[sys.executable,str(P/'guarded_run.py'),'--label',label,'--budget',str(budget),'--timeout','600','--env','SLOTSTREAM_NATIVE_DEFERRED_ROUTES=0']
 if serial:result+=['--env','DYLD_INSERT_LIBRARIES='+str(P/'metal_serial_encoder_probe.dylib'),'--env','SLOTSTREAM_SERIAL_PROBE='+str(P/label)]
 return result+['--']+list(map(str,args))
def counter(label):
 files=[f for f in P.glob(label+'.*.json') if f.stem.rsplit('.',1)[-1].isdigit()];assert len(files)==1,files
 count=json.loads(files[0].read_text())['concurrent_to_serial'];assert count>0
 return count
label='v48b-serial-component'
run(label,command(label,1,[P/'metal_serial_encoder_check'],True));assert counter(label)==4
rows=[];arms=[]
for i,arm in enumerate('ABBA'):
 label=f'v48b-serial-cached-{i}-{arm}'
 wait_nominal(P/(label+'-cooldown.json'))
 run(label,command(label,15,[P/'v48/slotstream','q2-profile','--model','smart-q2','--memory-gb','15','--rounds','3',
  '--fixture',P/'v29-profile-smart-q2-fixture.json','--output',P/(label+'.json')],arm=='B'))
 changed=counter(label)if arm=='B'else 0
 d=json.loads((P/(label+'.json')).read_text());obs=json.loads((P/(label+'.observer.json')).read_text())
 assert all(r['max_logit_difference']==0 and r['argmax_equal']for r in d['runs'])
 clean=not obs['paging']and obs['thermal_before']==obs['thermal_after']==0
 armrow=dict(label=label,arm=arm,clean=clean,serial_encoders=changed,medians={})
 for width in [1,2,4,8]:
  measured=[r for r in d['runs']if r['width']==width and r['round']>0 and not r['traced']]
  assert len(measured)==3 and all(r['io_seconds']==0 for r in measured)
  armrow['medians'][str(width)]=statistics.median(r['seconds']for r in measured)
 arms.append(armrow)
 summary=dict(complete=len(arms)==4,all_arms_eligible=all(x['clean']for x in arms),arms=arms,scope='Diagnostic same-token cached target replay. A=MLX concurrent encoder; B=public-API diagnostic serial override. All explicit MLX barriers, allocation and completion ownership retained. Not serving-speed or adoption evidence.')
 if len(arms)==4:
  summary['serial_over_ordinary']={str(w):statistics.median(a['medians'][str(w)]for a in arms if a['arm']=='B')/statistics.median(a['medians'][str(w)]for a in arms if a['arm']=='A')for w in [1,2,4,8]}
 summary['identity']={f:hashlib.sha256((P/f).read_bytes()).hexdigest()for f in ['metal_serial_encoder_probe.mm','metal_serial_encoder_probe.dylib','v48/slotstream']}
 (P/'v48b-serial-probe-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary),flush=True)
