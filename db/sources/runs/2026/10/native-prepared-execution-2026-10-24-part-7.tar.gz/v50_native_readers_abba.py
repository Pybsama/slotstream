from pathlib import Path
import json,statistics,subprocess,sys
P=Path(__file__).resolve().parent;R=P.parents[1];B=P/'v50/slotstream'
sys.path.insert(0,str(R/'.build/native-q2-20261021'));from thermal import wait_nominal
arms=[]
for index,arm in enumerate('ABBA'):
 label=f'v50-native-readers-{index}-{arm}';out=P/(label+'.json')
 wait_nominal(P/(label+'-cooldown.json'))
 enabled=arm=='B'
 cmd=[sys.executable,str(P/'guarded_run_io.py'),'--label',label,'--budget','15',
  '--env','SLOTSTREAM_NATIVE_DEFERRED_ROUTES=0','--env','SLOTSTREAM_NATIVE_SSD_READERS='+str(int(enabled)),
  '--',str(B),'smart-dflash-check','--native-read-ahead','on','--method','q2','--model','smart-q2',
  '--memory-gb','15','--max-context','8192','--cases',str(P/'short-warm-384-cases.json'),'--output',str(out)]
 print('START',label,flush=True)
 with(P/(label+'-driver.log')).open('x')as log:r=subprocess.run(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT)
 if r.returncode:raise SystemExit(r.returncode)
 d=json.loads(out.read_text());obs=json.loads((P/(label+'.observer.json')).read_text())
 assert d['complete'] and len(d['runs'])==4
 assert all((x['native_ssd_read_batches']>0)==enabled for x in d['runs'])
 assert all(x['stats']['nativeExecution']['projectionFailures']==0 and x['native_projection_schedule_failures']==0 for x in d['runs'])
 rows=[]
 for x in d['runs']:
  s=x['stats'];assert len(x['tokens'])==384 and s['reusedPrefixTokens']==0
  rows.append(dict(id=x['id'],tps=(s['decodeTokens']-1)/s['decodeSeconds'],request_seconds=x['elapsed_seconds'],io_seconds=s['ioSeconds'] if 'ioSeconds' in s else None,paging=bool(x['swapins_delta']or x['swapouts_delta'])))
 clean=not obs['paging'] and obs['thermal_before']==obs['thermal_after']==0 and not any(x['paging']for x in rows)
 arms.append(dict(label=label,arm=arm,reader_enabled=enabled,clean=clean,command=cmd,slots=d['plan']['pool_slots'],runs=rows))
 summary=dict(complete=len(arms)==4,all_arms_eligible=all(x['clean']for x in arms),arms=arms,
  scope='Native/native fresh-process ABBA. Same frozen v50 binary, 15 GB/context 8192, original target/draft/prompt IDs/greedy/BF16 KV. A current GCD strided raw Q2 demand, B original Splash reusable native SSD readers. Two symmetric warmups and two 384-token requests. No Splash parity claim.')
 if len(arms)==4:
  assert len({a['slots']for a in arms})==1
  summary['tasks']={}
  for case in ['timed-2','timed-3']:
   row={a:{k:statistics.median(r[k]for arm in arms if arm['arm']==a for r in arm['runs']if r['id']==case)for k in ['tps','request_seconds']}for a in 'AB'}
   row['reusable_tps_ratio']=row['B']['tps']/row['A']['tps'];row['reusable_request_ratio']=row['B']['request_seconds']/row['A']['request_seconds']
   summary['tasks'][case]=row
 (P/'v50-native-readers-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 print('END',label,'clean',clean,'rates',[(x['id'],round(x['tps'],2))for x in rows],flush=True)
