import json,subprocess,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];B=P/'v50/slotstream';rows=[]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
preflight(12)
def run(label,cmd):
 print('START',label,flush=True)
 start=time.monotonic()
 with(P/(label+'-driver.log')).open('x')as log:r=subprocess.run(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT)
 rows.append(dict(label=label,command=cmd,exit_code=r.returncode,seconds=time.monotonic()-start));(P/'v50-core-ledger.json').write_text(json.dumps(rows,indent=2)+'\n')
 print('END',label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
run('v50-build',['make','build','SLOTSTREAM_BUILD_JOBS=4'])
run('v50-freeze',[sys.executable,str(P/'freeze.py'),'v50'])
run('v50-readers',[sys.executable,str(P/'guarded_run.py'),'--label','v50-readers','--budget','1','--timeout','30','--',str(B),'q2-experts-check','--readers-only'])
run('v50-pieces',[sys.executable,str(P/'guarded_run.py'),'--label','v50-pieces','--budget','1','--timeout','30','--',str(B),'q2-experts-check','--piece-only'])
run('v50-draft-validated',[sys.executable,str(P/'guarded_run.py'),'--label','v50-draft-validated','--budget','1','--timeout','120','--env','MTL_DEBUG_LAYER=1','--env','MTL_SHADER_VALIDATION=1','--',str(B),'q2-experts-check','--draft-only'])
for model in ['smart-q2','fast']:
 label='v50-pool-'+model
 run(label,[sys.executable,str(P/'guarded_run.py'),'--label',label,'--budget','3','--timeout','900','--',str(B),'q2-experts-check','--pool-model',model])
run('v50-shared-validated',[sys.executable,str(P/'guarded_run.py'),'--label','v50-shared-validated','--budget','3','--timeout','900','--env','MTL_DEBUG_LAYER=1','--env','MTL_SHADER_VALIDATION=1','--',str(B),'q2-experts-check','--pool-model','smart-q2','--shared-only'])
run('v50-formats',[sys.executable,str(P/'guarded_run.py'),'--label','v50-formats','--budget','3','--timeout','240','--env','MTL_DEBUG_LAYER=1','--',str(B),'q2-format-check','--fixtures','bench/q2/formats.json','--policy-fixtures','bench/q2/verify-budget.json','--policy-fixtures','bench/q2/verify-budget-complete.json','--mix-fixtures','bench/q2/mix-quantization.json'])
run('v50-catalogue',[sys.executable,str(P/'guarded_run.py'),'--label','v50-catalogue','--budget','4','--timeout','300','--',str(P/'v50/slotstream-checks'),'--tier','t0','--tier','t1'])
run('v50-plain',[sys.executable,str(P/'v50_plain.py')])
run('v50-quality',[sys.executable,str(P/'v50_native_quality.py')])
