from pathlib import Path
import shutil,json,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1];H=P.parent/'q2-host-profile-20261025'
for name in ['NativeExpertSchedule-host.swift','ExpertStore-host.swift','SmartDFlashCommand-host.swift','named_stage_observer.mm','named_stage_observer.dylib','read_observer.cpp','read_observer.dylib','quiet_guarded_run.py','cases.json','run_host.py','analyze_host_scopes.py','check_restoration.py']:
 shutil.copy2(H/name,P/name)
s=(R/'Sources/Slotstream/DFlashDraft.swift').read_text()
s=s.replace('''        debugSink?("context_features", features)''','''        let hostAppendStart = Q2HostProbe.stamp()
        debugSink?("context_features", features)''')
s=s.replace('''        eval([context.hidden!] + context.keys + context.values)''','''        Q2HostProbe.end("draft_append_build", hostAppendStart)
        let hostAppendEval = Q2HostProbe.stamp()
        eval([context.hidden!] + context.keys + context.values)
        Q2HostProbe.end("draft_append_eval", hostAppendEval)''')
s=s.replace('''        let noise = try target.resident.embedChecked''','''        let hostEmbedStart = Q2HostProbe.stamp()
        let noise = try target.resident.embedChecked''')
s=s.replace('''        let hidden = try hiddenStates(noise: noise, depth: depth, context: context)''','''        Q2HostProbe.end("draft_embed_build", hostEmbedStart)
        let hidden = try hiddenStates(noise: noise, depth: depth, context: context)
        let hostLogitsStart = Q2HostProbe.stamp()''')
s=s.replace('''            let selected = DFlashSelector.select''','''            Q2HostProbe.end("draft_logits_selector_build", hostLogitsStart)
            let hostSelectStart = Q2HostProbe.stamp()
            let selected = DFlashSelector.select''')
s=s.replace('''            if captureConfidence { proposalConfidence = selected.confidence }''','''            Q2HostProbe.end("draft_select_eval", hostSelectStart)
            if captureConfidence { proposalConfidence = selected.confidence }''')
s=s.replace('''    package func hiddenStates(noise: MLXArray, depth: Int, context: Context) throws -> MLXArray {
        guard''','''    package func hiddenStates(noise: MLXArray, depth: Int, context: Context) throws -> MLXArray {
        let hostHiddenStart = Q2HostProbe.stamp()
        defer { Q2HostProbe.end("draft_hidden_build", hostHiddenStart) }
        guard''')
(P/'DFlashDraft-host.swift').write_text(s)
s=(R/'Sources/Slotstream/Layers.swift').read_text();needle='''        let (B, S) = (x.dim(0), x.dim(1))
        let precomputedShared = precomputedSharedParts''';assert s.count(needle)==1
s=s.replace(needle,'''        let hostRouteStart = Q2HostProbe.stamp()
        let (B, S) = (x.dim(0), x.dim(1))
        let precomputedShared = precomputedSharedParts''')
s=s.replace('''            asyncEval(routeIndices, forecast.indices, forecast.weights)''','''            Q2HostProbe.end(S <= 8 ? "target_small_route_build" : "target_prefill_route_build", hostRouteStart)
            let hostEnqueueStart = Q2HostProbe.stamp()
            asyncEval(routeIndices, forecast.indices, forecast.weights)
            Q2HostProbe.end("target_route_enqueue", hostEnqueueStart)''')
s=s.replace('''        if let queue = readbackQueue, !queue.isEmpty {''','''        if predicted == nil { Q2HostProbe.end(S <= 8 ? "target_small_route_build" : "target_prefill_route_build", hostRouteStart) }
        let hostReadbackStart = Q2HostProbe.stamp()
        if let queue = readbackQueue, !queue.isEmpty {''')
s=s.replace('''        let expertIds = routeIndices.asArray(Int32.self)  // B*S*topK''','''        let expertIds = routeIndices.asArray(Int32.self)  // B*S*topK
        Q2HostProbe.end(S <= 8 ? "target_small_route_readback" : "target_prefill_route_readback", hostReadbackStart)''')
(P/'Layers-host.swift').write_text(s)
s=(R/'Sources/Slotstream/Model.swift').read_text();needle='''        let attentionTaps = self.lookahead?.attentionForecastTaps ?? []
        for l in 0 ..< runLayers {''';assert s.count(needle)==1
s=s.replace(needle,needle+'''
            let hostLayerStart = Q2HostProbe.stamp()''')
needle='''            if nativeAttentionPrelaunch, S <= 8,
               pool.expertStore.isQ2 || pool.expertStore.nativeAffineTiles {
                asyncEval(attnOut)
            }''';assert s.count(needle)==1
s=s.replace(needle,'''            Q2HostProbe.end(S <= 8 ? "target_small_attention_build" : "target_prefill_attention_build", hostLayerStart)
            if nativeAttentionPrelaunch, S <= 8,
               pool.expertStore.isQ2 || pool.expertStore.nativeAffineTiles {
                let hostAttentionEval = Q2HostProbe.stamp()
                asyncEval(attnOut)
                Q2HostProbe.end("target_attention_enqueue", hostAttentionEval)
            }
            let hostFrontFinish = Q2HostProbe.stamp()''')
s=s.replace('''            let computedMoE = try moe[l]!(x2)''','''            Q2HostProbe.end(S <= 8 ? "target_small_resident_finish_build" : "target_prefill_resident_finish_build", hostFrontFinish)
            let computedMoE = try moe[l]!(x2)
            let hostTailStart = Q2HostProbe.stamp()''')
s=s.replace('''            let mustBarrier = l == runLayers - 1 || (!retireNativeReadersAtRouter && (period <= 1 || (l + 1) % period == 0))
            if mustBarrier {''','''            let mustBarrier = l == runLayers - 1 || (!retireNativeReadersAtRouter && (period <= 1 || (l + 1) % period == 0))
            Q2HostProbe.end(S <= 8 ? "target_small_tail_build" : "target_prefill_tail_build", hostTailStart)
            if mustBarrier {''')
(P/'Model-host.swift').write_text(s)
s=(H/'build_host_probe.py').read_text();s=s.replace("'Sources/slotstream-cli/SmartDFlashCommand.swift':'SmartDFlashCommand-host.swift'", "'Sources/slotstream-cli/SmartDFlashCommand.swift':'SmartDFlashCommand-host.swift','Sources/Slotstream/DFlashDraft.swift':'DFlashDraft-host.swift','Sources/Slotstream/Layers.swift':'Layers-host.swift','Sources/Slotstream/Model.swift':'Model-host.swift'")
(P/'build.py').write_text(s)
for n in ['run_host.py','analyze_host_scopes.py']:
 p=P/n;p.write_text(p.read_text().replace('ordinary-host-15','ordinary-graph-15'))
(P/'plan.json').write_text(json.dumps(dict(scope='One15GBQ2ordinarydiagnostic,2warm+2timed384tokenrequests. Bounded host scope timestamps in target graph construction, routing/evaluation and DFlash graph construction/evaluation, with same existing read/Metal observers. No inference observer, no full-logit copying, no CPU/GPU schedule change. Restore all production inputs/artifacts after build. Fast unchanged. No speed qualification and no retry.',purpose='Locate pre-submission gaps before choosing a bounded causal intervention; previous copy and expert preparation scopes too small to justify architecture rewrites.',prior_checkpoint='3314bccd50f442c975a1e8d6430b2a6f5e511957',sources={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in P.glob('*-host.swift')}),indent=2))
print('Prepared six diagnostic source files')
