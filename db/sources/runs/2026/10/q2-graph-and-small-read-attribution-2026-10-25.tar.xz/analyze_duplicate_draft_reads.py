import json,csv,bisect
from pathlib import Path
P=Path(__file__).resolve().parent;label='ordinary-graph-15-0-A'
with next(P.glob(label+'-reads.*.csv')).open() as f:reads=list(csv.DictReader(x for x in f if not x.startswith('#')))
reads=sorted([r for r in reads if int(r['bytes'])==1100],key=lambda r:float(r['start']));times=[float(r['start']) for r in reads];out=[]
for request in ['timed-2','timed-3']:
 with (P/(label+'.json.'+request+'.host.csv')).open() as f:scopes=[s for s in csv.DictReader(x for x in f if not x.startswith('#')) if s['kind']=='draft_embed_build']
 duplicates=[];count=0
 for s in scopes:
  a,b=int(s['start_ns'])/1e9,int(s['end_ns'])/1e9;rs=reads[bisect.bisect_left(times,a):bisect.bisect_left(times,b)];assert len(rs)==8
  seen=set()
  for r in rs:
   key=(r['fd'],r['offset']);count+=1
   if key in seen:duplicates.append(float(r['end'])-float(r['start']))
   seen.add(key)
 row=dict(id=request,calls=len(scopes),observed_rows=count,repeated_rows=len(duplicates),repeated_read_service_seconds=sum(duplicates),scope='Observed repeated reads within each draft lookup. This is removed baseline I/O work, not predicted complete-request speedup. No target lookup boundaries inferred.');out.append(row);print(row)
(P/'duplicate-draft-read-analysis.json').write_text(json.dumps(out,indent=2))
