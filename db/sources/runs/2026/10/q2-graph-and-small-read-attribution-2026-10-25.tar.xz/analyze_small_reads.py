from pathlib import Path
import csv,json,collections,bisect
P=Path(__file__).resolve().parent
ns={"__file__":__file__};exec((P/'analyze_host_scopes.py').read_text().split('ledger=json.loads')[0],ns)
parsed,union,length,inter=[ns[x]for x in ['parsed','union','length','inter']]
out=[]
for folder,label in [(P,'ordinary-graph-15-0-A'),(P.parent/'q2-host-profile-20261025','ordinary-copies-15-0-A'),(P.parent/'q2-host-profile-20261025','ordinary-copies-15-1-C')]:
 reads=parsed(next(folder.glob(label+'-reads.*.csv'))); stages=parsed(next(folder.glob(label+'-commands.*.stages.csv')));gpu=union((int(s['gpu_start'])/1e9,int(s['gpu_end'])/1e9)for s in stages if int(s['gpu_end'])>int(s['gpu_start'])>0)
 d=json.loads((folder/(label+'.json')).read_text())
 for r in d['runs']:
  if not r['id'].startswith('timed'):continue
  lo,hi=r['request_started_mach_ns']/1e9,r['request_ended_mach_ns']/1e9
  selected=[x for x in reads if lo<=float(x['start'])<hi];large=union((float(x['start']),float(x['end']))for x in selected if int(x['result'])>=65536);active=union(gpu+large);groups=collections.defaultdict(list)
  for x in selected:
   if int(x['result'])<65536:groups[(int(x['bytes']),int(x['fd']))].append(x)
  detail=[]
  for (size,fd),xs in groups.items():
   spans=union((float(x['start']),float(x['end']))for x in xs);exposed=length(spans)-length(inter(spans,active));detail.append(dict(bytes=size,fd=fd,calls=len(xs),service=sum(float(x['end'])-float(x['start'])for x in xs),union=length(spans),outside_large_reads_gpu=exposed,offset_min=min(int(x['offset'])for x in xs),offset_max=max(int(x['offset'])for x in xs),unique_offsets=len(set(int(x['offset'])for x in xs))))
  allsmall=union((float(x['start']),float(x['end']))for x in selected if int(x['result'])<65536)
  result=dict(label=label,id=r['id'],small_union=length(allsmall),small_outside_large_gpu=length(allsmall)-length(inter(allsmall,active)),groups=sorted(detail,key=lambda x:-x['outside_large_reads_gpu']))
  out.append(result);print(json.dumps(result,indent=2))
(P/'small-read-analysis.json').write_text(json.dumps(out,indent=2))
