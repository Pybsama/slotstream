from pathlib import Path
import csv,json,collections,bisect
P=Path(__file__).resolve().parent
# Reuse only the validated interval helpers, without executing a prior analysis.
exec((P.parent/'q2-host-profile-20261025'/'analyze_ready.py').read_text().split('summary=[];details=[]')[0],globals())
report=[]
for e in json.loads((P/'ordinary-graph-15-ledger.json').read_text()):
 label=e['label'];stagefile=next(P.glob(label+'-commands.*.stages.csv'));ss=rows(stagefile);cc=rows(stagefile.with_name(stagefile.name.replace('.stages.csv','.csv')));rr=rows(next(P.glob(label+'-reads.*.csv')));rr=union((float(r['start']),float(r['end']))for r in rr if int(r['result'])>0)
 bybuf=collections.defaultdict(list)
 for c in cc:
  for k in ['submitted','start','end']:c[k]=float(c[k])
  bybuf[c['buffer']].append(c)
 for v in bybuf.values():v.sort(key=lambda c:c['submitted'])
 times={k:[c['submitted']for c in v]for k,v in bybuf.items()};stages=[]
 for s in ss:
  encoded=float(s['encoded']);begin,end=int(s['gpu_start'])/1e9,int(s['gpu_end'])/1e9
  if begin==end==0:continue
  idx=bisect.bisect_left(times[s['buffer']],encoded);c=bybuf[s['buffer']][idx];assert c['submitted']<=begin
  stages.append(dict(encoded=encoded,begin=begin,end=end,submitted=c['submitted']))
 stages.sort(key=lambda s:s['begin']);d=json.loads((P/(label+'.json')).read_text())
 for r in d['runs']:
  if not r['id'].startswith('timed'):continue
  lo,hi=r['request_started_mach_ns']/1e9,r['request_ended_mach_ns']/1e9;selected=[s for s in stages if lo<=s['encoded']<hi];last=lo;pre=[];post=[];tail=[]
  for s in selected:
   if s['begin']>last:
    a,b=last,s['begin'];split=min(b,max(a,s['submitted']));pre.append([a,split]);post.append([split,b])
   last=max(last,s['end'])
  if last<hi:tail.append([last,hi])
  groups={}
  for name,x in [('before_submission',pre),('after_submission',post),('request_tail',tail)]:
   u=union(x);groups[name]=dict(union_seconds=length(u),outside_reads=length(u)-length(inter(u,rr)))
  row=dict(label=label,id=r['id'],groups=groups,scope='Observed stage gaps partitioned at the next parent command submission. Before submission is elapsed host-side interval, not pure CPU service. After submission may wait for reads, scheduling or dependencies; not automatically driver waste. Missing stage samples remain absent and widen gap bounds. Different adaptive work, attribution only.')
  report.append(row);print(json.dumps(row))
(P/'all-read-submission-gap-analysis.json').write_text(json.dumps(report,indent=2))
