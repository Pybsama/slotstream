from pathlib import Path
import json,sys,shutil,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1];OLD=R/'.build/native-replay-20261023/v68'
sys.path.insert(0,str(R/'Tools'));from optimization_build import build
replacements={'Sources/Slotstream/NativeExpertSchedule.swift':'NativeExpertSchedule-host.swift','Sources/Slotstream/ExpertStore.swift':'ExpertStore-host.swift','Sources/slotstream-cli/SmartDFlashCommand.swift':'SmartDFlashCommand-host.swift','Sources/Slotstream/DFlashDraft.swift':'DFlashDraft-host.swift','Sources/Slotstream/Layers.swift':'Layers-host.swift','Sources/Slotstream/Model.swift':'Model-host.swift'}
originals={name:(R/name).read_bytes()for name in replacements};result={}
try:
 for name,copy in replacements.items():(R/name).write_bytes((P/copy).read_bytes())
 result=build(R,P/'native-host-build',required_gb=10,jobs=4,wait_seconds=0)
 print(json.dumps({k:v for k,v in result.items()if k in ['passed','error','elapsed_seconds']}),flush=True)
finally:
 for name,b in originals.items():(R/name).write_bytes(b)
 for name in ['slotstream','slotstream-checks','mlx.metallib','build-identity.json','build-source.tar.gz']:shutil.copy2(OLD/name,R/'.build/release'/name)
 (P/'restored-host.json').write_text(json.dumps(dict(source_hashes={n:hashlib.sha256((R/n).read_bytes()).hexdigest()for n in originals},baseline_sha256=hashlib.sha256((R/'.build/release/slotstream').read_bytes()).hexdigest()),indent=2))
if not result.get('passed'):raise SystemExit(1)
