from pathlib import Path
P=Path(__file__).resolve().parent
s=(P/'group_bench.py').read_text()
a=s.index("groupbody=groupbody.replace('DECODE'");b=s.index('# Input args',a)
s=s[:a]+'''groupbody=groupbody.replace('''+repr(''' for(uint j=0;j<32;++j){
  uint row=row0+lane,col=k0+j;
  const device uchar* block=w+size_t(row)*RB+(col/BLOCK)*BYTES;
  ws[lane*32+j]=row<OUT?half(DECODE):half(0);
 }''')+''','''+repr(''' uint row=row0+lane,g=k0/32;
 uint2 q= row<OUT ? *reinterpret_cast<const device uint2*>(w+((size_t(row/32)*(IN/32)+g)*32+row%32)*8) : uint2(0);
 half d=row<OUT ? *reinterpret_cast<const device half*>(w+OUT*IN/4+((size_t(row/32)*(IN/64)+g/2)*32+row%32)*2) : half(0);
 for(uint j=0;j<32;++j)ws[lane*32+j]=half(float(int((q[j/16]>>(2*(j%16)))&3)-1)*float(d));''')+''')
'''+s[b:]
s=s.replace("'group_mpp'","'group_mpp_repacked'")
s=s.replace("w=mx.array(np.frombuffer(data,dtype=np.uint8));", """original=np.frombuffer(data,dtype=np.uint8).reshape(G,N,K//64,18)
  q=original[:,:,:,2:].reshape(G,N//32,32,K//32,8).transpose(0,1,3,2,4).reshape(G,-1)
  meta=original[:,:,:,0:2].reshape(G,N//32,32,K//64,2).transpose(0,1,3,2,4).reshape(G,-1)
  packed=mx.array(np.concatenate([q,meta],axis=1));w=mx.array(np.frombuffer(data,dtype=np.uint8));mx.eval(packed);""")
s=s.replace("else [x,w],template", "else [x,packed],template").replace("'group-bench.json'","'group-bench-repacked.json'")
(P/'group_bench_repacked.py').write_text(s)
