from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent));import splash_tiles as s
R=s.R
q=s.clean((s.S/'kernels/common/quant_formats.h').read_text())
q=q[:q.index('// IQ3_S: plane0 word')] + q[q.index('// Q4_0:'):q.index('// MXFP4:')] + q[q.index('template <uint F> struct FmtTwoBit'):q.index('template <uint Bits> struct AffinePlanes;')]
# Only IQ4's table is used by the finite checkpoint formats.
tables='constant constexpr int8_t kIQ4NLValues[16] = {-127,-104,-83,-65,-49,-35,-22,-10,1,13,25,38,53,69,89,113};'
header=s.abi+'\n'+tables+'\n'+q+'\n'+s.clean((s.S/'kernels/common/gguf_staged.h').read_text())
source='''// Adapted from incoai/splash 1482f6bbc2abf12375332725302019594150b6cb,
// runtime/metal/{abi/QuantFormat.h,kernels/common/{quant_formats.h,gguf_staged.h},
// kernels/shared/gguf_repack.metal}. Apache-2.0 and ggml MIT notices in Licenses/.
// The finite deployment keeps only its vector decoders; format metadata and
// byte rearrangement are retained for audit against the upstream layout.
// Swift/MLX owns allocation, dispatch, streaming and lifetime. No Splash runtime.
import MLX

package enum Q2ResidentKernelSources {
    static let header = #"""
'''+header+'''\n"""#
    static let repack = #"""
'''+s.rep+'''\n"""#
    static let matrix = #"""
'''+s.body+'''\n"""#
}
'''
(R/'Sources/Slotstream/Q2ResidentKernelSources.swift').write_text(source)
