import hashlib,json,pathlib,tarfile,subprocess
P=pathlib.Path(__file__).resolve().parent;R=P.parents[1]
paths=set()
for root in ['Sources','apps/macos/Runtime','apps/macos/Presentation','apps/macos/Text','apps/macos/App','apps/macos/CLI','apps/macos/Checks','apps/macos/ComposerChecks','apps/macos/PresentationTests','apps/macos/Resources']:
 paths.update(p for p in (R/root).rglob('*') if p.is_file())
for path in ['Package.swift','Package.resolved','apps/macos/Package.swift','apps/macos/Package.resolved','Tools/prepare_slotstream_build.py','Tools/check_slotstream_mac.sh']:
 paths.add(R/path)
inputs={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest()for p in sorted(paths)}
archive=P/'final-app-source.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz')as tar:
 for p in sorted(paths):tar.add(p,arcname=str(p.relative_to(R)),recursive=False)
output=R/'apps/macos/.build/release'
artifacts={name:hashlib.sha256((output/name).read_bytes()).hexdigest()for name in ['SlotstreamDesktop','slotstream-mac-checks','slotstream-extract','slotstream-home','slotstream-local','mlx.metallib']}
receipt={'sources':inputs,'artifacts':artifacts,'source_archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'native_input_stamp':(output/'.slotstream-native-inputs').read_text(),'swift_version':subprocess.check_output(['swift','--version'],text=True)}
(P/'final-app-identity.json').write_text(json.dumps(receipt,indent=2))
