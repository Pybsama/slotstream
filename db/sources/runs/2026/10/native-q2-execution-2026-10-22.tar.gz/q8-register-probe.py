# Diagnostic: upstream register-MMA idea for the narrow HC Q8 projection.
# Apache-2.0 sgmatrix helper from Splash 1482f6b; no product code change.
from splash_tiles import *
sg=clean((S/'kernels/common/sgmatrix.h').read_text())
source=r'''
uint lane=thread_index_in_simdgroup,sg=simdgroup_index_in_threadgroup;
auto l=sgmatrix::lane_map(lane);uint fm=l.fm,fn=l.fn;
uint base=threadgroup_position_in_grid.x*64+sg*16, row0=threadgroup_position_in_grid.y*8;
uint part=threadgroup_position_in_grid.z,G=IN/32,g0=G*part/PARTS,g1=G*(part+1)/PARTS;
float2 acc[2]={float2(0),float2(0)};
for(uint g=g0;g<g1;++g){
 float2 dot[2]={float2(0),float2(0)};
 for(uint f=0;f<4;++f){
  bfloat2 b=bfloat2(0);
  if(row0+fn<B)b.x=x[(row0+fn)*IN+g*32+f*8+fm];
  if(row0+fn+1<B)b.y=x[(row0+fn+1)*IN+g*32+f*8+fm];
  for(uint nf=0;nf<2;++nf){
   uint c=base+nf*8+fm;size_t at=(size_t(c/64)*G+g)*64+c%64;
   char2 q=*reinterpret_cast<const device char2*>(w+at*32+f*8+fn);
   sgmatrix::mma_acc<bfloat>(dot[nf],bfloat2(float2(q)),b);
  }
 }
 for(uint nf=0;nf<2;++nf){
  uint c=base+nf*8+fm;size_t at=(size_t(c/64)*G+g)*64+c%64;
  float d=float(*reinterpret_cast<const device half*>(w+META+at*2));
  acc[nf]=fma(dot[nf],d,acc[nf]);
 }
}
for(uint nf=0;nf<2;++nf)for(uint i=0;i<2;++i){uint c=base+nf*8+fm,b=row0+fn+i;
 if(c<OUT&&b<B)y[(size_t(part)*B+b)*OUT+c]=acc[nf][i];}
'''
ker=mx.fast.metal_kernel(name='q8_register_probe',input_names=['x','w'],output_names=['y'],source=source,header='#pragma clang fp reassociate(off)\n'+sg)
sw=(R/'Sources/Slotstream/Q2ResidentKernelSources.swift').read_text();prod=sw.split('static let matrix = #"""')[1].split('"""#')[0]
base=mx.fast.metal_kernel(name='q8_staged_control',input_names=['x','w'],output_names=['y'],source=prod,header='#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>\n#pragma clang fp reassociate(off)\n'+header+'\ntypedef FmtQ80 F;')
mx.set_cache_limit(64<<20);rng=np.random.default_rng(713);results=[]
for N,K in [(320,10240),(10240,320),(512,2560)]:
 q=rng.integers(-127,128,(N,K//32,32),dtype=np.int8);d=(rng.random((N,K//32))*0.02).astype(np.float16)
 raw=np.concatenate([d.view(np.uint8).reshape(N,K//32,2),q.view(np.uint8)],axis=-1).reshape(-1)
 n0=N*K;packed=repack(inputs=[mx.array(raw)],template=[('IN',K),('OUT',N),('RB',K//32*34),('FMT',6),('P1',n0),('META',n0)],grid=(N*K//32,1,1),threadgroup=(256,1,1),output_shapes=[(N*K//32*34,)],output_dtypes=[mx.uint8])[0]
 for B in [1,8,17]:
  x=mx.array(rng.normal(size=(B,K)).astype(np.float32),dtype=mx.bfloat16);mx.eval(packed,x)
  ref=np.asarray(x.astype(mx.float32)).astype(np.float64)@(q.astype(np.float64)*d.astype(np.float64)[...,None]).reshape(N,K).T
  for arm in ['staged','register']:
   for parts in ([4] if arm=='staged' and N<1024 and K>=4096 else [1]) if arm=='staged' else [1,4,8]:
    def run():
     call=base if arm=='staged' else ker
     tpl=[('IN',K),('OUT',N),('META',n0),('PARTS',parts)]+([('T',mx.bfloat16),('Y',mx.float32),('P1',n0)] if arm=='staged' else [('B',B)])
     return call(inputs=[x,packed],template=tpl,grid=(N if arm=='staged' else N*2,(B+7)//8,parts),threadgroup=(64 if arm=='staged' else 128,1,1),output_shapes=[(parts,B,N)],output_dtypes=[mx.float32])[0].sum(axis=0)
    timings=[]
    for r in range(5):
     start=time.perf_counter();ys=[run() for _ in range(12)];mx.eval(ys);timings.append((time.perf_counter()-start)/12)
    got=np.asarray(ys[-1]);error=float(np.max(np.abs(got-ref)));relative=float(np.linalg.norm(got-ref)/np.linalg.norm(ref))
    row=dict(N=N,K=K,B=B,arm=arm,parts=parts,ms=statistics.median(timings[2:])*1000,max_error=error,relative_error=relative);results.append(row);print(row,flush=True)
(P/'q8-register-probe.json').write_text(json.dumps(results,indent=2))
