from pathlib import Path
import hashlib,json,subprocess
P=Path(__file__).resolve().parent;R=P.parents[1]
D=R/'.build/checkouts/mlx-swift';f=D/'Source/Cmlx/mlx/mlx/backend/metal/device.cpp'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=D,text=True).strip()
s=f.read_text();(P/'device.cpp.original').write_text(s)
s='#include <mach/mach_time.h>\n#include <cstdio>\n#include <cstdlib>\n#include <mutex>\n#include <vector>\n'+s
needle='void CommandEncoder::commit(std::function<void()> completion) {'
assert s.count(needle)==1
s=s.replace(needle,'''namespace {
static double ss_uptime() {
  static mach_timebase_info_data_t tb=[] { mach_timebase_info_data_t v;mach_timebase_info(&v);return v; }();
  return double(mach_absolute_time()) * tb.numer / tb.denom / 1e9;
}
struct SSTimings {
  struct Span { double commit,start,end,completed;size_t ops,bytes; };
  std::mutex mutex;
  std::vector<Span> spans;
  const char* path=std::getenv("SLOTSTREAM_DIAGNOSTIC_GPU_TIMING");
  ~SSTimings() {
    if(!path)return;
    std::lock_guard<std::mutex> lock(mutex);
    FILE* f=std::fopen(path,"w");if(!f)return;
    std::fprintf(f,"commit,start,end,completed,ops,accounted_input_elements\\n");
    for(const auto& s:spans)std::fprintf(f,"%.9f,%.9f,%.9f,%.9f,%zu,%zu\\n",s.commit,s.start,s.end,s.completed,s.ops,s.bytes);
    std::fclose(f);
  }
};
static SSTimings& ss_timings(){static SSTimings t;return t;}
}

'''+needle+'''
  if(ss_timings().path) {
    double submitted=ss_uptime();size_t ops=buffer_ops_,bytes=buffer_sizes_;
    buffer_->addCompletedHandler([submitted,ops,bytes](MTL::CommandBuffer* b) {
      auto& t=ss_timings();double done=ss_uptime();
      std::lock_guard<std::mutex> lock(t.mutex);
      t.spans.push_back({submitted,b->GPUStartTime(),b->GPUEndTime(),done,ops,bytes});
    });
  }
''')
f.write_text(s)
patch=subprocess.check_output(['git','diff','--',str(f.relative_to(D))],cwd=D)
(P/'gpu-timing.patch').write_bytes(patch)
(P/'gpu-instrumentation-source.json').write_text(json.dumps({'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=D,text=True).strip(),'original_sha256':hashlib.sha256((P/'device.cpp.original').read_bytes()).hexdigest(),'patch_sha256':hashlib.sha256(patch).hexdigest(),'instrumented_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'production_qualified':False},indent=2))
