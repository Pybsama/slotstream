from splash_tiles import *
fixtures={f['format']:f for f in json.loads((R/'.build/native-q2-20261021/format-fixtures.json').read_text())}
results=[];mx.set_cache_limit(128<<20)
for fmt,N,K in [(8,320,10240),(8,10240,320),(12,512,2560),(13,2560,6144),(2,10240,2560),(14,640,2560)]:
 f=fixtures[fmt];fid,F,block,bs,p0,p1,mb,mg=formats[fmt];B=8;rb=K//block*bs;raw=base64.b64decode(f['bytes']);frb=256//block*bs
 w=mx.array(np.frombuffer(b''.join((raw[(i%f['rows'])*frb:((i%f['rows'])+1)*frb]*((K+255)//256))[:rb] for i in range(N)),dtype=np.uint8).copy())
 x=mx.array([(f['input']*((K+255)//256))[:K]]*B,dtype=mx.bfloat16);n0=N*K//32*p0;n1=N*K//32*p1;nm=N*K//32//mg*mb
 packed=repack(inputs=[w],template=[('IN',K),('OUT',N),('RB',rb),('FMT',fid),('P1',n0),('META',n0+n1)],grid=(N*K//32,1,1),threadgroup=(256,1,1),output_shapes=[(n0+n1+nm,)],output_dtypes=[mx.uint8])[0];mx.eval(packed,x)
 source=body.replace('auto payload=F::load(p0,p1);auto meta=F::loadMeta(mt);','''uint part=threadgroup_position_in_grid.z, first=groups*part/PARTS,last=groups*(part+1)/PARTS;
 auto payload=F::load(p0+size_t(first)*64*F::P0,p1+size_t(first)*64*F::P1);auto meta=F::loadMeta(mt+size_t(first/F::MetaGroups)*64*F::MetaBytes);''').replace('g=0;g<groups','g=first;g<last').replace('g+1<groups','g+1<last').replace('y[size_t(batch)*OUT+row]=T(acc[i])','y[(size_t(part)*batchCount+batch)*OUT+row]=float(acc[i])')
 ker=mx.fast.metal_kernel(name='split_'+str(fmt),input_names=['x','w'],output_names=['y'],source=source,header='#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>\n#pragma clang fp reassociate(off)\n'+header+'\ntypedef '+F+' F;')
 ref=None
 for parts in [1,2,4,8,16]:
  if (K//32)%parts:continue
  rounds=[]
  for r in range(5):
   start=time.perf_counter();ys=[]
   for z in range(16):
    y=ker(inputs=[x,packed],template=[('T',mx.bfloat16),('IN',K),('OUT',N),('P1',n0),('META',n0+n1),('PARTS',parts)],grid=(N,1,parts),threadgroup=(64,1,1),output_shapes=[(parts,B,N)],output_dtypes=[mx.float32])[0].sum(axis=0).astype(mx.bfloat16);ys.append(y)
   mx.eval(ys);rounds.append((time.perf_counter()-start)/16)
  if ref is None:ref=ys[-1]
  error=mx.max(mx.abs(ref.astype(mx.float32)-ys[-1].astype(mx.float32))).item();record=dict(format=fmt,N=N,K=K,parts=parts,ms=statistics.median(rounds[2:])*1000,max_delta=error);results.append(record);print(record,flush=True)
(P/'split-bench.json').write_text(json.dumps(results,indent=2))
