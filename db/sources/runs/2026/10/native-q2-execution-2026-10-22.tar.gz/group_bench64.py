import mlx.core as mx,json,time,statistics,base64
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1]
s=(P/'mpp_bench.py').read_text();exec(s[:s.index('fixtures=json.loads')])
f=next(f for f in json.loads((R/'.build/native-q2-20261021/format-fixtures.json').read_text()) if f['format']==42)
source=(R/'Sources/Slotstream/Q2GGUFLinear.swift').read_text().split('let matvec = MLXFast.metalKernel')[1].split('source: """')[1].split('"""')[0]
source=source.replace('\\(format.block)','64').replace('\\(format.bytes)','18').replace('\\(expression)','GgufEmbedQ20::decode(block,col%64)')
# Multi-row matrix tiles retain one weight record per expert.
groupbody=body.replace('uint row0=', 'x += threadgroup_position_in_grid.z * BATCH * IN;\nw += threadgroup_position_in_grid.z * OUT * RB;\ny += threadgroup_position_in_grid.z * BATCH * OUT;\nuint row0=')
groupbody=groupbody.replace('DECODE','GgufEmbedQ20::decode(block,col%64)').replace('BLOCK','64').replace('BYTES','18')
# One complete quant block per stage, half as many barriers.
groupbody=groupbody.replace('2*32*32','2*32*64').replace('sg*32*32','sg*32*64').replace('{32,32}', '{64,32}').replace('{1,32}', '{1,64}').replace('descriptor(8,32,32','descriptor(8,32,64').replace('slice<32,8>','slice<64,8>').replace('slice<32,32>','slice<64,32>').replace('k0+=32','k0+=64').replace('j<32','j<64').replace('ws[lane*32+j]','ws[lane*64+j]')
# Input args are local pointer parameters and can be advanced.
kernels=[mx.fast.metal_kernel(name='group_reference',input_names=['x','w','ids'],output_names=['y'],source=source,header=header),mx.fast.metal_kernel(name='group_mpp64',input_names=['x','w'],output_names=['y'],source=groupbody,header='#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>\n'+header)]
results=[];mx.set_cache_limit(128<<20)
for K,N in [(2560,640),(640,2560)]:
 for B in [1,2,4,8]:
  G=80//B;rb=256//64*18;raw=base64.b64decode(f['bytes']);rowlist=[raw[(i%f['rows'])*rb:((i%f['rows'])+1)*rb] for i in range(N)]
  # K=640 takes whole 64-element quant blocks, not an integral fixture row.
  data=b''.join((r*((K+255)//256))[:K//64*18] for r in rowlist)*G
  import numpy as np
  w=mx.array(np.frombuffer(data,dtype=np.uint8));x=mx.array(np.random.default_rng(42).normal(size=(G*B,K)),dtype=mx.bfloat16);ids=mx.array([i//B for i in range(G*B)],dtype=mx.int32);mx.eval(w,x,ids)
  outputs=[];times=[]
  for i,ker in enumerate(kernels):
   durations=[]
   for r in range(7):
    start=time.perf_counter();ys=[]
    for z in range(8):
     ys.append(ker(inputs=[x,w,ids] if i==0 else [x,w],template=[('T',mx.bfloat16),('IN',K),('OUT',N),('BATCH',B),('XREP',1),('RB',K//64*18)],grid=(32,N,G*B) if i==0 else (((N+63)//64)*64,(B+7)//8,G),threadgroup=(32,4,1) if i==0 else (64,1,1),output_shapes=[(G*B,N)],output_dtypes=[mx.bfloat16])[0])
    mx.eval(ys);durations.append((time.perf_counter()-start)/8)
   times.append(statistics.median(durations[2:])*1000);outputs.append(ys[-1])
  delta=mx.max(mx.abs(outputs[0].astype(mx.float32)-outputs[1].astype(mx.float32))).item()
  rec={'K':K,'N':N,'rows_per_expert':B,'experts':G,'reference_ms':times[0],'mpp_ms':times[1],'max_delta':delta};print(rec,flush=True);results.append(rec);(P/'group-bench64.json').write_text(json.dumps(results,indent=2))
