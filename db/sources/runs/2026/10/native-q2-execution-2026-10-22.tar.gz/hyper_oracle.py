from pathlib import Path
import mlx.core as mx
import numpy as np
import json,time
P=Path(__file__).resolve().parent;R=P.parents[1]
s=(R/'Sources/Slotstream/Q2HyperConnection.swift').read_text()
a=s.split('private static let norm = ')[1].split('source: """')[1].split('"""')[0]
b=s.split('private static let mixing = ')[1].split('source: """')[1].split('"""')[0]
kn=mx.fast.metal_kernel(name='hc_norm_oracle',input_names=['x','norm','inject'],output_names=['normalized','weights'],source=a,header='#pragma clang fp reassociate(off)\n')
km=mx.fast.metal_kernel(name='hc_mix_oracle',input_names=['x','gate'],output_names=['y'],source=b,header='#pragma clang fp reassociate(off)\n')
H=2560;W=H*4;results=[]
for n in [1,8,17]:
 x=mx.array(((np.arange(n*W)*71)%997-498).reshape(n,W)/128,dtype=mx.float32);w=mx.array(((np.arange(W)*11)%61+64)/128,dtype=mx.float32);iw=mx.array(((np.arange(W*4)*17)%97-48).reshape(4,W)/4096,dtype=mx.float32)
 v=x.reshape(n,4,H);norm=(v*mx.rsqrt(mx.mean(v*v,axis=-1,keepdims=True)+1e-6)).reshape(n,W)*w;inj=mx.array(2/(1+np.exp(-(np.array(norm).astype(np.float64)@np.array(iw).astype(np.float64).T)/4)),dtype=mx.float32)
 out=kn(inputs=[x,w,iw],template=[('H',H),('INJECT',True)],grid=(n*1024,1,1),threadgroup=(1024,1,1),output_shapes=[(n,W),(n,4)],output_dtypes=[mx.bfloat16,mx.float32]);mx.eval(out)
 gate=(x/2).astype(mx.bfloat16);mix=km(inputs=[out[0],gate],template=[('H',H)],grid=(H,n,1),threadgroup=(256,1,1),output_shapes=[(n,H)],output_dtypes=[mx.bfloat16])[0];ref=(out[0].astype(mx.float32)*mx.sigmoid(gate.astype(mx.float32))).reshape(n,4,H).mean(axis=1).astype(mx.bfloat16)
 r=dict(rows=n,norm_delta=mx.max(mx.abs(out[0].astype(mx.float32)-norm.astype(mx.bfloat16).astype(mx.float32))).item(),injection_delta=mx.max(mx.abs(inj-out[1])).item(),mix_delta=mx.max(mx.abs(ref.astype(mx.float32)-mix.astype(mx.float32))).item());results.append(r);print(r,flush=True)
 assert r['norm_delta']<=.03125 and r['injection_delta']<1e-5 and r['mix_delta']<=.015625
(P/'hyper-oracle.json').write_text(json.dumps(results,indent=2))
