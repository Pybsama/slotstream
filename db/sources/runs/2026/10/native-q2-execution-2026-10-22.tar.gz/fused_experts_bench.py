from pathlib import Path
import json,time,statistics
import mlx.core as mx
import numpy as np
P=Path(__file__).resolve().parent;R=P.parents[1]
s=(R/'Sources/Slotstream/Q2PackedExperts.swift').read_text()
original=s.split('private static let matrix = ')[1].split('source: """')[1].split('"""')[0]
source=original
weights='const device uchar* weights=w+size_t(slots[tile])*OUT*IN/64*18;'
source=source.replace(weights,'')
source=source.replace('for(ushort i=0;i<acc.get_capacity();++i) acc[i]=0;', '''auto gateValues=op.template get_destination_cooperative_tensor<decltype(as),decltype(bs),float>();
for(uint pass=0;pass<2;++pass){
const device uchar* weights=(pass==0?w:up)+size_t(slots[tile])*OUT*IN/64*18;
for(ushort i=0;i<acc.get_capacity();++i) acc[i]=0;''')
source=source.replace('if(row<OUT) y[(size_t(tile)*8+ij[1])*OUT+row]=T(acc[i]);','''if(pass==0)gateValues[i]=float(bfloat(acc[i]));
else if(row<OUT){float g=gateValues[i];y[(size_t(tile)*8+ij[1])*OUT+row]=T((g/(1.0f+fast::exp2(-1.44269504089f*g)))*float(bfloat(acc[i])));}''')+'\n}'
(P/'fused-experts-source.txt').write_text(source)
header='#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>\n#pragma clang fp reassociate(off)\n'
plain=mx.fast.metal_kernel(name='plain_pair_diagnostic',input_names=['x','w','slots'],output_names=['y'],source=original,header=header)
fused=mx.fast.metal_kernel(name='fused_pair_diagnostic',input_names=['x','w','slots','up'],output_names=['y'],source=source,header=header)
mx.set_cache_limit(128<<20);rng=np.random.default_rng(7);records=[]
for tiles in [10,32,64]:
 N,K=640,2560;rb=N*K//64*18
 raw=rng.integers(0,256,(tiles*2,rb),dtype=np.uint8);raw[:,N*K//4:]=np.tile(np.frombuffer(np.float16(.001).tobytes(),dtype=np.uint8),N*K//64)
 w=mx.array(raw[:tiles].copy());up=mx.array(raw[tiles:].copy());x=mx.array(rng.standard_normal((tiles*8,K)),dtype=mx.bfloat16);slots=mx.arange(tiles,dtype=mx.int32);mx.eval(w,up,x,slots)
 def mat(ker,weights):return ker(inputs=weights,template=[('T',mx.bfloat16),('IN',K),('OUT',N)],grid=(N,tiles,1),threadgroup=(64,1,1),output_shapes=[(tiles*8,N)],output_dtypes=[mx.bfloat16])[0]
 times=[];outs=[]
 for mode in [0,1]:
  rounds=[]
  for r in range(5):
   start=time.perf_counter();ys=[]
   for j in range(16):
    if mode:y=mat(fused,[x,w,slots,up])
    else:
     g=mat(plain,[x,w,slots]).astype(mx.float32);u=mat(plain,[x,up,slots]).astype(mx.float32);y=(g*mx.sigmoid(g)*u).astype(mx.bfloat16)
    ys.append(y)
   mx.eval(ys);rounds.append((time.perf_counter()-start)/16)
  times.append(statistics.median(rounds[2:])*1000);outs.append(ys[-1])
 row=dict(tiles=tiles,separate_ms=times[0],fused_ms=times[1],max_delta=mx.max(mx.abs(outs[0].astype(mx.float32)-outs[1].astype(mx.float32))).item());records.append(row);print(row,flush=True)
(P/'fused-experts-bench.json').write_text(json.dumps(records,indent=2))
