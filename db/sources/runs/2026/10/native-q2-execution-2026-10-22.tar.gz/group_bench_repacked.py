import mlx.core as mx,json,time,statistics,base64
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1]
s=(P/'mpp_bench.py').read_text();exec(s[:s.index('fixtures=json.loads')])
f=next(f for f in json.loads((R/'.build/native-q2-20261021/format-fixtures.json').read_text()) if f['format']==42)
source=(R/'Sources/Slotstream/Q2GGUFLinear.swift').read_text().split('let matvec = MLXFast.metalKernel')[1].split('source: """')[1].split('"""')[0]
source=source.replace('\\(format.block)','64').replace('\\(format.bytes)','18').replace('\\(expression)','GgufEmbedQ20::decode(block,col%64)')
# Multi-row matrix tiles retain one weight record per expert.
groupbody=body.replace('uint row0=', 'x += threadgroup_position_in_grid.z * BATCH * IN;\nw += threadgroup_position_in_grid.z * OUT * RB;\ny += threadgroup_position_in_grid.z * BATCH * OUT;\nuint row0=')
groupbody=groupbody.replace(' for(uint j=0;j<32;++j){\n  uint row=row0+lane,col=k0+j;\n  const device uchar* block=w+size_t(row)*RB+(col/BLOCK)*BYTES;\n  ws[lane*32+j]=row<OUT?half(DECODE):half(0);\n }',' uint row=row0+lane,g=k0/32;\n uint2 q= row<OUT ? *reinterpret_cast<const device uint2*>(w+((size_t(row/32)*(IN/32)+g)*32+row%32)*8) : uint2(0);\n half d=row<OUT ? *reinterpret_cast<const device half*>(w+OUT*IN/4+((size_t(row/32)*(IN/64)+g/2)*32+row%32)*2) : half(0);\n for(uint j=0;j<32;++j)ws[lane*32+j]=half(float(int((q[j/16]>>(2*(j%16)))&3)-1)*float(d));')
# Input args are local pointer parameters and can be advanced.
kernels=[mx.fast.metal_kernel(name='group_reference',input_names=['x','w','ids'],output_names=['y'],source=source,header=header),mx.fast.metal_kernel(name='group_mpp_repacked',input_names=['x','w'],output_names=['y'],source=groupbody,header='#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>\n'+header)]
results=[];mx.set_cache_limit(128<<20)
for K,N in [(2560,640),(640,2560)]:
 for B in [1,2,4,8]:
  G=80//B;rb=256//64*18;raw=base64.b64decode(f['bytes']);rowlist=[raw[(i%f['rows'])*rb:((i%f['rows'])+1)*rb] for i in range(N)]
  # K=640 takes whole 64-element quant blocks, not an integral fixture row.
  data=b''.join((r*((K+255)//256))[:K//64*18] for r in rowlist)*G
  import numpy as np
  original=np.frombuffer(data,dtype=np.uint8).reshape(G,N,K//64,18)
  q=original[:,:,:,2:].reshape(G,N//32,32,K//32,8).transpose(0,1,3,2,4).reshape(G,-1)
  meta=original[:,:,:,0:2].reshape(G,N//32,32,K//64,2).transpose(0,1,3,2,4).reshape(G,-1)
  packed=mx.array(np.concatenate([q,meta],axis=1));w=mx.array(np.frombuffer(data,dtype=np.uint8));mx.eval(packed);x=mx.array(np.random.default_rng(42).normal(size=(G*B,K)),dtype=mx.bfloat16);ids=mx.array([i//B for i in range(G*B)],dtype=mx.int32);mx.eval(w,x,ids)
  outputs=[];times=[]
  for i,ker in enumerate(kernels):
   durations=[]
   for r in range(7):
    start=time.perf_counter();ys=[]
    for z in range(8):
     ys.append(ker(inputs=[x,w,ids] if i==0 else [x,packed],template=[('T',mx.bfloat16),('IN',K),('OUT',N),('BATCH',B),('XREP',1),('RB',K//64*18)],grid=(32,N,G*B) if i==0 else (((N+63)//64)*64,(B+7)//8,G),threadgroup=(32,4,1) if i==0 else (64,1,1),output_shapes=[(G*B,N)],output_dtypes=[mx.bfloat16])[0])
    mx.eval(ys);durations.append((time.perf_counter()-start)/8)
   times.append(statistics.median(durations[2:])*1000);outputs.append(ys[-1])
  delta=mx.max(mx.abs(outputs[0].astype(mx.float32)-outputs[1].astype(mx.float32))).item()
  rec={'K':K,'N':N,'rows_per_expert':B,'experts':G,'reference_ms':times[0],'mpp_ms':times[1],'max_delta':delta};print(rec,flush=True);results.append(rec);(P/'group-bench-repacked.json').write_text(json.dumps(results,indent=2))
