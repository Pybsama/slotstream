from pathlib import Path
import json,time,statistics
import mlx.core as mx
import numpy as np
P=Path(__file__).resolve().parent;R=P.parents[1]
s=(R/'Sources/Slotstream/Q2PackedExperts.swift').read_text()
original=s.split('private static let matrix = ')[1].split('source: """')[1].split('"""')[0]
source=original.replace('threadgroup_position_in_grid.x*64+sg*32','threadgroup_position_in_grid.x*32')
source=source.replace('auto gateValues=op.template get_destination_cooperative_tensor<decltype(as),decltype(bs),float>();','')
source=source.replace('for(uint pass=0;pass<(FUSED?2:1);++pass) {','').replace('(pass==0?w:up)','(sg==0?w:up)')
source=source[:source.rindex('for(ushort i=0;i<acc.get_capacity();++i)')]+'''
threadgroup bfloat* gates=reinterpret_cast<threadgroup bfloat*>(stage);
if(sg==0)for(ushort i=0;i<acc.get_capacity();++i){
 if(!acc.is_valid_element(i))continue;auto ij=acc.get_multidimensional_index(i);
 gates[ij[1]*32+ij[0]]=bfloat(acc[i]);
}
threadgroup_barrier(mem_flags::mem_threadgroup);
if(sg==1)for(ushort i=0;i<acc.get_capacity();++i){
 if(!acc.is_valid_element(i))continue;auto ij=acc.get_multidimensional_index(i);
 uint row=row0+ij[0];float g=float(gates[ij[1]*32+ij[0]]);
 if(row<OUT)y[(size_t(tile)*8+ij[1])*OUT+row]=T((g/(1.0f+fast::exp2(-1.44269504089f*g)))*float(bfloat(acc[i])));
}
'''
(P/'parallel-experts-source.txt').write_text(source)
header='#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>\n#pragma clang fp reassociate(off)\n'
serial=mx.fast.metal_kernel(name='serial_pair',input_names=['x','w','slots','up'],output_names=['y'],source=original,header=header)
parallel=mx.fast.metal_kernel(name='parallel_pair',input_names=['x','w','slots','up'],output_names=['y'],source=source,header=header)
mx.set_cache_limit(128<<20);rng=np.random.default_rng(17);records=[]
for tiles in [10,32,64]:
 N,K=640,2560;rb=N*K//64*18
 raw=rng.integers(0,256,(tiles*2,rb),dtype=np.uint8);raw[:,N*K//4:]=np.tile(np.frombuffer(np.float16(.001).tobytes(),dtype=np.uint8),N*K//64)
 w=mx.array(raw[:tiles].copy());up=mx.array(raw[tiles:].copy());x=mx.array(rng.standard_normal((tiles*8,K)),dtype=mx.bfloat16);slots=mx.arange(tiles,dtype=mx.int32);mx.eval(w,up,x,slots)
 times=[];outs=[]
 for mode,ker in enumerate([serial,parallel]):
  rounds=[]
  for r in range(7):
   start=time.perf_counter();ys=[]
   for j in range(16):
    ys.append(ker(inputs=[x,w,slots,up],template=[('T',mx.bfloat16),('IN',K),('OUT',N),('FUSED',True)],grid=(N*(mode+1),tiles,1),threadgroup=(64,1,1),output_shapes=[(tiles*8,N)],output_dtypes=[mx.bfloat16])[0])
   mx.eval(ys);rounds.append((time.perf_counter()-start)/16)
  times.append(statistics.median(rounds[2:])*1000);outs.append(ys[-1])
 row=dict(tiles=tiles,serial_ms=times[0],parallel_ms=times[1],max_delta=mx.max(mx.abs(outs[0].astype(mx.float32)-outs[1].astype(mx.float32))).item());records.append(row);print(row,flush=True)
(P/'parallel-experts-bench.json').write_text(json.dumps(records,indent=2))
