import argparse,json,os,subprocess,sys,time,ctypes
from pathlib import Path
P=Path(__file__).resolve().parent; ROOT=P.parents[1]
sys.path.insert(0,str(ROOT/'Tools')); from prefill_bench import preflight,vm_snapshot,host_conditions,terminate_child_tree,digest
sys.path.insert(0,str(ROOT/'.build/native-q2-20261021')); from thermal import state
ap=argparse.ArgumentParser();ap.add_argument('--label',required=True);ap.add_argument('--order',default='ABBA');ap.add_argument('--budget',type=float,default=16);ap.add_argument('--case',default='perf-code');ap.add_argument('--kv',default='bf16');ap.add_argument('--native',default=str(ROOT/'.build/native-q2-20261021/native-final/slotstream'));ap.add_argument('--fused-gdn',action='store_true');ap.add_argument('--matched-cache',action='store_true');ap.add_argument('--env',action='append',default=[]);a=ap.parse_args()
case=next(c for c in json.loads((P/'cases.json').read_text()) if c['id']==a.case)
casefile=P/(a.label+'-cases.json');casefile.write_text(json.dumps([case]))
ledger=P/(a.label+'-ledger.json');assert not ledger.exists();events=[]
for i,arm in enumerate(a.order):
 name=f'{a.label}-{i}-{arm}'; out=P/(name+'.json');assert not out.exists()
 before={'vm':preflight(a.budget+4),'thermal':state(),'host':host_conditions()};assert before['thermal']==0,'Thermal state must be nominal'
 env={k:v for k,v in os.environ.items() if not k.startswith(('SLOTSTREAM_','MLX_'))}
 env.update(dict(item.split('=',1) for item in a.env))
 if arm=='A':
  if a.fused_gdn:env['SLOTSTREAM_OPT_GDN_RECORD']='1'
  raw=P/(name+'-raw.json');command=[a.native,'run','--model','smart-q2','--memory-gb',str(a.budget),'--max-context','8192','--vision','off','--max-tokens',str(case['maxTokens']),'--prompt-file',str(P/(a.case+'.txt')),'--greedy','--sample-footprint','--stats-json',str(raw)]
 else:
  tokenfile=P/(a.label+'-tokens.json');assert tokenfile.exists()
  command=[sys.executable,str(P/'upstream_bench.py'),'--memory-gb',str(a.budget),'--verify','auto','--kv',a.kv,'--cases',str(casefile),'--tokens',str(tokenfile),'--output',str(out)]
  if a.matched_cache:command += ['--expert-memory','7340544000','--ple-memory','51200000']
 print('START',name,flush=True);started=time.monotonic()
 with (P/(name+'-launcher.log')).open('x') as log:
  child=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True)
  try:rc=child.wait(timeout=900)
  finally:
   if child.poll() is None:terminate_child_tree(child)
 after={'vm':vm_snapshot(),'thermal':state(),'host':host_conditions()}
 event={'name':name,'arm':arm,'command':command,'before':before,'after':after,'wall_seconds':time.monotonic()-started,'exit_code':rc,'fused_gdn':a.fused_gdn,'matched_cache':a.matched_cache,'environment_overrides':dict(item.split('=',1) for item in a.env)}
 if arm=='A' and raw.exists():
  d=json.loads(raw.read_text());s=d['stats'];event.update(decode_tps=s['decodeTokens']/s['decodeSeconds'],request_seconds=s['requestSeconds'],peak_gb=s['peakMemoryGB'],binary_sha256=digest(Path(a.native)))
  event['raw_result']=raw.name; out.write_text(json.dumps(event,indent=2))
  assert s['peakMemoryGB']<=a.budget and not s['memoryPressureCancelled'] and not s.get('runtimeError')
  tf=P/(a.label+'-tokens.json'); tokens={'runs':[{'id':a.case,'prompt_ids':d['prompt_ids']}]}
  if tf.exists():assert json.loads(tf.read_text())==tokens
  else:tf.write_text(json.dumps(tokens))
 elif out.exists():
  d=json.loads(out.read_text());event['peak_gb']=d['peak_combined_bytes']/1e9
  if d['runs']:
   r=d['runs'][0]; event.update(timings=r['timings'],request_seconds=r['elapsed_seconds'],usage=r['usage'])
 event['paging']=any(after['vm'][k]!=before['vm'][k] for k in ['swapins','swapouts']);event['nominal_thermal']=before['thermal']==after['thermal']==0
 events.append(event);ledger.write_text(json.dumps(events,indent=2));print('END',name,{k:v for k,v in event.items() if k in ['decode_tps','request_seconds','peak_gb','paging','nominal_thermal','exit_code','timings']},flush=True)
 if rc:raise SystemExit(rc)
