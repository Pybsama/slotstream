from pathlib import Path
import mlx.core as mx,time,statistics,json
P=Path(__file__).parent
body=(P/'gdn-tape-kernel.txt').read_text();header=(P/'gdn-tape-header.txt').read_text()
mx.set_cache_limit(128<<20);mx.random.seed(33)
names=['conv','weight','a','b','z','alog','bias','norm','initial'];outs=['y','states','tape_keys','tape_values','tape_decay','tape_beta']
kernels=[mx.fast.metal_kernel(name=f'gdn_size_{i}',input_names=names,output_names=outs,source=body if i==0 else body.replace('17*D','ROWS*D').replace('[17]','[ROWS]'),header=header)for i in [0,1]]
HK,HV,D=16,48,128;C=(2*HK+HV)*D
states=[mx.random.normal((1,HV,D,D))*0.01 for _ in range(36)];mx.eval(states)
records=[]
for count in [1,4,8,17]:
 args=[mx.random.normal((1,count+3,C)).astype(mx.bfloat16),mx.ones((C,4,1),dtype=mx.bfloat16)*0.1,
 mx.zeros((1,count,HV),dtype=mx.bfloat16),mx.zeros((1,count,HV),dtype=mx.bfloat16),mx.zeros((1,count,HV,D),dtype=mx.bfloat16),mx.zeros((HV,)),mx.zeros((HV,),dtype=mx.bfloat16),mx.ones((D,))];mx.eval(args)
 shapes=[(1,count,HV,D),(1,HV,D,D),(1,count,HV,D),(1,count,HV,D),(1,count,HV),(1,count,HV)]
 dtypes=[mx.bfloat16,mx.float32,mx.bfloat16,mx.bfloat16,mx.float32,mx.bfloat16]
 results=[];outputs=[]
 for mode in [0,1]:
  rounds=[]
  for r in range(5):
   start=time.perf_counter();ys=[]
   for state in states:
    ys+=kernels[mode](inputs=[*args,state],template=[('HK',HK),('HV',HV),('RECORD',True),('ROWS',count)],grid=(HV*256,1,1),threadgroup=(256,1,1),output_shapes=shapes,output_dtypes=dtypes)[:2]
   mx.eval(ys);rounds.append((time.perf_counter()-start)*1000/36)
  outputs.append(ys);results.append(statistics.median(rounds[2:]))
 equal=all(bool(mx.all(a==b))for a,b in zip(outputs[0],outputs[1]))
 record={'rows':count,'fixed_ms':results[0],'bounded_ms':results[1],'exact':equal};print(record,flush=True);records.append(record)
(P/'gdn-tile-bench.json').write_text(json.dumps(records,indent=2))
