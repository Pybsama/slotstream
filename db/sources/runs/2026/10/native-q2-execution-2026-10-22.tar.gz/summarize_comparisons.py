import json,pathlib,statistics
P=pathlib.Path(__file__).resolve().parent
output=[]
for f in sorted(P.glob('*-ledger.json')):
 rows=json.loads(f.read_text()); entries=[]
 for x in rows:
  tps=x.get('decode_tps',x.get('timings',{}).get('predicted_per_second'))
  entry={'name':x['name'],'arm':x['arm'],'decode_tps':tps,'request_seconds':x.get('request_seconds'),'peak_gb':x.get('peak_gb'),'paging':x.get('paging'),'nominal_thermal':x.get('nominal_thermal'),'eligible':x.get('exit_code')==0 and x.get('nominal_thermal') is True and x.get('paging') is False,'requested_matched_cache':x.get('matched_cache')}
  result=P/(x.get('raw_result') or x['name']+'.json')
  if result.exists():
   d=json.loads(result.read_text())
   if x['arm']=='A':
    entry['actual_slots']=d.get('effective_pool_slots');entry['prompt_ids']=d.get('prompt_ids')
   else:
    entry['actual_slots']=d.get('status_ready',{}).get('streamed_experts',{}).get('slots')
    if d.get('runs'):entry['prompt_ids']=d['runs'][0].get('prompt_ids')
    entry['eligible'] &= d.get('complete') is True and not d.get('guard_errors')
  entries.append(entry)
 pairs=[];rejected=[]
 for i in range(0,len(entries)-1,2):
  a,b=entries[i:i+2]
  if {a['arm'],b['arm']}!={'A','B'}:continue
  native=a if a['arm']=='A' else b;upstream=b if b['arm']=='B' else a
  checks={'both_completed_clean_nominal':a['eligible'] and b['eligible'],
          'actual_slots_equal':a.get('actual_slots') is not None and a.get('actual_slots')==b.get('actual_slots'),
          'actual_prompt_ids_equal':bool(a.get('prompt_ids')) and a.get('prompt_ids')==b.get('prompt_ids'),
          'matched_recipe_requested':a['requested_matched_cache'] and b['requested_matched_cache']}
  pair={'native':native['name'],'splash':upstream['name'],'checks':checks}
  if all(checks.values()):
   pair.update(native_decode_tps=native['decode_tps'],splash_decode_tps=upstream['decode_tps'],native_to_splash_decode_ratio=native['decode_tps']/upstream['decode_tps']);pairs.append(pair)
  else:rejected.append(pair)
 for x in entries:x.pop('prompt_ids',None)
 output.append({'ledger':f.name,'runs':entries,'eligible_adjacent_matched_pairs':pairs,'excluded_pairs':rejected})
(P/'comparison-summary.json').write_text(json.dumps(output,indent=2))
print(json.dumps([{'ledger':x['ledger'],'pairs':x['eligible_adjacent_matched_pairs']}for x in output if x['eligible_adjacent_matched_pairs']],indent=2))
