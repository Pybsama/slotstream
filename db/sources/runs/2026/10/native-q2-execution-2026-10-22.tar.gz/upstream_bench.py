"""Bounded exact Q2 experiment; no product settings or user apps are changed."""
import argparse,ctypes,fcntl,hashlib,http.client,json,os,signal,subprocess,sys,threading,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'Tools'))
from prefill_bench import preflight,vm_snapshot,host_conditions,terminate_child_tree
P=Path(__file__).parent; OLD=ROOT/'.build/smart-dflash-eval'
BUNDLE=OLD/'upstream/splash-1.4.0-arm64-macos26'
ENGINE=BUNDLE/'engine/splash'
MODEL='ISTA-DASLab/Qwen3.8-Flash-Next-GSQ-RCO-GGUF:Q2_0'
PREPARED=OLD/'upstream-prepared/.resolved/938d6d6879dac79e95a5eae858867e0af230dc252a18266c6aefb6732b65dee7'
PORT=18973

def request(path,body=None,timeout=300):
 c=http.client.HTTPConnection('127.0.0.1',PORT,timeout=timeout)
 try:
  c.request('GET' if body is None else 'POST',path,body=None if body is None else json.dumps(body),headers={'Content-Type':'application/json'})
  r=c.getresponse(); raw=r.read()
  if r.status!=200:raise RuntimeError(f'HTTP {r.status}: {raw[:1000]!r}')
  return json.loads(raw)
 finally:c.close()

def stream(tokens,limit):
 c=http.client.HTTPConnection('127.0.0.1',PORT,timeout=300)
 start=time.monotonic();chunks=[];parts=[];first=None;finish=None;usage=None;metrics=None;timings=None
 try:
  c.request('POST','/v1/completions',json.dumps({'model':MODEL,'prompt':tokens,'temperature':0,'top_p':1,'max_tokens':limit,'stream':True,'stream_options':{'include_usage':True}}),headers={'Content-Type':'application/json'})
  r=c.getresponse()
  if r.status!=200:raise RuntimeError(f'HTTP {r.status}: {r.read()[:1000]!r}')
  done=False
  while line:=r.readline():
   if time.monotonic()-start>600:raise RuntimeError('request exceeded 600 seconds')
   if not line.startswith(b'data:'):continue
   raw=line[5:].strip()
   if raw==b'[DONE]':done=True;break
   chunk=json.loads(raw);elapsed=time.monotonic()-start;chunks.append({'elapsed_seconds':elapsed,'chunk':chunk})
   if 'error' in chunk:raise RuntimeError(str(chunk['error']))
   for choice in chunk.get('choices',[]):
    value=choice.get('text','')
    if value:
     if first is None:first=elapsed
     parts.append(value)
    if choice.get('finish_reason'):finish=choice['finish_reason']
   usage=chunk.get('usage') or usage;metrics=chunk.get('metrics') or metrics;timings=chunk.get('timings') or timings
  if not done or not finish or not usage:raise RuntimeError('stream ended without completion/usage')
  return {'text':''.join(parts),'finish_reason':finish,'usage':usage,'metrics':metrics,'timings':timings,'elapsed_seconds':time.monotonic()-start,'client_ttft_seconds':first,'chunks':chunks}
 finally:c.close()

class RUsage(ctypes.Structure):
 _fields_=[('uuid',ctypes.c_uint8*16)]+[(n,ctypes.c_uint64) for n in ('user_time','system_time','pkg_idle_wkups','interrupt_wkups','pageins','wired_size','resident_size','phys_footprint','proc_start_abstime','proc_exit_abstime','child_user_time','child_system_time','child_pkg_idle_wkups','child_interrupt_wkups','child_pageins','child_elapsed_abstime','diskio_bytesread','diskio_byteswritten')]

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--memory-gb',type=float,default=10);ap.add_argument('--verify',choices=['all','auto'],default='auto');ap.add_argument('--kv',choices=['bf16','int8'],default='int8');ap.add_argument('--cases',type=Path,required=True);ap.add_argument('--tokens',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--context',type=int,default=8192);ap.add_argument('--expert-memory',type=int);ap.add_argument('--ple-memory',type=int);a=ap.parse_args()
 assert 10<=a.memory_gb<=40 and not a.output.exists()
 assert not (BUNDLE/'engine/host-step.metallib').exists(),'No spin library may be enabled'
 assert json.loads((OLD/'tokenizer-identity.json').read_text())['pass']
 cases=json.loads(a.cases.read_text());base={r['id']:r['prompt_ids'] for r in json.loads(a.tokens.read_text())['runs']}
 assert cases and len(cases)<=100 and all(c['id'] in base and 1<=c['maxTokens']<=4096 for c in cases)
 before=preflight(a.memory_gb+4)
 lock=open(os.environ.get('SLOTSTREAM_MODEL_LOCK_PATH') or f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 command=[str(BUNDLE/'python/bin/python3'),'-m','server.server',str(PREPARED),'--model',MODEL,'--binary',str(ENGINE),'--host','127.0.0.1','--port',str(PORT),'--max-memory',str(int(a.memory_gb*1e9)),'--max-context',str(a.context),'--max-cache-disk','0','--verify-rows',a.verify,'--kv-format',a.kv,'--disable-ane','--allow-idle-sleep','--idle-release','off']
 if a.expert_memory is not None:command += ['--expert-memory',str(a.expert_memory)]
 if a.ple_memory is not None:command += ['--ple-memory',str(a.ple_memory)]
 receipt={'method':'splash-1.4.0-q2-dflash2','command':command,'memory_gb':a.memory_gb,'budget_semantics':'Splash flag bounds Metal allocations; separately guard total engine plus frontend footprint at the requested budget','physical_limit_bytes':int(a.memory_gb*1e9),'verify_rows':a.verify,'kv_format':a.kv,'spin_disabled':True,'engine_sha256':hashlib.sha256(ENGINE.read_bytes()).hexdigest(),'cases_sha256':hashlib.sha256(a.cases.read_bytes()).hexdigest(),'host_before':host_conditions(),'vm_before':before,'runs':[],'complete':False,'memory_samples':[],'peak_engine_bytes':0,'peak_frontend_bytes':0,'peak_combined_bytes':0}
 stop=threading.Event();process=None;log=a.output.with_suffix('.log').open('x');errors=[]
 def save():
  temp=a.output.with_suffix('.partial');temp.write_text(json.dumps(receipt,ensure_ascii=False,indent=2));os.replace(temp,a.output)
 def observe():
  lib=ctypes.CDLL('/usr/lib/libproc.dylib');lib.proc_pid_rusage.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.c_void_p];lib.proc_pid_rusage.restype=ctypes.c_int
  started=time.monotonic();lastvm=0
  try:
   while not stop.wait(.25):
    if process.poll() is not None:return
    children=subprocess.run(['pgrep','-P',str(process.pid)],capture_output=True,text=True,timeout=3)
    values={}
    for pid in [process.pid,*map(int,children.stdout.split())]:
     data=RUsage()
     if lib.proc_pid_rusage(pid,2,ctypes.byref(data))==0:values[pid]=data.phys_footprint
    frontend=values.get(process.pid,0);engine=sum(v for k,v in values.items() if k!=process.pid);total=frontend+engine
    receipt['peak_engine_bytes']=max(engine,receipt['peak_engine_bytes']);receipt['peak_frontend_bytes']=max(frontend,receipt['peak_frontend_bytes']);receipt['peak_combined_bytes']=max(total,receipt['peak_combined_bytes'])
    sample={'seconds':time.monotonic()-started,'frontend_bytes':frontend,'engine_bytes':engine,'combined_bytes':total};receipt['memory_samples'].append(sample)
    if total>receipt['physical_limit_bytes']:raise RuntimeError('combined process physical-memory ceiling exceeded')
    if time.monotonic()-lastvm>2:
     state=vm_snapshot();sample['reclaimable_bytes']=state['reclaimable_bytes'];lastvm=time.monotonic()
     if state['reclaimable_bytes']<1e9:raise RuntimeError('less than 1 GB reclaimable remains')
  except Exception as e:
   errors.append(str(e))
   try:os.killpg(process.pid,signal.SIGINT)
   except ProcessLookupError:pass
 observer=threading.Thread(target=observe,daemon=True)
 try:
  if vm_snapshot()['reclaimable_bytes']<(a.memory_gb+4)*1e9:raise RuntimeError('headroom fell before launch')
  process=subprocess.Popen(command,cwd=BUNDLE,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);receipt['pid']=process.pid;observer.start();start=time.monotonic()
  for _ in range(360):
   if process.poll() is not None:raise RuntimeError('Splash exited before ready: '+str(errors))
   try:
    if request('/ready',timeout=2):break
   except Exception:pass
   time.sleep(1)
  else:raise RuntimeError('readiness timeout')
  receipt['startup_seconds']=time.monotonic()-start;receipt['status_ready']=request('/status');save()
  for case in cases:
   vm0=vm_snapshot();status0=request('/status');tokens=base[case['id']]
   row={'id':case['id'],'prompt_ids':tokens,'status_before':status0,**stream(tokens,case['maxTokens'])}
   row['status_after']=request('/status');vm1=vm_snapshot();row['swapins_delta']=vm1['swapins']-vm0['swapins'];row['swapouts_delta']=vm1['swapouts']-vm0['swapouts']
   receipt['runs'].append(row);save();print(case['id'],row['usage'],row['timings'],flush=True)
   if errors:raise RuntimeError(str(errors))
  receipt['complete']=True
 except Exception as e:receipt['error']=f'{type(e).__name__}: {e}';raise
 finally:
  stop.set()
  if process is not None:
   if process.poll() is None:terminate_child_tree(process)
   receipt['exit_code']=process.returncode
  if observer.ident:observer.join(timeout=5)
  receipt['guard_errors']=errors;receipt['vm_after']=vm_snapshot();receipt['host_after']=host_conditions();save();log.close();lock.close()

if __name__=='__main__':main()
