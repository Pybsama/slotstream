import json, pathlib, subprocess, sys
P=pathlib.Path(__file__).resolve().parent
R=P.parents[1]
binary=P/'native-packed-v17/slotstream'
native=json.loads((P/'packed-v17-quality.json').read_text())
assert native['complete']
cases=[c for c in json.loads((R/'.build/native-q2-20261021/final-v3-cases.json').read_text()) if c['id'].startswith('q-code-')]
(P/'final-quality-remaining-cases.json').write_text(json.dumps(cases,indent=2))
commands=[]
for model,name in [('qwen38-flash-next-mlx-4bit','smart'),('qwen38-flash-next-gsq-q2','q2'),('qwen36-35b-a3b-4bit','fast')]:
 label='final-v17-state-'+name
 commands.append((label,[sys.executable,str(P/'guarded_run.py'),'--label',label,'--budget','10','--',str(binary),'optimization-state-check','--variant','state-recovery-lineage','--model',str(pathlib.Path.home()/'.slotstream/models'/model),'--json']))
results=[]
for label,command in commands:
 print('START',label,flush=True)
 with (P/(label+'-driver.log')).open('x') as log:
  r=subprocess.run(command,cwd=R,stdout=log,stderr=subprocess.STDOUT)
 results.append({'label':label,'command':command,'exit_code':r.returncode})
 (P/'final-checks-state-progress.json').write_text(json.dumps(results,indent=2))
 print('END',label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
