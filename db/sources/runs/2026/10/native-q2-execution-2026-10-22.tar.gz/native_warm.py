import json,sys,os,time,subprocess,http.client,hashlib
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight,terminate_child_tree,vm_snapshot
binary=P/'native-packed-v8/slotstream';port=18974
out=P/'packed-v8-warm16.json';assert not out.exists();preflight(20)
command=[str(binary),'serve','--model','smart-q2','--memory-gb','16','--max-context','8192','--vision','off','--port',str(port),'--no-prefix-cache']
record={'command':command,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'runs':[],'complete':False,'before':vm_snapshot()}
def request(path,body=None):
 c=http.client.HTTPConnection('127.0.0.1',port,timeout=300)
 try:
  c.request('POST' if body else 'GET',path,json.dumps(body) if body else None,{'Content-Type':'application/json'});r=c.getresponse();data=r.read()
  if r.status!=200:raise RuntimeError(str(r.status)+': '+data[:500].decode())
  return json.loads(data)
 finally:c.close()
start=time.monotonic()
with (P/'packed-v8-warm16-server.log').open('x') as log:
 child=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:
  for i in range(240):
   if child.poll() is not None:raise RuntimeError('Server exited')
   try:
    status=request('/api/ps');break
   except Exception:time.sleep(.5)
  else:raise RuntimeError('ready timeout')
  record['startup_seconds']=time.monotonic()-start;record['status_ready']=status
  cases=json.loads((P/'cases.json').read_text());case=cases[0]
  for i in range(4):
   before=vm_snapshot();t=time.monotonic()
   reply=request('/api/generate',dict(model='smart-q2',prompt=case['prompt'],think=False,stream=False,options=dict(temperature=0,num_predict=512,seed=1)))
   after=vm_snapshot();assert reply['prompt_eval_count']==80 and reply['eval_count']==512
   row=dict(index=i,reply=reply,seconds=time.monotonic()-t,before=before,after=after,tps=reply['eval_count']*1e9/reply['eval_duration']);record['runs'].append(row);out.write_text(json.dumps(record,indent=2));print(i,row['tps'],row['seconds'],flush=True)
  record['complete']=True
 finally:
  if child.poll() is None:terminate_child_tree(child)
  record['after']=vm_snapshot();out.write_text(json.dumps(record,indent=2))
