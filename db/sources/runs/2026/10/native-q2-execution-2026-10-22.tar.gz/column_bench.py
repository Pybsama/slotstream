from pathlib import Path
import re,time,json,statistics
import mlx.core as mx
import numpy as np
P=Path(__file__).resolve().parent;R=P.parents[1]
s=(R/'Sources/Slotstream/Q2PackedExperts.swift').read_text()
source=s.split('private static let matrix = ')[1].split('source: """')[1].split('"""')[0]
branch='''
uint live=counts[tile];
if(live<=2){
 uint row=row0+lane;float sums[2]={0,0};
 for(uint g=0;g<IN/32;++g){
  uint2 code=*reinterpret_cast<const device uint2*>(weights+((size_t(row/32)*(IN/32)+g)*32+row%32)*8);
  half d=*reinterpret_cast<const device half*>(weights+OUT*IN/4+((size_t(row/32)*(IN/64)+g/2)*32+row%32)*2);
  half4 values[8];
  for(uint i=0;i<8;++i){uint4 shifts=uint4(0,2,4,6)+((i%4)*8);values[i]=half4((int4((uint4(code[i/4])>>shifts)&3)-1))*d;}
  for(uint r=0;r<live;++r){
   const device uint4 *xr=reinterpret_cast<const device uint4*>(x+(size_t(tile)*8+r)*IN+g*32);float sum=0;
   #pragma unroll
   for(uint i=0;i<8;++i){uint4 q=xr[i/2];float4 a=float4(as_type<bfloat4>(i%2?q.zw:q.xy)),v=float4(values[i]);sum=sum+v.x*a.x;sum=sum+v.y*a.y;sum=sum+v.z*a.z;sum=sum+v.w*a.w;}
   sums[r]+=sum;
  }
 }
 for(uint r=0;r<8;++r)y[(size_t(tile)*8+r)*OUT+row]=r<live?T(sums[r]):T(0);
 return;
}
'''
updated=source.replace('threadgroup half stage[2*2*32*32];',branch+'\nthreadgroup half stage[2*2*32*32];')
(P/'column-branch.txt').write_text(branch)
mx.set_cache_limit(128<<20);results=[]
rng=np.random.default_rng(7)
for N,K in [(640,2560),(2560,640)]:
 tiles=64;rb=N*K//64*18
 # Legal packed records: codes then finite FP16 scales per record.
 raw=rng.integers(0,256,(tiles,rb),dtype=np.uint8);raw[:,N*K//4:]=np.tile(np.frombuffer(np.float16(.001).tobytes(),dtype=np.uint8),N*K//64)
 w=mx.array(raw);x=mx.array(rng.standard_normal((tiles*8,K)),dtype=mx.bfloat16);slots=mx.arange(tiles,dtype=mx.int32);mx.eval(w,x,slots)
 kernels=[mx.fast.metal_kernel(name='expert_mpp',input_names=['x','w','slots'],output_names=['y'],source=source,header='#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>\n'),mx.fast.metal_kernel(name='expert_column',input_names=['x','w','slots','counts'],output_names=['y'],source=updated,header='#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>\n#pragma clang fp reassociate(off)\n')]
 for live in [1,2,3,8]:
  counts=mx.full((tiles,),live,dtype=mx.int32);times=[];outs=[]
  for i,ker in enumerate(kernels):
   rounds=[]
   for r in range(5):
    start=time.perf_counter();ys=[ker(inputs=[x,w,slots]+([counts] if i else []),template=[('T',mx.bfloat16),('IN',K),('OUT',N)],grid=(N,tiles,1),threadgroup=(64,1,1),output_shapes=[(tiles*8,N)],output_dtypes=[mx.bfloat16])[0] for _ in range(12)];mx.eval(ys);rounds.append((time.perf_counter()-start)/12)
   times.append(statistics.median(rounds[2:]));outs.append(ys[-1].reshape(tiles,8,N)[:,:live,:])
  err=mx.max(mx.abs(outs[0].astype(mx.float32)-outs[1].astype(mx.float32))).item();v=dict(N=N,K=K,live=live,mpp_ms=times[0]*1000,column_ms=times[1]*1000,max_delta=err);results.append(v);print(v,flush=True)
(P/'column-bench.json').write_text(json.dumps(results,indent=2))
