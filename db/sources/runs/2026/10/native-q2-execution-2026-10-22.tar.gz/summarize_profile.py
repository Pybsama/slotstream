import json,sys,statistics,collections
x=json.load(open(sys.argv[1]))
for width in [1,2,4,8]:
 for traced in [False,True]:
  rows=[r for r in x["runs"] if r["width"]==width and r["traced"]==traced and r["round"]>0]
  if not rows:continue
  print(width,traced,"wall",round(statistics.median(r["seconds"] for r in rows)*1000,2),"io",round(statistics.median(r["io_seconds"] for r in rows)*1000,2),"tail",round(statistics.median(r["trailing_seconds"] for r in rows)*1000,2),"delta",max(r["max_logit_difference"] for r in rows))
  if traced:
   totals=collections.defaultdict(list)
   for r in rows:
    phases=collections.defaultdict(float)
    for p in r["phases"]:
     for k in ["host_seconds","eval_seconds"]:phases[p["phase"]+"/"+k]+=p[k]*1000
    for k,v in phases.items():totals[k].append(v)
   print(sorted([(k,round(statistics.median(v),2)) for k,v in totals.items()],key=lambda x:-x[1]))
