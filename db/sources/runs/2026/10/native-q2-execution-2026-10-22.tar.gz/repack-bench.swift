import Foundation
import Dispatch
func repackCPU(_ raw: UnsafeRawPointer, into output: UnsafeMutableRawPointer,
                                  rows: Int, columns: Int) {
        precondition(rows.isMultiple(of: 32) && columns.isMultiple(of: 64))
        let blocks = columns / 64
        for tile in 0..<(rows / 32) {
            for block in 0..<blocks {
                let codes = (tile * blocks * 2 + block * 2) * 32 * 8
                let scales = rows * columns / 4 + (tile * blocks + block) * 32 * 2
                for lane in 0..<32 {
                    let source = ((tile * 32 + lane) * blocks + block) * 18
                    output.storeBytes(of: raw.loadUnaligned(fromByteOffset: source + 2, as: UInt64.self),
                        toByteOffset: codes + lane * 8, as: UInt64.self)
                    output.storeBytes(of: raw.loadUnaligned(fromByteOffset: source + 10, as: UInt64.self),
                        toByteOffset: codes + 256 + lane * 8, as: UInt64.self)
                    output.storeBytes(of: raw.loadUnaligned(fromByteOffset: source, as: UInt16.self),
                        toByteOffset: scales + lane * 2, as: UInt16.self)
                }
            }
        }
    }

let piece=460800, count=512
let raw=UnsafeMutableRawPointer.allocate(byteCount:piece*count,alignment:16384)
let out=UnsafeMutableRawPointer.allocate(byteCount:piece*count,alignment:16384)
raw.initializeMemory(as:UInt8.self,repeating:37,count:piece*count)
out.initializeMemory(as:UInt8.self,repeating:0,count:piece*count)
for lanes in [1,4,8,12,16,24,32] {
 var times:[Double]=[]
 for _ in 0..<5 {
  let started=DispatchTime.now().uptimeNanoseconds
  DispatchQueue.concurrentPerform(iterations:lanes){lane in
   for index in stride(from:lane,to:count,by:lanes){
    repackCPU(raw+index*piece,into:out+index*piece,rows:640,columns:2560)
   }
  }
  times.append(Double(DispatchTime.now().uptimeNanoseconds-started)/1e9)
 }
 print(lanes,times,Double(piece*count)/times.sorted()[2]/1e9)
}
print(out.load(as:UInt8.self))
raw.deallocate();out.deallocate()
