import json,pathlib
P=pathlib.Path(__file__).resolve().parent
source='packed-v17-quality.json';d=json.loads((P/source).read_text());rows={r['id']:r for r in d['runs']}
checks={
 'recall':rows['conversation-recall']['text'].strip()=='CEDAR-2481',
 'cancelled':len(rows['cancel']['tokens'])==12 and rows['cancel']['callbacks']==12,
 'after_cancel':json.loads(rows['after-cancel']['text'])=={'ok':True},
 'stop':rows['stop-string']['text'].strip()=='one two three',
 'tool':rows['native-tool']['tool_calls']==[{'arguments_json':'{"key":"CEDAR-2481"}','name':'lookup_record'}] and not rows['native-tool']['malformed_tool_call'],
 'streams':all(r['streamed']==r['text'] for r in rows.values()),
 'bounded':all(r['stats']['peakMemoryGB']<=16 and not r['stats'].get('runtimeError') and not r['stats'].get('memoryPressureCancelled') for r in rows.values()),
 'long_retrieval':all(json.loads(rows[k]['text'])=={'audit_code':'PINE-3926'} for k in ['long-retrieval','long-retrieval-repeat']),
 'prefix_reuse':rows['long-retrieval-repeat']['stats']['reusedPrefixTokens']>0,
}
grade=json.loads((P/'packed-v17-quality-grade.json').read_text())[0]
upstream=json.loads((P/'final-splash-quality-grade.json').read_text())[0]
out={'source':source,'requests':len(rows),'checks':checks,'semantic':grade['semantic'],'strict':grade['strict'],'quality_cases':grade['total'],'quality_failures':[r['id'] for r in grade['rows'] if not r['semantic']], 'upstream_semantic':upstream['semantic'],'upstream_strict':upstream['strict'],'upstream_continuous_memory_gate':False,'complete':d['complete'] and len(rows)==32 and all(checks.values())}
(P/'final-quality-audit.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2));assert out['complete']
