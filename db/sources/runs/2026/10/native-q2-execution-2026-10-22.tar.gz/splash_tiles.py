from pathlib import Path
import re,json,base64,time,statistics
import mlx.core as mx
import numpy as np
P=Path(__file__).resolve().parent;R=P.parents[1];S=Path('/tmp/slotstream-splash-review.EJTswU/splash/runtime/metal')
def clean(s): return re.sub(r'^#(?:pragma once|include "[^"\n]+")\s*$', '',s,flags=re.M)
abi=clean((S/'abi/QuantFormat.h').read_text())
# Keep upstream format metadata and vector decoders unchanged for this diagnostic.
header='\n'.join(clean((S/p).read_text()) for p in ['abi/QuantFormat.h','abi/QuantTables.h','kernels/common/quant_formats.h','kernels/common/gguf_staged.h'])
rep=clean((S/'kernels/shared/gguf_repack.metal').read_text().split('kernel void gguf_repack(')[0])
repack=mx.fast.metal_kernel(name='splash_repack_diagnostic',input_names=['w'],output_names=['y'],header=abi+'\n'+rep,source='''
uint t=thread_position_in_grid.x;uint G=IN/32;if(t>=OUT*G)return;
uint n=t/G,g=t%G;
gguf_repack_group(w+size_t(n)*RB,FMT,G,n,g,y,y+P1,y+META);
''')
body='''
using namespace mpp::tensor_ops;
uint lane=thread_index_in_simdgroup,sg=simdgroup_index_in_threadgroup;
uint row0=threadgroup_position_in_grid.x*64+sg*32;
uint b0=threadgroup_position_in_grid.y*8;uint batchCount=x_shape[0];
threadgroup half stages[2*2*32*32];threadgroup half2 table[256];
quant_pair_table<F>(table,thread_index_in_threadgroup,64);
threadgroup half *ws=stages+sg*2*32*32;
auto a=tensor(const_cast<device T*>(x)+b0*IN,dextents<int,2>{IN,min(8,int(batchCount-b0))},array<int,2>{1,IN});
tensor<threadgroup half,dextents<int,2>,tensor_inline> b(ws,dextents<int,2>{32,32},array<int,2>{1,32});
tensor<threadgroup half,dextents<int,2>,tensor_inline> b1(ws+32*32,dextents<int,2>{32,32},array<int,2>{1,32});
constexpr auto desc=matmul2d_descriptor(8,32,32,false,true,false,matmul2d_descriptor::mode::multiply_accumulate);
matmul2d<desc,execution_simdgroups<1>> op;
auto as=a.template slice<32,8>(0,0);auto bs=b.template slice<32,32>(0,0);auto bs1=b1.template slice<32,32>(0,0);
auto acc=op.template get_destination_cooperative_tensor<decltype(as),decltype(bs),float>();
for(ushort i=0;i<acc.get_capacity();++i)acc[i]=0;
uint row=row0+lane,groups=IN/32;
device uchar* p0=const_cast<device uchar*>(w)+(size_t(row/64)*groups*64+row%64)*F::P0;
device uchar* p1=const_cast<device uchar*>(w)+P1+(size_t(row/64)*groups*64+row%64)*F::P1;
device uchar* mt=const_cast<device uchar*>(w)+META+(size_t(row/64)*(groups/F::MetaGroups)*64+row%64)*F::MetaBytes;
auto payload=F::load(p0,p1);auto meta=F::loadMeta(mt);
for(uint g=0;g<groups;++g){
 dequant32<F>(payload,meta,g%F::MetaGroups,table,ws+(g%2)*32*32+lane*32);
 simdgroup_barrier(mem_flags::mem_threadgroup);
 if(g+1<groups){payload=F::load(p0+size_t(g+1)*64*F::P0,p1+size_t(g+1)*64*F::P1);
 if((g+1)/F::MetaGroups!=g/F::MetaGroups)meta=F::loadMeta(mt+size_t((g+1)/F::MetaGroups)*64*F::MetaBytes);}
 auto at=a.template slice<32,8>(g*32,0);
 if(g%2)op.run(at,bs1,acc);else op.run(at,bs,acc);
}
for(ushort i=0;i<acc.get_capacity();++i){
 if(!acc.is_valid_element(i))continue;
 auto ij=acc.get_multidimensional_index(i);uint row=row0+ij[0],batch=b0+ij[1];
 if(row<OUT&&batch<batchCount)y[size_t(batch)*OUT+row]=T(acc[i]);
}
'''
formats={2:(15,'FmtQ40',32,18,16,0,2,1),6:(39,'FmtQ50',32,22,16,4,2,1),8:(6,'FmtQ80',32,34,32,0,2,1),11:(5,'FmtQ3K',256,110,8,4,16,8),12:(0,'FmtQ4K',256,144,16,0,16,8),13:(3,'FmtQ5K',256,176,16,4,16,8),14:(4,'FmtQ6K',256,210,16,8,20,8),20:(2,'FmtIQ4NL',32,18,16,0,2,1),23:(1,'FmtIQ4XS',256,136,16,0,8,8),42:(43,'FmtTwoBit<GGUF_FMT_Q20>',64,18,8,0,2,2)}
dec={2:'GgufEmbedQ40',6:'GgufEmbedQ50',8:'GgufEmbedQ80',11:'GgufEmbedQ3K',12:'GgufEmbedQ4K',13:'GgufEmbedQ5K',14:'GgufEmbedQ6K',20:'GgufEmbedIQ4NL',23:'GgufEmbedIQ4XS',42:'GgufEmbedQ20'}
rawheader=(R/'Sources/Slotstream/Q2GGUFKernelSources.swift').read_text().split('static let header = #"""')[1].split('"""#')[0]
oldsource=(R/'Sources/Slotstream/Q2GGUFLinear.swift').read_text().split('let matmul = MLXFast.metalKernel')[1].split('source: """')[1].split('"""')[0]
if __name__=='__main__':
 fixtures=json.loads((R/'.build/native-q2-20261021/format-fixtures.json').read_text()); results=[];mx.set_cache_limit(128<<20)
 for f in fixtures:
  fmt=f['format']
  if fmt not in formats:continue
  fid,F,block,bs,p0,p1,mb,mg=formats[fmt]
  # Actual GDN input geometry, then small HC-down geometry for Q8_0.
  for N,K in ([(10240,2560),(320,10240)] if fmt==8 else [(10240,2560)]):
   B=8;rb=K//block*bs;raw=base64.b64decode(f['bytes']);frb=256//block*bs
   w=mx.array(np.frombuffer(b''.join(raw[(i%f['rows'])*frb:((i%f['rows'])+1)*frb]*(K//256) for i in range(N)),dtype=np.uint8).copy())
   x=mx.array([f['input']*(K//256)]*B,dtype=mx.bfloat16);n0=N*K//32*p0;n1=N*K//32*p1;nm=N*K//32//mg*mb
   packed=repack(inputs=[w],template=[('IN',K),('OUT',N),('RB',rb),('FMT',fid),('P1',n0),('META',n0+n1)],grid=(N*K//32,1,1),threadgroup=(256,1,1),output_shapes=[(n0+n1+nm,)],output_dtypes=[mx.uint8])[0];mx.eval(w,x,packed)
   old=oldsource.replace('\\(format.block)',str(block)).replace('\\(format.bytes)',str(bs)).replace('\\(expression)',f'{dec[fmt]}::decode(block, col % {block})')
   kernels=[mx.fast.metal_kernel(name='old_'+str(fmt),input_names=['x','w'],output_names=['y'],source=old,header='#include <metal_simdgroup_matrix>\n'+rawheader),mx.fast.metal_kernel(name='upstream_tile_'+str(fmt),input_names=['x','w'],output_names=['y'],source=body,header='#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>\n#pragma clang fp reassociate(off)\n'+header+'\ntypedef '+F+' F;')]
   times=[];outs=[]
   for i,ker in enumerate(kernels):
    rounds=[]
    for r in range(5):
     start=time.perf_counter();ys=[ker(inputs=[x,w if i==0 else packed],template=[('T',mx.bfloat16),('IN',K),('OUT',N),('RB',rb),('P1',n0),('META',n0+n1)],grid=(((N+31)//32)*128,(B+7)//8,1) if i==0 else (((N+63)//64)*64,(B+7)//8,1),threadgroup=(128,1,1) if i==0 else (64,1,1),output_shapes=[(B,N)],output_dtypes=[mx.bfloat16])[0] for z in range(4)]
     mx.eval(ys);rounds.append((time.perf_counter()-start)/4)
    times.append(statistics.median(rounds[2:])*1000);outs.append(ys[-1])
   error=mx.max(mx.abs(outs[0].astype(mx.float32)-outs[1].astype(mx.float32))).item();record={'format':fmt,'N':N,'K':K,'old_ms':times[0],'mpp_ms':times[1],'max_delta':error};results.append(record);print(record,flush=True)
   (P/'splash-tiles.json').write_text(json.dumps(results,indent=2))
