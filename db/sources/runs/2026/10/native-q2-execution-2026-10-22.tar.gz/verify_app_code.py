import pathlib,json,subprocess,sys,resource,hashlib
p=pathlib.Path(__file__).resolve().parent;r=p.parents[1]
source=p/'app-real-q2-final/Sources/sum_to.py';data=source.read_text()
original=(r/'apps/macos/Fixtures/capabilities/sum_to.py').read_text()
assert data in [original.replace('range(n)',x) for x in ['range(n + 1)','range(n+1)','range(1, n + 1)','range(1,n+1)']]
def bounds():resource.setrlimit(resource.RLIMIT_CPU,(2,2))
out=subprocess.run([sys.executable,'-I','-c',data+'\nfor n in [0,1,2,5,17,100]:\n assert sum_to(n)==n*(n+1)//2\nprint("PASS: approved sum_to edit executes correctly for six boundaries")'],capture_output=True,text=True,timeout=5,preexec_fn=bounds)
receipt=dict(sha256=hashlib.sha256(source.read_bytes()).hexdigest(),exit_code=out.returncode,stdout=out.stdout,stderr=out.stderr,cpu_limit_seconds=2,wall_timeout_seconds=5,inputs=[0,1,2,5,17,100],scope='Exact allowlisted minimal fixture edit, fixed bounded inputs. Earlier RLIMIT_AS attempt failed in macOS preexec and did not execute the code.')
(p/'final-app-code-execution.json').write_text(json.dumps(receipt,indent=2));assert out.returncode==0;print(out.stdout)
f=p/'measurement-body.md';s=f.read_text().replace('These are development-app functional checks, not signed-release certification','The approved minimal code edit also passes six bounded execution cases.\nThese are development-app functional checks, not signed-release certification');s=s.replace('one scheduler rewrite will remove the entire gap.','one scheduler rewrite will remove the entire gap. A final isolated Q8\nregister-MMA adaptation has better unrounded numerical accuracy but is slower\nthan the current staged kernel in the tested narrow projection. Its first\nattempt had a packed-slot indexing error; the corrected probe and CPU oracle\nare preserved. This rejects that adaptation, not Splash\'s complete register\npath, and no additional production code is adopted.');f.write_text(s)
