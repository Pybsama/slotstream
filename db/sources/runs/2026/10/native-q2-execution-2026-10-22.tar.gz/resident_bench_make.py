from pathlib import Path
P=Path(__file__).resolve().parent;s=(P/'mpp_bench_batched.py').read_text()
s=s.replace("fixtures=json.loads",'''# Every byte of a quantization block is striped across 32 output rows.
strided=re.sub(r'(block|sc|qs)\\[([^\\[\\]]+)\\]',lambda m:m[1]+'[('+m[2]+')*32]',header)
strided=strided.replace('block + Scales','block + Scales*32').replace('block + Codes','block + Codes*32')
body=body.replace('w+size_t(row)*RB+(col/BLOCK)*BYTES','w+((size_t(row/32)*(IN/BLOCK)+col/BLOCK)*BYTES)*32+row%32')
fixtures=json.loads''')
s=s.replace("x=mx.array([f['input']*10]*B,dtype=mx.bfloat16);mx.eval(w,x)",'''x=mx.array([f['input']*10]*B,dtype=mx.bfloat16)
 import numpy as np
 packed=mx.array(np.array(w).reshape(N//32,32,K//block,bs).transpose(0,2,3,1).copy().reshape(-1));mx.eval(w,x,packed)''')
s=s.replace("name='mpp_'", "name='resident_mpp_'").replace("header='#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>\\n'+header", "header='#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>\\n'+strided")
s=s.replace('inputs=[x,w],template', 'inputs=[x,w if i==0 else packed],template').replace("'mpp-bench-batched.json'", "'resident-bench.json'")
(P/'resident_bench.py').write_text(s)
