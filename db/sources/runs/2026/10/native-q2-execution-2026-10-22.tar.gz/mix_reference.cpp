#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
// Frozen independent oracle, transcribed from Splash GgufPreparation.cpp
// 1482f6b quantizeQ8_0Block. Input: one format byte (0 BF16, 1 F16), blocks.
int main(){int type=getchar();uint16_t src[32];while(fread(src,2,32,stdin)==32){
 float v[32],maximum=0;for(int i=0;i<32;++i){if(type){__fp16 h;memcpy(&h,&src[i],2);v[i]=h;}else{uint32_t b=uint32_t(src[i])<<16;memcpy(&v[i],&b,4);} if(!std::isfinite(v[i]))return 2;maximum=std::max(maximum,std::fabs(v[i]));}
 float d=maximum/127,inv=d?1/d:0;__fp16 scale=d;if(!std::isfinite(float(scale)))return 3;
 fwrite(&scale,2,1,stdout);for(float x:v){int8_t q=std::round(x*inv);fwrite(&q,1,1,stdout);}
}}
