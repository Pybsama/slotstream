import mlx.core as mx,json,time,statistics,base64,re
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1]
header=(R/'Sources/Slotstream/Q2GGUFKernelSources.swift').read_text().split('static let header = #"""')[1].split('"""#')[0]
formats={0:('SlotstreamGGUFF32',1,4),1:('SlotstreamGGUFF16',1,2),30:('SlotstreamGGUFBF16',1,2),2:('GgufEmbedQ40',32,18),3:('GgufEmbedQ41',32,20),6:('GgufEmbedQ50',32,22),7:('GgufEmbedQ51',32,24),8:('GgufEmbedQ80',32,34),10:('GgufEmbedQ2K',256,84),11:('GgufEmbedQ3K',256,110),12:('GgufEmbedQ4K',256,144),13:('GgufEmbedQ5K',256,176),14:('GgufEmbedQ6K',256,210),20:('GgufEmbedIQ4NL',32,18),23:('GgufEmbedIQ4XS',256,136),42:('GgufEmbedQ20',64,18)}
# Resolve admitted formats from the maintained Swift enum instead of assuming IDs.
s=(R/'Sources/Slotstream/Q2GGUFFile.swift').read_text(); print(s[s.index('enum Q2GGUFFormat'):s.index('enum Q2GGUFFormat')+600])
body='''
using namespace mpp::tensor_ops;
uint lane=thread_index_in_simdgroup, sg=simdgroup_index_in_threadgroup;
uint row0=threadgroup_position_in_grid.x*64+sg*32;
uint b0=threadgroup_position_in_grid.y*8;
threadgroup half stage[2*32*32];
threadgroup half *ws=stage+sg*32*32;
auto a=tensor(const_cast<device T*>(x)+b0*IN,dextents<int,2>{IN,min(8,BATCH-int(b0))},array<int,2>{1,IN});
tensor<threadgroup half,dextents<int,2>,tensor_inline> b(ws,dextents<int,2>{32,32},array<int,2>{1,32});
constexpr auto desc=matmul2d_descriptor(8,32,32,false,true,false,matmul2d_descriptor::mode::multiply_accumulate);
matmul2d<desc,execution_simdgroups<1>> op;
auto as=a.template slice<32,8>(0,0);auto bs=b.template slice<32,32>(0,0);
auto acc=op.template get_destination_cooperative_tensor<decltype(as),decltype(bs),float>();
for(ushort i=0;i<acc.get_capacity();++i)acc[i]=0;
for(uint k0=0;k0<IN;k0+=32){
 for(uint j=0;j<32;++j){
  uint row=row0+lane,col=k0+j;
  const device uchar* block=w+size_t(row)*RB+(col/BLOCK)*BYTES;
  ws[lane*32+j]=row<OUT?half(DECODE):half(0);
 }
 simdgroup_barrier(mem_flags::mem_threadgroup);
 auto at=a.template slice<32,8>(k0,0);
 op.run(at,bs,acc);
 simdgroup_barrier(mem_flags::mem_threadgroup);
}
for(ushort i=0;i<acc.get_capacity();++i){
 if(!acc.is_valid_element(i))continue;
 auto ij=acc.get_multidimensional_index(i);uint row=row0+ij[0],batch=b0+ij[1];
 if(row<OUT&&batch<BATCH)y[size_t(batch)*OUT+row]=T(acc[i]);
}
'''
fixtures=json.loads((R/'.build/native-q2-20261021/format-fixtures.json').read_text()); results=[];mx.set_cache_limit(128<<20)
# Current source matrix kernel, with Swift substitutions resolved.
source=(R/'Sources/Slotstream/Q2GGUFLinear.swift').read_text().split('let matmul = MLXFast.metalKernel')[1].split('source: """')[1].split('"""')[0]
for f in fixtures:
 fmt=f['format']
 if fmt not in formats:print('UNKNOWN',fmt);continue
 dec,block,bs= formats[fmt]; expr=f'{dec}::decode(block, col % {block})'
 K=2560;N=640;B=8
 rowbytes=256//block*bs;raw=base64.b64decode(f['bytes']);w=mx.array(list(b''.join(raw[(i%f['rows'])*rowbytes:((i%f['rows'])+1)*rowbytes]*10 for i in range(N))),dtype=mx.uint8)
 x=mx.array([f['input']*10]*B,dtype=mx.bfloat16);mx.eval(w,x)
 old=source.replace('\\(format.block)',str(block)).replace('\\(format.bytes)',str(bs)).replace('\\(expression)',expr)
 kernels=[mx.fast.metal_kernel(name='old_'+str(fmt),input_names=['x','w'],output_names=['y'],source=old,header='#include <metal_simdgroup_matrix>\n'+header),mx.fast.metal_kernel(name='mpp_'+str(fmt),input_names=['x','w'],output_names=['y'],source=body.replace('DECODE',expr).replace('BLOCK',str(block)).replace('BYTES',str(bs)),header='#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>\n'+header)]
 times=[];outs=[]
 for i,ker in enumerate(kernels):
  rounds=[]
  for r in range(7):
   start=time.perf_counter();y=ker(inputs=[x,w],template=[('T',mx.bfloat16),('IN',K),('OUT',N),('BATCH',B),('RB',K//block*bs)],grid=(((N+31)//32)*128,(B+7)//8,1) if i==0 else (((N+63)//64)*64,(B+7)//8,1),threadgroup=(128,1,1) if i==0 else (64,1,1),output_shapes=[(B,N)],output_dtypes=[mx.bfloat16])[0];mx.eval(y);rounds.append(time.perf_counter()-start)
  times.append(statistics.median(rounds[2:])*1000);outs.append(y)
 error=mx.max(mx.abs(outs[0].astype(mx.float32)-outs[1].astype(mx.float32))).item();record={'format':fmt,'old_ms':times[0],'mpp_ms':times[1],'max_delta':error};results.append(record);print(record,flush=True)
 (P/'mpp-bench.json').write_text(json.dumps(results,indent=2))
