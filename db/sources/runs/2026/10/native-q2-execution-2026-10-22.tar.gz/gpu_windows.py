import sys, bisect, statistics, collections
def load_spans(p):
    sp = sorted(tuple(map(float, l.split())) for l in open(p))
    # merge into union
    merged = []
    for a, b in sp:
        if merged and a <= merged[-1][1]: merged[-1][1] = max(merged[-1][1], b)
        else: merged.append([a, b])
    return sp, merged
def analyze(tag, spans_path, win_path):
    sp, merged = load_spans(spans_path)
    starts = [m[0] for m in merged]
    rawstarts = [s[0] for s in sp]
    res = collections.defaultdict(list)
    for l in open(win_path):
        label, s, e = l.split(); s = float(s); e = float(e)
        if not label.startswith("warm"): continue
        i = max(0, bisect.bisect_left(starts, s) - 1); busy = 0.0
        while i < len(merged) and merged[i][0] < e:
            a, b = merged[i]; busy += max(0.0, min(b, e) - max(a, s)); i += 1
        j0 = bisect.bisect_left(rawstarts, s); j1 = bisect.bisect_left(rawstarts, e)
        nbuf = j1 - j0
        kernels_sum = sum(min(b, e) - max(a, s) for a, b in sp[j0:j1])
        res[label].append((e - s, busy, nbuf, kernels_sum))
    for label in sorted(res):
        rows = res[label][1:]  # drop warm-up position
        w = statistics.median(r[0] for r in rows) * 1e3
        b = statistics.median(r[1] for r in rows) * 1e3
        n = statistics.median(r[2] for r in rows)
        print(f"{tag} {label}: wall {w:.1f} ms, GPU busy {b:.1f} ms ({b/w*100:.0f}%), idle {w-b:.1f} ms, command buffers {n:.0f}, idle per buffer {(w-b)/n*1000:.1f} us")
for tag in sys.argv[2:]:
    analyze(tag, f"{sys.argv[1]}/spans-{tag}.txt", f"{sys.argv[1]}/windows-{tag}.txt")
