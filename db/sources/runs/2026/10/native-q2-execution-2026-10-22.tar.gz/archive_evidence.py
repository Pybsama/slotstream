import hashlib,io,json,pathlib,tarfile
P=pathlib.Path(__file__).resolve().parent;R=P.parents[1]
destination=R/'db/sources/runs/2026/10/native-q2-execution-2026-10-22.tar.gz'
assert not destination.exists()
allowed={'.py','.json','.log','.cpp','.swift','.csv','.txt','.patch','.md'}
files={str(f.relative_to(P)):f for f in P.iterdir() if f.is_file() and f.suffix in allowed}
for directory in P.iterdir():
 if directory.is_dir() and directory.name.startswith('native-'):
  for name in ['build-identity.json','build-source-before.json','build-source.tar.gz','gpu-timing.patch','gpu-instrumentation-source.json']:
   f=directory/name
   if f.is_file():files[str(f.relative_to(P))]=f
for name in ['final-app-source.tar.gz','upstream-source.tar.gz']:
 f=P/name
 if f.exists():files[f.name]=f
# Fixed external inputs and quality rubric used by the frozen replay/graders.
for name in ['final-v3-cases.json','quality-rubric.json','grade_v2.py','thermal.py']:
 f=R/'.build/native-q2-20261021'/name
 files['inherited-fixtures/'+name]=f
for name in ['quality-upstream-q2.json','quality-upstream-q2-repeat.json','tokenizer-identity.json']:
 f=R/'.build/smart-dflash-eval'/name
 files['inherited-fixtures/'+name]=f
for fixture in sorted((R/'apps/macos/Fixtures/capabilities').rglob('*')):
 if fixture.is_file(): files['app-fixtures/'+str(fixture.relative_to(R/'apps/macos/Fixtures/capabilities'))]=fixture
manifest={name:{'size':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}for name,f in sorted(files.items())}
blob=json.dumps({'scope':'Immutable experiment evidence. No weights, executables, metallibs, private Homes or prefix-cache payloads. Failed and excluded attempts remain included.','files':manifest},indent=2).encode()
with tarfile.open(destination,'w:gz')as tar:
 info=tarfile.TarInfo('MANIFEST.json');info.size=len(blob);tar.addfile(info,io.BytesIO(blob))
 for name,f in sorted(files.items()):tar.add(f,arcname=name,recursive=False)
with tarfile.open(destination)as tar:
 for name,m in manifest.items():
  b=tar.extractfile(name).read();assert len(b)==m['size'] and hashlib.sha256(b).hexdigest()==m['sha256']
result={'archive':str(destination.relative_to(R)),'sha256':hashlib.sha256(destination.read_bytes()).hexdigest(),'bytes':destination.stat().st_size,'files':len(files),'all_payloads_read_back_and_verified':True}
(P/'archive-receipt.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
