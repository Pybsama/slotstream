# Protocol and scope, recorded retrospectively

One M5 Pro with 48 GiB unified memory. No power mode changes, spin library,
ANE path, paid services, user-process termination or simulated availability.
One full model process at a time, builds outside model runs. Reclaimable memory
is checked before each launch. Whole-process footprint and one-GB remaining
headroom are guarded. Whole-run global paging excludes clean timing, not
functional or process-memory acceptance.

The starting native binary is preserved by the previous qualification. Splash
is release 1.4.0, source 1482f6bbc2abf12375332725302019594150b6cb. The exact two
Q2 shard paths are hardlinks of the same physical files. Both use the pinned
DFlash2 draft, greedy sampling and BF16 KV. The expert arena has 4,968 native
and Splash slots for the 16 GB / 8,192-context speed comparison. Splash's
explicit expert-memory flag includes a 471,859,200-byte staging reservation;
its actual arena is 6,867,763,200 bytes. PLE allowance is 51,200,000 bytes.
The initial A/B trial lacked the matched arena and is not causal cache parity.

Each final speed sequence is ABBA, fresh processes, no OS file-cache flush,
identical prompt token IDs and 512-token cap. Native is the full production
candidate path, Splash's server uses automatic verification. Load time is
excluded from request time and retained separately. Splash warms its kernels
at startup; a separate persistent native warm-server control checks that this
cannot alone explain the gap. The warm control uses no prefix cache and a
larger native pool, so is not a cache-matched speed ratio.

Final quality uses the same prompt token IDs, 32,768 context, BF16 KV and
4,546 native versus 4,545 Splash slots, with a 16 GB process guard. The one-slot difference comes from upstream metadata/alignment overhead and is retained as a near-matched quality control, not exact cache parity. Native runs all 32 requests;
24 are the frozen quality rubric and eight exercise runtime behavior. Splash
crossed the guard after sixteen quality requests; the remaining eight quality
cases run in a fresh server. Their aggregated grades are a quality comparison,
not a passing continuous-session memory gate. The earlier 10 GB native run
also completes 32 requests, but is a different cache-size condition.

Instrumented boundaries serialize work and are never whole-request timings.
The v11 completion-handler diagnostic emitted all requested samples, then
aborted at process shutdown. Preserve that failure and label its timings
exploratory. Its local MLX dependency patch was removed before all production
builds; normal artifact identity and upstream-clean dependency checks are
separate from the instrumented build. Cached untraced replays are separate
from the boundary-forcing arms.

Component checks use bounded fixtures with independent CPU arithmetic and
upstream C++ Q8-preparation/controller oracles. They do not prove whole-target
bit parity, broad quality, or physical 16/64 GB Mac qualification. Retained
quality failures must not be regraded away. Frozen microbenchmark source and
outputs include rejected hypotheses and compiler errors.

The first lower-budget twelve-GB comparison also had a one-slot difference:
2,074 native versus 2,073 Splash. The corrected exact-cache harness adds the
metadata/alignment allowance and asserts the observed slot count. Its final
ABBA has 2,074 slots in both engines. No adjacent pair is simultaneously free
of global paging. Preserve all four results; do not select a clean single arm
as a paired result. The summarizer independently reads actual slot counts and
prompt IDs instead of trusting the requested-matching flag.
