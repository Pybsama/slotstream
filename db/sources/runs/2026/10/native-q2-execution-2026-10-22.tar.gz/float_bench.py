from pathlib import Path
import re,json,statistics,time
import numpy as np
import mlx.core as mx
P=Path(__file__).resolve().parent;S=Path('/tmp/slotstream-splash-review.EJTswU/splash/runtime/metal/kernels')
header=(S/'common/sgmatrix.h').read_text().replace('#pragma once','')
f=(S/'shared/gguf_float.metal').read_text();eight=f[f.index('template <typename V> struct Eight;'):f.index('// One threadgroup:')]
header+='\n'+eight
source=f[f.index('  const sgmatrix::Lane l = '):f.index('\n}\n\n} // namespace gguf_float')]
source=source.replace('const uint K = p.input_size,','const uint K = IN,').replace('projection.tile * 8','threadgroup_position_in_grid.x * 8').replace('y * kRows','threadgroup_position_in_grid.y * kRows').replace('p.rows','input_shape[0]').replace('projection.weights','weights').replace('projection.output +','y +').replace('projection.out_stride','OUT').replace(' + projection.out_offset','')
source='''uint sg=simdgroup_index_in_threadgroup,lane=thread_index_in_simdgroup;
constexpr uint kFragments=4,kRows=32,kStep=64,kSplits=8;
threadgroup float2 parts[kSplits*kFragments*32];
'''+source
(P/'float-source.txt').write_text(source);(P/'float-header.txt').write_text(header)
ker=mx.fast.metal_kernel(name='q2_float_diagnostic',input_names=['input','weights'],output_names=['y'],source=source,header='#pragma clang fp reassociate(off)\n'+header)
mx.set_cache_limit(128<<20);rng=np.random.default_rng(11);records=[]
for N,K in [(512,2560),(2304,2560),(48,2560)]:
 for dtype in [mx.bfloat16,mx.float32]:
  w=mx.array(rng.standard_normal((N,K)),dtype=dtype);mx.eval(w)
  for rows in [1,4,8,17]:
   x=mx.array(rng.standard_normal((rows,K)),dtype=mx.bfloat16);mx.eval(x);times=[];outs=[]
   reference=np.asarray(x.astype(mx.float32)).astype(np.float64)@np.asarray(w.astype(mx.float32)).astype(np.float64).T
   for mode in [0,1]:
    rounds=[]
    for r in range(5):
     start=time.perf_counter();ys=[]
     for j in range(16):
      y=mx.matmul(x.astype(mx.float32),w.T) if mode==0 else ker(inputs=[x,w],template=[('W',dtype),('T',mx.float32),('IN',K),('OUT',N)],grid=(N//8*256,(rows+31)//32,1),threadgroup=(256,1,1),output_shapes=[(rows,N)],output_dtypes=[mx.float32])[0]
      ys.append(y)
     mx.eval(ys);rounds.append((time.perf_counter()-start)/16)
    times.append(statistics.median(rounds[2:])*1000);outs.append(ys[-1])
   errors=[float(np.max(np.abs(np.asarray(o)-reference))) for o in outs]
   row=dict(N=N,K=K,rows=rows,dtype=str(dtype),mlx_ms=times[0],splash_ms=times[1],max_errors=errors);records.append(row);print(row,flush=True)
(P/'float-bench.json').write_text(json.dumps(records,indent=2))
