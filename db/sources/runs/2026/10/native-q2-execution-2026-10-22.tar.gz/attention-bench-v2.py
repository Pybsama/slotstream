import mlx.core as mx,time,statistics,json
from pathlib import Path
mx.set_cache_limit(128<<20);mx.random.seed(15);results=[]
for keys in [80,256,512,1024,4096]:
 for rows in [2,4,8]:
  q=mx.random.normal((1,24,rows,256)).astype(mx.bfloat16)
  k=mx.random.normal((1,2,keys,256)).astype(mx.bfloat16)
  v=mx.random.normal((1,2,keys,256)).astype(mx.bfloat16);mx.eval(q,k,v)
  times=[];outs=[]
  for mode in [0,1,2]:
   rounds=[]
   for r in range(6):
    start=time.perf_counter();ys=[]
    for _ in range(16):
     if mode==0:out=mx.fast.scaled_dot_product_attention(q,k,v,scale=.0625,mask='causal')
     elif mode==1:
      qp=mx.concatenate([mx.zeros((1,24,16-rows,256),dtype=q.dtype),q],axis=2)
      out=mx.fast.scaled_dot_product_attention(qp,k,v,scale=.0625,mask='causal',force_fused=True)[:,:,-rows:]
     else:
      # Every row has the causal prefix it would see individually.
      out=mx.concatenate([mx.fast.scaled_dot_product_attention(q[:,:,j:j+1],k[:,:,:keys-rows+j+1],v[:,:,:keys-rows+j+1],scale=.0625)for j in range(rows)],axis=2)
     ys.append(out)
    mx.eval(ys);rounds.append((time.perf_counter()-start)*1000/16)
   times.append(statistics.median(rounds[2:]));outs.append(ys[-1])
  errors=[float(mx.max(mx.abs(outs[i].astype(mx.float32)-outs[0].astype(mx.float32))))for i in [1,2]]
  item={'keys':keys,'rows':rows,'stock_ms':times[0],'fused_ms':times[1],'split_ms':times[2],'max_difference':errors};print(item,flush=True);results.append(item)
Path(__file__).with_suffix('.json').write_text(json.dumps(results,indent=2))
