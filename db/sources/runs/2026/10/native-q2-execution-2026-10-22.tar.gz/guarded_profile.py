import ctypes,fcntl,json,os,subprocess,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));from upstream_bench import RUsage,PREPARED,BUNDLE
sys.path.insert(0,str(P.parents[1]/'Tools'));from prefill_bench import preflight,vm_snapshot,terminate_child_tree
out=P/'splash-profile16';assert not out.with_suffix('.json').exists();before=preflight(20)
lock=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
cmd=['/tmp/slotstream-splash-review.EJTswU/splash/build/engine-tests/decode-profile',str(BUNDLE/'engine/splash.metallib'),str(PREPARED),'--prompt-tokens','80','--cycles','2','--kv-format','bf16','--expert-memory','6867763200','--ple-memory','134217728','--dispatch-list',str(P/'splash-dispatches.txt')]
lib=ctypes.CDLL('/usr/lib/libproc.dylib');lib.proc_pid_rusage.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.c_void_p];samples=[];start=time.monotonic();error=None
with out.with_suffix('.log').open('x') as log:
 proc=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:
  while proc.poll() is None:
   r=RUsage();lib.proc_pid_rusage(proc.pid,2,ctypes.byref(r));vm=vm_snapshot();samples.append({'seconds':time.monotonic()-start,'footprint':r.phys_footprint,'reclaimable':vm['reclaimable_bytes']})
   if r.phys_footprint>16e9 or vm['reclaimable_bytes']<1e9 or time.monotonic()-start>480:raise RuntimeError('physical memory, headroom, or time guard exceeded')
   time.sleep(.5)
 except Exception as e:error=str(e)
 finally:
  if proc.poll() is None:terminate_child_tree(proc)
  out.with_suffix('.json').write_text(json.dumps({'command':cmd,'before':before,'after':vm_snapshot(),'samples':samples,'error':error,'exit_code':proc.wait()},indent=2))
 print('profile complete',proc.returncode,error,'peak',max(r['footprint'] for r in samples)/1e9)
 if error or proc.returncode:sys.exit(1)
