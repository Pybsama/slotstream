from pathlib import Path
import json,sys,subprocess,fcntl,os,argparse,time
P=Path(__file__).resolve().parent; R=P.parents[1]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight,terminate_child_tree
sys.path.insert(0,str(R/'.build/native-q2-20261021'));from thermal import wait_nominal
ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['validation','timing']);a=ap.parse_args()
reservation=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(reservation,fcntl.LOCK_EX|fcntl.LOCK_NB)
inner=P/(a.mode+'-child.lock');os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(inner)
ledger=P/(a.mode+'-ledger.json');assert not ledger.exists();events=[]
fixture=P/'timed-2.json';data=json.loads(fixture.read_text());validation=a.mode!='timing';rounds=1 if validation else 3
if not validation:assert json.loads((P/'validation-result.json').read_text())['passed']
model=R/'.build/smart-dflash-eval/upstream-prepared/.resolved/938d6d6879dac79e95a5eae858867e0af230dc252a18266c6aefb6732b65dee7'
F=P.parent/'q2-full-cycle-20261025'
refs={arm:json.loads((F/name).read_text())['rounds'][0]['steps']for arm,name in [('N','validation-0-N.json'),('S','validation-s-0-S.json')]}
sequence=[('N',100),('S',100)]if validation else [('N',0),('N',100),('S',100),('S',0),('S',0),('S',100),('N',100),('N',0)]
for i,(arm,delay) in enumerate(sequence):
 label=f'{a.mode}-{i}-{arm}-{delay}';out=P/(label+'.json');assert not out.exists()
 wait_nominal(P/(label+'-cooldown.json'));preflight(18)
 env=['--env','SLOTSTREAM_MODEL_LOCK_PATH='+str(inner),'--env','DYLD_INSERT_LIBRARIES='+str(P/'read_delay.dylib'),'--env','Q2_READ_DELAY_US='+str(delay),'--env','Q2_READ_DELAY_REPORT='+str(P/(label+'-reads.csv'))]
 if arm=='N':
  cmd=[str(F/'native-build/candidate/slotstream'),'q2-profile','--fixture',str(fixture),'--output',str(out),'--memory-gb','15','--rounds',str(rounds)]
  if validation:cmd+=['--validate']
 else:
  cmd=[str(F/'upstream/full-cycle'),str(F/'upstream/splash.metallib'),str(model),'--prompt-tokens',str(len(data['prompt_ids'])),'--cycles',str(rounds),'--kv-format','bf16','--state-format','fp32','--expert-memory','6094291728','--ple-memory','51200000']
  env+=['--env','Q2_DIAGNOSTIC_FIXTURE='+str(fixture)]
  if validation:env+=['--env','Q2_CYCLE_VALIDATE=1']
 if validation:env+=['--env','MTL_DEBUG_LAYER=1']
 full=[sys.executable,str(P/'quiet_guarded_run.py'),'--label',label,'--budget','15','--timeout','600',*env,'--',*cmd]
 print('START',label,flush=True);monitor=None
 with(P/(label+'-launcher.log')).open('x')as log,(P/(label+'-frequency.jsonl')).open('x')as freq,(P/(label+'-frequency.stderr')).open('x')as ferr:
  if not validation:monitor=subprocess.Popen([str(R/'.build/native-monitor/macmon'),'pipe','-s','3300','-i','200','--soc-info'],stdout=freq,stderr=ferr,start_new_session=True)
  child=subprocess.Popen(full,cwd=R,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:rc=child.wait(timeout=660)
  finally:
   if child.poll()is None:terminate_child_tree(child)
   if monitor and monitor.poll()is None:terminate_child_tree(monitor)
 guard=json.loads((P/(label+'.observer.json')).read_text());event=dict(label=label,arm=arm,delay_us=delay,exit_code=rc,command=full,eligible=not guard['external_build_samples'] and not guard['paging'] and guard['thermal_before']==guard['thermal_after']==0 and guard['peak_combined_bytes']<=15e9 and rc==0)
 events.append(event);ledger.write_text(json.dumps(events,indent=2))
 if rc:raise SystemExit(rc)
 if arm=='N':
  d=json.loads(out.read_text());assert d['complete'] and d['plan']['pool_slots']==4067
  rows=[row for rd in d['rounds'] for row in rd['steps']]
 else:
  rows=[];guesses={};selected={};rds=[];slots=None
  for line in(P/(label+'.log')).read_text().splitlines():
   x=line.split()
   if not x:continue
   if x[0]=='CONFIG':slots=int(dict(s.split('=',1)for s in x[1:])['slots'])
   elif x[0]in('DRAFT','SELECTED'):(guesses if x[0]=='DRAFT'else selected)[(int(x[1]),int(x[2]))]=list(map(int,x[3:]))
   elif x[0]=='ROUND':rds.append(dict(round=int(x[1]),seconds=float(x[2])))
   elif x[0]=='ROW':
    assert len(x)==(16 if validation else 15),(len(x),x)
    row=dict(zip(['round','step','width','kept'],map(int,x[1:5])))
    row.update(zip(['start','prepared','submitted','end','gpu_seconds','host_seconds'],map(float,x[5:11])))
    row.update(zip(['records_read','records_adopted','read_bytes','layer_loads'],map(int,x[11:15])))
    row['seconds']=row['end']-row['start'];row['records_fetched']=row['records_read']-row['records_adopted']
    if validation:row['logits_sha256']=x[15]
    rows.append(row)
  assert slots==4067
  for row in rows:row.update(actual_guesses=guesses[(row['round'],row['step'])],actual_selected=selected[(row['round'],row['step'])])
  for rd in rds:rd['steps']=[r for r in rows if r['round']==rd['round']]
  d=dict(complete=True,slots=slots,rounds=rds);out.write_text(json.dumps(d,indent=2))
 assert len(rows)==rounds*len(data['steps'])
 for row in rows:
  step=data['steps'][row['step']];assert row['width']==len(step['tokens']) and row['kept']==step['kept'];assert len(row['actual_guesses'])==7 and len(row['actual_selected'])==step['kept'];assert all(0<=t<248320 for t in row['actual_guesses']+row['actual_selected'])
 for rd in d['rounds']:
  assert len(rd['steps'])==111
  for row,ref in zip(rd['steps'],refs[arm]):
   for key in ['step','width','kept','actual_guesses','actual_selected']+(['logits_sha256']if validation else[]):assert row[key]==ref[key],(label,rd['round'],row['step'],key)
 read_report=(P/(label+'-reads.csv')).read_text();assert 'thread_overflow=0' in read_report
 for line in read_report.splitlines():
  if line.startswith('# thread='):assert 'errors=0 shorts=0 overflow=0' in line,line
 event['rounds']=[dict(round=rd['round'],seconds=rd['seconds'],cycle_seconds=sum(r['seconds']for r in rd['steps']),demand=sum(r['records_fetched']for r in rd['steps']),adopted=sum(r['records_adopted']for r in rd['steps']))for rd in d['rounds']]
 ledger.write_text(json.dumps(events,indent=2));print('END',label,event['eligible'],event['rounds'],flush=True)
if validation:(P/'validation-result.json').write_text(json.dumps(dict(passed=True,engines=['N','S'],full_logit_hashes=111,exact_proposals=111,exact_selected=111,delayed_us=100,scope='Each engine equals own reference; Metal validation and exact 4067slots; no speed claim.'),indent=2))
print('PROTOCOL FINISHED',flush=True)
