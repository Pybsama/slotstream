// Diagnostic only. Delay completed expert reads equally in both engines.
#include <unistd.h>
#include <sys/stat.h>
#include <mach/mach_time.h>
#include <pthread.h>
#include <atomic>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cerrno>
#include <cstring>
#ifdef Q2_DELAY_SELFTEST
#include <cassert>
struct Range {uint64_t device,inode,start,end;};static Range ranges[1];
#else
#include "ranges.hpp"
#endif
namespace {
constexpr size_t max_threads=128,bins=2400;
struct Bin {uint64_t calls=0,bytes=0,io=0,wait=0;};
struct alignas(128) Thread {uint64_t id=0;Bin values[bins];uint64_t errors=0,shorts=0,overflow=0;};
Thread rows[max_threads];std::atomic<size_t> used{0};std::atomic<uint64_t> thread_overflow{0};
bool enabled=false;uint64_t delay_ticks=0,origin=0,bin_ticks=0;double ns_per_tick=1;const char*output=nullptr;
bool match(int fd,off_t at,size_t n) {
 if(at<0||n==0||n>uint64_t(INT64_MAX)-uint64_t(at))return false;
 // Cache only successful immutable model descriptor identities. Both engines
 // retain these descriptors until model teardown. Negative matches are not cached.
 struct FD {int fd=-1;uint64_t device=0,inode=0;};
 thread_local FD files[4];uint64_t device=0,inode=0;
 for(auto&f:files)if(f.fd==fd){device=f.device;inode=f.inode;break;}
 if(!inode){
  struct stat st;if(fstat(fd,&st))return false;device=st.st_dev;inode=st.st_ino;
  bool known=false;for(auto&r:ranges)if(r.device==device&&r.inode==inode){known=true;break;}
  if(!known)return false;
  for(auto&f:files)if(f.fd==-1){f={fd,device,inode};break;}
 }
 for(auto&r:ranges)if(r.device==device&&r.inode==inode&&uint64_t(at)>=r.start&&uint64_t(at)+n<=r.end)return true;
 return false;
}
ssize_t delayed_pread(int fd,void*dst,size_t n,off_t at) {
 if(!enabled||!match(fd,at,n))return pread(fd,dst,n,at);
 thread_local size_t index=[](){auto i=used.fetch_add(1);if(i<max_threads)pthread_threadid_np(nullptr,&rows[i].id);else thread_overflow++;return i;}();
 const auto start=mach_absolute_time();const ssize_t result=pread(fd,dst,n,at);const int saved=errno;const auto io_end=mach_absolute_time();
 if(result>0&&delay_ticks){const auto deadline=io_end+delay_ticks;while(mach_wait_until(deadline)==KERN_ABORTED){} }
 const auto end=mach_absolute_time();
 if(index<max_threads){auto&t=rows[index];size_t b=(start-origin)/bin_ticks;
  if(b<bins){auto&v=t.values[b];++v.calls;v.bytes+=result>0?result:0;v.io+=io_end-start;v.wait+=end-io_end;}else ++t.overflow;
  if(result<0)++t.errors;else if(size_t(result)!=n)++t.shorts;
 }
 errno=saved;return result;
}
void dump(){enabled=false;if(!output)return;FILE*f=fopen(output,"wx");if(!f)return;
 fprintf(f,"# delay_ticks=%llu ns_per_tick=%.9f origin_ticks=%llu bin_ticks=%llu thread_overflow=%llu\n",delay_ticks,ns_per_tick,origin,bin_ticks,thread_overflow.load());
 fprintf(f,"thread,bin,start_s,end_s,calls,bytes,io_s,added_wait_s\n");
 for(size_t i=0;i<used.load()&&i<max_threads;++i){auto&t=rows[i];for(size_t b=0;b<bins;++b){auto&v=t.values[b];if(v.calls)fprintf(f,"%llu,%zu,%.9f,%.9f,%llu,%llu,%.9f,%.9f\n",t.id,b,(origin+b*bin_ticks)*ns_per_tick/1e9,(origin+(b+1)*bin_ticks)*ns_per_tick/1e9,v.calls,v.bytes,v.io*ns_per_tick/1e9,v.wait*ns_per_tick/1e9);}
  fprintf(f,"# thread=%llu errors=%llu shorts=%llu overflow=%llu\n",t.id,t.errors,t.shorts,t.overflow);}
 fclose(f);
}
__attribute__((constructor))void init(){output=getenv("Q2_READ_DELAY_REPORT");if(!output)return;
 auto*arg=getenv("Q2_READ_DELAY_US");if(!arg||!(strcmp(arg,"0")==0||strcmp(arg,"100")==0))_exit(91);
 mach_timebase_info_data_t tb;mach_timebase_info(&tb);ns_per_tick=double(tb.numer)/tb.denom;
 delay_ticks=uint64_t(strtoull(arg,nullptr,10)*1000/ns_per_tick);bin_ticks=uint64_t(250000000/ns_per_tick);origin=mach_absolute_time();enabled=true;atexit(dump);
}
}
#ifndef Q2_DELAY_SELFTEST
__attribute__((used))static struct{const void*replacement;const void*original;} interpose[]
__attribute__((section("__DATA,__interpose")))={{(const void*)delayed_pread,(const void*)pread}};
#else
int main(){
 char path[]="/tmp/q2-read-delay-selftest-XXXXXX";int fd=mkstemp(path);assert(fd>=0);unlink(path);
 unsigned char input[4096],output_bytes[600];for(size_t i=0;i<sizeof(input);++i)input[i]=i%251;
 assert(write(fd,input,sizeof(input))==sizeof(input));struct stat st;assert(fstat(fd,&st)==0);ranges[0]={uint64_t(st.st_dev),st.st_ino,1024,8192};
 errno=EDOM;auto start=mach_absolute_time();assert(delayed_pread(fd,output_bytes,512,1024)==512);auto end=mach_absolute_time();assert(errno==EDOM&&memcmp(output_bytes,input+1024,512)==0);assert((end-start)*ns_per_tick>=100000);
 assert(delayed_pread(fd,output_bytes,128,0)==128&&memcmp(output_bytes,input,128)==0);
 assert(delayed_pread(fd,output_bytes,200,4000)==96&&memcmp(output_bytes,input+4000,96)==0);
 assert(delayed_pread(fd,output_bytes,128,4096)==0);close(fd);errno=0;
 assert(delayed_pread(fd,output_bytes,128,1024)==-1&&errno==EBADF);
 uint64_t calls=0,bytes=0;for(auto&v:rows[0].values){calls+=v.calls;bytes+=v.bytes;}
 assert(used==1&&calls==4&&bytes==608&&rows[0].errors==1&&rows[0].shorts==2&&rows[0].overflow==0);
 puts("SELFTEST PASS: bytes, region selection, positive read delay, partial read, EOF, errno, failed read and counters");
}
#endif
