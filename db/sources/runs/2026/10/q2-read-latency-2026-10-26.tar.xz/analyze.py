from pathlib import Path
import csv,io,json,statistics,hashlib
P=Path(__file__).resolve().parent
assert json.loads((P/'validation-result.json').read_text())['passed']
events=json.loads((P/'timing-ledger.json').read_text());assert len(events)==8
identity=json.loads((P/'frozen-identity.json').read_text())
assert all(hashlib.sha256((P/n).read_bytes()).hexdigest()==h for n,h in identity.items())
results=[]
for e in events:
 label=e['label'];d=json.loads((P/(label+'.json')).read_text());report=(P/(label+'-reads.csv')).read_text()
 assert 'thread_overflow=0'in report
 for line in report.splitlines():
  if line.startswith('# thread='):assert 'errors=0 shorts=0 overflow=0'in line
 rows=list(csv.DictReader(io.StringIO('\n'.join(line for line in report.splitlines()if not line.startswith('#')))))
 for row in rows:
  for k in ['thread','bin','calls','bytes']:row[k]=int(row[k])
  for k in ['start_s','end_s','io_s','added_wait_s']:row[k]=float(row[k])
 rounds=[]
 for rd in d['rounds'][1:]:
  steps=rd['steps'];start=steps[0]['start_ns']/1e9 if e['arm']=='N'else steps[0]['start'];end=steps[-1]['end_ns']/1e9 if e['arm']=='N'else steps[-1]['end']
  inside=[r for r in rows if r['start_s']>=start and r['end_s']<=end]
  intersect=[r for r in rows if r['start_s']<end and r['end_s']>start]
  def totals(rs):
   out={k:sum(r[k]for r in rs)for k in ['calls','bytes','io_s','added_wait_s']};out['threads']=len(set(r['thread']for r in rs));out['added_wait_us_per_call']=out['added_wait_s']*1e6/out['calls']if out['calls']else None;out['io_us_per_call']=out['io_s']*1e6/out['calls']if out['calls']else None;return out
  rounds.append(dict(round=rd['round'],seconds=rd['seconds'],cycle_seconds=sum(r['seconds']for r in steps),demand=sum(r['records_fetched']for r in steps),adopted=sum(r['records_adopted']for r in steps),required_misses=sum(r['records_fetched']+r['records_adopted']for r in steps),read_bins_inside=totals(inside),read_bins_intersecting=totals(intersect),interval=[start,end],sampling_scope='250ms bins are bounded inclusion estimates, not exact per-round read attribution. io/wait are worker sums, never critical path or wall time.'))
 assert len(rounds)==2
 results.append(dict(label=label,arm=e['arm'],delay_us=e['delay_us'],eligible=e['eligible'],rounds=rounds,mean_seconds=statistics.mean(r['seconds']for r in rounds),mean_cycle_seconds=statistics.mean(r['cycle_seconds']for r in rounds)))
Nforward=results[1]['mean_seconds']/results[0]['mean_seconds'];Nreverse=results[6]['mean_seconds']/results[7]['mean_seconds'];Sforward=results[2]['mean_seconds']/results[3]['mean_seconds'];Sreverse=results[5]['mean_seconds']/results[4]['mean_seconds']
ratios=dict(native=[Nforward,Nreverse],splash=[Sforward,Sreverse],native_minus_splash_percentage_points=[100*(Nforward-Sforward),100*(Nreverse-Sreverse)],relative_amplification=[Nforward/Sforward,Nreverse/Sreverse])
supported=all(e['eligible']for e in events)and all(x>2 for x in ratios['native_minus_splash_percentage_points'])
summary=dict(protocol_eligible=all(e['eligible']for e in events),all_exact_proposals_and_selected=True,ratios=ratios,native_amplification_supported=supported,results=results,limitations='Artificial read-completion delay with actual original expert reads. No production speed claim. Both engines keep original coalescing and scheduler. Requested latency equals100us, realized added wait can differ and is reported. Routes are own-engine exact, not cross-engine byte-identical. Binned worker sums are not critical waits. No runtime change is retained.')
(P/'analysis.json').write_text(json.dumps(summary,indent=2))
print(json.dumps({k:v for k,v in summary.items()if k!='results'},indent=2))
for r in results:print(r['label'],r['mean_seconds'],[(q['demand'],q['adopted'],q['read_bins_inside']['added_wait_us_per_call'])for q in r['rounds']])
