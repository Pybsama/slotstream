from pathlib import Path
import hashlib,json,os,struct,subprocess,shutil
P=Path(__file__).resolve().parent;R=P.parents[1];F=P.parent/'q2-full-cycle-20261025'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
model=R/'.build/smart-dflash-eval/upstream-prepared/.resolved/938d6d6879dac79e95a5eae858867e0af230dc252a18266c6aefb6732b65dee7/model.json'
manifest=json.loads(model.read_text());ranges=[];tensors=[]
formats={0:(1,4),1:(1,2),2:(32,18),6:(32,22),8:(32,34),11:(256,110),12:(256,144),13:(256,176),14:(256,210),20:(32,18),23:(256,136),30:(1,2),42:(64,18)}
for desc in manifest['files'].values():
 f=Path(desc['path'])
 if f.suffix!='.gguf':continue
 with f.open('rb')as src:header=src.read(32<<20)
 pos=0
 def get(fmt):
  global pos
  result=struct.unpack_from('<'+fmt,header,pos);pos+=struct.calcsize('<'+fmt);return result[0]if len(result)==1 else result
 def string():
  global pos
  n=get('Q');assert n<32<<20;v=header[pos:pos+n];pos+=n;return v.decode()
 def skip(kind):
  global pos
  if kind==8:return string()
  if kind==9:
   k=get('I');n=get('Q');assert n<2_000_000
   if k in [0,1,2,3,4,5,6,7,10,11,12]:pos+=n*struct.calcsize('<'+{0:'B',1:'b',2:'H',3:'h',4:'I',5:'i',6:'f',7:'B',10:'Q',11:'q',12:'d'}[k])
   else:
    for _ in range(n):skip(k)
   return None
  return get({0:'B',1:'b',2:'H',3:'h',4:'I',5:'i',6:'f',7:'B',10:'Q',11:'q',12:'d'}[kind])
 assert get('I')==0x46554747 and get('I')==3
 nt,nk=get('QQ');alignment=32
 for _ in range(nk):
  key=string();value=skip(get('I'))
  if key=='general.alignment':alignment=value
 entries=[]
 for _ in range(nt):
  name=string();rank=get('I');dims=[get('Q')for _ in range(rank)];kind=get('I');offset=get('Q');entries.append((name,dims,kind,offset))
 data_start=(pos+alignment-1)//alignment*alignment;assert data_start<len(header)
 st=f.stat()
 for name,dims,kind,offset in entries:
  if not any(k in name for k in ['ffn_gate_exps','ffn_up_exps','ffn_down_exps']):continue
  n=1
  for dim in dims:n*=dim
  block,size=formats[kind];assert n%block==0
  start=data_start+offset;end=start+n//block*size
  row=dict(file=str(f),device=st.st_dev,inode=st.st_ino,name=name,start=start,end=end,aligned_start=start//16384*16384,aligned_end=(end+16383)//16384*16384,shape=dims,format=kind)
  tensors.append(row);ranges.append((st.st_dev,st.st_ino,row['aligned_start'],row['aligned_end']))
assert len(tensors)==144,len(tensors)
(P/'expert-ranges.json').write_text(json.dumps(tensors,indent=2))
header='struct Range { uint64_t device,inode,start,end; };\nstatic constexpr Range ranges[]={\n'+''.join('{%dULL,%dULL,%dULL,%dULL},\n'%v for v in sorted(ranges))+'};\n'
(P/'ranges.hpp').write_text(header)
for n in ['quiet_guarded_run.py','timed-2.json']:shutil.copy2(F/n,P/n)
binaries={'N':F/'native-build/candidate/slotstream','S':F/'upstream/full-cycle','B':P.parent/'q2-started-forecast-20261026/native-build/candidate/slotstream'}
plan=dict(scope='Read-completion sensitivity diagnostic, not an optimization or product parity claim.',hypothesis='Identical added latency after successful expert pread may cause native cancellation of forecasts with no finished piece to amplify demand waiting more than Splash. Test this before retaining any started-forecast change.',injection='100 microseconds blocking mach_wait_until after each successful expert-region read. No busy wait, GPU work, priority changes, byte mutation or altered return/errno. Both engines use the same interposer. Calls can differ through existing coalescing/cache routing; report actual delayed calls and measured wait duration. Exact expert regions extracted from original GGUF headers and bound to file device/inode, including existing page-rounded margins.',configuration='Same frozen 111 passes, actual trained draft, target inputs,1..8 widths and retention; 15GB physical,4067 slots, native8192context; Splash bounded original diagnostic arena; BF16 activation/KV, FP32 recurrence. Own-engine full-logit references, not cross-engine arithmetic identity.',validation='Independent interposer byte/error/partial/EOF/range-selection tests, then each N/S one full-logit validation with delay and Metal validation;111 full logits/proposals/selected equal own references.',protocol='Frozen N0,N100,S100,S0,S0,S100,N100,N0; each one warmup and two measured rounds. Global model reservation,18GB preflight,1GB remaining,15GB ceiling, nominal thermal,no paging,no competing heavy work. No large trace observers. Preserve all arms and exclude complete timing protocol on any environment failure. Never retry to select timings.',decision='Compare each engine delayed/zero ratios in forward and reverse pairs. A native amplification hypothesis needs a larger relative response in both directions, plus actual added waits, cache/adoption counts and own-output checks. A difference below2 percentage points is not meaningful evidence for a new scheduler fix. If supported, existing started-forecast build is a diagnostic ablation requiring its own frozen baseline/control and critical waiting investigation. Artificial-delay wins never qualify production; ordinary complete requests against v68 and published Splash are still required.',source_revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),binary_sha256={k:sha(v)for k,v in binaries.items()},fixture_sha256=sha(P/'timed-2.json'),model_manifest_sha256=sha(model))
(P/'plan.json').write_text(json.dumps(plan,indent=2));print('PREPARED',len(tensors),'expert tensor ranges',plan['binary_sha256'],flush=True)
