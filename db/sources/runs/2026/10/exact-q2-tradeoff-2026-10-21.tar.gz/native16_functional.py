import json,subprocess,sys,time
from pathlib import Path
P=Path(__file__).parent;ROOT=P.resolve().parents[1]
sys.path.insert(0,str(ROOT/'Tools'))
from prefill_bench import preflight,vm_snapshot,host_conditions,terminate_child_tree
from thermal import wait_nominal

def native(method,budget,cases,label):
 out=P/f'native-{method}-{budget}-{label}.json';assert not out.exists()
 before={'vm':preflight(budget+3),'host':host_conditions()};out.with_name(out.stem+'-host-before.json').write_text(json.dumps(before,indent=2))
 with out.with_suffix('.log').open('x') as log:
  child=subprocess.Popen([str(ROOT/'.build/release/slotstream'),'smart-dflash-check','--method',method,'--memory-gb',str(budget),'--cases',str(P/cases),'--output',str(out)],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:rc=child.wait(timeout=1200)
  finally:
   if child.poll() is None:terminate_child_tree(child)
 out.with_name(out.stem+'-host-after.json').write_text(json.dumps({'vm':vm_snapshot(),'host':host_conditions(),'exit_code':rc},indent=2))
 if rc:raise RuntimeError(f'native exited {rc}')

def upstream(verify,cases,label):
 out=P/f'q2-{verify}-bf16-10-{label}.json';assert not out.exists()
 child=subprocess.Popen([sys.executable,str(P/'upstream_bench.py'),'--memory-gb','10','--verify',verify,'--kv','bf16','--cases',str(P/cases),'--tokens',str(P/'diagnostic-prompt-ids.json'),'--output',str(out)],start_new_session=True)
 try:rc=child.wait(timeout=1200)
 finally:
  if child.poll() is None:terminate_child_tree(child)
 if rc:raise RuntimeError(f'Q2 exited {rc}')

def production(budget):
 cases=[c for c in json.loads((P/'performance-cases.json').read_text()) if c['id']=='perf-code']
 # Use the normal published CLI planner and Engine, including automatic MTP
 # and read-ahead, at the same 8K request window as upstream.
 rows=[];out=P/f'native-production-{budget}-diagnostic.json';assert not out.exists()
 for case in cases:
  wait_nominal(P/f'thermal-production-v2-{budget}-{case["id"]}.json')
  prompt=P/f'production-{case["id"]}.txt'
  if not prompt.exists():prompt.write_text(case['prompt'])
  result=P/f'production-{budget}-{case["id"]}-raw.json';assert not result.exists()
  before={'vm':preflight(budget+3),'host':host_conditions()}
  command=[str(ROOT/'.build/release/slotstream'),'run','--model','smart','--memory-gb',str(budget),'--max-context','8192','--vision','off','--max-tokens',str(case['maxTokens']),'--prompt-file',str(prompt),'--greedy','--sample-footprint','--stats-json',str(result)]
  with result.with_suffix('.log').open('x') as log:
   child=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
   try:rc=child.wait(timeout=1200)
   finally:
    if child.poll() is None:terminate_child_tree(child)
  after={'vm':vm_snapshot(),'host':host_conditions(),'exit_code':rc}
  if rc:raise RuntimeError(f'production CLI exited {rc}')
  d=json.loads(result.read_text());assert d['stats']['peakMemoryGB']<=budget and not d['stats']['memoryPressureCancelled']
  base=next(r for r in json.loads((P/'native-mtp-10-r0.json').read_text())['runs'] if r['id']==case['id']);assert d['prompt_ids']==base['prompt_ids']
  rows.append({'id':case['id'],'prompt_ids':d['prompt_ids'],'text':d['text'],'stats':d['stats'],'plan':d['plan'],'swapins_delta':after['vm']['swapins']-before['vm']['swapins'],'swapouts_delta':after['vm']['swapouts']-before['vm']['swapouts'],'host_before':before,'host_after':after,'command':command})
  out.write_text(json.dumps({'method':'production-auto','memory_gb':budget,'runs':rows,'complete':len(rows)==len(cases)},indent=2))
  print('production',budget,case['id'],d['stats']['decodeTokens']/d['stats']['decodeSeconds'],d['plan']['mtp'],d['plan']['decode_lookahead'],flush=True)

def upstream20():
 out=P/'q2-auto-int8-20-diagnostic.json';assert not out.exists()
 child=subprocess.Popen([sys.executable,str(P/'upstream_bench.py'),'--memory-gb','20','--verify','auto','--kv','int8','--cases',str(P/'diagnostic-performance-cases.json'),'--tokens',str(P/'diagnostic-prompt-ids.json'),'--output',str(out)],start_new_session=True)
 try:rc=child.wait(timeout=1200)
 finally:
  if child.poll() is None:terminate_child_tree(child)
 if rc:raise RuntimeError(f'Q2 twenty-GB diagnostic exited {rc}')


from thermal import state

def wait_nominal(path):
 # This late control is functional/indicative, not eligible for clean timing.
 ps=subprocess.check_output(['ps','-axo','pid,ppid,etime,%cpu,rss,comm'],text=True)
 competing=[r for r in ps.splitlines() if any(x in r for x in ['swift-frontend','SlotstreamMacChecks','slotstream-home-ui'])]
 obs={'time':time.time(),'thermal':state(),'competing':competing,'vm':vm_snapshot(),'clean_timing_eligible':False}
 path.write_text(json.dumps(obs,indent=2))
 if competing:raise RuntimeError('another heavy job prevents a larger-budget measurement')
 if obs['thermal']>=2:raise RuntimeError('serious or critical thermal state')

production(16)
