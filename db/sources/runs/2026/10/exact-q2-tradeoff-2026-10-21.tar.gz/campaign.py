"""Sequential follow-up runs. Preflight each step and retain every refusal."""
import argparse,json,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];P=Path(__file__).parent
sys.path.insert(0,str(ROOT/'Tools'))
from prefill_bench import preflight,vm_snapshot,host_conditions,terminate_child_tree

def native(method,budget,label):
 out=P/f'native-{method}-{budget}-{label}.json'
 assert not out.exists()
 host={'vm':preflight(budget+3),'host':host_conditions()}
 (P/f'native-{method}-{budget}-{label}-host-before.json').write_text(json.dumps(host,indent=2))
 command=[str(ROOT/'.build/release/slotstream'),'smart-dflash-check','--method',method,'--memory-gb',str(budget),'--cases',str(P/'performance-cases.json'),'--output',str(out)]
 with out.with_suffix('.log').open('x') as log:
  child=subprocess.Popen(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:rc=child.wait(timeout=1200)
  finally:
   if child.poll() is None:terminate_child_tree(child)
 (P/f'native-{method}-{budget}-{label}-host-after.json').write_text(json.dumps({'vm':vm_snapshot(),'host':host_conditions(),'exit_code':rc},indent=2))
 if rc:raise RuntimeError(f'native {method} exited {rc}')

def q2(budget,label,verify='auto',kv='int8'):
 command=[sys.executable,str(P/'upstream_bench.py'),'--memory-gb',str(budget),'--verify',verify,'--kv',kv,'--cases',str(P/'performance-cases.json'),'--tokens',str(P/'native-mtp-10-r0.json'),'--output',str(P/f'q2-{verify}-{kv}-{budget}-{label}.json')]
 child=subprocess.Popen(command,cwd=ROOT,start_new_session=True)
 try:rc=child.wait(timeout=1200)
 finally:
  if child.poll() is None:terminate_child_tree(child)
 if rc:raise RuntimeError(f'Q2 exited {rc}')

def main():
 ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['paired','diagnostic','larger']);ap.add_argument('--budget',type=int,default=16);a=ap.parse_args()
 events=[];log=P/f'campaign-{a.mode}-{a.budget}.json';assert not log.exists()
 if a.mode=='paired':
  steps=[]
  for r in (1,2,3):
   pair=[('native-mtp',lambda r=r:native('mtp',10,f'r{r}')),('q2-auto-int8',lambda r=r:q2(10,f'r{r}'))]
   if r==2:pair.reverse()
   steps.extend((f'r{r}-{name}',fn) for name,fn in pair)
 elif a.mode=='diagnostic':steps=[('native-dflash',lambda:native('dflash',10,'diagnostic')),('q2-all-bf16',lambda:q2(10,'diagnostic','all','bf16')),('q2-auto-bf16',lambda:q2(10,'diagnostic','auto','bf16'))]
 else:steps=[(f'q2-{a.budget}-r{r}',lambda r=r:q2(a.budget,f'r{r}')) for r in (1,2,3)]
 try:
  for label,fn in steps:
   events.append({'label':label,'began':time.time(),'status':'running'});log.write_text(json.dumps(events,indent=2));print('BEGIN',label,flush=True)
   fn();events[-1].update(ended=time.time(),status='complete');log.write_text(json.dumps(events,indent=2));print('END',label,flush=True);time.sleep(3)
 except Exception as e:
  events[-1].update(ended=time.time(),status='failed-or-refused',error=f'{type(e).__name__}: {e}');log.write_text(json.dumps(events,indent=2));raise

if __name__=='__main__':main()
