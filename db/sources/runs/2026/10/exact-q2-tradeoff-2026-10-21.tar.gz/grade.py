import ast,json,re,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'Tools'))
from quantization_tasks import grade_python
P=Path(__file__).parent
rubrics={r['id']:r for r in json.loads((P/'quality-rubric.json').read_text())}
def grade(path):
 d=json.loads(Path(path).read_text()); rows=[]
 for run in d['runs']:
  r=rubrics.get(run['id'])
  if r is None:continue
  text=run['text'].strip();raw=text
  m=re.fullmatch(r'```(?:json|python)?\s*\n(.*?)\n```',text,re.S)
  if m:text=m.group(1).strip()
  detail={}
  try:
   if r['kind']=='json': semantic=json.loads(text)==r['value']
   else:
    # Type annotations do not change these pure-function results. Remove them
    # before using the existing restricted, resource-bounded repository worker.
    tree=ast.parse(text)
    for node in ast.walk(tree):
     if isinstance(node,ast.FunctionDef):node.returns=None
     if isinstance(node,ast.arg):node.annotation=None
    detail=grade_python(ast.unparse(tree),r);semantic=detail['passed']
  except Exception as e:semantic=False;detail={'error':f'{type(e).__name__}: {e}'}
  s=run.get('stats',{});response=run.get('response',{})
  finish=s.get('finishReason') or response.get('choices',[{}])[0].get('finish_reason') or run.get('finish_reason')
  runtime=finish=='stop' and not s.get('runtimeError') and not s.get('memoryPressureCancelled')
  rows.append({'id':run['id'],'category':r['category'],'semantic':bool(semantic and runtime),'strict':bool(semantic and runtime and text==raw),'runtime_ok':runtime,**detail})
 return {'file':str(path),'total':len(rows),'semantic':sum(x['semantic'] for x in rows),'strict':sum(x['strict'] for x in rows),'rows':rows}
if __name__=='__main__':print(json.dumps([grade(x) for x in sys.argv[1:]],indent=2))
