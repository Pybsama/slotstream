# Production control interpretation

The normal ten-GB CLI coding control uses automatic MTP selection (off), normal
read-ahead (on), an 8,192-token context window and greedy, non-thinking output.
It matches the prepared comparison prompt IDs exactly. Its 1,024 output tokens
take 217.568 seconds to decode, or 4.7066 tokens/s. Request time is 224.901
seconds. Observed lifetime physical-footprint peak is 6.1752 GB; the ten-GB
process target prices a full workload envelope rather than allocating every
reserved byte for this short input. Both boundary thermal readings are nominal
and global swap counters are unchanged for this coding request.

Demand-read bytes alone are not total expert traffic with read-ahead enabled.
This run reports 334.762 GB of demand bytes and 576.170 GB of read-ahead issued
bytes, including 484.255 GB adopted and 91.902 GB wasted. The issued counter is
a scheduling counter, not an independent physical SSD trace. Forecast evaluation
is 70.238 seconds, demand IO is 57.813 seconds; those counters are not an
exclusive wall-time decomposition. There are 1,023 decode forward passes.

The normal explanation control also completes, but its request interval has
global swap activity (4 pages in, 1,216 out). Preserve its functional and
bounded-memory result; exclude its timing from clean comparisons. This does
not establish which application paged.

An unrelated Swift app build restarted during the following native DFlash
diagnostic. The raw observations are in followup-contention.jsonl, beginning
after the competing build was noticed. They are not a complete historical
process trace for earlier runs. Exclude that DFlash run from clean throughput
claims irrespective of nominal boundary temperatures or zero paging. Later
controls must be checked against these observations too. No other task's
process was stopped or modified.

The Splash ten-GB flag limits Metal allocation rather than whole-process
footprint. Its frontend and engine peak around 9.5 to 9.6 GB in the comparable
runs and are independently guarded at eleven GB. Therefore this compares
declared operating budgets and actual implementations, not equal physical
allocations or quantization in isolation. A future native port should separately
measure whether conservative reservations can safely reclaim capacity without
weakening long-context and peak-workload memory guarantees.
