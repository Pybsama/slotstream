import json,statistics
from pathlib import Path
P=Path(__file__).parent
def rows():
 out=[]
 for path in sorted([*P.glob('native-*.json'),*P.glob('q2-*.json')]):
  d=json.loads(path.read_text())
  if not isinstance(d,dict) or 'runs' not in d:continue
  for r in d['runs']:
   if not (r['id'].startswith('perf-') or r['id']=='long-retrieval'):continue
   row={'file':path.name,'id':r['id'],'complete_run':d['complete'],'swapins':r['swapins_delta'],'swapouts':r['swapouts_delta']}
   if 'stats' in r:
    s=r['stats'];row.update(tokens=s['decodeTokens'],decode_tps=s['decodeTokens']/s['decodeSeconds'],request_seconds=s['requestSeconds'],prefill_seconds=s['prefillSeconds'],read_GB=s['decodeReadBytes']/1e9,io_seconds=s['decodeIOSeconds'],peak_GB=s['peakMemoryGB'],accepted=s['acceptedDrafts'],drafted=s['draftedTokens'],finish=s['finishReason'],thermal=[s['generatorSystemBefore']['thermalState'],s['generatorSystemAfter']['thermalState']],draft_seconds=s['draftSeconds'],verify_seconds=s['verifySeconds'],adaptive_plain_tokens=s['adaptivePlainTokens'],adaptive_depths=sorted(set(s['adaptiveDraftDepths'])))
   else:
    a,b=r['status_before'],r['status_after'];am,bm=a['metrics'],b['metrics'];se0=a['streamed_experts']['decode'];se1=b['streamed_experts']['decode']
    loads=se1['loads']-se0['loads'];routed=se1['routed']-se0['routed'];read=se1['read']-se0['read'];tim=r['timings']
    row.update(tokens=r['usage']['completion_tokens'],decode_tps=tim['predicted_per_second'],native_command_tps=(bm['decode_output_tokens']-am['decode_output_tokens'])*1000/(bm['decode_wall_ms']-am['decode_wall_ms']),request_seconds=r['elapsed_seconds'],prefill_seconds=tim['prompt_ms']/1000,read_GB=(se1['read_bytes']-se0['read_bytes'])/1e9,peak_GB=d['peak_combined_bytes']/1e9,accepted=tim.get('draft_n_accepted',0),drafted=tim.get('draft_n',0),finish=r['finish_reason'],thermal=[a['thermal_state'],b['thermal_state']],cache_slots=b['streamed_experts']['slots'],cache_arena_GB=b['streamed_experts']['arena_bytes']/1e9,cache_hit_fraction=1-read/routed,loads=loads,routed=routed,read=read)
    for key in ['pickup_ms','work_ms','resume_ms']:
     row[key.replace('_ms','_seconds')]=(se1['host_steps'][key]['total']-se0['host_steps'][key]['total'])/1000
   if 'stats' in r:
    pf=r['stats'].get('expertPrefetch',{})
    row['prefetch_issued_GB']=pf.get('issuedBytes',0)/1e9
    row['prefetch_adopted_GB']=pf.get('adoptedBytes',0)/1e9
    row['prefetch_wasted_GB']=pf.get('wastedBytes',0)/1e9
    row['prefetch_forecast_eval_seconds']=pf.get('forecastEvalSeconds',0)
    row['cache_hit_fraction']=r['stats'].get('expertHitRate')
    row['read_counter_scope']='demand bytes; prefetch issued bytes separately counted'
   row['read_MB_per_output']=row['read_GB']*1000/row['tokens'];row['clean_timing']=not(row['swapins'] or row['swapouts']) and row['thermal']==['nominal','nominal']
   if path.name in ['native-dflash-10-diagnostic.json','q2-all-bf16-10-diagnostic.json','q2-auto-bf16-10-diagnostic.json','native-mtp-10-long.json']:
    row['clean_timing']=False
    row['timing_exclusion']='concurrent desktop work; functional follow-up protocol'
   elif not row['clean_timing']:
    row['timing_exclusion']='global paging or nonnominal boundary thermal state'
   out.append(row)
 return out
if __name__=='__main__':
 data=rows();(P/'timing-summary-v2.json').write_text(json.dumps(data,indent=2))
 for r in data:print(r['file'],r['id'],f"{r['decode_tps']:.2f} tok/s {r['request_seconds']:.2f}s {r['read_GB']:.2f} GB read {r['peak_GB']:.2f} GB peak",'clean' if r['clean_timing'] else 'CONTAMINATED')
