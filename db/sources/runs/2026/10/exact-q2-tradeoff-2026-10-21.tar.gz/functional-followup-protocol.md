# Functional follow-up under concurrent desktop work

The second campaign completed both production controls and the native DFlash diagnostics. Unrelated Swift builds overlapped DFlash and repeatedly restarted. The campaign was interrupted during its thermal wait before Q2 all/BF16; no model was running at interruption. Both completed results and the wait trace are retained.

Run the remaining Q2 all/BF16, Q2 auto/BF16 and native MTP long-input diagnostics with all existing real-headroom, process-footprint and one-model guards. Nominal or fair thermal state permits these functional checks; serious or critical state refuses admission. Record competing builds at entry and retain thermal/paging observations. None of these intervals qualifies as a clean timing comparison. Their purpose is correctness without INT8 KV, mechanism counters and completion of the same long prompt.

Do not start the planned larger native or twenty-GB Q2 controls while other heavy work is present or the required headroom is unavailable. Capture their final resource check separately. The earlier completed sixteen-GB Q2 runs remain the larger-budget evidence. This amendment changes timing eligibility, not any memory limit, expected answer or grader.
