import json,os,subprocess,time
from pathlib import Path
P=Path(__file__).parent
started=time.monotonic()
with (P/'followup-contention.jsonl').open('x') as f:
 while time.monotonic()-started<1800:
  try:os.kill(52180,0)
  except ProcessLookupError:break
  ps=subprocess.check_output(['ps','-axo','pid,ppid,etime,%cpu,rss,comm'],text=True)
  work=[r for r in ps.splitlines() if any(x in r for x in ['swift-frontend','SlotstreamMacChecks','slotstream-home-ui'])]
  f.write(json.dumps({'time':time.time(),'other_work':work})+'\n');f.flush();time.sleep(5)
