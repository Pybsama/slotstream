import json,subprocess,sys,time
from pathlib import Path
P=Path(__file__).parent;ROOT=P.resolve().parents[1]
sys.path.insert(0,str(ROOT/'Tools'))
from prefill_bench import preflight,vm_snapshot,host_conditions,terminate_child_tree
from thermal import wait_nominal

def native(method,budget,cases,label):
 out=P/f'native-{method}-{budget}-{label}.json';assert not out.exists()
 before={'vm':preflight(budget+3),'host':host_conditions()};out.with_name(out.stem+'-host-before.json').write_text(json.dumps(before,indent=2))
 with out.with_suffix('.log').open('x') as log:
  child=subprocess.Popen([str(ROOT/'.build/release/slotstream'),'smart-dflash-check','--method',method,'--memory-gb',str(budget),'--cases',str(P/cases),'--output',str(out)],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:rc=child.wait(timeout=1200)
  finally:
   if child.poll() is None:terminate_child_tree(child)
 out.with_name(out.stem+'-host-after.json').write_text(json.dumps({'vm':vm_snapshot(),'host':host_conditions(),'exit_code':rc},indent=2))
 if rc:raise RuntimeError(f'native exited {rc}')

def upstream(verify,cases,label):
 out=P/f'q2-{verify}-bf16-10-{label}.json';assert not out.exists()
 child=subprocess.Popen([sys.executable,str(P/'upstream_bench.py'),'--memory-gb','10','--verify',verify,'--kv','bf16','--cases',str(P/cases),'--tokens',str(P/'diagnostic-prompt-ids.json'),'--output',str(out)],start_new_session=True)
 try:rc=child.wait(timeout=1200)
 finally:
  if child.poll() is None:terminate_child_tree(child)
 if rc:raise RuntimeError(f'Q2 exited {rc}')

def production(budget):
 cases=json.loads((P/'performance-cases.json').read_text())
 # Use the normal published CLI planner and Engine, including automatic MTP
 # and read-ahead, at the same 8K request window as upstream.
 rows=[];out=P/f'native-production-{budget}-diagnostic.json';assert not out.exists()
 for case in cases:
  wait_nominal(P/f'thermal-production-{budget}-{case["id"]}.json')
  prompt=P/f'production-{case["id"]}.txt'
  if not prompt.exists():prompt.write_text(case['prompt'])
  result=P/f'production-{budget}-{case["id"]}-raw.json';assert not result.exists()
  before={'vm':preflight(budget+3),'host':host_conditions()}
  command=[str(ROOT/'.build/release/slotstream'),'run','--model','smart','--memory-gb',str(budget),'--max-context','8192','--vision','off','--max-tokens',str(case['maxTokens']),'--prompt-file',str(prompt),'--greedy','--sample-footprint','--stats-json',str(result)]
  with result.with_suffix('.log').open('x') as log:
   child=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
   try:rc=child.wait(timeout=1200)
   finally:
    if child.poll() is None:terminate_child_tree(child)
  after={'vm':vm_snapshot(),'host':host_conditions(),'exit_code':rc}
  if rc:raise RuntimeError(f'production CLI exited {rc}')
  d=json.loads(result.read_text());assert d['stats']['peakMemoryGB']<=budget and not d['stats']['memoryPressureCancelled']
  base=next(r for r in json.loads((P/'native-mtp-10-r0.json').read_text())['runs'] if r['id']==case['id']);assert d['prompt_ids']==base['prompt_ids']
  rows.append({'id':case['id'],'prompt_ids':d['prompt_ids'],'text':d['text'],'stats':d['stats'],'plan':d['plan'],'swapins_delta':after['vm']['swapins']-before['vm']['swapins'],'swapouts_delta':after['vm']['swapouts']-before['vm']['swapouts'],'host_before':before,'host_after':after,'command':command})
  out.write_text(json.dumps({'method':'production-auto','memory_gb':budget,'runs':rows,'complete':len(rows)==len(cases)},indent=2))
  print('production',budget,case['id'],d['stats']['decodeTokens']/d['stats']['decodeSeconds'],d['plan']['mtp'],d['plan']['decode_lookahead'],flush=True)

def upstream20():
 out=P/'q2-auto-int8-20-diagnostic.json';assert not out.exists()
 child=subprocess.Popen([sys.executable,str(P/'upstream_bench.py'),'--memory-gb','20','--verify','auto','--kv','int8','--cases',str(P/'diagnostic-performance-cases.json'),'--tokens',str(P/'diagnostic-prompt-ids.json'),'--output',str(out)],start_new_session=True)
 try:rc=child.wait(timeout=1200)
 finally:
  if child.poll() is None:terminate_child_tree(child)
 if rc:raise RuntimeError(f'Q2 twenty-GB diagnostic exited {rc}')

steps=[('production-10',lambda:production(10)),('production-16',lambda:production(16)),('dflash-10',lambda:native('dflash',10,'diagnostic-performance-cases.json','diagnostic')),
 ('q2-all-bf16',lambda:upstream('all','diagnostic-quality-cases.json','diagnostic')),
 ('q2-auto-bf16',lambda:upstream('auto','diagnostic-performance-cases.json','diagnostic')),
 ('mtp-16',lambda:native('mtp',16,'diagnostic-performance-cases.json','diagnostic')),
 ('mtp-10-long',lambda:native('mtp',10,'long-cases.json','long')),
 ('q2-20',lambda:upstream20())]
log=P/'followup-events.json';assert not log.exists();events=[]
try:
 for label,fn in steps:
  events.append({'label':label,'began':time.time(),'status':'running'});log.write_text(json.dumps(events,indent=2));print('BEGIN',label,flush=True)
  wait_nominal(P/f'thermal-followup-{label}.json');fn();events[-1].update(ended=time.time(),status='complete');log.write_text(json.dumps(events,indent=2));print('END',label,flush=True)
except BaseException as e:
 events[-1].update(ended=time.time(),status='failed-or-refused',error=f'{type(e).__name__}: {e}');log.write_text(json.dumps(events,indent=2));raise
