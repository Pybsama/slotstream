"""Small interleaved timing comparison; retain paging and operating evidence."""
import hashlib,json,subprocess,sys,time
from pathlib import Path
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root.parent.parent/'Tools'))
from prefill_bench import preflight,vm_snapshot
binary=root.parent/'release/slotstream'
assert not subprocess.run(['pgrep','-f','[f]etch_small_ranges.py'],capture_output=True).stdout, 'Pause the checkpoint download first'
identity=hashlib.sha256(binary.read_bytes()).hexdigest()
receipt={'binary_sha256':identity,'rounds':[],'scope':'Three interleaved rounds, identical prompts and a fixed full-process budget. Not a 48 GB auto-size or upstream hardware benchmark.'}
output=root/'paired-timing-v2-receipt.json'
assert not output.exists()
for i,order in enumerate([['plain','mtp','dflash'],['dflash','mtp','plain'],['mtp','plain','dflash']]):
 for method in order:
  time.sleep(2); preflight(15); before=vm_snapshot(); dest=root/f'timing-v2-r{i}-{method}.json'
  command=[str(binary),'smart-dflash-check','--method',method,'--memory-gb','10','--cases',str(root/'timing-cases.json'),'--output',str(dest)]
  with dest.with_suffix('.log').open('w') as log:
   result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=300)
  after=vm_snapshot()
  row={'round':i,'method':method,'command':command,'returncode':result.returncode,'before':before,'after':after}
  if result.returncode==0:
   data=json.loads(dest.read_text());row['complete']=data['complete'];row['cases']=[]
   for r in data['runs']:
    s=r['stats']; system=[s.get('generatorSystemBefore',{}),s.get('generatorSystemAfter',{})]
    nominal=all(x.get('thermalState')=='nominal' and not x.get('lowPowerModeEnabled',False) for x in system)
    eligible=before['swapins']==after['swapins'] and before['swapouts']==after['swapouts'] and nominal
    row['cases'].append({'id':r['id'],'request_seconds':s['requestSeconds'],'first_text_seconds':s['firstTextSeconds'],
      'decode_seconds':s['decodeSeconds'],'decode_tokens':s['decodeTokens'],'finish_reason':s['finishReason'],
      'runtime_error':s.get('runtimeError'),'memory_pressure_cancelled':s['memoryPressureCancelled'],'peak_gb':s['peakMemoryGB'],
      'timing_eligible':eligible})
  receipt['rounds'].append(row);output.write_text(json.dumps(receipt,indent=2))
  print(i,method,result.returncode,flush=True)
  if result.returncode:raise SystemExit('Timing run failed; preserve partial receipt')
receipt['complete']=True;output.write_text(json.dumps(receipt,indent=2))
