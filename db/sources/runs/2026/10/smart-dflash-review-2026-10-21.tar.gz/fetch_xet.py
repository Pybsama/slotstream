import hashlib, json, os, time
from pathlib import Path
os.environ['HF_HUB_DISABLE_PROGRESS_BARS']='1'
os.environ['HF_HUB_DOWNLOAD_TIMEOUT']='60'
os.environ['HF_XET_NUM_CONCURRENT_RANGE_GETS']='8'
from huggingface_hub import hf_hub_download
meta=json.load(open('/tmp/slotstream-gsq-current.json'))
root=Path('.build/smart-dflash-eval'); rows=[]
for item in reversed([x for x in meta['siblings'] if x['rfilename'].startswith('Q2_0/')]):
    print('START', item['rfilename'], time.time(), flush=True)
    path=Path(hf_hub_download(repo_id=meta['id'], filename=item['rfilename'], revision=meta['sha'], local_dir=root/'gsq-xet'))
    h=hashlib.sha256()
    with path.open('rb') as f:
        while chunk:=f.read(8*1024*1024): h.update(chunk)
    assert path.stat().st_size==item['size'] and h.hexdigest()==item['lfs']['sha256']
    rows.append({'path':str(path.resolve()),'repository':meta['id'],'revision':meta['sha'],'bytes':path.stat().st_size,'sha256':h.hexdigest()})
    (root/'xet-receipt.json').write_text(json.dumps(rows,indent=2))
    print('VERIFIED',path.name,time.time(),flush=True)
