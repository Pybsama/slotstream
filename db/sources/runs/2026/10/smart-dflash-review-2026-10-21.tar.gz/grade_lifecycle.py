import json,sys
from pathlib import Path
root=Path(__file__).parent
out=[]
for name in sys.argv[1:]:
    p=Path(name); receipt=json.loads(p.read_text()); rows={r['id']:r for r in receipt['runs']}
    checks={}
    for key,r in rows.items():
        stats=r['stats']
        checks[key+'/healthy']=not stats.get('runtimeError') and not stats.get('requestFailure') and not stats.get('memoryPressureCancelled') and stats['peakMemoryGB']<=receipt['memory_gb']
        checks[key+'/streamed-text']=r['text']==r['streamed']
    for key,code in [('cold','JUNIPER-2846'),('repeat','JUNIPER-2846'),('after-cancel','CEDAR-1907')]:
        if key in rows: checks[key+'/exact']=rows[key]['text'].strip()==code
    if 'cancel' in rows: checks['cancel/bounded']=rows['cancel']['callbacks']==12 and rows['cancel']['stats']['finishReason']=='stop'
    if 'sampled' in rows: checks['sampled/nonempty']=bool(rows['sampled']['text'].strip()) and rows['sampled']['stats']['finishReason']=='stop'
    if 'stop-sequence' in rows: checks['stop-sequence/exact']=rows['stop-sequence']['text'].strip()=='one two three four'
    expected=json.loads((root/'tool-contract.json').read_text())
    for case in expected:
        if case['id'] not in rows: continue
        row=rows[case['id']]; calls=row.get('tool_calls',[])
        checks[case['id']+'/grammar']=not row['malformed_tool_call'] and len(calls)==1
        try: actual={'name':calls[0]['name'],'arguments':json.loads(calls[0]['arguments_json'])}
        except (IndexError,ValueError): actual=None
        checks[case['id']+'/exact-call']=actual==case['expected_tool']
    out.append({'input':str(p),'complete':receipt['complete'],'passed':receipt['complete'] and all(checks.values()),'checks':checks})
print(json.dumps(out,indent=2))
