"""Exact published GSQ checkpoint through the isolated Splash 1.4.0 build.

The copied host-spin library is disabled. No user installation or preferences
are touched. One bounded native process, finally terminated with its server.
"""
import ctypes,ctypes.util,hashlib,json,os,signal,subprocess,sys,threading,time,urllib.request
from pathlib import Path
root=Path(__file__).resolve().parent
repo=root.parent.parent
sys.path.insert(0,str(repo/'Tools'))
from prefill_bench import preflight, vm_snapshot
bundle=root/'upstream/splash-1.4.0-arm64-macos26'
python=bundle/'python/bin/python3'
engine=bundle/'engine/splash'
assert not (bundle/'engine/host-step.metallib').exists()
receipts=json.loads((root/'ranges-receipt.json').read_text())
targets=[r for r in receipts if r['repository']=='ISTA-DASLab/Qwen3.8-Flash-Next-GSQ-RCO-GGUF']
assert len(targets)==2, 'Both target shards must be completely downloaded and verified first'
assert json.loads((root/'tokenizer-identity.json').read_text())['pass']
target=Path(targets[0]['path']).resolve()
draft=Path.home()/'.slotstream/models/qwen38-flash-next-mlx-4bit/dflash'
prepare='''import json,sys
from install.local import prepare_local_model
a=json.load(sys.stdin)
print(prepare_local_model(a['target'],draft=a['draft'],language_only=True,models_dir=a['models_dir']))
'''
preflight(13)
prepared=subprocess.run([str(python),'-c',prepare],cwd=bundle,
    input=json.dumps({'target':str(target),'draft':str(draft),'models_dir':str(root/'upstream-prepared')}),
    text=True,capture_output=True,timeout=300)
(root/'upstream-prepare.log').write_text(prepared.stdout+prepared.stderr)
assert prepared.returncode==0, 'inspect upstream-prepare.log'
model_root=prepared.stdout.strip().splitlines()[-1]
command=[str(python),'-m','server.server',model_root,'--model',
    'ISTA-DASLab/Qwen3.8-Flash-Next-GSQ-RCO-GGUF:Q2_0','--binary',str(engine),
    '--host','127.0.0.1','--port','18973','--max-memory','10000000000',
    '--max-context','8192','--max-cache-disk','0','--verify-rows','all','--kv-format','bf16',
    '--disable-ane','--allow-idle-sleep','--idle-release','off']
cases=json.loads((root/'quality-cases.json').read_text())
baseline={r['id']:r for r in json.loads((root/'quality-plain.json').read_text())['runs']}
def request(path,body=None,timeout=300):
    req=urllib.request.Request('http://127.0.0.1:18973'+path,
        data=None if body is None else json.dumps(body).encode(),headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=timeout) as response: return json.load(response)
rows=[]; receipt={'method':'splash-1.4.0-gsq-q2-dflash2','command':command,
    'engine_sha256':hashlib.sha256(engine.read_bytes()).hexdigest(),
    'target_files':targets,'spin_disabled':True,'verify_rows':'all','kv_format':'bf16','complete':False,
    'scope':'Whole-stack comparison; same prompt token IDs, different target quantization and runtime. Not isolated quantization loss.', 'runs':rows}
log=(root/'upstream-server.log').open('w')
process=None
stopped=threading.Event(); memory={'peak_engine_bytes':0,'limit_bytes':10_000_000_000,'exceeded':False}
def observe_memory():
    lib=ctypes.CDLL(ctypes.util.find_library('proc'))
    while not stopped.wait(0.25):
        if process is None or process.poll() is not None: continue
        children=subprocess.run(['pgrep','-P',str(process.pid)],capture_output=True,text=True)
        for value in children.stdout.split():
            data=ctypes.create_string_buffer(296)
            if lib.proc_pid_rusage(int(value),4,data)!=0: continue
            footprint=max(int.from_bytes(data.raw[72:80],'little'),int.from_bytes(data.raw[240:248],'little'))
            memory['peak_engine_bytes']=max(memory['peak_engine_bytes'],footprint)
            if footprint>memory['limit_bytes']:
                memory['exceeded']=True
                try: os.killpg(process.pid,signal.SIGINT)
                except ProcessLookupError: pass
                return
receipt['physical_memory']=memory
observer=threading.Thread(target=observe_memory,daemon=True)
try:
    preflight(13)
    process=subprocess.Popen(command,cwd=bundle,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    observer.start()
    began=time.monotonic()
    for _ in range(300):
        if process.poll() is not None: raise RuntimeError('Splash exited before ready')
        try:
            ready=request('/ready',timeout=2)
            if ready: break
        except Exception: pass
        time.sleep(1)
    else: raise RuntimeError('Splash readiness timeout')
    receipt['startup_seconds']=time.monotonic()-began
    for case in cases:
        tokens=baseline[case['id']]['prompt_ids']
        before=vm_snapshot();start=time.monotonic()
        response=request('/v1/completions',{'model':'ISTA-DASLab/Qwen3.8-Flash-Next-GSQ-RCO-GGUF:Q2_0',
            'prompt':tokens,'temperature':0,'top_p':1,'max_tokens':case['maxTokens'],'stream':False})
        after=vm_snapshot()
        text=response['choices'][0]['text']
        rows.append({'id':case['id'],'text':text,'prompt_ids':tokens,'response':response,
            'elapsed_seconds':time.monotonic()-start,
            'swapins_delta':after['swapins']-before['swapins'],'swapouts_delta':after['swapouts']-before['swapouts']})
        receipt['complete']=len(rows)==len(cases)
        (root/'quality-upstream-q2.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False))
        print(case['id'],repr(text[:90]),flush=True)
except Exception as error:
    receipt['error']=f'{type(error).__name__}: {error}'
    (root/'quality-upstream-q2.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False))
    raise
finally:
    stopped.set()
    if process is not None and process.poll() is None:
        os.killpg(process.pid,signal.SIGINT)
        try: process.wait(timeout=15)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid,signal.SIGKILL);process.wait()
    log.close()
    (root/'quality-upstream-q2.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False))
