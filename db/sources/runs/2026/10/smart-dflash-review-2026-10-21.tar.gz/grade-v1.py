"""Frozen, bounded grading: literal JSON and restricted Python functions.

An optional single Python fence is accepted for semantic code grading and
reported separately as a formatting deviation. JSON must be literal JSON.
"""
import ast, json, subprocess, sys
from pathlib import Path

BUILTINS = ('sum', 'range', 'min', 'max', 'set', 'list', 'dict', 'tuple', 'len', 'enumerate', 'sorted', 'abs', 'int', 'float', 'bool', 'zip', 'all', 'any')
METHODS = {'append', 'add', 'extend', 'get', 'fromkeys', 'keys', 'values', 'items', 'count'}

def code_check(source, checks):
    source = source.strip()
    fenced = source.startswith('```python\n') and source.endswith('\n```')
    if fenced: source = source[len('```python\n'):-len('\n```')]
    tree = ast.parse(source)
    assert tree.body and all(isinstance(n, ast.FunctionDef) for n in tree.body), 'only function definitions allowed'
    allowed = (ast.Module, ast.FunctionDef, ast.arguments, ast.arg, ast.Return,
        ast.Assign, ast.AugAssign, ast.AnnAssign, ast.If, ast.IfExp, ast.For,
        ast.While, ast.Break, ast.Continue, ast.Pass, ast.Expr, ast.ListComp,
        ast.SetComp, ast.DictComp, ast.GeneratorExp, ast.comprehension, ast.Call,
        ast.Name, ast.Constant, ast.List, ast.Tuple, ast.Set, ast.Dict, ast.Subscript,
        ast.Slice, ast.Attribute, ast.BinOp, ast.UnaryOp, ast.BoolOp, ast.Compare,
        ast.operator, ast.unaryop, ast.boolop, ast.cmpop, ast.expr_context, ast.keyword)
    names = {n.name for n in tree.body}
    for node in ast.walk(tree):
        assert isinstance(node, allowed), type(node).__name__
        if isinstance(node, ast.Name): assert not node.id.startswith('_')
        if isinstance(node, ast.Attribute): assert node.attr in METHODS
        if isinstance(node, ast.FunctionDef):
            assert not node.decorator_list and not node.name.startswith('_')
        if isinstance(node, ast.Call):
            assert isinstance(node.func, (ast.Name, ast.Attribute))
            if isinstance(node.func, ast.Name): assert node.func.id in set(BUILTINS) | names
    payload = {'source': source, 'checks': checks}
    worker = '''import builtins,json,resource,sys
resource.setrlimit(resource.RLIMIT_CPU,(2,2))
payload=json.load(sys.stdin)
scope={'__builtins__': {k:getattr(builtins,k) for k in %r}}
exec(compile(payload['source'],'<restricted-model-code>','exec'),scope)
print(json.dumps([bool(eval(c,scope)) for c in payload['checks']]))
''' % (BUILTINS,)
    result = subprocess.run([sys.executable, '-I', '-c', worker], input=json.dumps(payload), text=True, capture_output=True, timeout=4)
    assert result.returncode == 0, result.stderr[-500:]
    values = json.loads(result.stdout)
    return all(values), {'checks': values, 'format_deviation': fenced}

def grade(path):
    contract = json.loads(Path(__file__).with_name('quality-contract.json').read_text())
    expected = {c['id']: c for c in contract['cases']}
    data = json.loads(Path(path).read_text()); rows = []
    for run in data['runs']:
        if run['id'] not in expected: continue
        case = expected[run['id']]
        try:
            if 'expected' in case:
                actual = json.loads(run['text'].strip())
                passed = actual == case['expected']; detail = {'actual': actual}
            else: passed, detail = code_check(run['text'], case['code_tests'])
        except Exception as e: passed, detail = False, {'error': f'{type(e).__name__}: {e}'}
        rows.append({'id': run['id'], 'pass': passed, **detail})
    return {'input': str(path), 'complete': data.get('complete'), 'passed': sum(r['pass'] for r in rows), 'total': len(rows), 'rows': rows}

if __name__ == '__main__':
    print(json.dumps([grade(p) for p in sys.argv[1:]], ensure_ascii=False, indent=2))
