"""Compare GGUF token IDs with the actual deployed native tokenizer."""
import hashlib,json,struct
from pathlib import Path
root=Path(__file__).parent
receipt=json.loads((root/'ranges-receipt.json').read_text())
item=next(r for r in receipt if r['repository'].startswith('ISTA-') and '00001' in r['path'])
p=Path(item['path']);f=p.open('rb')
def num(fmt): return struct.unpack('<'+fmt,f.read(struct.calcsize('<'+fmt)))[0]
def string(): return f.read(num('Q')).decode('utf-8')
def value(kind,keep):
 if kind==8:return string()
 if kind==9:
  k,n=num('I'),num('Q');items=[]
  for _ in range(n):
   v=value(k,keep)
   if keep:items.append(v)
  return items
 return num({0:'B',1:'b',2:'H',3:'h',4:'I',5:'i',6:'f',7:'?',10:'Q',11:'q',12:'d'}[kind])
assert f.read(4)==b'GGUF' and num('I')==3
nt,nk=num('Q'),num('Q');metadata={}
for _ in range(nk):
 k=string();v=value(num('I'),k=='tokenizer.ggml.tokens')
 if k=='tokenizer.ggml.tokens': metadata[k]=v
vocab=metadata['tokenizer.ggml.tokens']
path=Path.home()/'.slotstream/models/qwen38-flash-next-mlx-4bit/tokenizer.json'
native=json.loads(path.read_text());mapping=native['model']['vocab'].copy()
mapping.update({t['content']:t['id'] for t in native['added_tokens']})
mismatches=[{'token':t,'native_id':i,'gguf_token':vocab[i] if i<len(vocab) else None} for t,i in mapping.items() if i>=len(vocab) or vocab[i]!=t]
result={'native_tokenizer_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'gguf_sha256':item['sha256'],
 'native_vocab_entries':len(mapping),'gguf_vocab_entries':len(vocab),'mismatch_count':len(mismatches),'examples':mismatches[:10],
 'pass':not mismatches,'scope':'Token-to-ID identity, not chat-template or runtime equivalence.'}
(root/'tokenizer-identity.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
assert not mismatches
