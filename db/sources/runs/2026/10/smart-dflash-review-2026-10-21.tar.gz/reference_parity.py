"""Compare native draft hidden states with the upstream MLX reference.

Uses actual native target features, target embeddings and the exact draft.
Only draft linear projections are affine4/group64, matching Splash's loader.
No target model is loaded in this process.
"""
import hashlib, importlib.util, json, sys
from pathlib import Path
import mlx.core as mx
import mlx.nn as nn

root = Path(__file__).parent
fixture_path = root/(sys.argv[sys.argv.index('--fixture')+1] if '--fixture' in sys.argv else 'native-draft.safetensors')
sys.path.insert(0, str(Path('Tools').resolve()))
from prefill_bench import preflight
preflight(6)
mx.set_cache_limit(2_000_000_000)
reference = root/'upstream-model_mlx.py'
spec = importlib.util.spec_from_file_location('inco_dflash_reference', reference)
module = importlib.util.module_from_spec(spec); sys.modules[spec.name] = module; spec.loader.exec_module(module)
draft = Path.home()/'.slotstream/models/qwen38-flash-next-mlx-4bit/dflash'
module.snapshot_download = lambda *args, **kwargs: str(draft)
model = module.load_draft(str(draft))
nn.quantize(model, group_size=64, bits=4, class_predicate=lambda name, layer: isinstance(layer, nn.Linear))
mx.eval(model.parameters())
fixture = mx.load(str(fixture_path))
features = fixture['context_features']; native = fixture['draft_hidden']
noise = fixture['noise_embedding']; end = int(fixture['context_end'].item())
model.embed_tokens = lambda _: noise
if '--unfused-swiglu' in sys.argv:
    module.MLP.__call__ = lambda self,x: self.down_proj(nn.silu(self.gate_proj(x))*self.up_proj(x))
if '--native-rope' in sys.argv:
    def native_rope(x, offset=0):
        frequencies = mx.power(mx.array(10000.0), -mx.arange(0,128,2,dtype=mx.float32)/128)
        angles = mx.arange(offset,offset+x.shape[-2],dtype=mx.float32)[:,None]*frequencies
        angles = mx.concatenate([angles,angles],axis=-1)
        rotated = mx.concatenate([-x[...,64:],x[...,:64]],axis=-1)
        return x*mx.cos(angles).astype(x.dtype) + rotated*mx.sin(angles).astype(x.dtype)
    model.rope = native_rope
cache = model.make_cache()
for entry in cache: entry.offset = end - features.shape[1]
chunks = [features.shape[1]]
if '--chunked' in sys.argv:
    # Native receipt: first prompt has 50 rows, then three plain calibration
    # steps before the first proposal. Keep those exact projection shapes.
    assert features.shape[1] == 53 and end == 53
    chunks = [50,1,1,1]
    at=0
    for count in chunks[:-1]:
        projected=model.hidden_norm(model.fc(features[:,at:at+count]))
        for layer, entry in zip(model.layers,cache):
            attention=layer.self_attn
            k=attention.k_norm(attention.k_proj(projected).reshape(1,count,8,128)).transpose(0,2,1,3)
            v=attention.v_proj(projected).reshape(1,count,8,128).transpose(0,2,1,3)
            k=model.rope(k,offset=entry.offset)
            keys,values=entry.update_and_fetch(k,v)
            mx.eval(keys,values)
        at+=count
    features=features[:,at:]
result = model.hidden_states(mx.zeros((1,8),dtype=mx.int32), features, cache, logits_start=1)[:, :native.shape[1]]
a, b = result.astype(mx.float32), native.astype(mx.float32)
delta = a-b
rmse = float(mx.sqrt(mx.mean(delta*delta)).item())
relative_rmse = rmse/float(mx.sqrt(mx.mean(a*a)).item())
cosine = float((mx.sum(a*b)/(mx.sqrt(mx.sum(a*a))*mx.sqrt(mx.sum(b*b)))).item())
receipt = {'reference_sha256': hashlib.sha256(reference.read_bytes()).hexdigest(),
    'fixture_sha256': hashlib.sha256(fixture_path.read_bytes()).hexdigest(),
    'shape': list(native.shape), 'context_rows': features.shape[1], 'context_end': end,
    'rmse': rmse, 'relative_rmse': relative_rmse, 'cosine': cosine,
    'max_absolute': float(mx.max(mx.abs(delta)).item()),
    'exact_elements_fraction': float(mx.mean(a==b).item()),
    'note': 'Diagnostic numeric comparison, not an output-quality measurement or proof of bitwise parity.'}
if 'candidate_ids' in fixture:
    projected = model.candidate_selector.hidden_projection(result)
    previous = int(fixture['anchor'].item()); path = []
    for position in range(native.shape[1]):
        candidates = fixture['candidate_ids'][0,position]
        pred = model.candidate_selector.predecessor_codebook.weight[previous].astype(mx.float32)
        succ = model.candidate_selector.successor_codebook.weight[candidates].astype(mx.float32)
        edges = mx.sum(pred * projected[0,position].astype(mx.float32) * succ,axis=-1)
        choice = int(mx.argmax(fixture['candidate_scores'][0,position]+edges).item())
        previous = int(candidates[choice].item()); path.append(previous)
    receipt['selector_float32_path'] = path
    receipt['native_proposals'] = fixture['draft_proposals'].tolist()
    receipt['selector_matches'] = path == receipt['native_proposals']
    receipt['selector_scope'] = 'Independent reference projection/codebooks with Splash float32 edge arithmetic, using captured target candidate logits.'
receipt['native_rope_diagnostic'] = '--native-rope' in sys.argv
receipt['projection_chunks'] = chunks
receipt['unfused_swiglu_diagnostic'] = '--unfused-swiglu' in sys.argv
output = 'reference-parity-native-rope.json' if '--native-rope' in sys.argv else 'reference-parity.json'
if '--chunked' in sys.argv: output=output.replace('.json','-chunked.json')
if '--unfused-swiglu' in sys.argv: output=output.replace('.json','-unfused.json')
if '--fixture' in sys.argv: output=fixture_path.stem+'-'+output
(root/output).write_text(json.dumps(receipt,indent=2)); print(json.dumps(receipt,indent=2))
