import concurrent.futures,hashlib,json,os,time,urllib.request
from pathlib import Path
root=Path('.build/smart-dflash-eval')
smart=json.load(open('/tmp/slotstream-smart-dflash-metadata.json'))
gsq=json.load(open('/tmp/slotstream-gsq-current.json'))
objects=[]
for meta,dest,include in [(smart,Path.home()/'.slotstream/models/qwen38-flash-next-mlx-4bit/dflash',lambda n:n=='model.safetensors'),(gsq,root/'gsq',lambda n:n.startswith('Q2_0/'))]:
 for item in meta['siblings']:
  if include(item['rfilename']): objects.append((meta,item,dest/Path(item['rfilename']).name))
receipts=[]
for meta,item,path in objects:
 path.parent.mkdir(parents=True,exist_ok=True)
 size=item['size']; sha=item['lfs']['sha256'];chunk=64*1024*1024
 part=Path(str(path)+'.ranges');journal=Path(str(path)+'.chunks.json')
 if path.exists():
  print('Existing complete candidate:',path.name,flush=True)
 else:
  done=set(json.loads(journal.read_text()) if journal.exists() else [])
  fd=os.open(part,os.O_RDWR|os.O_CREAT,0o600);os.ftruncate(fd,size)
  def read_chunk(start):
   count=min(chunk,size-start);end=start+count-1
   url='https://huggingface.co/'+meta['id']+'/resolve/'+meta['sha']+'/'+item['rfilename']+f'?slotstream_range={start}-{count}'
   last=None
   for attempt in range(3):
    try:
     req=urllib.request.Request(url,headers={'Range':f'bytes={start}-{end}','Accept-Encoding':'identity'})
     with urllib.request.urlopen(req,timeout=45) as response:
      assert response.status==206 and response.headers.get('Content-Range')==f'bytes {start}-{end}/{size}',(response.status,response.headers.get('Content-Range'))
      offset=start
      while offset<=end:
       data=response.read(min(4*1024*1024,end-offset+1))
       if not data: raise ValueError('truncated range')
       written=os.pwrite(fd,data,offset);assert written==len(data);offset+=written
      assert not response.read(1)
     return start
    except Exception as e:
     last=e
     if attempt<2: time.sleep(1+attempt)
   raise RuntimeError(f'Chunk {start} failed: {type(last).__name__}')
  starts=[s for s in range(0,size,chunk) if s not in done]
  began=time.monotonic()
  try:
   with concurrent.futures.ThreadPoolExecutor(max_workers=16) as pool:
    for start in pool.map(read_chunk,starts):
     os.fsync(fd);done.add(start);journal.write_text(json.dumps(sorted(done)))
     if len(done)%8==0: print(path.name,round(min(len(done)*chunk,size)/1e9,2),'GB',round(time.monotonic()-began),'s',flush=True)
  finally: os.close(fd)
  assert len(done)==(size+chunk-1)//chunk
  part.rename(path)
 h=hashlib.sha256()
 with path.open('rb') as f:
  while data:=f.read(8*1024*1024): h.update(data)
 assert path.stat().st_size==size and h.hexdigest()==sha,'hash mismatch'
 receipts.append(dict(path=str(path),repository=meta['id'],revision=meta['sha'],bytes=size,sha256=sha))
 (root/'ranges-receipt.json').write_text(json.dumps(receipts,indent=2))
 print('VERIFIED',path.name,flush=True)
