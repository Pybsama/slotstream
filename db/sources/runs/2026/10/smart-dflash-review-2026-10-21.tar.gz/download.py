import urllib.request, json, hashlib, os
from pathlib import Path
meta=json.load(open('/tmp/slotstream-smart-dflash-metadata.json'))
root=Path.home()/'.slotstream/models/qwen38-flash-next-mlx-4bit/dflash'
root.mkdir(exist_ok=True)
rows=[]
for item in meta['siblings']:
 name=item['rfilename']
 if name not in ('README.md','config.json','model.safetensors'): continue
 path=root/name; temporary=root/(name+'.download')
 if not path.exists():
  url='https://huggingface.co/'+meta['id']+'/resolve/'+meta['sha']+'/'+name
  with urllib.request.urlopen(url,timeout=60) as response, temporary.open('wb') as out:
   while block:=response.read(4*1024*1024): out.write(block)
  temporary.rename(path)
 h=hashlib.sha256()
 with path.open('rb') as f:
  while b:=f.read(4*1024*1024): h.update(b)
 assert path.stat().st_size==item['size']
 if 'lfs' in item: assert h.hexdigest()==item['lfs']['sha256']
 rows.append(dict(path=name,size=path.stat().st_size,sha256=h.hexdigest()))
 print(rows[-1],flush=True)
Path('.build/smart-dflash-eval/download-receipt.json').write_text(json.dumps(dict(repository=meta['id'],revision=meta['sha'],files=rows),indent=2))
