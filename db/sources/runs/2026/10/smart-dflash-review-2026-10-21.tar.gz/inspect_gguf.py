"""Read only the downloaded, journaled header of the first GGUF shard."""
import collections, json, struct
from pathlib import Path
root=Path(__file__).parent
path=next((root/'gsq').glob('*.ranges'))
journal=json.loads(Path(str(path).replace('.ranges','.chunks.json')).read_text())
assert 0 in journal
f=path.open('rb')
def unpack(fmt): return struct.unpack('<'+fmt,f.read(struct.calcsize('<'+fmt)))[0]
def string():
    length=unpack('Q'); assert length<64*1024*1024
    return f.read(length).decode('utf-8')
def value(kind,keep=True):
    if kind==8: return string()
    if kind==9:
        t=unpack('I'); n=unpack('Q'); assert n<10_000_000
        items=[]
        for i in range(n):
            v=value(t)
            if keep and n<1024: items.append(v)
        return items if keep and n<1024 else {'array_type':t,'count':n}
    return unpack({0:'B',1:'b',2:'H',3:'h',4:'I',5:'i',6:'f',7:'?',10:'Q',11:'q',12:'d'}[kind])
assert f.read(4)==b'GGUF'
version=unpack('I'); assert version==3
nt,nk=unpack('Q'),unpack('Q'); metadata={}
for _ in range(nk):
    k=string(); t=unpack('I'); metadata[k]=value(t)
tensors=[]
for _ in range(nt):
    name=string(); dims=[unpack('Q') for _ in range(unpack('I'))]
    tensors.append({'name':name,'dimensions':dims,'type':unpack('I'),'offset':unpack('Q')})
assert f.tell()<64*1024*1024
out={'scope':'first shard header only; payload incomplete','metadata':metadata,'tensors':tensors,'header_bytes':f.tell()}
(root/'gsq-header.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'metadata':{k:v for k,v in metadata.items() if not k.startswith('tokenizer.')},
    'tensor_types':dict(collections.Counter(t['type'] for t in tensors)),
    'tensor_examples':tensors[:10],'header_bytes':f.tell()},indent=2))
