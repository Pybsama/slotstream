import json,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];B=P/'v51/slotstream'
sys.path.insert(0,str(R/'.build/native-q2-20261021'));from grade_v2 import grade
cases=P/'v20b-quality-functional-cases.json'
for model,method in [('fast','fast'),('smart-q2','q2')]:
 label='v51b-native-quality-'+model;out=P/(label+'.json')
 cmd=[sys.executable,str(P/'guarded_run.py'),'--label',label,'--env','SLOTSTREAM_NATIVE_DEFERRED_ROUTES=0','--budget','9','--',str(B),'smart-dflash-check','--native-read-ahead',('on' if method=='q2' else 'off'),'--method',method,'--model',model,'--memory-gb','9','--max-context','8192','--cases',str(cases),'--output',str(out)]
 print('REVIEW FROZEN COMPLETED RUN',label,flush=True)
 observer=json.loads((P/(label+'.observer.json')).read_text())
 assert observer['complete'] and observer['exit_code']==0
 assert observer['binary_sha256']==json.loads((P/'v51/sha256.json').read_text())['slotstream']
 g=grade(out);(P/(label+'-review-c-grades.json')).write_text(json.dumps(g,indent=2))
 d=json.loads(out.read_text());rows=d['runs'];r={x['id']:x for x in rows}
 def parsed(text):
  try:return json.loads(text)
  except ValueError:return None
 tools=r['native-tool']['tool_calls']
 checks=dict(topk=any(x["native_draft_topk"]>0 for x in rows),parallel_pieces=(model!='smart-q2' or any((x['stats'].get('expertPrefetch',{}).get('parallelPieceRecords')or 0)>0 for x in rows)),packed_draft=any(x["draft_packed_projections"]>0 for x in rows),draft_convolutions=any(x['native_draft_convolutions']>0 for x in rows),mixed_expert=(model!='smart-q2' or all(x['native_mixed_expert_submissions']>0 for x in rows)),gdn_pair=(model!='smart-q2' or any(x['stats']['nativeExecution'].get('gdnInputPairs',0)>0 for x in rows)),ordinary_route=all(x['stats']['nativeExecution'].get('deferredExpertPasses',0)==0 for x in rows),gpu_staging=(model!='smart-q2' or any(x['stats']['nativeExecution'].get('gpuRepackedRecords',0)>0 for x in rows)),raw_forecast=(model!='smart-q2' or any(':raw-q2' in x['stats'].get('expertPrefetch',{}).get('predictorIdentity','')for x in rows)),native_projection_valid=all(x['native_projection_schedule_failures']==0 and x['stats']['nativeExecution']['projectionFailures']==0 for x in rows),native_expert_exercised=any(x['native_expert_scheduled_passes']>0 for x in rows),read_ahead_policy=(all(x['stats'].get('expertPrefetch',{}).get('issued',0)==0 for x in rows) if model=='fast' else any(x['stats'].get('expertPrefetch',{}).get('issued',0)>0 for x in rows)), recall=r['conversation-recall']['text'].strip()=='CEDAR-2481',
  cancelled=r['cancel']['callbacks']==12,after_cancel=parsed(r['after-cancel']['text'])=={'ok':True},
  stop=r['stop-string']['text'].strip()=='one two three',
  one_native_tool=len(tools)==1 and tools[0]['name']=='lookup_record' and parsed(tools[0]['arguments_json'])=={'key':'CEDAR-2481'},
  streams=all(x['streamed']==x['text']for x in rows),
  bounded=all(x['stats']['peakMemoryGB']<=9 and not x['stats']['memoryPressureCancelled']and not x['stats'].get('runtimeError')for x in rows),
  long_retrieval=all(parsed(r[k]['text'])=={'audit_code':'PINE-3926'}for k in ('long-retrieval','long-retrieval-repeat')),
  prefix_reuse=r['short-retrieval-repeat']['stats']['reusedPrefixTokens']>0, short_retrieval=all(parsed(r[k]['text'])=={'audit_code':'BIRCH-7412'}for k in ('short-retrieval','short-retrieval-repeat')), gpu_forecast=(model!='smart-q2' or any(x['stats']['nativeExecution'].get('gpuForecastRecords',0)>0 for x in rows)))
 audit=dict(source=out.name,requests=len(rows),checks=checks,passed=all(checks.values()),long_prefix_reuse=r['long-retrieval-repeat']['stats']['reusedPrefixTokens'],long_prefix_refusals=r['long-retrieval-repeat']['stats']['prefixCheckpointRefusals'],retention_budget_tokens=d['plan']['prefix_cache_max_tokens'])
 (P/(label+'-review-c-functional.json')).write_text(json.dumps(audit,indent=2));print('GRADE',model,g['semantic'],g['strict'],'FUNCTIONAL',checks,flush=True)


 prior=json.loads((P/('v49-native-quality-'+model+'-grades.json')).read_text())
 old={x['id']:x for x in prior['rows']}
 regressions=[dict(id=x['id'],field=k,old=old[x['id']][k],new=x[k]) for x in g['rows']for k in ['semantic','strict','runtime_ok']if old[x['id']][k] and not x[k]]
 previous={x['id']:x for x in json.loads((P/('v49-native-quality-'+model+'.json')).read_text())['runs']}
 changes=[dict(id=x['id'],old=previous[x['id']]['text'],new=x['text'])for x in rows if x['tokens']!=previous[x['id']]['tokens']]
 (P/(label+'-review-c-comparison.json')).write_text(json.dumps(dict(regressions=regressions,token_changes=changes,baseline='v49',old_semantic=prior['semantic'],new_semantic=g['semantic'],old_strict=prior['strict'],new_strict=g['strict']),indent=2)+'\n')
 if not audit["passed"] or regressions: raise SystemExit(1)
