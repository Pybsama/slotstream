import Foundation
import MLX

/// Bounded GPU top-16 adapted from Splash 1482f6b sampling.metal (Apache-2.0).
/// Eight shards stream each vocabulary row, retaining only sixteen candidates
/// each. The merge keeps Splash's total order: score descending, token ID
/// ascending. No full-vocabulary index sort or retained model state is needed.
/// Raw draft logits must be finite; a failed selection aborts the request.
package enum NativeDraftTopK {
    private static let lock = NSLock()
    private static var submissions = 0
    package static var submissionCount: Int { lock.withLock { submissions } }
    package struct Candidates {
        package let indices: MLXArray
        package let scores: MLXArray
        private let invalid: MLXArray
        fileprivate init(indices: MLXArray, scores: MLXArray, invalid: MLXArray) {
            self.indices=indices; self.scores=scores; self.invalid=invalid
        }
        package func checkFinite() throws {
            guard !invalid.asArray(UInt32.self).contains(where: { $0 != 0 }) else {
                throw ModelError("DFlash candidate selection received non-finite logits")
            }
        }
    }
    package static func select(_ logits: MLXArray) -> Candidates {
        precondition(logits.ndim == 3 && logits.dim(0) == 1 && (1...7).contains(logits.dim(1))
            && (16...248_320).contains(logits.dim(2)) && logits.dtype == .float32)
        let depth=logits.dim(1), vocabulary=logits.dim(2)
        let pieces=shards([contiguous(logits)], template: [("DEPTH",depth),("VOCAB",vocabulary)],
            grid: (depth*8*256,1,1), threadGroup: (256,1,1),
            outputShapes: [[depth,8,16],[depth,8,16],[depth,8]],
            outputDTypes: [.uint32,.float32,.uint32])
        let result=merge([pieces[0],pieces[1],pieces[2]], grid: (depth*32,1,1), threadGroup: (32,1,1),
            outputShapes: [[1,depth,16],[1,depth,16],[depth]],outputDTypes: [.uint32,.float32,.uint32])
        lock.withLock { submissions += 1 }
        return Candidates(indices: result[0],scores: result[1],invalid: result[2])
    }
    private static let header = #"""
inline bool top_beats(float value, uint token, float other, uint other_token) {
  return value > other || (value == other && token < other_token);
}

// Register-resident sorted top-16 insert for an entry the caller has already
// checked against the last slot; the unrolled shift keeps every index static.
inline void top16_insert(thread float (&values)[16], thread uint (&ids)[16],
                         float value, uint token) {
#pragma clang loop unroll(full)
  for (uint slot = 15; slot > 0; --slot) {
    bool here = top_beats(value, token, values[slot], ids[slot]);
    bool above = top_beats(value, token, values[slot - 1], ids[slot - 1]);
    values[slot] = here ? (above ? values[slot - 1] : value) : values[slot];
    ids[slot] = here ? (above ? ids[slot - 1] : token) : ids[slot];
  }
  bool top = top_beats(value, token, values[0], ids[0]);
  values[0] = top ? value : values[0];
  ids[0] = top ? token : ids[0];
}

// Pops the head of a register-resident sorted list of Count entries.
template <uint Count>
inline void top_pop(thread float (&values)[Count], thread uint (&ids)[Count]) {
#pragma clang loop unroll(full)
  for (uint slot = 0; slot + 1 < Count; ++slot) {
    values[slot] = values[slot + 1];
    ids[slot] = ids[slot + 1];
  }
  values[Count - 1] = -INFINITY;
  ids[Count - 1] = 0xffffffffu;
}

// The simdgroup's best list head: (value desc, id asc), so ties and the
// empty sentinel (-inf, ~0u) resolve the same way everywhere.
inline void simd_best_head(float value, uint token, thread float &best,
                           thread uint &best_token) {
  best = simd_max(value);
  best_token = simd_min(value == best ? token : 0xffffffffu);
}

inline void top16_merge_shards(device const uint *partial_ids,
                               device const float *partial_values,
                               uint row, uint lane, thread float &value,
                               thread uint &token) {
  constexpr uint K = 16;
  constexpr uint Shards = 8;
  constexpr uint Entries = Shards * K / 32;
  uint origin = row * Shards * K + lane * Entries;
  float values[Entries];
  uint ids[Entries];
  for (uint i = 0; i < Entries; ++i) {
    values[i] = partial_values[origin + i];
    ids[i] = partial_ids[origin + i];
  }
  value = -INFINITY;
  token = 0xffffffffu;
  for (uint rank = 0; rank < K; ++rank) {
    float best;
    uint best_id;
    simd_best_head(values[0], ids[0], best, best_id);
    if (lane == rank) {
      value = best;
      token = best_id;
    }
    if (values[0] == best && ids[0] == best_id)
      top_pop<Entries>(values, ids);
  }
}


"""#
    private static let shards = MLXFast.metalKernel(name: "slotstream_draft_top16_shards",
        inputNames: ["logits"], outputNames: ["partial_ids","partial_values","invalid"], source: #"""
  uint group=threadgroup_position_in_grid.x;
  uint thread_index=thread_index_in_threadgroup, lane=thread_index_in_simdgroup;
  uint simd_group=simdgroup_index_in_threadgroup, vocabulary=VOCAB;
  bool invalid_value=false;
  constexpr uint Positions = DEPTH;
  constexpr uint Shards = 8;
  constexpr uint K = 16;
  constexpr uint VectorTokens = 4, ChunkVectors = 16;
  uint batch = group / (Positions * Shards);
  uint local = group % (Positions * Shards);
  uint position = local / Shards;
  uint shard = local % Shards;
  ulong row_start = (ulong(batch) * Positions + position) * vocabulary;
  uint shard_tokens = (vocabulary + Shards - 1) / Shards;
  uint begin = min(shard * shard_tokens, vocabulary);
  uint end = min(begin + shard_tokens, vocabulary);
  // Vector loads require 16-byte alignment. Handle the shard's unaligned head
  // and tail with scalar inserts; the logits binding must also be aligned.
  uint head = uint((VectorTokens - (row_start + begin) % VectorTokens) %
                   VectorTokens);
  head = min(head, end - begin);
  uint vectors = (end - begin - head) / VectorTokens;
  uint vector_begin = begin + head;
  uint tail_begin = vector_begin + vectors * VectorTokens;
  device const float *row = logits + row_start;
  device const float4 *vector_row =
      reinterpret_cast<device const float4 *>(row + vector_begin);

  float values[K];
  uint ids[K];
  for (uint i = 0; i < K; ++i) {
    values[i] = -INFINITY;
    ids[i] = 0xffffffffu;
  }
  if (thread_index < head) {
    uint token = begin + thread_index;
    float value = row[token];
    if((as_type<uint>(value) & 0x7f800000u) == 0x7f800000u){invalid_value=true;value=-INFINITY;}
    if (top_beats(value, token, values[K - 1], ids[K - 1]))
      top16_insert(values, ids, value, token);
  }
  if (thread_index < end - tail_begin) {
    uint token = tail_begin + thread_index;
    float value = row[token];
    if((as_type<uint>(value) & 0x7f800000u) == 0x7f800000u){invalid_value=true;value=-INFINITY;}
    if (top_beats(value, token, values[K - 1], ids[K - 1]))
      top16_insert(values, ids, value, token);
  }

  threadgroup float maxima[256];
  threadgroup float thresholds[8];
  for (uint chunk = 0; chunk < vectors; chunk += 256 * ChunkVectors) {
    float4 loaded[ChunkVectors];
    float best = -INFINITY;
    for (uint i = 0; i < ChunkVectors; ++i) {
      uint index = chunk + thread_index + i * 256;
      loaded[i] = index < vectors ? vector_row[index] : float4(0.0f);
      if (index < vectors) {
        for (uint j = 0; j < VectorTokens; ++j)
          {
            if((as_type<uint>(loaded[i][j]) & 0x7f800000u) == 0x7f800000u) {invalid_value=true;loaded[i][j]=-INFINITY;}
            if(loaded[i][j]>best) best=loaded[i][j];
          }
      }
    }
    // The 16th largest thread maximum: the minimum over the maxima that
    // fewer than sixteen others exceed.
    maxima[thread_index] = best;
    threadgroup_barrier(mem_flags::mem_threadgroup);
    uint above = 0;
    for (uint other = 0; other < 256; ++other)
      above += maxima[other] > best ? 1u : 0u;
    float candidate = simd_min(above < K ? best : INFINITY);
    if (lane == 0)
      thresholds[simd_group] = candidate;
    threadgroup_barrier(mem_flags::mem_threadgroup);
    float threshold = thresholds[0];
    for (uint other = 1; other < 8; ++other)
      threshold = min(threshold, thresholds[other]);

    for (uint i = 0; i < ChunkVectors; ++i) {
      uint index = chunk + thread_index + i * 256;
      if (index >= vectors)
        continue;
      uint token = vector_begin + index * VectorTokens;
      for (uint j = 0; j < VectorTokens; ++j) {
        float value = loaded[i][j];
        if (value >= threshold &&
            top_beats(value, token + j, values[K - 1], ids[K - 1]))
          top16_insert(values, ids, value, token + j);
      }
    }
  }

  // Sixteen rounds pop the group-wide best head; the simdgroup bests
  // alternate between two slots so one barrier per round suffices.
  threadgroup float round_values[2][8];
  threadgroup uint round_ids[2][8];
  for (uint rank = 0; rank < K; ++rank) {
    float head_value = values[0];
    uint head_id = ids[0];
    float simd_value;
    uint simd_id;
    simd_best_head(head_value, head_id, simd_value, simd_id);
    uint slot = rank & 1;
    if (lane == 0) {
      round_values[slot][simd_group] = simd_value;
      round_ids[slot][simd_group] = simd_id;
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    float best = round_values[slot][0];
    uint best_id = round_ids[slot][0];
    for (uint other = 1; other < 8; ++other) {
      float value = round_values[slot][other];
      uint token = round_ids[slot][other];
      if (top_beats(value, token, best, best_id)) {
        best = value;
        best_id = token;
      }
    }
    if (thread_index == rank) {
      partial_ids[group * K + rank] = best_id;
      partial_values[group * K + rank] = best;
    }
    if (head_value == best && head_id == best_id)
      top_pop<K>(values, ids);
  }
  threadgroup uint invalid_groups[8];
  bool group_invalid=simd_any(invalid_value);
  if(lane==0)invalid_groups[simd_group]=uint(group_invalid);
  threadgroup_barrier(mem_flags::mem_threadgroup);
  if(thread_index==0){uint bad=0;for(uint i=0;i<8;++i)bad|=invalid_groups[i];invalid[group]=bad;}

"""#,header:header)
    private static let merge = MLXFast.metalKernel(name: "slotstream_draft_top16_merge",
        inputNames: ["partial_ids","partial_values","invalid_shards"], outputNames: ["ids","scores","invalid"], source: #"""
        uint lane=thread_index_in_simdgroup, row=threadgroup_position_in_grid.x;
        float value;uint token;
        top16_merge_shards(partial_ids,partial_values,row,lane,value,token);
        if(lane<16){ids[row*16+lane]=token;scores[row*16+lane]=value;}
        if(lane==0){uint bad=0;for(uint i=0;i<8;++i)bad|=invalid_shards[row*8+i];invalid[row]=bad;}
"""#,header:header)
}
