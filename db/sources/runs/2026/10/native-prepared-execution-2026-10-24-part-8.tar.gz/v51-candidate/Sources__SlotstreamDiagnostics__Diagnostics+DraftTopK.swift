import Foundation
import MLX
import Slotstream

extension Diagnostics {
    /// Independent full CPU sort, unlike the GPU's sharded retained lists.
    static func draftTopK(_ c: inout CheckBuilder) {
        for (vocabulary, depth) in [(16,1),(17,3),(31,7),(257,2),(513,7),(4097,3),(248320,7)] {
            for mode in 0...2 {
                let values: [Float] = (0..<(vocabulary * depth)).map { index in
                    if mode == 2 { return index % 2 == 0 ? Float(0) : -Float(0) }
                    if mode == 1 { return Float((index * 7) % 5 - 2) }
                    let mixed = UInt32(truncatingIfNeeded: index) &* 1664525 &+ 1013904223
                    return Float(Int(mixed % 1000003) - 500001) / 128
                }
                let input=MLXArray(values,[1,depth,vocabulary])
                let selected=NativeDraftTopK.select(input)
                eval(selected.indices,selected.scores)
                let ids=selected.indices.asArray(UInt32.self), scores=selected.scores.asArray(Float.self)
                var expected: [UInt32]=[], expectedScores: [Float]=[]
                for row in 0..<depth {
                    let ordered=(0..<vocabulary).sorted {
                        let a=values[row*vocabulary+$0], b=values[row*vocabulary+$1]
                        return a>b || (a==b && $0<$1)
                    }.prefix(16)
                    expected += ordered.map(UInt32.init)
                    expectedScores += ordered.map { values[row*vocabulary+$0] }
                }
                let label="draft top16 vocab \(vocabulary) depth \(depth) mode \(mode)"
                c.equal(label+" IDs",ids,expected)
                c.equal(label+" original scores",scores,expectedScores)
                do { try selected.checkFinite(); c.expect(label+" finite",true) }
                catch { c.expect(label+" finite",false) }
            }
        }
        // Opt-in component timing. Output evaluation is included, model loading
        // and input construction are excluded. This is not a serving benchmark.
        if ProcessInfo.processInfo.environment["SLOTSTREAM_CHECK_DRAFT_TOPK_TIMING"] == "1" {
            for depth in [1,3,7] {
                let vocabulary=248320
                let values: [Float]=(0..<(depth*vocabulary)).map { i in
                    Float(Int((UInt32(truncatingIfNeeded:i) &* 1664525 &+ 1013904223) % 1000003)-500001)/128
                }
                let input=MLXArray(values,[1,depth,vocabulary]);eval(input)
                func one(_ native: Bool) {
                    if native {
                        let selected=NativeDraftTopK.select(input)
                        eval(selected.indices,selected.scores)
                        do { try selected.checkFinite() } catch { preconditionFailure("Finite benchmark input failed") }
                    } else {
                        let ids=argPartition(input,kth:vocabulary-16,axis:-1)[.ellipsis,(vocabulary-16)...]
                        eval(ids,takeAlong(input,ids,axis:-1))
                    }
                }
                for _ in 0..<8 { one(false);one(true) }
                var old: [Double]=[], new: [Double]=[]
                for native in [false,true,true,false] {
                    for _ in 0..<80 {
                        let start=DispatchTime.now().uptimeNanoseconds;one(native)
                        let elapsed=Double(DispatchTime.now().uptimeNanoseconds-start)/1000
                        if native { new.append(elapsed) } else { old.append(elapsed) }
                    }
                }
                func median(_ values:[Double])->Double { let x=values.sorted();return (x[x.count/2-1]+x[x.count/2])/2 }
                c.measure("draft_top16_depth_\(depth)_fullsort_us",median(old))
                c.measure("draft_top16_depth_\(depth)_sharded_us",median(new))
            }
        }
        for value: Float in [.nan,.infinity,-.infinity] {
            var values=[Float](repeating:0,count:513*7);values[513*5+511]=value
            let selected=NativeDraftTopK.select(MLXArray(values,[1,7,513]))
            do { try selected.checkFinite();c.expect("draft non-finite refusal",false) }
            catch { c.expect("draft non-finite refusal",true) }
        }
    }
}
