from pathlib import Path
import json,subprocess,sys
P=Path(__file__).resolve().parent;R=P.parents[1]
assert json.loads((P/'v51b-controller-result.json').read_text())['exit_code']==1
ledger=json.loads((P/'v51b-core-ledger.json').read_text());assert all(x['exit_code']==0 for x in ledger[:-1]) and ledger[-1]['label']=='v51b-quality'
assert "KeyError: 'native_ssd_read_batches'" in (P/'v51b-quality-driver.log').read_text()
events=[]
def run(label,cmd):
 print('START',label,flush=True)
 with(P/(label+'-driver.log')).open('x')as f:r=subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT)
 events.append(dict(label=label,command=cmd,exit_code=r.returncode));(P/'v51c-qualification-ledger.json').write_text(json.dumps(events,indent=2)+'\n')
 print('END',label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
run('v51c-quality-review',[sys.executable,str(P/'v51c_quality_review.py')])
run('v51c-topk-timing',[sys.executable,str(P/'guarded_run.py'),'--label','v51c-topk-timing','--budget','2','--timeout','300','--env','SLOTSTREAM_CHECK_DRAFT_TOPK_TIMING=1','--',str(P/'v51/slotstream-checks'),'--tier','t1','--filter','dflash-selector','--json'])
for model in ['fast','smart-q2']:
 label='v51c-default-'+model+'15-splash'
 run(label,[sys.executable,str(P/'native_splash_compare_v51.py'),'--cases',str(P/'short-warm-384-cases.json'),'--label',label,'--native',str(P/'v51/slotstream'),'--model',model,'--budget','15'])
 run(label+'-summary',[sys.executable,str(P/'comparison_summary.py'),label])
