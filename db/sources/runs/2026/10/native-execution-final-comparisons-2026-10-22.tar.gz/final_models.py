import json,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];results=[]
def run(label,command):
 print('START',label,flush=True)
 with (P/(label+'-driver.log')).open('x')as log:rc=subprocess.run(command,cwd=R,stdout=log,stderr=subprocess.STDOUT).returncode
 results.append(dict(label=label,command=command,exit_code=rc));(P/'final-model-ledger.json').write_text(json.dumps(results,indent=2));print('END',label,rc,flush=True)
for model,script in [('fast','warm_compare.py'),('q2','q2_warm_compare.py')]:
 label=model+'-v7-matched16'
 run(label,[sys.executable,str(P/script),'--label',label,'--native',str(P/'v7/slotstream'),'--budget','16','--cases',str(P/'short-warm-cases.json')])
run('final-quality',[sys.executable,str(P/'quality_final.py')])
run('final-bounded-acceptance',[sys.executable,'Tools/fast_smart_acceptance.py','--binary',str(P/'v7/slotstream'),'--out',str(P/'final-bounded-acceptance')])
for model in ('fast','q2'):run('app-real-'+model,[sys.executable,str(P/('app-bench-'+model+'.py'))])
raise SystemExit(int(any(x['exit_code']for x in results)))
