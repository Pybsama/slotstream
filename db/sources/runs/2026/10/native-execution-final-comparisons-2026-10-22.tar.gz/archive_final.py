import hashlib,io,json,pathlib,tarfile
P=pathlib.Path(__file__).resolve().parent;R=P.parents[1]
assert len(json.loads((P/'final-matched15-ledger.json').read_text()))==2
assert len(json.loads((P/'final-model-ledger.json').read_text()))==6
support=P/'captured-support';support.mkdir(exist_ok=True)
for source in [R/'.build/fast-parity-20261022/quality-and-functional-cases.json',R/'.build/native-q2-20261021/grade_v2.py',R/'.build/native-q2-20261021/thermal.py',R/'Tools/prefill_bench.py',R/'Tools/fast_smart_acceptance.py']:
 (support/source.name).write_bytes(source.read_bytes())

def archive(name,paths,scope):
 destination=R/'db/sources/runs/2026/10'/name
 assert not destination.exists()
 files=sorted(set(x for x in paths if x.is_file() and 'prefix-cache' not in x.parts))
 assert all(x.stat().st_size < 20_000_000 for x in files), 'Unexpected large evidence file'
 manifest=dict(scope=scope,files={str(f.relative_to(P)):dict(bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest())for f in files})
 with tarfile.open(destination,'w:gz')as tar:
  for f in files:tar.add(f,arcname=str(f.relative_to(P)),recursive=False)
  raw=(json.dumps(manifest,indent=2)+'\n').encode();info=tarfile.TarInfo('archive-manifest.json');info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
 with tarfile.open(destination)as tar:
  for name,entry in manifest['files'].items():
   raw=tar.extractfile(name).read();assert len(raw)==entry['bytes']and hashlib.sha256(raw).hexdigest()==entry['sha256']
 return dict(path=str(destination.relative_to(R)),bytes=destination.stat().st_size,sha256=hashlib.sha256(destination.read_bytes()).hexdigest(),files=len(files))

common=list(support.iterdir())+[P/x for x in ['guarded_run.py','final_models.py','quality_final.py','app-bench-fast.py','app-bench-q2.py','archive_final.py','archive-exclusion.json']]
common += [x for x in (P/'v7').iterdir()if x.name not in ('slotstream','slotstream-checks','mlx.metallib')]
validation=[x for x in P.iterdir()if x.is_file()and x.name.startswith(('final-quality','final-static','final-catalogue','final-check','final-model','final-metal','app-','isolated-gpu','probe-gpu','register-gpu','metal-validation','probe_gpu','register_gpu'))]
validation += list((P/'final-bounded-acceptance').rglob('*'))+list((P/'app-real-fast').rglob('*'))+list((P/'app-real-q2').rglob('*'))+[P/'final-bounded-acceptance-driver.log']
comparisons=[x for x in P.iterdir()if x.is_file()and x.name.startswith(('fast-v7-matched','q2-v7-matched','final-matched'))]
comparisons += [P/x for x in ['warm_compare.py','q2_warm_compare.py','upstream_bench.py','q2_upstream_bench.py','short-warm-cases.json','prepared-path.txt','final_compare15.py','analyze_final.py','retiming-protocol.json','thermal-protocol-addendum.json','q2-cache-mismatch-exclusion.json','trace-phase-summary.json']]
receipts=[archive('native-execution-final-validation-2026-10-22.tar.gz',validation+common,'Final v7 independent checks, quality, bounded real app jobs and signed development bundle identity; full GPU instrumentation failure retained.'),archive('native-execution-final-comparisons-2026-10-22.tar.gz',comparisons+common,'All final matched comparison attempts, actual-cache assertions, frozen protocol and complete eligibility verdicts. Ineligible aggregates must not support precise speed claims.')]
(P/'final-archive-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(json.dumps(receipts,indent=2))
