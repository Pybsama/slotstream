import json,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];results=[]
assert len(json.loads((P/'final-model-ledger.json').read_text()))==6
for model,script in [('fast','warm_compare.py'),('q2','q2_warm_compare.py')]:
 label=model+'-v7-matched15'
 command=[sys.executable,str(P/script),'--label',label,'--native',str(P/'v7/slotstream'),'--budget','15','--cases',str(P/'short-warm-cases.json')]
 print('START',label,flush=True)
 with (P/(label+'-driver.log')).open('x')as log:rc=subprocess.run(command,cwd=R,stdout=log,stderr=subprocess.STDOUT).returncode
 results.append(dict(label=label,command=command,exit_code=rc));(P/'final-matched15-ledger.json').write_text(json.dumps(results,indent=2));print('END',label,rc,flush=True)
raise SystemExit(int(any(x['exit_code']for x in results)))
