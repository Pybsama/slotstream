import json,pathlib,statistics
P=pathlib.Path(__file__).resolve().parent
all_results={}
for model in ('fast','q2'):
 label=model+'-v7-matched15';events=json.loads((P/(label+'-ledger.json')).read_text());assert len(events)==4
 summary=dict(label=label,eligible=all(x['eligible']for x in events),slots=json.loads((P/(label+'-cache.json')).read_text())['slots'],observed_medians={},arms=[{k:e[k]for k in ['arm','label','eligible','thermal_nominal','runs']}for e in events])
 for arm in ('A','B'):
  summary['observed_medians'][arm]={}
  for case in ('timed-2','timed-3'):
   rows=[r for e in events if e['arm']==arm for r in e['runs']if r['id']==case]
   summary['observed_medians'][arm][case]={k:statistics.median(x[k]for x in rows)for k in ('tps','request_seconds','prefill_seconds','peak_gb')}
 a=json.loads((P/(label+'-0-A.json')).read_text());b=json.loads((P/(label+'-1-B.json')).read_text());summary['first_pair_equal_text']={x['id']:x['text']==y['text']for x,y in zip(a['runs'],b['runs'])}
 if model=='q2':
  summary['first_pair_diagnostics']=[]
  for x,y in zip(a['runs'],b['runs']):
   if not x['id'].startswith('timed'):continue
   s=x['stats'];before=y['status_before']['streamed_experts']['decode'];after=y['status_after']['streamed_experts']['decode']
   summary['first_pair_diagnostics'].append(dict(id=x['id'],native={k:s[k]for k in ('decodeSeconds','decodeIOSeconds','decodeReadBytes','draftSeconds','verifySeconds','verifyPasses','acceptedDrafts','draftedTokens')},splash=dict(timings=y['timings'],speculation=y['metrics']['speculation'],read_bytes=after['read_bytes']-before['read_bytes'],read_ahead=after['read_ahead']-before['read_ahead'],host_ms={k:after['host_steps'][k]['total']-before['host_steps'][k]['total']for k in ('pickup_ms','work_ms','resume_ms')})))
 (P/(label+'-summary.json')).write_text(json.dumps(summary,indent=2)+'\n');all_results[model]=summary
(P/'final-matched-summary.json').write_text(json.dumps(all_results,indent=2)+'\n')
for model,s in all_results.items():print(model,'eligible',s['eligible'],'slots',s['slots'],'medians',s['observed_medians'])
