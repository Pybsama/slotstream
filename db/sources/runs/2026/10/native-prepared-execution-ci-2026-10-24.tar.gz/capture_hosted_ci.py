import hashlib
import io
import json
import subprocess
import tarfile
from pathlib import Path

P = Path(__file__).resolve().parent
R = P.parents[1]
engine_commit = '42cce1ef6d74feae3060e100b4349699a49cea72'
app_commit = '5b4e18fe9c19e4f16488404bbba7112571f937c1'
runs = [(40140168406, engine_commit), (40140168402, engine_commit),
        (40140168404, engine_commit), (40139680688, app_commit)]
observed = []
for run, commit in runs:
    raw = subprocess.check_output(['gh', 'run', 'view', str(run), '--json',
        'databaseId,name,headSha,status,conclusion,url,jobs'], cwd=R)
    row = json.loads(raw)
    (P/f'hosted-ci-{run}.json').write_bytes(raw)
    assert row['headSha'] == commit and row['status'] == 'completed' and row['conclusion'] == 'success', row
    assert row['jobs'] and all(j['status'] == 'completed' and j['conclusion'] == 'success' for j in row['jobs'])
    observed.append(row)

source = json.loads((P/'v68/build-identity.json').read_text())['source']
archive = subprocess.check_output(['git', 'archive', engine_commit, '--', *source], cwd=R)
with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
    committed = {m.name: hashlib.sha256(tar.extractfile(m).read()).hexdigest()
                 for m in tar.getmembers() if m.isfile()}
assert committed == source
assert source == {name: hashlib.sha256((R/name).read_bytes()).hexdigest() for name in source}
app = json.loads((P/'app-v68-final-identity.json').read_text())['files']
assert all(hashlib.sha256((R/name).read_bytes()).hexdigest() == digest for name, digest in app.items())
changes = subprocess.check_output(['git', 'diff', '--name-only', app_commit, engine_commit], cwd=R, text=True).splitlines()
assert not (set(changes) & set(app))
summary = dict(engine_commit=engine_commit, app_commit=app_commit,
               runtime_source_matches_frozen_v68=True, runtime_inputs=len(source),
               app_inputs_unchanged=len(app), changes_between_app_and_repair=changes,
               complete_successful_runs=[dict(name=r['name'], id=r['databaseId'], url=r['url'],
                                             jobs=[j['name'] for j in r['jobs']]) for r in observed],
               scope='Complete hosted checks on the repair commit and unchanged-source app commit. The initial context failure and superseded engine cancellation remain preserved. No release, real-model quality pass, or broad Q2 speed parity is inferred from CI.')
(P/'hosted-ci-final-summary.json').write_text(json.dumps(summary, indent=2)+'\n')
names = ['capture_hosted_ci.py', 'hosted-ci-final-summary.json', 'superseded-ci-cancellation.json',
         'implementation-ci-history.json', 'repair-ci-history.json',
         'post-context-repair-app-source-identity.json', 'context-repair-repository-checks.json',
         'closeout-repository-checks.json',
         'cooled-confirmation-publication-brain-gates.log']
names += [f'hosted-ci-{run}.json' for run, _ in runs]
manifest = {name: dict(bytes=(P/name).stat().st_size,
                      sha256=hashlib.sha256((P/name).read_bytes()).hexdigest()) for name in names}
dest = R/'db/sources/runs/2026/10/native-prepared-execution-ci-2026-10-24.tar.gz'
assert not dest.exists()
with tarfile.open(dest, 'w:gz') as tar:
    for name in names:
        tar.add(P/name, arcname=name, recursive=False)
    raw = (json.dumps(manifest, indent=2)+'\n').encode()
    info = tarfile.TarInfo('manifest.json'); info.size = len(raw)
    tar.addfile(info, io.BytesIO(raw))
with tarfile.open(dest) as tar:
    for name, entry in manifest.items():
        assert hashlib.sha256(tar.extractfile(name).read()).hexdigest() == entry['sha256']
receipt = dict(path=str(dest.relative_to(R)), bytes=dest.stat().st_size,
               sha256=hashlib.sha256(dest.read_bytes()).hexdigest(), files=len(names), readback_verified=True)
(P/'hosted-ci-archive-receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps(dict(receipt=receipt, summary=summary)))
