import argparse,json,subprocess,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight,vm_snapshot,host_conditions,terminate_child_tree
sys.path.insert(0,str(R/'.build/native-q2-20261021'));from thermal import state,wait_nominal
ap=argparse.ArgumentParser();ap.add_argument('--label',required=True);ap.add_argument('--native',required=True);ap.add_argument('--model',required=True,choices=['fast','smart-q2']);ap.add_argument('--order',default='ABBA');ap.add_argument('--budget',type=float,default=10);ap.add_argument('--cases',default=str(P/'short-warm-cases.json'));ap.add_argument('--plain',action='store_true');a=ap.parse_args()
ledger=P/(a.label+'-ledger.json');assert not ledger.exists();events=[];recipe=None
for index,arm in enumerate(a.order):
 label=a.label+'-'+str(index)+'-'+arm;out=P/(label+'.json');assert not out.exists()
 if not a.plain:wait_nominal(P/(label+'-cooldown.json'))
 before=dict(vm=preflight(a.budget+3),thermal=state(),host=host_conditions())
 if not a.plain:assert before['thermal']==0
 command=[sys.executable,str(P/'guarded_run_io.py'),'--label',label+'-guard','--budget',str(a.budget),'--env','SLOTSTREAM_NATIVE_DEFERRED_ROUTES=1',*(['--env','MLX_MAX_MB_PER_BUFFER=65536','--env','MLX_MAX_OPS_PER_BUFFER=256'] if arm=='B' else []),'--',str(Path(a.native).resolve()),'smart-dflash-check','--native-read-ahead','on' if a.model=='smart-q2' else 'off','--method','q2' if a.model=='smart-q2' else 'fast','--model',a.model,'--memory-gb',str(a.budget),'--max-context','8192','--cases',str(Path(a.cases).resolve()),'--output',str(out)]
 if a.plain:command+=['--disable-draft']
 print('START',label,flush=True)
 with (P/(label+'-launcher.log')).open('x') as log:
  child=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:rc=child.wait(timeout=1800)
  finally:
   if child.poll() is None:terminate_child_tree(child)
 after=dict(vm=vm_snapshot(),thermal=state());event=dict(label=label,arm=arm,command=command,before=before,after=after,exit_code=rc,runs=[])
 if out.exists():
  d=json.loads(out.read_text()); observed=dict(slots=d['plan']['pool_slots'],prompts=[x['prompt_ids']for x in d['runs']])
  if recipe is None:recipe=observed
  elif d.get("complete"):assert recipe==observed
  for row in d['runs']:
   s=row['stats'];scheduled=row['native_expert_scheduled_passes'];assert s['nativeExecution'].get('deferredExpertPasses',0)>0 and scheduled>0 and row['native_projection_schedule_failures']==0 and s['nativeExecution']['projectionFailures']==0
   event['runs'].append(dict(id=row['id'],tokens=len(row['tokens']),tps=(s['decodeTokens']-1)/s['decodeSeconds'],request_seconds=row['elapsed_seconds'],prefill_seconds=s['prefillSeconds'],reused=s['reusedPrefixTokens'],paging=bool(row['swapins_delta']or row['swapouts_delta']),peak_gb=s['peakMemoryGB'],scheduled=scheduled))
  event['complete']=d.get('complete',False);event['thermal_nominal']=before['thermal']==after['thermal']==0
  event['process_paging']=any(after['vm'][k]!=before['vm'][k] for k in ['swapins','swapouts'])
  event['eligible']=not event['process_paging'] and all(not r['paging'] for r in event['runs']) and rc==0 and event['complete'] and len([r for r in event['runs']if r['id'].startswith('timed')])==2 and event['thermal_nominal'] and all(not r['paging'] and r['reused']==0 and r['tokens']==384 and r['peak_gb']<=a.budget for r in event['runs']if r['id'].startswith('timed'))
 events.append(event);ledger.write_text(json.dumps(events,indent=2));print('END',label,'eligible',event.get('eligible'),'rates',[(r['id'],round(r['tps'],2),r['paging'])for r in event['runs']],flush=True)
 if rc:raise SystemExit(rc)
