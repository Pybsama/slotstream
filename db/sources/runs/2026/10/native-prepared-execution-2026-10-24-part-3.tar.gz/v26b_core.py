import json,subprocess,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];B=P/'v26b/slotstream';rows=[]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
preflight(12)
def run(label,cmd):
 print('START',label,flush=True)
 start=time.monotonic()
 with(P/(label+'-driver.log')).open('x')as log:r=subprocess.run(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT)
 rows.append(dict(label=label,command=cmd,exit_code=r.returncode,seconds=time.monotonic()-start));(P/'v26b-core-ledger.json').write_text(json.dumps(rows,indent=2)+'\n')
 print('END',label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
run('v26b-build',['make','build','SLOTSTREAM_BUILD_JOBS=4'])
run('v26b-freeze',[sys.executable,str(P/'freeze.py'),'v26b'])
for model in ['smart-q2','fast']:
 label='v26b-pool-'+model
 run(label,[sys.executable,str(P/'guarded_run.py'),'--label',label,'--budget','3','--timeout','300','--',str(B),'q2-experts-check','--pool-model',model])
run('v26b-formats',[sys.executable,str(P/'guarded_run.py'),'--label','v26b-formats','--budget','3','--timeout','240','--',str(B),'q2-format-check','--fixtures','bench/q2/formats.json','--policy-fixtures','bench/q2/verify-budget.json','--policy-fixtures','bench/q2/verify-budget-complete.json','--mix-fixtures','bench/q2/mix-quantization.json'])
run('v26b-catalogue',[sys.executable,str(P/'guarded_run.py'),'--label','v26b-catalogue','--budget','4','--timeout','300','--',str(P/'v26b/slotstream-checks'),'--tier','t0','--tier','t1'])
run('v26b-plain',[sys.executable,str(P/'v26b_plain.py')])
run('v26b-quality',[sys.executable,str(P/'v26b_native_quality.py')])
