import json,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];events=[]
def run(label,cmd):
 print('START',label,flush=True)
 with(P/(label+'-driver.log')).open('x')as out:r=subprocess.run(cmd,cwd=R,stdout=out,stderr=subprocess.STDOUT)
 events.append(dict(label=label,command=cmd,exit_code=r.returncode));(P/'v30-submission-ledger.json').write_text(json.dumps(events,indent=2)+'\n')
 print('END',label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
for model in ['smart-q2','fast']:
 label='v30-submit-pool-'+model
 run(label,[sys.executable,str(P/'guarded_run.py'),'--label',label,'--budget','3','--timeout','300',
  '--env','SLOTSTREAM_NATIVE_DEFERRED_ROUTES=1','--env','MLX_MAX_MB_PER_BUFFER=65536','--env','MLX_MAX_OPS_PER_BUFFER=256',
  '--',str(P/'v29/slotstream'),'q2-experts-check','--pool-model',model])
run('v30-submit-plain',[sys.executable,str(P/'v30_submission_plain.py')])
for model in ['smart-q2','fast']:
 label='v30-submit-'+model+'15'
 run(label,[sys.executable,str(P/'v30_submission_ablation.py'),'--label',label,'--native',str(P/'v29/slotstream'),
  '--model',model,'--budget','15','--cases',str(P/'short-warm-384-cases.json')])
