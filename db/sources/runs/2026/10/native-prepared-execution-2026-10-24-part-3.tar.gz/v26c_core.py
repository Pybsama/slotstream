import json,subprocess,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];B=P/'v26c/slotstream';rows=[]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
preflight(12)
def run(label,cmd):
 print('START',label,flush=True)
 start=time.monotonic()
 with(P/(label+'-driver.log')).open('x')as log:r=subprocess.run(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT)
 rows.append(dict(label=label,command=cmd,exit_code=r.returncode,seconds=time.monotonic()-start));(P/'v26c-core-ledger.json').write_text(json.dumps(rows,indent=2)+'\n')
 print('END',label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
run('v26c-build',['make','build','SLOTSTREAM_BUILD_JOBS=4'])
run('v26c-freeze',[sys.executable,str(P/'freeze.py'),'v26c'])
for model in ['smart-q2','fast']:
 label='v26c-pool-'+model
 run(label,[sys.executable,str(P/'guarded_run.py'),'--label',label,'--budget','3','--timeout','300','--',str(B),'q2-experts-check','--pool-model',model])
run('v26c-formats',[sys.executable,str(P/'guarded_run.py'),'--label','v26c-formats','--budget','3','--timeout','240','--',str(B),'q2-format-check','--fixtures','bench/q2/formats.json','--policy-fixtures','bench/q2/verify-budget.json','--policy-fixtures','bench/q2/verify-budget-complete.json','--mix-fixtures','bench/q2/mix-quantization.json'])
run('v26c-catalogue',[sys.executable,str(P/'guarded_run.py'),'--label','v26c-catalogue','--budget','4','--timeout','300','--',str(P/'v26c/slotstream-checks'),'--tier','t0','--tier','t1'])
run('v26c-plain',[sys.executable,str(P/'v26c_plain.py')])
run('v26c-quality',[sys.executable,str(P/'v26c_native_quality.py')])
