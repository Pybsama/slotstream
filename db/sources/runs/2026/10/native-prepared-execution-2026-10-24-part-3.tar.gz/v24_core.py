import json,subprocess,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];B=P/'v24/slotstream';rows=[]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
preflight(12)
def run(label,cmd):
 print('START',label,flush=True)
 start=time.monotonic()
 with(P/(label+'-driver.log')).open('x')as log:r=subprocess.run(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT)
 rows.append(dict(label=label,command=cmd,exit_code=r.returncode,seconds=time.monotonic()-start));(P/'v24-core-ledger.json').write_text(json.dumps(rows,indent=2)+'\n')
 print('END',label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
run('v24-metal-target-probe',['swift',str(P/'metal_target_probe.swift')])
run('v24-build',['make','build','SLOTSTREAM_BUILD_JOBS=4'])
run('v24-freeze',[sys.executable,str(P/'freeze.py'),'v24'])
for model in ['smart-q2','fast']:
 label='v24-pool-'+model
 run(label,[sys.executable,str(P/'guarded_run.py'),'--label',label,'--budget','3','--timeout','300','--',str(B),'q2-experts-check','--pool-model',model])
run('v24-formats',[sys.executable,str(P/'guarded_run.py'),'--label','v24-formats','--budget','3','--timeout','240','--',str(B),'q2-format-check','--fixtures','bench/q2/formats.json','--policy-fixtures','bench/q2/verify-budget.json','--policy-fixtures','bench/q2/verify-budget-complete.json','--mix-fixtures','bench/q2/mix-quantization.json'])
run('v24-catalogue',[sys.executable,str(P/'guarded_run.py'),'--label','v24-catalogue','--budget','4','--timeout','300','--',str(P/'v24/slotstream-checks'),'--tier','t0','--tier','t1'])
run('v24-plain',[sys.executable,str(P/'v24_plain.py')])
run('v24-quality',[sys.executable,str(P/'v24_native_quality.py')])
