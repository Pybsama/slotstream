#include "NativeSchedule.h"
#include "mlx/primitives.h"
#include "mlx/backend/metal/device.h"
#include "mlx/backend/metal/event.h"
#include <algorithm>
#include <optional>
#include <mutex>
#include <limits>
#include <condition_variable>
#include <deque>
#include <functional>
#include <thread>
#include <pthread.h>

// This extension links the same MLX implementation used by mlx-swift. Header
// and mlx-c context layouts are pinned to Package.swift, not inferred at run
// time. No second allocator, command queue or inference runtime is created.
using namespace mlx::core;
namespace {
thread_local std::string last_error;
struct Plan {
  NS::SharedPtr<MTL::ComputePipelineState> gather, gate_up, down, scatter;
  NS::SharedPtr<MTL::ComputePipelineState> repack_gate, repack_down;
  int hidden, intermediate;
  bool affine;
  Plan(void *g, void *u, void *d, void *s, int h, int m, bool a, void *rg, void *rd)
      : gather(NS::RetainPtr(static_cast<MTL::ComputePipelineState *>(g))),
        gate_up(NS::RetainPtr(static_cast<MTL::ComputePipelineState *>(u))),
        down(NS::RetainPtr(static_cast<MTL::ComputePipelineState *>(d))),
        scatter(NS::RetainPtr(static_cast<MTL::ComputePipelineState *>(s))),
        hidden(h), intermediate(m), affine(a) {
    if (rg) repack_gate = NS::RetainPtr(static_cast<MTL::ComputePipelineState *>(rg));
    if (rd) repack_down = NS::RetainPtr(static_cast<MTL::ComputePipelineState *>(rd));
  }
};
// Reuse host-ready events only after both the host ticket and the submitted
// GPU command release their lease. Values only increase; an older publication
// can never accidentally release a newer command. The cache retains at most
// 64 events, independent of the number of layers, requests or model weights.
struct ReadyEvent {
  Event event;
  uint64_t next = 0;
  explicit ReadyEvent(Stream stream) : event(stream) {}
};
struct ReadyEvents {
  std::mutex mutex;
  std::vector<std::shared_ptr<ReadyEvent>> idle;
  uint64_t created = 0, reused = 0;
  std::shared_ptr<ReadyEvent> take(Stream stream) {
    std::lock_guard guard(mutex);
    for (auto& candidate : idle) {
      if (candidate.use_count() == 1 && candidate->event.stream() == stream &&
          !candidate->event.load_error() && candidate->next < std::numeric_limits<uint64_t>::max()) {
        ++candidate->next; ++reused;
        return candidate;
      }
    }
    auto candidate = std::make_shared<ReadyEvent>(stream);
    candidate->next = 1; ++created;
    if (idle.size() < 64) idle.push_back(candidate);
    return candidate;
  }
};
ReadyEvents& ready_events() { static ReadyEvents pool; return pool; }
// Native host callbacks are serialized. Only the model owner submits work;
// callbacks never evaluate MLX or allocate scheduler-owned arrays.
struct DeferredScope {
  std::vector<array> raw;
  std::shared_ptr<ReadyEvent> last_consumed;
  std::mutex mutex;
  std::condition_variable completed;
  size_t outstanding = 0;
  std::string error;
  void fail(std::string message) {
    std::lock_guard lock(mutex);
    if (error.empty()) error = std::move(message);
  }
  bool failed() { std::lock_guard lock(mutex); return !error.empty(); }
  void wait() {
    std::unique_lock lock(mutex);
    completed.wait(lock, [&] { return outstanding == 0; });
  }
};
class DeferredWorker {
  std::mutex mutex;
  std::condition_variable changed;
  std::deque<std::function<void()>> tasks;
  bool stopping = false;
  std::thread thread;
 public:
  DeferredWorker() : thread([this] {
    pthread_set_qos_class_self_np(QOS_CLASS_USER_INITIATED, 0);
    for (;;) {
      std::function<void()> task;
      {
        std::unique_lock lock(mutex);
        changed.wait(lock, [&] { return stopping || !tasks.empty(); });
        if (tasks.empty()) return;
        task = std::move(tasks.front()); tasks.pop_front();
      }
      auto scoped_pool = metal::new_scoped_memory_pool();
      task();
    }
  }) {}
  ~DeferredWorker() {
    { std::lock_guard lock(mutex); stopping = true; }
    changed.notify_one(); thread.join();
  }
  void add(std::function<void()> task) {
    { std::lock_guard lock(mutex);
      if (tasks.size() >= 64 || stopping) throw std::runtime_error("Deferred route queue exceeds its bounded forward");
      tasks.push_back(std::move(task)); }
    changed.notify_one();
  }
};
DeferredWorker& deferred_worker() { static DeferredWorker value; return value; }

struct Job {
  std::shared_ptr<ReadyEvent> lease, consumed;
  array ready;
  std::vector<array> raw;
  std::optional<array> mask;
  std::optional<array> sources;
  int forecast_records = 0;
  struct Release {
    void *context;
    void (*release)(void *);
  };
  std::vector<Release> forecast_owners;
  int staged = 0;
  std::atomic<bool> published{false};
  explicit Job(Stream stream, bool awaiting_reads) : ready({uint32_t(0), uint32_t(0)}, uint32) {
    if (awaiting_reads) lease = ready_events().take(stream);
  }
  void prepare_staging(int count, int piece_bytes) {
    staged = count; ready.data<uint32_t>()[1] = count;
    if (!count) return;
    // Host-owned materialized inputs; the event gates every GPU read.
    for (int i = 0; i < 3; ++i)
      raw.emplace_back(allocator::malloc(size_t(count) * piece_bytes), Shape{count, piece_bytes}, uint8);
    mask.emplace(allocator::malloc(size_t(count) * sizeof(int32_t)), Shape{count}, int32);
    std::fill_n(mask->data<int32_t>(), count, 0);
    sources.emplace(allocator::malloc(size_t(count) * sizeof(int32_t)), Shape{count}, int32);
    std::fill_n(sources->data<int32_t>(), count, 0);
  }
  void publish(bool success) {
    if (published.load(std::memory_order_acquire)) return;
    ready.data<uint32_t>()[0] = success ? 1 : 2;
    if (lease) lease->event.cast<metal::EventImpl>().signal(lease->next);
    published.store(true, std::memory_order_release);
  }
  ~Job() {
    publish(false);
    for (auto& owner : forecast_owners) owner.release(owner.context);
  }
};
struct DeferredRoute {
  std::shared_ptr<DeferredScope> scope;
  std::shared_ptr<Plan> plan;
  std::shared_ptr<Job> job;
  std::shared_ptr<ReadyEvent> route_ready, previous_consumed;
  std::vector<array> compute_inputs;
  array routes{int32_t(0)}, forecast_ids{int32_t(0)}, forecast_weights{float(0)};
  int top_k, route_count, capacity;
  void *context = nullptr;
  bool (*load)(void *, void *, void *, const int32_t *, int, const int32_t *, const float *, int) = nullptr;
  void (*release)(void *) = nullptr;
  std::atomic<bool> submitted{false};
  ~DeferredRoute() { if (release) release(context); }
};
class HostRoute final : public Primitive {
  std::shared_ptr<DeferredRoute> route_;
 public:
  HostRoute(Stream stream, std::shared_ptr<DeferredRoute> route)
      : Primitive(stream), route_(std::move(route)) {}
  const char *name() const override { return "SlotstreamDeferredRoute"; }
  void eval_cpu(const std::vector<array>&, std::vector<array>&) override {
    throw std::runtime_error("Deferred routes require the current GPU stream");
  }
  void eval_gpu(const std::vector<array>& in, std::vector<array>& out) override {
    auto route = route_;
    if (route->submitted.exchange(true)) throw std::logic_error("Deferred route evaluated twice");
    out[0].copy_shared_buffer(in[0]);
    auto& encoder = metal::get_command_encoder(stream());
    // This point depends on routes and every previous layer's expert reader.
    // MLX alone commits this command buffer: its evaluator still registers
    // completion ownership after eval_gpu returns. The worker uses blocking
    // event waits and can be cancelled if the enclosing graph is abandoned.
    encoder.signal_event(route->route_ready->event, route->route_ready->next);
    encoder.get_command_buffer()->addCompletedHandler([lease = route->route_ready](MTL::CommandBuffer*) { (void)lease; });
    { std::lock_guard lock(route->scope->mutex); ++route->scope->outstanding; }
    try {
      deferred_worker().add([route] {
        bool success = false;
        try {
          auto& event = route->route_ready->event;
          event.check_error();
          auto* metal_event = event.cast<metal::EventImpl>().mtl_event();
          while (!metal_event->waitUntilSignaledValue(route->route_ready->next, 10)) {
            if (route->scope->failed()) throw std::runtime_error("Deferred forward cancelled before routing completed");
            event.check_error();
          }
          event.check_error();
          if (route->previous_consumed) {
            auto& previous = *route->previous_consumed;
            previous.event.check_error();
            if (previous.event.cast<metal::EventImpl>().mtl_event()->signaledValue() < previous.next)
              throw std::runtime_error("Deferred routes require ordered layer dependencies before staging reuse");
          }
          if (!route->scope->failed()) {
            // Borrowed shared_ptr handle, valid only during this callback.
            auto job = route->job;
            const int forecast_count = route->forecast_ids.size();
            auto borrowed = route;
            success = route->load(route->context, &job, &borrowed, route->routes.data<int32_t>(), route->route_count,
                forecast_count ? route->forecast_ids.data<int32_t>() : nullptr,
                forecast_count ? route->forecast_weights.data<float>() : nullptr, forecast_count);
            if (!success) route->scope->fail("Deferred expert loading failed");
          }
        } catch (const std::exception& e) { route->scope->fail(e.what()); }
        catch (...) { route->scope->fail("Unknown deferred expert loading failure"); }
        route->job->publish(success);
        { std::lock_guard lock(route->scope->mutex); --route->scope->outstanding; }
        route->scope->completed.notify_all();
      });
    } catch (...) {
      route->scope->fail("Could not enqueue deferred expert loading");
      route->job->publish(false);
      { std::lock_guard lock(route->scope->mutex); --route->scope->outstanding; }
      route->scope->completed.notify_all();
      throw;
    }
  }
};

class ExpertSchedule final : public Primitive {
  std::shared_ptr<Plan> plan_;
  std::shared_ptr<Job> job_;
  int rows_, routes_, count_;
  bool grouped_output_;
 public:
  ExpertSchedule(Stream s, std::shared_ptr<Plan> plan, std::shared_ptr<Job> job,
                 int rows, int routes, int count, bool grouped_output)
      : Primitive(s), plan_(std::move(plan)), job_(std::move(job)),
        rows_(rows), routes_(routes), count_(count), grouped_output_(grouped_output) {}
  const char *name() const override { return "SlotstreamExpertSchedule"; }
  void eval_cpu(const std::vector<array>&, std::vector<array>&) override {
    throw std::runtime_error("Native expert schedule requires a GPU stream");
  }
  void eval_gpu(const std::vector<array>& in, std::vector<array>& out) override {
    auto scoped_pool = metal::new_scoped_memory_pool();
    auto& p = *plan_;
    // MLX owns scratch and output allocations and their complete GPU lifetime.
    // Its bounded allocator cache can reuse them without registering new
    // Metal views of multi-GB expert buffers or retaining a second buffer pool.
    array grouped({rows_, p.hidden}, bfloat16, nullptr, {});
    array activated({rows_, p.intermediate}, bfloat16, nullptr, {});
    array projected({rows_, p.hidden}, bfloat16, nullptr, {});
    for (auto *a : {&grouped, &activated, &out[0]})
      a->set_data(allocator::malloc(a->nbytes()));
    if (grouped_output_) projected = out[0];
    else projected.set_data(allocator::malloc(projected.nbytes()));
    auto& enc = metal::get_command_encoder(stream());
    // An all-hit call can stay lazy in the surrounding MLX graph. If the
    // host already published the bytes, no event wait or encoder split is
    // needed. The acquire observes the host writes before dispatch encoding.
    if (job_->lease) {
      if (!job_->published.load(std::memory_order_acquire))
        enc.wait_event(job_->lease->event, job_->lease->next);
      // A primitive may be released before Metal completes. Keep its event
      // lease until completion as well, without an extra buffer or CPU join.
      enc.get_command_buffer()->addCompletedHandler([lease = job_->lease](MTL::CommandBuffer*) { (void)lease; });
    } else if (!job_->published.load(std::memory_order_acquire)) {
      throw std::logic_error("All-hit expert schedule was not published");
    }
    // The full expert arena and staging allocations are stable ownership,
    // not the bytes this routed invocation scans. MLX's existing raw-buffer
    // adapter records cross-encoder read/write fences without charging their
    // whole capacity to its command-submission heuristic. Arrays remain input
    // owners of this primitive. Internal pool-write visibility is explicit.
    const auto storage = [&](const array& a, int index) {
      enc.set_buffer(static_cast<const MTL::Buffer*>(a.buffer().ptr()), index, a.offset());
    };
    const int order = count_ + 1, inverse = order + 1;
    const int slots = order + 2, live = order + 3, ready = order + 4;
    if (job_->staged) {
      const int raw = ready + 1, mask = raw + 3, destinations = mask + 1;
      const int forecast = destinations + 1, sources = forecast + 3;
      // Keep ticket leases beyond primitive/array release, through the last
      // GPU reader. Their arena positions cannot be reused before completion.
      enc.get_command_buffer()->addCompletedHandler([job = job_](MTL::CommandBuffer*) { (void)job; });
      for (int piece = 0; piece < 3; ++piece) {
        enc.set_compute_pipeline_state(piece == 2 ? p.repack_down.get() : p.repack_gate.get());
        storage(in[raw + piece], 0);
        // A copied array handle shares the pinned pool allocation.
        // Register its write without casting away the input vector constness.
        auto destination = in[1 + piece];
        storage(destination, 1);
        enc.register_output_array(destination);
        enc.set_input_array(in[destinations], 2);
        enc.set_input_array(in[mask], 3); enc.set_input_array(in[ready], 4);
        storage(in[forecast + piece], 5);
        enc.set_input_array(in[sources], 6);
        enc.dispatch_threads(MTL::Size(p.hidden * p.intermediate / 64, 4, 1), MTL::Size(256, 1, 1));
      }
      // All projections below read the repacked arena. Raw bindings do not
      // participate in MLX's per-dispatch input-set tracking, so order these
      // writes before every later read explicitly on the same encoder.
      enc.barrier();
    }
    auto reorder = [&](MTL::ComputePipelineState *kernel, const array& x,
                       const array& indices, array& y, uint32_t n) {
      enc.set_compute_pipeline_state(kernel);
      enc.set_input_array(x, 0); enc.set_input_array(indices, 1);
      enc.set_output_array(y, 2); enc.set_bytes(n, 3);
      enc.set_input_array(in[ready], 4);
      enc.dispatch_threadgroups(MTL::Size((n + 255) / 256, 1, 1), MTL::Size(256, 1, 1));
    };
    auto project = [&](MTL::ComputePipelineState *kernel, const array& x,
                       array& y, int piece, bool fused, int width) {
      int w = 1 + (p.affine ? piece * 3 : piece);
      int s = p.affine ? w + 1 : w, b = p.affine ? w + 2 : w;
      int u = fused ? (p.affine ? 4 : 2) : w;
      enc.set_compute_pipeline_state(kernel);
      enc.set_input_array(x, 0);
      const int inputs[] = {w, s, b, u, fused && p.affine ? 5 : s,
                            fused && p.affine ? 6 : b, slots, live};
      for (int i = 0; i < 8; ++i) {
        if (i < 6) storage(in[inputs[i]], i + 1);
        else enc.set_input_array(in[inputs[i]], i + 1);
      }
      enc.set_output_array(y, 9); enc.set_input_array(in[ready], 10);
      enc.dispatch_threadgroups(MTL::Size(width / (fused ? 32 : 64), rows_ / 8, 1), MTL::Size(64, 1, 1));
    };
    reorder(p.gather.get(), in[0], in[order], grouped, rows_ * p.hidden);
    project(p.gate_up.get(), grouped, activated, 0, true, p.intermediate);
    project(p.down.get(), activated, projected, 2, false, p.hidden);
    if (!grouped_output_)
      reorder(p.scatter.get(), projected, in[inverse], out[0], routes_ * p.hidden);
    if (grouped_output_) enc.add_temporaries({grouped, activated});
    else enc.add_temporaries({grouped, activated, projected});
    if (job_->consumed) {
      enc.signal_event(job_->consumed->event, job_->consumed->next);
      enc.get_command_buffer()->addCompletedHandler([lease = job_->consumed](MTL::CommandBuffer*) { (void)lease; });
    }
  }
};
}
extern "C" {
void ss_schedule_event_stats(uint64_t *created, uint64_t *reused, uint64_t *cached) {
  auto& pool = ready_events(); std::lock_guard guard(pool.mutex);
  if (created) *created = pool.created;
  if (reused) *reused = pool.reused;
  if (cached) *cached = pool.idle.size();
}
const char *ss_schedule_error() { return last_error.c_str(); }
void *ss_schedule_plan(void *g, void *u, void *d, void *s, int h, int m, bool a, void *rg, void *rd) {
  try {
    if (!g || !u || !d || !s || h < 64 || m < 64 || h % 64 || m % 64)
      throw std::invalid_argument("Invalid native schedule plan");
    if ((!rg) != (!rd)) throw std::invalid_argument("Incomplete native repack plan");
    return new std::shared_ptr<Plan>(std::make_shared<Plan>(g, u, d, s, h, m, a, rg, rd));
  } catch (const std::exception& e) { last_error = e.what(); return nullptr; }
}
void ss_schedule_plan_free(void *p) { delete static_cast<std::shared_ptr<Plan> *>(p); }
int ss_schedule_prepare(void *p, void *x, void *const *weights, int count,
                        const int32_t *order, int rows, const int32_t *inverse,
                        int routes, const int32_t *slots, const int32_t *live,
                        const int32_t *staged_slots, int staged_count, bool awaiting_reads, bool grouped_output,
                        void *prerequisite, void *const *forecast, void *stream_context, void **output, void **job) {
  try {
    if (!p || !x || !output || !job || !weights || !order || !inverse || !slots || !live || !stream_context)
      throw std::invalid_argument("Missing native schedule argument");
    auto plan = *static_cast<std::shared_ptr<Plan> *>(p);
    if (count != (plan->affine ? 9 : 3) || routes < 1 || routes > 256 ||
        rows < 8 || rows > routes * 8 || rows % 8)
      throw std::invalid_argument("Invalid native schedule geometry");
    if (staged_count < 0 || staged_count > 80 || (staged_count &&
        (!staged_slots || !awaiting_reads || plan->affine || !plan->repack_gate || !plan->repack_down)))
      throw std::invalid_argument("Invalid native staging geometry");
    if (uint64_t(staged_count) * 3 * plan->hidden * plan->intermediate / 64 * 18 > 110592000)
      throw std::invalid_argument("Native staging exceeds its charged byte ceiling");
    // The stream adapter follows pinned mlx-c/private/stream.h, preserving
    // both device and index rather than manufacturing a GPU stream index.
    auto stream = *static_cast<Stream *>(stream_context);
    if (stream.device != Device::gpu)
      throw std::invalid_argument("Native expert schedule requires the current GPU stream");
    auto work = std::make_shared<Job>(stream, awaiting_reads);
    std::vector<array> inputs{*static_cast<array *>(x)};
    if (inputs[0].dtype() != bfloat16 || !inputs[0].flags().row_contiguous)
      throw std::invalid_argument("Invalid native schedule activation");
    for (int i = 0; i < count; ++i) {
      if (!weights[i]) throw std::invalid_argument("Missing native expert weight");
      inputs.push_back(*static_cast<array *>(weights[i]));
    }
    for (int i = 0; i < staged_count; ++i) {
      if (staged_slots[i] < 0 || staged_slots[i] >= inputs[1].shape(0))
        throw std::invalid_argument("Staged expert destination is out of bounds");
      for (int j = 0; j < i; ++j) if (staged_slots[j] == staged_slots[i])
        throw std::invalid_argument("Duplicate staged expert destination");
      if (std::find(slots, slots + rows / 8, staged_slots[i]) == slots + rows / 8)
        throw std::invalid_argument("Staged destination is not a routed expert");
    }
    inputs.emplace_back(order, Shape{rows});
    inputs.emplace_back(inverse, Shape{routes});
    inputs.emplace_back(slots, Shape{rows / 8});
    inputs.emplace_back(live, Shape{rows / 8});
    inputs.push_back(work->ready);
    work->prepare_staging(staged_count, plan->hidden * plan->intermediate / 64 * 18);
    if (staged_count) {
      inputs.insert(inputs.end(), work->raw.begin(), work->raw.end());
      inputs.push_back(*work->mask); inputs.emplace_back(staged_slots, Shape{staged_count});
      for (int piece = 0; piece < 3; ++piece) {
        if (forecast) {
          if (!forecast[piece]) throw std::invalid_argument("Missing forecast arena piece");
          auto& a = *static_cast<array *>(forecast[piece]);
          if (a.dtype() != uint8 || a.ndim() != 2 || a.shape(0) != 64 ||
              a.shape(1) != plan->hidden * plan->intermediate / 64 * 18 || !a.flags().row_contiguous)
            throw std::invalid_argument("Invalid forecast arena geometry");
          inputs.push_back(a); work->forecast_records = a.shape(0);
        } else inputs.push_back(work->raw[piece]);
      }
      inputs.push_back(*work->sources);
    }
    // The shared expert is an ordering dependency, not another expert weight.
    // Its projection commands precede the host-ready wait in the same MLX
    // evaluation. This removes a separate async-evaluation submission while
    // retaining useful overlap with host demand reads.
    if (prerequisite) inputs.push_back(*static_cast<array *>(prerequisite));
    auto primitive = std::make_shared<ExpertSchedule>(stream, plan, work, rows, routes, count, grouped_output);
    auto value = std::make_unique<array>(Shape{grouped_output ? rows : routes, plan->hidden}, bfloat16, primitive, std::move(inputs));
    auto ticket = std::make_unique<std::shared_ptr<Job>>(work);
    *output = value.release(); *job = ticket.release(); return 0;
  } catch (const std::exception& e) { last_error = e.what(); return 1; }
}
void ss_schedule_publish(void *j, bool success) {
  (*static_cast<std::shared_ptr<Job> *>(j))->publish(success);
}
void *ss_schedule_forecast_array(int records, int piece_bytes, void **base) {
  try {
    if (!base || records != 64 || piece_bytes < 1 || uint64_t(records) * piece_bytes > 134217728 / 3)
      throw std::invalid_argument("Forecast arena exceeds its reservation");
    auto value = std::make_unique<array>(allocator::malloc(size_t(records) * piece_bytes),
                                       Shape{records, piece_bytes}, uint8);
    *base = value->data<uint8_t>();
    return value.release();
  } catch (const std::exception& e) { last_error = e.what(); return nullptr; }
}
int ss_schedule_stage_forecast(void *j, int index, int source, void *context, void (*release)(void *)) {
  try {
    if (!j || !context || !release) throw std::invalid_argument("Missing forecast lease");
    auto& work = **static_cast<std::shared_ptr<Job> *>(j);
    if (work.published.load(std::memory_order_acquire) || index < 0 || index >= work.staged ||
        source < 0 || source >= work.forecast_records || work.mask->data<int32_t>()[index] != 0)
      throw std::invalid_argument("Invalid forecast staging publication");
    work.forecast_owners.push_back({context, release});
    work.sources->data<int32_t>()[index] = source;
    work.mask->data<int32_t>()[index] = 2;
    return 0;
  } catch (const std::exception& e) { last_error = e.what(); return 1; }
}
void *ss_schedule_stage_base(void *j, int piece) {
  if (!j || piece < 0 || piece >= 3) return nullptr;
  auto& work = **static_cast<std::shared_ptr<Job> *>(j);
  if (!work.staged || work.published.load(std::memory_order_acquire)) return nullptr;
  return work.raw[piece].data<uint8_t>();
}
int ss_schedule_stage_mark(void *j, const int32_t *indices, int count) {
  try {
    if (!j || !indices || count < 1 || count > 80) throw std::invalid_argument("Invalid staging publication");
    auto& work = **static_cast<std::shared_ptr<Job> *>(j);
    if (!work.staged || work.published.load(std::memory_order_acquire)) throw std::invalid_argument("Staging already released");
    for (int i = 0; i < count; ++i)
      if (indices[i] < 0 || indices[i] >= work.staged) throw std::invalid_argument("Staged index is out of bounds");
    for (int i = 0; i < count; ++i) work.mask->data<int32_t>()[indices[i]] = 1;
    return 0;
  } catch (const std::exception& e) { last_error = e.what(); return 1; }
}
void ss_schedule_job_free(void *j) { delete static_cast<std::shared_ptr<Job> *>(j); }
void *ss_deferred_scope_new(void *p) {
  try {
    if (!p) throw std::invalid_argument("Missing deferred expert plan");
    auto plan = *static_cast<std::shared_ptr<Plan> *>(p);
    auto scope = std::make_shared<DeferredScope>();
    if (!plan->affine) {
      const int bytes = plan->hidden * plan->intermediate / 64 * 18;
      if (uint64_t(80) * 3 * bytes > 110592000) throw std::invalid_argument("Deferred staging exceeds its charged reservation");
      for (int i = 0; i < 3; ++i)
        scope->raw.emplace_back(allocator::malloc(size_t(80) * bytes), Shape{80, bytes}, uint8);
    }
    return new std::shared_ptr<DeferredScope>(std::move(scope));
  } catch (const std::exception& e) { last_error = e.what(); return nullptr; }
}
int ss_deferred_scope_finish(void *p, bool reset) {
  try {
    if (!p) throw std::invalid_argument("Missing deferred scope");
    auto scope = *static_cast<std::shared_ptr<DeferredScope> *>(p);
    scope->wait();
    std::lock_guard lock(scope->mutex);
    if (!scope->error.empty()) { last_error = scope->error; if (reset) scope->error.clear(); return 1; }
    return 0;
  } catch (const std::exception& e) { last_error = e.what(); return 1; }
}
void ss_deferred_scope_cancel(void *p) {
  if (p) (*static_cast<std::shared_ptr<DeferredScope> *>(p))->fail("Deferred forward cancelled");
}
void ss_deferred_scope_free(void *p) {
  if (!p) return;
  ss_deferred_scope_cancel(p);
  (*static_cast<std::shared_ptr<DeferredScope> *>(p))->wait();
  delete static_cast<std::shared_ptr<DeferredScope> *>(p);
}
int ss_deferred_prepare(void *p, void *s, void *x, void *routes, void *const *weights, int count,
    int top_k, void *forecast_ids, void *forecast_weights, void *const *forecast_arena,
    void *context, bool (*load)(void *, void *, void *, const int32_t *, int, const int32_t *, const float *, int),
    void (*release)(void *), void *stream_context, void **anchor, void **handle) {
  try {
    if (!p || !s || !x || !routes || !weights || !context || !load || !release || !stream_context || !anchor || !handle)
      throw std::invalid_argument("Missing deferred route argument");
    auto plan = *static_cast<std::shared_ptr<Plan> *>(p);
    auto scope = *static_cast<std::shared_ptr<DeferredScope> *>(s);
    auto stream = *static_cast<Stream *>(stream_context);
    auto input = *static_cast<array *>(x), ids = *static_cast<array *>(routes);
    const int route_count = ids.size(), rows = route_count * 8;
    if (stream.device != Device::gpu || count != (plan->affine ? 9 : 3) ||
        top_k != (plan->affine ? 8 : 10) || route_count < top_k || route_count > top_k * 8 || route_count % top_k ||
        input.dtype() != bfloat16 || !input.flags().row_contiguous || input.size() != route_count / top_k * plan->hidden ||
        ids.dtype() != int32 || !ids.flags().row_contiguous)
      throw std::invalid_argument("Invalid deferred route geometry");
    if (!weights[0]) throw std::invalid_argument("Missing deferred weight storage");
    auto deferred = std::make_shared<DeferredRoute>();
    deferred->scope = scope; deferred->plan = plan; deferred->top_k = top_k;
    deferred->route_count = route_count; deferred->capacity = static_cast<array *>(weights[0])->shape(0);
    deferred->route_ready = ready_events().take(stream);
    deferred->job = std::make_shared<Job>(stream, true);
    deferred->job->consumed = ready_events().take(stream);
    deferred->previous_consumed = scope->last_consumed;
    deferred->routes = ids;
    auto& job = *deferred->job;
    std::vector<array> dependency{input, ids};
    if ((forecast_ids == nullptr) != (forecast_weights == nullptr)) throw std::invalid_argument("Incomplete route forecast");
    if (forecast_ids) {
      deferred->forecast_ids = *static_cast<array *>(forecast_ids);
      deferred->forecast_weights = *static_cast<array *>(forecast_weights);
      if (deferred->forecast_ids.dtype() != int32 || deferred->forecast_weights.dtype() != float32 ||
          deferred->forecast_ids.size() != route_count || deferred->forecast_weights.size() != route_count ||
          !deferred->forecast_ids.flags().row_contiguous || !deferred->forecast_weights.flags().row_contiguous)
        throw std::invalid_argument("Invalid deferred forecast geometry");
      dependency.push_back(deferred->forecast_ids); dependency.push_back(deferred->forecast_weights);
    } else {
      deferred->forecast_ids = array(Shape{0}, int32, nullptr, {});
      deferred->forecast_weights = array(Shape{0}, float32, nullptr, {});
    }
    auto materialized = [](int n) {
      array a(allocator::malloc(size_t(n) * sizeof(int32_t)), Shape{n}, int32);
      std::fill_n(a.data<int32_t>(), n, 0); return a;
    };
    auto& in = deferred->compute_inputs;
    in.push_back(input);
    for (int i = 0; i < count; ++i) {
      if (!weights[i]) throw std::invalid_argument("Missing deferred weight binding");
      in.push_back(*static_cast<array *>(weights[i]));
    }
    in.push_back(materialized(rows)); in.push_back(materialized(route_count));
    in.push_back(materialized(route_count)); in.push_back(materialized(route_count));
    in.push_back(job.ready);
    if (!plan->affine) {
      job.staged = 80; job.raw = scope->raw; job.mask = materialized(80); job.sources = materialized(80);
      in.insert(in.end(), job.raw.begin(), job.raw.end());
      in.push_back(*job.mask); in.push_back(materialized(80));
      for (int i = 0; i < 3; ++i) {
        if (forecast_arena) {
          if (!forecast_arena[i]) throw std::invalid_argument("Missing deferred forecast storage");
          auto a = *static_cast<array *>(forecast_arena[i]);
          if (a.dtype() != uint8 || a.ndim() != 2 || a.shape(0) != 64 || a.shape(1) != scope->raw[i].shape(1) || !a.flags().row_contiguous)
            throw std::invalid_argument("Invalid deferred forecast storage");
          in.push_back(a); job.forecast_records = 64;
        } else in.push_back(job.raw[i]);
      }
      in.push_back(*job.sources);
    }
    auto primitive = std::make_shared<HostRoute>(stream, deferred);
    auto value = std::make_unique<array>(input.shape(), input.dtype(), primitive, std::move(dependency));
    auto ticket = std::make_unique<std::shared_ptr<DeferredRoute>>(deferred);
    // Only successful construction transfers callback ownership.
    deferred->context = context; deferred->load = load; deferred->release = release;
    scope->last_consumed = deferred->job->consumed;
    *anchor = value.release(); *handle = ticket.release();
    return 0;
  } catch (const std::exception& e) { last_error = e.what(); return 1; }
}
int ss_deferred_configure(void *r, const int32_t *slot_ids, int n,
    const int32_t *order, int rows, const int32_t *inverse, const int32_t *slots, const int32_t *live,
    const int32_t *staged, int staged_count) {
  try {
    if (!r || !slot_ids || !order || !inverse || !slots || !live) throw std::invalid_argument("Missing deferred grouping");
    auto route = *static_cast<std::shared_ptr<DeferredRoute> *>(r);
    if (n != route->route_count || rows < 8 || rows > n * 8 || rows % 8 || staged_count < 0 || staged_count > 80 ||
        (staged_count && (!staged || route->plan->affine))) throw std::invalid_argument("Invalid deferred grouping geometry");
    for (int i = 0; i < n; ++i)
      if (slot_ids[i] < 0 || slot_ids[i] >= route->capacity || inverse[i] < 0 || inverse[i] >= rows)
        throw std::invalid_argument("Invalid deferred route slot");
    for (int i = 0; i < rows; ++i)
      if (order[i] < 0 || order[i] >= n / route->top_k) throw std::invalid_argument("Invalid deferred input order");
    for (int i = 0; i < rows / 8; ++i)
      if (slots[i] < 0 || slots[i] >= route->capacity || live[i] < 1 || live[i] > 8)
        throw std::invalid_argument("Invalid deferred tile metadata");
    route->job->ready.data<uint32_t>()[1] = staged_count;
    const int first = route->plan->affine ? 10 : 4;
    auto& in = route->compute_inputs;
    std::copy_n(order, rows, in[first].data<int32_t>());
    std::copy_n(inverse, n, in[first + 1].data<int32_t>());
    std::copy_n(slots, rows / 8, in[first + 2].data<int32_t>());
    std::copy_n(live, rows / 8, in[first + 3].data<int32_t>());
    if (staged_count) {
      for (int i = 0; i < staged_count; ++i) {
        if (staged[i] < 0 || staged[i] >= route->capacity || std::find(slot_ids, slot_ids + n, staged[i]) == slot_ids + n)
          throw std::invalid_argument("Invalid deferred staged slot");
        for (int j = 0; j < i; ++j) if (staged[i] == staged[j]) throw std::invalid_argument("Duplicate deferred staged slot");
      }
      std::copy_n(staged, staged_count, in[first + 9].data<int32_t>());
    }
    return 0;
  } catch (const std::exception& e) { last_error = e.what(); return 1; }
}
int ss_deferred_compute(void *r, void *anchor, void *shared, bool grouped, void *stream_context, void **output, void **inverse) {
  try {
    if (!r || !anchor || !stream_context || !output || (grouped && !inverse)) throw std::invalid_argument("Missing deferred compute argument");
    auto route = *static_cast<std::shared_ptr<DeferredRoute> *>(r);
    auto stream = *static_cast<Stream *>(stream_context);
    auto inputs = route->compute_inputs;
    inputs[0] = *static_cast<array *>(anchor);
    if (shared) inputs.push_back(*static_cast<array *>(shared));
    auto primitive = std::make_shared<ExpertSchedule>(stream, route->plan, route->job,
        route->route_count * 8, route->route_count, route->plan->affine ? 9 : 3, grouped);
    // This metadata is host-filled only before the expert job's ready event.
    // A consumer must depend on the returned expert output, which gates it.
    std::unique_ptr<array> inverse_value;
    if (grouped) inverse_value = std::make_unique<array>(inputs[(route->plan->affine ? 9 : 3) + 2]);
    auto value = std::make_unique<array>(Shape{route->route_count * (grouped ? 8 : 1), route->plan->hidden},
        bfloat16, primitive, std::move(inputs));
    *output = value.release();
    if (grouped) *inverse = inverse_value.release();
    return 0;
  } catch (const std::exception& e) { last_error = e.what(); return 1; }
}
void ss_deferred_free(void *r) { delete static_cast<std::shared_ptr<DeferredRoute> *>(r); }

}
