import Foundation
import MLX
import Slotstream
import ArgumentParser

/// Actual checkpoint bytes, bounded pools and deliberately deferred four-layer
/// graphs exercise the ownership seam without loading a language model.
func checkNativeDeferredSchedule(index: CheckpointIndex, store: ExpertStore) throws {
    let cfg = index.config, topK = cfg.topK
    let pool = SlotPool(slots: topK * 2, store: store)
    pool.directDemandReads = true; pool.adaptiveReplacementEnabled = true
    let input = MLXArray((0..<cfg.hiddenSize).map { sin(Float($0) * 0.071) }, [1, cfg.hiddenSize]).asType(.bfloat16)
    func makeScope() throws -> NativeExpertSchedule.DeferredScope {
        try .init(pool: pool, hidden: cfg.hiddenSize, intermediate: cfg.moeIntermediate, affine: store.nativeAffineTiles)
    }
    func append(_ input: MLXArray, scope: NativeExpertSchedule.DeferredScope, layer: Int,
                cancelled: Bool = false) throws -> MLXArray {
        let ids = (0..<topK).map { Int32(($0 + layer * topK) % cfg.numExperts) }
        let pending = try scope.prepare(input, routes: MLXArray(ids), topK: topK, prediction: nil) {
            job, route, actual, _, _ in
            guard actual == ids else { throw ValidationError("Deferred route readback differs") }
            if cancelled { throw CancellationError() }
            pool.unpinAll()
            let keys = actual.map { ExpertKey(0, Int($0)) }
            var staging: NativeExpertSchedule.Staging?
            _ = try pool.ensureScheduled(keys, staging: { staging }) { slots, _ in
                let staged = store.isQ2 ? keys.enumerated().compactMap { pool.isResident($0.element) ? nil : slots[$0.offset] } : []
                staging = try scope.configure(job: job, route: route, slots: slots.map(Int32.init),
                    topK: topK, stagedSlots: staged)
            }
        }
        return try pending.compute(shared: nil)
    }
    // The final input depends on every prior GPU expert reader. Only that
    // dependency licenses reusing the single raw staging arena and pool.
    for rows in [1, 2, 8] {
        let scope = try makeScope()
        var actual = broadcast(input, to: [rows, cfg.hiddenSize])
        var expected = actual
        for layer in 0..<4 {
            let ids = (0..<(rows * topK)).map { Int32(($0 % topK + layer * topK) % cfg.numExperts) }
            let keys = (0..<topK).map { ExpertKey(0, ($0 + layer * topK) % cfg.numExperts) }
            let bytes = try store.readBatchChecked(keys)
            let referenceIDs = (0..<(rows * topK)).map { Int32($0 % topK) }
            expected = NativeExpertTiles.apply(expected, weights: bytes, ids: referenceIDs, repeatInput: topK,
                hidden: cfg.hiddenSize, intermediate: cfg.moeIntermediate, affine: store.nativeAffineTiles)
                .reshaped([rows, topK, cfg.hiddenSize]).mean(axis: 1).asType(.bfloat16)
            // Complete the independent reference before starting the deferred
            // graph; it cannot share or overwrite the candidate pool.
            eval(expected)
            let pending = try scope.prepare(actual, routes: MLXArray(ids), topK: topK, prediction: nil) {
                job, route, observed, _, _ in
                guard observed == ids else { throw ValidationError("Deferred route IDs changed") }
                pool.unpinAll()
                var staging: NativeExpertSchedule.Staging?
                _ = try pool.ensureScheduled(keys, staging: { staging }) { slots, _ in
                    let allSlots = observed.map { slots[Int($0) - layer * topK] }
                    let staged = store.isQ2 ? keys.enumerated().compactMap { pool.isResident($0.element) ? nil : slots[$0.offset] } : []
                    staging = try scope.configure(job: job, route: route, slots: allSlots.map(Int32.init), topK: topK, stagedSlots: staged)
                }
            }
            actual = try pending.compute(shared: nil).reshaped([rows, topK, cfg.hiddenSize]).mean(axis: 1).asType(.bfloat16)
        }
        eval(actual); try scope.finish()
        guard (actual .== expected).all().item(Bool.self) else { throw ValidationError("Deferred four-layer graph differs from original checkpoint bytes") }
        pool.unpinAll()
    }
    // Both a callback cancellation and a partial read failure must release GPU
    // waits, report failure and leave a subsequent independent scope usable.
    for cancelled in [false, true] {
        pool.unpinAll(); pool.resize(to: topK * 2)
        let scope = try makeScope()
        pool.readFault = cancelled ? nil : ReadFault(afterJobs: 2)
        let value = try append(input, scope: scope, layer: 7, cancelled: cancelled)
        eval(value)
        do { try scope.finish(); throw ValidationError("Deferred failure was hidden") }
        catch is CancellationError { guard cancelled else { throw ValidationError("Wrong deferred error") } }
        catch is CheckpointReadError { guard !cancelled else { throw ValidationError("Wrong deferred error") } }
        guard pool.pinnedSlotCount == 0 else { throw ValidationError("Deferred failure leaked pins") }
        pool.readFault = nil
        let recovered = try makeScope()
        let next = try append(input, scope: recovered, layer: 8)
        eval(next); try recovered.finish()
        guard isFinite(next).all().item(Bool.self) else { throw ValidationError("Deferred failure poisoned retry") }
        pool.unpinAll()
    }
    // Releasing an unevaluated graph must not enqueue a waiter or retain slots.
    do { let scope = try makeScope(); _ = try append(input, scope: scope, layer: 9); try scope.finish() }
    guard pool.pinnedSlotCount == 0 else { throw ValidationError("Unevaluated deferred graph changed pins") }
    print("Native deferred schedule: four-layer 1/2/8-row original-byte equality, failed reads, cancellation, retry and lazy disposal PASS")
}
