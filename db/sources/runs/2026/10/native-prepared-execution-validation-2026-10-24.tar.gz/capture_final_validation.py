import hashlib
import io
import json
import tarfile
from pathlib import Path

P = Path(__file__).resolve().parent
R = P.parents[1]
assert (P/'final-static-gates.log').read_text().rstrip().endswith('STATIC GATES PASS')
assert (P/'final-brain-gates.log').read_text().rstrip().endswith('BRAIN GATES PASS')
names = [
    'final-static-gates.log', 'final-static-exit.json', 'final-brain-gates.log',
    'final_repository_checks.py', 'final-repository-checks.json',
    'final-repository-checks-before-link-repair.json', 'publication-link-repair.json',
    'archive-split-receipt.json', 'privacy-review.json', 'local-build-selection.json',
    'v68-selected-source-scope.json', 'v68-final-engine-validation.json',
    'v68-final-fast-15-summary.json', 'v68-final-fast-thermal-audit.json',
    'v68-final-smart-q2-12-summary.json', 'v68-final-smart-q2-15-summary.json',
    'app-v68-final-summary.json', 'v68-upstream-quality-comparison.json',
    'capture_final_validation.py',
]
manifest = {}
for name in names:
    raw = (P/name).read_bytes()
    manifest[name] = dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
dest = R/'db/sources/runs/2026/10/native-prepared-execution-validation-2026-10-24.tar.gz'
assert not dest.exists()
with tarfile.open(dest, 'w:gz') as tar:
    for name in names:
        tar.add(P/name, arcname=name, recursive=False)
    raw = (json.dumps(manifest, indent=2)+'\n').encode()
    info = tarfile.TarInfo('manifest.json'); info.size = len(raw)
    tar.addfile(info, io.BytesIO(raw))
with tarfile.open(dest) as tar:
    for name, record in manifest.items():
        raw = tar.extractfile(name).read()
        assert len(raw) == record['bytes'] and hashlib.sha256(raw).hexdigest() == record['sha256']
receipt = dict(path=str(dest.relative_to(R)), bytes=dest.stat().st_size,
               sha256=hashlib.sha256(dest.read_bytes()).hexdigest(), files=len(names), readback_verified=True)
(P/'final-validation-archive-receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps(receipt))
