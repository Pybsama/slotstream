import hashlib
import importlib.util
import json
import re
import subprocess
from pathlib import Path
from urllib.parse import unquote, urlsplit

P = Path(__file__).resolve().parent
R = P.parents[1]
spec = importlib.util.spec_from_file_location('identity', R/'Tools/build_identity.py')
identity = importlib.util.module_from_spec(spec)
spec.loader.exec_module(identity)
expected = json.loads((P/'v68/build-identity.json').read_text())
current = {str(f.relative_to(R)): identity.sha(f) for f in identity.source_files(R)}
assert current == expected['source'], 'Frozen v68 build source differs from current source'
for name, digest in json.loads((P/'v68/sha256.json').read_text()).items():
    assert identity.sha(P/'v68'/name) == digest, name

paths = subprocess.check_output(['git', 'diff', '--name-only'], cwd=R, text=True).splitlines()
untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=R, text=True).splitlines()
checks, failures = [], []
for name in sorted(set(paths + untracked)):
    if not name.endswith('.md'):
        continue
    if name in untracked:
        lines = (R/name).read_text().splitlines()
    else:
        diff = subprocess.check_output(['git', 'diff', '--unified=0', '--', name], cwd=R, text=True)
        lines = [line[1:] for line in diff.splitlines() if line.startswith('+') and not line.startswith('+++')]
    for line in lines:
        for target in re.findall(r'\]\(([^\s)]+)\)', line):
            url = urlsplit(target.strip('<>'))
            if url.scheme or url.netloc or not url.path:
                continue
            file = (R/name).parent/unquote(url.path)
            exists = file.exists()
            checks.append(dict(source=name, target=target, exists=exists))
            if not exists:
                failures.append(checks[-1])

diff = subprocess.run(['git', 'diff', '--check'], cwd=R, capture_output=True, text=True)
result = dict(source_matches_v68=True, source_files=len(current), frozen_artifact_hashes_match=True,
              added_markdown_file_links=checks, broken_file_links=failures,
              scope='New and added Markdown file targets; wiki-links are checked independently by dbmd. Fragment anchors are not checked here.',
              diff_check=dict(exit_code=diff.returncode, stdout=diff.stdout, stderr=diff.stderr))
(P/'final-repository-checks.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(dict(source_matches_v68=True, link_count=len(checks), broken_links=failures, diff_check_exit=diff.returncode)))
assert not failures and diff.returncode == 0
