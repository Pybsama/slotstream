import json,subprocess,sys,hashlib,shutil
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1]
B=P/'v4';B.mkdir(exist_ok=False)
for name in ['slotstream','mlx.metallib','build-identity.json','build-source.tar.gz','build-source-before.json']:
 src=R/'.build/release'/name
 if src.exists(): shutil.copy2(src,B/name)
(B/'sha256.json').write_text(json.dumps({x.name:hashlib.sha256(x.read_bytes()).hexdigest() for x in B.iterdir()}))
def run(label,cmd):
 print('START',label,flush=True)
 with (P/(label+'-driver.log')).open('x') as f: r=subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT)
 print('END',label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
run('native-v4-kernels',[str(B/'slotstream'),'q2-experts-check'])
for label,binary,flag in [('baseline',P/'baseline/slotstream',False),('v4',B/'slotstream',False),('v4-fused',B/'slotstream',True),('v4-repeat',B/'slotstream',False)]:
 name='profile-fast-'+label
 fixture=R/'.build/fast-parity-20261022/matched16-baseline-0-A-raw.json'
 cmd=[sys.executable,str(P/'guarded_run.py'),'--label',name,'--budget','12']
 if flag:cmd+=['--env','SLOTSTREAM_OPT_GDN_PROJECTION=1']
 cmd+=['--',str(binary),'q2-profile','--model','fast','--memory-gb','12','--rounds','3','--fixture',str(fixture),'--output',str(P/(name+'.json'))]
 run(name,cmd)
for model,cases in [('fast',R/'.build/fast-parity-20261022/quality-and-functional-cases.json'),('smart-q2',R/'.build/q2-parity-20261022/final-quality-cases.json')]:
 name='v4-quality-'+model
 run(name,[sys.executable,str(P/'guarded_run.py'),'--label',name,'--budget','12','--',str(B/'slotstream'),'smart-dflash-check','--method',('q2' if model=='smart-q2' else model),'--memory-gb','12','--cases',str(cases),'--output',str(P/(name+'.json'))])
