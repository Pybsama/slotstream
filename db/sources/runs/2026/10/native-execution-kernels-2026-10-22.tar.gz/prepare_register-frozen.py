from pathlib import Path
import re
P=Path(__file__).resolve().parent
R=Path('/tmp/slotstream-splash-review.EJTswU/splash/runtime')
seen=set()
def flatten(name):
 if name in seen:return ''
 seen.add(name);s=(R/name).read_text()
 s=re.sub(r'^#pragma once\s*\n','',s,flags=re.M)
 return re.sub(r'^#include "([^"]+)"',lambda m:flatten(m[1]),s,flags=re.M)
header='\n'.join(flatten(p) for p in ['metal/abi/Gguf.h','metal/kernels/common/gguf_sgmatrix.h','metal/kernels/common/quant_formats.h','metal/kernels/common/sgmatrix.h'])
s=(R/'metal/kernels/decode/linear_gguf_sgmatrix.metal').read_text();s=s[s.index('namespace gguf_sg {'):s.index('// Table16 for `lanes`')]
s=s.replace('template <class F, uint L, GgufEpilogue Ep, class Out>','template <class F, uint L>')
s=s.replace('device uchar *w1, device uchar *meta, device Out *out,\n                   device coherent(device) float *partials, device atomic_uint *counters,\n                   device const bfloat *aux, const GgufDecodeParams p, uint2 tg, uint tid, uint sg,','device uchar *w1, device uchar *meta, device float *out,\n                   const GgufDecodeParams p, uint2 tg, uint tid, uint sg,')
a=s.index('  if (splits > 1) {');s=s[:a]+'''  for (uint r=0;r<L;++r) for(uint nf=0;nf<2;++nf) {
    uint column=p.out_offset+base+nf*8+fm;
    for(uint i=0;i<2;++i)out[((ulong(r)*splits+tg.y)*8+fn+i)*p.out_stride+column]=acc[r][nf][i];
  }
}
} // namespace gguf_sg
'''
assert 'coherent(device)' not in s and 'Out *' not in s
(P/'register-header.metal').write_text('#pragma clang fp reassociate(off)\n'+header+s)
(P/'register-prepare.metal').write_text('''uint span=(threadgroup_position_in_grid.x*4+simdgroup_index_in_threadgroup)/8;
uint row=(threadgroup_position_in_grid.x*4+simdgroup_index_in_threadgroup)%8;
uint lane=thread_index_in_simdgroup,k=span*64+2*lane;
bfloat a=row<COUNT?input[row*IN+k]:bfloat(0),b=row<COUNT?input[row*IN+k+1]:bfloat(0);
gguf_sg::write_input(table,sums,IN,span,row,lane,a,b);
''')
(P/'register-matrix.metal').write_text('''threadgroup bfloat2 lut[F::Kind==QuantCodebook?kQuantPairTableEntries:1];
threadgroup gguf_sg::Coef<F> coefs[gguf_sg::kCoefs<F>];threadgroup uint arrival;
quant_pair_table<F>(lut,thread_index_in_threadgroup,128);
const GgufDecodeParams params{IN,SPLITS,OUT,0,0};
gguf_sg::decode<F,1>(table,sums,const_cast<device uchar*>(w),const_cast<device uchar*>(w)+P1,
 const_cast<device uchar*>(w)+META,y,params,uint2(threadgroup_position_in_grid.x,threadgroup_position_in_grid.y),
 thread_index_in_threadgroup,simdgroup_index_in_threadgroup,thread_index_in_simdgroup,lut,coefs,&arrival);
''')
print('header bytes',len(header+s))
