uint span=(threadgroup_position_in_grid.x*4+simdgroup_index_in_threadgroup)/8;
uint row=(threadgroup_position_in_grid.x*4+simdgroup_index_in_threadgroup)%8;
uint lane=thread_index_in_simdgroup,k=span*64+2*lane;
bfloat a=row<COUNT?input[row*IN+k]:bfloat(0),b=row<COUNT?input[row*IN+k+1]:bfloat(0);
gguf_sg::write_input(table,sums,IN,span,row,lane,a,b);
