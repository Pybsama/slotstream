from pathlib import Path
p=Path('Sources/Slotstream/Q2MoE.swift');s=p.read_text().replace('sharedGate: MLXArray)','sharedGate: MLXArray, experts: Int = 512, topK: Int = 10)')
s=s.replace('precondition(scores.size == rows * 512 && sharedGate.size == hidden)','precondition((experts == 256 && topK == 8) || (experts == 512 && topK == 10))\n        precondition(scores.size == rows * experts && sharedGate.size == hidden)')
s=s.replace('template: [("H", hidden)], grid: (rows * 512,1,1), threadGroup: (512,1,1),','template: [("H", hidden), ("E", experts), ("K", topK)], grid: (rows * experts,1,1), threadGroup: (experts,1,1),')
s=s.replace('shape + [10],shape + [10]','shape + [topK],shape + [topK]')
s=s.replace('precondition(experts.size == rows * 10 * hidden && weights.size == rows * 10 && sharedWeight.size == rows)','let topK = weights.dim(-1)\n        precondition((topK == 8 || topK == 10) && experts.size == rows * topK * hidden\n                     && weights.size == rows * topK && sharedWeight.size == rows)')
s=s.replace('template: [("H",hidden)]','template: [("H",hidden), ("K", topK)]')
a=s.index('        uint row=threadgroup_position_in_grid.x');b=s.index('        """#,header:',a)
s=s[:a]+s[a:b].replace('[512]','[E]').replace('[10]','[K]').replace('[16]','[E/32]').replace('*512','*E').replace('+=512','+=E').replace('<16','<E/32').replace('slot=16','slot=E/32').replace('slot==16','slot==E/32').replace('<10','<K').replace('*10','*K')+s[b:]
a=s.index('        uint d=thread_position_in_grid.x');s=s[:a]+s[a:].replace('<10','<K').replace('*10','*K')
p.write_text(s)
p=Path('Sources/Slotstream/Weights.swift');s=p.read_text();needle='        var packed: [Int: PackedProjectionPair] = [:]';assert needle in s
s=s.replace(needle,'''        if config.isFast && Q2PackedExperts.enabled {
            // Splash prepares these small affine projections as FP32. Decode
            // the original codes once, without an intermediate BF16 rounding.
            // Replace the compressed tensors instead of retaining both copies;
            // PackMemoryProfile.fast reserves the bounded increase separately.
            for layer in 0..<config.numLayers {
                for suffix in ["gate", "shared_expert_gate"] {
                    let base = "model.layers.\\(layer).mlp.\\(suffix)"
                    guard let w = kept[base + ".weight"], let scales = kept[base + ".scales"],
                          let biases = kept[base + ".biases"] else { continue }
                    let q = config.quantizationOverrides[base]
                    let value = dequantized(w, scales: scales.asType(.float32), biases: biases.asType(.float32),
                        groupSize: q?.groupSize ?? config.qGroup, bits: q?.bits ?? config.qBits)
                    eval(value)
                    kept[base + ".weight"] = value
                    kept.removeValue(forKey: base + ".scales")
                    kept.removeValue(forKey: base + ".biases")
                }
            }
        }
''' + needle)
s=s.replace('if (self as? ResidentWeights)?.usesQ2 == true, s == nil {','if ((self as? ResidentWeights)?.usesQ2 == true || (config.isFast && Q2PackedExperts.enabled)), s == nil {')
p.write_text(s)
p=Path('Sources/Slotstream/Layers.swift');s=p.read_text().replace('return pool.expertStore.isQ2 ? Q2HyperConnection.swiGLU','return (pool.expertStore.isQ2 || pool.expertStore.nativeAffineTiles) ? Q2HyperConnection.swiGLU')
s=s.replace('if pool.expertStore.isQ2 {\n            let route = Q2MoE.route(scores: logits, input: x, sharedGate: sharedGate.w)','if pool.expertStore.isQ2 || pool.expertStore.nativeAffineTiles {\n            let route = Q2MoE.route(scores: logits, input: x, sharedGate: sharedGate.w,\n                experts: cfg.numExperts, topK: cfg.topK)')
p.write_text(s)
p=Path('Sources/Slotstream/PackMemoryProfile.swift');s=p.read_text().replace('identity: "qwen36-fast-memory-v1"','identity: "qwen36-fast-memory-v2"');print(s[s.index('    package static let fast'):s.index('    package static let fast')+600]);p.write_text(s)
p=Path('Sources/Slotstream/PersistentPrefixFormat.swift');s=p.read_text().replace('affine4-column-staged-fused-gdn-v2','affine4-column-staged-fused-gdn-float-routes-v3');p.write_text(s)
for p in [Path('Licenses/splash-NOTICE.txt'),Path('apps/macos/Resources/Licenses/splash-NOTICE.txt')]:
 s=p.read_text().replace('Q2PackedExperts.swift,','Q2PackedExperts.swift, NativeExpertTiles.swift, NativeAffineExperts.swift,');p.write_text(s)
