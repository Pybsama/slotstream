import json,subprocess,sys,hashlib,shutil
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];B=P/'v5';B.mkdir(exist_ok=False)
for name in ['slotstream','mlx.metallib','build-identity.json','build-source.tar.gz','build-source-before.json']:
 src=R/'.build/release'/name
 if src.exists():shutil.copy2(src,B/name)
(B/'sha256.json').write_text(json.dumps({x.name:hashlib.sha256(x.read_bytes()).hexdigest() for x in B.iterdir()}))
for model,fixture in [('fast',R/'.build/fast-parity-20261022/matched16-baseline-0-A-raw.json'),('smart-q2',R/'.build/q2-parity-20261022/final-v17-perf-code-0-A-raw.json')]:
 label='profile-v5-graph-'+model;print('START',label,flush=True)
 cmd=[sys.executable,str(P/'guarded_run.py'),'--label',label,'--budget','12','--env','SLOTSTREAM_NATIVE_GDN_GRAPH=1','--',str(B/'slotstream'),'q2-profile','--model',model,'--memory-gb','12','--rounds','3','--fixture',str(fixture),'--output',str(P/(label+'.json'))]
 with (P/(label+'-driver.log')).open('x') as log:r=subprocess.run(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT)
 print('END',label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
