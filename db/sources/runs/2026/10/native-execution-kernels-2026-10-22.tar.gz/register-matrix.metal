threadgroup bfloat2 lut[F::Kind==QuantCodebook?kQuantPairTableEntries:1];
threadgroup gguf_sg::Coef<F> coefs[gguf_sg::kCoefs<F>];threadgroup uint arrival;
quant_pair_table<F>(lut,thread_index_in_threadgroup,128);
const GgufDecodeParams params{IN,SPLITS,OUT,0,0};
gguf_sg::decode<F,1>(table,sums,const_cast<device uchar*>(w),const_cast<device uchar*>(w)+P1,
 const_cast<device uchar*>(w)+META,y,params,uint2(threadgroup_position_in_grid.x,threadgroup_position_in_grid.y),
 thread_index_in_threadgroup,simdgroup_index_in_threadgroup,thread_index_in_simdgroup,lut,coefs,&arrival);
