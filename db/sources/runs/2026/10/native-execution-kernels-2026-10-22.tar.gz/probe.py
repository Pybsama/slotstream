import mlx.core as mx, numpy as np,re,time,json
from pathlib import Path
R=Path(__file__).resolve().parents[2]
s=(R/'Sources/Slotstream/NativeExpertTiles.swift').read_text();source=s.split('outputNames: ["y"], source: #"""')[1].split('"""#')[0]
kernel=mx.fast.metal_kernel(name='native_expert_probe',input_names=['x','w','scales','biases','up','up_scales','up_biases','slots','live'],output_names=['y'],source=source,header='#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>\n#pragma clang fp reassociate(off)\n')
def bf(x):return np.array(mx.array(x,dtype=mx.float32).astype(mx.bfloat16).astype(mx.float32))
def weights(h,m,affine):
 packed=[];decoded=[]
 for piece in range(3):
  n,k=(h,m) if piece==2 else (m,h)
  if affine:
   words=(np.arange(3*n*k//8,dtype=np.uint64)*2654435761+piece*7717).astype(np.uint32).reshape(3,n,k//8)
   scale=bf(((np.arange(3*n*k//64)*17+piece)%31+1)/8192).reshape(3,n,k//64)
   bias=bf(-scale.ravel()*((np.arange(scale.size)*11)%15)).reshape(scale.shape)
   codes=((words[...,None] >> np.arange(0,32,4,dtype=np.uint32))&15).reshape(3,n,k).astype(np.float32)
   dense=(codes*np.repeat(scale,64,axis=-1)+np.repeat(bias,64,axis=-1)).astype(np.float16).astype(np.float32)
   packed.extend([mx.array(words.reshape(3,n//32,32,k//32,4).transpose(0,1,3,2,4).copy().reshape(words.shape)),
      mx.array(scale.reshape(3,n//32,32,k//64).transpose(0,1,3,2).copy().reshape(scale.shape),dtype=mx.bfloat16),
      mx.array(bias.reshape(3,n//32,32,k//64).transpose(0,1,3,2).copy().reshape(bias.shape),dtype=mx.bfloat16)])
  else:
   scale=(((np.arange(3*n*k//64)*7+piece)%17+1)/4096).astype(np.float16).reshape(3,n,k//64)
   q=(np.arange(3*n*k//4,dtype=np.uint64)*31+piece*19).astype(np.uint8).reshape(3,n,k//4)
   codes=((q[...,None] >> np.arange(0,8,2,dtype=np.uint8))&3).reshape(3,n,k).astype(np.float32)-1
   dense=(codes*np.repeat(scale.astype(np.float32),64,axis=-1)).astype(np.float16).astype(np.float32)
   plane=q.reshape(3,n//32,32,k//32,8).transpose(0,1,3,2,4).copy().reshape(3,-1)
   meta=scale.reshape(3,n//32,32,k//64).transpose(0,1,3,2).copy().view(np.uint8).reshape(3,-1)
   packed.append(mx.array(np.concatenate([plane,meta],axis=1)))
  decoded.append(dense)
 return packed,decoded
results=[]
for affine,h,m in [(False,2560,640),(True,128,64),(True,2048,512)]:
 w,dense=weights(h,m,affine)
 for ids in [[2],[1,1],[2,0,2],[2,0,1,0,0,2,0,0,0,0,0,0],[1]*17]:
  by={e:[r for r,v in enumerate(ids) if v==e] for e in dict.fromkeys(ids)};order=[];slots=[];live=[];inverse=[0]*len(ids)
  for e,rs in by.items():
   for start in range(0,len(rs),8):
    tile=rs[start:start+8]
    for r in tile:inverse[r]=len(order);order.append(r)
    order.extend([tile[-1]]*(8-len(tile)));slots.append(e);live.append(len(rs) if len(rs)<=2 else 8)
  inp=bf(((np.arange(len(ids)*h)*17)%101-50)/64).reshape(len(ids),h);x=mx.array(inp[order],dtype=mx.bfloat16)
  def proj(x,piece,fused,n,k):
   a=w[piece*3 if affine else piece];sc=w[piece*3+1] if affine else a;b=w[piece*3+2] if affine else a
   u=w[3 if affine else 1] if fused else a;us=w[4] if fused and affine else sc;ub=w[5] if fused and affine else b
   return kernel(inputs=[x,a,sc,b,u,us,ub,mx.array(slots,mx.int32),mx.array(live,mx.int32)],template=[('IN',k),('OUT',n),('FUSED',fused),('AFFINE',affine)],grid=(n//(32 if fused else 64)*64,len(slots),1),threadgroup=(64,1,1),output_shapes=[(len(slots)*8,n)],output_dtypes=[mx.bfloat16])[0]
  def run():return proj(proj(x,0,True,m,h),2,False,h,m)[mx.array(inverse)].astype(mx.float32)
  got=np.array(run());expect=[]
  for r,e in enumerate(ids):
   g=bf(inp[r].astype(np.float64)@dense[0][e].astype(np.float64).T);u=bf(inp[r].astype(np.float64)@dense[1][e].astype(np.float64).T)
   active=bf(g/(1+np.exp(-g))*u)
   expect.append(bf(active.astype(np.float64)@dense[2][e].astype(np.float64).T))
  expect=np.array(expect);err=float(np.max(np.abs(got-expect)));scale=float(np.max(np.abs(expect)))
  row=dict(affine=affine,h=h,m=m,routes=len(ids),error=err,scale=scale,finite=bool(np.all(np.isfinite(got))))
  print(row,flush=True);assert row['finite'] and err<=max(1e-6,scale*.015)
  results.append(row)
(R/'.build/native-execution-20261022/probe-results.json').write_text(json.dumps(results,indent=2))
