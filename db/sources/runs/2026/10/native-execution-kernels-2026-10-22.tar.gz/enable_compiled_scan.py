from pathlib import Path
p=Path('Sources/Slotstream/Layers.swift');s=p.read_text()
needle='    private func normalizeQK(_ q: MLXArray, _ k: MLXArray) -> (MLXArray, MLXArray) {'
assert s.count(needle)==1
body='''    private var preparedScan: (@Sendable ([MLXArray]) -> [MLXArray])?
    private var preparedRecordedScan: (@Sendable ([MLXArray]) -> [MLXArray])?

    /// Reuse the small native scan graph, including its input/output projections.
    /// Only eight verification widths can enter the cache. Weights are captured
    /// once; recurrent and convolution state are explicit input/output values.
    /// Recovery arrays remain lazy, so rejected states are never materialized.
    private func prepareNativeScan(record: Bool) -> @Sendable ([MLXArray]) -> [MLXArray] {
        let qkv = inQKV, z = inZ, a = inA, b = inB, out = outProj
        let weight = convWeight, log = aLog, bias = dtBias, normalization = norm.weight
        let hk = cfg.linearNumKHeads, hv = cfg.linearNumVHeads, width = valueDim
        let sigmoid = cfg.outputGateType == "sigmoid"
        return compile { values in
            let x = values[0], mixed = qkv(x)
            let convolution = concatenated([values[1], mixed], axis: 1)
            let result = Q2GatedDelta.apply(convInput: convolution, convWeight: weight,
                a: a(x), b: b(x), z: z(x).reshaped([1, x.dim(1), hv, 128]),
                aLog: log, dtBias: bias, norm: normalization, state: values[2],
                keyHeads: hk, valueHeads: hv, record: record, sigmoidGate: sigmoid)
            return [out(result.output.reshaped([1, x.dim(1), width])), convolution, result.state] + result.states
        }
    }

'''
s=s.replace(needle,body+needle)
needle='''        let (B, S) = (x.dim(0), x.dim(1))
        let profile = phaseProfile'''
assert s.count(needle)==1
s=s.replace(needle,'''        let (B, S) = (x.dim(0), x.dim(1))
        if ProcessInfo.processInfo.environment["SLOTSTREAM_NATIVE_GDN_GRAPH"] == "1",
           q2Arithmetic || (cfg.isFast && Q2PackedExperts.enabled),
           B == 1, (1...8).contains(S), minimumProjectionRows == 0,
           !fuseInputProjection, phaseProfile == nil {
            let record = cache?.record == true
            if record && preparedRecordedScan == nil { preparedRecordedScan = prepareNativeScan(record: true) }
            if !record && preparedScan == nil { preparedScan = prepareNativeScan(record: false) }
            let scan = record ? preparedRecordedScan! : preparedScan!
            let oldConvolution = cache?.convState ?? MLXArray.zeros([1, 3, convDim], dtype: .bfloat16)
            let oldState = cache?.ssmState ?? MLXArray.zeros([1, cfg.linearNumVHeads, 128, 128], dtype: .float32)
            let result = scan([x, oldConvolution, oldState])
            if let cache {
                cache.convState = result[1][0..., S..., 0...]
                cache.ssmState = result[2]
                if record {
                    cache.convStates = (0..<S).map { t in result[1][0..., (t + 1)..<(t + 4), 0...] }
                    cache.ssmStates = Array(result.dropFirst(3))
                }
            }
            return result[0]
        }
        let profile = phaseProfile''')
p.write_text(s)
