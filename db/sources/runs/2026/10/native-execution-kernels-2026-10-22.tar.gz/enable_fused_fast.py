from pathlib import Path
p=Path('Sources/Slotstream/Q2GatedDelta.swift');s=p.read_text();s=s.replace('''        record: Bool) ->''','''        record: Bool, sigmoidGate: Bool = true) ->''',1);s=s.replace('("RECORD", record)]','("RECORD", record), ("SIGMOID_GATE", sigmoidGate)]',1);s=s.replace('''            y[pos]=bfloat(float(normalized)/(1.0f+fast::exp2(-1.44269504089f*float(z[pos]))));''','''            float gate=float(z[pos]);
            float gated=SIGMOID_GATE ? 1.0f/(1.0f+fast::exp2(-1.44269504089f*gate))
                : gate/(1.0f+fast::exp2(-1.44269504089f*gate));
            y[pos]=bfloat(float(normalized)*gated);''');p.write_text(s)
p=Path('Sources/Slotstream/Layers.swift');s=p.read_text();s=s.replace('''        if q2Arithmetic {
            let fused = Q2GatedDelta.apply''','''        if q2Arithmetic || (cfg.isFast && Q2PackedExperts.enabled) {
            let fused = Q2GatedDelta.apply''',1);s=s.replace('''                valueHeads: cfg.linearNumVHeads, record: cache?.record == true)''','''                valueHeads: cfg.linearNumVHeads, record: cache?.record == true,
                sigmoidGate: cfg.outputGateType == "sigmoid")''',1)
s=s.replace('''if fuseInputProjection, let packedInput, packedInput.supportsOneToken(x)''','''if fuseInputProjection, let packedInput,
           cfg.isFast ? packedInput.supportsRows(x) : packedInput.supportsOneToken(x)''',1);p.write_text(s)
p=Path('Sources/Slotstream/PackedProjectionPair.swift');s=p.read_text();s=s.replace('''    package func callAsFunction(_ x: MLXArray)''','''    package func supportsRows(_ x: MLXArray) -> Bool {
        x.ndim == 3 && x.dim(0) == 1 && (1...512).contains(x.dim(1)) && x.dtype == .bfloat16
            && x.dim(2) == combined.w.dim(1) * 8
    }

    package func callAsFunction(_ x: MLXArray)''',1);p.write_text(s)
p=Path('Sources/Slotstream/PersistentPrefixFormat.swift');s=p.read_text().replace('affine4-column-staged-v1','affine4-column-staged-fused-gdn-v2');p.write_text(s)
