from pathlib import Path
p=Path('Sources/Slotstream/ExpertStore.swift');s=p.read_text()
s=s.replace('    package var isQ2: Bool { index.q2 != nil }','    package var isQ2: Bool { index.q2 != nil }\n    package let nativeAffineTiles: Bool')
s=s.replace('    public init(index: CheckpointIndex) throws {','''    public convenience init(index: CheckpointIndex) throws {
        try self.init(index: index, nativeAffineTiles: false)
    }

    package init(index: CheckpointIndex, nativeAffineTiles: Bool) throws {''',1)
s=s.replace('        self.downQuantization = down','''        self.downQuantization = down
        self.nativeAffineTiles = nativeAffineTiles && Q2PackedExperts.enabled && cfg.isFast
            && index.q2 == nil && affine.bits == 4 && affine.groupSize == 64 && down == affine''',1)
s=s.replace('        if isQ2 && Q2PackedExperts.enabled {\n            // A speculative','        if nativeAffineTiles || (isQ2 && Q2PackedExperts.enabled) {\n            // A speculative',1)
s=s.replace('''            try read(into: raw, layer: key.layer, piece: piece, offset: key.expert * bytes, count: bytes)
            guard shouldContinue() else { throw CheckpointReadError.cancelled }
            Q2PackedExperts.repackCPU(raw, into: destination,
                rows: piece == 2 ? cfg.hiddenSize : cfg.moeIntermediate,
                columns: piece == 2 ? cfg.moeIntermediate : cfg.hiddenSize)''','''            if usePackedLayout, let packedLayout {
                try packedLayout.readPiece(key, piece: piece, into: raw)
            } else { try read(into: raw, layer: key.layer, piece: piece, offset: key.expert * bytes, count: bytes) }
            guard shouldContinue() else { throw CheckpointReadError.cancelled }
            repackPieceCPU(raw, into: destination, piece: piece)''',1)
s=s.replace('''        try packedLayout.readRecord(key, into: destination)
    }''','''        try packedLayout.readRecord(key, into: destination)
        if nativeAffineTiles || (isQ2 && Q2PackedExperts.enabled) {
            guard let scratch = malloc(pieceRowBytes.max()!) else { throw ModelError("out of memory preparing an expert record") }
            defer { free(scratch) }
            var offset = 0
            for (piece, bytes) in pieceRowBytes.enumerated() {
                guard shouldContinue() else { throw CheckpointReadError.cancelled }
                memcpy(scratch, destination + offset, bytes)
                repackPieceCPU(scratch, into: destination + offset, piece: piece)
                offset += bytes
            }
        }
    }

    private func repackPieceCPU(_ raw: UnsafeRawPointer, into destination: UnsafeMutableRawPointer, piece: Int) {
        if nativeAffineTiles {
            NativeAffineExperts.repackCPU(raw, into: destination,
                rows: piece >= 6 ? cfg.hiddenSize : cfg.moeIntermediate,
                columns: piece >= 6 ? cfg.moeIntermediate : cfg.hiddenSize, codes: piece.isMultiple(of: 3))
        } else {
            Q2PackedExperts.repackCPU(raw, into: destination,
                rows: piece == 2 ? cfg.hiddenSize : cfg.moeIntermediate,
                columns: piece == 2 ? cfg.moeIntermediate : cfg.hiddenSize)
        }
    }''',1)
s=s.replace('''            if isQ2 && Q2PackedExperts.enabled {
                Q2PackedExperts.repackCPU(from, into: to,
                    rows: piece == 2 ? cfg.hiddenSize : cfg.moeIntermediate,
                    columns: piece == 2 ? cfg.moeIntermediate : cfg.hiddenSize)
            } else { memcpy(to, from, pieceRowBytes[piece]) }''','''            if nativeAffineTiles || (isQ2 && Q2PackedExperts.enabled) {
                repackPieceCPU(from, into: to, piece: piece)
            } else { memcpy(to, from, pieceRowBytes[piece]) }''',1)
s=s.replace('''        let evalStart = profile == nil ? 0 : RuntimeClock.now()
        if let profile { profile.wrappingSeconds''','''        if nativeAffineTiles {
            out = out.enumerated().map { p, raw in
                NativeAffineExperts.repack(raw, rows: p >= 6 ? cfg.hiddenSize : cfg.moeIntermediate,
                    columns: p >= 6 ? cfg.moeIntermediate : cfg.hiddenSize, codes: p.isMultiple(of: 3))
            }
        }
        let evalStart = profile == nil ? 0 : RuntimeClock.now()
        if let profile { profile.wrappingSeconds''',1)
p.write_text(s)
p=Path('Sources/Slotstream/Model.swift');s=p.read_text().replace('let store = try ExpertStore(index: index)','let store = try ExpertStore(index: index, nativeAffineTiles: index.config.isFast)');p.write_text(s)
p=Path('Sources/Slotstream/Layers.swift');s=p.read_text()
needle='''            let g = gatherQuantizedMM(
                xe, pool.pools[0]'''
assert needle in s;s=s.replace(needle,'''            if pool.expertStore.nativeAffineTiles {
                return NativeExpertTiles.apply(x, weights: pool.pools, ids: slotIds, repeatInput: count,
                    hidden: cfg.hiddenSize, intermediate: cfg.moeIntermediate, affine: true)
                    .reshaped([B, S, count, cfg.hiddenSize])
            }
            let g = gatherQuantizedMM(
                xe, pool.pools[0]''',1)
needle='''                        dAll = q2Experts(xg, weights: w, ids: local, repeatInput: 1).expandedDimensions(axis: 1)
                    } else {'''
assert needle in s;s=s.replace(needle,'''                        dAll = q2Experts(xg, weights: w, ids: local, repeatInput: 1).expandedDimensions(axis: 1)
                    } else if pool.expertStore.nativeAffineTiles {
                        dAll = NativeExpertTiles.apply(xg, weights: w, ids: local, repeatInput: 1,
                            hidden: H, intermediate: cfg.moeIntermediate, affine: true).expandedDimensions(axis: 1)
                    } else {''',1)
p.write_text(s)
p=Path('Sources/Slotstream/PersistentPrefixFormat.swift');s=p.read_text().replace('planes-mpp-hc-q80-bf16-gdn-float-split-moe-ple-qkv-v7','planes-mpp-hc-q80-bf16-gdn-float-column-moe-ple-qkv-v8');s=s.replace('"q2_preparation":','"fast_experts": model.pool.expertStore.nativeAffineTiles ? "affine4-column-staged-v1" : "mlx-qmm-v1",\n            "q2_preparation":');p.write_text(s)
