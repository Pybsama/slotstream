from pathlib import Path
import bisect,collections,csv,json,statistics
P=Path(__file__).resolve().parent
events=json.loads((P/'profile-ledger.json').read_text());assert len(events)==4
means=[statistics.mean(r['cycle_seconds']for r in e['rounds'][1:])for e in events]
controls=dict(baseline=means[1]/means[0],candidate=means[2]/means[3])
def read(path):
    lines=path.read_text().splitlines();footer=dict(x.split('=')for x in lines[-1][2:].split());assert int(footer['total'])<int(footer['cap'])
    return list(csv.DictReader(x for x in lines if not x.startswith('#'))),footer
def union(pairs):
    out=[]
    for a,b in sorted(pairs):
        if b<=a:continue
        if out and a<=out[-1][1]:out[-1]=(out[-1][0],max(out[-1][1],b))
        else:out.append((a,b))
    return out
def intersect(a,b):
    i=j=0;out=[]
    while i<len(a)and j<len(b):
        lo=max(a[i][0],b[j][0]);hi=min(a[i][1],b[j][1])
        if hi>lo:out.append((lo,hi))
        if a[i][1]<b[j][1]:i+=1
        else:j+=1
    return out
def length(xs):return sum(b-a for a,b in xs)
reports=[]
for event in events:
    if not event['traced']:continue
    label=event['label'];data=json.loads((P/(label+'.json')).read_text())
    stages,foot=read(next(P.glob(label+'-commands.*.stages.csv')));pipelines,_=read(next(P.glob(label+'-commands.*.pipelines.csv')));assignments,_=read(next(P.glob(label+'-commands.*.assignments.csv')))
    assert foot['cpu_initial']==foot['gpu_initial'] and foot['cpu_final']==foot['gpu_final']
    by_pointer=collections.defaultdict(list)
    for i,s in enumerate(stages):
        s.update(index=i,encoded=float(s['encoded']),gpu_start=int(s['gpu_start'])/1e9,gpu_end=int(s['gpu_end'])/1e9,names=[])
        by_pointer[s['encoder']].append(s)
    for v in by_pointer.values():v.sort(key=lambda s:s['encoded'])
    created={k:[s['encoded']for s in v]for k,v in by_pointer.items()}
    by_pipeline=collections.defaultdict(list)
    for p in pipelines:p['stamp']=float(p['stamp']);by_pipeline[p['pipeline']].append(p)
    for v in by_pipeline.values():v.sort(key=lambda p:p['stamp'])
    ptime={k:[p['stamp']for p in v]for k,v in by_pipeline.items()}
    unknown=unassigned=0
    for a in assignments:
        t=float(a['stamp']);ss=by_pointer.get(a['encoder'],[]);i=bisect.bisect_right(created.get(a['encoder'],[]),t)-1
        if i<0:unassigned+=1;continue
        ps=by_pipeline.get(a['pipeline'],[]);j=bisect.bisect_right(ptime.get(a['pipeline'],[]),t)-1
        if j<0:unknown+=1;name='UNKNOWN'
        else:name=ps[j]['name']
        ss[i]['names'].append(name)
    stages.sort(key=lambda s:s['encoded']);starts=[s['encoded']for s in stages]
    rounds=[]
    for rd in data['rounds'][1:]:
        windows=union([(s['start_ns']/1e9,s['end_ns']/1e9)for s in rd['steps']]);inside=[];groups=collections.defaultdict(list)
        for step in rd['steps']:
            lo,hi=step['start_ns']/1e9,step['end_ns']/1e9
            selected=stages[bisect.bisect_left(starts,lo):bisect.bisect_left(starts,hi)]
            for s in selected:
                assert s['gpu_end']>s['gpu_start']>0,(label,s['index'])
                assert 'UNKNOWN' not in s['names']
                inside.append(s);groups[tuple(s['names'])].append((s,step['width']))
        spans=union([(s['gpu_start'],s['gpu_end'])for s in stages if s['gpu_end']>s['gpu_start']>0])
        gpu=length(intersect(windows,spans));wall=length(windows)
        expert=[s for s in inside if 'native_gate_up' in s['names']]
        ex=length(intersect(windows,union([(s['gpu_start'],s['gpu_end'])for s in expert])))
        details=[]
        for names,vs in groups.items():
            details.append(dict(names=names,encoders=len(vs),seconds=sum(s['gpu_end']-s['gpu_start']for s,w in vs),by_width={str(w):dict(encoders=len(ww),seconds=sum(s['gpu_end']-s['gpu_start']for s in ww))for w in range(1,9)if(ww:=[s for s,x in vs if x==w])}))
        details.sort(key=lambda d:-d['seconds'])
        rounds.append(dict(round=rd['round'],cycle_seconds=wall,gpu_union_seconds=gpu,outside_gpu_seconds=wall-gpu,expert_gpu_seconds=ex,expert_encoders=len(expert),encoders=len(inside),groups=details))
    reports.append(dict(label=label,arm=event['arm'],unknown_pipeline_assignments=unknown,unassigned_encoder_selections=unassigned,rounds=rounds))
eligible=all(e['eligible']for e in events);sensitive=all(.98<=r<=1.02 for r in controls.values())
result=dict(environment_eligible=eligible,observer_controls=controls,controls_passed=sensitive,quantitative_attribution_eligible=eligible and sensitive,cycle_seconds=means,arms=reports,scope='GPU stage intervals clipped to frozen full-cycle windows. Outside-GPU coverage is not pure idle or recoverable CPU time. Expert groups may include other commands in that same encoder; named signatures preserved. Diagnostic only; original clean ABBA rejection stands.')
(P/'profile-analysis.json').write_text(json.dumps(result,indent=2))
print(json.dumps({**{k:v for k,v in result.items()if k!='arms'},'arms':[{**x,'rounds':[{k:v for k,v in r.items()if k!='groups'}for r in x['rounds']]}for x in reports]},indent=2))
