from pathlib import Path
import json,hashlib,shutil
P=Path(__file__).resolve().parent
backup=P/'initial-sources';backup.mkdir()
for n in ['NativeExpertSchedule.swift','Layers.swift','plan.json','run.py','build_native.py']:shutil.copy2(P/n,backup/n)
p=P/'NativeExpertSchedule.swift';s=p.read_text();anchor='    package static let gpuStagingEnabled = enabled\n'
assert s.count(anchor)==1
s=s.replace(anchor,'    package static let deferredEnabled = ProcessInfo.processInfo.environment["SLOTSTREAM_Q2_EARLY_EXPERT"] != "0"\n'+anchor);p.write_text(s)
p=P/'Layers.swift';s=p.read_text();old='''        if ProcessInfo.processInfo.environment["SLOTSTREAM_Q2_EARLY_EXPERT"] != "0",
           predicted != nil, readbackQueue?.arrays.isEmpty != false,
           pool.expertStore.isQ2, B == 1, S <= 8, contextNumericsObserver == nil,''';new='''        if pool.expertStore.isQ2, B == 1, S <= 8, contextNumericsObserver == nil,
           NativeExpertSchedule.deferredEnabled,
           predicted != nil, readbackQueue?.arrays.isEmpty != false,'''
assert s.count(old)==1;s=s.replace(old,new);p.write_text(s)
for n in ['build_native.py','run.py']:
    p=P/n;s=p.read_text();assert 'native-build' in s;s=s.replace('native-build','native-build-v2');p.write_text(s)
rep=json.loads((P/'replacements.json').read_text());plan=json.loads((P/'plan.json').read_text())
plan['sources']={k:hashlib.sha256((P/v).read_bytes()).hexdigest()for k,v in rep.items()}
plan['revision']='Before any timing, cache the diagnostic-switch lookup and test Q2 first, preserving Fast bypass. Initial checkpoint/lifetime checks apply to byte-identical C++/Swift deferred implementation and check source. Full-model validation uses this exact revision.'
(P/'plan.json').write_text(json.dumps(plan,indent=2))
