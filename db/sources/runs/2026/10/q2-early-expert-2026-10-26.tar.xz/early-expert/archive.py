from pathlib import Path
import fcntl,hashlib,io,json,os,re,subprocess,sys,tarfile
P=Path(__file__).resolve().parent;R=P.parents[1]
assert (P/'analysis.json').exists()and(P/'profile-analysis.json').exists()
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
preflight(4)
reservation=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(reservation,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert not subprocess.run(['pgrep','-f',str(P/'native-build-v2/candidate/slotstream')],capture_output=True,text=True).stdout.strip()
sha=lambda b:hashlib.sha256(b).hexdigest()
allowed={'.py','.swift','.h','.cpp','.mm','.json','.jsonl','.csv','.log','.stderr','.txt'}
secret=re.compile(rb'(?:ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{25,}|sk-(?:proj-)?[A-Za-z0-9_-]{30,}|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----)')
files={}
for f in P.rglob('*'):
    if not f.is_file()or '__pycache__' in f.parts or f.suffix not in allowed or f.name.startswith('archive-receipt')or(f.name.startswith('archive')and f.suffix=='.log'):continue
    files['early-expert/'+str(f.relative_to(P))]=f
for name in ['NativeExpertSchedule.swift','Layers.swift']:files['reference/'+name]=R/'Sources/Slotstream'/name
files['reference/NativeSchedule.cpp']=R/'Sources/CNativeSchedule/NativeSchedule.cpp'
files['reference/v68-build-identity.json']=R/'.build/native-replay-20261023/v68/build-identity.json'
files['reference/full-cycle-build-identity.json']=R/'.build/q2-full-cycle-20261025/native-build/candidate/build-identity.json'
files['reference/named_stage_observer.mm']=R/'.build/q2-sequence-20261025/named_stage_observer.mm'
files['reference/LICENSE']=R/'LICENSE'
manifest={}
for n,f in files.items():
    b=f.read_bytes();assert not secret.search(b),n;manifest[n]=dict(bytes=len(b),sha256=sha(b))
dest=R/'db/sources/runs/2026/10/q2-early-expert-2026-10-26.tar.xz';assert not dest.exists();raw=json.dumps(manifest,indent=2).encode()
with tarfile.open(dest,'w:xz',preset=3)as t:
    for n,f in sorted(files.items()):t.add(f,arcname=n,recursive=False)
    info=tarfile.TarInfo('archive-manifest.json');info.size=len(raw);t.addfile(info,io.BytesIO(raw))
seen={}
with tarfile.open(dest,'r|xz')as t:
    for m in t:
        b=t.extractfile(m).read()
        if m.name=='archive-manifest.json':assert json.loads(b)==manifest
        else:seen[m.name]=dict(bytes=len(b),sha256=sha(b))
assert seen==manifest and dest.stat().st_size<100_000_000
receipt=dict(path=str(dest.relative_to(R)),files=len(manifest),bytes=dest.stat().st_size,sha256=sha(dest.read_bytes()),readback_verified=True,credential_pattern_matches=0,excluded='Executables, libraries, weights, pycache, duplicate source archives and active archive-driver output. Raw CSV timestamps and pipeline names contain no tensor data.')
(P/'archive-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt),flush=True)
