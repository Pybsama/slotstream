from pathlib import Path
import argparse,fcntl,json,os,subprocess,sys
P=Path(__file__).resolve().parent;R=P.parents[1]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight,terminate_child_tree
sys.path.insert(0,str(R/'.build/native-q2-20261021'));from thermal import wait_nominal
ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['checks','validation','timing','profile']);a=ap.parse_args()
reservation=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(reservation,fcntl.LOCK_EX|fcntl.LOCK_NB)
inner=P/(a.mode+'-child.lock');os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(inner)
prefix='timing-fixed' if a.mode=='timing' else a.mode
ledger=P/(prefix+'-ledger.json');assert not ledger.exists();events=[]
validation=a.mode=='validation';checks=a.mode=='checks';rounds=1 if validation else 3
if a.mode!='checks':assert json.loads((P/'checks-result.json').read_text())['passed']
if a.mode in ('timing','profile'):assert json.loads((P/'validation-result.json').read_text())['passed']
if a.mode=='profile':assert json.loads((P/'analysis.json').read_text())['environment_eligible']
for i,raw_arm in enumerate('B' if validation or checks else 'AabB' if a.mode=='profile' else 'ABBA'):
    arm=raw_arm.upper();traced=a.mode=='profile' and raw_arm.islower()
    label=f'{prefix}-{i}-{arm}';out=P/(label+'.json');assert not out.exists()
    wait_nominal(P/(label+'-cooldown.json'));budget=6 if checks else 15;preflight(budget+3)
    binary=(P/'native-build-v2/candidate/slotstream') if arm=='B' else (P.parent/'q2-full-cycle-20261025/native-build/candidate/slotstream')
    env=['--env','SLOTSTREAM_MODEL_LOCK_PATH='+str(inner)]
    if traced:env+=['--env','DYLD_INSERT_LIBRARIES='+str(R/'.build/q2-sequence-20261025/named_stage_observer.dylib'),'--env','SLOTSTREAM_METAL_OBSERVER='+str(P/(label+'-commands'))]
    if checks:env+=['--env','SLOTSTREAM_CHECK_DEFERRED=1']
    if checks or validation:env+=['--env','MTL_DEBUG_LAYER=1']
    cmd=[str(binary),'q2-experts-check','--pool-model','smart-q2'] if checks else [str(binary),'q2-profile','--fixture',str(P/'timed-2.json'),'--output',str(out),'--memory-gb','15','--rounds',str(rounds)]
    if validation:cmd+=['--validate']
    full=[sys.executable,str(P/'quiet_guarded_run.py'),'--label',label,'--budget',str(budget),'--timeout','600',*env,'--',*cmd]
    print('START',label,flush=True)
    with(P/(label+'-launcher.log')).open('x')as log:
        child=subprocess.Popen(full,cwd=R,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        try:rc=child.wait(timeout=660)
        finally:
            if child.poll()is None:terminate_child_tree(child)
    guard=json.loads((P/(label+'.observer.json')).read_text())
    event=dict(label=label,arm=arm,traced=traced,exit_code=rc,command=full,eligible=not guard['external_build_samples'] and not guard['paging'] and guard['thermal_before']==guard['thermal_after']==0 and guard['peak_combined_bytes']<=budget*1e9 and rc==0)
    events.append(event);ledger.write_text(json.dumps(events,indent=2))
    if rc:raise SystemExit(rc)
    if checks:
        log=(P/(label+'.log')).read_text()
        for needle in ['Deferred bounded reservation and unbound cancellation PASS','Deferred invalid bind, duplicate destination, temporary owners, multirow/shared and independent bytes PASS','Mixed shared/routed grids: actual cache hit/miss/cancel/resize/forecast lifecycle PASS']:assert needle in log,needle
        (P/'checks-result.json').write_text(json.dumps(dict(passed=True,scope='Original bytes, shared/routed arithmetic, failures/retry/resize/forecast, deferred invalid binding/cancellation/temporary owners and shared reservation. Metal validation.')))
        continue
    d=json.loads(out.read_text());assert d['complete'] and d['plan']['pool_slots']==4067
    rows=[r for rd in d['rounds'] for r in rd['steps']]
    ref=json.loads((P.parent/'q2-full-cycle-20261025/validation-0-N.json').read_text())['rounds'][0]['steps']
    assert len(rows)==rounds*111
    for row in rows:
        expected=ref[row['step']]
        for key in ['width','kept','actual_guesses','actual_selected']+(['logits_sha256'] if validation else []):assert row[key]==expected[key],(label,row['round'],row['step'],key)
    if arm=='B':
        stats=d['deferred_stats'];assert stats[0]>0 and stats[2]>0 and stats[2]<=stats[0],stats
        event['deferred_stats']=stats
    event['rounds']=[dict(round=rd['round'],seconds=rd['seconds'],cycle_seconds=sum(r['seconds']for r in rd['steps']),demand=sum(r['records_fetched']for r in rd['steps']),adopted=sum(r['records_adopted']for r in rd['steps']))for rd in d['rounds']]
    ledger.write_text(json.dumps(events,indent=2));print('END',label,event['eligible'],event['rounds'],flush=True)
if validation:(P/'validation-result.json').write_text(json.dumps(dict(passed=True,scope='111full-logithashes,proposals,selectedtokens exactly match frozenv68; Metal validation; actual deferred branches;4067slots and15GBphysical ceiling. Not product speed or semantic quality.')))
print('PROTOCOL FINISHED',flush=True)
