from pathlib import Path
import hashlib,json,shutil,subprocess
P=Path(__file__).resolve().parent;R=P.parents[1];D=P.parent/'q2-required-dependencies-20261026'
rep={}
def change(s,old,new):
 assert s.count(old)==1,(old,s.count(old));return s.replace(old,new)
def save(name,s):
 local=Path(name).name;rep[name]=local;(P/local).write_text(s)
for name in ['build_native.py','quiet_guarded_run.py','timed-2.json','check_restoration.py','Q2ProfileCommand.swift']:shutil.copy2(D/name,P/name)
rep['Sources/slotstream-cli/Q2ProfileCommand.swift']='Q2ProfileCommand.swift'
s=(R/'Sources/CNativeSchedule/NativeSchedule.cpp').read_text()
s=change(s,'struct Job {',r'''
constexpr size_t staging_limit = 110592000;
std::atomic<size_t> staging_live{0};
std::atomic<uint64_t> deferred_prepared{0}, deferred_refused{0}, deferred_bound{0};
struct StagingUnavailable : std::exception {};
struct StagingReservation {
  size_t bytes;
  StagingReservation(size_t n, bool bounded) : bytes(n) {
    if (bounded) {
      auto used=staging_live.load(std::memory_order_acquire);
      do {
        if (used > staging_limit || n > staging_limit-used) { ++deferred_refused; throw StagingUnavailable(); }
      } while (!staging_live.compare_exchange_weak(used,used+n,std::memory_order_acq_rel));
    } else staging_live.fetch_add(n,std::memory_order_acq_rel);
  }
  ~StagingReservation(){staging_live.fetch_sub(bytes,std::memory_order_acq_rel);}
};
struct DeferredRoutes {
  std::vector<array> metadata;
  int rows=0, routes=0, records=0;
  bool mixed=false, bound=false;
};
struct Job {''')
s=change(s,'  int staged = 0;','  int staged = 0;\n  std::shared_ptr<StagingReservation> reservation;\n  std::optional<DeferredRoutes> deferred;')
s=change(s,'  void prepare_staging(int count, int piece_bytes) {','  void prepare_staging(int count, int piece_bytes, bool bounded = false) {')
s=change(s,'    // Host-owned materialized inputs; the event gates every GPU read.\n    for (int i = 0; i < 3; ++i)\n      raw.emplace_back(allocator::malloc(size_t(count) * piece_bytes), Shape{count, piece_bytes}, uint8);',r'''
    // Charge until the last actual MLX data owner releases all three pieces.
    // A speculative preparation is refused, never granted a second reserve.
    reservation=std::make_shared<StagingReservation>(size_t(count)*piece_bytes*3,bounded);
    for (int i = 0; i < 3; ++i)
      raw.emplace_back(allocator::malloc(size_t(count) * piece_bytes), Shape{count, piece_bytes}, uint8,
          [held=reservation](allocator::Buffer b){allocator::free(b);});''')
s=change(s,'    ready.data<uint32_t>()[0] = success ? 1 : 2;','    success = success && (!deferred || deferred->bound);\n    ready.data<uint32_t>()[0] = success ? 1 : 2;')
s=change(s,'int ss_schedule_prepare(void *p, void *x, void *const *weights, int count,','static int prepare_schedule(void *p, void *x, void *const *weights, int count,')
s=change(s,'                        void *prerequisite, void *const *forecast, void *stream_context, void **output, void **job) {','                        void *prerequisite, void *const *forecast, void *stream_context, void **output, void **job, bool deferred) {')
s=change(s,'    work->prepare_staging(staged_count, plan->hidden * plan->intermediate / 64 * 18);','    work->prepare_staging(staged_count, plan->hidden * plan->intermediate / 64 * 18, deferred);')
s=change(s,'    auto primitive = std::make_shared<ExpertSchedule>(stream, plan, work, rows, routes, count, grouped_output);',r'''
    if (deferred) {
      if (plan->affine || !plan->mixed_shared || !grouped_output || prerequisite || staged_count!=routes)
        throw std::invalid_argument("Deferred expert preparation requires bounded Q2 mixed output");
      const int order_at=count+1, destinations_at=count+10;
      work->deferred.emplace(DeferredRoutes{{inputs[order_at],inputs[order_at+1],inputs[order_at+2],inputs[order_at+3],inputs[destinations_at]},rows,routes,inputs[1].shape(0),true,false});
      work->ready.data<uint32_t>()[1]=0;
      ++deferred_prepared;
    }
    auto primitive = std::make_shared<ExpertSchedule>(stream, plan, work, rows, routes, count, grouped_output);''')
s=change(s,'    *output = value.release(); *job = ticket.release(); return 0;\n  } catch (const std::exception& e) { last_error = e.what(); return 1; }\n}\nvoid ss_schedule_publish',r'''
    *output = value.release(); *job = ticket.release(); return 0;
  } catch (const StagingUnavailable&) { return 2; }
  catch (const std::exception& e) { last_error = e.what(); return 1; }
}
int ss_schedule_prepare(void *p, void *x, void *const *weights, int count,
    const int32_t *order, int rows, const int32_t *inverse, int routes,
    const int32_t *slots, const int32_t *live, const int32_t *staged_slots,
    int staged_count, bool awaiting_reads, bool grouped_output, void *prerequisite,
    void *const *forecast, void *stream_context, void **output, void **job) {
  return prepare_schedule(p,x,weights,count,order,rows,inverse,routes,slots,live,staged_slots,
      staged_count,awaiting_reads,grouped_output,prerequisite,forecast,stream_context,output,job,false);
}
int ss_schedule_prepare_deferred(void *p, void *x, void *const *weights, int count,
    int routes, int input_rows, void *const *forecast, void *stream_context, void **output, void **job) {
  if (routes<1 || routes>80 || input_rows<1 || input_rows>8) {last_error="Invalid deferred extent";return 1;}
  std::vector<int32_t> order((routes+1)*8,0),inverse(routes,0),slots(routes+1,0),live(routes+1,1),destinations(routes);
  for(int i=0;i<routes;++i)slots[i]=destinations[i]=i;
  for(int i=0;i<8;++i)order[routes*8+i]=std::min(i,input_rows-1);
  live.back()=input_rows;
  return prepare_schedule(p,x,weights,count,order.data(),int(order.size()),inverse.data(),routes,
      slots.data(),live.data(),destinations.data(),routes,true,true,nullptr,forecast,stream_context,output,job,true);
}
int ss_schedule_bind_deferred(void *j,const int32_t *order,int rows,const int32_t *inverse,int routes,
    const int32_t *slots,const int32_t *live,const int32_t *destinations,int staged) {
  try {
    if(!j || !order || !inverse || !slots || !live || staged<0 || (staged && !destinations))throw std::invalid_argument("Missing deferred routes");
    auto& work=**static_cast<std::shared_ptr<Job>*>(j);
    if(!work.deferred || work.deferred->bound || work.published.load(std::memory_order_acquire))throw std::invalid_argument("Deferred routes already closed");
    auto& d=*work.deferred;
    if(routes!=d.routes || rows<16 || rows>d.rows || rows%8 || staged>d.routes)throw std::invalid_argument("Deferred geometry differs");
    const int tiles=rows/8-1;
    for(int i=0;i<routes;++i)if(inverse[i]<0 || inverse[i]>=tiles*8)throw std::invalid_argument("Invalid deferred inverse");
    const int input_rows=static_cast<int>(d.metadata[3].data<int32_t>()[d.rows/8-1]);
    for(int i=0;i<rows;++i)if(order[i]<0 || order[i]>=input_rows)throw std::invalid_argument("Invalid deferred input row");
    for(int i=0;i<tiles;++i)if(slots[i]<0 || slots[i]>=d.records || live[i]<1 || live[i]>8)throw std::invalid_argument("Invalid deferred tile");
    if(live[tiles]!=input_rows)throw std::invalid_argument("Invalid deferred shared rows");
    for(int i=0;i<staged;++i){
      if(destinations[i]<0 || destinations[i]>=d.records || std::find(slots,slots+tiles,destinations[i])==slots+tiles)throw std::invalid_argument("Unrouted deferred destination");
      for(int k=0;k<i;++k)if(destinations[i]==destinations[k])throw std::invalid_argument("Duplicate deferred destination");
    }
    std::copy_n(order,tiles*8,d.metadata[0].data<int32_t>());
    std::copy_n(order+tiles*8,8,d.metadata[0].data<int32_t>()+d.rows-8);
    std::copy_n(inverse,routes,d.metadata[1].data<int32_t>());
    std::copy_n(slots,tiles,d.metadata[2].data<int32_t>());
    std::fill_n(d.metadata[3].data<int32_t>(),d.rows/8-1,0);
    std::copy_n(live,tiles,d.metadata[3].data<int32_t>());
    if(staged)std::copy_n(destinations,staged,d.metadata[4].data<int32_t>());
    work.ready.data<uint32_t>()[1]=staged;d.bound=true;++deferred_bound;
    return 0;
  }catch(const std::exception&e){last_error=e.what();return 1;}
}
void ss_schedule_deferred_stats(uint64_t *prepared,uint64_t *refused,uint64_t *bound,uint64_t *live_bytes){
  if(prepared)*prepared=deferred_prepared.load();if(refused)*refused=deferred_refused.load();
  if(bound)*bound=deferred_bound.load();if(live_bytes)*live_bytes=staging_live.load();
}
void ss_schedule_publish''')
s=change(s,'index < 0 || index >= work.staged ||','index < 0 || index >= int(work.ready.data<uint32_t>()[1]) ||')
s=change(s,'indices[i] < 0 || indices[i] >= work.staged','indices[i] < 0 || indices[i] >= int(work.ready.data<uint32_t>()[1])')
save('Sources/CNativeSchedule/NativeSchedule.cpp',s)
s=(R/'Sources/CNativeSchedule/include/NativeSchedule.h').read_text();s+='''
#ifdef __cplusplus
extern "C" {
#endif
int ss_schedule_prepare_deferred(void*,void*,void*const*,int,int,int,void*const*,void*,void**,void**);
int ss_schedule_bind_deferred(void*,const int32_t*,int,const int32_t*,int,const int32_t*,const int32_t*,const int32_t*,int);
void ss_schedule_deferred_stats(uint64_t*,uint64_t*,uint64_t*,uint64_t*);
#ifdef __cplusplus
}
#endif
''';save('Sources/CNativeSchedule/include/NativeSchedule.h',s)
s=(R/'Sources/Slotstream/NativeExpertSchedule.swift').read_text()
s=change(s,'    fileprivate final class Ticket {',r'''
    package static var deferredStats: (UInt64,UInt64,UInt64,UInt64) {
        var a:UInt64=0,b:UInt64=0,c:UInt64=0,d:UInt64=0
        ss_schedule_deferred_stats(&a,&b,&c,&d);return(a,b,c,d)
    }
    package func submitDeferred(_ input: MLXArray, bindings: Bindings, routes: Int, repeatInput: Int,
                                forecastArena: NativeForecastArena?, shared: SharedBindings) throws -> Pending? {
        guard !affine, mixedShared, (1...80).contains(routes), repeatInput>0, routes.isMultiple(of: repeatInput),
              bindings.records>=routes, bindings.hidden==hidden, bindings.intermediate==intermediate,
              input.dtype == .bfloat16, input.size==routes/repeatInput*hidden else { return nil }
        let count=routes/repeatInput
        guard (1...8).contains(count) else { return nil }
        let x=contiguous(input), sharedOwners=shared.arrays(count:count), stream=StreamOrDevice.default
        let owners=bindings.owners+sharedOwners
        var output:UnsafeMutableRawPointer?,job:UnsafeMutableRawPointer?
        let rc=withExtendedLifetime((x,owners,forecastArena,stream)) {
            ss_schedule_prepare_deferred(nativePlan,x.ctx.ctx,owners.map{$0.ctx.ctx},Int32(owners.count),
                Int32(routes),Int32(count),forecastArena?.arrays.map{$0.ctx.ctx},stream.ctx.ctx,&output,&job)
        }
        if rc==2{return nil}
        guard rc==0,let output,let job else {throw ModelError(String(cString:ss_schedule_error()))}
        let value=MLXArray(mlx_array(ctx:output))
        let pending=try Pending(output:value,job:job,stagedSlots:[],forecastArena:forecastArena,inverse:nil,sharedRows:count)
        pending.deferredArena=forecastArena;pending.deferredRepeat=repeatInput;pending.needsBinding=true
        asyncEval(value)
        return pending
    }
    fileprivate final class Ticket {''')
s=change(s,'        package let staging: Staging?','        package private(set) var staging: Staging?')
s=change(s,'        package let inverse: [Int32]?','        package private(set) var inverse: [Int32]?')
s=change(s,'        private var finished = false','''        private var finished = false
        fileprivate var deferredArena: NativeForecastArena?
        fileprivate var deferredRepeat = 0
        fileprivate var needsBinding = false
        package func bindDeferred(ids:[Int32],stagedSlots:[Int]) throws {
            guard needsBinding,!finished,deferredRepeat>0 else {throw ModelError("Deferred command is not bindable")}
            let grouping=NativeExpertTiles.Grouping(ids:ids)
            var order=grouping.order.map{$0/Int32(deferredRepeat)}
            order += (0..<8).map{Int32(min($0,sharedRows-1))}
            let experts=grouping.experts+[0],counts=grouping.counts+[Int32(sharedRows)]
            guard ss_schedule_bind_deferred(job,order,Int32(order.count),grouping.inverse,Int32(ids.count),
                experts,counts,stagedSlots.map(Int32.init),Int32(stagedSlots.count))==0 else {
                throw ModelError(String(cString:ss_schedule_error()))
            }
            staging=stagedSlots.isEmpty ? nil : try Staging(ticket:ticket,slots:stagedSlots,forecastArena:deferredArena)
            inverse=grouping.inverse;needsBinding=false
        }''')
s=change(s,'            guard !finished else { throw ModelError("Native expert command was already consumed") }','            guard !finished,!needsBinding else { throw ModelError("Native expert command was consumed or is unbound") }')
save('Sources/Slotstream/NativeExpertSchedule.swift',s)
s=(R/'Sources/Slotstream/Layers.swift').read_text()
old='''        if let queue = readbackQueue, !queue.isEmpty {
            let waitStart = RuntimeClock.now()'''
new='''        var preparedEarly: (NativeExpertSchedule.Pending, NativeExpertSchedule.SharedBindings)?
        // Only Q2, and only when the existing routing submission is complete.
        // No work from the deferred queue may be queued behind the gated expert.
        if ProcessInfo.processInfo.environment["SLOTSTREAM_Q2_EARLY_EXPERT"] != "0",
           predicted != nil, readbackQueue?.arrays.isEmpty != false,
           pool.expertStore.isQ2, B == 1, S <= 8, contextNumericsObserver == nil,
           NativeExpertSchedule.enabled, NativeExpertSchedule.gpuStagingEnabled,
           NativeExpertSchedule.earlySubmission, pool.supportsScheduledDemand,
           let gate=sharedGateProj.gguf,let up=sharedUpProj.gguf,let down=sharedDownProj.gguf,
           let shared=NativeExpertSchedule.SharedBindings(gate:gate,up:up,down:down) {
            let plan=try NativeExpertSchedule.plan(hidden:cfg.hiddenSize,intermediate:cfg.moeIntermediate,affine:false,mixedShared:true)
            if let pending=try plan.submitDeferred(x,bindings:pool.scheduledBindings(for:plan),routes:B*S*cfg.topK,
                repeatInput:cfg.topK,forecastArena:pool.lookahead?.prefetch?.nativeForecastArena,shared:shared) {
                preparedEarly=(pending,shared)
            }
        }
        defer { preparedEarly?.0.cancel() }
        if let queue = readbackQueue, !queue.isEmpty {
            let waitStart = RuntimeClock.now()'''
s=change(s,old,new)
s=change(s,'            if pool.expertStore.isQ2, B == 1, S <= 8, contextNumericsObserver == nil,','            if let preparedEarly { mixedShared=preparedEarly.1 }\n            else if pool.expertStore.isQ2, B == 1, S <= 8, contextNumericsObserver == nil,')
s=change(s,'                    mixedShared: mixedShared, mixedWeights: weights, mixedSharedWeight: q2SharedWeight)','                    mixedShared: mixedShared, mixedWeights: weights, mixedSharedWeight: q2SharedWeight, earlyPending: preparedEarly?.0)')
s=change(s,'                        mixedWeights: MLXArray? = nil, mixedSharedWeight: MLXArray? = nil) throws -> MLXArray {','                        mixedWeights: MLXArray? = nil, mixedSharedWeight: MLXArray? = nil,\n                        earlyPending: NativeExpertSchedule.Pending? = nil) throws -> MLXArray {')
s=change(s,'            var pending: NativeExpertSchedule.Pending?\n            defer { pending?.cancel() }','            var pending: NativeExpertSchedule.Pending? = earlyPending\n            defer { pending?.cancel() }')
old='''                pending = try schedule.submit(x, bindings: bindings, ids: slots,'''
new='''                if let earlyPending {
                    let staged=uniq.enumerated().compactMap { self.pool.isResident($0.element) ? nil : slotOf[$0.offset] }
                    try earlyPending.bindDeferred(ids:slots,stagedSlots:staged)
                } else {
                pending = try schedule.submit(x, bindings: bindings, ids: slots,'''
s=change(s,old,new)
s=change(s,'                    forecastArena: self.pool.lookahead?.prefetch?.nativeForecastArena, shared: mixedShared)\n                if awaitingReads','                    forecastArena: self.pool.lookahead?.prefetch?.nativeForecastArena, shared: mixedShared)\n                }\n                if awaitingReads')
save('Sources/Slotstream/Layers.swift',s)
(P/'replacements.json').write_text(json.dumps(rep,indent=2))
(P/'plan.json').write_text(json.dumps(dict(scope='Q2-only early expert preparation while the already-submitted router runs. Late-bind actual routes and staging destinations before the existing host-ready publication. Same arithmetic and actual active tiles; padded inactive tiles return immediately. No threads, polling, power changes or second staging reserve.',hypothesis='Host preparation/submission after route readiness contributes meaningful repeated gaps. Moving independent preparation before the required router wait may hide work without changing reader policy.',memory='Track original Q2 raw staging through actual MLX Data owners. Early maximum-route staging is refused unless it fits the existing110592000-byte staging reserve together with live prior raw staging. Ordinary scheduling is the fallback; Fast never enters the deferred path.',validation='Independent original-byte pool/failure/retry/resize/forecast tests, explicit late-binding/cancel/lifetime/reservation checks,111 full logits/proposals/tokens against frozenv68 underMetalvalidation. Require actual early branch counts. Then fixed ABBA fullcycles; one warmup and two observed rounds, clean15GB4067slots8192context. Advance only for both-direction improvement and at least1percent pooled improvement; then ordinary ABCCBA vs v68 and publishedSplash with quality checks. Preserve every arm and exclusion.',source_revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),sources={n:hashlib.sha256((P/f).read_bytes()).hexdigest()for n,f in rep.items()}),indent=2));print('prepared',len(rep),'inputs')
