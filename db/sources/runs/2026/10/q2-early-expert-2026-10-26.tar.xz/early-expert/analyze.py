from pathlib import Path
import json,statistics
P=Path(__file__).resolve().parent
events=json.loads((P/'timing-fixed-ledger.json').read_text());assert [e['arm']for e in events]==list('ABBA')
means=[statistics.mean(r['cycle_seconds']for r in e['rounds'][1:])for e in events]
directions=[means[1]/means[0],means[2]/means[3]]
ratio=statistics.mean(means[1:3])/statistics.mean([means[0],means[3]])
eligible=all(e['eligible']for e in events)
result=dict(environment_eligible=eligible,cycle_seconds=means,candidate_over_baseline_directions=directions,candidate_over_baseline_pooled=ratio,advance_to_requests=eligible and all(r<1 for r in directions) and ratio<=.99,arms=events,checks=json.loads((P/'checks-result.json').read_text()),validation=json.loads((P/'validation-result.json').read_text()),scope='111 frozen full cycles per round, real proposals, verification and commits; one warmup then two observed rounds. This excludes adaptive-controller, tokenization and streaming behavior, so it is not a completed-request parity claim. All arms retained; any failed environment guard excludes entire protocol.')
(P/'analysis.json').write_text(json.dumps(result,indent=2))
print(json.dumps({k:v for k,v in result.items()if k not in ['arms','checks','validation']},indent=2))
