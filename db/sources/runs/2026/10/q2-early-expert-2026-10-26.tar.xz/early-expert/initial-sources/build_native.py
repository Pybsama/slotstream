from pathlib import Path
import hashlib,json,shutil,sys
P=Path(__file__).resolve().parent;R=P.parents[1];B=R/'.build/native-replay-20261023/v68'
sys.path.insert(0,str(R/'Tools'));from optimization_build import build
rep=json.loads((P/'replacements.json').read_text());old={n:(R/n).read_bytes()if(R/n).exists()else None for n in rep};result={}
try:
    for n,f in rep.items():(R/n).write_bytes((P/f).read_bytes())
    result=build(R,P/'native-build',required_gb=10,jobs=4,wait_seconds=0)
    print(json.dumps({k:v for k,v in result.items()if k in ['passed','error','elapsed_seconds']}),flush=True)
finally:
    for n,b in old.items():
        if b is None:(R/n).unlink(missing_ok=True)
        else:(R/n).write_bytes(b)
    for n in ['slotstream','slotstream-checks','mlx.metallib','build-identity.json','build-source.tar.gz']:shutil.copy2(B/n,R/'.build/release'/n)
    (P/'native-restoration.json').write_text(json.dumps({n:hashlib.sha256((R/n).read_bytes()).hexdigest()if b is not None else 'removed temporary file'for n,b in old.items()},indent=2))
if not result.get('passed'):raise SystemExit(1)
identity=json.loads((P/'native-build/candidate/build-identity.json').read_text())
for n,f in rep.items():assert identity['source'][n]==hashlib.sha256((P/f).read_bytes()).hexdigest()
