from pathlib import Path
import json,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1]
s=(R/'Sources/slotstream-cli/NativeSchedulePoolChecks.swift').read_text()
old='''        var pending: NativeExpertSchedule.Pending?
        defer { pending?.cancel() }
        let slots = try pool.ensureScheduled(keys, staging: { pending?.staging }) { slots, awaitingReads in
            pending = try plan.submit'''
new='''        var pending: NativeExpertSchedule.Pending?
        if mixed, let shared, ProcessInfo.processInfo.environment["SLOTSTREAM_CHECK_DEFERRED"] == "1" {
            pending = try plan.submitDeferred(input, bindings:pool.scheduledBindings(for:plan),
                routes:keys.count, repeatInput:keys.count, forecastArena:pool.lookahead?.prefetch?.nativeForecastArena, shared:shared)
        }
        let early=pending
        defer { pending?.cancel() }
        let slots = try pool.ensureScheduled(keys, staging: { pending?.staging }) { slots, awaitingReads in
            if let early {
                try early.bindDeferred(ids:slots.map(Int32.init),stagedSlots:Array(Set(keys.enumerated().compactMap {
                    pool.isResident($0.element) ? nil : slots[$0.offset]
                })).sorted().reversed())
                return
            }
            pending = try plan.submit'''
assert s.count(old)==1;s=s.replace(old,new)
anchor='    pool.directDemandReads = false\n'
checks='''    if mixed, let shared, ProcessInfo.processInfo.environment["SLOTSTREAM_CHECK_DEFERRED"] == "1" {
        pool.unpinAll();pool.resize(to:80)
        let before=NativeExpertSchedule.deferredStats
        let wide=MLXArray((0..<(8*cfg.hiddenSize)).map{sin(Float($0)*0.013)},[8,cfg.hiddenSize]).asType(.bfloat16)
        eval(wide)
        var held=try plan.submitDeferred(wide,bindings:pool.scheduledBindings(for:plan),routes:80,repeatInput:10,forecastArena:nil,shared:shared)
        guard let held else {throw ValidationError("Maximum deferred reservation was unexpectedly refused")}
        guard try plan.submitDeferred(input,bindings:pool.scheduledBindings(for:plan),routes:1,repeatInput:1,forecastArena:nil,shared:shared)==nil,
              NativeExpertSchedule.deferredStats.3<=110592000 else {throw ValidationError("Deferred staging exceeded its shared reserve")}
        do {_ = try held.value();throw ValidationError("Unbound deferred output was published")}catch is ModelError {}
        held.cancel();held.cancel()
        do {try held.bindDeferred(ids:Array(repeating:0,count:80),stagedSlots:[]);throw ValidationError("Canceled deferred command was rebound")}catch is ModelError {}
        // The canceled ticket deliberately retains its actual backing owners.
        guard NativeExpertSchedule.deferredStats.3>0 else {throw ValidationError("Live backing owners lost their reservation")}
        print("Deferred bounded reservation and unbound cancellation PASS")
    }
'''
# Put the cancellation owner in a separate scope so later tests can acquire the reserve.
checks+='''    if mixed, let shared, ProcessInfo.processInfo.environment["SLOTSTREAM_CHECK_DEFERRED"] == "1" {
        let deadline=Date().addingTimeInterval(2)
        while NativeExpertSchedule.deferredStats.3 != 0 && Date()<deadline {Thread.sleep(forTimeInterval:0.001)}
        guard NativeExpertSchedule.deferredStats.3==0 else {throw ValidationError("Deferred data owner leaked its staging reservation")}
        for count in [1,2,8] {
            let x=MLXArray((0..<(count*cfg.hiddenSize)).map{cos(Float($0)*0.017)},[count,cfg.hiddenSize]).asType(.bfloat16)
            eval(x)
            let keys=(0..<(count*3)).map{ExpertKey(0,($0*7)%13)}
            var pending=try plan.submitDeferred(x+MLXArray(Float(0)).asType(.bfloat16),bindings:pool.scheduledBindings(for:plan),routes:keys.count,repeatInput:3,forecastArena:nil,shared:shared)
            guard let command=pending else {throw ValidationError("Small deferred test refused")}
            defer {command.cancel()}
            do {try command.bindDeferred(ids:Array(repeating:-1,count:keys.count),stagedSlots:[]);throw ValidationError("Invalid route accepted")}catch is ModelError {}
            let slots=try pool.ensureScheduled(keys,staging:{command.staging}) {slots,_ in
                let staged=Array(Set(keys.enumerated().compactMap{pool.isResident($0.element) ? nil : slots[$0.offset]})).sorted()
                if let first=staged.first {
                    do {try command.bindDeferred(ids:slots.map(Int32.init),stagedSlots:[first,first]);throw ValidationError("Duplicate deferred destination accepted")}catch is ModelError {}
                }
                try command.bindDeferred(ids:slots.map(Int32.init),stagedSlots:staged)
            }
            do {try command.bindDeferred(ids:slots.map(Int32.init),stagedSlots:[]);throw ValidationError("Bound command was rebound")}catch is ModelError {}
            let output=try command.value()
            guard let inverse=command.inverse,let actualShared=command.sharedValue,
                  let expectedShared=NativeProjectionSchedule.sharedStaged(x,gate:sharedLinears[0],up:sharedLinears[1],down:sharedLinears[2]) else {throw ValidationError("Deferred output missing")}
            let actual=take(output,MLXArray(inverse),axis:0)
            let expected=NativeExpertTiles.apply(x,weights:pool.pools,ids:slots.map(Int32.init),repeatInput:3,hidden:cfg.hiddenSize,intermediate:cfg.moeIntermediate,affine:false)
            guard (actual .== expected).all().item(Bool.self),(actualShared.reshaped(expectedShared.shape) .== expectedShared).all().item(Bool.self) else {throw ValidationError("Deferred multirow arithmetic differs")}
            let independent=try store.readBatchChecked(keys);eval(independent)
            for piece in independent.indices {guard (pool.pools[piece][MLXArray(slots.map(Int32.init))] .== independent[piece]).all().item(Bool.self) else {throw ValidationError("Deferred original-byte preparation differs")}}
            pool.unpinAll();pending=nil
        }
        let stats=NativeExpertSchedule.deferredStats
        guard stats.0>3,stats.1>0,stats.2>3 else {throw ValidationError("Deferred checks did not cover actual branches")}
        print("Deferred actual branches prepared=\\(stats.0) refused=\\(stats.1) bound=\\(stats.2)")
        print("Deferred invalid bind, duplicate destination, temporary owners, multirow/shared and independent bytes PASS")
    }
'''
assert s.count(anchor)==1;s=s.replace(anchor,checks+anchor)
(P/'NativeSchedulePoolChecks.swift').write_text(s)
p=P/'Q2ProfileCommand.swift';s=p.read_text();anchor='"peak_gb":ProcessMemory.peakResidentGB,"rounds":reports,'
assert s.count(anchor)==1
s=s.replace(anchor,anchor+'"deferred_stats":[NativeExpertSchedule.deferredStats.0,NativeExpertSchedule.deferredStats.1,NativeExpertSchedule.deferredStats.2,NativeExpertSchedule.deferredStats.3],')
p.write_text(s)
rep=json.loads((P/'replacements.json').read_text());rep['Sources/slotstream-cli/NativeSchedulePoolChecks.swift']='NativeSchedulePoolChecks.swift'
(P/'replacements.json').write_text(json.dumps(rep,indent=2))
plan=json.loads((P/'plan.json').read_text());plan['sources']={k:hashlib.sha256((P/v).read_bytes()).hexdigest()for k,v in rep.items()};(P/'plan.json').write_text(json.dumps(plan,indent=2))
