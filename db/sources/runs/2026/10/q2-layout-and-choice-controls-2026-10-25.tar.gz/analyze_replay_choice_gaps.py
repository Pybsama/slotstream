from pathlib import Path
import json, statistics
P=Path(__file__).resolve().parent
label='replay-choice-complete-15'
events=json.loads((P/(label+'-ledger.json')).read_text())
comparison=json.loads((P/(label+'-summary.json')).read_text())
result=dict(scope='Observed long streaming gaps grouped by frozen target width. Each gap includes draft/verify plus preceding reconciliation and host scheduling. This is neither isolated GPU time nor a pure cycle timer. Diagnostic only, with the whole request eligibility retained.',eligible=comparison['causal_timing_eligible'],threshold_seconds=.005,rows=[])
for e in events:
    d=json.loads((P/(e['label']+'.json')).read_text())
    for r in d['runs'][2:]:
        stats=r['stats']; gaps=[x for x in stats['interTokenSeconds']if x>.005]
        assert len(gaps)==stats['verifyPasses']==len(stats['adaptiveDraftDepths']), 'Cannot map gaps to passes'
        for depth in sorted(set(stats['adaptiveDraftDepths'])):
            values=[v for v,k in zip(gaps,stats['adaptiveDraftDepths'])if k==depth]
            result['rows'].append(dict(arm=e['label'],task=r['id'],width=depth+1,count=len(values),median_ms=1000*statistics.median(values),sum_ms=1000*sum(values)))
(P/'replay-choice-stream-gaps.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
