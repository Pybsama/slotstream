from pathlib import Path
import hashlib, io, importlib.util, json, re, subprocess, tarfile
P=Path(__file__).resolve().parent; R=P.parents[1]; OLD=R/'.build/native-replay-20261023/v68'
summary=json.loads((P/'replay-choice-complete-15-summary.json').read_text())
assert len(json.loads((P/'replay-choice-complete-15-ledger.json').read_text()))==4
spec=importlib.util.spec_from_file_location('identity',R/'Tools/build_identity.py'); identity=importlib.util.module_from_spec(spec);spec.loader.exec_module(identity)
expected=json.loads((OLD/'build-identity.json').read_text())['source']
current={str(f.relative_to(R)):identity.sha(f) for f in identity.source_files(R)}
assert expected==current
artifacts={n:identity.sha(R/'.build/release'/n)==identity.sha(OLD/n) for n in ['slotstream','slotstream-checks','mlx.metallib','build-identity.json','build-source.tar.gz']}
assert all(artifacts.values())
(P/'complete-control-restoration.json').write_text(json.dumps(dict(all_runtime_sources_equal_v68=True,count=len(current),artifacts=artifacts,head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),production_changes_retained=False,fast_changed=False),indent=2))
files={f.name:f for pattern in ['padding-only-*','replay-choice-*','complete-control-*','adaptive-copy-control-*','adaptive-cost-diagnosis-*'] for f in P.glob(pattern) if f.is_file() and f.suffix in ['.json','.log','.patch'] and 'archive-receipt' not in f.name}
for name in ['complete_padding_only.py','analyze_padding_only.py','build_replay_choice.py','complete_replay_choice.py','analyze_replay_choice.py','analyze_replay_choice_gaps.py','complete_adaptive_copy_control.py','analyze_adaptive_copy_control.py','archive_complete_controls.py','quiet_guarded_run.py','restored-replay-choice.json','fixed-depth-archive-receipt.json']:
    files[name]=P/name
for f in (P/'replay-choice-src').rglob('*'):
    if f.is_file():files[str(f.relative_to(P))]=f
for name in ['build.txt','manifest.json','candidate/build-identity.json']:
    f=P/'native-replay-choice-build'/name;files[str(f.relative_to(P))]=f
for name,path in [('short-warm-384-cases.json',R/'.build/native-replay-20261023/short-warm-384-cases.json'),('baseline-build-identity.json',OLD/'build-identity.json'),('fixed-depth-build-identity.json',P/'native-fixed-depth-build/candidate/build-identity.json'),('previous-archive-receipt.json',P/'archive-receipt.json')]:
    files['reference/'+name]=path
secret=re.compile(rb'(?:ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{25,}|sk-(?:proj-)?[A-Za-z0-9_-]{30,}|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----)')
for f in files.values():assert f.exists() and not secret.search(f.read_bytes()),f
manifest={n:dict(bytes=f.stat().st_size,sha256=identity.sha(f))for n,f in files.items()}
raw=json.dumps(manifest,indent=2).encode()+b'\n'
dest=R/'db/sources/runs/2026/10/q2-layout-and-choice-controls-2026-10-25.tar.gz';assert not dest.exists()
with tarfile.open(dest,'w:gz')as tar:
    for n,f in sorted(files.items()):tar.add(f,arcname=n,recursive=False)
    info=tarfile.TarInfo('archive-manifest.json');info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
with tarfile.open(dest)as tar:
    for n,m in manifest.items():
        raw=tar.extractfile(n).read();assert len(raw)==m['bytes'] and hashlib.sha256(raw).hexdigest()==m['sha256']
receipt=dict(path=str(dest.relative_to(R)),files=len(manifest),bytes=dest.stat().st_size,sha256=identity.sha(dest),readback_verified=True,credential_pattern_matches=0)
(P/'complete-control-archive-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
