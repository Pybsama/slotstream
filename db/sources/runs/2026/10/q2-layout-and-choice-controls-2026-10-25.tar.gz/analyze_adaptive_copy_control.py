import json, statistics
from pathlib import Path

P = Path(__file__).resolve().parent
import sys
label = sys.argv[1] if len(sys.argv)>1 else 'adaptive-copy-control-15'
events = json.loads((P / (label+'-ledger.json')).read_text())
assert [e['arm'] for e in events] == list('ABBA')
result = dict(eligible=all(e['eligible'] for e in events),
              capacity_note='Normal adaptive complete requests. A and B are the same padded candidate at4062slots. Aoriginalcopies/Baligneddirect.15GBtotalbudget8192context. Normal adaptive choices enabled, fixed/recorded depth overrides absent. No Splash arm; no production adoption.', tasks={})
for task in ['timed-2', 'timed-3']:
    rows = {}
    for arm in 'AB':
        runs = [next(r for r in e['runs'] if r['id'] == task) for e in events if e['arm'] == arm]
        rows[arm] = dict(request_seconds=[r['request_seconds'] for r in runs],
                         tps=[r['tps'] for r in runs],
                         median_request_seconds=statistics.median(r['request_seconds'] for r in runs),
                         median_tps=statistics.median(r['tps'] for r in runs))
    rows['candidate_over_baseline'] = rows['B']['median_request_seconds'] / rows['A']['median_request_seconds']
    rows['pair_candidate_over_baseline'] = [b / old for b, old in zip(rows['B']['request_seconds'], rows['A']['request_seconds'])]
    result['tasks'][task] = rows
result['copy_benefit_gate'] = result['eligible'] and all(t['candidate_over_baseline'] <= .98 and all(p < 1 for p in t['pair_candidate_over_baseline']) for t in result['tasks'].values())
(P / (label+'-summary.json')).write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
