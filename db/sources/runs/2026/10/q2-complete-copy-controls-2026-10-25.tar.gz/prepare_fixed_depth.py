from pathlib import Path
import json, difflib
P=Path(__file__).resolve().parent; R=P.parents[1]
paths=[f for f in json.loads((P/'padded-paths.json').read_text()) if not f.startswith('Sources/slotstream-cli/')]
paths.append('Sources/Slotstream/DFlashGenerate.swift')
sources={f:(P/'padded-src'/f).read_text() for f in paths[:-1]}
f=paths[-1];s=(R/f).read_text()
old='            let chosen = verifyBudget.map { $0.depth(confidence: draft.proposalConfidence) } ?? guesses.count'
assert s.count(old)==1
new='''            let chosen: Int
            if model.pool.expertStore.isQ2, let value = environment["SLOTSTREAM_Q2_DIAGNOSTIC_DEPTH"] {
                guard let fixed = Int(value), (1...7).contains(fixed) else { throw ModelError("Invalid diagnostic fixed depth") }
                chosen = min(fixed, guesses.count)
            } else {
                chosen = verifyBudget.map { $0.depth(confidence: draft.proposalConfidence) } ?? guesses.count
            }'''
sources[f]=s.replace(old,new)
for f,s in sources.items():
 target=P/'fixed-depth-src'/f;target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists();target.write_text(s)
(P/'fixed-depth-paths.json').write_text(json.dumps(paths,indent=2))
(P/'fixed-depth.patch').write_text(''.join(''.join(difflib.unified_diff((R/f).read_text().splitlines(True),s.splitlines(True),fromfile='a/'+f,tofile='b/'+f))for f,s in sources.items()))
build=(P/'build_padded_reads.py').read_text().replace('padded-paths','fixed-depth-paths').replace('padded-src','fixed-depth-src').replace('native-padded-build','native-fixed-depth-build').replace('restored-padded','restored-fixed-depth')
(P/'build_fixed_depth.py').write_text(build)
driver=(P/'complete_padded_requests.py').read_text().replace("default='ABCCBA'", "default='ABBA'")
before=" if arm=='B':\n  at=command.index('--');command[at:at]=['--env','SLOTSTREAM_Q2_ALIGNED_DIRECT=1']"
assert driver.count(before)==1
after=""" assert arm in ('A','B'), 'This diagnostic has native arms only'
 at=command.index('--');command[at:at]=['--env','SLOTSTREAM_Q2_DIAGNOSTIC_DEPTH=3']
 if arm=='B':
  at=command.index('--');command[at:at]=['--env','SLOTSTREAM_Q2_ALIGNED_DIRECT=1']"""
driver=driver.replace(before,after)
marker="   if a.model=='smart-q2':\n    assert all((r['stats'].get('dflashCalibrationCyclesBefore')or 0)>0 for r in d['runs'][1:])"
assert driver.count(marker)==1
driver=driver.replace(marker,"   assert all(all(0<=x<=3 for x in r['stats']['adaptiveDraftDepths']) and r['stats']['adaptiveDraftDepths'].count(3)>=len(r['stats']['adaptiveDraftDepths'])-2 for r in d['runs']), 'Chosen widths not frozen'\n"+marker)
(P/'complete_fixed_depth.py').write_text(driver)
plan=dict(parent='next-fixed-depth-control-plan.json',candidate='native-fixed-depth-build',
          exact_scope='Same combined padded binary, diagnostic depth3 in both arms. A uses original scratch/copy, B aligned direct demand+forecast. Production CLI otherwise unchanged.4062slots15GB, ABBA, two384tokenwarmups+code/prose. Complete generation, no per-pass full-logit readback. No Splash comparison or production qualification inferred.',
          required='All prompt/output tokens, text/stream and work counts must agree across all four arms before attributing timing to copies. All arms clean; report every value, median and both orders. No adaptive result is replaced by this diagnostic.')
(P/'fixed-depth-plan.json').write_text(json.dumps(plan,indent=2))
