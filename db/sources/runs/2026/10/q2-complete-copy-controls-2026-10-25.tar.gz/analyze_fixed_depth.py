from pathlib import Path
import json, statistics, sys
P=Path(__file__).resolve().parent
label=sys.argv[1]if len(sys.argv)>1 else 'fixed-depth-complete-15'
events=json.loads((P/(label+'-ledger.json')).read_text())
assert [e['arm']for e in events]==list('ABBA')
data={e['label']:json.loads((P/(e['label']+'.json')).read_text()) for e in events}
reference=data[events[0]['label']]['runs']
checks=[]
for e in events:
    d=data[e['label']]
    for old,row in zip(reference,d['runs']):
        exact={k:old[k]==row[k] for k in ['id','prompt_ids','tokens','text','streamed','tool_calls','malformed_tool_call']}
        work={k:old['stats'][k]==row['stats'][k] for k in ['verifyPasses','draftedTokens','acceptedDrafts','decodeModelTokens','adaptiveDraftDepths']}
        work['logical_repacked_records']=old['stats']['nativeExecution']['gpuRepackedRecords']==row['stats']['nativeExecution']['gpuRepackedRecords']
        checks.append(dict(arm=e['label'],task=row['id'],exact=exact,work=work))
binary_hashes={e['label']:json.loads((P/(e['label']+'-guard.observer.json')).read_text())['binary_sha256']for e in events}
result=dict(clean=all(e['eligible']for e in events),
            same_binary=len(set(binary_hashes.values()))==1, binary_hashes=binary_hashes,
            slots=[e['actual_cache_slots']for e in events],checks=checks,tasks={},
            scope='Diagnostic complete native generation at fixed chosen depth3. A/B are the same padded binary, copy versus aligned direct demand+forecast. No per-pass full-logit readback. Does not replace ordinary adaptive results or establish Splash parity.')
result['identical_output']=all(all(c['exact'].values())for c in checks)
result['identical_core_work']=all(all(c['work'].values())for c in checks)
for task in ['timed-2','timed-3']:
    arms={}
    for arm in 'AB':
        rows=[next(r for r in e['runs']if r['id']==task)for e in events if e['arm']==arm]
        arms[arm]=dict(seconds=[r['request_seconds']for r in rows],median_seconds=statistics.median(r['request_seconds']for r in rows),tps=[r['tps']for r in rows])
    arms['direct_over_copy']=arms['B']['median_seconds']/arms['A']['median_seconds']
    arms['pair_ratios']=[b/a for a,b in zip(arms['A']['seconds'],arms['B']['seconds'])]
    result['tasks'][task]=arms
result['causal_timing_eligible']=result['clean']and result['same_binary']and result['identical_output']and result['identical_core_work']and set(result['slots'])=={4062}
(P/(label+'-summary.json')).write_text(json.dumps(result,indent=2))
print(json.dumps({k:v for k,v in result.items()if k!='checks'},indent=2))
