from pathlib import Path
import json,sys,shutil,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1];OLD=R/'.build/native-replay-20261023/v68'
sys.path.insert(0,str(R/'Tools'));from optimization_build import build
paths=json.loads((P/'fixed-depth-paths.json').read_text());original={f:(R/f).read_bytes()for f in paths}
try:
 for f in paths:(R/f).write_bytes((P/'fixed-depth-src'/f).read_bytes())
 result=build(R,P/'native-fixed-depth-build',required_gb=10,jobs=4,wait_seconds=600)
 print(json.dumps({k:v for k,v in result.items()if k in ['passed','error','elapsed_seconds']}),flush=True)
finally:
 for f,b in original.items():(R/f).write_bytes(b)
 for name in ['slotstream','slotstream-checks','mlx.metallib','build-identity.json','build-source.tar.gz']:shutil.copy2(OLD/name,R/'.build/release'/name)
 (P/'restored-fixed-depth.json').write_text(json.dumps(dict(sources={f:hashlib.sha256((R/f).read_bytes()).hexdigest()for f in paths},baseline_sha256=hashlib.sha256((R/'.build/release/slotstream').read_bytes()).hexdigest()),indent=2))
if not result['passed']:raise SystemExit(1)
