from pathlib import Path
import json
P=Path(__file__).resolve().parent;S=P.parent/'q2-sequence-20261025';results=[]
for arm,name,reference in [('N','validation-0-N','frequency-untraced-0-N.json'),('S','validation-1-S','frequency-untraced-1-S.json')]:
 d=json.loads((P/(name+'.json')).read_text());rows=[r for rd in d['rounds']for r in rd['steps']];ref={r['step']:r for r in json.loads((S/reference).read_text())['runs']if r['round']==0}
 assert len(ref)==len(rows)==111
 mismatch=[r['step']for r in rows if r['logits_sha256']!=ref[r['step']]['logits_sha256']]
 selected_mismatch=[r['step']for r in rows if r['actual_selected']!=ref[r['step']]['top1'][:r['kept']]]
 guard=json.loads((P/(name+'.observer.json')).read_text())
 results.append(dict(engine=arm,steps=len(rows),hash_mismatches=mismatch,greedy_mismatches=selected_mismatch,reference=reference,real_proposals=sum(len(r['actual_guesses'])for r in rows),forecast_adoptions=sum(r['records_adopted']for r in rows),peak_gb=guard['peak_combined_bytes']/1e9,paging=guard['paging'],metal_validation=True,exit_code=guard['exit_code']))
report=dict(passed=all(not r['hash_mismatches']and not r['greedy_mismatches']and r['exit_code']==0 for r in results),engines=results,scope='Each engine matches its own full-logit and greedy-ID reference for111 fixed target passes with real draft proposals and commits. Cross-engine arithmetic is not bit-identical; this checks the diagnostic did not change target math. Timing mode omits full-logit readback.')
(P/'validation-result.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));assert report['passed']
