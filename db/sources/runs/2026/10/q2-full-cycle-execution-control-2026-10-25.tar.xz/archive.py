from pathlib import Path
import hashlib,io,json,re,tarfile
P=Path(__file__).resolve().parent;R=P.parents[1];sha=lambda b:hashlib.sha256(b).hexdigest()
files={}
for f in P.rglob('*'):
 if not f.is_file()or'__pycache__'in f.parts or f.name in ['archive-receipt.json','objects.txt','validation-splash-sample.txt']:continue
 if f.suffix not in ['.py','.swift','.cpp','.mm','.hpp','.h','.json','.jsonl','.csv','.log','.stderr','.txt']:continue
 files[str(f.relative_to(P))]=f
S=R/'.build/q2-sequence-20261025'
for n in ['frequency-untraced-0-N.json','frequency-untraced-1-S.json','copy_observer.cpp','named_stage_observer.mm']:
 files['reference/'+n]=S/n
files['reference/read_observer.cpp']=R/'.build/q2-handoff-20261025/read_observer.cpp'
files['reference/v68-build-identity.json']=R/'.build/native-replay-20261023/v68/build-identity.json'
W=Path('/var/folders/d4/t1c8ltbx5s3_11cs9y6gjh8m0000gp/T/slotstream-splash-host-ugnf26pi/source')
files['upstream/LICENSE']=W/'LICENSE';files['baseline/LICENSE']=R/'LICENSE'
for n in ['Layers.swift','NativeExpertSchedule.swift','DFlashGenerate.swift']:
 files['baseline/'+n]=R/'Sources/Slotstream'/n
secret=re.compile(rb'(?:ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{25,}|sk-(?:proj-)?[A-Za-z0-9_-]{30,}|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----)');manifest={}
for n,f in files.items():
 b=f.read_bytes();assert not secret.search(b),n;manifest[n]=dict(bytes=len(b),sha256=sha(b))
dest=R/'db/sources/runs/2026/10/q2-full-cycle-execution-control-2026-10-25.tar.xz';assert not dest.exists();raw=json.dumps(manifest,indent=2).encode()
with tarfile.open(dest,'w:xz',preset=3)as t:
 for n,f in sorted(files.items()):t.add(f,arcname=n,recursive=False)
 info=tarfile.TarInfo('archive-manifest.json');info.size=len(raw);t.addfile(info,io.BytesIO(raw))
seen={}
with tarfile.open(dest,'r|xz')as t:
 for m in t:
  b=t.extractfile(m).read()
  if m.name=='archive-manifest.json':assert json.loads(b)==manifest
  else:seen[m.name]=dict(bytes=len(b),sha256=sha(b))
assert seen==manifest
receipt=dict(path=str(dest.relative_to(R)),files=len(manifest),bytes=dest.stat().st_size,sha256=sha(dest.read_bytes()),readback_verified=True,credential_pattern_matches=0,excluded='Executables, libraries, weights and duplicate full-source archives. Exact sources and identities retained. Compiler sample reduced to relevant main-thread frames; full system image inventory omitted. Original diagnostic readout failure, corrected source and all validation/timing/trace arms retained.')
(P/'archive-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt,indent=2))
