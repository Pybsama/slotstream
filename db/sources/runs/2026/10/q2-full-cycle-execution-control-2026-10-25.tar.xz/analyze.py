from pathlib import Path
import collections,datetime,json,statistics
P=Path(__file__).resolve().parent
ledger=json.loads((P/'timing-ledger.json').read_text());report=[]
for event in ledger:
 label,arm=event['label'],event['arm'];data=json.loads((P/(label+'.json')).read_text());guard=json.loads((P/(label+'.observer.json')).read_text());rounds=[]
 offsets=[x['unix']-x['mach_ns']/1e9 for x in guard['samples']];offset=statistics.median(offsets)
 raw=[json.loads(line)for line in(P/(label+'-frequency.jsonl')).read_text().splitlines()];ticks=[datetime.datetime.fromisoformat(x['timestamp']).timestamp()-offset for x in raw]
 delta=statistics.median(b-a for a,b in zip(ticks,ticks[1:]));assert .15<delta<.5,(label,delta)
 samples=[(ticks[i-1]if i else t-delta,t,x)for i,(t,x)in enumerate(zip(ticks,raw))]
 for rd in data['rounds']:
  rows=rd['steps'];windows=[(r['start_ns']/1e9,r['end_ns']/1e9)if'start_ns'in r else(r['start'],r['end'])for r in rows]
  sums=collections.defaultdict(float);covered=0
  for b,e,x in samples:
   overlap=sum(max(0,min(hi,e)-max(lo,b))for lo,hi in windows)
   covered+=overlap
   for key in ['gpu_freq_mhz','gpu_active_ratio','gpu_scaled_ratio','gpu_power','gpu_ram_power']:sums[key]+=overlap*x[key]
  length=sum(hi-lo for lo,hi in windows);assert abs(covered-length)<.01,(label,covered,length)
  r=dict(round=rd['round'],wall_seconds=rd['seconds'],cycle_seconds=length,frequency={k:v/covered for k,v in sums.items()},demand=sum(r['records_fetched']for r in rows),adopted=sum(r['records_adopted']for r in rows),passes=len(rows),rows=sum(r['width']for r in rows),kept=sum(r['kept']for r in rows))
  if arm=='N':
   r['phase_seconds']={k:sum(x[k]for x in rows)for k in ['draft_seconds','verify_seconds','sample_seconds','commit_seconds']}
  else:
   r['phase_seconds']=dict(prepare=sum(x['prepared']-x['start']for x in rows),submit=sum(x['submitted']-x['prepared']for x in rows),after_submit=sum(x['end']-x['submitted']for x in rows),gpu_reported=sum(x['gpu_seconds']for x in rows),host_reported=sum(x['host_seconds']for x in rows))
  rounds.append(r)
 # No full-logit readback in timings; actual sampled IDs checked against validated round.
 validation=json.loads((P/('validation-0-N.json'if arm=='N'else'validation-s-0-S.json')).read_text())['rounds'][0]['steps']
 selected_diffs=[(rd['round'],r['step'])for rd in data['rounds']for r in rd['steps']if r['actual_selected']!=validation[r['step']]['actual_selected']]
 guesses_diffs=[(rd['round'],r['step'])for rd in data['rounds']for r in rd['steps']if r['actual_guesses']!=validation[r['step']]['actual_guesses']]
 report.append(dict(label=label,arm=arm,eligible=event['eligible'],selected_differences=selected_diffs,proposal_differences=guesses_diffs,peak_gb=guard['peak_combined_bytes']/1e9,paging=guard['paging'],clock_offset_range_seconds=max(offsets)-min(offsets),rounds=rounds))
summary={arm:{k:statistics.median(r[k]for e in report if e['arm']==arm for r in e['rounds']if r['round']>0)for k in ['wall_seconds','cycle_seconds','demand','adopted']}for arm in ['N','S']}
ratio=summary['N']['wall_seconds']/summary['S']['wall_seconds']
result=dict(scope='Frozen full-cycle diagnostic, not ordinary complete requests. Same inputs, widths, accepted prefixes, real7tokenproposals. Each backend retains its target arithmetic and cache evolution, so routed expert work may differ. Native phase times are sequential, while Splash reported GPU/host time overlap and cannot be added. One warmup then2timedrounds perarm. No timed full-logit readback.',eligible=len(report)==4 and all(e['eligible']and not e['selected_differences']for e in report),arms=report,median=summary,native_over_splash=ratio)
(P/'analysis.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items()if k!='arms'},indent=2))
for e in report:print(e['label'],'selected_diffs',len(e['selected_differences']),'draft_diffs',len(e['proposal_differences']),[(r['round'],round(r['wall_seconds'],3),round(r['frequency']['gpu_freq_mhz']))for r in e['rounds']])
