from pathlib import Path
import json,sys,shutil,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1];OLD=R/'.build/native-replay-20261023/v68'
sys.path.insert(0,str(R/'Tools'));from optimization_build import build
source=R/'Sources/slotstream-cli/Q2ProfileCommand.swift';original=source.read_bytes()
try:
 source.write_bytes((P/'Q2ProfileCommand.swift').read_bytes())
 result=build(R,P/'native-build',required_gb=10,jobs=4,wait_seconds=600)
 print(json.dumps({k:v for k,v in result.items()if k in ['passed','error','elapsed_seconds']}),flush=True)
finally:
 source.write_bytes(original)
 for name in ['slotstream','slotstream-checks','mlx.metallib','build-identity.json','build-source.tar.gz']:
  shutil.copy2(OLD/name,R/'.build/release'/name)
 (P/'restored.json').write_text(json.dumps(dict(source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),baseline_sha256=hashlib.sha256((R/'.build/release/slotstream').read_bytes()).hexdigest()),indent=2))
if not result['passed']:raise SystemExit(1)
