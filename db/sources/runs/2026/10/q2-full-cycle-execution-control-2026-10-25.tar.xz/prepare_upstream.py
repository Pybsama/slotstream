from pathlib import Path
import subprocess,hashlib,json
P=Path(__file__).resolve().parent;R=P.parents[1];D=P/'upstream';W=Path('/var/folders/d4/t1c8ltbx5s3_11cs9y6gjh8m0000gp/T/slotstream-splash-host-ugnf26pi/source')
def original(name):return subprocess.check_output(['git','show','HEAD:'+name],cwd=W).decode()
r=original('runtime/model/Runtime.cpp');h=original('runtime/model/RuntimeInstrumentation.hpp')
h=h.replace('public:\n','''public:
  struct FixedCycle { double start, prepared, submitted, ended, gpu, host; std::vector<uint32_t> guesses, selected; };
  static FixedCycle fixedCycle(Runtime &runtime, const ModelBatchItem &item, std::span<const uint32_t> tokens, uint32_t retained);
''',1)
(D/'include/model/RuntimeInstrumentation.hpp').write_text(h)
r='#include "ops/RowCopy.hpp"\n'+r
helper=r'''
#ifdef SPLASH_RUNTIME_INSTRUMENTATION
RuntimeInstrumentation::FixedCycle RuntimeInstrumentation::fixedCycle(Runtime &runtime,
    const ModelBatchItem &item, std::span<const uint32_t> tokens, uint32_t retained) {
  if(tokens.empty()||tokens.size()>8||!retained||retained>tokens.size())throw std::invalid_argument("invalid fixed cycle");
  auto now=[] {return double(AwakeClock::now().time_since_epoch().count())/1e9;};
  FixedCycle out{};out.start=now();auto &impl=*runtime.impl_;auto &entry=impl.request(item.requestId);
  entry.pendingToken=tokens.front();impl.prepareDecodeLane(entry,item,0);
  auto d=[&](DecodeTensor t){return impl.decodeArena->batchSlice(t,1);};
  auto fixed=impl.backend.allocateBuffer(36,metal::BufferStorage::Shared,"frozen cycle control");
  auto guesses=impl.backend.allocateBuffer(28,metal::BufferStorage::Shared,"real proposal evidence");
  auto *words=contents<uint32_t>(fixed,"frozen constants");std::fill_n(words,9,0);
  std::copy(tokens.begin()+1,tokens.end(),words);words[7]=tokens.size();words[8]=retained;
  Runtime::Impl::Request *request=&entry;std::span<Runtime::Impl::Request *const> entries(&request,1);
  std::span<const ModelBatchItem> items(&item,1);const uint64_t position=item.logicalPosition;const uint32_t maximum=8;
  auto reads=impl.decodeReads(items);CommandGraph graph;
  impl.addRopeTables(graph,d(DecodeTensor::Positions),8,d(DecodeTensor::DraftPositions),8,
      d(DecodeTensor::RopeCos),d(DecodeTensor::RopeSin),d(DecodeTensor::DraftRopeCos),d(DecodeTensor::DraftRopeSin));
  impl.encodeBatchEmbedding(graph,DecodeTensor::DraftInputTokens,DecodeTensor::DraftHidden0,1);
  impl.encodeDraftBatchGraph(graph,entries,{&position,1},{&maximum,1},false);
  // Small existing GPU copies impose the frozen decisions without adding a
  // host wait between draft and target. Validate their exact integer bits.
  ops::RowCopy::add(graph,d(DecodeTensor::ProposedTokens),{0,14,0},guesses,{0,14,0},1,14);
  ops::RowCopy::add(graph,fixed,{0,18,0},d(DecodeTensor::ProposedTokens),{0,14,0},1,14);
  ops::RowCopy::add(graph,fixed,{0,18,14},d(DecodeTensor::VerifyRows),{0,2,0},1,2);
  impl.encodeBatchVerifyInput(graph,1);
  impl.encodeBatchEmbedding(graph,DecodeTensor::InputTokens,DecodeTensor::Hidden0,1);
  impl.encodeTargetVerifyBatchForward(graph,entries,items,*reads);
  impl.encodeTargetVerifyBatchPolicy(graph,entries);
  impl.encodeBatchAcceptance(graph,entries,{&maximum,1});
  ops::RowCopy::add(graph,fixed,{0,18,16},d(DecodeTensor::RetainedCount),{0,2,0},1,2);
  impl.encodeTargetStateCommit(graph,entries);
  impl.encodeDraftStateCommitBatch(graph,entries,items);
  out.prepared=now();auto ticket=impl.backend.submitCommandAsync(graph.command());out.submitted=now();
  auto timing=ticket.wait();reads->end();
  if(*contents<uint32_t>(d(DecodeTensor::VerifyRows),"rows")!=tokens.size()||
     *contents<uint32_t>(d(DecodeTensor::RetainedCount),"kept")!=retained||
     !std::equal(tokens.begin(),tokens.end(),contents<uint32_t>(d(DecodeTensor::InputTokens),"target input")))
    throw std::runtime_error("frozen GPU control changed integer bits");
  impl.states.swapDecodeParity(entry.stateLane,retained);const auto nextLength=item.logicalPosition+retained;
  impl.states.updateLengths(entry.stateLane,
      impl.advanceDraftContext(impl.states.metadata(entry.stateLane).lengths,nextLength,item.logicalPosition,nextLength,false,false));
  entry.tokens.insert(entry.tokens.end(),tokens.begin(),tokens.begin()+retained);
  out.ended=now();out.gpu=timing.gpuSeconds;out.host=timing.hostSeconds;
  auto *draft=contents<uint32_t>(guesses,"actual proposals");out.guesses.assign(draft,draft+7);
  auto *selected=contents<uint32_t>(d(DecodeTensor::OutputTokens),"actual greedy decisions");out.selected.assign(selected,selected+retained);
  return out;
}
#endif
'''
marker='} // namespace splash::model';assert r.endswith(marker+'\n');r=r[:-len(marker+'\n')]+helper+marker+'\n';(D/'Runtime.cpp').write_text(r)
(D/'MetalBackend.mm').write_text(original('runtime/metal/MetalBackend.mm'))
m=(R/'.build/q2-sequence-20261025/upstream/fixed_verify.mm').read_text()
m=m.replace('      store->diagnosticReadAhead(std::getenv("Q2_SEQUENCE_AHEAD") == nullptr || std::string(std::getenv("Q2_SEQUENCE_AHEAD"))!="0");','')
a=m.index('      for(uint32_t round=0;round<cycles;++round) {');b=m.index('      return 0;',a)
m=m[:a]+r'''
      const bool validate=std::getenv("Q2_CYCLE_VALIDATE")!=nullptr;
      for(uint32_t round=0;round<cycles;++round) {
        prefill(executor,lanes[0],prompt);
        uint32_t step=0;std::ostringstream output;
        const auto roundStart=std::chrono::steady_clock::now();
        for(NSDictionary *row in fixture[@"steps"]) {
          tokens.clear();for(NSNumber *n in row[@"tokens"])tokens.push_back(n.unsignedIntValue);
          const uint32_t retained=[row[@"kept"] unsignedIntValue];
          if(lanes[0].position!=[row[@"position"] unsignedLongLongValue])throw std::runtime_error("frozen position mismatch");
          ModelBatchItem item{lanes[0].id,lanes[0].position,0,lanes[0].pages,lanes[0].pageTableRevision};
          const auto before=store->stats().uses[1];
          const auto timing=model::RuntimeInstrumentation::fixedCycle(executor,item,tokens,retained);
          const auto after=store->stats().uses[1];
          output<<std::setprecision(12)<<"ROW "<<round<<' '<<step<<' '<<tokens.size()<<' '<<retained<<' '
            <<timing.start<<' '<<timing.prepared<<' '<<timing.submitted<<' '<<timing.ended<<' '<<timing.gpu<<' '<<timing.host<<' '
            <<after.read-before.read<<' '<<after.prefetched-before.prefetched<<' '<<after.readBytes-before.readBytes<<' '
            <<after.loads-before.loads;
          if(validate) {
            const auto logits=model::RuntimeInstrumentation::lastLogits(executor,0).first(tokens.size()*248320);
            unsigned char digest[CC_SHA256_DIGEST_LENGTH];CC_SHA256(logits.data(),CC_LONG(logits.size_bytes()),digest);
            char hex[3];output<<' ';for(auto b:digest){snprintf(hex,sizeof(hex),"%02x",b);output<<hex;}
          }
          output<<'\n'<<"DRAFT "<<round<<' '<<step;for(auto t:timing.guesses)output<<' '<<t;
          output<<'\n'<<"SELECTED "<<round<<' '<<step;for(auto t:timing.selected)output<<' '<<t;output<<'\n';
          lanes[0].position+=retained;++step;
        }
        const double wall=std::chrono::duration<double>(std::chrono::steady_clock::now()-roundStart).count();
        executor.end(lanes[0].id);std::cout<<output.str()<<"ROUND "<<round<<' '<<std::setprecision(12)<<wall<<std::endl;
      }
''' +m[b:]
m='#include <sstream>\n#include <iomanip>\n'+m;(D/'full_cycle.mm').write_text(m)
(P/'upstream-source.json').write_text(json.dumps(dict(commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip(),tree_changes=subprocess.check_output(['git','status','--short'],cwd=W,text=True),backend_from_git=True,notes='Fresh original backend retains published CPU polling; no GPU spin library. Original static library supplies unchanged modules; Runtime replaced by one isolated instrumentation helper. No per-read observer or expert-store diagnostic code.'),indent=2))
print('prepared isolated upstream full-cycle control')
