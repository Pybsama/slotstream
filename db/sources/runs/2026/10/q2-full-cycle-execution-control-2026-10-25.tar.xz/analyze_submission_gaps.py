from pathlib import Path
import bisect,collections,csv,json
P=Path(__file__).resolve().parent
exec((P/'analyze_readiness.py').read_text().split('results=[];details=[]')[0],globals())
readiness={x['label']:x for x in json.loads((P/'readiness-detail.json').read_text())if x['id']=='steps-0-through110'}
report=[]
for e in json.loads((P/'trace-ledger.json').read_text()):
 label=e['label'];cp=next(p for p in P.glob(label+'-commands.*.csv')if not any(n in p.name for n in ['events','stages','assignments','pipelines']))
 cc=rows(cp);ss=rows(P/(cp.stem+'.stages.csv'));bybuf=collections.defaultdict(list)
 for c in cc:c['submitted']=float(c['submitted']);bybuf[c['buffer']].append(c)
 for vv in bybuf.values():vv.sort(key=lambda c:c['submitted'])
 times={b:[c['submitted']for c in v]for b,v in bybuf.items()}
 valid=[];bad=0
 for s in ss:
  start,end=int(s['gpu_start'])/1e9,int(s['gpu_end'])/1e9
  if not end>start>0:bad+=1;continue
  i=bisect.bisect_left(times[s['buffer']],float(s['encoded']));s.update(start=start,end=end,submitted=bybuf[s['buffer']][i]['submitted']);valid.append(s)
 valid.sort(key=lambda s:s['start']);spans=[];edge=0
 for s in valid:
  if s['start']>edge:spans.append(dict(start=edge,end=s['start'],submitted=s['submitted'],encoder=s['encoder']))
  edge=max(edge,s['end'])
 d=json.loads((P/(label+'.json')).read_text());per=[]
 rr=rows(next(P.glob(label+'-reads.*.csv')));reads=union((float(x['start']),float(x['end']))for x in rr if int(x['result'])>0)
 phases=collections.defaultdict(list)
 for r in d['rounds'][0]['steps']:
  lo,hi=(r['start_ns']/1e9,r['end_ns']/1e9)if e['arm']=='N'else(r['start'],r['end']);window=[[lo,hi]]
  gaps=inter(union((s['start'],s['end'])for s in spans),window)
  before=inter(union((s['start'],min(s['end'],s['submitted']))for s in spans),window)
  matched=readiness[label]['matches'];known=inter(union(m[k]for m in matched for k in ['unready','setter','ready']),window)
  per.append(dict(step=r['step'],width=r['width'],seconds=hi-lo,gpu_gap_seconds=length(gaps),before_submit_seconds=length(before),before_submit_with_reads=length(inter(before,reads)),known_readiness_seconds=length(known),gap_not_known_readiness_seconds=length(gaps)-length(inter(gaps,known))))
  if e['arm']=='N':
   a=lo
   for k in ['draft_seconds','verify_seconds','sample_seconds','commit_seconds']:
    b=a+r[k];phases[k].append(dict(gap=length(inter(gaps,[[a,b]])),before_submit=length(inter(before,[[a,b]])),known_readiness=length(inter(known,[[a,b]]))));a=b
 result=dict(label=label,missing_stage_timestamps=bad,summary={k:sum(r[k]for r in per)for k in per[0]if k not in ['step','width']},phases={k:{v:sum(x[v]for x in xs)for v in xs[0]}for k,xs in phases.items()},passes=per)
 report.append(result);print(json.dumps({k:v for k,v in result.items()if k!='passes'},indent=2))
(P/'submission-gaps.json').write_text(json.dumps(dict(scope='Gaps between measured GPU encoder intervals, clipped to full-cycle windows. Before-submit portion ends at observed commit call of following encoder command. This is unsubmitted next work, not proof CPU is running or that hardware could begin immediately. Missing encoder timestamps can overstate gaps. Readiness intervals remain overlapping classifications, never added to before-submit. Native phases use recorded timestamps; no equivalent split inside Splash combined graph.',arms=report),indent=2))
