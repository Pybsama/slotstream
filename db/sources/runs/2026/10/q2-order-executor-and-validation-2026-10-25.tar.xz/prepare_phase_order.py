from pathlib import Path
P=Path(__file__).resolve().parent
s=(P/'Q2ProfileCommand-frequency-cache.swift').read_text()
old='''                var rows: [[String: Any]] = [], reference: String?
                for ahead in [false,true] {'''
new='''                // Seed the fixed routed keys before either condition order.
                // This is one ordinary verification, outside the measured phases.
                state.setRecording(true)
                eval(try model.allLogitsWithMultiChecked(ids,state:state).logits)
                try state.restoreChecked(checkpoint)
                model.pool.unpinAll()
                let orderValue=ProcessInfo.processInfo.environment["Q2_REVERSE_PHASES"] ?? "0"
                guard orderValue == "0" || orderValue == "1" else {throw ModelError("Invalid diagnostic order")}
                let reverse=orderValue == "1"
                let aheadOrder=reverse ? [true,false] : [false,true]
                let cacheOrder=reverse ? ["partial","cached"] : ["cached","partial"]
                var rows: [[String: Any]] = [], reference: String?
                for ahead in aheadOrder {'''
assert old in s;s=s.replace(old,new).replace('for cache in ["cached","partial"] {','for cache in cacheOrder {')
s=s.replace('"trace_reads":traceReads,"evictions":drops,','"trace_reads":traceReads,"evictions":drops,"reverse_phases":reverse,')
(P/'Q2ProfileCommand-phase-order.swift').write_text(s)
u=(P/'frequency-cache-upstream.mm').read_text()
old='''      std::vector<float> reference;
      for(bool ahead: {false,true}) {'''
new='''      store->diagnosticReadAhead(false);
      (void)model::RuntimeInstrumentation::fixedVerify(executor,item,tokens);
      const char *orderValue=std::getenv("Q2_REVERSE_PHASES");
      if(orderValue && std::string(orderValue)!="0" && std::string(orderValue)!="1")throw std::runtime_error("invalid diagnostic order");
      const bool reverse=orderValue && std::string(orderValue)=="1";
      const std::array<bool,2> aheadOrder=reverse?std::array<bool,2>{true,false}:std::array<bool,2>{false,true};
      const std::array<const char*,2> cacheOrder=reverse?std::array<const char*,2>{"partial","cached"}:std::array<const char*,2>{"cached","partial"};
      std::vector<float> reference;
      for(bool ahead: aheadOrder) {'''
assert old in u;u=u.replace(old,new).replace('for(const char *cache: {"cached","partial"}) {','for(const char *cache: cacheOrder) {')
(P/'phase-order-upstream.mm').write_text(u)
b=(P/'build_frequency_cache.py').read_text().replace('Q2ProfileCommand-frequency-cache.swift','Q2ProfileCommand-phase-order.swift').replace('native-frequency-cache-build','native-phase-order-build').replace('restored-frequency-cache.json','restored-phase-order.json')
(P/'build_phase_order.py').write_text(b)
b=(P/'build_frequency_cache_upstream.py').read_text().replace('frequency-cache','phase-order');(P/'build_phase_order_upstream.py').write_text(b)
r=(P/'run_frequency_cache.py').read_text().replace('frequency-cache','phase-order')
r=r.replace("  if arm=='N':\n   cmd=", "  reverse=index>=2\n  env+=['--env','Q2_REVERSE_PHASES='+('1' if reverse else '0')]\n  if arm=='N':\n   cmd=")
r=r.replace("row=dict(label=label,arm=arm,width=width,", "row=dict(label=label,arm=arm,width=width,reverse_phases=reverse,")
r=r.replace("scope='Cached/partial by ahead off/on frozen-pass diagnostic. Same common 393 missing keys and prefilled recurrent state, not complete generation. No power or priority intervention.'", "scope='Order control: N forward, S forward, S reverse, N reverse. One unmeasured no-ahead pass seeds routed keys before each process; then two warmups and64measured percondition. Same393keys, capacity, precision and fixed input. Not complete generation. No power or priority intervention.'")
(P/'run_phase_order.py').write_text(r)
for name in ['build_phase_order.py','build_phase_order_upstream.py','run_phase_order.py']:compile((P/name).read_text(),name,'exec')
a=(P/'analyze_frequency_cache.py').read_text().replace("default='frequency-cache'","default='phase-order'")
(P/'analyze_phase_order.py').write_text(a)
a=(P/'analyze_frequency_cache_details.py').read_text().replace('frequency-cache','phase-order').replace("Fixed condition order is a confound: cached_off, partial_off, cached_on, partial_on.","Conditions run forward in N0/S1 and reverse in S2/N3, after an identical seed pass within each engine. One process per engine/order, not a broad sustained-load qualification.")
(P/'analyze_phase_order_details.py').write_text(a)
print('Prepared bounded forward/reverse controls, production unchanged')
