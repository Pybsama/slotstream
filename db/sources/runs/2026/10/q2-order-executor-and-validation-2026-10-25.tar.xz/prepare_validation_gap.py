from pathlib import Path
P=Path(__file__).resolve().parent
s=(P/'Q2ProfileCommand-phase-order.swift').read_text()
s=s.replace('                var rows: [[String: Any]] = [], reference: String?', '''                let deferValue=ProcessInfo.processInfo.environment["Q2_DEFER_VALIDATION"] ?? "0"
                guard ["0","1"].contains(deferValue) else {throw ModelError("Invalid validation diagnostic")}
                let deferValidation=deferValue == "1"
                var rows: [[String: Any]] = [], reference: String?
                func validate(_ logits: MLXArray, condition: String, round: Int) throws -> String {
                    let raw=logits.asType(.float32).asArray(Float.self).withUnsafeBytes { Data($0) }
                    let hash=SHA256.hash(data:raw).map{String(format:"%02x",$0)}.joined()
                    if let reference {guard hash == reference else {throw ModelError("Fixed input/state/cache changed logits")}}
                    else {reference=hash}
                    if round == 2 {try raw.write(to: URL(fileURLWithPath: output+"-"+condition+".f32"))}
                    return hash
                }''')
s=s.replace('                    for round in 0..<66 {','''                    let phaseFirstRow=rows.count
                    var deferredLogits: [MLXArray] = []
                    deferredLogits.reserveCapacity(66)
                    for round in 0..<66 {''')
first=s.index('                        let raw=logits.asType(.float32)')
last=s.index('                        var row: [String:Any]',first)
s=s[:first]+'''                        let validationStarted=RuntimeClock.now()
                        let hash: String
                        if deferValidation {deferredLogits.append(logits); hash="pending"}
                        else {hash=try validate(logits,condition:condition,round:round)}
                        let validationEnded=RuntimeClock.now()
'''+s[last:]
s=s.replace('"routes":observer.ids.mapKeysToStrings(),"logits_sha256":hash,','"routes":observer.ids.mapKeysToStrings(),"logits_sha256":hash,"interpass_validation_ns":validationEnded-validationStarted,')
first=s.index('                        let receipt:[String:Any]')
last=s.index('                        print(',first)
s=s[:first]+s[last:]
needle='''                    }
                }
                }
                model.lookahead?.requestFinished()'''
assert needle in s
s=s.replace(needle,'''                    }
                    if deferValidation {
                        guard deferredLogits.count == 66 else {throw ModelError("Missing deferred output")}
                        for round in 0..<66 {rows[phaseFirstRow+round]["logits_sha256"]=try validate(deferredLogits[round],condition:condition,round:round)}
                    }
                    deferredLogits.removeAll()
                    guard ProcessMemory.peakResidentGB <= memoryGB else {throw ModelError("Diagnostic retained outputs exceed ceiling")}
                    let receipt:[String:Any] = ["plan":plan.json(),"prompt_ids":prefix,"continuation_ids":ids,"runs":rows,"trace_reads":traceReads,"evictions":drops,"reverse_phases":reverse,"deferred_validation":deferValidation,
                        "scope":"Diagnostic timing-perturbation control: original validation between passes versus retained evaluated outputs validated after each condition. All full logits checked. Same runtime, actual cache and inputs. Extra retained outputs remain inside the physical ceiling. Not a runtime optimization or complete generation."]
                    try JSONSerialization.data(withJSONObject:receipt,options:[.prettyPrinted,.sortedKeys]).write(to:URL(fileURLWithPath:output),options:.atomic)
                }
                }
                model.lookahead?.requestFinished()''')
(P/'Q2ProfileCommand-validation-gap.swift').write_text(s)
(P/'build_validation_gap.py').write_text((P/'build_phase_order.py').read_text().replace('phase-order','validation-gap'))
r=(P/'run_phase_order.py').read_text().replace('phase-order','validation-gap')
r=r.replace("order='NSSN'","order='ABBA'")
r=r.replace("for index,arm in enumerate('NS'if phase=='probe'else'NSSN'):","for index,mode in enumerate('ABBA'):\n  arm='N'")
r=r.replace("label=f'{phase}-{width}-{index}-{arm}'","label=f'{phase}-{width}-{index}-{mode}'")
r=r.replace("env+=['--env','Q2_REVERSE_PHASES='+('1' if reverse else '0')]","env+=['--env','Q2_REVERSE_PHASES='+('1' if reverse else '0'),'--env','Q2_DEFER_VALIDATION='+('1' if mode=='B' else '0')]")
r=r.replace('dict(label=label,arm=arm,width=width,reverse_phases=reverse','dict(label=label,arm=arm,mode=mode,width=width,reverse_phases=reverse')
r=r.replace("scope='Order control: N forward, S forward, S reverse, N reverse. One unmeasured no-ahead pass seeds routed keys before each process; then two warmups and64measured percondition. Same393keys, capacity, precision and fixed input. Not complete generation. No power or priority intervention.'", "scope='Native diagnostic-only validation-placement control. A=original full readback/hash between passes; B=retain evaluated outputs and validate after each condition, bounded to66outputs. ABBA with forward phases first2 and reverse last2. Same393missingkeys, capacity, runtime and exact-logit checks. All actual memory charged by physical guard. No power or priority change, no runtime change.'")
(P/'run_validation_gap.py').write_text(r)
a=(P/'analyze_phase_order.py').read_text().replace("default='phase-order'","default='validation-gap'").replace('label=label,arm=arm,eligible=',"label=label,arm=arm,mode=event['mode'],eligible=")
(P/'analyze_validation_gap.py').write_text(a)
