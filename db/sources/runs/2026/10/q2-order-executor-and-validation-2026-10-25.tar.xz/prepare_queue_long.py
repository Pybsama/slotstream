from pathlib import Path
P=Path(__file__).resolve().parent
s=(P/'Q2ProfileCommand-phase-order.swift').read_text().replace('import Foundation','import Foundation\nimport Darwin')
start='                let model=engine.model, state=model.makeState()'
s=s.replace(start,'''                let mode=ProcessInfo.processInfo.environment["Q2_DIAGNOSTIC_EXECUTOR"] ?? "A"
                guard ["A","B","C"].contains(mode) else {throw ModelError("Invalid executor diagnostic")}
                let work: () throws -> Void = {
                let actualQos=qos_class_self().rawValue
                guard actualQos == (mode == "C" ? 33 : 25) else {throw ModelError("Unexpected execution QoS: \\(actualQos)")}
'''+start,1)
needle='                model.lookahead?.requestFinished()\n            } catch { outcome = .failure(error) }'
assert needle in s
s=s.replace(needle,'''                model.lookahead?.requestFinished()
                }
                if mode == "A" { try work() }
                else {
                    try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
                        DispatchQueue(label:"slotstream.diagnostic-verification", qos: mode == "C" ? .userInteractive : .userInitiated).async {
                            do {try work(); continuation.resume()}
                            catch {continuation.resume(throwing:error)}
                        }
                    }
                }
            } catch { outcome = .failure(error) }''',1)
s=s.replace('let receipt:[String:Any] = ["plan":','let receipt:[String:Any] = ["execution_mode":mode,"execution_qos":actualQos,"plan":')
(P/'Q2ProfileCommand-queue-long.swift').write_text(s)
s=(P/'build_phase_order.py').read_text().replace('phase-order','queue-long')
(P/'build_queue_long.py').write_text(s)
