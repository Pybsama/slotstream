from pathlib import Path
import json,statistics
P=Path(__file__).resolve().parent
out=[]
for event in json.loads((P/'phase-order-ledger.json').read_text()):
    label=event['label'];rows=json.loads((P/(label+'.json')).read_text())['runs'];conditions={}
    for c in ['cached_off','partial_off','cached_on','partial_on']:
        z=[r for r in rows if r['condition']==c and r['round']>=2]
        gaps=[(b['start_ns']-a['end_ns'])/1e6 if 'start_ns'in a else (b['start']-a['end'])*1000 for a,b in zip(z,z[1:])]
        conditions[c]={'gap_ms':gaps,'median_ms':statistics.median(gaps),'minimum_ms':min(gaps),'maximum_ms':max(gaps)}
    out.append({'label':label,'eligible':event['eligible'],'conditions':conditions})
(P/'interpass-gaps.json').write_text(json.dumps({'scope':'All work between consecutive measured passes, including validation and setup; not solely hash cost. Phase-order source protocol is clean. No causal frequency claim.','arms':out},indent=2))
