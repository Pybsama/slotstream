from pathlib import Path
import argparse,bisect,collections,csv,datetime,json,statistics
P=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--label',default='validation-gap');a=ap.parse_args()
def union(xs):
 out=[]
 for lo,hi in sorted(xs):
  if hi<=lo:continue
  if not out or lo>out[-1][1]:out.append([lo,hi])
  else:out[-1][1]=max(hi,out[-1][1])
 return out
def length(xs):return sum(b-a for a,b in xs)
def intersection(a,b):
 out=[];i=j=0
 while i<len(a) and j<len(b):
  lo,hi=max(a[i][0],b[j][0]),min(a[i][1],b[j][1])
  if hi>lo:out.append([lo,hi])
  if a[i][1]<b[j][1]:i+=1
  else:j+=1
 return out
def csvrows(path):
 with path.open()as f:
  for x in csv.DictReader(line for line in f if not line.startswith('#')):yield x
 with path.open('rb')as f:
  f.seek(max(0,path.stat().st_size-1024));tail=f.read().decode().splitlines()[-1]
 foot=dict(x.split('=')for x in tail[2:].split());assert int(foot['total'])<int(foot['cap'])
 if 'gpu_initial'in foot:assert foot['gpu_initial']==foot['cpu_initial'] and foot['gpu_final']==foot['cpu_final']
def limits(r):return (r['start_ns']/1e9,r['end_ns']/1e9)if'start_ns'in r else(r['start'],r['end'])
ledger=json.loads((P/(a.label+'-ledger.json')).read_text());report=[]
reference='c6cc487735173af3198566071fbc3a2016f3e970a1f576523f046386cea94d22'
for event in ledger:
 label,arm=event['label'],event['arm'];data=json.loads((P/(label+'.json')).read_text());steps=[r for r in data['runs']if r['round']>=2]
 for i,r in enumerate(steps):r['step']=i;r['width']=4;r.setdefault('records_fetched',r.get('records_read'));r.setdefault('records_adopted',r.get('records_prefetched'))
 assert len(steps)==256
 if arm=='N':assert all(r['logits_sha256']==reference for r in data['runs'])
 windows=[limits(r)for r in steps];lo,hi=windows[0][0],windows[-1][1]
 guard=event['guard'];offsets=[x['unix']-x['mach_ns']/1e9 for x in guard['samples']];offset=statistics.median(offsets)
 raw=[json.loads(line)for line in(P/(label+'-frequency.jsonl')).read_text().splitlines()]
 ticks=[datetime.datetime.fromisoformat(x['timestamp']).timestamp()-offset for x in raw]
 delta=statistics.median(b-a for a,b in zip(ticks,ticks[1:]));assert .15<delta<.5,(label,delta)
 samples=[(ticks[i-1] if i else t-delta,t,x)for i,(t,x) in enumerate(zip(ticks,raw))]
 def frequency(intervals,shift=0):
  weighted=collections.defaultdict(float);covered=0;count=0
  for b,e,x in samples:
   overlap=length(intersection(intervals,[(b+shift,e+shift)]))
   if not overlap:continue
   covered+=overlap;count+=1
   for key in ['gpu_freq_mhz','gpu_active_ratio','gpu_scaled_ratio','gpu_power','gpu_ram_power']:
    weighted[key]+=overlap*x[key]
  if not shift:assert abs(covered-length(intervals))<.01,(label,covered,length(intervals))
  return dict(covered_seconds=covered,coverage_ratio=covered/length(intervals),samples=count,**{k:v/covered for k,v in weighted.items()} if covered else {},frequency_time_million_cycles=weighted['gpu_freq_mhz'])
 def measure(intervals):
  return dict(verify_seconds=length(intervals),frequency=frequency(intervals),frequency_shift_sensitivity={str(s):frequency(intervals,s)for s in [-delta,delta]})
 result=dict(label=label,arm=arm,mode=event['mode'],eligible=event['eligible'],native_full_hashes_exact=arm=='N',scope='Fixed width-four verification, cached and controlled 393-key partial misses, read-ahead off/on. Whole-device frequency association, not complete requests or causal governor proof.',clock_offset_seconds=offset,clock_offset_range_seconds=max(offsets)-min(offsets),sample_interval_seconds=delta,summary=measure(windows),records_fetched=sum(r['records_fetched']for r in steps),records_adopted=sum(r['records_adopted']for r in steps),by_condition={c:dict(**measure([limits(r)for r in steps if r['condition']==c]),median_seconds=statistics.median(r['seconds']for r in steps if r['condition']==c),fetched_per_pass=statistics.mean(r['records_fetched']for r in steps if r['condition']==c),adopted_per_pass=statistics.mean(r['records_adopted']for r in steps if r['condition']==c))for c in ['cached_off','partial_off','cached_on','partial_on']},passes=[dict(step=r['step'],width=r['width'],**measure([limits(r)]))for r in steps])
 report.append(result);print(json.dumps({k:v for k,v in result.items()if k not in ['passes']},indent=2))
(P/(a.label+'-analysis.json')).write_text(json.dumps(dict(whole_protocol_eligible=len(report)==4 and all(x['eligible']for x in report),arms=report),indent=2))
