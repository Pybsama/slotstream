from pathlib import Path
import json,csv,bisect,collections
P=Path(__file__).resolve().parent;H=P.parent/'q2-handoff-20261025'
def read(path):
    with path.open()as f:return list(csv.DictReader(l for l in f if not l.startswith('#')))
d=json.loads((H/'readiness-4-0-N.json').read_text())
c=read(H/'readiness-4-0-N-commands.69375.csv');ev=read(H/'readiness-4-0-N-commands.69375.events.csv')
sub=collections.defaultdict(list)
for r in c:sub[int(r['buffer'])].append(float(r['submitted']))
for v in sub.values():v.sort()
enc=collections.defaultdict(list);sets={(r['event'],r['value'])for r in ev if r['kind']=='S'}
for r in ev:
    if r['kind']=='E':enc[(int(r['buffer']),bisect.bisect_left(sub[int(r['buffer'])],float(r['stamp'])))].append(float(r['stamp']))
out={'scope':'Structural reuse of a prior fixed-pass trace. Every CPU-published expert readiness wait starts before the first compute encoder in both partial conditions. Not a timing or whole-runtime correctness claim.','conditions':{}}
for condition in ['cached_off','partial_off','cached_on','partial_on']:
    spans=[(r['start_ns']/1e9,r['end_ns']/1e9)for r in d['runs']if r['condition']==condition and r['round']>=2]
    count=collections.Counter()
    for r in ev:
        if r['kind']!='W'or(r['event'],r['value'])not in sets:continue
        t=float(r['stamp'])
        if not any(a<=t<b for a,b in spans):continue
        k=(int(r['buffer']),bisect.bisect_left(sub[int(r['buffer'])],t))
        count[sum(x<t for x in enc[k])]+=1
    if condition.startswith('partial'):assert count=={0:144}
    else:assert not count
    out['conditions'][condition]=dict(count)
(P/'readiness-first-wait-control.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
