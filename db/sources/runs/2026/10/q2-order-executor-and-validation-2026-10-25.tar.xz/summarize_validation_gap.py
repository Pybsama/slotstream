from pathlib import Path
import json,statistics,subprocess,sys
P=Path(__file__).resolve().parent
with (P/'validation-gap-analysis.log').open('w') as f:
    subprocess.run([sys.executable,str(P/'analyze_validation_gap.py')],stdout=f,check=True)
d=json.loads((P/'validation-gap-analysis.json').read_text())
out={'whole_protocol_eligible':d['whole_protocol_eligible'],'arms':[]}
for a in d['arms']:
    raw=json.loads((P/(a['label']+'.json')).read_text())
    assert raw['deferred_validation']==(a['mode']=='B')
    assert len(raw['runs'])==264
    assert all(r['logits_sha256']=='c6cc487735173af3198566071fbc3a2016f3e970a1f576523f046386cea94d22'for r in raw['runs'])
    conditions={}
    for c,v in a['by_condition'].items():
        rows=[r for r in raw['runs']if r['condition']==c and r['round']>=2]
        assert len(rows)==64
        assert all(r['records_fetched']+r['records_adopted']==(393 if c.startswith('partial')else 0)for r in rows)
        conditions[c]={'median_ms':v['median_seconds']*1000,'mhz':v['frequency']['gpu_freq_mhz'],
                       'between_passes_median_ms':statistics.median((y['start_ns']-x['end_ns'])/1e6 for x,y in zip(rows,rows[1:])),
                       'interpass_validation_median_ms':statistics.median(r['interpass_validation_ns']/1e6 for r in rows),
                       'quartile_ms':[statistics.median(r['seconds']for r in rows[i:i+16])*1000 for i in range(0,64,16)]}
    out['arms'].append({'label':a['label'],'mode':a['mode'],'eligible':a['eligible'],'full_logits_exact':True,'conditions':conditions})
if len(out['arms'])==4:
    out['medians_by_mode']={mode:{c:{k:statistics.median(a['conditions'][c][k]for a in out['arms']if a['mode']==mode)for k in ['median_ms','mhz']}for c in conditions}for mode in 'AB'}
(P/'validation-gap-summary.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
