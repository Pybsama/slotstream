import ArgumentParser
import Foundation
import CryptoKit
import MLX
import Slotstream

final class MatchedRoutes: ExpertLookaheadObserver {
    var ids: [Int: [Int32]] = [:]
    func beginPass(id: Int, phase: ExpertLookaheadPhase, tokens: [Int], features: [ExpertLookaheadStartFeature], nanos: UInt64) { ids = [:] }
    func routes(pass: Int, layer: Int, rows: Int, topK: Int, ids: [Int32]) { self.ids[layer] = Array(Set(ids)).sorted() }
    func layerCompleted(pass: Int, layer: Int, x2: MLXArray, nanos: UInt64) {}
    func demand(_ event: ExpertLookaheadDemandEvent) {}
    func admissions(pass: Int, layer: Int, experts: [Int32]) {}
    func residency(_ snapshot: ExpertLookaheadResidency, afterPass: Int) {}
    func passReconciled(id: Int, kept: Int) {}
    func endPass(id: Int, nanos: UInt64, aborted: Bool) {}
}

struct Q2ProfileCheck: ParsableCommand {
    static let configuration = CommandConfiguration(commandName: "q2-profile", abstract: "Isolated matched Q2 target verification diagnostic")
    @Option var fixture: String
    @Option var output: String
    @Option var memoryGB: Double = 15
    @Option var evictions: String?
    @Option var width: Int = 4
    @Flag var traceReads = false
    func run() throws {
        guard memoryGB == 15, !FileManager.default.fileExists(atPath: output) else { throw ValidationError("Cached/partial frequency diagnostic requires a bounded budget and a fresh receipt") }
        let input = try JSONSerialization.jsonObject(with: Data(contentsOf: URL(fileURLWithPath: fixture))) as! [String: Any]
        let prefix = input["prompt_ids"] as! [Int], ids = Array((input["output_ids"] as! [Int]).prefix(width))
        guard prefix.count <= 768, ids.count == width && (3...4).contains(width) else { throw ValidationError("Invalid fixed inputs") }
        let drops=try evictions.map { try JSONDecoder().decode([Int].self,from:Data(contentsOf:URL(fileURLWithPath:$0))) } ?? []
        let machine = Machine.current()
        guard (machine.availableGB ?? 0) >= memoryGB + 3 else { throw ModelError("Budget plus 3 GB required") }
        let plan = try Planner.plan(resources: .q2, expertsPerLayer: nil, poolGB: nil, memoryGB: memoryGB,
            ramGB: machine.ramGB, workingSetGB: machine.workingSetGB, availableGB: machine.availableGB,
            mtp: .off, mtpAvailable: false, vision: .off, visionAvailable: false, maxContextTokens: 8192,
            qualification: false, decodeLookahead: .reserved(bytes: NativeInputReadAhead.reserveBytes), mtpExperts: .automatic)
        let sem=DispatchSemaphore(value:0)
        var outcome: Result<Void, Error> = .success(())
        Task {
            do {
                let engine = try await Engine(modelDir: ModelLocator.resolve("smart-q2"), plan: plan)
                let model=engine.model, state=model.makeState()
                let observer=MatchedRoutes()
                for lo in stride(from:0,to:prefix.count,by:256) { eval(try model.lastLogitsChecked(Array(prefix[lo..<min(lo+256,prefix.count)]),state:state)) }
                let checkpoint=state.checkpoint()
                model.capturesDraftFeatures=true
                // Seed the fixed routed keys before either condition order.
                // This is one ordinary verification, outside the measured phases.
                state.setRecording(true)
                eval(try model.allLogitsWithMultiChecked(ids,state:state).logits)
                try state.restoreChecked(checkpoint)
                model.pool.unpinAll()
                let orderValue=ProcessInfo.processInfo.environment["Q2_REVERSE_PHASES"] ?? "0"
                guard orderValue == "0" || orderValue == "1" else {throw ModelError("Invalid diagnostic order")}
                let reverse=orderValue == "1"
                let aheadOrder=reverse ? [true,false] : [false,true]
                let cacheOrder=reverse ? ["partial","cached"] : ["cached","partial"]
                var rows: [[String: Any]] = [], reference: String?
                for ahead in aheadOrder {
                    model.lookahead?.requestFinished()
                    model.lookahead=nil
                    if ahead { try model.enableNativeInputReadAhead(reservedBytes:plan.lookaheadReserveBytes) }
                    else { model.lookahead=ExpertLookaheadSession() }
                    model.lookahead?.observer=observer
                for cache in cacheOrder {
                    let condition=cache + (ahead ? "_on" : "_off")
                    for round in 0..<66 {
                        model.lookahead?.requestFinished()
                        try state.restoreChecked(checkpoint)
                        model.pool.unpinAll()
                        if cache == "partial" { try model.pool.diagnosticDiscardKeys(drops) }
                        state.setRecording(true)
                        model.pool.resetStats(); model.lookahead?.prefetch?.resetObservation()
                        let before=ProcessMemory.vmActivity()
                        let retire=model.nativeRouterRetirementPasses, schedules=model.nativeExpertScheduledPasses
                        let repacked=model.nativeGPURepackedRecords, forecasts=model.nativeGPUForecastRecords
                        let started=RuntimeClock.now()
                        model.lookahead?.beginPass(phase:.mainVerify,tokens:ids,features:[])
                        let logits=try model.allLogitsWithMultiChecked(ids,state:state).logits
                        let built=RuntimeClock.now()
                        eval(logits)
                        let evaluated=RuntimeClock.now()
                        model.lookahead?.endPass()
                        let ended=RuntimeClock.now()
                        let after=ProcessMemory.vmActivity()
                        let raw=logits.asType(.float32).asArray(Float.self).withUnsafeBytes { Data($0) }
                        let hash=SHA256.hash(data:raw).map{String(format:"%02x",$0)}.joined()
                        if let reference { guard hash == reference else { throw ModelError("Fixed input/state/cache changed logits") } } else { reference=hash }
                        if round == 2 { try raw.write(to: URL(fileURLWithPath: output+"-"+condition+".f32")) }
                        var row: [String:Any] = ["condition":condition,"round":round,"start_ns":started,"built_ns":built,"evaluated_ns":evaluated,"end_ns":ended,
                            "seconds":Double(ended-started)/1e9,"model_call_seconds":Double(built-started)/1e9,"final_eval_seconds":Double(evaluated-built)/1e9,
                            "io_seconds":model.pool.ioSeconds,"adopt_seconds":model.pool.adoptSeconds,"records_fetched":model.pool.recordsFetched,"records_adopted":model.pool.recordsAdopted,
                            "routes":observer.ids.mapKeysToStrings(),"logits_sha256":hash,
                            "router_retirement_passes":model.nativeRouterRetirementPasses-retire,"scheduled_passes":model.nativeExpertScheduledPasses-schedules,
                            "gpu_repacked_records":model.nativeGPURepackedRecords-repacked,"gpu_forecast_records":model.nativeGPUForecastRecords-forecasts,
                            "peak_gb":ProcessMemory.peakResidentGB,"swapins_delta":(after?.swapins ?? 0)-(before?.swapins ?? 0),"swapouts_delta":(after?.swapouts ?? 0)-(before?.swapouts ?? 0)]
                        if let observation=model.lookahead?.prefetch?.observation { row["prefetch"] = try JSONSerialization.jsonObject(with:JSONEncoder().encode(observation)) }
                        guard ProcessMemory.peakResidentGB <= memoryGB, (after?.reclaimableBytes ?? 0)>1_000_000_000 else {throw ModelError("Physical ceiling/headroom violated")}
                        rows.append(row)
                        let receipt:[String:Any] = ["plan":plan.json(),"prompt_ids":prefix,"continuation_ids":ids,"runs":rows,"trace_reads":traceReads,"evictions":drops,"reverse_phases":reverse,
                          "scope":"Target-only fixed captured-width verification, same state each pass. Two warmups. Model-call time includes internal GPU/I/O waits, not pure CPU preparation. Partial misses discard explicit common routed keys only; tensor storage and capacity unchanged. Prefix is re-prefilled identically by chunk, not a byte-identical cross-engine state." ]
                        if round == 65 { try JSONSerialization.data(withJSONObject:receipt,options:[.prettyPrinted,.sortedKeys]).write(to:URL(fileURLWithPath:output),options:.atomic) }
                        print("\(condition) \(round): \(row["seconds"]!) seconds, fetched \(model.pool.recordsFetched), adopted \(model.pool.recordsAdopted)")
                    }
                }
                }
                model.lookahead?.requestFinished()
            } catch { outcome = .failure(error) }
            sem.signal()
        }
        sem.wait(); try outcome.get()
    }
}
private extension Dictionary where Key == Int, Value == [Int32] {
    func mapKeysToStrings() -> [String:[Int32]] { Dictionary<String,[Int32]>(uniqueKeysWithValues:map{(String($0.key),$0.value)}) }
}
