from pathlib import Path
import hashlib,io,json,re,tarfile
P=Path(__file__).resolve().parent;R=P.parents[1]
dest=R/'db/sources/runs/2026/10/q2-order-executor-and-validation-2026-10-25.tar.xz'
assert not dest.exists()
files={}
for pattern in ['phase-order-*','queue-long-*','validation-gap-*']:
    for f in P.glob(pattern):
        if f.is_file() and f.suffix in ['.json','.jsonl','.log','.mm','.stderr']:
            files[f.name]=f
for stem in ['phase_order','queue_long','validation_gap']:
    for prefix in ['prepare','build','run','analyze','summarize']:
        f=P/(prefix+'_'+stem+'.py')
        if f.exists():files[f.name]=f
for name in ['build_phase_order_upstream.py','analyze_phase_order_details.py','analyze_interpass_gaps.py','interpass-gaps.json','ExpertStore-frequency-cache.swift','quiet_guarded_run.py','archive_context_diagnosis.py','context-runtime-restoration.json','readiness-first-wait-control.py','readiness-first-wait-control.json']:
    files[name]=P/name
for stem in ['phase-order','queue-long','validation-gap']:
    files['Q2ProfileCommand-'+stem+'.swift']=P/('Q2ProfileCommand-'+stem+'.swift')
    files['restored-'+stem+'.json']=P/('restored-'+stem+'.json')
    for name in ['manifest.json','build.txt','candidate/build-identity.json','candidate/build-source.tar.gz']:
        files[stem+'-build/'+name]=P/('native-'+stem+'-build')/name
files['reference/native-v68-build-identity.json']=R/'.build/native-replay-20261023/v68/build-identity.json'
for name in ['fixture-4.json','evictions-4.json','readiness-4-0-N.json','readiness-4-0-N-commands.69375.csv','readiness-4-0-N-commands.69375.events.csv']:
    files['reference/'+name]=R/'.build/q2-handoff-20261025'/name
W=Path('/var/folders/d4/t1c8ltbx5s3_11cs9y6gjh8m0000gp/T/slotstream-splash-host-ugnf26pi/source')
for name in ['runtime/metal/MetalBackend.mm','runtime/model/SsdReaders.cpp']:
    files['reference/splash/'+name]=W/name
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
unique={};copies=[]
for pattern in ['phase-order-*.f32','queue-long-*.f32','validation-gap-*.f32']:
    for f in sorted(P.glob(pattern)):
        digest=sha(f)
        if digest not in unique:
            unique[digest]='full-logits/'+digest+'.f32';files[unique[digest]]=f
        copies.append({'original':f.name,'bytes':f.stat().st_size,'sha256':digest,'archive_member':unique[digest]})
assert len(unique)==2
dedup=P/'context-logits-deduplication.json';dedup.write_text(json.dumps(copies,indent=2));files[dedup.name]=dedup
secret=re.compile(rb'(?:ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{25,}|sk-(?:proj-)?[A-Za-z0-9_-]{30,}|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----)')
for f in files.values():assert f.exists() and not secret.search(f.read_bytes()),f
manifest={n:{'bytes':f.stat().st_size,'sha256':sha(f)}for n,f in files.items()}
raw=json.dumps(manifest,indent=2).encode()+b'\n'
with tarfile.open(dest,'w:xz',preset=3)as t:
    for n,f in sorted(files.items()):t.add(f,arcname=n,recursive=False)
    i=tarfile.TarInfo('archive-manifest.json');i.size=len(raw);t.addfile(i,io.BytesIO(raw))
seen={}
with tarfile.open(dest,'r|xz')as t:
    for member in t:
        b=t.extractfile(member).read()
        if member.name=='archive-manifest.json':assert json.loads(b)==manifest
        else:seen[member.name]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
assert seen==manifest
receipt={'path':str(dest.relative_to(R)),'files':len(manifest),'bytes':dest.stat().st_size,'sha256':sha(dest),'readback_verified':True,'credential_pattern_matches':0,'full_logit_files_verified':len(copies),'unique_full_logits':len(unique)}
(P/'context-archive-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
