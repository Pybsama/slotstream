from pathlib import Path
import collections,csv,fcntl,json,os,statistics,struct,sys
P=Path(__file__).resolve().parent;R=P.parents[1]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
reservation=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(reservation,fcntl.LOCK_EX|fcntl.LOCK_NB);os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(P/'analysis-child.lock');preflight(4)
def union(xs):
 out=[]
 for a,b in sorted(xs):
  if b<=a:continue
  if not out or a>out[-1][1]:out.append([a,b])
  else:out[-1][1]=max(b,out[-1][1])
 return out
def inter(a,b):
 out=[];i=j=0
 while i<len(a)and j<len(b):
  lo,hi=max(a[i][0],b[j][0]),min(a[i][1],b[j][1])
  if hi>lo:out.append([lo,hi])
  if a[i][1]<b[j][1]:i+=1
  else:j+=1
 return out
def length(xs):return sum(b-a for a,b in xs)
def csvrows(path):
 lines=path.read_text().splitlines();footer=dict(x.split('=',1)for x in lines[-1][2:].split());assert int(footer['total'])<int(footer['cap'])
 return list(csv.DictReader(x for x in lines if not x.startswith('#'))),footer
ledger=json.loads((P/'trace-ledger.json').read_text());assert [e['probe']for e in ledger]==[False,True,True,False]
times=[e['round_seconds'][-1]for e in ledger];ratios=[times[1]/times[0],times[2]/times[3]];pooled=(times[1]+times[2])/(times[0]+times[3])
reports=[]
for event in ledger:
 if not event['probe']:continue
 label=event['label'];result=json.loads((P/(label+'.json')).read_text());steps=result['rounds'][-1]['steps'];windows=union((r['start_ns']/1e9,r['end_ns']/1e9)for r in steps)
 meta=json.loads((P/(label+'.json.alloc.json')).read_text());rows=list(struct.iter_unpack('<8Q',(P/(label+'.json.alloc.bin')).read_bytes()));assert len(rows)==meta['rows'] and meta['active']==0 and len(rows)<meta['cap']
 scale=meta['numer']/meta['denom']/1e9;owner=meta['owner'];groups=collections.defaultdict(list);count=collections.Counter();bykind=collections.defaultdict(list);children=collections.defaultdict(list);boundary=[]
 for i,(start,acq,release,end,tid,parent,size,kind)in enumerate(rows):
  assert start>0 and start<=end and tid>0,(i,'span')
  who='owner'if tid==owner else'background';count[who+('_lock'if kind>=100 else'_call')]+=1
  if kind>=100:
   assert start<=acq<=release<=end,(i,'lock order')
   if parent:
    p=rows[parent-1];assert parent<=i and p[4]==tid and p[7]+100==kind and p[0]<=start and end<=p[3] and p[6]==size,(i,'parent')
    children[parent].append(i)
   else:assert kind==100;boundary.append(i)
   for name,a,b in [('wait',start,acq),('held',acq,release),('unlock',release,end)]:groups[who+'_'+name].append((a*scale,b*scale))
  else:
   assert 1<=kind<=8 and parent==0 and acq==release==0,(i,'call')
   groups[who+'_api'].append((start*scale,end*scale));bykind[(who,kind)].append((start*scale,end*scale))
 stages,sfoot=csvrows(next(P.glob(label+'-commands.*.stages.csv')));assert sfoot['cpu_initial']==sfoot['gpu_initial'] and sfoot['cpu_final']==sfoot['gpu_final']
 reads,rfoot=csvrows(next(P.glob(label+'-reads.*.csv')))
 gpu=union((int(s['gpu_start'])/1e9,int(s['gpu_end'])/1e9)for s in stages if int(s['gpu_end'])>int(s['gpu_start'])>0)
 rd=union((float(r['start']),float(r['end']))for r in reads if int(r['result'])>0);busy=union(gpu+rd)
 def metric(xs):
  clipped=inter(union(xs),windows)
  return dict(union_seconds=length(clipped),overlap_gpu_seconds=length(inter(clipped,gpu)),overlap_reads_seconds=length(inter(clipped,rd)),outside_gpu_and_reads_seconds=length(clipped)-length(inter(clipped,busy)))
 metrics={key:metric(xs)for key,xs in groups.items()}
 # malloc keeps one lock acquisition for cache hits, and unlocks/relocks
 # around new Metal-buffer allocation on cache misses. Count actual paths.
 mallocpaths=collections.Counter();mallocgroups=collections.defaultdict(list)
 for i,r in enumerate(rows):
  if r[7]!=4:continue
  who='owner'if r[4]==owner else'background';n=len(children[i+1]);mallocpaths[(who,n)]+=1
  mallocgroups[(who,n)].append((r[0]*scale,r[3]*scale))
 coverage=metric(inter(union(groups['owner_wait']),union(groups['background_held'])))
 report=dict(label=label,metadata=meta,thread_count=len({r[4]for r in rows}),counts=dict(count),boundary_locks=boundary,fields=metrics,api_by_kind={f'{k[0]}_{k[1]}':metric(v)for k,v in bykind.items()},malloc_lock_paths={f'{k[0]}_{k[1]}':dict(calls=n,**metric(mallocgroups[k]))for k,n in mallocpaths.items()},owner_wait_overlapping_observed_background_hold=coverage,cycle_seconds=length(windows),footers=dict(stages=sfoot,reads=rfoot),scope='Actual allocatorAPI, lock acquisition, held and unlock intervals; parents and children are nested and must not be added. Background durations are unions, not request costs. Observed read/GPU overlap is not global idle attribution; unrelated forecasts may hide required host work. kind100 is a lock whose parent API began before recording.')
 (P/(label+'-analysis.json')).write_text(json.dumps(report,indent=2));reports.append({k:v for k,v in report.items()if k not in ['footers','scope']})
control=dict(observed_seconds=times,ratios=ratios,pooled_ratio=pooled,within_two_percent=all(abs(r-1)<=.02 for r in ratios+[pooled]))
summary=dict(scope='Bounded native allocator attribution, not a product speed test or comparison against Splash. Preserve exact-output evidence and all control arms; do not infer a fix from background service sums.',environment_eligible=all(e['eligible']for e in ledger),control=control,reports=reports)
(P/'analysis.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
