#pragma once
#include "NativeSchedule.h"
#include "NativeProgram.h"
#include "AdaptiveReplacement.h"

#ifdef __cplusplus
extern "C" {
#endif
void ss_mlx_alloc_probe_begin(void);
int ss_mlx_alloc_probe_end(const char* prefix);
#ifdef __cplusplus
}
#endif
