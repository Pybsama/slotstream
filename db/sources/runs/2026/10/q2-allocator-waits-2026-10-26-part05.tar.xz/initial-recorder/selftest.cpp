#include <mutex>
#include <optional>
#include <cstdlib>
#include <unistd.h>
#include <thread>
#include <condition_variable>
#include "probe.hpp.txt"
int main(int argc,char**argv){
 if(argc!=2)return 1;
 std::mutex allocator,coordination;std::condition_variable cv;bool ready=false,release=false;
 ss_mlx_alloc_probe_begin();
 std::thread completion([&]{
   SSAllocSpan call(6,0);SSAllocLock held(allocator,call);
   std::unique_lock lk(coordination);ready=true;cv.notify_all();
   cv.wait(lk,[&]{return release;});
 });
 {std::unique_lock lk(coordination);cv.wait(lk,[&]{return ready;});}
 std::thread releaser([&]{usleep(5000);std::lock_guard lk(coordination);release=true;cv.notify_all();});
 {SSAllocSpan call(4,4096);SSAllocLock held(allocator,call);held.unlock();held.lock();}
 completion.join();releaser.join();
 return ss_mlx_alloc_probe_end(argv[1]);
}
