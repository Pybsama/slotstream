from pathlib import Path
import argparse,fcntl,json,os,subprocess,sys,time
P=Path(__file__).resolve().parent;R=P.parents[1];F=P.parent/'q2-full-cycle-20261025'
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight,terminate_child_tree
sys.path.insert(0,str(R/'.build/native-q2-20261021'));from thermal import wait_nominal
ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['validation','trace']);a=ap.parse_args();validation=a.mode=='validation'
reservation=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(reservation,fcntl.LOCK_EX|fcntl.LOCK_NB)
inner=P/(a.mode+'-child.lock');os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(inner)
ledger=P/(a.mode+'-ledger.json');assert not ledger.exists();events=[]
ref=json.loads((F/'validation-0-N.json').read_text())['rounds'][0]['steps']
if not validation:assert json.loads((P/'validation-result.json').read_text())['passed']
for i,on in enumerate([True]if validation else[False,True,True,False]):
 label=f'{a.mode}-{i}-'+('on'if on else'off');out=P/(label+'.json');assert not out.exists();rounds=1 if validation else 2
 wait_nominal(P/(label+'-cooldown.json'));preflight(18)
 env=['--env','SLOTSTREAM_MODEL_LOCK_PATH='+str(inner),'--env','DYLD_INSERT_LIBRARIES=']
 if validation:env+=['--env','MTL_DEBUG_LAYER=1']
 else:
  env[-1]='DYLD_INSERT_LIBRARIES='+str(R/'.build/q2-sequence-20261025/copy_observer.dylib')+':'+str(R/'.build/q2-sequence-20261025/named_stage_observer.dylib')+':'+str(R/'.build/q2-handoff-20261025/read_observer.dylib')
  env+=['--env','SLOTSTREAM_COPY_OBSERVER='+str(P/(label+'-copies')),'--env','SLOTSTREAM_METAL_OBSERVER='+str(P/(label+'-commands')),'--env','SLOTSTREAM_READ_OBSERVER='+str(P/(label+'-reads'))]
 cmd=[str(P/'native-build/candidate/slotstream'),'q2-profile','--fixture',str(P/'timed-2.json'),'--output',str(out),'--memory-gb','15','--rounds',str(rounds)]
 if validation:cmd+=['--validate']
 if on:cmd+=['--alloc-probe']
 full=[sys.executable,str(P/'quiet_guarded_run.py'),'--label',label,'--budget','15','--timeout','600',*env,'--',*cmd]
 print('START',label,flush=True);monitor=None
 with(P/(label+'-launcher.log')).open('x')as log,(P/(label+'-frequency.jsonl')).open('x')as freq,(P/(label+'-frequency.stderr')).open('x')as ferr:
  if not validation:monitor=subprocess.Popen([str(R/'.build/native-monitor/macmon'),'pipe','-s','3300','-i','200','--soc-info'],stdout=freq,stderr=ferr,start_new_session=True)
  child=subprocess.Popen(full,cwd=R,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:rc=child.wait(timeout=660)
  finally:
   if child.poll()is None:terminate_child_tree(child)
   if monitor and monitor.poll()is None:terminate_child_tree(monitor)
 guard=json.loads((P/(label+'.observer.json')).read_text());event=dict(label=label,probe=on,exit_code=rc,command=full,eligible=not guard['external_build_samples'] and not guard['paging'] and guard['thermal_before']==guard['thermal_after']==0 and guard['peak_combined_bytes']<=15e9 and rc==0)
 events.append(event);ledger.write_text(json.dumps(events,indent=2));assert rc==0
 d=json.loads(out.read_text());assert d['complete'] and d['plan']['pool_slots']==4067
 for rd in d['rounds']:
  assert len(rd['steps'])==111
  for row,expected in zip(rd['steps'],ref):
   for k in ['actual_guesses','actual_selected']+(['logits_sha256']if validation else[]):assert row[k]==expected[k],(label,rd['round'],row['step'],k)
 if on:
  meta=json.loads(Path(str(out)+'.alloc.json').read_text());assert meta['active']==0 and 0<meta['rows']<meta['cap'] and meta['row_bytes']==64
  assert Path(str(out)+'.alloc.bin').stat().st_size==meta['rows']*64
  event['probe_rows']=meta['rows']
 event['round_seconds']=[r['seconds']for r in d['rounds']];ledger.write_text(json.dumps(events,indent=2));print('END',label,event['eligible'],event['round_seconds'],event.get('probe_rows'),flush=True)
if validation:(P/'validation-result.json').write_text(json.dumps(dict(passed=True,full_logit_hashes=111,exact_proposals=111,exact_selected=111,scope='Modified MLX diagnostic path with Metal validation; same real frozen cycles, 4067 actual slots and 15 GB ceiling. No speed evidence.'),indent=2))
print('PROTOCOL FINISHED',flush=True)
