from pathlib import Path
import hashlib,json,shutil,subprocess
P=Path(__file__).resolve().parent;R=P.parents[1];F=P.parent/'q2-full-cycle-20261025';O=P.parent/'q2-mlx-ownership-20261026';M=R/'.build/checkouts/mlx-swift'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=M,text=True).strip()
backend='.build/checkouts/mlx-swift/Source/Cmlx/mlx/mlx/backend/metal/allocator.cpp'
s=(R/backend).read_text();(P/'allocator-original.cpp').write_text(s)
s=s.replace('namespace mlx::core {','#include <optional>\n'+(P/'probe.hpp.txt').read_text()+'\nnamespace mlx::core {',1)
# Wrap every original allocator mutex acquisition. Each API call has its own
# parent row, so release work on a completion thread cannot be added to the
# request-thread wait total. malloc retains its original unlock/relock path.
functions=[('size_t MetalAllocator::set_cache_limit(size_t limit) {',1,'limit'),('size_t MetalAllocator::set_memory_limit(size_t limit) {',2,'limit'),('size_t MetalAllocator::set_wired_limit(size_t limit) {',3,'limit'),('Buffer MetalAllocator::malloc(size_t size) {',4,'size'),('void MetalAllocator::clear_cache() {',5,'0'),('void MetalAllocator::free(Buffer buffer) {',6,'0'),('Buffer MetalAllocator::make_buffer(void* ptr, size_t size) {',7,'size'),('void MetalAllocator::release(Buffer buffer) {',8,'0')]
for head,kind,size in functions:
 assert s.count(head)==1;s=s.replace(head,head+f'\n  SSAllocSpan call({kind},{size});')
assert s.count('std::unique_lock lk(mutex_);')==8
s=s.replace('std::unique_lock lk(mutex_);','SSAllocLock lk(mutex_,call);')
(P/'allocator-probe.cpp').write_text(s);rep={backend:'allocator-probe.cpp'}
s=(R/'Tools/build_identity.py').read_text();needle='    if any(p.is_symlink() for p in candidates):';assert s.count(needle)==1
s=s.replace(needle,"    # Explicit diagnostic dependency override, included in the source archive.\n    candidates.append(root/"+repr(backend)+")\n"+needle);(P/'build_identity-probe.py').write_text(s);rep['Tools/build_identity.py']='build_identity-probe.py'
s=(R/'Sources/CNativeSchedule/include/CNativeSchedule.h').read_text()+'''\n#ifdef __cplusplus
extern "C" {
#endif
void ss_mlx_alloc_probe_begin(void);
int ss_mlx_alloc_probe_end(const char* prefix);
#ifdef __cplusplus
}
#endif
''';(P/'CNativeSchedule-probe.h').write_text(s);rep['Sources/CNativeSchedule/include/CNativeSchedule.h']='CNativeSchedule-probe.h'
s=(F/'Q2ProfileCommand.swift').read_text().replace('import Slotstream','import Slotstream\nimport CNativeSchedule').replace('    @Flag var validate = false','    @Flag var validate = false\n    @Flag var allocProbe = false')
s=s.replace('                    let requestStart=RuntimeClock.now()','                    if allocProbe && round == rounds - 1 { ss_mlx_alloc_probe_begin() }\n                    let requestStart=RuntimeClock.now()')
s=s.replace('                    let requestEnd=RuntimeClock.now()','''                    let requestEnd=RuntimeClock.now()
                    if allocProbe && round == rounds - 1 {
                        let path = output + ".alloc"
                        let result = path.withCString({ ss_mlx_alloc_probe_end($0) })
                        guard result == 0 else { throw ModelError("Allocator diagnostic failed with code \(result)") }
                    }''')
(P/'Q2ProfileCommand-probe.swift').write_text(s);rep['Sources/slotstream-cli/Q2ProfileCommand.swift']='Q2ProfileCommand-probe.swift'
(P/'replacements.json').write_text(json.dumps(rep,indent=2))
for n in ['quiet_guarded_run.py','timed-2.json','check_restoration.py']:shutil.copy2(F/n,P/n)
s=(O/'build.py').read_text().replace('/metal/eval.cpp','/metal/allocator.cpp').replace('eval-probe.cpp','allocator-probe.cpp');(P/'build.py').write_text(s)
s=(O/'run.py').read_text().replace('[False,True]','[False,True,True,False]').replace("['--mlx-probe']","['--alloc-probe']").replace("'.mlx-host.json'","'.alloc.json'").replace("'.mlx-host.bin'","'.alloc.bin'")
s=s.replace("meta['foreign_calls']==0 and 0<meta['rows']<meta['cap'] and meta['row_bytes']==80","meta['active']==0 and 0<meta['rows']<meta['cap'] and meta['row_bytes']==64").replace("meta['rows']*80","meta['rows']*64")
(P/'run.py').write_text(s)
plan=dict(scope='Diagnose actual MLX allocator mutex wait/hold and API service across the request owner and completion threads. This is not an optimization. Keep the original mutex, cache policy, allocation, ownership, unlock/relock and release operations. Do not sum background cleanup into request latency.',hypothesis='Immutable routing packing showed no gain. The allocator shares one mutex for allocating and recycling buffers, including asynchronous completion work; earlier capture-construction/registration probes did not measure this contention. Test whether request-thread acquisition waits explain at least0.1s of exposed latency before proposing a change.',protocol='Exact111full-logit/proposal/selected validation underMetal. Then one frozen off/on/on/off protocol with one warmup and one measured111cycle perprocess. Counter active only final measured pass. Same read/copy/GPU observers both states.15GB4067slots8192nativecontext,BF16/FP32,18GBpreflight. Both-order and pooled2% instrumentation sensitivity; preserve failed controls, no retries. Separate wait unions, held sections and completeAPI spans, thread identity and actual read/GPU overlap.',bounds='At most4194304rows of64bytes in static storage, one model process. Stop recording after request timer; drain only active writes for at most2s before evidence output. Include actual peak footprint and fail on cap overflow, incomplete writes or invalid nesting.',kinds={k:head.split('(')[0]for head,k,size in functions},dependency_revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=M,text=True).strip(),source_revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),sources={n:hashlib.sha256((P/f).read_bytes()).hexdigest()for n,f in rep.items()})
plan['revision']='v2 resolves all lock parents, but the all-thread recorder fails both2% sensitivity controls. Owner-only revision ignores background spans before touching counters and separates read-mostly enable/owner state from written counters. This removes recorder contention rather than changing allocator behavior. Preserve all v1/v2 evidence; no product benchmark retry or optimization.'
plan['scope']='Observe allocatorAPI and actual mutex waits on the request owner only; background calls and hold time are intentionally unmeasured. Original allocator mutex/cache/lifetimes remain unchanged.'
plan['hypothesis']='All-thread observations locate only6.4/6.6ms owner wait but their5.75%pooled overhead disqualifies representative costs. Check the actual request-thread wait directly with a lower-contention observer before ruling the allocator in or out.'
(P/'plan.json').write_text(json.dumps(plan,indent=2));print('Prepared bounded allocator diagnostic')
