from pathlib import Path
import json,subprocess,struct,sys,fcntl,os
P=Path(__file__).resolve().parent;R=P.parents[1]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
reservation=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(reservation,fcntl.LOCK_EX|fcntl.LOCK_NB);os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(P/'selftest-child.lock');preflight(4)
subprocess.run(['xcrun','clang++','-std=c++17','-O2',str(P/'selftest.cpp'),'-o',str(P/'selftest')],check=True)
subprocess.run([str(P/'selftest'),str(P/'selftest-observations')],check=True)
m=json.loads((P/'selftest-observations.json').read_text());rows=list(struct.iter_unpack('<8Q',(P/'selftest-observations.bin').read_bytes()));assert m['rows']==len(rows)==3 and m['active']==0
owner=m['owner'];waits=[];holds=[]
for i,r in enumerate(rows):
 start,acq,release,end,tid,parent,size,kind=r
 if kind>=100:
  assert start<=acq<=release<=end and parent>0
  p=rows[parent-1];assert p[0]<=start and end<=p[3] and p[4]==tid and p[7]+100==kind
  holds.append((acq,release));
  if tid==owner:waits.append((start,acq))
 else:assert kind in [4,6] and parent==0 and acq==release==0 and start<=end
assert len(waits)==2 and len({r[4]for r in rows})==1
holds.sort();assert all(a[1]<=b[0]for a,b in zip(holds,holds[1:]))
scale=m['numer']/m['denom']/1e9
out=dict(passed=True,rows=len(rows),recorded_threads=1,contending_threads=2,owner_wait_seconds=sum(b-a for a,b in waits)*scale,scope='Known background contention with owner-only recording, exact parent nesting, unlock/relock, nonoverlapping held intervals and drained write count. Background spans deliberately excluded. Diagnostic wrapper self-test; no model-performance claim.')
(P/'selftest-result.json').write_text(json.dumps(out,indent=2));print(out)
