from pathlib import Path
import collections,csv,fcntl,json,os,sys,statistics
P=Path(__file__).resolve().parent;R=P.parents[1]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
reservation=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(reservation,fcntl.LOCK_EX|fcntl.LOCK_NB);os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(P/'comparison-child.lock');preflight(4)
def union(xs):
 out=[]
 for a,b in sorted(xs):
  if b<=a:continue
  if not out or a>out[-1][1]:out.append([a,b])
  else:out[-1][1]=max(b,out[-1][1])
 return out
def inter(a,b):
 out=[];i=j=0
 while i<len(a)and j<len(b):
  lo,hi=max(a[i][0],b[j][0]),min(a[i][1],b[j][1])
  if hi>lo:out.append([lo,hi])
  if a[i][1]<b[j][1]:i+=1
  else:j+=1
 return out
def length(xs):return sum(b-a for a,b in xs)
def read(path):
 lines=path.read_text().splitlines();footer=dict(x.split('=',1)for x in lines[-1][2:].split());assert int(footer['total'])<int(footer['cap'])
 return list(csv.DictReader(x for x in lines if not x.startswith('#'))),footer
reports=[]
for e in json.loads((P/'trace-ledger.json').read_text()):
 label=e['label'];d=json.loads((P/(label+'.json')).read_text());stages,sfoot=read(next(P.glob(label+'-commands.*.stages.csv')))
 assert sfoot['cpu_initial']==sfoot['gpu_initial'] and sfoot['cpu_final']==sfoot['gpu_final']
 reads,rfoot=read(next(P.glob(label+'-reads.*.csv')))
 gpu=union((int(s['gpu_start'])/1e9,int(s['gpu_end'])/1e9)for s in stages if int(s['gpu_end'])>int(s['gpu_start'])>0)
 rd=union((float(r['start']),float(r['end']))for r in reads if int(r['result'])>0)
 rds=[]
 for row in d['rounds']:
  steps=row['steps'];w=union((r['start_ns']/1e9,r['end_ns']/1e9)for r in steps);phases={key:sum(r[key]for r in steps)for key in ['draft_seconds','verify_seconds','sample_seconds','commit_seconds']}
  keys=['records_fetched','records_adopted','scheduled_passes','gpu_forecast_records']
  assert all(k in r for k in keys for r in steps)
  counts={k:sum(r[k]for r in steps)for k in keys}
  timed=[r for r in reads if w[0][0]<=float(r['start'])<w[-1][1] and int(r['result'])>0]
  durations=sorted(float(r['end'])-float(r['start'])for r in timed)
  bysize=collections.defaultdict(list)
  for r in timed:bysize[int(r['result'])].append(float(r['end'])-float(r['start']))
  distribution=dict(median_us=statistics.median(durations)*1e6,p95_us=durations[int(.95*(len(durations)-1))]*1e6,by_size=[dict(bytes=k,count=len(v),service_sum_seconds=sum(v),median_us=statistics.median(v)*1e6)for k,v in sorted(bysize.items(),key=lambda p:-len(p[1]))])
  rds.append(dict(read_latency=distribution,round=row['round'],cycle_seconds=length(w),gpu_union_seconds=length(inter(w,gpu)),read_union_seconds=length(inter(w,rd)),read_outside_gpu_seconds=length(inter(w,rd))-length(inter(inter(w,rd),gpu)),outside_gpu_and_reads_seconds=length(w)-length(inter(w,union(gpu+rd))),phases=phases,counts=counts,successful_read_calls=len(timed),read_service_sum_seconds=sum(float(r['end'])-float(r['start'])for r in timed),read_bytes=sum(int(r['result'])for r in timed)))
 reports.append(dict(label=label,probe=e['probe'],rounds=rds,footers=dict(stages=sfoot,reads=rfoot)))
result=dict(scope='Offline localization of the complete frozen owner-probe control. All phases, including warmup, remain visible. Failed sensitivity means no product-speed or removable-cost claim. GPU/read unions are temporal coverage, not proof of GPU idleness; summed read service overlaps across workers.',reports=reports)
(P/'arm-localization.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
