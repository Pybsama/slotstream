from pathlib import Path
import fcntl,hashlib,io,json,os,re,sys,tarfile
P=Path(__file__).resolve().parent;R=P.parents[1];A=P.parent/'q2-allocator-waits-20261026';B=P.parent/'q2-allocator-waits-v2-20261026'
assert json.loads((P/'validation-result.json').read_text())['passed'] and json.loads((B/'validation-result.json').read_text())['passed']
assert (P/'analysis.json').exists()and(B/'analysis.json').exists()and(P/'arm-localization.json').exists()
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
reservation=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(reservation,fcntl.LOCK_EX|fcntl.LOCK_NB);os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(P/'archive-child.lock');preflight(4)
sha=lambda b:hashlib.sha256(b).hexdigest();allowed={'.py','.swift','.h','.hpp','.cpp','.json','.jsonl','.csv','.bin','.log','.stderr','.txt'}
secret=re.compile(rb'(?:ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{25,}|sk-(?:proj-)?[A-Za-z0-9_-]{30,}|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----)');files={}
for prefix,root in [('initial-recorder',A),('all-thread',B),('owner-only',P)]:
 for f in root.rglob('*'):
  if not f.is_file()or '__pycache__'in f.parts or f.suffix not in allowed or f.name.startswith('archive-receipt')or(f.name.startswith('archive')and f.suffix=='.log'):continue
  files[prefix+'/'+str(f.relative_to(root))]=f
F=R/'.build/q2-full-cycle-20261025';S=R/'.build/q2-required-dependencies-20261026/source-reference'
for name,path in [('Slotstream-LICENSE',R/'LICENSE'),('Splash-LICENSE',S/'LICENSE'),('Splash-RuntimeArenas.hpp',S/'runtime/model/RuntimeArenas.hpp'),('Splash-RuntimeArenas.cpp',S/'runtime/model/RuntimeArenas.cpp'),('Splash-WeightSource.cpp',S/'runtime/model/WeightSource.cpp'),('native-Q2GGUFFile.swift',R/'Sources/Slotstream/Q2GGUFFile.swift'),('full-cycle-build-identity.json',F/'native-build/candidate/build-identity.json'),('validation-0-N.json',F/'validation-0-N.json'),('v68-build-identity.json',R/'.build/native-replay-20261023/v68/build-identity.json')]:files['reference/'+name]=path
# Bound each raw shard before compression. All files and all arms survive;
# chunking changes only archive size, never inclusion or interpretation.
chunks=[];current={};size=0
for n,f in sorted(files.items()):
 if current and size+f.stat().st_size>180_000_000:chunks.append(current);current={};size=0
 current[n]=f;size+=f.stat().st_size
if current:chunks.append(current)
receipts=[]
for i,chunk in enumerate(chunks):
 manifest={}
 for n,f in chunk.items():
  b=f.read_bytes();assert not secret.search(b),n;manifest[n]=dict(bytes=len(b),sha256=sha(b))
 dest=R/f'db/sources/runs/2026/10/q2-allocator-waits-2026-10-26-part{i+1:02}.tar.xz';assert not dest.exists();raw=json.dumps(manifest,indent=2).encode()
 with tarfile.open(dest,'w:xz',preset=3)as t:
  for n,f in chunk.items():t.add(f,arcname=n,recursive=False)
  info=tarfile.TarInfo('archive-manifest.json');info.size=len(raw);t.addfile(info,io.BytesIO(raw))
 seen={}
 with tarfile.open(dest,'r|xz')as t:
  for m in t:
   b=t.extractfile(m).read()
   if m.name=='archive-manifest.json':assert json.loads(b)==manifest
   else:seen[m.name]=dict(bytes=len(b),sha256=sha(b))
 assert seen==manifest and dest.stat().st_size<100_000_000
 receipt=dict(path=str(dest.relative_to(R)),files=len(manifest),bytes=dest.stat().st_size,sha256=sha(dest.read_bytes()),readback_verified=True,credential_pattern_matches=0,excluded='Executables, libraries, model weights, pycache, duplicate source archives and active archive-driver output. All initial failures, valid output checks and excluded timing controls remain.')
 receipts.append(receipt);print(json.dumps(receipt),flush=True)
(P/'archive-receipts.json').write_text(json.dumps(receipts,indent=2));print('ARCHIVED',len(files),'files in',len(receipts),'shards',flush=True)
