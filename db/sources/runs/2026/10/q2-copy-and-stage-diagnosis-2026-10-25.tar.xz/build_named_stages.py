from pathlib import Path
import csv,fcntl,hashlib,json,os,subprocess,sys
P=Path(__file__).resolve().parent;R=P.parents[1]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
lock=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(P/'named-stage-build-child.lock');before=preflight(4)
assert not(P/'named-stage-build.json').exists()
flags=['xcrun','clang++','-std=c++17','-O2','-framework','Foundation','-framework','Metal']
cmds=[flags+['-dynamiclib',str(P/'named_stage_observer.mm'),'-o',str(P/'named_stage_observer.dylib')],flags+[str(P/'named_stage_check.mm'),'-o',str(P/'named-stage-check')]]
for i,cmd in enumerate(cmds):
 r=subprocess.run(cmd,capture_output=True,text=True,timeout=120);(P/f'named-stage-build-{i}.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stderr
env={k:v for k,v in os.environ.items()if not k.startswith(('SLOTSTREAM_','MLX_','DYLD_'))};env.update(DYLD_INSERT_LIBRARIES=str(P/'named_stage_observer.dylib'),SLOTSTREAM_METAL_OBSERVER=str(P/'named-stage-check'))
r=subprocess.run([str(P/'named-stage-check')],env=env,capture_output=True,text=True,timeout=30);(P/'named-stage-check.log').write_text(r.stdout+r.stderr);assert r.returncode==0 and 'NAMED_STAGE_BYTES_PASS'in r.stdout
rows={}
for kind in ['pipelines','assignments','stages']:
 path=next(P.glob('named-stage-check.*.'+kind+'.csv'));lines=path.read_text().splitlines();rows[kind]=list(csv.DictReader(x for x in lines if not x.startswith('#')))
assert len(rows['pipelines'])==1 and rows['pipelines'][0]['name']=='named_stage_check'
assert len(rows['assignments'])==len(rows['stages'])==2
assert all(int(r['gpu_end'])>int(r['gpu_start'])>0 for r in rows['stages'])
receipt=dict(before=before,commands=cmds,passed=True,observed_pipelines=1,observed_assignments=2,observed_stages=2,scope='Weights-free observer byte/count check. Diagnostic only; does not change model/runtime/defaults.',files={n:hashlib.sha256((P/n).read_bytes()).hexdigest()for n in ['named_stage_observer.mm','named_stage_check.mm','named_stage_observer.dylib','named-stage-check']})
(P/'named-stage-build.json').write_text(json.dumps(receipt,indent=2));print('NAMED_STAGE_BUILD_CHECK_PASS')
