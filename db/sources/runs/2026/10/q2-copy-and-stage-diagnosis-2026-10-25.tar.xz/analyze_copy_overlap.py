from pathlib import Path
import bisect,collections,csv,json,re,statistics
P=Path(__file__).resolve().parent;R=P.parents[1]
def parsed(path):
 lines=path.read_text().splitlines(); footer=dict(t.split('=') for t in lines[-1][2:].split())
 assert int(footer['total'])<int(footer['cap']),(path,footer)
 return list(csv.DictReader(l for l in lines if not l.startswith('#'))),footer
def union(xs):
 out=[]
 for lo,hi in sorted(xs):
  if hi<=lo: continue
  if not out or lo>out[-1][1]:out.append([lo,hi])
  else:out[-1][1]=max(hi,out[-1][1])
 return out
def length(xs):return sum(b-a for a,b in xs)
def intersection(a,b):
 out=[];i=j=0
 while i<len(a) and j<len(b):
  lo,hi=max(a[i][0],b[j][0]),min(a[i][1],b[j][1])
  if hi>lo:out.append([lo,hi])
  if a[i][1]<b[j][1]:i+=1
  else:j+=1
 return out
def window(xs,lo,hi):return union((max(lo,a),min(hi,b))for a,b in xs if a<hi and b>lo)
def percentiles(values):
 v=sorted(values)
 return {str(p):v[min(len(v)-1,int((len(v)-1)*p/100))] for p in [0,50,90,99,100]}if v else {}
header=json.loads((R/'.build/smart-dflash-eval/gsq-header.json').read_text());extents=[]
for t in header['tensors']:
 m=re.fullmatch(r'blk\.(\d+)\.ffn_(gate|up|down)_exps\.weight',t['name'])
 if m:extents.append(dict(start=11024672+t['offset'],end=11024672+t['offset']+512*460800,layer=int(m[1]),piece={'gate':0,'up':1,'down':2}[m[2]]))
assert len(extents)==144;extents.sort(key=lambda x:x['start']);extent_starts=[x['start']for x in extents]
ledger=json.loads((P/'copy-overlap-ledger.json').read_text());report=[]
for e in ledger:
 label,arm=e['label'],e['arm'];data=json.loads((P/(label+'.json')).read_text());steps=[r for r in data['runs']if r['round']==1]
 def limits(r):return (r['start_ns']/1e9,r['end_ns']/1e9) if arm=='N' else (r['start'],r['end'])
 lo,hi=limits(steps[0])[0],limits(steps[-1])[1]
 reads,_=parsed(next(P.glob(label+'-reads.*.csv')));copies,_=parsed(next(P.glob(label+'-copies.*.csv')));stages,sfooter=parsed(next(P.glob(label+'-commands.*.stages.csv')))
 assert sfooter['cpu_initial']==sfooter['gpu_initial'] and sfooter['cpu_final']==sfooter['gpu_final']
 rr=[];by_thread=collections.defaultdict(list)
 for x in reads:
  r={k:(float(v)if k in ['start','end']else int(v)) for k,v in x.items()}
  if r['result']<65536:continue
  by_thread[r['thread']].append(r)
  if r['start']<hi and r['end']>lo:rr.append(r)
 for vv in by_thread.values():vv.sort(key=lambda x:x['end'])
 endings={t:[x['end']for x in vv]for t,vv in by_thread.items()}
 destinations=collections.Counter(x['destination']for x in rr)
 forecast={k for k,v in destinations.most_common(4)} if arm=='N' else set()
 cc=[]
 for x in copies:
  c={k:(float(v)if k in ['start','end']else v if k=='kind'else int(v))for k,v in x.items()}
  if not c['start']<hi or not c['end']>lo:continue
  c.update(category='unattributed',read_end=None,read_destination=None)
  vv=by_thread.get(c['thread'],[]);j=bisect.bisect_right(endings.get(c['thread'],[]),c['start'])-1
  if j>=0:
   read=vv[j]
   if read['destination']<=c['source'] and c['source']+c['bytes']<=read['destination']+read['result']:
    offset=read['offset']+c['source']-read['destination'];idx=bisect.bisect_right(extent_starts,offset)-1
    if idx>=0:
     tensor=extents[idx]
     if tensor['start']<=offset and offset+c['bytes']<=tensor['end'] and c['bytes']==460800 and (offset-tensor['start'])%460800==0:
      c.update(category='forecast'if read['destination']in forecast else 'demand',read_end=read['end'],read_destination=read['destination'],layer=tensor['layer'],piece=tensor['piece'],expert=(offset-tensor['start'])//460800)
  cc.append(c)
 ss=[(int(x['gpu_start'])/1e9,int(x['gpu_end'])/1e9)for x in stages if int(x['gpu_end'])>int(x['gpu_start'])>0]
 ss=[(a,b)for a,b in ss if a<hi and b>lo]
 ri=[(x['start'],x['end'])for x in rr];ci=[(x['start'],x['end'])for x in cc];wi=[(x['start'],x['end'])for x in cc if x['category']!='unattributed'];metrics=[]
 for step in steps:
  a,b=limits(step);ru,cu,gu,wu=[window(xs,a,b)for xs in [ri,ci,ss,wi]]
  chosen=[c for c in cc if a<=c['start']<b];demand=sum(c['category']=='demand' for c in chosen)
  metrics.append(dict(step=step['step'],width=step['width'],wall_seconds=b-a,read_union_seconds=length(ru),copy_union_seconds=length(cu),expert_copy_union_seconds=length(wu),gpu_stage_union_seconds=length(gu),copy_gpu_overlap_seconds=length(intersection(cu,gu)),expert_copy_gpu_overlap_seconds=length(intersection(wu,gu)),copy_read_overlap_seconds=length(intersection(cu,ru)),triple_overlap_seconds=length(intersection(intersection(cu,gu),ru)),copy_without_read_or_gpu_seconds=length(cu)-length(intersection(cu,union(ru+gu))),uncovered_seconds=b-a-length(union(ru+cu+gu)),demand_copies=demand,expected_demand_copies=3*step['records_fetched'],forecast_copies=sum(c['category']=='forecast'for c in chosen),unattributed_copies=sum(c['category']=='unattributed'for c in chosen)))
 categories={}
 for name in ['demand','forecast','unattributed']:
  xx=[c for c in cc if c['category']==name]
  categories[name]=dict(count=len(xx),bytes=sum(c['bytes']for c in xx),cpu_service_seconds=sum(c['end']-c['start']for c in xx),duration_us_percentiles=percentiles([(c['end']-c['start'])*1e6 for c in xx]),sizes=collections.Counter(c['bytes']for c in xx),read_to_copy_us_percentiles=percentiles([(c['start']-c['read_end'])*1e6 for c in xx if c['read_end'] is not None]))
 native_hashes=None
 if arm=='N':
  prior=json.loads((P/'commit-relaxed-0-B.json').read_text())['runs'];ref={(r['round'],r['step']):r['logits_sha256']for r in prior}
  native_hashes=all(r['logits_sha256']==ref[(r['round'],r['step'])]for r in data['runs']);assert native_hashes
 summary={k:sum(r[k]for r in metrics)for k in metrics[0]if k not in ['step','width']}
 result=dict(label=label,arm=arm,guard_eligible=e.get('eligible'),scope='Diagnostic localization, not qualified speed. CPU service sums overlap. GPU encoder timestamp intervals are not utilization. Same-thread last-completed read and exact GGUF extent required for copy attribution.',native_hashes_match=native_hashes,all_demand_counts_match=all(r['demand_copies']==r['expected_demand_copies']for r in metrics)if arm=='N'else None,summary=summary,categories=categories,forecast_destination_counts=[destinations[k]for k in forecast],passes=metrics)
 report.append(result);print(json.dumps({k:v for k,v in result.items()if k!='passes'},indent=2))
(P/'copy-overlap-analysis.json').write_text(json.dumps(report,indent=2))
