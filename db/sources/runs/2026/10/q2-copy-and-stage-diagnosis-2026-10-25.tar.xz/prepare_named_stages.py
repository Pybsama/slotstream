from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1]
s=(R/'.build/q2-handoff-20261025/stage_observer.mm').read_text()
s=s.replace('std::set<Class> devices, queues, commands, sharedEvents;', 'std::set<Class> devices, queues, commands, sharedEvents, computeEncoders;')
needle='void recordEvent(char kind, id buffer, id event, uint64_t value) {'
addition=r'''
constexpr size_t pipelineLimit=16384, assignmentLimit=2097152;
struct PipelineRecord { double stamp=0; uintptr_t pipeline=0; char name[384]={}; };
struct AssignmentRecord { double stamp=0; uintptr_t encoder=0,pipeline=0; };
PipelineRecord pipelineRecords[pipelineLimit];std::atomic<size_t> pipelineNext{0};
AssignmentRecord assignments[assignmentLimit];std::atomic<size_t> assignmentNext{0};
void recordPipeline(id pipeline,id<MTLFunction> function) {
  size_t i=pipelineNext.fetch_add(1);if(i>=pipelineLimit)return;
  pipelineRecords[i].stamp=now();pipelineRecords[i].pipeline=(uintptr_t)pipeline;
  snprintf(pipelineRecords[i].name,sizeof(pipelineRecords[i].name),"%s",function.name.UTF8String?:"");
}
void computeEncoder(id object) {
  if(!object)return;
  std::lock_guard lock(hooksMutex);Class cls=object_getClass(object);
  if(!computeEncoders.insert(cls).second)return;
  SEL sel=@selector(setComputePipelineState:);Method method=class_getInstanceMethod(cls,sel);if(!method)return;
  const IMP original=method_getImplementation(method);
  IMP wrapped=imp_implementationWithBlock(^(id encoder,id pipeline){
    const size_t i=assignmentNext.fetch_add(1);
    if(i<assignmentLimit)assignments[i]={now(),(uintptr_t)encoder,(uintptr_t)pipeline};
    reinterpret_cast<void(*)(id,SEL,id)>(original)(encoder,sel,pipeline);
  });class_replaceMethod(cls,sel,wrapped,method_getTypeEncoding(method));
}
void dumpPipelines(const char* prefix) {
  char path[4096];snprintf(path,sizeof(path),"%s.%d.pipelines.csv",prefix,getpid());FILE*f=fopen(path,"wx");if(!f)return;
  fprintf(f,"stamp,pipeline,name\n");const size_t n=pipelineNext.load();
  for(size_t i=0;i<std::min(n,pipelineLimit);++i){const auto&r=pipelineRecords[i];fprintf(f,"%.9f,%llu,\"%s\"\n",r.stamp,(unsigned long long)r.pipeline,r.name);}
  fprintf(f,"# total=%zu cap=%zu\n",n,pipelineLimit);fclose(f);
  snprintf(path,sizeof(path),"%s.%d.assignments.csv",prefix,getpid());f=fopen(path,"wx");if(!f)return;
  fprintf(f,"stamp,encoder,pipeline\n");const size_t m=assignmentNext.load();
  for(size_t i=0;i<std::min(m,assignmentLimit);++i){const auto&r=assignments[i];fprintf(f,"%.9f,%llu,%llu\n",r.stamp,(unsigned long long)r.encoder,(unsigned long long)r.pipeline);}
  fprintf(f,"# total=%zu cap=%zu\n",m,assignmentLimit);fclose(f);
}
'''
assert needle in s;s=s.replace(needle,addition+'\n'+needle)
s=s.replace('stages[i]={now(),(uintptr_t)buffer,(uintptr_t)encoder};[desc release];return encoder;','stages[i]={now(),(uintptr_t)buffer,(uintptr_t)encoder};computeEncoder(encoder);[desc release];return encoder;')
s=s.replace('  dumpStages(path);','  dumpStages(path);\n  dumpPipelines(path);')
needle='  if(!devices.insert(cls).second) return;'
addition=r'''
  {
    SEL ps=@selector(newComputePipelineStateWithFunction:error:);Method pm=class_getInstanceMethod(cls,ps);
    if(pm){const IMP originalPipeline=method_getImplementation(pm);
      IMP wrappedPipeline=imp_implementationWithBlock(^id(id d,id function,NSError** error){
        id result=reinterpret_cast<id(*)(id,SEL,id,NSError**)>(originalPipeline)(d,ps,function,error);
        if(result)recordPipeline(result,function);return result;
      });class_replaceMethod(cls,ps,wrappedPipeline,method_getTypeEncoding(pm));
    }
  }
'''
assert needle in s;s=s.replace(needle,needle+addition)
(P/'named_stage_observer.mm').write_text(s)
r=(P/'run_stages.py').read_text().replace("R/'.build/q2-handoff-20261025/stage_observer.dylib'","P/'named_stage_observer.dylib'").replace("P/'native-build-v3/candidate/slotstream'","P/'native-build-v4/candidate/slotstream'")
assert 'named_stage_observer.dylib'in r and 'native-build-v4'in r
(P/'run_named_stages.py').write_text(r)
