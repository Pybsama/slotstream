// Diagnostic only. Observe large CPU copies without changing their bytes,
// destination, ordering or scheduling. No model data is written to the log.
#include <atomic>
#include <algorithm>
#include <cerrno>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <mach/mach_time.h>
#include <pthread.h>
#include <unistd.h>
namespace {
constexpr size_t capacity = 1048576;
struct Record { uint64_t start, end, thread; uintptr_t destination, source; size_t bytes; char kind; };
Record records[capacity];
std::atomic<size_t> count{0};
std::atomic<bool> enabled{false};
thread_local bool inside = false;

template<bool Move> void* copy(void* destination, const void* source, size_t bytes) {
  if (!enabled.load(std::memory_order_relaxed) || bytes < 65536 || inside)
    return Move ? memmove(destination, source, bytes) : memcpy(destination, source, bytes);
  inside = true;
  const int savedErrno = errno;
  thread_local uint64_t thread = [] { uint64_t v=0; pthread_threadid_np(nullptr, &v); return v; }();
  const auto index = count.fetch_add(1, std::memory_order_relaxed);
  const auto start = mach_absolute_time();
  void* result = Move ? memmove(destination, source, bytes) : memcpy(destination, source, bytes);
  const auto end = mach_absolute_time();
  if (index < capacity) records[index] = {start, end, thread, uintptr_t(destination), uintptr_t(source), bytes, Move ? 'v' : 'c'};
  errno = savedErrno;
  inside = false;
  return result;
}
void* copied(void* destination, const void* source, size_t bytes) { return copy<false>(destination, source, bytes); }
void* moved(void* destination, const void* source, size_t bytes) { return copy<true>(destination, source, bytes); }
void dump() {
  enabled.store(false, std::memory_order_relaxed);
  const char* prefix = getenv("SLOTSTREAM_COPY_OBSERVER"); if (!prefix) return;
  char path[4096]; snprintf(path, sizeof(path), "%s.%d.csv", prefix, getpid());
  FILE* f = fopen(path, "wx"); if (!f) return;
  mach_timebase_info_data_t t; mach_timebase_info(&t);
  const double scale = double(t.numer) / t.denom / 1e9;
  fprintf(f, "start,end,thread,destination,source,bytes,kind\n");
  const auto total = count.load();
  for (size_t i=0; i<std::min(total,capacity); ++i) {
    const auto& r=records[i];
    fprintf(f,"%.9f,%.9f,%llu,%llu,%llu,%zu,%c\n",r.start*scale,r.end*scale,
      (unsigned long long)r.thread,(unsigned long long)r.destination,
      (unsigned long long)r.source,r.bytes,r.kind);
  }
  fprintf(f,"# total=%zu cap=%zu min_bytes=65536\n",total,capacity); fclose(f);
}
__attribute__((constructor)) void initialize() {
  if (getenv("SLOTSTREAM_COPY_OBSERVER")) { enabled.store(true); atexit(dump); }
}
}
__attribute__((used)) static struct { const void* replacement; const void* original; }
interposers[] __attribute__((section("__DATA,__interpose"))) = {
  {(const void*)&copied,(const void*)&memcpy},
  {(const void*)&moved,(const void*)&memmove}
};
