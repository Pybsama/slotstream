#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <cstdio>
int main(){ @autoreleasepool{
 id<MTLDevice>d=MTLCreateSystemDefaultDevice();NSError*error=nil;
 id<MTLLibrary>lib=[d newLibraryWithSource:@"#include <metal_stdlib>\nusing namespace metal; kernel void named_stage_check(device uint* a [[buffer(0)]],uint i [[thread_position_in_grid]]) {a[i]=i+7;}" options:nil error:&error];
 if(!lib){fprintf(stderr,"%s\n",error.description.UTF8String);return 1;}
 id<MTLFunction>fn=[lib newFunctionWithName:@"named_stage_check"];id<MTLComputePipelineState>p=[d newComputePipelineStateWithFunction:fn error:&error];if(!p)return 2;
 id<MTLBuffer>b=[d newBufferWithLength:4096 options:MTLResourceStorageModeShared];id<MTLCommandQueue>q=[d newCommandQueue];
 for(int j=0;j<2;++j){id<MTLCommandBuffer>cb=[q commandBuffer];id<MTLComputeCommandEncoder>e=[cb computeCommandEncoder];[e setComputePipelineState:p];[e setBuffer:b offset:0 atIndex:0];[e dispatchThreads:MTLSizeMake(1024,1,1) threadsPerThreadgroup:MTLSizeMake(128,1,1)];[e endEncoding];[cb commit];[cb waitUntilCompleted];if(cb.status!=MTLCommandBufferStatusCompleted)return 3;for(unsigned i=0;i<1024;++i)if(((unsigned*)b.contents)[i]!=i+7)return 4;}
 puts("NAMED_STAGE_BYTES_PASS");return 0;
}}
