from pathlib import Path
import hashlib,importlib.util,io,json,re,tarfile
P=Path(__file__).resolve().parent;R=P.parents[1];OLD=R/'.build/native-replay-20261023/v68'
spec=importlib.util.spec_from_file_location('identity',R/'Tools/build_identity.py');identity=importlib.util.module_from_spec(spec);spec.loader.exec_module(identity)
source=json.loads((OLD/'build-identity.json').read_text())['source'];assert source=={str(f.relative_to(R)):identity.sha(f)for f in identity.source_files(R)}
artifacts={n:identity.sha(R/'.build/release'/n)==identity.sha(OLD/n)for n in ['slotstream','slotstream-checks','mlx.metallib','build-identity.json','build-source.tar.gz']};assert all(artifacts.values())
copy=json.loads((P/'copy-overlap-analysis.json').read_text());named=json.loads((P/'named-stage-analysis.json').read_text())
assert all(x['guard_eligible']for x in copy+named);assert copy[0]['all_demand_counts_match']and copy[0]['native_hashes_match']and named[0]['native_full_hashes_exact']
extra=next(g for g in named[0]['groups']if g['signature']==['g1_copybfloat16bfloat16'])
assert extra['stages']==named[0]['total_stages']-111*147
(P/'copy-stage-findings.json').write_text(json.dumps(dict(scope='Diagnostic phase attribution only; no speed qualification or retained candidate.',runtime_inputs_equal_v68=len(source),default_artifacts=artifacts,retained_runtime_changes=False,fast_changed=False,extra_native_encoders=extra['stages'],extra_native_encoder_device_interval_seconds=extra['total_seconds'],all_extra_encoder_count_explained=True,copy_category_scope='Categories span first measured pass start through last measured pass end, including commit gaps. Per-pass summaries exclude gaps; 220 nonexpert copies lie in gaps.',threshold_conclusion='Extra encoder pattern survives high operation and byte limits together. No threshold change retained.',limits=['CPU copy service times overlap each other, reads and GPU stages.','GPU encoder intervals are not ALU utilization or individual kernel timings.','Named prepared projection functions are all run; no semantic identity inferred from that name.','Named-trace native offline preview was parsed after native ended and during Splash setup; no timing qualification is drawn from either instrumented pair.','Copy observer v1 bootstrap abort is an instrumentation failure, corrected and checked before any model run.','No complete requests or new semantic quality tests in this diagnostic; full frozen native logits remain exact.'],next_action='Phase-match same-binary/same-layout copy-on versus aligned-copy-free native verification at a fixed actual cache capacity, alongside Splash. Use named stages to test whether removed CPU transfers shorten overlapping expert GPU intervals. Prior direct-read complete-request rejection stands; do not revive its default from a component win.'),indent=2))
patterns=['commit-threshold-*','commit-ops-*','commit-relaxed-*','copy-observer-*','copy-overlap-*','named-stage-*','named-stages-*']
files={}
for pattern in patterns:
 for f in P.glob(pattern):
  if f.is_file()and f.suffix in ['.json','.log','.csv']and'archive-receipt'not in f.name:files[f.name]=f
for name in ['copy-stage-findings.json','run_commit_threshold.py','run_commit_ops.py','run_commit_relaxed.py','copy_observer.cpp','copy_observer-v1-tlv.cpp','copy_observer_check.cpp','build_copy_observer.py','build_copy_observer-v1.py','run_copy_overlap.py','analyze_copy_overlap.py','prepare_named_stages.py','named_stage_observer.mm','named_stage_check.mm','build_named_stages.py','run_named_stages.py','analyze_named_stages.py','archive_copy_stage_diagnosis.py','quiet_guarded_run.py','timed-2.json']:
 files[name]=P/name
for name,f in [('reference/native-build-identity.json',P/'native-build-v4/candidate/build-identity.json'),('reference/stage_observer.mm',R/'.build/q2-handoff-20261025/stage_observer.mm'),('reference/read_observer.cpp',R/'.build/q2-handoff-20261025/read_observer.cpp'),('reference/previous-sequence-archive.json',P/'copy-causal-frozen-12-archive-receipt.json')]:files[name]=f
secret=re.compile(rb'(?:ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{25,}|sk-(?:proj-)?[A-Za-z0-9_-]{30,}|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----)')
for f in files.values():assert f.exists()and not secret.search(f.read_bytes()),f
manifest={n:dict(bytes=f.stat().st_size,sha256=identity.sha(f))for n,f in files.items()};raw=json.dumps(manifest,indent=2).encode()+b'\n'
dest=R/'db/sources/runs/2026/10/q2-copy-and-stage-diagnosis-2026-10-25.tar.gz';assert not dest.exists()
with tarfile.open(dest,'w:gz')as t:
 for n,f in sorted(files.items()):t.add(f,arcname=n,recursive=False)
 info=tarfile.TarInfo('archive-manifest.json');info.size=len(raw);t.addfile(info,io.BytesIO(raw))
with tarfile.open(dest)as t:
 for n,m in manifest.items():
  raw=t.extractfile(n).read();assert len(raw)==m['bytes']and hashlib.sha256(raw).hexdigest()==m['sha256']
receipt=dict(path=str(dest.relative_to(R)),files=len(manifest),bytes=dest.stat().st_size,sha256=identity.sha(dest),readback_verified=True,credential_pattern_matches=0)
(P/'copy-stage-archive-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
