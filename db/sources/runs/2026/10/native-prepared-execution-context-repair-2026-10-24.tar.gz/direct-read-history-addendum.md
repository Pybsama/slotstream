

## Direct-read constraint from earlier evidence

The earlier [[records/measurements/expert-lookahead-2-slot-adoption-screen-2026-09-12]]
records kernel-level file-read stalls after an experiment reading directly into
GPU-shared pool storage. It did not isolate the cause. Removing the current
private scratch copy is therefore not an established safe speedup. A future
read-scheduler experiment must preserve bounded buffer ownership, completion
and failure draining, and separately qualify any changed file-read destination.
The remaining shared-reader scheduling hypothesis can be tested without first
reintroducing that destination change.

The final upstream logs explicitly report that the host-step spin library is
absent and GPU keepawake is disabled. The comparison harness asserts the
library is absent before each arm. The observed Q2 gap is not evidence that
this study accidentally compared against an enabled upstream GPU keepalive.
