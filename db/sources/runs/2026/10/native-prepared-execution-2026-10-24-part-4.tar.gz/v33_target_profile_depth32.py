import json,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1]
ledger=[]
for model in ['smart-q2']:
 label='v33-depth32-cached-profile-'+model
 command=[sys.executable,str(P/'guarded_run.py'),'--label',label,'--budget','15','--timeout','600',
  '--env','SLOTSTREAM_NATIVE_DEFERRED_ROUTES=1','--env','SLOTSTREAM_DECODE_BARRIER_LAYERS=32','--',str(P/'v33/slotstream'),'q2-profile','--model',model,
  '--memory-gb','15','--rounds','3','--fixture',str(P/('v29-profile-'+model+'-fixture.json')),'--output',str(P/(label+'.json'))]
 with(P/(label+'-driver.log')).open('x')as out:r=subprocess.run(command,cwd=R,stdout=out,stderr=subprocess.STDOUT)
 ledger.append(dict(label=label,command=command,exit_code=r.returncode));(P/'v33-depth32-target-profile-ledger.json').write_text(json.dumps(ledger,indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)

 data=json.loads((P/(label+'.json')).read_text())
 assert len(data['runs'])==32
 assert all(x['max_logit_difference']==0 and x['argmax_equal'] for x in data['runs']), 'Traced and ordinary target outputs diverged'
 print('PROFILE EXACT-OUTPUT CHECK PASSED', model, flush=True)
