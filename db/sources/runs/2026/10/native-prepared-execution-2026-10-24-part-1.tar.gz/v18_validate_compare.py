import json,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1]
assert json.loads((P/'v18-build-retry1-receipt.json').read_text())['exit_code']==0
commands=[('v18-core',[sys.executable,str(P/'v18_core.py')]),('v18-smart-q29-splash',[sys.executable,str(P/'native_splash_compare_v18.py'),'--label','v18-smart-q29-splash','--native',str(P/'v18/slotstream'),'--model','smart-q2','--budget','9'])]
for label,command in commands:
 print('START',label,flush=True)
 with (P/(label+'-driver.log')).open('x')as log:r=subprocess.run(command,cwd=R,stdout=log,stderr=subprocess.STDOUT)
 print('END',label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
subprocess.run([sys.executable,str(P/'comparison_summary.py'),'v18-smart-q29-splash'],cwd=R,check=True)
