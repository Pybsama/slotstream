from pathlib import Path
R=Path(__file__).resolve().parents[2]
p=R/'Sources/slotstream-cli/NativeExpertsChecks.swift';s=p.read_text();needle='    let wideRoutes = [Int32](repeating: 2, count: 641 * 8)'
assert needle in s
s=s.replace(needle,'''    // More live leases than the event-cache bound, with publications in
    // reverse order. No newer command may reuse an unpublished event.
    let schedule = try NativeExpertSchedule.plan(hidden: h, intermediate: m, affine: true)
    let eventInput = MLXArray((0..<h).map { bf(Float($0 % 17 - 8) / 64) }, [1, h]).asType(.bfloat16)
    let eventReference = NativeExpertTiles.apply(eventInput, weights: packed, ids: [1], repeatInput: 1,
        hidden: h, intermediate: m, affine: true).asArray(Float.self)
    let beforeHits = NativeExpertSchedule.eventStats.created
    for _ in 0..<4 {
        guard try schedule.apply(eventInput, weights: packed, ids: [1], repeatInput: 1).asArray(Float.self) == eventReference else {
            throw ValidationError("All-hit event-free dispatch changed output")
        }
    }
    guard NativeExpertSchedule.eventStats.created == beforeHits else {
        throw ValidationError("All-hit commands allocated host-ready events")
    }
    for _ in 0..<2 {
        var pending: [NativeExpertSchedule.Pending] = []
        for _ in 0..<70 {
            pending.append(try schedule.submit(eventInput, weights: packed, ids: [1], repeatInput: 1, awaitingReads: true))
        }
        var outputs: [MLXArray] = []
        for command in pending.reversed() { outputs.append(try command.value()) }
        eval(outputs)
        for output in outputs where output.asArray(Float.self) != eventReference {
            throw ValidationError("Out-of-order publication crossed event leases")
        }
    }
    let eventStats = NativeExpertSchedule.eventStats
    guard eventStats.reused > 0, eventStats.cached <= 64 else {
        throw ValidationError("Host-ready event cache did not reuse a bounded set")
    }
    print("Native ready events: hit elision, 70 concurrent leases, reverse publication, reuse and bound PASS")
''' + needle)
p.write_text(s)
p=R/'Sources/CNativeSchedule/NativeSchedule.cpp';s=p.read_text().replace('[lease = job_->lease](MTL::CommandBuffer*) {}','[lease = job_->lease](MTL::CommandBuffer*) { (void)lease; }');p.write_text(s)
P=R/'.build/native-replay-20261023'
for name in ['v15_core.py','v15_plain.py','native_splash_compare_v15.py','v15_quality.py']:
 (P/name.replace('15','16')).write_text((P/name).read_text().replace('v15','v16'))
print('Prepared v16 correctness, target-only, comparison and quality harnesses.')
