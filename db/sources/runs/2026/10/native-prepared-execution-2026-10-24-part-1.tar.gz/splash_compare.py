import argparse,json,os,subprocess,sys,time,hashlib
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight,vm_snapshot,host_conditions,terminate_child_tree
sys.path.insert(0,str(R/'.build/native-q2-20261021'));from thermal import state,wait_nominal
ap=argparse.ArgumentParser();ap.add_argument('--label',required=True);ap.add_argument('--native',required=True);ap.add_argument('--order',default='ABBA');ap.add_argument('--budget',type=float,default=9);ap.add_argument('--cases',default=str(P/'short-warm-cases.json'));ap.add_argument('--context',type=int,default=8192);ap.add_argument('--ahead',default='off',choices=['off','reserve','on']);ap.add_argument('--model',required=True,choices=['fast','smart-q2']);ap.add_argument('--schedule',choices=['0','1'],default='1');a=ap.parse_args()
ledger=P/(a.label+'-ledger.json');assert not ledger.exists();events=[];cache_path=P/(a.label+'-cache.json');tokenpath=P/(a.label+'-tokens.json')
for index,arm in enumerate(a.order):
 label=a.label+'-'+str(index)+'-'+arm;out=P/(label+'.json');assert not out.exists()
 wait_nominal(P/(label+'-cooldown.json'))
 before=dict(vm=preflight(a.budget+3),thermal=state(),host=host_conditions());assert before['thermal']==0
 if arm=='A':
  command=[sys.executable,str(P/'guarded_run.py'),'--label',label+'-guard','--budget',str(a.budget),'--env','SLOTSTREAM_NATIVE_EXPERT_SCHEDULE='+a.schedule,'--',str(Path(a.native).resolve()),'smart-dflash-check','--native-read-ahead','on' if a.model=='smart-q2' else 'off','--method','q2' if a.model=='smart-q2' else 'fast','--model',a.model,'--memory-gb',str(a.budget),'--max-context',str(a.context),'--cases',str(Path(a.cases).resolve()),'--output',str(out)]
 else:
  cache=json.loads(cache_path.read_text())
  command=[sys.executable,str(P/('q2_upstream_bench.py' if a.model=='smart-q2' else 'upstream_bench.py')),'--memory-gb',str(a.budget),'--verify','auto','--kv','bf16','--cases',str(Path(a.cases).resolve()),'--tokens',str(tokenpath),'--output',str(out),'--context',str(a.context),'--expert-memory',str(cache['expert_memory']),'--ple-memory','51200000','--expected-slots',str(cache['slots'])]
 print('START',label,flush=True)
 with (P/(label+'-launcher.log')).open('x') as log:
  child=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:rc=child.wait(timeout=1800)
  finally:
   if child.poll() is None:terminate_child_tree(child)
 after=dict(vm=vm_snapshot(),thermal=state());event=dict(label=label,arm=arm,command=command,before=before,after=after,exit_code=rc,runs=[])
 if out.exists():
  d=json.loads(out.read_text())
  if arm=='A':
   slots=d['plan']['pool_slots'];cache={'slots':slots,'expert_memory':(3*(slots*409600+((slots*51200+16383)//16384)*16384)+471859200+98304+14336+16+32*(512+22)*4 if a.model=='smart-q2' else slots*1769472+465567744+40960+7168+16+32*(257+18)*4+4096)};tokens={'runs':[dict(id=r['id'],prompt_ids=r['prompt_ids'])for r in d['runs']]}
   for file,value in [(cache_path,cache),(tokenpath,tokens)]:
    if file.exists() and d.get('complete'):assert json.loads(file.read_text())==value
    else:file.write_text(json.dumps(value,indent=2))
   for row in d['runs']:
    s=row['stats'];assert row['native_expert_scheduled_passes']>0 if a.schedule=='1' else row['native_expert_scheduled_passes']==0;event['runs'].append(dict(id=row['id'],tokens=len(row['tokens']),tps=(s['decodeTokens']-1)/s['decodeSeconds'],request_seconds=row['elapsed_seconds'],prefill_seconds=s['prefillSeconds'],reused=s['reusedPrefixTokens'],paging=bool(row['swapins_delta']or row['swapouts_delta']),peak_gb=s['peakMemoryGB']))
  else:
   assert d['status_ready']['streamed_experts']['slots']==json.loads(cache_path.read_text())['slots']
   for row in d['runs']:
    t=row['timings'];event['runs'].append(dict(id=row['id'],tokens=row['usage']['completion_tokens'],tps=row['metrics']['decode']['tokens']/(t['predicted_ms']/1000),request_seconds=row['elapsed_seconds'],prefill_seconds=t['prompt_ms']/1000,reused=t['cache_n'],paging=bool(row['swapins_delta']or row['swapouts_delta']),peak_gb=d['peak_combined_bytes']/1e9))
  event['complete']=d.get('complete',False)
  event['thermal_nominal']=before['thermal']==after['thermal']==0
  event['eligible']=rc==0 and event['complete'] and len([r for r in event['runs']if r['id'].startswith('timed')])==2 and event['thermal_nominal'] and all(not r['paging'] and r['reused']==0 and r['tokens']==512 and r['peak_gb']<=a.budget for r in event['runs']if r['id'].startswith('timed'))
 events.append(event);ledger.write_text(json.dumps(events,indent=2));print('END',label,'eligible',event.get('eligible'),'rates',[(r['id'],round(r['tps'],2),r['paging'],r['reused'])for r in event['runs']],flush=True)
 if rc:raise SystemExit(rc)
