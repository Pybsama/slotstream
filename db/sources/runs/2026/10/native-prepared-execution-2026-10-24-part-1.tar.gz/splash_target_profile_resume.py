import json,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];D=P/'splash-q2-target-profile'
cache=json.loads((P/'v29b-default-smart-q215-splash-cache.json').read_text())
fixture=json.loads((P/'v29-profile-smart-q2-fixture.json').read_text())
prepared=R/'.build/smart-dflash-eval/upstream-prepared/.resolved/938d6d6879dac79e95a5eae858867e0af230dc252a18266c6aefb6732b65dee7'
cmd=[sys.executable,str(P/'guarded_run.py'),'--label','splash-q2-target-profile','--budget','15','--timeout','600','--',sys.executable,str(P/'with_model_lock.py'),str(D/'decode-profile'),str(D/'splash.metallib'),str(prepared),'--prompt-tokens',str(len(fixture['prompt_ids'])),'--cycles','3','--kv-format','bf16','--state-format','fp32','--expert-memory',str(cache['expert_memory']),'--ple-memory','51200000','--dispatch-list',str(D/'dispatches.txt')]
with(D/'run.log').open('x')as log:r=subprocess.run(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT)
ledger=json.loads((D/'ledger.json').read_text());ledger.append(dict(label='run',command=cmd,exit_code=r.returncode));(D/'ledger.json').write_text(json.dumps(ledger,indent=2)+'\n')
raise SystemExit(r.returncode)
