from pathlib import Path
p=Path('Sources/slotstream-cli/NativeSchedulePoolChecks.swift');s=p.read_text();s=s.replace('func scheduled(_ keys: [ExpertKey]) throws -> (MLXArray, [Int32]) {','var lastRepacked = 0\n    func scheduled(_ keys: [ExpertKey]) throws -> (MLXArray, [Int32]) {');s=s.replace('let value = try pending.value()','lastRepacked = pending.staging?.copiedSlots.count ?? 0\n        let value = try pending.value()')
point='''    pool.directDemandReads = false'''
new='''    if store.isQ2, NativeExpertSchedule.enabled, NativeExpertSchedule.gpuStagingEnabled {
        pool.unpinAll()
        let configuration = NativeInputReadAhead.configuration(reservedBytes: NativeInputReadAhead.reserveBytes, topK: cfg.topK)
        let scheduler = ExpertPrefetchScheduler(store: store, pool: pool, configuration: configuration,
            predictor: nil, layers: cfg.numLayers, experts: cfg.numExperts)
        guard scheduler.stagesRawQ2 else { throw ValidationError("Raw forecast branch was not selected") }
        let session = ExpertLookaheadSession()
        session.prefetch = scheduler; pool.lookahead = session
        defer { scheduler.close(); pool.lookahead = nil }
        func forecast(_ expert: Int) throws {
            session.beginPass(phase: .mainVerify, tokens: [1], features: [])
            scheduler.forecast(target: 1, ids: [Int32(expert)], margins: [])
            let deadline = Date().addingTimeInterval(5)
            while scheduler.diagnosticState(ExpertKey(1, expert)) != .ready && Date() < deadline {
                Thread.sleep(forTimeInterval: 0.001)
            }
            guard scheduler.diagnosticState(ExpertKey(1, expert)) == .ready else {
                throw ValidationError("Raw forecast did not finish within its bounded wait")
            }
        }
        try forecast(3)
        let adopted = pool.recordsAdopted
        _ = try scheduled([ExpertKey(0, 30), ExpertKey(1, 3), ExpertKey(1, 4)])
        guard pool.recordsAdopted == adopted + 1, lastRepacked == 2 else {
            throw ValidationError("Mixed hit, raw forecast and demand did not reach the GPU")
        }
        pool.unpinAll(); session.endPass()
        // A caller outside the prepared GPU path must still receive prepared
        // pool bytes when adopting a raw forecast ticket.
        try forecast(6)
        let key = ExpertKey(1, 6), slots = try pool.ensureChecked([key])
        let reference = try store.readBatchChecked([key])
        for piece in reference.indices {
            guard (pool.pools[piece][MLXArray(slots.map(Int32.init))] .== reference[piece]).all().item(Bool.self) else {
                throw ValidationError("Unscheduled adoption interpreted raw bytes as prepared weights")
            }
        }
        pool.unpinAll(); session.endPass()
        try forecast(8)
        pool.readFault = ReadFault(afterJobs: 0)
        let failing = [ExpertKey(1, 8), ExpertKey(1, 9)]
        do {
            _ = try scheduled(failing)
            throw ValidationError("Demand failure after a raw adoption was ignored")
        } catch is CheckpointReadError {}
        guard pool.readFault?.hasFired == true, pool.pinnedSlotCount == 0,
              failing.allSatisfy({ !pool.isResident($0) }) else {
            throw ValidationError("Failed demand published an adopted but unprepared raw ticket")
        }
        pool.readFault = nil
        _ = try scheduled(failing)
        pool.unpinAll(); session.endPass(); scheduler.requestFinished()
        guard scheduler.accounting.liveBytes == 0 else { throw ValidationError("Raw forecast staging leaked") }
        print("Raw Q2 forecast: mixed demand, unscheduled adoption, failure recovery and independent bytes PASS")
    }
    pool.directDemandReads = false'''
assert point in s;s=s.replace(point,new,1);p.write_text(s)
p=Path('Sources/Slotstream/ExpertStore.swift');s=p.read_text().replace('// prepared bytes. Wrong predictions never evict slots.','// bytes in its scheduler-declared representation. Wrong\n                        // predictions never evict slots.');p.write_text(s)
P=Path('.build/native-replay-20261023')
for a in ['core','plain']:
 s=(P/f'v14_{a}.py').read_text().replace('v14','v15')
 if a=='core':s=s.replace("'--env','SLOTSTREAM_NATIVE_PROJECTION_SCHEDULE=1'","'--env','SLOTSTREAM_NATIVE_PROJECTION_SCHEDULE=1','--env','SLOTSTREAM_NATIVE_EXPERT_SCHEDULE=1','--env','SLOTSTREAM_NATIVE_GPU_STAGING=1'")
 (P/f'v15_{a}.py').write_text(s)
(P/'native_splash_compare_v15.py').write_text((P/'native_splash_compare_v14.py').read_text())
