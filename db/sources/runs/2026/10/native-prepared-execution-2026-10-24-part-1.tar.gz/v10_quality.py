import json,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];B=P/'v10/slotstream'
sys.path.insert(0,str(R/'.build/native-q2-20261021'));from grade_v2 import grade
cases=R/'.build/fast-parity-20261022/quality-and-functional-cases.json'
for model,method in [('fast','fast'),('smart-q2','q2')]:
 label='v10-native-quality-'+model;out=P/(label+'.json')
 cmd=[sys.executable,str(P/'guarded_run.py'),'--label',label,'--budget','9','--env','SLOTSTREAM_NATIVE_EXPERT_SCHEDULE=1','--env','SLOTSTREAM_NATIVE_PROJECTION_SCHEDULE=1','--',str(B),'smart-dflash-check','--native-read-ahead',('on' if method=='q2' else 'off'),'--method',method,'--model',model,'--memory-gb','9','--cases',str(cases),'--output',str(out)]
 print('START',label,flush=True);result=subprocess.run(cmd,cwd=R);print('END',label,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
 g=grade(out);(P/(label+'-grades.json')).write_text(json.dumps(g,indent=2))
 d=json.loads(out.read_text());rows=d['runs'];r={x['id']:x for x in rows}
 def parsed(text):
  try:return json.loads(text)
  except ValueError:return None
 tools=r['native-tool']['tool_calls']
 checks=dict(native_projection_valid=all(x['native_projection_schedule_failures']==0 and x['stats']['nativeExecution']['projectionFailures']==0 for x in rows),native_expert_exercised=any(x['native_expert_scheduled_passes']>0 for x in rows),read_ahead_policy=(all(x['stats'].get('expertPrefetch',{}).get('issued',0)==0 for x in rows) if model=='fast' else any(x['stats'].get('expertPrefetch',{}).get('issued',0)>0 for x in rows)), recall=r['conversation-recall']['text'].strip()=='CEDAR-2481',
  cancelled=r['cancel']['callbacks']==12,after_cancel=parsed(r['after-cancel']['text'])=={'ok':True},
  stop=r['stop-string']['text'].strip()=='one two three',
  one_native_tool=len(tools)==1 and tools[0]['name']=='lookup_record' and parsed(tools[0]['arguments_json'])=={'key':'CEDAR-2481'},
  streams=all(x['streamed']==x['text']for x in rows),
  bounded=all(x['stats']['peakMemoryGB']<=9 and not x['stats']['memoryPressureCancelled']and not x['stats'].get('runtimeError')for x in rows),
  long_retrieval=all(parsed(r[k]['text'])=={'audit_code':'PINE-3926'}for k in ('long-retrieval','long-retrieval-repeat')),
  prefix_reuse=r['long-retrieval-repeat']['stats']['reusedPrefixTokens']>0)
 audit=dict(source=out.name,requests=len(rows),checks=checks,passed=all(checks.values()))
 (P/(label+'-functional.json')).write_text(json.dumps(audit,indent=2));print('GRADE',model,g['semantic'],g['strict'],'FUNCTIONAL',checks,flush=True)
