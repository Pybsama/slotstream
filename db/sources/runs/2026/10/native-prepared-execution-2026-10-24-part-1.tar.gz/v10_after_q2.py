import json,os,signal,subprocess,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1]
owned=json.loads((P/'v10-controller-paused.json').read_text())
# The controller is stopped while its child completes the frozen comparison.
# Let the child finish before terminating the waiting controller.
start=time.monotonic()
while True:
 ledger=P/'v10-smart-q29-splash-ledger.json'
 if ledger.exists() and len(json.loads(ledger.read_text()))==4:break
 if time.monotonic()-start>1200:raise RuntimeError('Q2 comparison did not finish; preserve controller for inspection')
 time.sleep(2)
parent=owned['pid']
check=subprocess.run(['ps','-p',str(parent),'-o','command='],capture_output=True,text=True)
assert check.stdout.strip().endswith('/native-replay-20261023/v10_sequence.py')
os.kill(parent,signal.SIGTERM);os.kill(parent,signal.SIGCONT)
time.sleep(2)
assert not any(x.rstrip().endswith(('/slotstream','/splash'))for x in subprocess.run(['ps','-axo','comm='],capture_output=True,text=True).stdout.splitlines())
label='v10-q2-submit9'
cmd=[sys.executable,str(P/'commit_ablation_v10.py'),'--label',label,'--native',str(P/'v10/slotstream'),'--model','smart-q2','--budget','9']
with (P/(label+'-driver.log')).open('x') as f:r=subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT)
print('SUBMISSION_ABLATION',r.returncode,flush=True)
raise SystemExit(r.returncode)
