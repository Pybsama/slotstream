import json,subprocess,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
ledger=json.loads((P/'v17-fast9-splash-ledger.json').read_text())
assert len(ledger)==4 and all(x['complete'] and x['exit_code']==0 for x in ledger)
receipt={'preflight':preflight(12),'command':['make','build','SLOTSTREAM_BUILD_JOBS=4']}
start=time.monotonic()
with (P/'v18-build.log').open('x') as log:r=subprocess.run(receipt['command'],cwd=R,stdout=log,stderr=subprocess.STDOUT)
receipt.update(exit_code=r.returncode,seconds=time.monotonic()-start)
(P/'v18-build-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
raise SystemExit(r.returncode)
