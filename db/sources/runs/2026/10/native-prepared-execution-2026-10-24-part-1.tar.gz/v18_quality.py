import json,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];B=P/'v18/slotstream'
sys.path.insert(0,str(R/'.build/native-q2-20261021'));from grade_v2 import grade
cases=R/'.build/fast-parity-20261022/quality-and-functional-cases.json'
for model,method in [('fast','fast'),('smart-q2','q2')]:
 label='v18-native-quality-'+model;out=P/(label+'.json')
 cmd=[sys.executable,str(P/'guarded_run.py'),'--label',label,'--budget','9','--env','SLOTSTREAM_NATIVE_EXPERT_SCHEDULE=1','--env','SLOTSTREAM_NATIVE_PROJECTION_SCHEDULE=1','--env','SLOTSTREAM_ADAPTIVE_REPLACEMENT=1','--env','SLOTSTREAM_NATIVE_GPU_STAGING=1','--',str(B),'smart-dflash-check','--native-read-ahead',('on' if method=='q2' else 'off'),'--method',method,'--model',model,'--memory-gb','9','--max-context','8192','--cases',str(cases),'--output',str(out)]
 print('START',label,flush=True);result=subprocess.run(cmd,cwd=R);print('END',label,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
 g=grade(out);(P/(label+'-grades.json')).write_text(json.dumps(g,indent=2))
 d=json.loads(out.read_text());rows=d['runs'];r={x['id']:x for x in rows}
 def parsed(text):
  try:return json.loads(text)
  except ValueError:return None
 tools=r['native-tool']['tool_calls']
 checks=dict(gpu_staging=(model!='smart-q2' or any(x['stats']['nativeExecution'].get('gpuRepackedRecords',0)>0 for x in rows)),raw_forecast=(model!='smart-q2' or any(':raw-q2' in x['stats'].get('expertPrefetch',{}).get('predictorIdentity','')for x in rows)),native_projection_valid=all(x['native_projection_schedule_failures']==0 and x['stats']['nativeExecution']['projectionFailures']==0 for x in rows),native_expert_exercised=any(x['native_expert_scheduled_passes']>0 for x in rows),read_ahead_policy=(all(x['stats'].get('expertPrefetch',{}).get('issued',0)==0 for x in rows) if model=='fast' else any(x['stats'].get('expertPrefetch',{}).get('issued',0)>0 for x in rows)), recall=r['conversation-recall']['text'].strip()=='CEDAR-2481',
  cancelled=r['cancel']['callbacks']==12,after_cancel=parsed(r['after-cancel']['text'])=={'ok':True},
  stop=r['stop-string']['text'].strip()=='one two three',
  one_native_tool=len(tools)==1 and tools[0]['name']=='lookup_record' and parsed(tools[0]['arguments_json'])=={'key':'CEDAR-2481'},
  streams=all(x['streamed']==x['text']for x in rows),
  bounded=all(x['stats']['peakMemoryGB']<=9 and not x['stats']['memoryPressureCancelled']and not x['stats'].get('runtimeError')for x in rows),
  long_retrieval=all(parsed(r[k]['text'])=={'audit_code':'PINE-3926'}for k in ('long-retrieval','long-retrieval-repeat')),
  prefix_reuse=r['long-retrieval-repeat']['stats']['reusedPrefixTokens']>0)
 audit=dict(source=out.name,requests=len(rows),checks=checks,passed=all(checks.values()))
 (P/(label+'-functional.json')).write_text(json.dumps(audit,indent=2));print('GRADE',model,g['semantic'],g['strict'],'FUNCTIONAL',checks,flush=True)

# Matched quality baselines: exact prompts, target/draft, context, budget and slots.
for model,method in [('fast','fast'),('smart-q2','q2')]:
 current=P/('v18-native-quality-'+model+'.json')
 d=json.loads(current.read_text());slots=d['plan']['pool_slots']
 quality=R/'.build/fast-parity-20261022/final-quality-cases.json'
 label='v18-old-quality-'+model;out=P/(label+'.json')
 cmd=[sys.executable,str(P/'guarded_run_io.py'),'--label',label,'--budget','9','--',str(P/'v1c/slotstream'),'smart-dflash-check','--native-read-ahead',('on' if method=='q2' else 'off'),'--method',method,'--model',model,'--memory-gb','9','--max-context','8192','--cases',str(quality),'--output',str(out)]
 print('START',label,flush=True);result=subprocess.run(cmd,cwd=R)
 if result.returncode:raise SystemExit(result.returncode)
 old=json.loads(out.read_text());assert old['complete'] and old['plan']['pool_slots']==slots
 assert {x['id']:x['prompt_ids']for x in old['runs']}=={x['id']:x['prompt_ids']for x in d['runs']if x['id'].startswith('q-')}
 (P/(label+'-grades.json')).write_text(json.dumps(grade(out),indent=2))
 expert=(3*(slots*409600+((slots*51200+16383)//16384)*16384)+471859200+98304+14336+16+32*(512+22)*4 if model=='smart-q2' else slots*1769472+465567744+40960+7168+16+32*(257+18)*4+4096)
 label='v18-splash-quality-'+model;out=P/(label+'.json')
 cmd=[sys.executable,str(P/('q2_upstream_bench_io.py' if model=='smart-q2' else 'upstream_bench_io.py')),'--memory-gb','9','--verify','auto','--kv','bf16','--context','8192','--expert-memory',str(expert),'--ple-memory','51200000','--expected-slots',str(slots),'--cases',str(quality),'--tokens',str(current),'--output',str(out)]
 print('START',label,flush=True);result=subprocess.run(cmd,cwd=R)
 if result.returncode:raise SystemExit(result.returncode)
 reference=json.loads(out.read_text());assert reference['complete'] and reference['status_ready']['streamed_experts']['slots']==slots
 (P/(label+'-grades.json')).write_text(json.dumps(grade(out),indent=2))
