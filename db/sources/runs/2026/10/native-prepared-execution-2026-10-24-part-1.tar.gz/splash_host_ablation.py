import json,subprocess,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight,vm_snapshot,host_conditions,terminate_child_tree
sys.path.insert(0,str(R/'.build/native-q2-20261021'));from thermal import state,wait_nominal
label='splash-host-wait-q215';events=[];ledger=P/(label+'-ledger.json');assert not ledger.exists()
base=P/'v22-default-smart-q215-splash'
cache=json.loads(Path(str(base)+'-cache.json').read_text())
for index,arm in enumerate('ABBA'):
 name=label+'-'+str(index)+'-'+arm;binary=P/('splash-host-base'if arm=='A'else'splash-host-wait')/'splash'
 wrapper=P/(name+'-wrapper.py');assert not wrapper.exists()
 wrapper.write_text('from pathlib import Path\nimport q2_upstream_bench_io as bench\nbench.ENGINE=Path('+repr(str(binary))+')\nbench.main()\n')
 wait_nominal(P/(name+'-cooldown.json'))
 before=dict(vm=preflight(18),thermal=state(),host=host_conditions());assert before['thermal']==0
 output=P/(name+'.json')
 command=[sys.executable,str(wrapper),'--memory-gb','15','--verify','auto','--kv','bf16',
  '--cases',str(P/'short-warm-384-cases.json'),'--tokens',str(base)+'-tokens.json','--output',str(output),
  '--context','8192','--expert-memory',str(cache['expert_memory']),'--ple-memory','51200000','--expected-slots',str(cache['slots'])]
 print('START',name,flush=True)
 with(P/(name+'-launcher.log')).open('x')as log:
  result=subprocess.Popen(command,cwd=R,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try: result.wait(timeout=1800)
  finally:
   if result.poll()is None:terminate_child_tree(result)
 after=dict(vm=vm_snapshot(),thermal=state());d=json.loads(output.read_text())
 rows=[dict(id=r['id'],tokens=r['usage']['completion_tokens'],tps=r['metrics']['decode']['tokens']/(r['timings']['predicted_ms']/1000),
  request_seconds=r['elapsed_seconds'],reused=r['timings']['cache_n'],paging=bool(r['swapins_delta']or r['swapouts_delta']),
  speculation=r['metrics'].get('speculation'))for r in d['runs']]
 event=dict(label=name,arm=arm,host_spin_ms=5 if arm=='A'else 0,command=command,before=before,after=after,
  complete=d.get('complete',False),exit_code=result.returncode,runs=rows,
  process_paging=any(before['vm'][k]!=after['vm'][k]for k in ['swapins','swapouts']),thermal_nominal=before['thermal']==after['thermal']==0)
 event['eligible']=event['complete']and result.returncode==0 and not event['process_paging']and event['thermal_nominal']and len(rows)==4 and all(not r['paging']and r['reused']==0 and r['tokens']==384 for r in rows)and d['peak_combined_bytes']<=15e9
 events.append(event);ledger.write_text(json.dumps(events,indent=2)+'\n')
 print('END',name,event['eligible'],[(r['id'],round(r['tps'],2))for r in rows],flush=True)
 if result.returncode:raise SystemExit(result.returncode)
print('Completed host-wait ablation. Both arms are rebuilt Splash controls, not Slotstream.',flush=True)
