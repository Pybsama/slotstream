from pathlib import Path
import q2_upstream_bench_io as bench
bench.ENGINE=Path('/Users/carlos/Projects/slotstream/.build/native-replay-20261023/splash-host-base/splash')
bench.main()
