import fcntl, hashlib, json, os, shutil, subprocess, sys
from pathlib import Path
P=Path(__file__).resolve().parent; R=P.parents[1]
sys.path.insert(0,str(R/'Tools')); from prefill_bench import preflight
W=Path('/var/folders/d4/t1c8ltbx5s3_11cs9y6gjh8m0000gp/T/slotstream-splash-host-ugnf26pi/source')
D=P/'splash-q2-target-profile'; D.mkdir(exist_ok=False)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()=='1482f6bbc2abf12375332725302019594150b6cb'
assert 'kHostStepSpin = std::chrono::milliseconds(0)' in (W/'runtime/metal/MetalBackend.mm').read_text()
fixture=json.loads((P/'v29-profile-smart-q2-fixture.json').read_text())
prompt=fixture['prompt_ids']; assert 16<=len(prompt)<=512
original=(W/'dev/benchmarks/decode_profile.mm').read_text(); source=original
changes={
 'const uint32_t extentPages = kvLayout.maximumExtentPages();':'const uint32_t extentPages = kvLayout.minimumExtentPages();',
 '(pagesPerLane * 4 + extentPages - 1)':'(pagesPerLane + extentPages - 1)',
 'backend, backend.capabilities().recommendedMaxWorkingSetBytes, 1, 1,':'backend, 15000000000ULL, 1, 1,',
 'std::array<Lane, 4> lanes;':'std::array<Lane, 1> lanes;',
 'const std::vector<uint32_t> prompt = chatPrompt(promptTokens);':'const std::vector<uint32_t> prompt = {'+','.join(map(str,prompt))+'};'
}
for before,after in changes.items():
 assert source.count(before)==1,before
 source=source.replace(before,after)
(D/'decode_profile.mm').write_text(source)
(D/'original_decode_profile.mm').write_text(original)
events=[]
def run(label,command,cwd=R):
 preflight(18 if label=='run' else 12)
 with(D/(label+'.log')).open('x')as log:r=subprocess.run(command,cwd=cwd,stdout=log,stderr=subprocess.STDOUT)
 events.append(dict(label=label,command=command,exit_code=r.returncode))
 (D/'ledger.json').write_text(json.dumps(events,indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
run('instrumented-backend',['make','-j4','build/engine/metal/MetalBackendInstrumented.o'],W)
run('link',['xcrun','-sdk','macosx','clang++','-std=c++20','-O2','-fobjc-arc','-mmacosx-version-min=26.4',
 '-Iruntime','-Idev',str(D/'decode_profile.mm'),'build/engine/metal/MetalBackendInstrumented.o','build/engine/libsplash.a',
 '-framework','Foundation','-framework','Metal','-framework','IOKit','-framework','IOSurface','-o',str(D/'decode-profile')],W)
library=R/'.build/smart-dflash-eval/upstream/splash-1.4.0-arm64-macos26/engine/splash.metallib'
shutil.copyfile(library,D/'splash.metallib')
cache=json.loads((P/'v29b-default-smart-q215-splash-cache.json').read_text())
(D/'identity.json').write_text(json.dumps(dict(source_commit='1482f6bbc2abf12375332725302019594150b6cb',
 host_spin_ms=0,source_changes=changes,expert_slots=cache['slots'],
 hashes={f:hashlib.sha256((D/f).read_bytes()).hexdigest()for f in ['decode-profile','splash.metallib','decode_profile.mm']},
 scope='Instrumented upstream single-conversation component attribution with bounded KV extents and 15 GB physical guard. Same code prompt and expert capacity; not a serving-speed or exact-fixed-continuation comparison.'),indent=2)+'\n')
lock=open(os.environ.get('SLOTSTREAM_MODEL_LOCK_PATH') or f'/tmp/slotstream-model-{os.getuid()}.lock','a')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
prepared=R/'.build/smart-dflash-eval/upstream-prepared/.resolved/938d6d6879dac79e95a5eae858867e0af230dc252a18266c6aefb6732b65dee7'
run('run',[sys.executable,str(P/'guarded_run.py'),'--label','splash-q2-target-profile','--budget','15','--timeout','600','--',
 str(D/'decode-profile'),str(D/'splash.metallib'),str(prepared),'--prompt-tokens',str(len(prompt)),'--cycles','3',
 '--kv-format','bf16','--state-format','fp32','--expert-memory',str(cache['expert_memory']),'--ple-memory','51200000',
 '--dispatch-list',str(D/'dispatches.txt')])
