import json,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];B=P/'v18/slotstream';rows=[]
def run(label,cmd):
 print('START',label,flush=True)
 with (P/(label+'-driver.log')).open('x') as log:r=subprocess.run(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT)
 rows.append(dict(label=label,command=cmd,exit_code=r.returncode));(P/'v18-core-ledger.json').write_text(json.dumps(rows,indent=2)+'\n')
 print('END',label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
run('v18-freeze',[sys.executable,str(P/'freeze.py'),'v18'])
for model in ['smart-q2','fast']:
 label='v18-pool-'+model
 run(label,[sys.executable,str(P/'guarded_run.py'),'--label',label,'--budget','3','--timeout','300','--env','SLOTSTREAM_NATIVE_PROJECTION_SCHEDULE=1','--env','SLOTSTREAM_NATIVE_EXPERT_SCHEDULE=1','--env','SLOTSTREAM_NATIVE_GPU_STAGING=1','--',str(B),'q2-experts-check','--pool-model',model])
run('v18-formats',[sys.executable,str(P/'guarded_run.py'),'--label','v18-formats','--budget','3','--timeout','240','--env','SLOTSTREAM_NATIVE_PROJECTION_SCHEDULE=1','--env','SLOTSTREAM_NATIVE_EXPERT_SCHEDULE=1','--env','SLOTSTREAM_NATIVE_GPU_STAGING=1','--',str(B),'q2-format-check','--fixtures','bench/q2/formats.json','--policy-fixtures','bench/q2/verify-budget.json','--mix-fixtures','bench/q2/mix-quantization.json'])
run('v18-plain',[sys.executable,str(P/'v18_plain.py')])
