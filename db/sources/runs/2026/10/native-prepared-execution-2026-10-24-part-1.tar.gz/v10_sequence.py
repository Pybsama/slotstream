import json,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];B=P/'v10/slotstream';rows=[]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
preflight(12)
r=subprocess.run(['ps','-axo','comm='],capture_output=True,text=True)
assert not any(l.rstrip().endswith(('/slotstream','/splash'))for l in r.stdout.splitlines())
def run(label,cmd):
 print('START',label,flush=True)
 with (P/(label+'-driver.log')).open('x') as log:r=subprocess.run(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT)
 rows.append(dict(label=label,command=cmd,exit_code=r.returncode));(P/'v10-sequence-ledger.json').write_text(json.dumps(rows,indent=2)+'\n')
 print('END',label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
run('v10-build',['make','build','SLOTSTREAM_BUILD_JOBS=4'])
run('v10-freeze',[sys.executable,str(P/'freeze.py'),'v10'])
for model in ['fast','smart-q2']:
 label='v10-pool-'+model
 run(label,[sys.executable,str(P/'guarded_run.py'),'--label',label,'--budget','3','--timeout','300','--env','SLOTSTREAM_NATIVE_PROJECTION_SCHEDULE=1','--',str(B),'q2-experts-check','--pool-model',model])
run('v10-formats',[sys.executable,str(P/'guarded_run.py'),'--label','v10-formats','--budget','3','--timeout','240','--env','SLOTSTREAM_NATIVE_PROJECTION_SCHEDULE=1','--',str(B),'q2-format-check','--fixtures','bench/q2/formats.json','--policy-fixtures','bench/q2/verify-budget.json','--mix-fixtures','bench/q2/mix-quantization.json'])
run('v10-plain',[sys.executable,str(P/'v10_plain.py')])
for model in ['smart-q2','fast']:
 label='v10-'+model+'9-splash'
 run(label,[sys.executable,str(P/'native_splash_compare_v10.py'),'--label',label,'--native',str(B),'--model',model,'--budget','9'])
run('v10-quality',[sys.executable,str(P/'v10_quality.py')])
