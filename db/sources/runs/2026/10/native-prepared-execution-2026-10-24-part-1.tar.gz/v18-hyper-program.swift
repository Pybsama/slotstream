    /// The complete maintained Q2 hyper-connection is one prepared program.
    /// Reuse its topology while supplying all weights and request arrays on
    /// each call. FP32 normalization/injection, the register down projection,
    /// BF16 low activation, staged up projection and final mix keep the same
    /// arithmetic and reduction order as their separately scheduled paths.
    package static func hyper(_ hyper: MLXArray, norm: MLXArray, inject: MLXArray?,
                              down: Q2GGUFLinear, up: Q2GGUFLinear, hidden: Int) -> (MLXArray, MLXArray?)? {
        let width = 4 * hidden, count = hyper.size / width
        guard enabled, Q2PackedExperts.enabled, (1...8).contains(count),
              hyper.dim(-1) == width, hidden.isMultiple(of: 256), norm.size == width,
              inject == nil || inject!.shape == [4, width],
              down.inputOrder == nil, down.outputOrder == nil, up.inputOrder == nil, up.outputOrder == nil,
              down.inputType == .bfloat16, up.inputType == .bfloat16,
              down.outputType == .bfloat16, up.outputType == .bfloat16,
              let d = down.prepared, let u = up.prepared,
              d.format == .q80, u.format == .q80,
              d.columns == width, u.columns == d.rows, u.rows == width,
              NativeProjectionPolicy.useRegister(rows: d.rows, columns: d.columns, batch: count, format: d.format),
              !NativeProjectionPolicy.useRegister(rows: u.rows, columns: u.columns, batch: count, format: u.format),
              NativeProjectionPolicy.splits(rows: u.rows, columns: u.columns, cores: NativeProjectionPolicy.device.cores,
                register: false, apple10: NativeProjectionPolicy.device.apple10) == 1 else { return nil }
        let m = d.rows
        let splits = NativeProjectionPolicy.splits(rows: m, columns: width, cores: NativeProjectionPolicy.device.cores,
            register: true, apple10: true)
        let inputs = [contiguous(hyper.asType(.float32).reshaped([count, width])),
            contiguous(norm.asType(.float32)), contiguous((inject ?? norm).asType(.float32)), d.bytes, u.bytes]
        let key = "hyper.\(hidden).\(m).\(count).\(inject != nil).\(splits)"
        guard let values = run(key, inputs: inputs, make: {
            let p = try Plan(inputs: 5, buffers: inputs.map { Buffer($0.shape, $0.dtype) } + [
                Buffer([count, width], .bfloat16), Buffer([count, 4], .float32, output: true),
                Buffer([width * 8], .bfloat16), Buffer([width / 16 * 8 + width / 32 * 8], .float32),
                Buffer([splits, 8, m], .float32), Buffer([count, m], .bfloat16),
                Buffer([count, m], .bfloat16), Buffer([count, width], .bfloat16),
                Buffer([count, hidden], .bfloat16, output: true)])
            try p.add(header: "#pragma clang fp reassociate(off)\n", body: Q2HyperConnection.normSource,
                parameters: ["device const float* x", "device const float* norm", "device const float* inject",
                    "device bfloat* normalized", "device float* weights"],
                definitions: "constexpr int H=\(hidden);constexpr bool INJECT=\(inject != nil ? "true" : "false");",
                bindings: [0, 1, 2, 5, 6], writes: 24, grid: [Int32(count * 1024), 1, 1], group: [1024, 1, 1])
            try p.add(header: Q2RegisterKernelSources.header, body: Q2RegisterKernelSources.prepare,
                parameters: ["device const bfloat* input", "device bfloat* table", "device float* sums"],
                definitions: "constexpr int IN=\(width);constexpr int COUNT=\(count);",
                bindings: [5, 7, 8], writes: 6, grid: [Int32(width / 64 * 8 / 4 * 128), 1, 1], group: [128, 1, 1])
            try p.add(header: Q2RegisterKernelSources.header + "\ntypedef FmtQ80 F;\n", body: Q2RegisterKernelSources.matrix,
                parameters: ["device const bfloat* table", "device const float* sums", "device const uchar* w", "device float* y"],
                definitions: "constexpr int IN=\(width);constexpr int OUT=\(m);constexpr int SPLITS=\(splits);constexpr int P1=\(d.plane1);constexpr int META=\(d.meta);",
                bindings: [7, 8, 3, 9], writes: 8, grid: [Int32(m / 64 * 128), Int32(splits), 1], group: [128, 1, 1])
            try p.add(header: "#pragma clang fp reassociate(off)\n",
                body: "uint i=thread_position_in_grid.x;if(i>=\(m * count))return;float sum=0;for(uint p=0;p<\(splits);++p)sum+=x[p*\(8 * m)+i];y[i]=bfloat(sum);",
                parameters: ["device const float* x", "device bfloat* y"], definitions: "",
                bindings: [9, 10], writes: 2, grid: [Int32(m * count), 1, 1], group: [Int32(min(256, m * count)), 1, 1])
            // Match pinned MLX's stable Sigmoid operator, including its
            // subtraction on positive values, rather than substituting an
            // algebraically equivalent but differently rounded expression.
            try p.add(header: "#pragma clang fp reassociate(off)\n",
                body: "uint i=thread_position_in_grid.x;if(i>=\(m * count))return;float v=float(x[i])/4.0f;float t=1.0f/(1.0f+exp(abs(v)));y[i]=bfloat(v*(v<0?t:1.0f-t));",
                parameters: ["device const bfloat* x", "device bfloat* y"], definitions: "",
                bindings: [10, 11], writes: 2, grid: [Int32(m * count), 1, 1], group: [Int32(min(256, m * count)), 1, 1])
            try p.add(header: "#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>\n#pragma clang fp reassociate(off)\n"
                    + Q2ResidentKernelSources.header + "\ntypedef FmtQ80 F;\n",
                body: "const int x_shape[2]={\(count),\(m)};\n" + Q2ResidentKernelSources.matrix,
                parameters: ["device const bfloat* x", "device const uchar* w", "device bfloat* y"],
                definitions: "typedef bfloat T;typedef bfloat Y;constexpr int IN=\(m);constexpr int OUT=\(width);constexpr int P1=\(u.plane1);constexpr int META=\(u.meta);constexpr int PARTS=1;",
                bindings: [11, 4, 12], writes: 4, grid: [Int32(width), 1, 1], group: [64, 1, 1])
            try p.add(header: "#pragma clang fp reassociate(off)\n", body: Q2HyperConnection.mixSource,
                parameters: ["device const bfloat* x", "device const bfloat* gate", "device bfloat* y"],
                definitions: "constexpr int H=\(hidden);", bindings: [5, 12, 13], writes: 4,
                grid: [Int32(hidden), Int32(count), 1], group: [256, 1, 1])
            return p
        }) else { return nil }
        return (values[1].reshaped(Array(hyper.shape.dropLast()) + [hidden]),
            inject == nil ? nil : values[0].reshaped(Array(hyper.shape.dropLast()) + [4]))
    }
