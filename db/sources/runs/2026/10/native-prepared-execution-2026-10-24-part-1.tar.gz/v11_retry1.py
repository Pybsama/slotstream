import json,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];B=P/'v11/slotstream';rows=[]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
preflight(12)
r=subprocess.run(['ps','-axo','comm='],capture_output=True,text=True)
assert not any(l.rstrip().endswith(('/slotstream','/splash'))for l in r.stdout.splitlines())
def run(label,cmd):
 print('START',label,flush=True)
 with (P/(label+'-driver.log')).open('x') as log:r=subprocess.run(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT)
 rows.append(dict(label=label,command=cmd,exit_code=r.returncode));(P/'v11-retry1-ledger.json').write_text(json.dumps(rows,indent=2)+'\n')
 print('END',label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
# run('v11-recycler-build',['c++','-std=c++20','-O2','-I'+str(R/'Sources/CNativeSchedule/splash'),'-I/tmp/slotstream-splash-review.EJTswU/splash/dev/tests/engine','/tmp/slotstream-splash-review.EJTswU/splash/dev/tests/engine/slot_recycler_test.cpp',str(R/'Sources/CNativeSchedule/splash/model/SlotRecycler.cpp'),'-o',str(P/'v11-recycler-test')])
# run('v11-recycler-reference',[str(P/'v11-recycler-test'),'/tmp/slotstream-splash-review.EJTswU/splash/dev/tests/fixtures/kv-selection-traces'])
run('v11-build-retry1',['make','build','SLOTSTREAM_BUILD_JOBS=4'])
run('v11-freeze',[sys.executable,str(P/'freeze.py'),'v11'])
for model in ['fast','smart-q2']:
 label='v11-pool-'+model
 run(label,[sys.executable,str(P/'guarded_run.py'),'--label',label,'--budget','3','--timeout','300','--env','SLOTSTREAM_NATIVE_PROJECTION_SCHEDULE=1','--',str(B),'q2-experts-check','--pool-model',model])
run('v11-formats',[sys.executable,str(P/'guarded_run.py'),'--label','v11-formats','--budget','3','--timeout','240','--env','SLOTSTREAM_NATIVE_PROJECTION_SCHEDULE=1','--',str(B),'q2-format-check','--fixtures','bench/q2/formats.json','--policy-fixtures','bench/q2/verify-budget.json','--mix-fixtures','bench/q2/mix-quantization.json'])
run('v11-plain',[sys.executable,str(P/'v11_plain.py')])
