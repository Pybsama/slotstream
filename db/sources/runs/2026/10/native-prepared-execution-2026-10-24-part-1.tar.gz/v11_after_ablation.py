import json,subprocess,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1]
start=time.monotonic()
while True:
 ledger=P/'v10-q2-submit9-ledger.json'
 if ledger.exists() and len(json.loads(ledger.read_text()))==4:break
 if time.monotonic()-start>2400:raise RuntimeError('Ablation did not finish; no build launched')
 time.sleep(2)
time.sleep(2)
assert not any(x.rstrip().endswith(('/slotstream','/splash'))for x in subprocess.run(['ps','-axo','comm='],capture_output=True,text=True).stdout.splitlines())
for label,cmd in [('v11-core',[sys.executable,str(P/'v11_core.py')]),('v11-q29-splash',[sys.executable,str(P/'native_splash_compare_v11.py'),'--label','v11-q29-splash','--native',str(P/'v11/slotstream'),'--model','smart-q2','--budget','9'])]:
 print('START',label,flush=True)
 with (P/(label+'-driver.log')).open('x') as f:r=subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT)
 print('END',label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
