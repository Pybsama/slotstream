import json,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1]
ledger=json.loads((P/'v14-core-ledger.json').read_text())
assert ledger[-1]['label']=='v14-plain' and all(x['exit_code']==0 for x in ledger)
for model in ['smart-q2','fast']:
 label='v14-'+model+'9-splash'
 cmd=[sys.executable,str(P/'native_splash_compare_v14.py'),'--label',label,'--native',str(P/'v14/slotstream'),'--model',model,'--budget','9']
 print('START',label,flush=True)
 with (P/(label+'-driver.log')).open('x')as log:r=subprocess.run(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT)
 print('END',label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
