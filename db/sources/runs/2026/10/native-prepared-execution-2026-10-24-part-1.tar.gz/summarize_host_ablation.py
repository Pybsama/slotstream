import json,statistics
from pathlib import Path
P=Path(__file__).resolve().parent;rows=json.loads((P/'splash-host-wait-q215-ledger.json').read_text());assert len(rows)==4
out=dict(protocol='Rebuilt same pinned Splash CPU host and byte-identical published shaders; ABBA, A=5ms CPU polling before wait, B=0ms CPU polling. Q2, 15 GB physical ceiling, 4067 actual expert slots, BF16 KV 8192, identical original prompt IDs and 384-token outputs, two warmup and two timed requests per process. GPU spin absent in both.',eligible=all(r['eligible']for r in rows),tasks={},scope='This isolates CPU host-step polling in two rebuilt controls. It is not a comparison between Slotstream and the released Splash binary, and does not isolate every host scheduling difference.')
for task in ['timed-2','timed-3']:
 arms={}
 for arm in ['A','B']:
  rs=[next(x for x in r['runs']if x['id']==task)for r in rows if r['arm']==arm]
  arms[arm]={key:statistics.median(x[key]for x in rs)for key in ['tps','request_seconds']}
 out['tasks'][task]=dict(arms,no_polling_tps_ratio=arms['B']['tps']/arms['A']['tps'],no_polling_request_ratio=arms['B']['request_seconds']/arms['A']['request_seconds'])
out['conclusion']='Clean controls show only a small throughput/request difference. CPU polling is not supported as the explanation for the much larger native Q2 gap in this study. No CPU polling is ported.'if out['eligible']else'Excluded aggregate; no attribution.'
(P/'splash-host-wait-q215-summary.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
