from pathlib import Path
import json,subprocess,sys
P=Path(__file__).resolve().parent;R=P.parents[1]
arms=[];references={}
for model in ['fast']:
 for enabled in [1]:
  label=f'v64-window-state-{model}-{enabled}'
  cmd=[sys.executable,str(P/'guarded_run.py'),'--label',label,'--budget','10','--timeout','600','--env','SLOTSTREAM_GDN_PENDING_STATE='+str(enabled),'--',str(P/'v64/slotstream'),'q2-profile','--model',model,'--memory-gb','10','--rounds','1','--retained-prefix','3','--fixture',str(P/('v29-profile-'+model+'-fixture.json')),'--output',str(P/(label+'.json'))]
  print('START',label,flush=True)
  with(P/(label+'-driver.log')).open('x')as f:r=subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT)
  if r.returncode:raise SystemExit(r.returncode)
  d=json.loads((P/(label+'.json')).read_text());o=json.loads((P/(label+'.observer.json')).read_text())
  assert len(d['runs'])==16 and all(x['max_logit_difference']==0 and x['argmax_equal']for x in d['runs'])
  for x in d['runs']:
   key=(model,x['width']);hashes=(x['logits_sha256'],x['recurrence_sha256'])
   old=json.loads((P/'v56b-pending-state-r2-fast-1.json').read_text());prior=next(r for r in old['runs']if r['width']==x['width']and r['traced']==x['traced']);assert hashes==(prior['logits_sha256'],prior['recurrence_sha256']),('changed Fast trained continuation',key);references.setdefault(key,hashes);assert references[key]==hashes,('trained state or logits differ',label,key)
   assert (x['pending_recurrence_folds']>0)==(enabled==1 and not x['traced']),(label,x)
  arms.append(dict(label=label,complete=True,full_logits_and_recurrence_equal=True,branch_proven=True,peak=o['peak_combined_bytes']/1e9,paging=o['paging']))
  (P/'v64-window-state-summary.json').write_text(json.dumps(dict(complete=len(arms)==1,arms=arms,scope='Correctness only: trained fixed prefix, eight-row proposal retaining three rows, continued at widths 1/2/4/8, traced/untraced and enabled/disabled. Full FP32 logits and recurrent state hashes equal across every arm. This is not a serving speed comparison.'),indent=2)+'\n')
  print('END',arms[-1],flush=True)
