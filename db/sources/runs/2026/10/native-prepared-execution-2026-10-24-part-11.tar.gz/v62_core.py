import json,subprocess,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];B=P/'v62/slotstream';rows=[]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
preflight(12)
def run(label,cmd):
 print('START',label,flush=True)
 start=time.monotonic()
 with(P/(label+'-driver.log')).open('x')as log:r=subprocess.run(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT)
 rows.append(dict(label=label,command=cmd,exit_code=r.returncode,seconds=time.monotonic()-start));(P/'v62-core-ledger.json').write_text(json.dumps(rows,indent=2)+'\n')
 print('END',label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
run('v62-build',['make','build','SLOTSTREAM_BUILD_JOBS=4'])
run('v62-freeze',[sys.executable,str(P/'freeze.py'),'v62'])
run('v62-pieces',[sys.executable,str(P/'guarded_run.py'),'--label','v62-pieces','--budget','1','--timeout','30','--',str(B),'q2-experts-check','--piece-only'])
run('v62-draft-validated',[sys.executable,str(P/'guarded_run.py'),'--label','v62-draft-validated','--budget','1','--timeout','120','--env','MTL_DEBUG_LAYER=1','--env','MTL_SHADER_VALIDATION=1','--',str(B),'q2-experts-check','--draft-only'])
