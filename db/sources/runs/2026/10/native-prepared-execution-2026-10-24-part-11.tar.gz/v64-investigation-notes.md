Further investigation after v61

The v62c AF4G64 draft port is removed. Original-code references, lifetime checks and every frozen quality case passed, but the complete clean Q2 native/native ABBA yielded a geometric request ratio of 1.0113549416239926 and failed the declared useful-gain gate. Keep all four arms and the frozen source.

The v63 borrowed-buffer/descriptor reuse is removed. Correctness checks passed and the complete clean ABBA improved full requests slightly, with geometric ratio 0.9803400775366985. It narrowly missed the preregistered <=0.98 gate; do not change the threshold or turn this into proof of parity. No extra production knob remains.

The existing compile-observer trace also measures non-native library calls: v61 has 168 such calls totaling 0.1016167146153748 seconds over the observed first 96-token request. This is not a steady-state speed comparison or proof about every future shape, but does not support those calls as the multi-second gap in this scope. The audit preserves raw trace coordinates.

Source review confirms Splash also stages raw expert records and performs GPU repacking into planes (runtime/model/ExpertStore.cpp, ProjectionLayout and read/repack round ownership). The word prepared in its checkpoint path does not prove an absent native on-disk plane optimization. Native GPU repacking is therefore not, by itself, evidence of unequal recipes.

v64 is an isolated, not-yet-qualified change: an immutable convolution-window recording description creates only a selected rollback view. It preserves exact GPU arithmetic, diagnostic full materialization, bounded parent ownership and state counts. Independent original-row and released-owner checks passed (36 checks); real-model checks and complete-request qualification remain pending.
