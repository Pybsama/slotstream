from pathlib import Path
import subprocess,sys,json
P=Path(__file__).resolve().parent;R=P.parents[1]
sys.path.insert(0,str(R/'.build/native-q2-20261021'));from thermal import wait_nominal
label='v61-fixed-target'
wait_nominal(P/(label+'-cooldown.json'))
cmd=[sys.executable,str(P/'guarded_run.py'),'--label',label,'--budget','15','--timeout','600','--env','DYLD_INSERT_LIBRARIES='+str(P/'metal_command_observer_mrc.dylib'),'--env','SLOTSTREAM_METAL_OBSERVER='+str(P/(label+'-timestamps')),'--',str(P/'v61/slotstream'),'q2-profile','--model','smart-q2','--memory-gb','15','--rounds','3','--fixture',str(P/'v29-profile-smart-q2-fixture.json'),'--output',str(P/(label+'.json'))]
with(P/(label+'-driver.log')).open('x')as f:r=subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT)
(P/(label+'-controller.json')).write_text(json.dumps(dict(command=cmd,exit_code=r.returncode,scope='Instrumented target-only cached replay. Not a serving benchmark and not equal work to the Splash draft-plus-target replay.'),indent=2)+'\n')
raise SystemExit(r.returncode)
