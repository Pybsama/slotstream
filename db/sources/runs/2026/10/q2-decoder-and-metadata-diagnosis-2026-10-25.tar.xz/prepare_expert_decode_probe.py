from pathlib import Path
import hashlib,json
P=Path(__file__).resolve().parent;R=P.parents[1]
s=(R/'Sources/Slotstream/NativeExpertTiles.swift').read_text().split('package static let source = #"""',1)[1].split('"""#',1)[0]
start=s.index('        const auto decode =');end=s.index('        load(0);',start)
candidate='''        const auto decode = [&](thread half4 (&values)[8]) {
            #pragma unroll
            for(ushort c=0;c<4;++c) {
                uint word=payload[c/2]>>(16*(c%2));
                uint spread=(word&0x3333u)|((word&0xCCCCu)<<14);
                uint4 p=(uint4(spread)>>uint4(0,4,8,12))&0x00030003u;
                const auto pair=[&](uint x){return half2(float2(as_type<half2>(x|0x64006400u)-half2(1025))*scaleValue);};
                values[c*2]=half4(pair(p.x),pair(p.y));
                values[c*2+1]=half4(pair(p.z),pair(p.w));
            }
        };
'''
b=s[:start]+candidate+s[end:]
header='''#include <metal_stdlib>
#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>
using namespace metal;
#pragma clang fp reassociate(off)
'''
args='''device const bfloat* x [[buffer(0)]], device const uchar* w [[buffer(1)]], device const uchar* scales [[buffer(2)]], device const uchar* biases [[buffer(3)]], device const uchar* up [[buffer(4)]], device const uchar* up_scales [[buffer(5)]], device const uchar* up_biases [[buffer(6)]], device const int* slots [[buffer(7)]], device const int* live [[buffer(8)]], device bfloat* y [[buffer(9)]], uint3 threadgroup_position_in_grid [[threadgroup_position_in_grid]], uint thread_index_in_simdgroup [[thread_index_in_simdgroup]], uint simdgroup_index_in_threadgroup [[simdgroup_index_in_threadgroup]]'''
out=header
for name,body in [('original',s),('paired',b)]:
 for fused,k,n in [(True,2560,640),(False,640,2560)]:
  out+=f'#define IN {k}\n#define OUT {n}\n#define FUSED {str(fused).lower()}\n#define AFFINE false\nkernel void {name}_{"gate_up" if fused else "down"}({args}){{\n{body}\n}}\n#undef IN\n#undef OUT\n#undef FUSED\n#undef AFFINE\n'
(P/'expert-decode-probe.metal').write_text(out)
(P/'expert-decode-plan.json').write_text(json.dumps(dict(scope='Cached expert-only original native, adjacent-pair decoder candidate retaining layout, and pinned Splash kernels. Independent CPU pack from same raw Q2 bytes, shared BF16 inputs, same active rows, shapes and tile counts. No model timing or 15 GB parity claim.',shapes=['gate_up 2560 -> 640','down 640 -> 2560'],tiles=[10,30,60],rows=[1,2,3,8],variants=['original','paired','Splash'],rounds=10,warmup_rounds=2,repetitions=8,order='ABC/CBA alternating',retention='Only a reproducible kernel benefit can justify a runtime candidate, then full correctness and complete-request baseline/Splash checks remain mandatory.',source_sha256=hashlib.sha256(s.encode()).hexdigest()),indent=2))
