from pathlib import Path
import fcntl,json,os,subprocess,sys
P=Path(__file__).resolve().parent;R=P.parents[1]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
lock=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);inner=P/'paired-decoder-check-child.lock';os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(inner);preflight(7)
cmd=[sys.executable,str(P/'quiet_guarded_run.py'),'--label','paired-decoder-check','--budget','4','--timeout','600','--env','SLOTSTREAM_MODEL_LOCK_PATH='+str(inner),'--',str(P/'native-paired-decoder-build/candidate/slotstream'),'q2-experts-check']
with (P/'paired-decoder-check-launcher.log').open('x') as f: r=subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT)
print('PAIRED_DECODER_CHECK',r.returncode);assert r.returncode==0
