from pathlib import Path
import csv,fcntl,hashlib,json,os,re,subprocess,sys
P=Path(__file__).resolve().parent;R=P.parents[1];sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
lock=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(P/'stat-observer-build-child.lock');before=preflight(4)
assert not(P/'stat-observer-build.json').exists();base=['xcrun','clang++','-std=c++17','-O2'];cmds=[base+['-dynamiclib',str(P/'stat_observer.cpp'),'-o',str(P/'stat_observer.dylib')],base+[str(P/'stat_observer_check.cpp'),'-o',str(P/'stat-observer-check')]]
for i,cmd in enumerate(cmds):
 r=subprocess.run(cmd,capture_output=True,text=True,timeout=120);(P/f'stat-observer-build-{i}.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stderr
env={k:v for k,v in os.environ.items()if not k.startswith(('SLOTSTREAM_','MLX_','DYLD_'))};env.update(DYLD_INSERT_LIBRARIES=str(P/'stat_observer.dylib'),SLOTSTREAM_STAT_OBSERVER=str(P/'stat-observer-check'))
r=subprocess.run([str(P/'stat-observer-check')],env=env,capture_output=True,text=True,timeout=30);(P/'stat-observer-check.log').write_text(r.stdout+r.stderr);assert r.returncode==0
fd=int(re.search(r'STAT_OBSERVER_BYTES_ERRNO_PASS fd=(\d+)',r.stdout)[1]);path=next(P.glob('stat-observer-check.*.csv'));rows=list(csv.DictReader(x for x in path.read_text().splitlines()if not x.startswith('#')));selected=[x for x in rows if int(x['fd'])==fd];bad=[x for x in rows if int(x['fd'])==-1]
assert len(selected)==82 and all(x['result']=='0'for x in selected)and len({x['thread']for x in selected})==5
assert len(bad)==1 and bad[0]['result']=='-1'and bad[0]['error']=='9'
result=dict(before=before,commands=cmds,passed=True,successful_expected_fstats=82,failed_expected_fstats=1,threads=5,files={n:hashlib.sha256((P/n).read_bytes()).hexdigest()for n in ['stat_observer.cpp','stat_observer_check.cpp','stat_observer.dylib','stat-observer-check']})
(P/'stat-observer-build.json').write_text(json.dumps(result,indent=2));print('STAT_OBSERVER_CHECK_PASS')
