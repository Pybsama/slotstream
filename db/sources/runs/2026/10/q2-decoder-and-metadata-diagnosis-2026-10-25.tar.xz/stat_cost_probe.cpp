#include <sys/stat.h>
#include <sys/resource.h>
#include <fcntl.h>
#include <unistd.h>
#include <chrono>
#include <thread>
#include <vector>
#include <atomic>
#include <mutex>
#include <condition_variable>
#include <cstdio>
#include <cstdlib>
using Clock=std::chrono::steady_clock;
static bool check(int fd,const struct stat& expected){struct stat s{};return fstat(fd,&s)==0&&s.st_size==expected.st_size&&s.st_mtimespec.tv_sec==expected.st_mtimespec.tv_sec&&s.st_mtimespec.tv_nsec==expected.st_mtimespec.tv_nsec&&s.st_ctimespec.tv_sec==expected.st_ctimespec.tv_sec&&s.st_ctimespec.tv_nsec==expected.st_ctimespec.tv_nsec;}
static double cpu(){struct rusage u{};getrusage(RUSAGE_SELF,&u);return u.ru_utime.tv_sec+u.ru_stime.tv_sec+1e-6*(u.ru_utime.tv_usec+u.ru_stime.tv_usec);}
int main(int argc,char**argv){if(argc!=3)return 2;int fds[2];struct stat expected[2];for(int i=0;i<2;++i){fds[i]=open(argv[i+1],O_RDONLY|O_CLOEXEC|O_NOFOLLOW);if(fds[i]<0||fstat(fds[i],&expected[i]))return 3;}
 // Four file validations per logical piece, exactly as CheckpointIndex.readRouted.
 // Counts come from the prior clean copy-observer continuation; no weight reads.
 for(int round=0;round<4;++round)for(int mode=0;mode<3;++mode){std::vector<size_t> counts;
  if(mode!=1)for(size_t j=0;j<4;++j)counts.push_back(125696/4+(j<125696%4));
  if(mode!=0)for(size_t j=0;j<18;++j)counts.push_back(70716/18+(j<70716%18));
  bool go=false;std::atomic<bool>okay{true};size_t ready=0;std::mutex mutex;std::condition_variable cv;std::vector<std::thread>workers;size_t total=0;
  for(size_t n:counts){total+=n;workers.emplace_back([&,n]{{std::unique_lock<std::mutex> lock(mutex);++ready;cv.notify_all();cv.wait(lock,[&]{return go;});}for(size_t j=0;j<n;++j)for(int pass=0;pass<2;++pass)for(int f=0;f<2;++f)if(!check(fds[f],expected[f]))okay=false;});}
  std::unique_lock<std::mutex> lock(mutex);cv.wait(lock,[&]{return ready==counts.size();});double c=cpu();auto t=Clock::now();go=true;lock.unlock();cv.notify_all();for(auto&x:workers)x.join();double wall=std::chrono::duration<double>(Clock::now()-t).count();c=cpu()-c;
  if(!okay.load())return 4;printf("ROW %d %d %zu %zu %.9f %.9f\n",round,mode,counts.size(),total*4,wall,c);fflush(stdout);
 }
 for(int fd:fds)close(fd);return 0;
}
