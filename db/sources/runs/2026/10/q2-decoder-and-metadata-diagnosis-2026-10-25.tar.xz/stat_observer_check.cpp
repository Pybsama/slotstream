#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <cstdio>
#include <cstdlib>
#include <cerrno>
#include <thread>
#include <vector>
#include <atomic>
int main(){char name[]="/tmp/slotstream-stat-check-XXXXXX";int fd=mkstemp(name);if(fd<0)return 2;unlink(name);struct stat s{};if(ftruncate(fd,5)||fstat(fd,&s)||s.st_size!=5)return 3;if(ftruncate(fd,9)||fstat(fd,&s)||s.st_size!=9)return 4;std::atomic<bool>okay{true};std::vector<std::thread>threads;for(int i=0;i<4;++i)threads.emplace_back([&]{for(int j=0;j<20;++j){struct stat v{};if(fstat(fd,&v)||v.st_size!=9)okay=false;}});for(auto&t:threads)t.join();errno=0;if(fstat(-1,&s)!=-1||errno!=EBADF)return 5;close(fd);if(!okay)return 6;printf("STAT_OBSERVER_BYTES_ERRNO_PASS fd=%d\n",fd);return 0;}
