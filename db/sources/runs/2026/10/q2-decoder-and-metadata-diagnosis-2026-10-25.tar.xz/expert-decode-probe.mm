#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <vector>
#include <algorithm>
#include "metal/abi/MoE.h"
#include "metal/abi/QuantFormat.h"
static uint16_t bf(float f){uint32_t u;memcpy(&u,&f,4);return (u+0x7fff+((u>>16)&1))>>16;}
static float unbf(uint16_t x){uint32_t u=uint32_t(x)<<16;float f;memcpy(&f,&u,4);return f;}
int main(int argc,const char**argv){@autoreleasepool{
 if(argc!=3)return 2;NSError *error=nil;auto d=MTLCreateSystemDefaultDevice();auto q=[d newCommandQueue];auto opt=[MTLCompileOptions new];opt.mathMode=MTLMathModeFast;
 auto lib=[d newLibraryWithSource:[NSString stringWithContentsOfFile:@(argv[1]) encoding:NSUTF8StringEncoding error:&error] options:opt error:&error];if(!lib){fprintf(stderr,"%s\n",error.description.UTF8String);return 3;}
 auto slib=[d newLibraryWithFile:@(argv[2]) error:&error];if(!slib){fprintf(stderr,"%s\n",error.description.UTF8String);return 4;}
 auto buf=[&](size_t n){auto b=[d newBufferWithLength:n options:MTLResourceStorageModeShared];if(!b)throw 11;return b;};
 const int cap=60;const size_t piece=460800,codes=409600,meta=51200;
 auto native=buf(2*cap*piece),splash=buf(2*cap*piece),x=buf(cap*8*2560*2),output=buf(cap*8*2560*2),slots=buf(cap*4),live=buf(cap*4),tiles=buf(cap*sizeof(MoeTileDescriptor)),count=buf(4);
 for(int i=0;i<cap;++i)((uint32_t*)slots.contents)[i]=i;
 for(bool fused:{true,false}){
  int K=fused?2560:640,N=fused?640:2560;
  std::vector<id<MTLComputePipelineState>> pipes;
  for(int v=0;v<3;++v){NSString *name=v==2?(fused?@"moe_expert_gguf_m8_gate_up":@"moe_expert_gguf_m8_a"):[NSString stringWithFormat:@"%s_%s",v?"paired":"original",fused?"gate_up":"down"];
   auto pipe=[d newComputePipelineStateWithFunction:[(v==2?slib:lib) newFunctionWithName:name] error:&error];if(!pipe){fprintf(stderr,"%s\n",error.description.UTF8String);return 5;}pipes.push_back(pipe);
   printf("PIPE fused=%d variant=%d threads=%lu shared=%lu\n",fused,v,(unsigned long)pipe.maxTotalThreadsPerThreadgroup,(unsigned long)pipe.staticThreadgroupMemoryLength);
  }
  memset(native.contents,0,native.length);memset(splash.contents,0,splash.length);
  // Independent packing of identical original Q2 values into each layout.
  for(int z=0;z<2;++z)for(int e=0;e<cap;++e)for(int row=0;row<N;++row)for(int g=0;g<K/32;++g){
   auto *np=(uint8_t*)native.contents+z*cap*piece+e*piece;
   auto *sp=(uint8_t*)splash.contents+z*cap*piece;
   size_t at=((row/64*(K/32)+g)*64+row%64)*8;
   for(int j=0;j<32;++j){uint32_t scalar=(e*N+row)*K+g*32+j;uint8_t code=(scalar*1664525u+(scalar>>5)*1013904223u+z*31u)>>28&3;
    np[at+j/4]|=code<<(2*(j%4));int sj=quant_slot(j);sp[e*codes+at+sj/4]|=code<<(2*(sj%4));
   }
   if(g%2==0){uint16_t h=uint16_t(0x2000+((e+row+g+z)%16)*64);size_t ma=((row/64*(K/64)+g/2)*64+row%64)*2;
    memcpy(np+codes+ma,&h,2);memcpy(sp+cap*codes+e*meta+ma,&h,2);
   }
  }
  for(int i=0;i<cap*8*K;++i)((uint16_t*)x.contents)[i]=bf(float((i*17+i/23)%101-50)/64);
  for(int n:{10,30,60})for(int rows:{1,2,3,8}){
   for(int e=0;e<n;++e){((uint32_t*)live.contents)[e]=rows;((MoeTileDescriptor*)tiles.contents)[e]={uint32_t(e),uint32_t(rows)};}*((uint32_t*)count.contents)=n;
   MoeGgufGateUpParams gp{uint32_t(K),uint32_t(N),cap,GGUF_FMT_Q20,GGUF_FMT_Q20,GGUF_FMT_Q20,GGUF_FMT_Q20};
   MoeGgufExpertParams dp{uint32_t(K),uint32_t(N),cap,GGUF_FMT_Q20,GGUF_FMT_Q20};
   auto submit=[&](int v,int repeats){auto cmd=[q commandBuffer];auto enc=[cmd computeCommandEncoder];[enc setComputePipelineState:pipes[v]];
    if(v<2){[enc setBuffer:x offset:0 atIndex:0];for(int i=1;i<=6;++i)[enc setBuffer:native offset:i>=4?cap*piece:0 atIndex:i];[enc setBuffer:slots offset:0 atIndex:7];[enc setBuffer:live offset:0 atIndex:8];[enc setBuffer:output offset:0 atIndex:9];}
    else{[enc setBuffer:x offset:0 atIndex:0];[enc setBuffer:tiles offset:0 atIndex:1];[enc setBuffer:count offset:0 atIndex:2];
     for(int z=0;z<(fused?2:1);++z)for(int i=0;i<6;++i)[enc setBuffer:splash offset:z*cap*piece+((i%3)?cap*codes:0) atIndex:3+z*6+i];
     if(fused){[enc setBuffer:output offset:0 atIndex:15];[enc setBuffer:slots offset:0 atIndex:16];[enc setBytes:&gp length:sizeof(gp) atIndex:17];}
     else{[enc setBuffer:output offset:0 atIndex:9];[enc setBuffer:output offset:0 atIndex:10];[enc setBuffer:slots offset:0 atIndex:11];[enc setBytes:&dp length:sizeof(dp) atIndex:12];}
    }
    for(int j=0;j<repeats;++j)[enc dispatchThreadgroups:MTLSizeMake(N/(fused?32:64),n,1) threadsPerThreadgroup:MTLSizeMake(64,1,1)];
    [enc endEncoding];[cmd commit];[cmd waitUntilCompleted];if(cmd.status!=MTLCommandBufferStatusCompleted){fprintf(stderr,"GPU %s\n",cmd.error.description.UTF8String);throw 9;}return cmd.GPUEndTime-cmd.GPUStartTime;
   };
   submit(0,1);std::vector<uint16_t> ref(n*8*N);memcpy(ref.data(),output.contents,ref.size()*2);
   for(int v=1;v<3;++v){submit(v,1);size_t mismatch=0;float maxerr=0,peak=0;
    for(int e=0;e<n;++e)for(int r=0;r<rows;++r)for(int c=0;c<N;++c){size_t i=(e*8+r)*N+c;auto got=((uint16_t*)output.contents)[i];float a=unbf(got),b=unbf(ref[i]);if(!std::isfinite(a)||!std::isfinite(b))return 10;mismatch+=got!=ref[i];maxerr=std::max(maxerr,std::abs(a-b));peak=std::max(peak,std::abs(b));}
    printf("CHECK fused=%d tiles=%d rows=%d variant=%d mismatches=%lu max_error=%.9g peak=%.9g\n",fused,n,rows,v,(unsigned long)mismatch,maxerr,peak);if(v==1&&mismatch)return 12;if(v==2&&maxerr>std::max(1e-6f,peak*0.02f))return 13;
   }
   for(int round=0;round<10;++round)for(int step=0;step<3;++step){int v=round%2?2-step:step;double t=submit(v,8);printf("TIME fused=%d tiles=%d rows=%d round=%d variant=%d seconds=%.9f repetitions=8\n",fused,n,rows,round,v,t);}
   fflush(stdout);
  }
 }
 return 0;
}}
