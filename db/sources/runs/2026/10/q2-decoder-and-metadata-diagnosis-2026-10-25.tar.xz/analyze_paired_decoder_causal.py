from pathlib import Path
import json,statistics
P=Path(__file__).resolve().parent;ev=json.loads((P/'paired-decoder-causal-ledger.json').read_text());assert [x['arm']for x in ev]==list('ABBA')
rows=[];ref={(x['round'],x['step']):x['logits_sha256']for x in json.loads((P/'commit-relaxed-0-B.json').read_text())['runs']}
for e in ev:
 d=json.loads((P/(e['label']+'.json')).read_text());assert all(r['logits_sha256']==ref[(r['round'],r['step'])]for r in d['runs']);x=next(r for r in e['rounds']if r['round']==1);assert x['records']+x['adopted']==45109;rows.append(dict(label=e['label'],arm=e['arm'],guard_eligible=e['eligible'],**x))
a=[r['seconds']for r in rows if r['arm']=='A'];b=[r['seconds']for r in rows if r['arm']=='B'];o=dict(scope='Post-rejection, trace-disabled fixed-work diagnosis only; cannot reverse complete-request rejection.',eligible=all(x['guard_eligible']for x in rows),all_888_full_logit_hashes_exact=True,logical_misses_each=45109,rows=rows,median_baseline=statistics.median(a),median_candidate=statistics.median(b),candidate_over_baseline=statistics.median(b)/statistics.median(a),paired_ratios=[b[0]/a[0],b[1]/a[1]],conclusion='Cached kernel gains do not establish a repeatable partial-miss verification gain even with selector work fixed. No retained fix.')
(P/'paired-decoder-causal-analysis.json').write_text(json.dumps(o,indent=2));print(json.dumps(o,indent=2))
