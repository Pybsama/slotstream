import json, statistics
from pathlib import Path

P = Path(__file__).resolve().parent
import sys
label = sys.argv[1] if len(sys.argv)>1 else 'paired-decoder-complete-15'
events = json.loads((P / (label+'-ledger.json')).read_text())
assert [e['arm'] for e in events] == list('ABCCBA')
result = dict(eligible=all(e['eligible'] for e in events),
              capacity_note='All engines use 4067 actual slots, 15 GB total budgets and 8192 context. The only runtime candidate change is the Q2 expert decoder.', tasks={})
for task in ['timed-2', 'timed-3']:
    rows = {}
    for arm in 'ABC':
        runs = [next(r for r in e['runs'] if r['id'] == task) for e in events if e['arm'] == arm]
        rows[arm] = dict(request_seconds=[r['request_seconds'] for r in runs],
                         tps=[r['tps'] for r in runs],
                         median_request_seconds=statistics.median(r['request_seconds'] for r in runs),
                         median_tps=statistics.median(r['tps'] for r in runs))
    rows['candidate_over_baseline'] = rows['B']['median_request_seconds'] / rows['A']['median_request_seconds']
    rows['candidate_over_splash'] = rows['B']['median_request_seconds'] / rows['C']['median_request_seconds']
    rows['baseline_over_splash'] = rows['A']['median_request_seconds'] / rows['C']['median_request_seconds']
    rows['pair_candidate_over_baseline'] = [b / old for b, old in zip(rows['B']['request_seconds'], rows['A']['request_seconds'])]
    result['tasks'][task] = rows
result['retention_gate'] = result['eligible'] and all(t['candidate_over_baseline'] <= .99 and all(p < 1 for p in t['pair_candidate_over_baseline']) for t in result['tasks'].values())
result['goal_timing_gate'] = result['eligible'] and all(t['candidate_over_splash'] <= 1.05 for t in result['tasks'].values())
result['native_work'] = []
for e in events:
    if e['arm'] not in 'AB': continue
    data = json.loads((P/(e['label']+'.json')).read_text())
    for r in data['runs']:
        stats=r['stats']
        result['native_work'].append(dict(label=e['label'],id=r['id'],depths=stats['adaptiveDraftDepths'],**{k:stats[k] for k in ['decodeModelTokens','decodeForwardPasses','decodeRecords','decodeIOSeconds','verifySeconds','draftSeconds','prefillSeconds','dflashCalibrationCyclesBefore']}))
result['limits'] = ['Automatic draft decisions vary the target work and can change emitted tokens because target arithmetic is batch-dependent. Frozen full-logit equality is the independent implementation check.', 'Fixed384-token throughput prompts are not completed semantic quality jobs. Fast recall and Python-only formatting failures remain open.', 'The first native warmup varied strongly; no cause is assigned from time alone.']
(P / (label+'-summary.json')).write_text(json.dumps(result, indent=2))
print(json.dumps({k:v for k,v in result.items() if k!='native_work'}, indent=2))
