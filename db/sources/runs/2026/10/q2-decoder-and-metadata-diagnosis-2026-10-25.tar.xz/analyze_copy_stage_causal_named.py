from pathlib import Path
import bisect,collections,csv,json,statistics
P=Path(__file__).resolve().parent

def rows(path):
 lines=path.read_text().splitlines();foot=dict(x.split('=')for x in lines[-1][2:].split());assert int(foot['total'])<int(foot['cap'])
 return list(csv.DictReader(x for x in lines if not x.startswith('#'))),foot
report=[]
for event in json.loads((P/'copy-stage-causal-ledger.json').read_text()):
 label,arm=event['label'],event['arm'];data=json.loads((P/(label+'.json')).read_text());steps=[r for r in data['runs']if r['round']==1]
 ss,foot=rows(next(P.glob(label+'-commands.*.stages.csv')));pp,_=rows(next(P.glob(label+'-commands.*.pipelines.csv')));aa,_=rows(next(P.glob(label+'-commands.*.assignments.csv')))
 assert foot['cpu_initial']==foot['gpu_initial'] and foot['cpu_final']==foot['gpu_final']
 by_pointer=collections.defaultdict(list)
 for i,x in enumerate(ss):
  x.update(index=i,encoded=float(x['encoded']),gpu_start=int(x['gpu_start']),gpu_end=int(x['gpu_end']),pipelines=[])
  by_pointer[x['encoder']].append(x)
 for vv in by_pointer.values():vv.sort(key=lambda x:x['encoded'])
 creation={k:[x['encoded']for x in vv]for k,vv in by_pointer.items()}
 pipelines=collections.defaultdict(list)
 for i,x in enumerate(pp):x.update(stamp=float(x['stamp']),identity=i);pipelines[x['pipeline']].append(x)
 for vv in pipelines.values():vv.sort(key=lambda x:x['stamp'])
 times={k:[x['stamp']for x in vv]for k,vv in pipelines.items()}
 unknown=unassigned=0
 for x in aa:
  t=float(x['stamp']);vv=by_pointer.get(x['encoder'],[]);idx=bisect.bisect_right(creation.get(x['encoder'],[]),t)-1
  if idx<0:unassigned+=1;continue
  pv=pipelines.get(x['pipeline'],[]);j=bisect.bisect_right(times.get(x['pipeline'],[]),t)-1
  if j<0:name='UNKNOWN';identity=-1;unknown+=1
  else:name=pv[j]['name'];identity=pv[j]['identity']
  vv[idx]['pipelines'].append((identity,name))
 ss.sort(key=lambda x:x['encoded']);starts=[x['encoded']for x in ss];groups=collections.defaultdict(list);per_pass=[]
 for step in steps:
  lo,hi=(step['start_ns']/1e9,step['end_ns']/1e9)if arm!='S'else(step['start'],step['end'])
  stages=ss[bisect.bisect_left(starts,lo):bisect.bisect_left(starts,hi)]
  slices=[]
  for s in stages:
   assert s['gpu_end']>s['gpu_start']>0
   signature=tuple(n for i,n in s['pipelines']);duration=(s['gpu_end']-s['gpu_start'])/1e9
   row=dict(step=step['step'],width=step['width'],index=s['index'],seconds=duration,pipeline_ids=[i for i,n in s['pipelines']]);groups[signature].append(row)
   slices.append(dict(signature=' | '.join(signature),**row))
  per_pass.append(dict(step=step['step'],width=step['width'],encoder_count=len(stages),stage_seconds=sum(x['seconds']for x in slices),stages=slices))
 group_report=[]
 for sig,vv in groups.items():
  group_report.append(dict(signature=list(sig),stages=len(vv),total_seconds=sum(x['seconds']for x in vv),median_seconds=statistics.median(x['seconds']for x in vv),by_width={str(w):dict(stages=len(ww),total_seconds=sum(x['seconds']for x in ww))for w in range(1,9)if(ww:=[x for x in vv if x['width']==w])}))
 group_report.sort(key=lambda x:-x['total_seconds'])
 exact=None
 if arm!='S':
  ref={(r['round'],r['step']):r['logits_sha256']for r in json.loads((P/'commit-relaxed-0-B.json').read_text())['runs']};exact=all(r['logits_sha256']==ref[(r['round'],r['step'])]for r in data['runs']);assert exact
 summary=dict(label=label,guard_eligible=event.get('eligible'),native_full_hashes_exact=exact,unknown_pipeline_assignments=unknown,unassigned_encoder_selections=unassigned,measured_stage_seconds=sum(x['total_seconds']for x in group_report),total_stages=sum(x['stages']for x in group_report),groups=group_report)
 report.append(dict(**summary,passes=per_pass,pipelines=pp))
 print(json.dumps({**summary,'groups':group_report[:9]},indent=2))
(P/'copy-stage-causal-named-analysis.json').write_text(json.dumps(report,indent=2))
