from pathlib import Path
import fcntl,json,os,subprocess,sys,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
lock=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(P/'stat-cost-child.lock');before=preflight(4)
assert not(P/'stat-cost-probe.json').exists()
cmd=['xcrun','clang++','-std=c++17','-O2',str(P/'stat_cost_probe.cpp'),'-o',str(P/'stat-cost-probe')]
r=subprocess.run(cmd,capture_output=True,text=True,timeout=120);(P/'stat-cost-build.log').write_text(r.stdout+r.stderr);assert r.returncode==0
paths=sorted((R/'.build/smart-dflash-eval/gsq').glob('Qwen3.8-Flash-Next-GSQ-RCO-Q2_0-0000*-of-00002.gguf'));assert len(paths)==2
run=[str(P/'stat-cost-probe'),*map(str,paths)];r=subprocess.run(run,capture_output=True,text=True,timeout=90);(P/'stat-cost-probe.log').write_text(r.stdout+r.stderr)
receipt=dict(before=before,build=cmd,command=run,exit_code=r.returncode,source_sha256=hashlib.sha256((P/'stat_cost_probe.cpp').read_bytes()).hexdigest(),scope='Metadata-only cost probe: no weight reads, no model or GPU work. Continuous 4/18/22-thread load is not the actual interleaved reader schedule, so its wall time is not an inference speedup or measured critical path.')
if r.returncode==0:
 rows=[]
 for line in r.stdout.splitlines():
  x=line.split();assert len(x)==7 and x[0]=='ROW';rows.append(dict(round=int(x[1]),mode=int(x[2]),threads=int(x[3]),fstats=int(x[4]),wall_seconds=float(x[5]),cpu_seconds=float(x[6])))
 assert len(rows)==12;receipt['rows']=rows
(P/'stat-cost-probe.json').write_text(json.dumps(receipt,indent=2));print(json.dumps({k:v for k,v in receipt.items()if k not in ['before','build','command']}));assert r.returncode==0
