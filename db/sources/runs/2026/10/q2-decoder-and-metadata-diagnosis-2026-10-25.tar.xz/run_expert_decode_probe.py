from pathlib import Path
import fcntl,json,os,subprocess,sys,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight,terminate_child_tree
sys.path.insert(0,str(R/'.build/native-q2-20261021'));from thermal import wait_nominal
lock=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);inner=P/'expert-decode-child.lock';os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(inner);preflight(7)
source=Path('/var/folders/d4/t1c8ltbx5s3_11cs9y6gjh8m0000gp/T/slotstream-splash-host-ugnf26pi/source')
cmd=['xcrun','clang++','-std=c++17','-O2','-fobjc-arc','-framework','Foundation','-framework','Metal','-I'+str(source/'runtime'),str(P/'expert-decode-probe.mm'),'-o',str(P/'expert-decode-probe')]
r=subprocess.run(cmd,capture_output=True,text=True,timeout=120);(P/'expert-decode-build.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stderr
wait_nominal(P/'expert-decode-cooldown.json');preflight(7)
run=[sys.executable,str(P/'quiet_guarded_run.py'),'--label','expert-decode','--budget','4','--timeout','600','--env','SLOTSTREAM_MODEL_LOCK_PATH='+str(inner),'--',str(P/'expert-decode-probe'),str(P/'expert-decode-probe.metal'),str(P/'upstream/splash.metallib')]
with(P/'expert-decode-launcher.log').open('x')as f:
 child=subprocess.Popen(run,stdout=f,stderr=subprocess.STDOUT,cwd=R,start_new_session=True)
 try:rc=child.wait(timeout=660)
 finally:
  if child.poll() is None:terminate_child_tree(child)
receipt=dict(build=cmd,run=run,exit_code=rc,hashes={n:hashlib.sha256((P/n).read_bytes()).hexdigest()for n in ['expert-decode-probe.mm','expert-decode-probe.metal','expert-decode-probe','upstream/splash.metallib']})
(P/'expert-decode-receipt.json').write_text(json.dumps(receipt,indent=2));print('EXPERT_DECODE_EXIT',rc);assert rc==0
