from pathlib import Path
import bisect,collections,csv,json
P=Path(__file__).resolve().parent
label='stat-overlap-0-N'
data=json.loads((P/(label+'.json')).read_text());steps=[r for r in data['runs'] if r['round']==1]
limits=[(r['start_ns']/1e9,r['end_ns']/1e9) for r in steps];starts=[x[0] for x in limits]
def union(xs):
 out=[]
 for a,b in sorted(xs):
  if b<=a:continue
  if not out or a>out[-1][1]:out.append([a,b])
  else:out[-1][1]=max(out[-1][1],b)
 return out
def length(xs):return sum(b-a for a,b in xs)
def intersect(a,b):
 out=[];i=j=0
 while i<len(a) and j<len(b):
  lo,hi=max(a[i][0],b[j][0]),min(a[i][1],b[j][1])
  if hi>lo:out.append([lo,hi])
  if a[i][1]<b[j][1]:i+=1
  else:j+=1
 return out
def buckets():return [[] for _ in limits]
bykind={k:buckets() for k in ['stat','read','gpu']}; counts=collections.Counter();fds=collections.Counter();threads=collections.Counter();dur=[];footers={}
for kind,suffix in [('stat','stats.*.csv'),('read','reads.*.csv'),('gpu','commands.*.stages.csv')]:
 path=next(P.glob(label+'-'+suffix))
 with path.open() as f:
  for row in csv.DictReader(f):
   if next(iter(row.values())).startswith('#'):
    footers[kind]=dict(t.split('=') for t in next(iter(row.values()))[2:].split());continue
   a,b=(int(row['gpu_start'])/1e9,int(row['gpu_end'])/1e9) if kind=='gpu' else (float(row['start']),float(row['end']))
   if b<=limits[0][0] or a>=limits[-1][1] or b<=a:continue
   i=max(0,bisect.bisect_right(starts,a)-1)
   while i<len(limits) and limits[i][0]<b:
    lo,hi=max(a,limits[i][0]),min(b,limits[i][1])
    if hi>lo:
     bykind[kind][i].append((lo,hi))
     if kind=='stat':
      counts[row['result']]+=1;fds[row['fd']]+=1;threads[row['thread']]+=1;dur.append((hi-lo)*1e6)
    i+=1
 for k in ['total','cap']:
  assert k in footers[kind]
 assert int(footers[kind]['total'])<int(footers[kind]['cap'])
metrics=[]
for i,r in enumerate(steps):
 su,ru,gu=[union(bykind[k][i])for k in ['stat','read','gpu']]
 metrics.append(dict(step=r['step'],width=r['width'],wall=limits[i][1]-limits[i][0],stat_count=len(bykind['stat'][i]),stat_service=length(bykind['stat'][i]),stat_union=length(su),read_union=length(ru),gpu_union=length(gu),stat_read_overlap=length(intersect(su,ru)),stat_gpu_overlap=length(intersect(su,gu)),stat_outside_read_and_gpu=length(su)-length(intersect(su,union(ru+gu)))))
dur.sort();prior=json.loads((P/'commit-relaxed-0-B.json').read_text())['runs'];ref={(r['round'],r['step']):r['logits_sha256']for r in prior};exact=all(r['logits_sha256']==ref[(r['round'],r['step'])]for r in data['runs']);assert exact
out=dict(label=label,scope='Instrumented localization, not speed qualification. CPU services overlap each other and reads/GPU; timestamp stages are not utilization.',exact_full_native_hashes=exact,summary={k:sum(r[k]for r in metrics) for k in metrics[0]if k not in ['step','width']},result_counts=counts,fd_counts=fds,threads=len(threads),service_us_percentiles={str(p):dur[min(len(dur)-1,int((len(dur)-1)*p/100))]for p in [0,50,90,99,99.9,100]},footers=footers,passes=metrics)
(P/'stat-overlap-analysis.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items()if k!='passes'},indent=2))
