// Diagnostic only: bounded observations of actual metadata-check service.
#include <sys/stat.h>
#include <mach/mach_time.h>
#include <pthread.h>
#include <unistd.h>
#include <atomic>
#include <algorithm>
#include <cerrno>
#include <cstdio>
#include <cstdlib>
namespace {
constexpr size_t capacity=4194304;
struct Record{uint64_t start,end,thread;int fd,result,error;};
Record records[capacity];std::atomic<size_t> count{0};std::atomic<bool> enabled{false};
int observed(int fd,struct stat*value){
 if(!enabled.load(std::memory_order_relaxed))return fstat(fd,value);
 int before=errno;uint64_t thread=0;pthread_threadid_np(nullptr,&thread);size_t i=count.fetch_add(1,std::memory_order_relaxed);errno=before;
 uint64_t start=mach_absolute_time();int result=fstat(fd,value);int error=errno;uint64_t end=mach_absolute_time();
 if(i<capacity)records[i]={start,end,thread,fd,result,result<0?error:0};errno=error;return result;
}
void dump(){enabled=false;const char*prefix=getenv("SLOTSTREAM_STAT_OBSERVER");if(!prefix)return;char path[4096];snprintf(path,sizeof(path),"%s.%d.csv",prefix,getpid());FILE*f=fopen(path,"wx");if(!f)return;mach_timebase_info_data_t t;mach_timebase_info(&t);double scale=double(t.numer)/t.denom/1e9;fprintf(f,"start,end,thread,fd,result,error\n");size_t total=count.load();for(size_t i=0;i<std::min(total,capacity);++i){auto&r=records[i];fprintf(f,"%.9f,%.9f,%llu,%d,%d,%d\n",r.start*scale,r.end*scale,(unsigned long long)r.thread,r.fd,r.result,r.error);}fprintf(f,"# total=%zu cap=%zu\n",total,capacity);fclose(f);}
__attribute__((constructor))void initialize(){if(getenv("SLOTSTREAM_STAT_OBSERVER")){enabled=true;atexit(dump);}}
}
__attribute__((used))static struct{const void*replacement;const void*original;}interposer __attribute__((section("__DATA,__interpose")))={(const void*)&observed,(const void*)&fstat};
