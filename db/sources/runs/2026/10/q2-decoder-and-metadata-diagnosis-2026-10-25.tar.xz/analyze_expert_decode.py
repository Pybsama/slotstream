from pathlib import Path
import json,collections,statistics
P=Path(__file__).resolve().parent;groups=collections.defaultdict(lambda:collections.defaultdict(list));checks=[]
for l in (P/'expert-decode.log').read_text().splitlines():
 if not l.startswith(('TIME ','CHECK ')):continue
 v=dict(x.split('=')for x in l.split()[1:]);v={k:float(x)if k in ['seconds','max_error','peak'] else int(x)for k,x in v.items()}
 if l.startswith('CHECK '):checks.append(v);continue
 if v['round']<2:continue
 groups[(v['fused'],v['tiles'],v['rows'])][v['variant']].append(v['seconds']/v['repetitions'])
rows=[]
for k,g in groups.items():
 m=[statistics.median(g[i])for i in range(3)];r=dict(fused=k[0],tiles=k[1],rows=k[2],median_us=[x*1e6 for x in m],candidate_ratio=m[1]/m[0],splash_ratio=m[2]/m[0]);rows.append(r);print(k, ['%.3f'%x for x in r['median_us']],'paired %.2f%%'%((r['candidate_ratio']-1)*100),'Splash %.2f%%'%((r['splash_ratio']-1)*100))
guard=json.loads((P/'expert-decode.observer.json').read_text());eligible=not guard['paging'] and not guard['external_build_samples'] and guard['thermal_before']==guard['thermal_after']==0
out=dict(scope='cached synthetic expert kernel diagnosis only; excludes repack, shared expert, resident model, reads and whole requests',eligible=eligible,guard={k:guard[k]for k in ['peak_combined_bytes','paging','thermal_before','thermal_after','external_build_samples']},checks=checks,rows=rows)
(P/'expert-decode-analysis.json').write_text(json.dumps(out,indent=2));print('GUARD',out['guard']);print('mismatches',[(x['variant'],x['mismatches'])for x in checks if x['mismatches']])
