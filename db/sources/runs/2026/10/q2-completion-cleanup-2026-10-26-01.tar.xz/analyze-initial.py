from pathlib import Path
import ast,bisect,collections,csv,fcntl,hashlib,json,math,os,statistics,struct,subprocess,sys
P=Path(__file__).resolve().parent;R=P.parents[1];D=P.parent/'q2-required-dependencies-20261026'
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
reservation=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(reservation,fcntl.LOCK_EX|fcntl.LOCK_NB);os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(P/'analysis-child.lock');preflight(5)
events=json.loads((P/'trace-ledger.json').read_text());assert len(events)==4
assert all(hashlib.sha256((P/n).read_bytes()).hexdigest()==h for n,h in json.loads((P/'frozen-identity.json').read_text()).items())
scope={k:globals()[k]for k in ['Path','bisect','collections','csv','json','statistics','struct','subprocess']};scope.update(P=P,PAGE=65536)
defs=[n for n in ast.parse((D/'analyze_dependencies.py').read_text()).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))]
exec(compile(ast.Module(body=defs,type_ignores=[]),'dependency-analysis-defs','exec'),scope)
union,inter,length,Coverage,rows,footer=map(scope.get,['union','inter','length','Coverage','csv_rows','footer'])
times=[e['round_seconds'][-1]for e in events];ratios=[times[1]/times[0],times[2]/times[3]];pooled=math.sqrt(math.prod(ratios))
control=dict(observed_seconds=times,direction_ratios=ratios,pooled_ratio=pooled,environment_eligible=all(e['eligible']for e in events),sensitivity_pass=all(abs(r-1)<=.02 for r in [*ratios,pooled]))
report=[]
names={int(k):v for k,v in json.loads((P/'plan.json').read_text())['fields'].items()}
for event in events:
 if not event['probe']:continue
 label=event['label'];print('ANALYZE',label,flush=True)
 dependency=scope['analyze'](dict(event,arm='N'))
 # analyze writes its own full exact-ancestry receipt. Read it rather than
 # assume a particular Python return type from the archived helper.
 dep=json.loads((P/(label+'-dependency-analysis.json')).read_text());assert not dep['missing_or_ambiguous_dependencies'],dep['missing_or_ambiguous_dependencies'][:3]
 raw=json.loads((P/(label+'.json')).read_text());last=raw['rounds'][-1];windows=union((r['start_ns']/1e9,r['end_ns']/1e9)for r in last['steps'])
 stages=next(P.glob(label+'-commands.*.stages.csv'));sf=footer(stages);assert sf['cpu_initial']==sf['gpu_initial']and sf['cpu_final']==sf['gpu_final']
 gpu=union((int(r['gpu_start'])/1e9,int(r['gpu_end'])/1e9)for r in rows(stages)if int(r['gpu_end'])>int(r['gpu_start'])>0)
 jobs=[j for j in dep['jobs']if j['round']==last['round']];assert len(jobs)==5328
 required=union((j['begin'],max(j['begin'],j.get('gpu_start',j['published'])))for j in jobs)
 covered=union(gpu+required);meta=json.loads((P/(label+'.json.cleanup.json')).read_text());scale=meta['numer']/meta['denom']/1e9
 assert meta['active']==meta['overflow']==0 and meta['threads']<=128
 binary=(P/(label+'.json.cleanup.bin')).read_bytes();assert len(binary)==72*meta['allocated_rows'];owner=meta['owner'];filled=0
 kinds=collections.defaultdict(list);owner_rows=[];background_rows=[];submit_waits=[];completion_holds=collections.defaultdict(list);max_end=0
 for i,v in enumerate(struct.iter_unpack('<9Q',binary)):
  start,acq,rel,end,thread,obj,parent,count,kind=v
  if not start:assert not any(v);continue
  filled+=1;assert start<=end and thread>0 and kind in names
  if parent:
   assert 0<parent<=meta['allocated_rows'];p=struct.unpack_from('<9Q',binary,(parent-1)*72);assert p[0]<=start<=end<=p[3]and p[4]==thread,(i,parent,v,p)
  if kind in (5,6):assert start<=acq<=rel<=end
  else:assert acq==rel==0
  interval=(start*scale,end*scale);max_end=max(max_end,interval[1]);is_owner=thread==owner
  if interval[1]<windows[0][0]or interval[0]>windows[-1][1]:continue
  kinds[(kind,is_owner)].append(interval)
  if kind in (1,2,3,4,9,10,11):(owner_rows if is_owner else background_rows).append(interval)
  if kind==5 and is_owner:submit_waits.append((obj,start*scale,acq*scale))
  if kind==6 and not is_owner:completion_holds[obj].append((acq*scale,rel*scale))
 assert filled==meta['filled_rows']
 def coverage(xs):
  u=inter(union(xs),windows);g=length(inter(u,gpu));c=length(inter(u,covered))
  return dict(union_seconds=length(u),outside_gpu_seconds=length(u)-g,outside_gpu_or_required_dependency_seconds=length(u)-c)
 details=[dict(kind=kind,name=names[kind],request_owner=on,count=len(v),summed_seconds=sum(b-a for a,b in v),**coverage(v))for(kind,on),v in sorted(kinds.items())]
 waits=union((a,b)for obj,a,b in submit_waits);matched=[]
 for obj,a,b in submit_waits:matched+=inter([(a,b)],union(completion_holds[obj]))
 result=dict(label=label,cycle_seconds=length(windows),gpu=coverage(gpu),required_dependency=coverage(required),residual_seconds=length(windows)-length(inter(windows,covered)),metadata=meta,filled_rows=filled,owner_destruction=coverage(owner_rows),background_destruction=coverage(background_rows),owner_submit_lock_wait=coverage(waits),owner_wait_overlapping_same_mutex_background_hold=coverage(matched),details=details,required_jobs=len(jobs),recorded_tail_after_request_seconds=max(0,max_end-last['end_ns']/1e9),limits='Destructor/container spans include nested releases and overlap callbacks. Only unions are wall coverage. Background cleanup is not request waiting. Same-mutex held/wait overlap localizes contention but excludes scheduler wakeup after release. Covered GPU/required jobs do not represent all possible device activity.')
 report.append(result);print(json.dumps({k:v for k,v in result.items()if k not in ['details','metadata']},indent=2),flush=True)
 for r in details:print(r['kind'],r['request_owner'],r['count'],r['union_seconds'],r['outside_gpu_or_required_dependency_seconds'],flush=True)
out=dict(control=control,arms=report,representative_attribution_qualified=control['environment_eligible']and control['sensitivity_pass'],scope='Actual new cleanup instrument compared with prior unmodified dependency baseline. Fixed111cycle diagnostic, not ordinary-request performance or broad quality.')
(P/'analysis.json').write_text(json.dumps(out,indent=2));print('CONTROL',json.dumps(control),flush=True)
