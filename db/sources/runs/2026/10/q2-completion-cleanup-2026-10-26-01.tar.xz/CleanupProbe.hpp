#pragma once
// Temporary diagnostic. Own exactly the original containers and release them
// at their original capture-destruction boundary, including bucket storage.
#include <atomic>
#include <cstdio>
#include <cstdint>
#include <cstdlib>
#include <mutex>
#include <type_traits>
#include <utility>
#include <mach/mach_time.h>
#include <pthread.h>
#include <unistd.h>
namespace sscleanup {
constexpr size_t cap=4194304,chunk=256,max_threads=128;
struct Row {uint64_t start=0,acquired=0,released=0,end=0,thread=0,object=0,parent=0,count=0,kind=0;};
static_assert(sizeof(Row)==72);
inline Row rows[cap];
struct alignas(128) Thread {std::atomic<size_t> active{0};uint64_t id=0;};
inline Thread threads[max_threads];
alignas(128) inline std::atomic<bool> enabled{false};
alignas(128) inline std::atomic<size_t> next{0},thread_count{0},overflow{0};
inline uint64_t owner=0;
struct Local {size_t thread=max_threads,base=0,used=chunk;uint64_t parent=0;};
inline thread_local Local local;
inline uint64_t tid(){uint64_t n=0;pthread_threadid_np(nullptr,&n);return n;}
struct Scope {
 Row* row=nullptr;size_t id=0,thread=max_threads;uint64_t previous=0;
 Scope(uint64_t kind,uint64_t object=0,uint64_t count=0){
  if(!enabled.load(std::memory_order_seq_cst))return;
  if(local.thread==max_threads){
   local.thread=thread_count.fetch_add(1,std::memory_order_seq_cst);
   if(local.thread>=max_threads){overflow++;return;}
   threads[local.thread].id=tid();
  }
  if(local.thread>=max_threads){overflow++;return;}
  thread=local.thread;threads[thread].active.fetch_add(1,std::memory_order_seq_cst);
  if(!enabled.load(std::memory_order_seq_cst)){threads[thread].active.fetch_sub(1,std::memory_order_seq_cst);thread=max_threads;return;}
  if(local.used==chunk){local.base=next.fetch_add(chunk,std::memory_order_relaxed);local.used=0;}
  size_t i=local.base+local.used++;
  if(i>=cap){overflow++;threads[thread].active.fetch_sub(1,std::memory_order_seq_cst);thread=max_threads;return;}
  row=&rows[i];id=i+1;previous=local.parent;local.parent=id;
  *row={};row->thread=threads[thread].id;row->object=object;row->parent=previous;row->count=count;row->kind=kind;row->start=mach_absolute_time();
 }
 Scope(const Scope&)=delete;Scope&operator=(const Scope&)=delete;
 ~Scope(){if(row){row->end=mach_absolute_time();local.parent=previous;threads[thread].active.fetch_sub(1,std::memory_order_seq_cst);}}
};
template<class T,uint64_t Kind>struct Owned {
 union {T value;};uint64_t object;
 Owned(T&&v,uint64_t o):value(std::move(v)),object(o){}
 Owned(const Owned&o):value(o.value),object(o.object){}
 Owned(Owned&&o) noexcept(std::is_nothrow_move_constructible<T>::value):value(std::move(o.value)),object(o.object){}
 ~Owned(){
  size_t n;if constexpr(std::is_invocable<T>::value)n=bool(value)?1:0;else n=value.size();
  if(n){Scope s(Kind,object,n);value.~T();}else value.~T();
 }
 auto begin(){return value.begin();}auto end(){return value.end();}
 explicit operator bool()const{return bool(value);}
 decltype(auto) operator()(){return value();}
};
template<uint64_t Kind,class T>Owned<T,Kind> own(T&&value,uint64_t object){return Owned<T,Kind>(std::move(value),object);}
struct Lock {
 Scope scope;std::unique_lock<std::mutex> lock;
 Lock(std::mutex&m,uint64_t kind):scope(kind,reinterpret_cast<uint64_t>(&m)),lock(m){if(scope.row)scope.row->acquired=mach_absolute_time();}
 ~Lock(){if(scope.row)scope.row->released=mach_absolute_time();lock.unlock();}
};
inline void begin(){
 // Exactly one recorded round per process; TLS chunk ownership is not reset.
 if(next.load()||enabled.load()||thread_count.load())std::abort();
 owner=tid();enabled.store(true,std::memory_order_seq_cst);
}
inline size_t active(){size_t n=0;for(size_t i=0;i<thread_count.load()&&i<max_threads;++i)n+=threads[i].active.load(std::memory_order_seq_cst);return n;}
inline int end(const char*prefix){
 enabled.store(false,std::memory_order_seq_cst);
 if(tid()!=owner)return -2;
 // Only drain already-started diagnostic writes after the request timer.
 for(int i=0;i<2000&&active();++i)usleep(1000);
 if(active())return -3;
 size_t n=next.load();if(n>cap||overflow.load()||thread_count.load()>max_threads)return -4;
 char path[4096];if(snprintf(path,sizeof(path),"%s.bin",prefix)>=int(sizeof(path)))return -5;
 FILE*f=fopen(path,"wbx");if(!f)return -6;bool okay=fwrite(rows,sizeof(Row),n,f)==n;fclose(f);if(!okay)return -7;
 if(snprintf(path,sizeof(path),"%s.json",prefix)>=int(sizeof(path)))return -8;
 f=fopen(path,"wx");if(!f)return -9;mach_timebase_info_data_t tb;mach_timebase_info(&tb);size_t filled=0;
 for(size_t i=0;i<n;++i)filled+=rows[i].start!=0;
 fprintf(f,"{\"allocated_rows\":%zu,\"filled_rows\":%zu,\"cap\":%zu,\"row_bytes\":72,\"numer\":%u,\"denom\":%u,\"owner\":%llu,\"active\":%zu,\"threads\":%zu,\"overflow\":%zu,\"layout\":\"little-endian9uint64:start,acquired,released,end,thread,object,parent,count,kind\"}\n",n,filled,cap,tb.numer,tb.denom,owner,active(),thread_count.load(),overflow.load());fclose(f);return 0;
}
}
