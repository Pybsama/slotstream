#pragma once
#include "NativeSchedule.h"
#include "NativeProgram.h"
#include "AdaptiveReplacement.h"

// Diagnostic-only completion cleanup scope.
#ifdef __cplusplus
extern "C" {
#endif
void ss_mlx_cleanup_probe_begin(void);
int ss_mlx_cleanup_probe_end(const char* prefix);
#ifdef __cplusplus
}
#endif
