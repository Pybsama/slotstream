#include "CleanupProbe.hpp"
#include <cassert>
#include <chrono>
#include <functional>
#include <memory>
#include <thread>
#include <unordered_set>
#include <vector>
struct Life {int* count;~Life(){++*count;}};
int main(int argc,char**argv){
 assert(argc==2);int destroyed=0;auto item=std::make_shared<Life>();item->count=&destroyed;
 sscleanup::begin();
 {
  std::unordered_set<std::shared_ptr<Life>> original{item};assert(item.use_count()==2);
  auto owners=sscleanup::own<1>(std::move(original),123);assert(item.use_count()==2&&original.empty());
  {
   auto copy=owners;assert(item.use_count()==3);
   auto moved=std::move(copy);assert(item.use_count()==3&&copy.value.empty());
   std::function<void()> f=[hold=std::move(moved)](){assert(hold.value.size()==1);};
   assert(item.use_count()==3);auto wrapped=sscleanup::own<9>(std::move(f),124);assert(!f&&bool(wrapped));wrapped();
   assert(item.use_count()==3&&destroyed==0);
  }
  assert(item.use_count()==2&&destroyed==0);
 }
 assert(item.use_count()==1&&destroyed==0);
 std::mutex mutex;std::atomic<bool> entered{false};
 std::thread worker([&]{sscleanup::Scope body(7,456);sscleanup::Lock lock(mutex,6);entered=true;std::this_thread::sleep_for(std::chrono::milliseconds(12));});
 while(!entered.load())std::this_thread::sleep_for(std::chrono::microseconds(100));
 {sscleanup::Lock lock(mutex,5);}worker.join();
 assert(sscleanup::end(argv[1])==0);item.reset();assert(destroyed==1);
 bool waiting=false,nested=false;size_t count=0;
 for(size_t i=0;i<sscleanup::next.load();++i){const auto&r=sscleanup::rows[i];if(!r.start)continue;++count;assert(r.start<=r.end);if(r.parent){const auto&p=sscleanup::rows[r.parent-1];assert(p.start<=r.start&&r.end<=p.end&&p.thread==r.thread);nested=true;}if(r.kind==5){mach_timebase_info_data_t t;mach_timebase_info(&t);assert(r.start<=r.acquired&&r.acquired<=r.released&&r.released<=r.end);waiting=(r.acquired-r.start)*double(t.numer)/t.denom>5e6;}}
 assert(waiting&&nested&&count>=6);printf("SELFTEST PASS: exact shared-owner retention across copy/move/function captures; final release once; nested intervals; two-thread measured lock contention; %zu records\n",count);
}
