from pathlib import Path
import argparse,fcntl,json,os,subprocess,sys,time
P=Path(__file__).resolve().parent;R=P.parents[1];F=P.parent/'q2-full-cycle-20261025'
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight,terminate_child_tree
sys.path.insert(0,str(R/'.build/native-q2-20261021'));from thermal import wait_nominal
ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['validation','trace']);a=ap.parse_args();validation=a.mode=='validation'
reservation=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(reservation,fcntl.LOCK_EX|fcntl.LOCK_NB)
inner=P/(a.mode+'-child.lock');os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(inner)
ledger=P/(a.mode+'-ledger.json');assert not ledger.exists();events=[]
ref=json.loads((F/'validation-0-N.json').read_text())['rounds'][0]['steps']
if not validation:assert json.loads((P/'validation-result.json').read_text())['passed']
for i,on in enumerate([True]if validation else[False,True,True,False]):
 label=f'{a.mode}-{i}-'+('on'if on else'off');out=P/(label+'.json');assert not out.exists();rounds=1 if validation else 2
 wait_nominal(P/(label+'-cooldown.json'));preflight(18)
 env=['--env','SLOTSTREAM_MODEL_LOCK_PATH='+str(inner),'--env','DYLD_INSERT_LIBRARIES=','--env','SLOTSTREAM_DEPENDENCY_OBSERVER='+str(P/(label+'-dependencies'))]
 if validation:env+=['--env','MTL_DEBUG_LAYER=1']
 else:
  env[3]='DYLD_INSERT_LIBRARIES='+str(R/'.build/q2-sequence-20261025/copy_observer.dylib')+':'+str(R/'.build/q2-sequence-20261025/named_stage_observer.dylib')+':'+str(R/'.build/q2-handoff-20261025/read_observer.dylib')
  env+=['--env','SLOTSTREAM_COPY_OBSERVER='+str(P/(label+'-copies')),'--env','SLOTSTREAM_METAL_OBSERVER='+str(P/(label+'-commands')),'--env','SLOTSTREAM_READ_OBSERVER='+str(P/(label+'-reads'))]
 binary=P/'native-build/candidate/slotstream'if on else P.parent/'q2-required-dependencies-20261026/native-build/candidate/slotstream'
 cmd=[str(binary),'q2-profile','--fixture',str(P/'timed-2.json'),'--output',str(out),'--memory-gb','15','--rounds',str(rounds)]
 if validation:cmd+=['--validate']
 if on:cmd+=['--cleanup-probe']
 full=[sys.executable,str(P/'quiet_guarded_run.py'),'--label',label,'--budget','15','--timeout','600',*env,'--',*cmd]
 print('START',label,flush=True);monitor=None
 with(P/(label+'-launcher.log')).open('x')as log,(P/(label+'-frequency.jsonl')).open('x')as freq,(P/(label+'-frequency.stderr')).open('x')as ferr:
  if not validation:monitor=subprocess.Popen([str(R/'.build/native-monitor/macmon'),'pipe','-s','3300','-i','200','--soc-info'],stdout=freq,stderr=ferr,start_new_session=True)
  child=subprocess.Popen(full,cwd=R,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:rc=child.wait(timeout=660)
  finally:
   if child.poll()is None:terminate_child_tree(child)
   if monitor and monitor.poll()is None:terminate_child_tree(monitor)
 guard=json.loads((P/(label+'.observer.json')).read_text());event=dict(label=label,probe=on,exit_code=rc,command=full,eligible=not guard['external_build_samples'] and not guard['paging'] and guard['thermal_before']==guard['thermal_after']==0 and guard['peak_combined_bytes']<=15e9 and rc==0)
 events.append(event);ledger.write_text(json.dumps(events,indent=2));assert rc==0
 d=json.loads(out.read_text());assert d['complete'] and d['plan']['pool_slots']==4067
 for rd in d['rounds']:
  assert len(rd['steps'])==111
  for row,expected in zip(rd['steps'],ref):
   for k in ['actual_guesses','actual_selected']+(['logits_sha256']if validation else[]):assert row[k]==expected[k],(label,rd['round'],row['step'],k)
 if on:
  meta=json.loads(Path(str(out)+'.cleanup.json').read_text());assert meta['active']==0 and 0<meta['filled_rows']<=meta['allocated_rows']<=meta['cap'] and meta['row_bytes']==72 and meta['overflow']==0
  assert Path(str(out)+'.cleanup.bin').stat().st_size==meta['allocated_rows']*72
  event['probe_rows']=meta['filled_rows']
 dep=json.loads(next(P.glob(label+'-dependencies.*.json')).read_text());assert 0<dep['rows']==dep['written']<dep['cap']
 assert next(P.glob(label+'-dependencies.*.bin')).stat().st_size==dep['rows']*64
 event['round_seconds']=[r['seconds']for r in d['rounds']];ledger.write_text(json.dumps(events,indent=2));print('END',label,event['eligible'],event['round_seconds'],event.get('probe_rows'),flush=True)
if validation:(P/'validation-result.json').write_text(json.dumps(dict(passed=True,full_logit_hashes=111,exact_proposals=111,exact_selected=111,scope='Actual MLX capture destruction/output-map locks with exact original native111whole-logits/proposals/selectedIDs and Metalvalidation;4067slots15GB8192context. No speed evidence.'),indent=2))
print('PROTOCOL FINISHED',flush=True)
