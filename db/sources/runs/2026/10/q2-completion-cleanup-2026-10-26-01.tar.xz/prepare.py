from pathlib import Path
import json,hashlib,shutil,subprocess
P=Path(__file__).resolve().parent;R=P.parents[1];F=P.parent/'q2-full-cycle-20261025';D=P.parent/'q2-required-dependencies-20261026';M=R/'.build/checkouts/mlx-swift'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=M,text=True).strip()
base='.build/checkouts/mlx-swift/Source/Cmlx/mlx/mlx/backend/metal/'
def replace(s,a,b):assert s.count(a)==1,(a,s.count(a));return s.replace(a,b)
rep={base+'CleanupProbe.hpp':'CleanupProbe.hpp'}
s=(R/(base+'eval.cpp')).read_text();(P/'eval-original.cpp').write_text(s);s='#include "CleanupProbe.hpp"\n'+s
s=replace(s,'[s, buffers = std::move(buffers)]() {','[s, buffers = sscleanup::own<1>(std::move(buffers),reinterpret_cast<uint64_t>(command_buffer))]() {')
s=replace(s,'[buffers = std::move(buffers)](MTL::CommandBuffer* cbuf) {}','[buffers = sscleanup::own<1>(std::move(buffers),reinterpret_cast<uint64_t>(command_buffer))](MTL::CommandBuffer* cbuf) {}')
s+='\nextern "C" void ss_mlx_cleanup_probe_begin(){sscleanup::begin();}\nextern "C" int ss_mlx_cleanup_probe_end(const char*p){return sscleanup::end(p);}\n'
(P/'eval-probe.cpp').write_text(s);rep[base+'eval.cpp']='eval-probe.cpp'
s=(R/(base+'device.cpp')).read_text();(P/'device-original.cpp').write_text(s);s='#include "CleanupProbe.hpp"\n'+s
s=replace(s,'    std::lock_guard lk(outputs_mtx_);\n    for (auto& in : all_inputs_)','    sscleanup::Lock lk(outputs_mtx_,5);\n    for (auto& in : all_inputs_)')
s=replace(s,'temporaries = std::move(temporaries_),','temporaries = sscleanup::own<2>(std::move(temporaries_),reinterpret_cast<uint64_t>(buffer_.get())),')
s=replace(s,'all_outputs = std::move(all_outputs_),','all_outputs = sscleanup::own<4>(std::move(all_outputs_),reinterpret_cast<uint64_t>(buffer_.get())),')
s=replace(s,'waiting_on = std::move(waiting_on)](','waiting_on = sscleanup::own<3>(std::move(waiting_on),reinterpret_cast<uint64_t>(buffer_.get()))](')
s=replace(s,'                                   MTL::CommandBuffer*) mutable {\n    std::lock_guard lk(outputs_mtx_);','                                   MTL::CommandBuffer* ss_cb) mutable {\n    sscleanup::Scope body(7,reinterpret_cast<uint64_t>(ss_cb),all_outputs.value.size());\n    sscleanup::Lock lk(outputs_mtx_,6);')
s=replace(s,'wait_events = std::move(wait_events_),','wait_events = sscleanup::own<10>(std::move(wait_events_),reinterpret_cast<uint64_t>(buffer_.get())),')
s=replace(s,'signal_events = std::move(signal_events_),','signal_events = sscleanup::own<11>(std::move(signal_events_),reinterpret_cast<uint64_t>(buffer_.get())),')
s=replace(s,'completion = std::move(completion)](MTL::CommandBuffer* cbuf) mutable {','completion = sscleanup::own<9>(std::move(completion),reinterpret_cast<uint64_t>(buffer_.get()))](MTL::CommandBuffer* cbuf) mutable {\n        sscleanup::Scope body(8,reinterpret_cast<uint64_t>(cbuf));')
(P/'device-probe.cpp').write_text(s);rep[base+'device.cpp']='device-probe.cpp'
for n in ['NativeSchedule-probe.cpp','DependencyProbe.hpp']:shutil.copy2(D/n,P/n)
rep.update({'Sources/CNativeSchedule/NativeSchedule.cpp':'NativeSchedule-probe.cpp','Sources/CNativeSchedule/DependencyProbe.hpp':'DependencyProbe.hpp'})
s=(R/'Tools/build_identity.py').read_text();needle='    if any(p.is_symlink() for p in candidates):'
s=replace(s,needle,'    # Identity-bound temporary dependency diagnostics.\n'+''.join('    candidates.append(root/'+repr(base+n)+')\n'for n in ['eval.cpp','device.cpp','CleanupProbe.hpp'])+needle)
(P/'build_identity-probe.py').write_text(s);rep['Tools/build_identity.py']='build_identity-probe.py'
s=(R/'Sources/CNativeSchedule/include/CNativeSchedule.h').read_text()+'''\n// Diagnostic-only completion cleanup scope.
#ifdef __cplusplus
extern "C" {
#endif
void ss_mlx_cleanup_probe_begin(void);
int ss_mlx_cleanup_probe_end(const char* prefix);
#ifdef __cplusplus
}
#endif
'''
(P/'CNativeSchedule-probe.h').write_text(s);rep['Sources/CNativeSchedule/include/CNativeSchedule.h']='CNativeSchedule-probe.h'
s=(F/'Q2ProfileCommand.swift').read_text().replace('import Slotstream','import Slotstream\nimport CNativeSchedule').replace('    @Flag var validate = false','    @Flag var validate = false\n    @Flag var cleanupProbe = false')
s=replace(s,'                    let requestStart=RuntimeClock.now()','                    if cleanupProbe && round == rounds-1 { ss_mlx_cleanup_probe_begin() }\n                    let requestStart=RuntimeClock.now()')
s=replace(s,'                    let requestEnd=RuntimeClock.now()','''                    let requestEnd=RuntimeClock.now()
                    if cleanupProbe && round == rounds-1 {
                        let rc = (output + ".cleanup").withCString { ss_mlx_cleanup_probe_end($0) }
                        guard rc == 0 else { throw ModelError("Cleanup diagnostic failed: \\(rc)") }
                    }''')
(P/'Q2ProfileCommand-probe.swift').write_text(s);rep['Sources/slotstream-cli/Q2ProfileCommand.swift']='Q2ProfileCommand-probe.swift'
(P/'replacements.json').write_text(json.dumps(rep,indent=2))
for n in ['quiet_guarded_run.py','timed-2.json','check_restoration.py']:shutil.copy2(F/n,P/n)
plan=dict(scope='Actual completion capture destruction and output-map locking. Diagnostic only; preserve original captured container types, copy/move semantics, destructor boundaries, mutex identity and publication order. No performance candidate.',prior_evidence='Matched read-delay comparison makes native less sensitive than Splash; do not revive started-forecast reuse. Existing capture/registration and allocator-method probes do not cover later destruction or encoder output-map mutex.',fields={1:'captured array::Data unordered_set destruction',2:'temporary array vector destruction',3:'waited fence set destruction',4:'output set destruction',5:'submission output-map mutex',6:'completion output-map mutex',7:'end-encoding callback body; nested lock6',8:'commit completion body',9:'commit completion function capture destruction; may nest owner1',10:'wait-event vector destruction',11:'signal-event vector destruction'},recording='Last round only. Thread-local row chunks and nesting, bounded4M72byte rows,128threads. Stop admits no new rows; drain only already-active record writes after request timer. Complete lifetimes outside the recorded round are not inferred. Skip empty captured containers.',validation='Independent copied/moved shared-owner/function-capture lifetime tests and real two-thread mutex contention; one111cycle whole-logit/proposal/selected-ID native match underMetalvalidation.',protocol='Off/on/on/off; one warmup plus one measured111cycle perprocess. Existing dependency/read/copy/encoder probes identical and enabled in all timing arms. Compare new cleanup recording sensitivity with2percent pooled and both-direction gate; retain all arms and no retry selection. Match15GBphysical4067slotsnative8192contextBF16activation/KVFP32state,18GBpreflight,1GBremaining,nominalthermal,nopaging,nocompetingheavywork. Global model lock across entire protocol.',interpretation='Resolve exact required payloads and readiness through reused ancestry analysis. Separate request-owner waits from background cleanup, correlate lock waits with same-mutex background holds, and intersect with actual GPU and required-dependency coverage. Nested rows overlap; never sum them as wall time. A large count or concurrent cleanup sum does not establish a bottleneck.',dependency_revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=M,text=True).strip(),hashes={n:hashlib.sha256((P/f).read_bytes()).hexdigest()for n,f in rep.items()})
(P/'plan.json').write_text(json.dumps(plan,indent=2));print('PREPARED',len(rep),'identity-bound diagnostic sources',flush=True)
