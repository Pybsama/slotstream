from pathlib import Path
import csv,json,collections
P=Path(__file__).resolve().parent

def parsed(path):
 with path.open()as f:rs=list(csv.DictReader(l for l in f if not l.startswith('#')))
 with path.open('rb')as f:f.seek(max(0,path.stat().st_size-256));tail=f.read().decode().splitlines()[-1]
 foot=dict(x.split('=')for x in tail[2:].split());assert int(foot['total'])<int(foot['cap']),(path,foot)
 return rs

def union(xs):
 out=[]
 for a,b in sorted(xs,key=lambda x:(x[0],x[1])):
  if b<=a:continue
  if not out or a>out[-1][1]:out.append([a,b])
  else:out[-1][1]=max(b,out[-1][1])
 return out

def length(xs):return sum(b-a for a,b in xs)
def inter(a,b):
 out=[];i=j=0
 while i<len(a)and j<len(b):
  lo,hi=max(a[i][0],b[j][0]),min(a[i][1],b[j][1])
  if hi>lo:out.append([lo,hi])
  if a[i][1]<b[j][1]:i+=1
  else:j+=1
 return out
ledger=json.loads((P/'ordinary-tail-15-ledger.json').read_text());assert len(ledger)==1
e=ledger[0];label=e['label'];d=json.loads((P/(label+'.json')).read_text());stages=parsed(next(P.glob(label+'-commands.*.stages.csv')));reads=parsed(next(P.glob(label+'-reads.*.csv')))
assert all(int(x['gpu_end'])>int(x['gpu_start'])>0 for x in stages)
gpu_all=union((int(x['gpu_start'])/1e9,int(x['gpu_end'])/1e9)for x in stages);read_all=union((float(x['start']),float(x['end']))for x in reads if int(x['result'])>0)
out=[]
for r in d['runs']:
 if not r['id'].startswith('timed'):continue
 lo,hi=r['request_started_mach_ns']/1e9,r['request_ended_mach_ns']/1e9;w=[[lo,hi]];gpu=inter(gpu_all,w);read=inter(read_all,w);active=union(gpu+read)
 rows=parsed(P/(label+'.json.'+r['id']+'.host.csv'));groups=collections.defaultdict(list)
 for x in rows:
  a,b=int(x['start_ns'])/1e9,int(x['end_ns'])/1e9;assert lo<=a<=b<=hi,(lo,a,b,hi);groups[x['kind']].append([a,b])
 summaries=[]
 for kind,spans in groups.items():
  u=union(spans);dt=length(u);summaries.append(dict(kind=kind,calls=len(spans),service_seconds=sum(b-a for a,b in spans),union_seconds=dt,outside_reads_gpu=dt-length(inter(u,active)),outside_gpu=dt-length(inter(u,gpu)),outside_reads=dt-length(inter(u,read)),read_overlap=length(inter(u,read)),gpu_overlap=length(inter(u,gpu))))
 overall=union(sum(groups.values(),[]));result=dict(id=r['id'],request_seconds=hi-lo,target_passes=r['stats']['decodeForwardPasses'],gpu_seconds=length(gpu),read_seconds=length(read),outside_read_gpu=hi-lo-length(active),host_scopes_outside_read_gpu=length(overall)-length(inter(overall,active)),outside_all_observed=hi-lo-length(union(active+overall)),scopes=sorted(summaries,key=lambda x:-x['outside_reads_gpu']))
 assert r['streamed']==r['text']and len(r['tokens'])==384 and not r['stats'].get('runtimeError')
 out.append(result);print(json.dumps(result,indent=2))
(P/'host-scope-all-read-analysis.json').write_text(json.dumps(dict(environment_eligible=e['eligible'],scope='Bounded single-owner CPU elapsed scopes with all positive pread sizes and encoder intervals. Prior expert-read attribution used a64KiBthreshold; these all-read complements avoid classifying small token/PLEreads as host overhead. Parent and child scopes overlap and must not be summed. Encoder intervals include scheduling/stalls; complements are not guaranteed recoverable CPU delay. Diagnostic only; no speed or parity claim. Runtime restored after build.',requests=out),indent=2))
