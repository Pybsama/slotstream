from pathlib import Path
import shutil,json,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1];OLD=P.parent/'q2-graph-profile-20261025'
for n in ['NativeExpertSchedule-host.swift','ExpertStore-host.swift','SmartDFlashCommand-host.swift','DFlashDraft-host.swift','Layers-host.swift','Model-host.swift','named_stage_observer.mm','named_stage_observer.dylib','read_observer.cpp','read_observer.dylib','quiet_guarded_run.py','cases.json','run_host.py','build.py','check_restoration.py','analyze_host_all_reads.py']:
 shutil.copy2(OLD/n,P/n)
def replace(name,a,b):
 p=P/name;s=p.read_text();assert s.count(a)==1,(name,a,s.count(a));p.write_text(s.replace(a,b))
p=P/'NativeExpertSchedule-host.swift';p.write_text(p.read_text().replace('131072','262144'))
replace(p.name,'        package func value(afterRelease: (() -> Void)? = nil) throws -> MLXArray {','''        package func value(afterRelease: (() -> Void)? = nil) throws -> MLXArray {
            let hostPublish = Q2HostProbe.stamp()
            defer { Q2HostProbe.end("expert_publish_and_release", hostPublish) }''')
replace('ExpertStore-host.swift','            func readDemand(_ order: [Int]) throws {','''            func readDemand(_ order: [Int]) throws {
                let hostDemand = Q2HostProbe.stamp()
                defer { Q2HostProbe.end("pool_read_demand", hostDemand) }''')
replace('ExpertStore-host.swift','''            } else if let scheduler, !pendingReads.isEmpty {
                let finished = scheduler.finishReading(pendingReads)''','''            } else if let scheduler, !pendingReads.isEmpty {
                let hostJoin = Q2HostProbe.stamp()
                let finished = scheduler.finishReading(pendingReads)
                Q2HostProbe.end("pool_join_promoted", hostJoin)
                let hostAdopt = Q2HostProbe.stamp()''')
replace('ExpertStore-host.swift','''                let fallback = Set(try adoptTickets(finished))''','''                let fallback = Set(try adoptTickets(finished))
                Q2HostProbe.end("pool_adopt_promoted", hostAdopt)''')
replace('ExpertStore-host.swift','''        completed = true
        return result''','''        completed = true
        return result''') # assert function shape without changing behavior
s=(R/'Sources/Slotstream/DFlashGenerate.swift').read_text()
s=s.replace('''            let result = try model.allLogitsWithMultiChecked(input, state: state)
            eval(result.logits)''','''            let hostTargetCall = Q2HostProbe.stamp()
            let result = try model.allLogitsWithMultiChecked(input, state: state)
            Q2HostProbe.end("target_verify_call", hostTargetCall)
            let hostLogitsEval = Q2HostProbe.stamp()
            eval(result.logits)
            Q2HostProbe.end("target_logits_eval", hostLogitsEval)''')
s=s.replace('''            for position in 0...proposals.count {''','''            let hostSampleLoop = Q2HostProbe.stamp()
            for position in 0...proposals.count {''')
s=s.replace('''            let reconcileStart = RuntimeClock.now()''','''            Q2HostProbe.end("target_sample_loop", hostSampleLoop)
            let hostReconcile = Q2HostProbe.stamp()
            let reconcileStart = RuntimeClock.now()''')
s=s.replace('''            consumed.append(contentsOf: kept)
            if let captured {''','''            consumed.append(contentsOf: kept)
            Q2HostProbe.end("target_rollback_and_reconcile", hostReconcile)
            if let captured {''')
assert s.count('Q2HostProbe.end')==4
(P/'DFlashGenerate-host.swift').write_text(s)
p=P/'build.py';s=p.read_text();s=s.replace("'Sources/Slotstream/Model.swift':'Model-host.swift'","'Sources/Slotstream/Model.swift':'Model-host.swift','Sources/Slotstream/DFlashGenerate.swift':'DFlashGenerate-host.swift'");p.write_text(s)
for n in ['run_host.py','analyze_host_all_reads.py']:
 p=P/n;p.write_text(p.read_text().replace('ordinary-graph-15','ordinary-tail-15'))
(P/'plan.json').write_text(json.dumps(dict(scope='One native ordinary adaptive diagnostic,15GB4067slots8192context,2warm+2timed384tokens, bounded host timestamps plus unchanged read/Metal observers. No optimization, graph, math, scheduling or precision change. Restore sources and all v68 artifacts after build. No retries, speed or semantic-quality qualification.',evidence='Existing graph diagnostic leaves0.263/0.268s outside host/read/GPU observation between pool demand and MoE return, and0.206/0.213s between last target layer and draft context append. Split those regions into demand launch/join, promoted ticket join/adoption, publish/release, target-call, logits evaluation, sampling and rollback. Parent/child elapsed scopes overlap, never sum.',capacity=262144,sources={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in P.glob('*-host.swift')}),indent=2))
