from pathlib import Path
import hashlib,io,json,re,tarfile
P=Path(__file__).resolve().parent;R=P.parents[1];Q=P.parent/'q2-submit-read-overlap-20261025';sha=lambda b:hashlib.sha256(b).hexdigest();files={}
for prefix,root in [('boundary',P),('overlap',Q)]:
 for f in root.rglob('*'):
  if not f.is_file()or'__pycache__'in f.parts or f.name in ['archive-receipt.json']:continue
  if f.suffix not in ['.py','.swift','.cpp','.mm','.hpp','.h','.json','.jsonl','.csv','.log','.stderr','.txt']:continue
  files[prefix+'/'+str(f.relative_to(root))]=f
for root,names in [(R/'.build/q2-sequence-20261025',['copy_observer.cpp','named_stage_observer.mm']),(R/'.build/q2-handoff-20261025',['read_observer.cpp'])]:
 for n in names:files['reference/'+n]=root/n
files['reference/v68-build-identity.json']=R/'.build/native-replay-20261023/v68/build-identity.json'
files['baseline/LICENSE']=R/'LICENSE'
for n in ['Layers.swift','NativeExpertSchedule.swift','ExpertStore.swift','RoutingReadbackQueue.swift','ExpertPrefetch.swift','Model.swift']:
 files['baseline/'+n]=R/'Sources/Slotstream'/n
files['baseline/NativeSchedulePoolChecks.swift']=R/'Sources/slotstream-cli/NativeSchedulePoolChecks.swift'
for n in ['array.cpp','transforms.cpp','backend/metal/event.cpp']:
 files['reference/mlx/'+n]=R/'.build/checkouts/mlx-swift/Source/Cmlx/mlx/mlx'/n
files['reference/mlx/LICENSE']=R/'Sources/CNativeSchedule/MLX-LICENSE.txt'
secret=re.compile(rb'(?:ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{25,}|sk-(?:proj-)?[A-Za-z0-9_-]{30,}|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----)');manifest={}
for n,f in files.items():
 b=f.read_bytes();assert not secret.search(b),n;manifest[n]=dict(bytes=len(b),sha256=sha(b))
dest=R/'db/sources/runs/2026/10/q2-expert-submission-boundary-2026-10-25.tar.xz';assert not dest.exists();raw=json.dumps(manifest,indent=2).encode()
with tarfile.open(dest,'w:xz',preset=3)as t:
 for n,f in sorted(files.items()):t.add(f,arcname=n,recursive=False)
 info=tarfile.TarInfo('archive-manifest.json');info.size=len(raw);t.addfile(info,io.BytesIO(raw))
seen={}
with tarfile.open(dest,'r|xz')as t:
 for m in t:
  b=t.extractfile(m).read()
  if m.name=='archive-manifest.json':assert json.loads(b)==manifest
  else:seen[m.name]=dict(bytes=len(b),sha256=sha(b))
assert seen==manifest
receipt=dict(path=str(dest.relative_to(R)),files=len(manifest),bytes=dest.stat().st_size,sha256=sha(dest.read_bytes()),readback_verified=True,credential_pattern_matches=0,excluded='Executables, libraries, weights, pycache and duplicate full-source archives. Source replacements, original baseline sources and identities retained. Original contaminated/interrupted timing, one frozen replacement and separate paging-excluded overlap trial all retained.')
(P/'archive-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt,indent=2))
