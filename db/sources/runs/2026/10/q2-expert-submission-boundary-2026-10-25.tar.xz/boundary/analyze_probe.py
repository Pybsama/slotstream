from pathlib import Path
import collections,json,bisect
P=Path(__file__).resolve().parent
# Executes only interval/CSV helpers.
exec((P/'analyze_readiness.py').read_text().split('results=[];details=[]')[0],globals())
label='trace-0-N';cp=next(p for p in P.glob(label+'-commands.*.csv')if not any(n in p.name for n in ['events','stages','assignments','pipelines']));ss=rows(cp.with_name(cp.stem+'.stages.csv'));cc=rows(cp);bybuf=collections.defaultdict(list)
for c in cc:c['submitted']=float(c['submitted']);bybuf[c['buffer']].append(c)
for v in bybuf.values():v.sort(key=lambda c:c['submitted'])
times={k:[c['submitted']for c in v]for k,v in bybuf.items()};signatures={s['index']:s['signature']for q in json.loads((P/'named-stage-analysis.json').read_text())[0]['passes']for s in q['stages']}
valid=[]
for index,s in enumerate(ss):
 a,b=int(s['gpu_start'])/1e9,int(s['gpu_end'])/1e9;assert b>a>0
 i=bisect.bisect_left(times[s['buffer']],float(s['encoded']));valid.append(dict(start=a,end=b,submitted=bybuf[s['buffer']][i]['submitted'],index=index))
valid.sort(key=lambda s:s['start']);before=[];expert=[];last=0
for s in valid:
 if s['start']>last:
  b=min(s['start'],s['submitted'])
  if b>last:
   before.append([last,b])
   if signatures.get(s['index'],'').startswith(('native_repack','native_gather')):expert.append([last,b])
 last=max(last,s['end'])
d=json.loads((P/(label+'.json')).read_text())['rounds'][0];lo,hi=d['start_ns']/1e9,d['end_ns']/1e9;w=[[lo,hi]];before=inter(union(before),w);expert=inter(union(expert),w)
gpu=inter(union((s['start'],s['end'])for s in valid),w);read=inter(union((float(r['start']),float(r['end']))for r in rows(next(P.glob(label+'-reads.*.csv')))if int(r['result'])>0),w)
groups=collections.defaultdict(list)
for x in rows(P/(label+'.json.round0.host.csv')):
 a,b=int(x['start_ns'])/1e9,int(x['end_ns'])/1e9;assert lo<=a<=b<=hi,(x,a,b,lo,hi);groups[x['kind']].append([a,b])
summary=[]
for k,v in groups.items():
 u=union(v);summary.append(dict(kind=k,calls=len(v),total_seconds=length(u),before_submit=length(inter(u,before)),before_expert=length(inter(u,expert)),outside_gpu=length(u)-length(inter(u,gpu)),outside_read_and_gpu=length(u)-length(inter(u,union(gpu+read)))))
report=dict(eligible=json.loads((P/'trace-ledger.json').read_text())[0]['eligible'],scope='Full-cycle diagnostic scopes intersected with observed before-expert command submission gaps. Parent/child scopes overlap; no exclusive CPU attribution. Known polling and observer overhead retained. All111target/proposal IDs match prior validation; no full-logit readback in this trace.',wall_seconds=hi-lo,before_submit_seconds=length(before),before_expert_seconds=length(expert),scopes=sorted(summary,key=lambda x:-x['before_expert']))
(P/'probe-analysis.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
