from pathlib import Path
import json,sys,shutil,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1];B=R/'.build/native-replay-20261023/v68'
sys.path.insert(0,str(R/'Tools'));from optimization_build import build
rep=json.loads((P/'replacements.json').read_text());old={n:(R/n).read_bytes()for n in rep};result={}
try:
 for n,f in rep.items():(R/n).write_bytes((P/f).read_bytes())
 result=build(R,P/'native-probe-build',required_gb=10,jobs=4,wait_seconds=0);print(json.dumps({k:v for k,v in result.items()if k in ['passed','error','elapsed_seconds']}),flush=True)
finally:
 for n,b in old.items():(R/n).write_bytes(b)
 for n in ['slotstream','slotstream-checks','mlx.metallib','build-identity.json','build-source.tar.gz']:shutil.copy2(B/n,R/'.build/release'/n)
 (P/'restored-probe.json').write_text(json.dumps(dict(sources={n:hashlib.sha256((R/n).read_bytes()).hexdigest()for n in old},default_binary=hashlib.sha256((R/'.build/release/slotstream').read_bytes()).hexdigest()),indent=2))
if not result.get('passed'):raise SystemExit(1)
