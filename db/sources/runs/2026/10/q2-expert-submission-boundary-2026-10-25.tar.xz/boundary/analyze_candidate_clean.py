from pathlib import Path
import json,statistics as st
P=Path(__file__).resolve().parent
es=json.loads((P/'clean-candidate-timing-ledger.json').read_text());assert [e['arm']for e in es]==list('ABBA')
refs=json.loads((P/'candidate-validation-0-B.json').read_text())['rounds'][0]['steps']
exact=True;arms={};rows=[]
for e in es:
 d=json.loads((P/(e['label']+'.json')).read_text());assert len(d['rounds'])==3
 for rd in d['rounds']:
  exact &= all(a['actual_guesses']==b['actual_guesses'] and a['actual_selected']==b['actual_selected'] for a,b in zip(rd['steps'],refs))
  assert len(rd['steps'])==len(refs)
 values=[rd['seconds'] for rd in d['rounds'][1:]];arms[e['label']]=st.median(values);rows.append(dict(label=e['label'],eligible=e['eligible'],rounds=[rd['seconds']for rd in d['rounds']],median=st.median(values)))
ratios=[rows[1]['median']/rows[0]['median'],rows[2]['median']/rows[3]['median']]
a=[r for e in es if e['arm']=='A' for r in [rd['seconds']for rd in json.loads((P/(e['label']+'.json')).read_text())['rounds'][1:]]]
b=[r for e in es if e['arm']=='B' for r in [rd['seconds']for rd in json.loads((P/(e['label']+'.json')).read_text())['rounds'][1:]]]
pooled=st.median(b)/st.median(a);eligible=all(e['eligible']for e in es)
report=dict(eligible=eligible,all_proposals_and_selected_ids_exact=exact,rows=rows,forward_reverse_ratios=ratios,baseline_median=st.median(a),candidate_median=st.median(b),pooled_ratio=pooled,advance=eligible and exact and all(r<1 for r in ratios) and pooled<=.99,scope='Controlled real-draft cycles, not ordinary app/request speed. One ABBA with initial warmup removed symmetrically and both remaining rounds included. No retries or selection of favorable rounds.')
(P/'candidate-analysis.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));assert exact
