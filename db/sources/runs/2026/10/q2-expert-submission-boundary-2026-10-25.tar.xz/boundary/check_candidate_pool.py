from pathlib import Path
import os,sys,fcntl,subprocess,json
P=Path(__file__).resolve().parent;R=P.parents[1]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
reservation=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(reservation,fcntl.LOCK_EX|fcntl.LOCK_NB)
os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(P/'candidate-pool-child.lock')
preflight(13)
cmd=[sys.executable,str(P/'quiet_guarded_run.py'),'--label','candidate-pool','--budget','10','--timeout','600','--env','SLOTSTREAM_MODEL_LOCK_PATH='+str(P/'candidate-pool-child.lock'),'--env','MTL_DEBUG_LAYER=1','--env','DYLD_INSERT_LIBRARIES=','--',str(P/'native-candidate-build/candidate/slotstream'),'q2-experts-check','--pool-model','smart-q2']
with (P/'candidate-pool-launcher.log').open('x') as log:r=subprocess.run(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT,timeout=660)
g=json.loads((P/'candidate-pool.observer.json').read_text());print(dict(passed=r.returncode==0,peak_gb=g['peak_combined_bytes']/1e9,paging=g['paging']))
raise SystemExit(r.returncode)
