from pathlib import Path
import json,hashlib,shutil
P=Path(__file__).resolve().parent;R=P.parents[1];H=R/'.build/q2-host-profile-20261025';F=R/'.build/q2-full-cycle-20261025'
# Reuse previously validated scope patches against byte-identical v68 sources.
for n in ['NativeExpertSchedule-host.swift','ExpertStore-host.swift']:shutil.copy2(H/n,P/n)
s=(R/'Sources/Slotstream/Layers.swift').read_text()
def replace(old,new):
 global s
 assert s.count(old)==1,(old[:70],s.count(old));s=s.replace(old,new)
replace('''            asyncEval(routeIndices, forecast.indices, forecast.weights)''','''            let forecastSubmitStart = Q2HostProbe.stamp()
            asyncEval(routeIndices, forecast.indices, forecast.weights)
            Q2HostProbe.end("router_forecast_submit", forecastSubmitStart)''')
replace('''            eval([routeIndices] + queue.arrays)
            queue.drain(waited: RuntimeClock.seconds(since: waitStart))''','''            let routeEvalStart = Q2HostProbe.stamp()
            eval([routeIndices] + queue.arrays)
            Q2HostProbe.end("router_eval", routeEvalStart)
            let retireStart = Q2HostProbe.stamp()
            queue.drain(waited: RuntimeClock.seconds(since: waitStart))
            Q2HostProbe.end("router_retire", retireStart)''')
replace('''        let expertIds = routeIndices.asArray(Int32.self)  // B*S*topK''','''        let hostRouteStart = Q2HostProbe.stamp()
        let expertIds = routeIndices.asArray(Int32.self)  // B*S*topK
        Q2HostProbe.end("router_to_host", hostRouteStart)
        let afterRoutes = Q2HostProbe.stamp()''')
replace('''            let experts = try B * S >= SweepTuning.minTokens''','''            Q2HostProbe.end("moe_after_routes", afterRoutes)
            let experts = try B * S >= SweepTuning.minTokens''')
replace('''                        mixedWeights: MLXArray? = nil, mixedSharedWeight: MLXArray? = nil) throws -> MLXArray {
        let (B, S)''','''                        mixedWeights: MLXArray? = nil, mixedSharedWeight: MLXArray? = nil) throws -> MLXArray {
        let cachedStart = Q2HostProbe.stamp()
        let (B, S)''')
replace('''            _ = try pool.ensureScheduled(uniq, staging: { pending?.staging })''','''            Q2HostProbe.end("cached_before_pool", cachedStart)
            _ = try pool.ensureScheduled(uniq, staging: { pending?.staging })''')
(P/'Layers-host.swift').write_text(s)
s=(R/'Sources/Slotstream/RoutingReadbackQueue.swift').read_text().replace('''        let work = finishers
''','''        let clearStart = Q2HostProbe.stamp()
        let work = finishers
''').replace('''        let share = seconds / Double(work.count)
        for finish in work { finish(share) }''','''        Q2HostProbe.end("retire_clear", clearStart)
        let finishStart = Q2HostProbe.stamp()
        let share = seconds / Double(work.count)
        for finish in work { finish(share) }
        Q2HostProbe.end("retire_finish", finishStart)''');(P/'RoutingReadbackQueue-host.swift').write_text(s)
s=(F/'Q2ProfileCommand.swift').read_text().replace('''                    let requestStart=RuntimeClock.now()''','''                    Q2HostProbe.begin(true)
                    let requestStart=RuntimeClock.now()''').replace('''                    let requestEnd=RuntimeClock.now()''','''                    let requestEnd=RuntimeClock.now()
                    try Q2HostProbe.flush(output + ".round" + String(round) + ".host.csv")''');(P/'Q2ProfileCommand-host.swift').write_text(s)
replacements={f'Sources/Slotstream/{n}.swift':f'{n}-host.swift'for n in ['NativeExpertSchedule','ExpertStore','Layers','RoutingReadbackQueue']};replacements['Sources/slotstream-cli/Q2ProfileCommand.swift']='Q2ProfileCommand-host.swift'
(P/'replacements.json').write_text(json.dumps(replacements,indent=2));(P/'probe-plan.json').write_text(json.dumps(dict(question='Locate the pre-cache half of observed before-expert GPU submission gaps: route eval completion/readback, queued state retirement, post-route and unique-key construction, then known cache/native preparation scopes.',scope='Diagnostic-only bounded host timestamp scopes and the unchanged frozen full-cycle workload. Separate exact-logit validation, then one native attribution sequence with existing read/copy/named-stage observers. No runtime optimization, full request speed claim or changed arithmetic. First compare all selected IDs/proposals and scope intersections, including overlap. Single model owner,15GB,4067slots,nominal thermal,no paging.',hashes={n:hashlib.sha256((P/n).read_bytes()).hexdigest()for n in replacements.values()}),indent=2))
for n in ['timed-2.json','quiet_guarded_run.py','check_restoration.py']:shutil.copy2(F/n,P/n)
print('Prepared five diagnostic source replacements')
