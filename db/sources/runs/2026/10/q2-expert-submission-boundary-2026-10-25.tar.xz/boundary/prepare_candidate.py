from pathlib import Path
import json,hashlib,shutil
P=Path(__file__).resolve().parent;R=P.parents[1];F=R/'.build/q2-full-cycle-20261025';D=R/'.build/q2-forecast-dispatch-20261025'
s=(R/'Sources/Slotstream/Layers.swift').read_text()
old='''        if let queue = readbackQueue, !queue.isEmpty {
            let waitStart = RuntimeClock.now()
            eval([routeIndices] + queue.arrays)
            queue.drain(waited: RuntimeClock.seconds(since: waitStart))
        }
        let expertIds = routeIndices.asArray(Int32.self)  // B*S*topK'''
new='''        let expertIds: [Int32]  // B*S*topK
        if pool.expertStore.isQ2, let queue = readbackQueue,
           !queue.isEmpty, queue.arrays.isEmpty {
            // The route readback already waits for this stream. With no other
            // arrays to evaluate, run the deferred completions after that wait.
            let waitStart = RuntimeClock.now()
            expertIds = routeIndices.asArray(Int32.self)
            queue.drain(waited: RuntimeClock.seconds(since: waitStart))
        } else {
            if let queue = readbackQueue, !queue.isEmpty {
                let waitStart = RuntimeClock.now()
                eval([routeIndices] + queue.arrays)
                queue.drain(waited: RuntimeClock.seconds(since: waitStart))
            }
            expertIds = routeIndices.asArray(Int32.self)
        }'''
assert s.count(old)==1
(P/'Layers-single-readback.swift').write_text(s.replace(old,new))
shutil.copy2(F/'Q2ProfileCommand.swift',P/'Q2ProfileCommand-full-cycle.swift')
shutil.copy2(D/'SmartDFlashCommand-request-clock.swift',P/'SmartDFlashCommand-request-clock.swift')
rep={'Sources/Slotstream/Layers.swift':'Layers-single-readback.swift','Sources/slotstream-cli/Q2ProfileCommand.swift':'Q2ProfileCommand-full-cycle.swift','Sources/slotstream-cli/SmartDFlashCommand.swift':'SmartDFlashCommand-request-clock.swift'}
(P/'candidate-replacements.json').write_text(json.dumps(rep,indent=2))
(P/'candidate-plan.json').write_text(json.dumps(dict(hypothesis='Q2 with deferred completions but no deferred arrays performs vector eval then asArray. Test one direct readback, preserving completion callbacks and retry timing after the route has completed. This saves wrapper/allocation overhead, not the required GPU wait. Measured router_eval gap includes waits and cannot be claimed as removable overhead.',scope='Q2 only; Fast retains existing branch. No observer, retry, event, priority, power or numerical changes.',protocol='Exact 111-pass full logits/proposals/selected IDs under Metal validation, existing raw-pool tests. Then one uninstrumented ABBA full-cycle experiment (each warmup + two measured rounds). Only advance to ordinary ABCCBA baseline/candidate/Splash if both directions improve and pooled full-cycle improvement >=1%. Otherwise revert candidate. Any paging excludes entire timing protocol; no favorable retry.',hashes={v:hashlib.sha256((P/v).read_bytes()).hexdigest()for v in rep.values()}),indent=2))
s=(P/'build_probe.py').read_text().replace("'replacements.json'","'candidate-replacements.json'").replace("'native-probe-build'","'native-candidate-build'").replace("'restored-probe.json'","'restored-candidate.json'")
(P/'build_candidate.py').write_text(s)
print('Prepared one-readback candidate; no production files changed yet')
