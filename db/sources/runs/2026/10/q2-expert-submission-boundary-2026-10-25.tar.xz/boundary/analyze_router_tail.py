from pathlib import Path
import json,bisect,statistics
P=Path(__file__).resolve().parent
exec((P/'analyze_probe.py').read_text().split('summary=[]')[0],globals())
ends=sorted(s['end']for s in valid);tails=[]
for a,b in groups['router_eval']:
 i=bisect.bisect_right(ends,b)-1
 if i>=0 and a<=ends[i]<=b:tails.append(b-ends[i])
r=dict(scope='Time from latest observed GPU encoder end inside each route eval to its return. Upper bound includes Metal signal/notification and host-library return; it is not an isolated scheduler-wakeup measurement. Other GPU work can shorten this bound. No causal speed claim.',calls=len(groups['router_eval']),with_encoder_end=len(tails),total_seconds=sum(tails),median_microseconds=statistics.median(tails)*1e6,p95_microseconds=sorted(tails)[int(.95*len(tails))]*1e6)
(P/'router-tail-analysis.json').write_text(json.dumps(r,indent=2));print(r)
