from pathlib import Path
P=Path(__file__).resolve().parent;F=P.parent/'q2-full-cycle-20261025'
s=(F/'run.py').read_text()
s=s.replace("choices=['validation','validation-s','timing']","choices=['validation','timing']")
s=s.replace("ledger=P/(a.mode+'-ledger.json')","ledger=P/('candidate-'+a.mode+'-ledger.json')")
s=s.replace("assert json.loads((P/'validation-result.json').read_text())['passed']","assert json.loads((P/'candidate-validation-result.json').read_text())['passed']")
s=s.replace("enumerate('S' if a.mode=='validation-s' else ('NS' if validation else 'NSSN'))","enumerate('B' if validation else 'ABBA')")
s=s.replace("label=f'{a.mode}-{i}-{arm}'","label=f'candidate-{a.mode}-{i}-{arm}'")
s=s.replace("if arm=='N':","if arm in ('A','B'):")
s=s.replace("str(P/'native-build/candidate/slotstream')","str(P/'native-candidate-build/candidate/slotstream') if arm=='B' else str(P.parent/'q2-full-cycle-20261025/native-build/candidate/slotstream')")
(P/'run_candidate.py').write_text(s)
s=(P/'validate_probe.py').read_text().replace("'validation-0-N.json'","'candidate-validation-0-B.json'",1).replace("'validation-result.json'","'candidate-validation-result.json'").replace('Instrumented host scopes with unchanged full-cycle arithmetic.','Single route readback; deferred completions preserved.')
(P/'validate_candidate.py').write_text(s)
print('candidate runner frozen')
