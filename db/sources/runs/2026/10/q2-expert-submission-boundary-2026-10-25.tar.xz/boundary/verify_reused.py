from pathlib import Path
import tarfile,hashlib,json
P=Path(__file__).resolve().parent;R=P.parents[1];H=P.parent/'q2-host-profile-20261025';F=P.parent/'q2-full-cycle-20261025';label='ordinary-host-15-0-A'
def sha(b):return hashlib.sha256(b).hexdigest()
checks=[]
for root,archive,want,expected in [(H,R/'db/sources/runs/2026/10/q2-ordinary-host-attribution-2026-10-25.tar.xz',list(H.glob(label+'*.csv'))+[H/(label+'.json')], 'e3f9af12154cd926f21cd88c97e31ba490630b31c31675aa40d12c819f147719'),(F,R/'db/sources/runs/2026/10/q2-full-cycle-execution-control-2026-10-25.tar.xz',[F/'validation-0-N.json',F/'timed-2.json',F/'analyze_readiness.py'],'e952a5d5563b9e1f0b36d0c924858e6cd5dff5cde278f989581cf6588fadb9a5')]:
 assert sha(archive.read_bytes())==expected
 target={str(f.relative_to(root)):sha(f.read_bytes())for f in want};seen={}
 with tarfile.open(archive,'r|xz')as t:
  for m in t:
   if m.name in target:seen[m.name]=sha(t.extractfile(m).read())
 assert seen==target,(seen.keys(),target.keys())
 checks.append(dict(archive=str(archive.relative_to(R)),sha256=expected,members=target,passed=True))
(P/'reused-evidence-verification.json').write_text(json.dumps(checks,indent=2));print('verified',sum(len(c['members'])for c in checks),'reused members')
