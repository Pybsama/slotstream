from pathlib import Path
import json
P=Path(__file__).resolve().parent;F=P.parent/'q2-full-cycle-20261025'
r=json.loads((P/'candidate-validation-0-B.json').read_text())['rounds'][0]['steps'];ref=json.loads((F/'validation-0-N.json').read_text())['rounds'][0]['steps'];assert len(r)==len(ref)==111
bad={k:[i for i,(a,b)in enumerate(zip(r,ref))if a[k]!=b[k]]for k in ['logits_sha256','actual_selected','actual_guesses']};out=dict(passed=not any(bad.values()),steps=len(r),differences=bad,scope='Single route readback; deferred completions preserved. Exact whole logits, selected IDs and real proposals against prior native reference; no speed claim from validation.');(P/'candidate-validation-result.json').write_text(json.dumps(out,indent=2));print(out);assert out['passed']
