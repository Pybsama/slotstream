from pathlib import Path
import bisect,collections,csv,json
P=Path(__file__).resolve().parent;H=P.parent/'q2-host-profile-20261025';F=P.parent/'q2-full-cycle-20261025'
exec((F/'analyze_readiness.py').read_text().split('results=[];details=[]')[0],globals());P=Path(__file__).resolve().parent
label='ordinary-host-15-0-A';stagefile=next(H.glob(label+'-commands.*.stages.csv'));prefix=stagefile.name[:-len('.stages.csv')]
ss=rows(stagefile);cc=rows(H/(prefix+'.csv'));aa=rows(H/(prefix+'.assignments.csv'));pp=rows(H/(prefix+'.pipelines.csv'))
bybuf=collections.defaultdict(list);encoders=collections.defaultdict(list);pipelines=collections.defaultdict(list)
for c in cc:c['submitted']=float(c['submitted']);bybuf[c['buffer']].append(c)
for vv in bybuf.values():vv.sort(key=lambda c:c['submitted'])
times={b:[c['submitted']for c in v]for b,v in bybuf.items()}
for s in ss:
 s.update(encoded=float(s['encoded']),start=int(s['gpu_start'])/1e9,end=int(s['gpu_end'])/1e9,names=[])
 i=bisect.bisect_left(times[s['buffer']],s['encoded']);s['submitted']=bybuf[s['buffer']][i]['submitted'];encoders[s['encoder']].append(s)
for vv in encoders.values():vv.sort(key=lambda s:s['encoded'])
created={k:[s['encoded']for s in v]for k,v in encoders.items()}
for p in pp:p['stamp']=float(p['stamp']);pipelines[p['pipeline']].append(p)
for vv in pipelines.values():vv.sort(key=lambda p:p['stamp'])
ptimes={k:[p['stamp']for p in v]for k,v in pipelines.items()}
for a in aa:
 t=float(a['stamp']);i=bisect.bisect_right(created[a['encoder']],t)-1;j=bisect.bisect_right(ptimes[a['pipeline']],t)-1;assert i>=0 and j>=0
 encoders[a['encoder']][i]['names'].append(pipelines[a['pipeline']][j]['name'])
ss.sort(key=lambda s:s['start']);spans=[];edge=0
for s in ss:
 if not s['end']>s['start']>0:continue
 if s['start']>edge and s['names'] and s['names'][0]in ['native_repack','native_gather']:
  b=min(s['start'],s['submitted'])
  if b>edge:spans.append([edge,b])
 edge=max(edge,s['end'])
read=union((float(r['start']),float(r['end']))for r in rows(next(H.glob(label+'-reads.*.csv')))if int(r['result'])>0)
out=[]
for r in json.loads((H/(label+'.json')).read_text())['runs']:
 if not r['id'].startswith('timed'):continue
 lo,hi=r['request_started_mach_ns']/1e9,r['request_ended_mach_ns']/1e9;gaps=inter(union(spans),[[lo,hi]]);groups=collections.defaultdict(list)
 for x in rows(H/(label+'.json.'+r['id']+'.host.csv')):groups[x['kind']].append([int(x['start_ns'])/1e9,int(x['end_ns'])/1e9])
 allhost=union([x for vv in groups.values()for x in vv]);covered=inter(gaps,allhost)
 result=dict(id=r['id'],before_expert_seconds=length(gaps),gap_with_reads=length(inter(gaps,read)),covered_by_host_scopes=length(covered),outside_host_scopes=length(gaps)-length(covered),scopes={k:dict(gap_overlap=length(inter(gaps,union(v))),gap_overlap_outside_reads=length(inter(gaps,union(v)))-length(inter(inter(gaps,union(v)),read)))for k,v in groups.items()})
 # Locate gaps outside existing scopes relative to pool entry and asyncEval.
 phases=collections.defaultdict(list)
 for a,b in gaps:
  pool=[x for k in ['pool_before_prepare_miss','pool_before_prepare_hit']for x in groups[k]if a<=x[0]<b]
  if pool:phases['before_pool_entry'].append([a,min(x[0]for x in pool)])
 result['phases']={k:dict(seconds=length(union(v)),outside_reads=length(union(v))-length(inter(union(v),read)))for k,v in phases.items()};out.append(result);print(json.dumps(result,indent=2))
(P/'existing-localization.json').write_text(json.dumps(dict(scope='Offline intersection of expert-command pre-submission gaps with recorded host scopes in existing clean ordinary native requests. Parent/child scopes overlap. Not a new timing protocol or CPU-service proof. Original archive/member identities must accompany conclusions.',results=out),indent=2))
