from pathlib import Path
import json,shutil,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1];F=R/'.build/q2-full-cycle-20261025';H=R/'.build/q2-expert-submit-20261025'
def replace(s,a,b):
 assert s.count(a)==1,(a[:100],s.count(a));return s.replace(a,b)
rep={}
def save(n,s):
 name=Path(n).name;rep[n]=name;(P/name).write_text(s)
n='Sources/Slotstream/NativeExpertSchedule.swift';s=(R/n).read_text()
s=replace(s,'forecastArena: NativeForecastArena? = nil, shared: SharedBindings? = nil) throws -> Pending {','forecastArena: NativeForecastArena? = nil, shared: SharedBindings? = nil,\n                        submitAlongsideReads: Bool = false) throws -> Pending {')
s=replace(s,'inverse: groupedOutput ? grouping.inverse : nil, sharedRows: mixedShared ? count : 0)','inverse: groupedOutput ? grouping.inverse : nil, sharedRows: mixedShared ? count : 0,\n                deferredSubmission: submitAlongsideReads && awaitingReads && !affine)')
s=replace(s,'if awaitingReads || Self.earlySubmission { asyncEval(value) }','if !pending.deferredSubmission, awaitingReads || Self.earlySubmission { asyncEval(value) }')
s=replace(s,'private var finished = false\n        fileprivate init(output:', '''private var finished = false
        fileprivate var deferredSubmission: Bool
        /// Called by one read-batch iteration, joined before value/cancel.
        /// All input owners and the MLX stream were bound on the model thread.
        package func submitDeferred() {
            guard deferredSubmission else { return }
            autoreleasepool { asyncEval(output) }
            deferredSubmission = false
        }
        fileprivate init(output:''')
s=replace(s,'forecastArena: NativeForecastArena?, inverse: [Int32]?, sharedRows: Int = 0) throws {','forecastArena: NativeForecastArena?, inverse: [Int32]?, sharedRows: Int = 0,\n                         deferredSubmission: Bool = false) throws {\n            self.deferredSubmission = deferredSubmission')
s=replace(s,'ss_schedule_publish(job, true); finished = true','submitDeferred() // All-adopted misses have no demand batch to run it.\n            ss_schedule_publish(job, true); finished = true')
save(n,s)
n='Sources/Slotstream/ExpertStore.swift';s=(R/n).read_text()
s=replace(s,'finishReaders: (() -> Void)? = nil, rawCopy: Bool = false) throws {','finishReaders: (() -> Void)? = nil, rawCopy: Bool = false,\n                                      alongsideReads: (() -> Void)? = nil) throws {')
a='''        DispatchQueue.concurrentPerform(iterations: lanes) { lane in
            guard let (buffer, temporary) = scratch.acquire() else {'''
b='''        // One bounded work item can submit the already-prepared GPU job
        // while these unchanged lanes read its inputs. All items join before
        // bytes are marked ready, including every error path.
        DispatchQueue.concurrentPerform(iterations: lanes + (alongsideReads == nil ? 0 : 1)) { lane in
            if lane == lanes { alongsideReads?(); return }
            guard let (buffer, temporary) = scratch.acquire() else {'''
s=replace(s,a,b)
s=replace(s,'staging: (() -> NativeExpertSchedule.Staging?)? = nil,\n                                 prepare:','staging: (() -> NativeExpertSchedule.Staging?)? = nil,\n                                 alongsideReads: (() -> Void)? = nil,\n                                 prepare:')
s=replace(s,'finishReaders: nil, prepare: prepare, staging: staging)','finishReaders: nil, prepare: prepare, staging: staging, alongsideReads: alongsideReads)')
s=replace(s,'staging: (() -> NativeExpertSchedule.Staging?)? = nil) throws -> [Int] {','staging: (() -> NativeExpertSchedule.Staging?)? = nil,\n                            alongsideReads: (() -> Void)? = nil) throws -> [Int] {')
s=replace(s,'func readDemand(_ order: [Int]) throws {','var pendingReadWork = alongsideReads\n            func readDemand(_ order: [Int]) throws {')
s=replace(s,'finishReaders: readersPending ? finishResidentReaders : nil, rawCopy: raw != nil)','finishReaders: readersPending ? finishResidentReaders : nil, rawCopy: raw != nil,\n                                alongsideReads: pendingReadWork)\n                            pendingReadWork = nil')
save(n,s)
n='Sources/Slotstream/Layers.swift';s=(R/n).read_text()
s=replace(s,'_ = try pool.ensureScheduled(uniq, staging: { pending?.staging }) { slotOf, awaitingReads in','_ = try pool.ensureScheduled(uniq, staging: { pending?.staging },\n                alongsideReads: pool.expertStore.isQ2 ? { pending?.submitDeferred() } : nil) { slotOf, awaitingReads in')
s=replace(s,'forecastArena: self.pool.lookahead?.prefetch?.nativeForecastArena, shared: mixedShared)','forecastArena: self.pool.lookahead?.prefetch?.nativeForecastArena, shared: mixedShared,\n                    submitAlongsideReads: self.pool.expertStore.isQ2)')
save(n,s)
for n,src in [('Sources/slotstream-cli/Q2ProfileCommand.swift',F/'Q2ProfileCommand.swift'),('Sources/slotstream-cli/SmartDFlashCommand.swift',H/'SmartDFlashCommand-request-clock.swift')]:save(n,src.read_text())
(P/'replacements.json').write_text(json.dumps(rep,indent=2))
for n in ['quiet_guarded_run.py','check_restoration.py','timed-2.json']:shutil.copy2(H/n,P/n)
s=(H/'build_probe.py').read_text().replace("'native-probe-build'","'native-build'");(P/'build.py').write_text(s)
(P/'plan.json').write_text(json.dumps(dict(hypothesis='Current host trace measures143.8ms in expert asyncEval across111cycles before current-layer demand reads start. Prepare the same job, then submit it as one joined work item alongside existing demand lanes, so useful disk work can overlap host graph encoding. No reader pool, lanes, cache policy, arithmetic, spin or priority changes.',scope='Only Q2 asks for deferred submission. Fast keeps early submission and the original number of demand iterations. Joined callback cannot survive the batch or race readiness publication. All-adopted fallback submits before publish; cancellation publishes failure then drains.',protocol='Independent candidate, excluding rejected single-readback change. Validate111exact logits/proposals/selected IDs and pool cancellation/failure paths. One ABBA full-cycle control with one warmup+two measured per arm, no concurrent build/archive/analysis. Advance to ordinary baseline/candidate/Splash ABCCBA only on clean both-direction wins and >=1percent pooled control gain. All paging or competing work excludes entire protocol. No retry.'),indent=2))
print('Prepared source-only overlap candidate')
