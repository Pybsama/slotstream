from pathlib import Path
import json
P=Path(__file__).resolve().parent;R=P.parents[1]
def sub(s,a,b):
 assert s.count(a)==1,(s.count(a),a[:60]);return s.replace(a,b)
f=P/'NativeExpertSchedule.swift';s=f.read_text().replace('guard deferredSubmission else { return }','guard deferredSubmission, !finished else { return }');f.write_text(s)
s=(R/'Sources/slotstream-cli/NativeSchedulePoolChecks.swift').read_text()
s=sub(s,'    var lastForecast = 0','    var lastForecast = 0\n    var overlapSubmissions = 0')
s=sub(s,'pool.ensureScheduled(keys, staging: { pending?.staging }) { slots, awaitingReads in','pool.ensureScheduled(keys, staging: { pending?.staging },\n            alongsideReads: store.isQ2 ? { pending?.submitDeferred(); overlapSubmissions += 1 } : nil) { slots, awaitingReads in')
s=sub(s,'forecastArena: pool.lookahead?.prefetch?.nativeForecastArena, shared: shared)','forecastArena: pool.lookahead?.prefetch?.nativeForecastArena, shared: shared, submitAlongsideReads: store.isQ2)')
s=sub(s,'    for completedJobs in [0, 2] {','''    if store.isQ2 {
        // No read batch has submitted this job. Cancellation must publish
        // failure and drain it without waiting forever on its readiness event.
        let canceled = try plan.submit(input, bindings: pool.scheduledBindings(for: plan),
            ids: [0], repeatInput: 1, awaitingReads: true, groupedOutput: mixed,
            shared: shared, submitAlongsideReads: true)
        canceled.cancel(); canceled.cancel(); canceled.submitDeferred()
        do {
            _ = try canceled.value()
            throw ValidationError("Canceled deferred job was consumed")
        } catch is ModelError {}
    }
    for completedJobs in [0, 2] {''')
s=sub(s,'        try forecast(8)\n        pool.readFault', '''        try forecast(11)
        let beforeNoDemand = (pool.recordsFetched, overlapSubmissions)
        _ = try scheduled([ExpertKey(1, 11)])
        guard pool.recordsFetched == beforeNoDemand.0, overlapSubmissions == beforeNoDemand.1 else {
            throw ValidationError("All-adopted deferred job unexpectedly used a demand batch")
        }
        pool.unpinAll(); session.endPass()
        try forecast(8)
        pool.readFault''')
s=sub(s,'    pool.directDemandReads = false','''    if store.isQ2 {
        guard overlapSubmissions > 0 else { throw ValidationError("No Q2 submission ran alongside reads") }
        print("Deferred Q2 submission: joined demand, pre-submit cancellation and all-adopted fallback PASS")
    }
    pool.directDemandReads = false''')
(P/'NativeSchedulePoolChecks.swift').write_text(s);rep=json.loads((P/'replacements.json').read_text());rep['Sources/slotstream-cli/NativeSchedulePoolChecks.swift']='NativeSchedulePoolChecks.swift';(P/'replacements.json').write_text(json.dumps(rep,indent=2))
