from pathlib import Path
import shutil
P=Path(__file__).resolve().parent;H=P.parent/'q2-expert-submit-20261025'
s=(H/'run_candidate.py').read_text().replace("'native-candidate-build/candidate/slotstream'","'native-build/candidate/slotstream'")
(P/'run.py').write_text(s)
for src,dst in [('validate_candidate.py','validate.py'),('analyze_candidate.py','analyze.py')]:shutil.copy2(H/src,P/dst)
s=(H/'check_candidate_pool.py').read_text().replace("'native-candidate-build/candidate/slotstream'","'native-build/candidate/slotstream'");(P/'check_pool.py').write_text(s)
