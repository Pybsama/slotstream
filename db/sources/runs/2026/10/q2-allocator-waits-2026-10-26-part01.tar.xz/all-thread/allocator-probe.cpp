// Copyright © 2023-2024 Apple Inc.
#include "mlx/backend/metal/allocator.h"
#include "mlx/backend/gpu/device_info.h"
#include "mlx/backend/metal/metal.h"
#include "mlx/backend/metal/resident.h"
#include "mlx/memory.h"

#include <mach/vm_page_size.h>
#include <unistd.h>
#include <cassert>
#include <cstdlib>

#include <optional>
// Temporary diagnostic only. Preserve the allocator's original mutex and
// ownership. Observe actual lock acquisition and release on every thread.
#include <atomic>
#include <cstdio>
#include <cstdint>
#include <mach/mach_time.h>
#include <pthread.h>
namespace {
constexpr size_t ss_alloc_cap=4194304;
struct SSAllocRow {
  uint64_t start=0,acquired=0,released=0,end=0,thread=0,parent=0,bytes=0,kind=0;
};
static_assert(sizeof(SSAllocRow)==64);
SSAllocRow ss_alloc_rows[ss_alloc_cap];
std::atomic<bool> ss_alloc_recording{false};
std::atomic<size_t> ss_alloc_next{0},ss_alloc_active{0};
uint64_t ss_alloc_owner=0;
uint64_t ss_alloc_thread(){static thread_local uint64_t tid=[] {uint64_t v=0;pthread_threadid_np(nullptr,&v);return v;}();return tid;}
struct SSAllocSpan {
  SSAllocRow* row=nullptr;
  size_t id=0;
  SSAllocSpan(uint64_t kind,uint64_t bytes,uint64_t parent=0){
    if(!ss_alloc_recording.load(std::memory_order_acquire))return;
    ss_alloc_active.fetch_add(1,std::memory_order_acq_rel);
    if(!ss_alloc_recording.load(std::memory_order_acquire)){ss_alloc_active.fetch_sub(1,std::memory_order_release);return;}
    const size_t i=ss_alloc_next.fetch_add(1,std::memory_order_relaxed);
    if(i>=ss_alloc_cap){ss_alloc_active.fetch_sub(1,std::memory_order_release);return;}
    id=i+1;row=&ss_alloc_rows[i];*row={};
    row->thread=ss_alloc_thread();row->parent=parent;row->bytes=bytes;row->kind=kind;row->start=mach_absolute_time();
  }
  void finish(){if(row){row->end=mach_absolute_time();row=nullptr;ss_alloc_active.fetch_sub(1,std::memory_order_release);}}
  ~SSAllocSpan(){finish();}
};
struct SSAllocLock {
  std::unique_lock<std::mutex> held;
  const SSAllocSpan& parent;
  std::optional<SSAllocSpan> span;
  SSAllocLock(std::mutex& mutex,const SSAllocSpan& p):held(mutex,std::defer_lock),parent(p){lock();}
  void lock(){
    span.emplace(parent.row?parent.row->kind+100:100,parent.row?parent.row->bytes:0,parent.id);
    held.lock();if(span->row)span->row->acquired=mach_absolute_time();
  }
  void unlock(){
    if(span->row)span->row->released=mach_absolute_time();
    held.unlock();span->finish();span.reset();
  }
  ~SSAllocLock(){if(held.owns_lock())unlock();}
};
}
extern "C" void ss_mlx_alloc_probe_begin(){
  if(ss_alloc_active.load())std::abort();
  ss_alloc_next.store(0);ss_alloc_owner=ss_alloc_thread();
  ss_alloc_recording.store(true,std::memory_order_release);
}
extern "C" int ss_mlx_alloc_probe_end(const char* prefix){
  ss_alloc_recording.store(false,std::memory_order_release);
  if(ss_alloc_thread()!=ss_alloc_owner)return -2;
  // The request timer has ended. Drain only active diagnostic writes before
  // copying the evidence; never move or delay a model allocation or release.
  for(int i=0;i<2000 && ss_alloc_active.load(std::memory_order_acquire);++i)usleep(1000);
  fprintf(stderr,"ALLOC_PROBE rows=%zu cap=%zu active=%zu owner=%llu caller=%llu\n",ss_alloc_next.load(),ss_alloc_cap,ss_alloc_active.load(),(unsigned long long)ss_alloc_owner,(unsigned long long)ss_alloc_thread());
  if(ss_alloc_active.load(std::memory_order_acquire))return -3;
  const size_t n=ss_alloc_next.load();if(n>=ss_alloc_cap)return -4;
  char path[4096];int length=snprintf(path,sizeof(path),"%s.bin",prefix);
  if(length<0 || size_t(length)>=sizeof(path))return -5;
  FILE*f=fopen(path,"wbx");if(!f)return -6;
  const bool okay=fwrite(ss_alloc_rows,sizeof(SSAllocRow),n,f)==n;fclose(f);if(!okay)return -7;
  length=snprintf(path,sizeof(path),"%s.json",prefix);if(length<0 || size_t(length)>=sizeof(path))return -8;
  f=fopen(path,"wx");if(!f)return -9;
  mach_timebase_info_data_t time;mach_timebase_info(&time);
  fprintf(f,"{\"rows\":%zu,\"cap\":%zu,\"row_bytes\":64,\"numer\":%u,\"denom\":%u,\"owner\":%llu,\"active\":%zu,\"layout\":\"little-endian8uint64:start,acquired,released,end,thread,parent,bytes,kind\"}\n",n,ss_alloc_cap,time.numer,time.denom,(unsigned long long)ss_alloc_owner,ss_alloc_active.load());
  fclose(f);return 0;
}

namespace mlx::core {

constexpr size_t resource_options =
    MTL::ResourceStorageModeShared | MTL::ResourceHazardTrackingModeUntracked;

namespace allocator {

Allocator& allocator() {
  return metal::allocator();
}

void* Buffer::raw_ptr() {
  if (!ptr_) {
    return nullptr;
  }
  auto* buf = static_cast<MTL::Buffer*>(ptr_);
  assert(buf->storageMode() != MTL::StorageModePrivate);
  return buf->contents();
}

bool can_reuse_alien_buffer(void* ptr) {
  if (!ptr) {
    return true;
  }
  auto* buf = static_cast<MTL::Buffer*>(ptr);
  return buf->storageMode() != MTL::StorageModePrivate;
}

} // namespace allocator

namespace metal {

MetalAllocator::MetalAllocator(Device& d)
    : device_(d.mtl_device()),
      residency_sets_(d.residency_sets()),
      buffer_cache_(
          vm_page_size,
          [](MTL::Buffer* buf) { return buf->length(); },
          [this](MTL::Buffer* buf) {
            if (!buf->heap()) {
              residency_sets_.erase(buf);
            }
            auto pool = metal::new_scoped_memory_pool();
            buf->release();
          }) {
  const auto& info = gpu::device_info(0);
  auto memsize = std::get<size_t>(info.at("memory_size"));
  auto max_rec_size =
      std::get<size_t>(info.at("max_recommended_working_set_size"));
  resource_limit_ = std::get<size_t>(info.at("resource_limit"));
  block_limit_ = std::min(1.5 * max_rec_size, 0.95 * memsize);
  gc_limit_ = std::min(static_cast<size_t>(0.95 * max_rec_size), block_limit_);
  max_pool_size_ = block_limit_;
  bool is_vm = std::get<std::string>(info.at("device_name")) ==
      "Apple Paravirtual device";
  if (is_vm) {
    return;
  }
  auto pool = metal::new_scoped_memory_pool();
  auto heap_desc = MTL::HeapDescriptor::alloc()->init()->autorelease();
  heap_desc->setResourceOptions(resource_options);
  heap_desc->setSize(heap_size_);
  heap_ = NS::TransferPtr(device_->newHeap(heap_desc));
  residency_sets_.insert(heap_.get());
}

MetalAllocator::~MetalAllocator() = default;

size_t MetalAllocator::set_cache_limit(size_t limit) {
  SSAllocSpan call(1,limit);
  SSAllocLock lk(mutex_,call);
  std::swap(limit, max_pool_size_);
  return limit;
};

size_t MetalAllocator::set_memory_limit(size_t limit) {
  SSAllocSpan call(2,limit);
  SSAllocLock lk(mutex_,call);
  std::swap(limit, block_limit_);
  gc_limit_ = std::min(
      block_limit_,
      static_cast<size_t>(0.95 * device_->recommendedMaxWorkingSetSize()));
  return limit;
};

size_t MetalAllocator::get_memory_limit() {
  return block_limit_;
}

size_t MetalAllocator::set_wired_limit(size_t limit) {
  SSAllocSpan call(3,limit);
  SSAllocLock lk(mutex_,call);
  std::swap(limit, wired_limit_);
  residency_sets_.resize(wired_limit_);
  return limit;
};

Buffer MetalAllocator::malloc(size_t size) {
  SSAllocSpan call(4,size);
  // Metal doesn't like empty buffers
  if (size == 0) {
    return Buffer{nullptr};
  }

  // More helpful message if maximum buffer length is exceeded
  if (size > device_->maxBufferLength()) {
    std::ostringstream msg;
    msg << "[metal::malloc] Attempting to allocate " << size
        << " bytes which is greater than"
        << " the maximum allowed buffer size of " << device_->maxBufferLength()
        << " bytes.";
    throw std::runtime_error(msg.str());
  }

  // Align up memory
  if (size > vm_page_size) {
    size = vm_page_size * ((size + vm_page_size - 1) / vm_page_size);
  }

  // Try the cache
  SSAllocLock lk(mutex_,call);
  MTL::Buffer* buf = buffer_cache_.reuse_from_cache(size);
  if (!buf) {
    size_t mem_required = get_active_memory() + get_cache_memory() + size;

    // If we have a lot of memory pressure try to reclaim memory from the cache
    if (mem_required >= gc_limit_ || num_resources_ >= resource_limit_) {
      num_resources_ -=
          buffer_cache_.release_cached_buffers(mem_required - gc_limit_);
    }

    // Allocate new buffer if needed
    if (num_resources_ >= resource_limit_) {
      std::ostringstream msg;
      msg << "[metal::malloc] Resource limit (" << resource_limit_
          << ") exceeded.";
      throw std::runtime_error(msg.str());
    }
    lk.unlock();
    if (size < small_size_ && heap_) {
      buf = heap_->newBuffer(size, resource_options);
    }
    if (!buf) {
      buf = device_->newBuffer(size, resource_options);
    }
    if (!buf) {
      std::ostringstream msg;
      msg << "[malloc] Unable to allocate " << size << " bytes.";
      throw std::runtime_error(msg.str());
    }
    lk.lock();
    num_resources_++;
    if (!buf->heap()) {
      residency_sets_.insert(buf);
    }
  }

  active_memory_ += buf->length();
  peak_memory_ = std::max(peak_memory_, active_memory_);

  // Maintain the cache below the requested limit
  if (get_cache_memory() > max_pool_size_) {
    num_resources_ -= buffer_cache_.release_cached_buffers(
        get_cache_memory() - max_pool_size_);
  }

  return Buffer{static_cast<void*>(buf)};
}

void MetalAllocator::clear_cache() {
  SSAllocSpan call(5,0);
  SSAllocLock lk(mutex_,call);
  num_resources_ -= buffer_cache_.clear();
}

void MetalAllocator::free(Buffer buffer) {
  SSAllocSpan call(6,0);
  auto buf = static_cast<MTL::Buffer*>(buffer.ptr());
  if (buf == nullptr) {
    return;
  }
  SSAllocLock lk(mutex_,call);
  active_memory_ -= buf->length();
  if (get_cache_memory() < max_pool_size_) {
    buffer_cache_.recycle_to_cache(buf);
  } else {
    num_resources_--;
    if (!buf->heap()) {
      residency_sets_.erase(buf);
    }
    lk.unlock();
    auto pool = metal::new_scoped_memory_pool();
    buf->release();
  }
}

size_t MetalAllocator::size(Buffer buffer) const {
  return static_cast<MTL::Buffer*>(buffer.ptr())->length();
}

Buffer MetalAllocator::make_buffer(void* ptr, size_t size) {
  SSAllocSpan call(7,size);
  auto buf = device_->newBuffer(ptr, size, resource_options, nullptr);
  if (!buf) {
    return Buffer{nullptr};
  }
  SSAllocLock lk(mutex_,call);
  residency_sets_.insert(buf);
  active_memory_ += buf->length();
  peak_memory_ = std::max(peak_memory_, active_memory_);
  num_resources_++;
  return Buffer{static_cast<void*>(buf)};
}

void MetalAllocator::release(Buffer buffer) {
  SSAllocSpan call(8,0);
  auto buf = static_cast<MTL::Buffer*>(buffer.ptr());
  if (buf == nullptr) {
    return;
  }
  SSAllocLock lk(mutex_,call);
  active_memory_ -= buf->length();
  num_resources_--;
  residency_sets_.erase(buf);
  lk.unlock();
  auto pool = metal::new_scoped_memory_pool();
  buf->release();
}

MetalAllocator& allocator() {
  // By creating the |allocator_| on heap, the destructor of MetalAllocator
  // will not be called on exit and buffers in the cache will be leaked. This
  // can save some time at program exit.
  static MetalAllocator* allocator_ =
      new MetalAllocator(device(mlx::core::Device::gpu));
  return *allocator_;
}

} // namespace metal

size_t set_cache_limit(size_t limit) {
  return metal::allocator().set_cache_limit(limit);
}
size_t set_memory_limit(size_t limit) {
  return metal::allocator().set_memory_limit(limit);
}
size_t get_memory_limit() {
  return metal::allocator().get_memory_limit();
}
size_t set_wired_limit(size_t limit) {
  if (limit > std::get<size_t>(
                  gpu::device_info(0).at("max_recommended_working_set_size"))) {
    throw std::invalid_argument(
        "[metal::set_wired_limit] Setting a wired limit larger than "
        "the maximum working set size is not allowed.");
  }
  return metal::allocator().set_wired_limit(limit);
}
size_t get_active_memory() {
  return metal::allocator().get_active_memory();
}
size_t get_peak_memory() {
  return metal::allocator().get_peak_memory();
}
void reset_peak_memory() {
  metal::allocator().reset_peak_memory();
}
size_t get_cache_memory() {
  return metal::allocator().get_cache_memory();
}
void clear_cache() {
  return metal::allocator().clear_cache();
}

} // namespace mlx::core
