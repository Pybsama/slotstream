#include <vector>
#include <thread>
#include <cstring>
#include <cassert>
#include <cstdio>
int main() {
  std::vector<std::thread> workers;
  for (int j=0;j<4;++j) workers.emplace_back([j] {
    constexpr size_t n=262144;
    std::vector<unsigned char> source(n),target(n+16);
    for(size_t i=0;i<n;++i) source[i]=static_cast<unsigned char>(i+j);
    assert(memcpy(target.data(),source.data(),n)==target.data());
    assert(memcmp(target.data(),source.data(),n)==0);
    assert(memmove(target.data()+16,target.data(),n)==target.data()+16);
    assert(memcmp(target.data()+16,source.data(),n)==0);
    assert(memcpy(target.data(),source.data(),32)==target.data());
    assert(memcmp(target.data(),source.data(),32)==0);
  });
  for(auto& t:workers)t.join();
  puts("COPY_OBSERVER_BYTES_AND_OVERLAP_PASS");
}
