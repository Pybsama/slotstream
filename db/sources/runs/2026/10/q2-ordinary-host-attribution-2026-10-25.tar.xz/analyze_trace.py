from pathlib import Path
import csv,json,collections,bisect,statistics,hashlib
P=Path(__file__).resolve().parent

def rows(path):
    with path.open()as f:
        for r in csv.DictReader(x for x in f if not x.startswith('#')):yield r
    with path.open('rb')as f:f.seek(max(0,path.stat().st_size-512));last=f.read().decode().splitlines()[-1]
    foot=dict(s.split('=',1)for s in last[2:].split());assert int(foot['total'])<int(foot['cap']),(path,foot)
    if 'gpu_initial'in foot:assert foot['gpu_initial']==foot['cpu_initial']and foot['gpu_final']==foot['cpu_final']
def union(xs):
    out=[]
    for a,b in sorted(xs,key=lambda x:(x[0],x[1])):
        if b<=a:continue
        if not out or a>out[-1][1]:out.append([a,b])
        else:out[-1][1]=max(out[-1][1],b)
    return out
def length(xs):return sum(b-a for a,b in xs)
def intersection(a,b):
    out=[];i=j=0
    while i<len(a)and j<len(b):
        lo,hi=max(a[i][0],b[j][0]),min(a[i][1],b[j][1])
        if hi>lo:out.append([lo,hi])
        if a[i][1]<b[j][1]:i+=1
        else:j+=1
    return out
ledger=json.loads((P/'ordinary-copies-15-ledger.json').read_text());report=[]
for event in ledger:
    label=event['label'];native=event['arm']=='A';data=json.loads((P/(label+'.json')).read_text())
    paths=list(P.glob(label+'-commands.*.stages.csv'));assert len(paths)==1,(label,paths)
    stagepath=paths[0];prefix=stagepath.name[:-len('.stages.csv')]
    ss=list(rows(stagepath));pp=list(rows(P/(prefix+'.pipelines.csv')));aa=list(rows(P/(prefix+'.assignments.csv')))
    by_encoder=collections.defaultdict(list);pipelines=collections.defaultdict(list)
    for i,s in enumerate(ss):
        s.update(index=i,encoded=float(s['encoded']),gpu_start=int(s['gpu_start'])/1e9,gpu_end=int(s['gpu_end'])/1e9,pipelines=[])
        assert s['gpu_end']>s['gpu_start']>0 or s['gpu_end']==s['gpu_start']==0
        by_encoder[s['encoder']].append(s)
    for vv in by_encoder.values():vv.sort(key=lambda x:x['encoded'])
    creation={k:[s['encoded']for s in vv]for k,vv in by_encoder.items()}
    for x in pp:x['stamp']=float(x['stamp']);pipelines[x['pipeline']].append(x)
    for vv in pipelines.values():vv.sort(key=lambda x:x['stamp'])
    times={k:[x['stamp']for x in vv]for k,vv in pipelines.items()}
    unassigned=unknown=0
    for x in aa:
        t=float(x['stamp']);vv=by_encoder.get(x['encoder'],[]);idx=bisect.bisect_right(creation.get(x['encoder'],[]),t)-1
        if idx<0:unassigned+=1;continue
        # Ignore later selections on a reused pointer unless their encoder is a selected stage.
        # Stage time overlaps alone are insufficient; selected epochs below bound every assignment.
        pv=pipelines.get(x['pipeline'],[]);j=bisect.bisect_right(times.get(x['pipeline'],[]),t)-1
        name='UNKNOWN'if j<0 else pv[j]['name'];unknown+=j<0
        vv[idx]['pipelines'].append((t,name))
    readpath=P/(prefix.replace('-commands.','-reads.')+'.csv');reads=list(rows(readpath))
    commands=list(rows(P/(prefix+'.csv')));events=list(rows(P/(prefix+'.events.csv')))
    summaries=[]
    for r in data['runs']:
        if not r['id'].startswith('timed'):continue
        lo,hi=r['request_started_mach_ns']/1e9,r['request_ended_mach_ns']/1e9;window=[[lo,hi]]
        selected=[s for s in ss if lo<=s['encoded']<hi];assert selected
        gpu=intersection(union((s['gpu_start'],s['gpu_end'])for s in selected if s['gpu_end']>s['gpu_start']>0),window)
        missing=[s for s in selected if s['gpu_start']==s['gpu_end']==0]
        missing_spans=[]
        for stage in missing:
            candidates=[c for c in commands if c['buffer']==stage['buffer']and float(c['submitted'])>=stage['encoded']]
            c=min(candidates,key=lambda c:float(c['submitted']));assert int(c['status'])==4 and float(c['end'])>float(c['start'])>0
            missing_spans.append((float(c['start']),float(c['end'])))
        gpu_upper=intersection(union(gpu+missing_spans),window)
        rr=[x for x in reads if float(x['start'])<hi and float(x['end'])>lo and int(x['result'])>=65536]
        read=intersection(union((float(x['start']),float(x['end']))for x in rr),window)
        cs=[c for c in commands if lo<=float(c['submitted'])<hi]
        cmd=intersection(union((float(c['start']),float(c['end']))for c in cs if float(c['end'])>float(c['start'])>0),window)
        groups=collections.defaultdict(list)
        for s in selected:
            if s['gpu_start']==s['gpu_end']==0:continue
            names=tuple(n for t,n in s['pipelines']if lo<=t<hi)
            dt=s['gpu_end']-s['gpu_start'];groups[names].append(dt)
        group_report=sorted([dict(signature=list(k),count=len(v),sum_seconds=sum(v),median_seconds=statistics.median(v))for k,v in groups.items()],key=lambda x:-x['sum_seconds'])
        elapsed=hi-lo;g,rtime,overlap=length(gpu),length(read),length(intersection(gpu,read))
        targetpasses=r['stats']['decodeForwardPasses']if native else r['status_after']['scheduler']['decode_batches']-r['status_before']['scheduler']['decode_batches']
        summary=dict(id=r['id'],request_seconds=elapsed,target_passes=targetpasses,encoder_count=len(selected),gpu_encoder_union_seconds=g,read_union_seconds=rtime,gpu_read_overlap_seconds=overlap,read_outside_encoder_seconds=rtime-overlap,outside_reads_and_encoders_seconds=elapsed-length(union(gpu+read)),command_span_union_seconds=length(cmd),read_calls=len(rr),read_bytes=sum(int(x['result'])for x in rr),command_count=len(cs),missing_timestamp_encoders=len(missing),gpu_union_upper_bound_seconds=length(gpu_upper),missing_timestamp_added_upper_bound_seconds=length(gpu_upper)-g,text_sha256=hashlib.sha256(r['text'].encode()).hexdigest(),groups=group_report)
        if native:
            s=r['stats'];summary['native_phase_seconds']={k:s[k]for k in ['prefillSeconds','verifySeconds','draftSeconds','reconciliationSeconds','decodeSeconds']};assert r['streamed']==r['text']and not s.get('runtimeError')and len(r['tokens'])==384
        else:assert r['usage']['completion_tokens']==384
        assert min(g,rtime,overlap,summary['outside_reads_and_encoders_seconds'])>=-1e-5
        summaries.append(summary)
        print(json.dumps({**{k:v for k,v in summary.items()if k!='groups'},'label':label,'groups':group_report[:8]},indent=2))
    assert sum(s['encoder_count']for s in summaries)==len(ss),(label,len(ss))
    report.append(dict(label=label,guard_eligible=event['eligible'],unknown_pipeline_assignments=unknown,unassigned_selections_outside_sampled_epochs=unassigned,requests=summaries))
out=dict(scope='Instrumented ordinary requests, no speed qualification. Within counter capacity. Zero timestamp encoders are retained as missing observations, bounded by their completed enclosing command spans. Report encoder union lower bound and upper bound including those spans; never treat missing samples as zero execution. Encoder intervals include hardware scheduling/stalls, not arithmetic utilization. Read and encoder unions account for overlap. Full request includes prefill, draft, verify, rollback and emission; target pass counts exclude prefill. Different texts/work prevent direct per-pass attribution. Read bytes are physical observed calls including ahead.',whole_environment_eligible=len(report)==2 and all(r['guard_eligible']for r in report),arms=report)
(P/'trace-analysis.json').write_text(json.dumps(out,indent=2))
