// Diagnostic only: equal, allocation-free timing of actual reads in both engines.
#include <unistd.h>
#include <mach/mach_time.h>
#include <pthread/qos.h>
#include <pthread.h>
#include <atomic>
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <cerrno>
#include <algorithm>
namespace {
constexpr size_t capacity=1048576;
struct Record { uint64_t start,end,thread; uintptr_t destination; int64_t offset,result; size_t bytes; int fd,error,qos; };
Record records[capacity]; std::atomic<size_t> count{0}; bool enabled=false;
ssize_t traced_pread(int fd,void*destination,size_t bytes,off_t offset){
 if(!enabled)return pread(fd,destination,bytes,offset);
 thread_local uint64_t thread=[] { uint64_t v=0; pthread_threadid_np(nullptr,&v);return v; }();
 thread_local int qos=[] { qos_class_t q=QOS_CLASS_UNSPECIFIED;pthread_get_qos_class_np(pthread_self(),&q,nullptr);return (int)q; }();
 const size_t index=count.fetch_add(1,std::memory_order_relaxed); const auto start=mach_absolute_time();
 const ssize_t result=pread(fd,destination,bytes,offset); const int error=errno;
 const auto end=mach_absolute_time();
 if(index<capacity)records[index]={start,end,thread,(uintptr_t)destination,offset,result,bytes,fd,result<0?error:0,qos};
 errno=error;return result;
}
void dump(){
 const char* prefix=getenv("SLOTSTREAM_READ_OBSERVER");if(!prefix)return;enabled=false;
 char path[4096];snprintf(path,sizeof(path),"%s.%d.csv",prefix,getpid());FILE*f=fopen(path,"wx");if(!f)return;
 mach_timebase_info_data_t info;mach_timebase_info(&info);const double scale=double(info.numer)/info.denom/1e9;
 fprintf(f,"start,end,thread,destination,offset,result,bytes,fd,error,qos\n");
 const auto total=count.load();for(size_t i=0;i<std::min(total,capacity);++i){const auto&r=records[i];
 fprintf(f,"%.9f,%.9f,%llu,%llu,%lld,%lld,%zu,%d,%d,%d\n",r.start*scale,r.end*scale,(unsigned long long)r.thread,(unsigned long long)r.destination,(long long)r.offset,(long long)r.result,r.bytes,r.fd,r.error,r.qos);}
 fprintf(f,"# total=%zu cap=%zu\n",total,capacity);fclose(f);
}
__attribute__((constructor)) void initialize(){enabled=getenv("SLOTSTREAM_READ_OBSERVER")!=nullptr;if(enabled)atexit(dump);}
}
__attribute__((used)) static struct {const void* replacement;const void* original;} interpose[]
__attribute__((section("__DATA,__interpose")))={{(const void*)traced_pread,(const void*)pread}};
