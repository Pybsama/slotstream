from pathlib import Path
import csv,json,collections,bisect
P=Path(__file__).resolve().parent;O=P.parent/'q2-request-profile-20261025'
exec((P/'analyze_ready.py').read_text().split('summary=[];details=[]')[0],globals())
label='ordinary-stacks-15-0-A';f=next(O.glob(label+'-commands.*.stacks.csv'));prefix=f.name[:-len('.stacks.csv')]
ss=rows(O/(prefix+'.stages.csv'));cc=rows(O/(prefix+'.csv'));stack_rows=rows(f);symbols=json.loads((O/'stack-analysis.json').read_text())['symbols'];by_command=collections.defaultdict(list)
for x in stack_rows:
 if Path(x['image']).name=='slotstream':by_command[int(x['command'])].append((int(x['frame']),symbols[x['address']]))
frames={k:[s for _,s in sorted(v)]for k,v in by_command.items()};bybuffer=collections.defaultdict(list)
for c in cc:
 for k in ['submitted','start','end']:c[k]=float(c[k])
 c['index']=int(c['index']);bybuffer[c['buffer']].append(c)
for v in bybuffer.values():v.sort(key=lambda x:x['submitted'])
times={k:[c['submitted']for c in v]for k,v in bybuffer.items()};stage=[]
for x in ss:
 t=float(x['encoded']);a,b=int(x['gpu_start'])/1e9,int(x['gpu_end'])/1e9
 if a==b==0:continue
 c=bybuffer[x['buffer']][bisect.bisect_left(times[x['buffer']],t)];assert c['submitted']<=a
 stage.append(dict(encoded=t,start=a,end=b,command=c))
stage.sort(key=lambda x:x['start']);read=rows(next(O.glob(label+'-reads.*.csv')));read=union((float(x['start']),float(x['end']))for x in read if int(x['result'])>=65536)
read_ends=[b for a,b in read];read_prefix=[0]
for a,b in read:read_prefix.append(read_prefix[-1]+b-a)
def read_before(t):
 i=bisect.bisect_right(read_ends,t)
 return read_prefix[i]+(max(0,t-read[i][0])if i<len(read)else 0)
def origin(fs):
 names=['NativeExpertSchedule.submit','DFlashDraft.propose','DFlashDraft.append','Sampler.next','Generator.sample','Qwen4ExpModel.runHiddenMulti','Generator.dflashDecode']
 for n in names:
  if any(n in s for s in fs):return n
 return 'other'
report=[]
for r in json.loads((O/(label+'.json')).read_text())['runs']:
 if not r['id'].startswith('timed'):continue
 lo,hi=r['request_started_mach_ns']/1e9,r['request_ended_mach_ns']/1e9;last=lo;groups=collections.defaultdict(list);sampled=total=0
 for s in [s for s in stage if lo<=s['encoded']<hi]:
  if s['start']>last:
   a,b=last,min(s['start'],max(last,s['command']['submitted']));u=[[a,b]]if b>a else[];dt=max(0,b-a)-(read_before(b)-read_before(a));total+=dt
   fs=frames.get(s['command']['index'])
   if fs is not None:
    sampled+=dt;groups[origin(fs)].append(dict(exposed_seconds=dt,host_gap_seconds=b-a,frames=fs,command=s['command']['index']))
  last=max(last,s['end'])
 out=dict(id=r['id'],total_pre_submission_outside_reads=total,sampled_pre_submission_outside_reads=sampled,groups=sorted([dict(origin=k,count=len(v),sampled_exposed_seconds=sum(x['exposed_seconds']for x in v),largest=sorted(v,key=lambda x:-x['exposed_seconds'])[:3])for k,v in groups.items()],key=lambda x:-x['sampled_exposed_seconds']))
 report.append(out)
 print(r['id'],'covered',sampled,'of',total)
 for g in out['groups']:print(g['origin'],g['count'],g['sampled_exposed_seconds'])
(P/'submission-origin-analysis.json').write_text(json.dumps(dict(scope='Existing one-in-eight sampled commit stacks joined to next-encoder pre-submission intervals. Samples are not random; do not extrapolate sums or call them CPU execution time. Exact prior executable symbolication. No new model run.',requests=report),indent=2))
