from pathlib import Path
import json,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1];OLD=R/'.build/q2-request-profile-20261025'
probe='''
// Diagnostic build only. Single model owner, bounded events, output after request.
package enum Q2HostProbe {
    private struct Entry { let kind: String; let start: UInt64; let end: UInt64 }
    private static var entries: [Entry] = []
    private static var enabled = false
    private static var overflow = false
    package static func begin(_ active: Bool) {
        enabled = false; entries.removeAll(keepingCapacity: true)
        entries.reserveCapacity(131072); overflow = false; enabled = active
    }
    package static func stamp() -> UInt64 { enabled ? RuntimeClock.now() : 0 }
    package static func end(_ kind: String, _ start: UInt64) {
        guard start != 0 else { return }
        let end = RuntimeClock.now()
        if entries.count < 131072 { entries.append(Entry(kind: kind, start: start, end: end)) }
        else { overflow = true }
    }
    package static func flush(_ path: String) throws {
        enabled = false
        guard !overflow else { throw ModelError("Q2 host diagnostic capacity exceeded") }
        var text = "kind,start_ns,end_ns\\n"
        for entry in entries { text += "\\(entry.kind),\\(entry.start),\\(entry.end)\\n" }
        text += "# total=\\(entries.count) cap=131072\\n"
        try text.write(toFile: path, atomically: true, encoding: .utf8)
    }
}
'''
p=R/'Sources/Slotstream/NativeExpertSchedule.swift';s=p.read_text();start='''        try autoreleasepool {
            guard !ids.isEmpty''';assert s.count(start)==1
s=s.replace(start,'''        let hostStart = Q2HostProbe.stamp()
        defer { Q2HostProbe.end("submit_all", hostStart) }
        return try autoreleasepool {
            guard !ids.isEmpty''')
s=s.replace('''            let result = withExtendedLifetime((x, weightOwners, prerequisite, forecastArena, stream)) {''','''            Q2HostProbe.end("submit_swift_prepare", hostStart)
            let cppStart = Q2HostProbe.stamp()
            let result = withExtendedLifetime((x, weightOwners, prerequisite, forecastArena, stream)) {''')
s=s.replace('''            guard result == 0, let output, let job else''','''            Q2HostProbe.end("submit_cpp_prepare", cppStart)
            let pendingStart = Q2HostProbe.stamp()
            guard result == 0, let output, let job else''')
s=s.replace('''            if awaitingReads || Self.earlySubmission { asyncEval(value) }''','''            Q2HostProbe.end("submit_pending_prepare", pendingStart)
            if awaitingReads || Self.earlySubmission {
                let evalStart = Q2HostProbe.stamp()
                asyncEval(value)
                Q2HostProbe.end("submit_async_eval", evalStart)
            }''')
s+=probe;(P/'NativeExpertSchedule-host.swift').write_text(s)
p=R/'Sources/Slotstream/ExpertStore.swift';s=p.read_text();needle='''                            staging: (() -> NativeExpertSchedule.Staging?)? = nil) throws -> [Int] {
        for key in keys''';assert s.count(needle)==1
s=s.replace(needle,'''                            staging: (() -> NativeExpertSchedule.Staging?)? = nil) throws -> [Int] {
        let hostPoolStart = Q2HostProbe.stamp()
        for key in keys''')
s=s.replace('''                try prepare(planned, true)
            }
            if diagnosticOverlapReadyTickets''','''                Q2HostProbe.end("pool_before_prepare_miss", hostPoolStart)
                try prepare(planned, true)
            }
            let hostAfterPrepare = Q2HostProbe.stamp()
            if diagnosticOverlapReadyTickets''')
s=s.replace('''            try readDemand(demandOrder)
            // Tickets''','''            Q2HostProbe.end("pool_after_prepare_before_demand", hostAfterPrepare)
            try readDemand(demandOrder)
            // Tickets''')
s=s.replace('''        if missKeys.isEmpty { try prepare?(result, false) }''','''        if missKeys.isEmpty {
            Q2HostProbe.end("pool_before_prepare_hit", hostPoolStart)
            try prepare?(result, false)
        }''')
(P/'ExpertStore-host.swift').write_text(s)
s=(OLD/'SmartDFlashCommand-trace-window.swift').read_text()
s=s.replace('''                    let startMach=RuntimeClock.now()''','''                    Q2HostProbe.begin(probe.id.hasPrefix("timed"))
                    let startMach=RuntimeClock.now()''')
s=s.replace('''                    print("\\(probe.id):''','''                    try Q2HostProbe.flush(output + "." + probe.id + ".host.csv")
                    print("\\(probe.id):''')
assert 'Q2HostProbe.flush'in s
(P/'SmartDFlashCommand-host.swift').write_text(s)
plan=dict(question='Localize preparation and async evaluation time outside observed reads/GPU encoders in ordinary Q2 requests before changing read/submission ordering.',changes='Bounded timestamps only, no inference observer, no scheduling/math/memory/controller changes. Single-owner scopes, output after each request; capacity failure is fatal.',scope='One native diagnostic with read and Metal observers and ordinary2warm+2timed384tokens; no speed qualification. All production files and artifacts restored after build.',hashes={n:hashlib.sha256((P/n).read_bytes()).hexdigest()for n in ['NativeExpertSchedule-host.swift','ExpertStore-host.swift','SmartDFlashCommand-host.swift']})
(P/'host-probe-plan.json').write_text(json.dumps(plan,indent=2));print('Prepared three diagnostic source replacements only')
