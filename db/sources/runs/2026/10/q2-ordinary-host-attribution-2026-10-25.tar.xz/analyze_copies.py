from pathlib import Path
import bisect,collections,csv,json,re
P=Path(__file__).resolve().parent;R=P.parents[1]
def parsed(path):
 with path.open()as f:rows=list(csv.DictReader(l for l in f if not l.startswith('#')))
 with path.open('rb')as f:f.seek(max(0,path.stat().st_size-256));footer=dict(t.split('=')for t in f.read().decode().splitlines()[-1][2:].split())
 assert int(footer['total'])<int(footer['cap']),(path,footer)
 return rows,footer
def union(xs):
 out=[]
 for a,b in sorted(xs,key=lambda x:(x[0],x[1])):
  if b<=a:continue
  if not out or a>out[-1][1]:out.append([a,b])
  else:out[-1][1]=max(out[-1][1],b)
 return out
def length(x):return sum(b-a for a,b in x)
def inter(a,b):
 out=[];i=j=0
 while i<len(a)and j<len(b):
  lo,hi=max(a[i][0],b[j][0]),min(a[i][1],b[j][1])
  if hi>lo:out.append([lo,hi])
  if a[i][1]<b[j][1]:i+=1
  else:j+=1
 return out
header=json.loads((R/'.build/smart-dflash-eval/gsq-header.json').read_text());extents=[]
for t in header['tensors']:
 m=re.fullmatch(r'blk\.(\d+)\.ffn_(gate|up|down)_exps\.weight',t['name'])
 if m:extents.append(dict(start=11024672+t['offset'],end=11024672+t['offset']+512*460800,layer=int(m[1]),piece={'gate':0,'up':1,'down':2}[m[2]]))
assert len(extents)==144;extents.sort(key=lambda x:x['start']);extent_starts=[x['start']for x in extents]
ledger=json.loads((P/'ordinary-copies-15-ledger.json').read_text());report=[]
assert len(ledger)==2
for e in ledger:
 label=e['label'];native=e['arm']=='A';data=json.loads((P/(label+'.json')).read_text())
 reads,_=parsed(next(P.glob(label+'-reads.*.csv')));copies,_=parsed(next(P.glob(label+'-copies.*.csv')));stagefile=next(P.glob(label+'-commands.*.stages.csv'));stages,sfooter=parsed(stagefile);commands,_=parsed(stagefile.with_name(stagefile.name.replace('.stages.csv','.csv')))
 assert sfooter['cpu_initial']==sfooter['gpu_initial']and sfooter['cpu_final']==sfooter['gpu_final']
 rr=[];by_thread=collections.defaultdict(list)
 for x in reads:
  r={k:(float(v)if k in ['start','end']else int(v))for k,v in x.items()}
  if r['result']<65536:continue
  rr.append(r);by_thread[r['thread']].append(r)
 for vv in by_thread.values():vv.sort(key=lambda x:x['end'])
 endings={t:[x['end']for x in vv]for t,vv in by_thread.items()}
 cc=[]
 for x in copies:
  c={k:(float(v)if k in ['start','end']else v if k=='kind'else int(v))for k,v in x.items()};c['category']='other'
  vv=by_thread.get(c['thread'],[]);j=bisect.bisect_right(endings.get(c['thread'],[]),c['start'])-1
  if j>=0:
   read=vv[j]
   if read['destination']<=c['source']and c['source']+c['bytes']<=read['destination']+read['result']:
    offset=read['offset']+c['source']-read['destination'];idx=bisect.bisect_right(extent_starts,offset)-1
    if idx>=0:
     tensor=extents[idx]
     if tensor['start']<=offset and offset+c['bytes']<=tensor['end']and c['bytes']==460800 and(offset-tensor['start'])%460800==0:c.update(category='expert',layer=tensor['layer'],piece=tensor['piece'],expert=(offset-tensor['start'])//460800)
  cc.append(c)
 results=[]
 for row in data['runs']:
  if not row['id'].startswith('timed'):continue
  lo,hi=row['request_started_mach_ns']/1e9,row['request_ended_mach_ns']/1e9;window=[[lo,hi]]
  selected=[s for s in stages if lo<=float(s['encoded'])<hi]
  gpu=inter(union((int(s['gpu_start'])/1e9,int(s['gpu_end'])/1e9)for s in selected if int(s['gpu_end'])>int(s['gpu_start'])>0),window)
  missing=[]
  for s in selected:
   if int(s['gpu_start'])==int(s['gpu_end'])==0:
    matches=[c for c in commands if c['buffer']==s['buffer']and float(c['submitted'])>=float(s['encoded'])];c=min(matches,key=lambda c:float(c['submitted']));assert int(c['status'])==4;missing.append([float(c['start']),float(c['end'])])
  gpu_upper=inter(union(gpu+missing),window);reads_u=inter(union((x['start'],x['end'])for x in rr),window)
  chosen=[c for c in cc if c['start']<hi and c['end']>lo];out={}
  for kind in ['all','expert','other']:
   xs=[c for c in chosen if kind=='all'or c['category']==kind];u=inter(union((c['start'],c['end'])for c in xs),window)
   out[kind]=dict(calls=len(xs),bytes=sum(c['bytes']for c in xs),service_seconds=sum(c['end']-c['start']for c in xs),union_seconds=length(u),outside_read_gpu_upper=length(u)-length(inter(u,union(reads_u+gpu))),outside_read_gpu_lower=length(u)-length(inter(u,union(reads_u+gpu_upper))),gpu_overlap=length(inter(u,gpu)),read_overlap=length(inter(u,reads_u)),sizes=collections.Counter(c['bytes']for c in xs))
  result=dict(id=row['id'],request_seconds=hi-lo,gpu_union_seconds=length(gpu),read_union_seconds=length(reads_u),outside_read_gpu_seconds_upper=hi-lo-length(union(gpu+reads_u)),outside_read_gpu_seconds_lower=hi-lo-length(union(gpu_upper+reads_u)),copies=out)
  results.append(result);print(label,json.dumps(result,indent=2))
 report.append(dict(label=label,guard_eligible=e['eligible'],requests=results))
(P/'copy-analysis.json').write_text(json.dumps(dict(scope='Instrumented ordinary requests; no speed qualification. Exact same-thread source-read + original GGUF extent required for expert attribution. Read/GPU/copy unions account for overlap, not additive CPU thread service. Missing encoder timestamps bounded by enclosing completed command spans. Different adaptive work prevents direct equal-work differential.',environment_eligible=all(e['eligible']for e in ledger),arms=report),indent=2))
