from pathlib import Path
import csv,fcntl,hashlib,json,os,subprocess,sys
P=Path(__file__).resolve().parent;R=P.parents[1]
sys.path.insert(0,str(R/'Tools'))
from prefill_bench import preflight
lock=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(P/'copy-observer-build-child.lock')
before=preflight(4)
assert not(P/'copy-observer-build.json').exists()
flags=['xcrun','clang++','-std=c++17','-O2','-fno-builtin-memcpy','-fno-builtin-memmove']
commands=[flags+['-dynamiclib',str(P/'copy_observer.cpp'),'-o',str(P/'copy_observer.dylib')],flags+[str(P/'copy_observer_check.cpp'),'-o',str(P/'copy-observer-check')]]
receipt=dict(before=before,commands=commands,scope='Diagnostic observer and weights-free byte/lifetime check only. No production build or performance claim.')
for i,cmd in enumerate(commands):
 r=subprocess.run(cmd,capture_output=True,text=True,timeout=120)
 (P/f'copy-observer-build-{i}.log').write_text(r.stdout+r.stderr)
 assert r.returncode==0,r.stderr
env={k:v for k,v in os.environ.items()if not k.startswith(('SLOTSTREAM_','MLX_','DYLD_'))}
env.update(DYLD_INSERT_LIBRARIES=str(P/'copy_observer.dylib'),SLOTSTREAM_COPY_OBSERVER=str(P/'copy-observer-check'))
r=subprocess.run([str(P/'copy-observer-check')],env=env,capture_output=True,text=True,timeout=30)
(P/'copy-observer-check.log').write_text(r.stdout+r.stderr)
assert r.returncode==0 and 'COPY_OBSERVER_BYTES_AND_OVERLAP_PASS'in r.stdout
f=next(P.glob('copy-observer-check.*.csv'))
lines=f.read_text().splitlines();rows=list(csv.DictReader(x for x in lines if not x.startswith('#')))
assert len(rows)==8 and len({r['thread']for r in rows})==4
assert all(int(r['bytes'])==262144 and float(r['end'])>=float(r['start'])for r in rows)
receipt.update(passed=True,observed_large_copies=len(rows),observed_threads=4,small_copies_excluded=True,files={n:hashlib.sha256((P/n).read_bytes()).hexdigest()for n in ['copy_observer.cpp','copy_observer_check.cpp','copy_observer.dylib','copy-observer-check']})
(P/'copy-observer-build.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps({k:v for k,v in receipt.items()if k not in ['commands','before','files']}))
