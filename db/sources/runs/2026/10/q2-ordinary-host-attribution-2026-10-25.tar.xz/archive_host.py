from pathlib import Path
import hashlib,io,json,re,tarfile
P=Path(__file__).resolve().parent;R=P.parents[1];OLD=P.parent/'q2-request-profile-20261025'
assert json.loads((P/'ordinary-host-15-ledger.json').read_text())[0]['complete']
assert len(json.loads((P/'ordinary-copies-15-ledger.json').read_text()))==2
sha=lambda b:hashlib.sha256(b).hexdigest()
prior=R/'db/sources/runs/2026/10/q2-ordinary-request-and-submission-diagnosis-2026-10-25.tar.xz'
refs={'prior_archive':str(prior.relative_to(R)),'sha256':sha(prior.read_bytes()),'files':{}}
needed=['stack-analysis.json','ordinary-stacks-15-0-A.json']
needed += [f.name for f in OLD.glob('ordinary-stacks-15-0-A-commands.*.csv')]
needed += [f.name for f in OLD.glob('ordinary-stacks-15-0-A-reads.*.csv')]
for n in needed:refs['files'][n]=sha((OLD/n).read_bytes())
with tarfile.open(prior,'r|xz')as t:
 found=None
 for m in t:
  if m.name=='archive-manifest.json':found=json.load(t.extractfile(m))
assert found
for n,h in refs['files'].items():assert found[n]['sha256']==h
(P/'prior-stack-evidence.json').write_text(json.dumps(refs,indent=2))
parts={'copies':{},'host':{}}
for f in P.rglob('*'):
 if not f.is_file()or'__pycache__'in f.parts or f.name=='archive-receipt.json':continue
 if f.suffix not in ['.py','.swift','.cpp','.mm','.json','.jsonl','.csv','.log','.stderr','.txt']and f.name!='build-source.tar.gz':continue
 name=str(f.relative_to(P));key='copies'if f.name.startswith('ordinary-copies-15')else'host';parts[key][name]=f
parts['host']['reference/v68-build-identity.json']=R/'.build/native-replay-20261023/v68/build-identity.json'
parts['host']['reference/trace-cli-build-identity.json']=OLD/'native-trace-build/candidate/build-identity.json'
secret=re.compile(rb'(?:ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{25,}|sk-(?:proj-)?[A-Za-z0-9_-]{30,}|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----)')
receipts=[]
for key,files in parts.items():
 dest=R/('db/sources/runs/2026/10/q2-ordinary-'+key+'-attribution-2026-10-25.tar.xz');assert not dest.exists()
 manifest={}
 for n,f in files.items():
  b=f.read_bytes();assert not secret.search(b),n;manifest[n]=dict(bytes=len(b),sha256=sha(b))
 raw=json.dumps(manifest,indent=2).encode()+b'\n'
 with tarfile.open(dest,'w:xz',preset=3)as t:
  for n,f in sorted(files.items()):t.add(f,arcname=n,recursive=False)
  info=tarfile.TarInfo('archive-manifest.json');info.size=len(raw);t.addfile(info,io.BytesIO(raw))
 seen={}
 with tarfile.open(dest,'r|xz')as t:
  for m in t:
   b=t.extractfile(m).read()
   if m.name=='archive-manifest.json':assert json.loads(b)==manifest
   else:seen[m.name]=dict(bytes=len(b),sha256=sha(b))
 assert seen==manifest
 receipts.append(dict(path=str(dest.relative_to(R)),files=len(manifest),bytes=dest.stat().st_size,sha256=sha(dest.read_bytes()),readback_verified=True,credential_pattern_matches=0));print(json.dumps(receipts[-1]),flush=True)
(P/'archive-receipt.json').write_text(json.dumps(dict(parts=receipts,prior_refs=refs,excluded='Executables, dylibs, metallibs, weights, transient window files and pycache. Existing sampled-stack raw bytes referenced by verified prior archive hashes.'),indent=2))
