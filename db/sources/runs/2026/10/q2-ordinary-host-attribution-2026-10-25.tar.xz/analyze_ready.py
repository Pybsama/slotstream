from pathlib import Path
import csv,json,collections,bisect,re
P=Path(__file__).resolve().parent

def rows(p):
 with p.open()as f:r=list(csv.DictReader(l for l in f if not l.startswith('#')))
 with p.open('rb')as f:f.seek(max(0,p.stat().st_size-256));tail=f.read().decode().splitlines()[-1]
 foot=dict(x.split('=')for x in tail[2:].split());assert int(foot['total'])<int(foot['cap'])
 return r

def union(xs):
 out=[]
 for a,b in sorted(xs,key=lambda x:(x[0],x[1])):
  if b<=a:continue
  if not out or a>out[-1][1]:out.append([a,b])
  else:out[-1][1]=max(out[-1][1],b)
 return out
def length(xs):return sum(b-a for a,b in xs)
def inter(a,b):
 out=[];i=j=0
 while i<len(a)and j<len(b):
  lo,hi=max(a[i][0],b[j][0]),min(a[i][1],b[j][1])
  if hi>lo:out.append([lo,hi])
  if a[i][1]<b[j][1]:i+=1
  else:j+=1
 return out
summary=[];details=[]
for e in json.loads((P/'ordinary-copies-15-ledger.json').read_text())+json.loads((P/'ordinary-host-15-ledger.json').read_text()):
 label=e['label'];ep=next(P.glob(label+'-commands.*.events.csv'));cp=ep.with_name(ep.name.replace('.events.csv','.csv'))
 cs=[{k:float(v)for k,v in c.items()}for c in rows(cp)]
 ev=[dict(kind=x['kind'],stamp=float(x['stamp']),buffer=int(x['buffer']),event=int(x['event']),value=int(x['value']))for x in rows(ep)]
 bybuffer=collections.defaultdict(list);signals=collections.defaultdict(list);returns=collections.defaultdict(list)
 for x in ev:
  if x['kind']in ['W','E']:bybuffer[x['buffer']].append(x)
  elif x['kind']=='S':signals[(x['event'],x['value'])].append(x['stamp'])
  elif x['kind']=='R':returns[(x['event'],x['value'])].append(x['stamp'])
 for v in bybuffer.values():v.sort(key=lambda x:x['stamp'])
 times={k:[x['stamp']for x in v]for k,v in bybuffer.items()}
 for v in list(signals.values())+list(returns.values()):v.sort()
 previous={};matches=[];unmatched=0
 for c in sorted(cs,key=lambda x:x['submitted']):
  b=int(c['buffer']);lo=previous.get(b,0);previous[b]=c['submitted'];vv=bybuffer.get(b,[]);tt=times.get(b,[]);es=vv[bisect.bisect_right(tt,lo):bisect.bisect_right(tt,c['submitted'])]
  for w in [x for x in es if x['kind']=='W']:
   key=w['event'],w['value'];ss=signals.get(key,[]);idx=bisect.bisect_left(ss,w['stamp'])
   if idx<len(ss)and ss[idx]<=c['end']:s=ss[idx]
   elif idx and ss[idx-1]>=lo:s=ss[idx-1]
   else:unmatched+=1;continue
   rr=returns.get(key,[]);j=bisect.bisect_left(rr,s);assert j<len(rr);end=rr[j]
   first=not any(x['kind']=='E'and x['stamp']<w['stamp']for x in es)
   matches.append(dict(submitted=c['submitted'],first=first,signal=s,signal_return=end,gpu_start=c['start'],gpu_end=c['end'],wait_encoded=w['stamp'],setter=end-s,resume=max(0,c['start']-end),pre_signal=max(0,min(s,c['end'])-c['start'])))
 stage=rows(ep.with_name(ep.name.replace('.events.csv','.stages.csv')));gpu=union((int(x['gpu_start'])/1e9,int(x['gpu_end'])/1e9)for x in stage if int(x['gpu_end'])>int(x['gpu_start'])>0)
 read=rows(next(P.glob(label+'-reads.*.csv')));read=union((float(x['start']),float(x['end']))for x in read if int(x['result'])>=65536)
 d=json.loads((P/(label+'.json')).read_text())
 for r in d['runs']:
  if not r['id'].startswith('timed'):continue
  lo,hi=r['request_started_mach_ns']/1e9,r['request_ended_mach_ns']/1e9;ms=[m for m in matches if lo<=m['submitted']<hi];first=[m for m in ms if m['first']]
  spans=inter(union([m['signal_return'],m['gpu_start']]for m in first),[[lo,hi]]);setter=inter(union([m['signal'],m['signal_return']]for m in first),[[lo,hi]])
  out=dict(label=label,id=r['id'],guard=e['eligible'],matched_host_waits=len(ms),first_waits=len(first),pre_signal_first=sum(m['pre_signal']for m in first),resume_union=length(spans),resume_outside_reads_gpu=length(spans)-length(inter(spans,union(read+gpu))),setter_union=length(setter),setter_outside_reads_gpu=length(setter)-length(inter(setter,union(read+gpu))),unmatched_waits_in_process=unmatched)
  summary.append(out);details.append(dict(label=label,id=r['id'],matches=ms));print(json.dumps(out))
(P/'readiness-summary.json').write_text(json.dumps(summary,indent=2));(P/'readiness-detail.json').write_text(json.dumps(details,indent=2))
