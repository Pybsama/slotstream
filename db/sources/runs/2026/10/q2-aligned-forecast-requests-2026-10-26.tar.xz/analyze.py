from pathlib import Path
import collections,hashlib,json,statistics
P=Path(__file__).resolve().parent
ledger=json.loads((P/'forecast-15-ledger.json').read_text());assert [e['arm']for e in ledger]==list('ABCCBA')
rows=[];outputs={}
for event in ledger:
 d=json.loads((P/(event['label']+'.json')).read_text());native=event['arm']!='C'
 g=json.loads((P/(event['label']+'-guard.observer.json')).read_text())if native else d
 samples=g['samples']if native else g['memory_samples']
 headroom=[s['reclaimable']if native else s.get('reclaimable_bytes')for s in samples];headroom=[x for x in headroom if x is not None]
 assert headroom and min(headroom)>=1e9 and g['peak_combined_bytes']<=15e9
 assert event['actual_cache_slots']==4067
 eligible=event['eligible'] and g.get('complete',False) and not g.get('external_build_samples',[]) and not g.get('guard_errors',[])
 row=dict(label=event['label'],arm=event['arm'],eligible=eligible,peak_gb=g['peak_combined_bytes']/1e9,min_headroom_gb=min(headroom)/1e9,swapins=event['after']['vm']['swapins']-event['before']['vm']['swapins'],swapouts=event['after']['vm']['swapouts']-event['before']['vm']['swapouts'],runs=[])
 for run in d['runs']:
  r=dict(id=run['id'],request_seconds=run['elapsed_seconds'])
  outputs[(event['label'],run['id'])]=dict(prompt_ids=run['prompt_ids'],tokens=run.get('tokens'),text=run['text'])
  if native:
   s=run['stats'];r.update({k:s.get(k)for k in ['decodeSeconds','prefillSeconds','verifySeconds','verifyPasses','draftSeconds','draftedTokens','acceptedDrafts','decodeModelTokens','decodeReadBytes','decodeRecords','decodeIOSeconds','reconciliationSeconds']});r['depth_histogram']=dict(sorted(collections.Counter(s['adaptiveDraftDepths']).items()));r['prefetch']={k:s['expertPrefetch'].get(k)for k in ['adopted','issued','cancelled','expired','failed','demandMisses','scheduleSeconds','peakLiveBytes']}
  else:
   r.update(timings=run['timings'],decode=run['metrics'].get('decode'))
  row['runs'].append(r)
 rows.append(row)
ratios={};variation=[]
for ident in ['timed-2','timed-3']:
 t=[next(r['request_seconds']for r in e['runs']if r['id']==ident)for e in rows]
 ab=[t[1]/t[0],t[4]/t[5]];bc=[t[1]/t[2],t[4]/t[3]]
 am,bm,cm=[statistics.median([t[i],t[j]])for i,j in [(0,5),(1,4),(2,3)]]
 ratios[ident]=dict(times=t,median_seconds=dict(baseline=am,candidate=bm,splash=cm),candidate_over_baseline_directions=ab,candidate_over_baseline_pooled=bm/am,candidate_over_splash_directions=bc,candidate_over_splash_pooled=bm/cm,baseline_over_splash_pooled=am/cm,retention=all(x<1 for x in ab)and bm/am<=.98,parity=all(x<=1.05 for x in bc))
 base=outputs[(ledger[0]['label'],ident)]
 for e in ledger:
  other=outputs[(e['label'],ident)];assert other['prompt_ids']==base['prompt_ids']
  variation.append(dict(task=ident,reference=ledger[0]['label'],other=e['label'],text_equal=base['text']==other['text'],first_token_difference=None if other['tokens']is None else next((i for i,(a,b)in enumerate(zip(base['tokens'],other['tokens']))if a!=b),None)))
eligible=all(r['eligible']for r in rows)
out=dict(environment_eligible=eligible,retention_passed=eligible and all(r['retention']for r in ratios.values()),parity_passed=eligible and all(r['parity']for r in ratios.values()),arms=rows,ratios=ratios,output_variation=variation,scope='New complete adaptive request study. Prior aligned-forecast component exclusion stays excluded and was not rerun. All current arms count. Capped throughput success is not semantic task quality. Exact arithmetic validated previously for the identical candidate.')
(P/'analysis.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:out[k]for k in ['environment_eligible','retention_passed','parity_passed','ratios']},indent=2))
