from pathlib import Path
import json,subprocess
P=Path(__file__).resolve().parent;R=P.parents[1];DB=R/'db';tool='/Users/carlos/.dbmd/bin/dbmd'
r=json.loads((P/'archive-receipt.json').read_text());assert r['readback_verified']
a=json.loads((P/'analysis.json').read_text());assert a['environment_eligible'] and not a['retention_passed']
def write(path, kind, title, fields, body):
    f = P / (Path(path).name + '.body.md')
    f.write_text(body.strip() + '\n')
    cmd = [tool, 'write', path, '--dir', str(DB), '--json', '--type', kind, '--summary', title, '--fm', 'title=' + title, '--body-file', str(f)]
    for (k, v) in fields.items():
        cmd += ['--fm', k + '=' + str(v)]
    print(subprocess.run(cmd, check=True, capture_output=True, text=True).stdout.strip())
    if not (DB / path).exists():
        found = list(DB.rglob(Path(path).name))
        assert len(found) == 1
        print(subprocess.run([tool, 'rename', str(found[0].relative_to(DB)), path, '--dir', str(DB), '--json'], check=True, capture_output=True, text=True).stdout.strip())
run='sources/runs/2026/10/2026-10-26-q2-aligned-forecast-requests.md';machine='[[records/machines/macbook-pro-m5-pro-48gb]]'
write(run,'run','Q2 aligned forecast-only normal requests reject retention',dict(tool='Originalv68, immutable aligned forecast candidate and publishedSplash1.4.0',command='Archived request_run.py --order ABCCBA --budget15 --context8192 --modelsmart-q2',binary='Baseline db1af8ffd201d3dfb83d64b036db12383b08ac0a522d9079c3343acebe78c89b; candidate e2538ce6eebcf1ee814668b0a5e9159cabb3c72654f12d217f5dec932aba93bf; full source identities archived',captured_at='2026-10-26',machines=machine,discarded='false'),f"""
[Raw evidence]({Path(r['path']).name}): {r['files']} members, {r['bytes']} bytes, SHA-256 `{r['sha256']}`. Every member is read back and hash-verified, with zero credential-pattern matches.

Preserve the independently frozen new-scope plan, immutable candidate/source comparison, prior component exclusion, original correctness receipts, all six ordinary request arms, every warmup, streamed output, prompt IDs, request/work counters, observed memory/paging/thermal/build state, passive clocks, analysis and default restoration. The previous target-only prerequisite is never reclassified as passed. This is its first normal-adaptive request comparison, not a retry of excluded component timing.

All six arms pass the environmental gates with 4,067 actual slots at 15 GB and 8,192 context. The candidate improves code in both orders, but slows prose in both. It is rejected for production. The same candidate had already passed original-byte, lifecycle and 111-pass full-logit arithmetic checks; throughput text is not semantic task quality. The conditional additional task-quality suite does not run because speed retention fails. Known strict-format and Fast recall failures remain visible.

The archive also contains the cleanup-analysis interval-index equivalence check: 15,000 seeded cases match naive interval intersection. This is an offline analyzer check, not a model or speed rerun.
""")
write('records/measurements/q2-aligned-forecast-normal-requests.md','measurement','Q2 aligned forecast reads improve code but regress prose',dict(date='2026-10-26',doc='measurements',level=2,order=1920,status='measured',machines=machine,runs=f'[[{run[:-3]}]]'),f"""
Aligned forecast-only direct reads fail normal-request retention: code becomes 6.69 percent faster, but prose becomes 3.16 percent slower. Both effects have the same direction in forward and reverse order. Keep v68. Fast's retained production path is unchanged, and the Q2 parity goal remains open.

This directly tests the missing ordinary-request scope identified after [[records/measurements/q2-completion-cleanup]]. The prior [[records/measurements/q2-forecast-only-continuation]] remains paging-excluded, and its own conditional follow-up remains unrun. The new experiment is explicitly frozen separately; it neither reruns that target-only protocol nor counts its favorable arms. Evidence is [[{run[:-3]}]].

The candidate removes forecast scratch copies with page-aligned read extents, leaving the original demand path, 4,067-slot cache and 128 MiB forecast reserve. Reuse the exact checked binary; seven runtime files differ from v68, plus an unused diagnostic CLI command. No new model rebuild or arithmetic change enters this request study. Both engines use identical prompt IDs, BF16 activations/KV, FP32 recurrence, 8,192 requested context and a 15 GB physical ceiling. Published Splash retains its CPU polling; its GPU spin library is absent.

One ABCCBA has two warmups then 384-token code and prose requests per fresh process. All six arms pass observed memory, paging, thermal and competing-build gates. Peak physical use is at most 12.300 GB native and 13.886 GB Splash; observed remaining headroom stays above 13.009 GB.

| Engine | Code seconds, forward/reverse | Prose seconds, forward/reverse |
| --- | ---: | ---: |
| Native v68 | 12.8985 / 13.9233 | 13.7084 / 13.3274 |
| Aligned forecasts | 12.3411 / 12.6857 | 14.2249 / 13.6648 |
| Published Splash | 11.5761 / 12.1798 | 12.9650 / 12.7023 |

The candidate remains 5.35 percent slower than Splash on pooled code and 8.66 percent slower on pooled prose; it misses the separate within-five-percent target. The unchanged baseline is 12.91/5.33 percent slower in this protocol. These are current two-request measurements, not model-wide performance estimates or the best historical speeds.

The amount of work changes under normal adaptation. Native code uses 111/106 passes and 475/490 target rows; the candidate uses 111/113 and 456/500. Native prose uses 126/126 passes and 465/479 rows; the candidate uses 133/134 and 468/478. Candidate prose reads 27,367/28,668 demand records versus 26,992/26,782. Timed outputs also diverge between unchanged baseline processes. These facts explain why fixed-component timing cannot simply predict whole requests; they do not prove a controller bug or assign a causal percentage to extra passes.

The next discriminating experiment holds the original 111 target passes and retained prefixes fixed while executing complete cycles, including real drafting, greedy selection and commits. It differs from the older target-only component. A faster fixed cycle would locate an interaction with changing work; a flat cycle would show that the old component copy effect does not transfer to complete work. Neither outcome alone can reverse this normal-request rejection.

The candidate is isolated and never installed. Its common C++ Job metadata allocation would also need a Q2-only boundary before any future retention to preserve Fast's allocation path; this study never runs Fast through the candidate. All 509 production runtime inputs and five default artifacts remain byte-identical to v68. No Smart promotion, release or complete app-readiness claim follows.
""")
subprocess.run([tool,'log','update','records/measurements/q2-aligned-forecast-normal-requests.md','--dir',str(DB),'-m','First clean ordinary request test of immutable aligned forecast-only candidate: code6.69percent faster, prose3.16percent slower in bothorders; rejectretention. Preserve allABCCBAarms, oldcomponent exclusion and exactcandidate provenance. Next holdcompletecycleworkfixed to separateworkchanges fromcopycost. ProductionFast/v68unchanged.'],check=True)
