from pathlib import Path
import json,subprocess
P=Path(__file__).resolve().parent;R=P.parents[1];DB=R/'db';tool='/Users/carlos/.dbmd/bin/dbmd'
C=P.parent/'q2-completion-cleanup-20261026'
r=json.loads((C/'archive-receipt.json').read_text());assert r['readback_verified']
a=json.loads((C/'analysis.json').read_text());assert a['representative_attribution_qualified']
def write(path, kind, title, fields, body):
    f = P / (Path(path).name + '.body.md')
    f.write_text(body.strip() + '\n')
    cmd = [tool, 'write', path, '--dir', str(DB), '--json', '--type', kind, '--summary', title, '--fm', 'title=' + title, '--body-file', str(f)]
    for (k, v) in fields.items():
        cmd += ['--fm', k + '=' + str(v)]
    print(subprocess.run(cmd, check=True, capture_output=True, text=True).stdout.strip())
    if not (DB / path).exists():
        found = list(DB.rglob(Path(path).name))
        assert len(found) == 1
        print(subprocess.run([tool, 'rename', str(found[0].relative_to(DB)), path, '--dir', str(DB), '--json'], check=True, capture_output=True, text=True).stdout.strip())
run='sources/runs/2026/10/2026-10-26-q2-completion-cleanup.md';machine='[[records/machines/macbook-pro-m5-pro-48gb]]'
links='\n'.join(f"- [{Path(x['path']).name}]({Path(x['path']).name}): {x['bytes']} bytes; SHA-256 `{x['sha256']}`." for x in r['archives'])
write(run,'run','Q2 completion cleanup and output-map contention diagnostic',dict(tool='Bounded MLX cleanup and exact dependency diagnostic',command='Archived prepare.py, build.py, run.py validation/trace, analyze.py',binary='Isolated MLX cleanup candidate and original required-dependency baseline; full identities archived',captured_at='2026-10-26',machines=machine,discarded='false'),f"""
{links}

All 129 members are read back and hash-verified, with zero credential-pattern matches. Sources, dependency revisions, build identities, lifetime/lock self-test, Metal validation, all four timing arms and warmups, binary cleanup/dependency records, GPU/read/copy traces and analyses are retained. Executables, weights and duplicate source tarballs are excluded.

The whole-instrument control compares the original dependency baseline with the new destructor wrappers plus recording, not merely the same wrapped binary with its flag disabled. Off/on/on/off is clean and stays within its two-percent sensitivity bound in both orders. The exact validation and all timed proposals/selected IDs match their own reference. Resolve 5,328 jobs per instrumented arm with no missing or ambiguous ancestry.

The first offline matcher recomputed and scanned each mutex's entire hold union for every wait. It was explicitly terminated after excessive CPU time, exit 143. Its source and log remain. The completed analysis indexes each mutex once and bisects to overlapping holds. No model run was repeated or selected because of this offline algorithm change. A separate seeded 15,000-case naive/indexed equivalence receipt is preserved with the following aligned-forecast request evidence.

All 509 runtime inputs, five v68 artifacts and MLX dependency bytes/modes are restored. No production change, Fast change, Smart promotion or app-readiness claim follows.
""")
write('records/measurements/q2-completion-cleanup.md','measurement','Q2 completion cleanup is too small to explain the remaining gap',dict(date='2026-10-26',doc='measurements',level=2,order=1919,status='measured',machines=machine,runs=f'[[{run[:-3]}]]'),f"""
MLX completion cleanup and its output-map mutex do not account for a meaningful part of the remaining Q2 slowdown. Keep this path unchanged. This closes the specific coverage gap from [[records/measurements/q2-controlled-read-latency]]; evidence is [[{run[:-3]}]].

The bounded diagnostic preserves container copy/move ownership and destroys the whole original container at the original capture-lifetime boundary, including bucket storage. It brackets callback bodies, temporary arrays, captured data owners, fence/output sets, event vectors and the existing submission/completion mutex. A standalone lifetime and known-contention check passes. Under Metal validation, all 111 full-logit hashes, proposals and selected IDs match the native reference.

At 15 GB, 8,192 context and 4,067 actual expert slots, the original-baseline/new-instrument off/on/on/off control measures 11.4111/11.5309/11.5705/11.4394 seconds. Both directions pass the two-percent sensitivity bound; the pooled instrument cost is 1.10 percent. All environmental gates pass. Each process has one warmup and one measured 111-cycle round. This is frozen complete-cycle diagnosis, not normal adaptive request qualification.

Both instrumented rounds resolve every one of 5,328 required jobs. Request-thread destruction totals 11.26/12.05 milliseconds, with only 0.970/0.981 milliseconds outside the union of recorded GPU work and actual required-read dependencies. Output-map acquisition waiting totals 0.285/0.396 milliseconds; only 0.033/0.031 milliseconds lie outside that union. No request-thread wait overlaps a recorded background holder of the same mutex. Background destruction covers 130.1/128.3 milliseconds, of which 46.2/44.7 lie outside that union. Concurrent background work is not request waiting. Nested intervals are unioned, never added.

The recorder covers cleanup that starts during the measured request; it drains already-active writes afterward. Later-starting cleanup is unmeasured. Recorded GPU intervals are not kernel utilization, and this result does not prove every reference-management operation free. It rejects this concrete cleanup/mutex hypothesis as the large direct cause. No allocator, fence, buffer-pool or ownership rewrite is justified.

The next useful observation is normal adaptive requests with aligned forecast-only reads, preserving the original demand path and cache capacity. That candidate has exact arithmetic evidence but has never completed ordinary request qualification. Its old component protocol remains paging-excluded, and its original conditional follow-up remains unrun. A separately frozen ordinary-request experiment directly tests the missing user-facing question; it must not reinterpret that excluded prerequisite as passed or reuse favorable historical timing arms. The independent Splash extra-copy intervention motivates this scope after the reader, delay and cleanup hypotheses failed to explain enough of the gap.

Fast remains unchanged. Existing Fast recall and Q2 strict-format failures stay separate; no release or Smart-default promotion follows.
""")
subprocess.run([tool,'log','update','records/measurements/q2-completion-cleanup.md','--dir',str(DB),'-m','Qualify completion-cleanup instrumentation at1.10percent pooled overhead. Exact111full logits and5328jobs per traced round; request cleanup exposes about1ms and mutex waits below0.4ms. Reject cleanup rewrite; preserve stopped offline matcher and corrected indexing. No production or Fast change.'],check=True)
