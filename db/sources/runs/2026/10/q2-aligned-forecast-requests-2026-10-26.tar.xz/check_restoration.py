from pathlib import Path
import json,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1];B=R/'.build/native-replay-20261023/v68'
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
source=json.loads((B/'build-identity.json').read_text())['source'];bad={n:sha(R/n)for n,h in source.items()if sha(R/n)!=h};assert not bad,bad
names=['slotstream','slotstream-checks','mlx.metallib','build-identity.json','build-source.tar.gz'];hashes={n:sha(R/'.build/release'/n)for n in names};assert all(h==sha(B/n)for n,h in hashes.items())
(P/'restoration.json').write_text(json.dumps(dict(runtime_source_count=len(source),source_mismatches=bad,default_artifact_sha256=hashes,runtime_and_Fast_unchanged=True,reference='native-replay-20261023/v68'),indent=2));print('RESTORED',len(source),len(names))
