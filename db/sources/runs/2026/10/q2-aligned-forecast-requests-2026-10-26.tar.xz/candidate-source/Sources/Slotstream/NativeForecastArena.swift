import Foundation
import MLX
import Cmlx
import CNativeSchedule

/// Read-ahead owns at most 64 records in the already charged 128 MiB reserve.
/// The GPU repacks a successful prediction from its original arena position,
/// as Splash's staging source table does. A lease survives the last GPU read;
/// wrong predictions release staging without touching the expert cache.
package final class NativeForecastArena {
    package static let enabled = NativeExpertSchedule.gpuStagingEnabled
        && ProcessInfo.processInfo.environment["SLOTSTREAM_NATIVE_FORECAST_ARENA"] != "0"
    package let arrays: [MLXArray]
    private let bases: [UnsafeMutableRawPointer]
    package let pieceBytes: [Int]
    private let pieceStrides: [Int]
    private let lock = NSLock()
    private var free = Array((0..<64).reversed())
    package var available: Int { lock.withLock { free.count } }

    package init(pieceBytes: [Int]) throws {
        let pieceStrides = pieceBytes.map { (($0 + 16383) / 16384 + 1) * 16384 }
        guard pieceBytes.count == 3, pieceBytes.allSatisfy({ $0 > 0 }),
              pieceStrides.reduce(0, +) * 64 <= 128 * 1024 * 1024 else {
            throw ModelError("Native forecast arena exceeds its reservation")
        }
        var arrays: [MLXArray] = [], bases: [UnsafeMutableRawPointer] = []
        for bytes in pieceStrides {
            var base: UnsafeMutableRawPointer?
            guard let context = ss_schedule_forecast_array(64, Int32(bytes), &base), let base else {
                throw ModelError(String(cString: ss_schedule_error()))
            }
            arrays.append(MLXArray(mlx_array(ctx: context))); bases.append(base)
        }
        self.arrays = arrays; self.bases = bases; self.pieceBytes = pieceBytes; self.pieceStrides = pieceStrides
    }

    package var pageAligned: Bool { bases.allSatisfy { Int(bitPattern: $0) % 16384 == 0 } }
    package var strideBytes: Int { pieceStrides.max() ?? 0 }

    package func acquire(offsets: [Int] = [0, 0, 0]) -> Lease? {
        lock.withLock {
            guard offsets.count == 3, offsets.enumerated().allSatisfy({ $0.element >= 0 && $0.element < 16384 && $0.element + pieceBytes[$0.offset] <= pieceStrides[$0.offset] }),
                  let index = free.popLast() else { return nil }
            return Lease(arena: self, index: index, offsets: offsets)
        }
    }

    package final class Lease {
        package let arena: NativeForecastArena, index: Int
        private let lock = NSLock()
        private var released = false
        package let offsets: [Int]
        fileprivate init(arena: NativeForecastArena, index: Int, offsets: [Int]) { self.arena = arena; self.index = index; self.offsets = offsets }
        package var buffers: [UnsafeMutableRawPointer] {
            arena.bases.indices.map { arena.bases[$0] + index * arena.pieceStrides[$0] + offsets[$0] }
        }
        package func release() {
            lock.withLock {
                guard !released else { return }
                released = true
                arena.lock.withLock { arena.free.append(index) }
            }
        }
        deinit { release() }
    }
}
