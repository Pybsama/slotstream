from pathlib import Path
import sys,subprocess,json
P=Path(__file__).resolve().parent;R=P.parents[1];D=R/'.build/q2-bottleneck-20261024';OLD=R/'.build/native-replay-20261023'
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight,terminate_child_tree
sys.path.insert(0,str(R/'.build/native-q2-20261021'));from thermal import wait_nominal
wait_nominal(P/'normal-cooldown.json');preflight(18)
command=[sys.executable,str(P/'guarded_run.py'),'--label','normal-native','--budget','15','--env','DYLD_INSERT_LIBRARIES='+str(OLD/'metal_command_observer_mrc.dylib'),'--env','SLOTSTREAM_METAL_OBSERVER='+str(P/'normal-commands'),'--',str(P/'diagnostic-build/candidate/slotstream'),'smart-dflash-check','--native-read-ahead','on','--method','q2','--model','smart-q2','--memory-gb','15','--max-context','8192','--cases',str(OLD/'short-warm-384-cases.json'),'--output',str(P/'normal-native.json')]
(P/'normal-plan.json').write_text(json.dumps(dict(command=command,scope='Diagnostic only. Actual code and prose verify widths, cache demand, host spans and passive GPU command timestamps. No speed claim. Production outputs remain frozen v68.'),indent=2))
with(P/'normal-driver.log').open('x') as f:
 child=subprocess.Popen(command,cwd=R,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 try:rc=child.wait(timeout=900)
 finally:
  if child.poll() is None:terminate_child_tree(child)
raise SystemExit(rc)
