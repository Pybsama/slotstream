from pathlib import Path
import shutil
P=Path(__file__).resolve().parent;OLD=P.parent/'q2-bottleneck-20261024';D=P/'upstream';D.mkdir(exist_ok=False)
shutil.copytree(OLD/'upstream/include',D/'include')
for n in ['Runtime.cpp','ExpertStore.cpp','fixed_verify.mm']:(D/n).write_bytes((OLD/'upstream'/n).read_bytes())
p=D/'Runtime.cpp';s=p.read_text().replace('if(tokens.size()!=8)','if(tokens.empty()||tokens.size()>8)').replace('"fixed target requires eight rows"','"fixed target requires one through eight rows"').replace('contents<uint32_t>(d(DecodeTensor::VerifyRows),"fixed rows")=8','contents<uint32_t>(d(DecodeTensor::VerifyRows),"fixed rows")=uint32_t(tokens.size())');p.write_text(s)
p=D/'ExpertStore.cpp';s=p.read_text();anchor='void ExpertStore::diagnosticClearResidency() {'
s=s.replace(anchor,'''void ExpertStore::diagnosticDiscardKeys(const std::vector<uint64_t> &keys) {
  std::lock_guard lock(impl_->mutex);auto &impl=*impl_;impl.retireAhead();
  for(auto key:keys) {
    auto block=uint32_t(key/impl.shape.experts),expert=uint32_t(key%impl.shape.experts);
    auto slot=impl.blocks.at(block).slot.at(expert);
    if(slot==kNoSlot) throw std::logic_error("diagnostic requested key not resident");
    auto &size=impl.sizes[impl.blocks[block].size];impl.evict(size,slot);size.recycling.free(slot);
  }
  impl.publish();
}
'''+anchor);p.write_text(s)
p=D/'include/model/ExpertStore.hpp';s=p.read_text().replace('  void diagnosticClearResidency();','  void diagnosticClearResidency();\n  void diagnosticDiscardKeys(const std::vector<uint64_t> &keys);');p.write_text(s)
p=D/'fixed_verify.mm';s=p.read_text();start=s.index('      const std::vector<uint32_t> prompt = {',s.index('int main('));end=s.index('      ModelBatchItem item',start)
s=s[:start]+'''      const char *fixturePath=std::getenv("Q2_DIAGNOSTIC_FIXTURE");
      if(!fixturePath) throw std::runtime_error("fixture missing");
      NSData *data=[NSData dataWithContentsOfFile:[NSString stringWithUTF8String:fixturePath]];
      NSDictionary *fixture=[NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
      if(!fixture) throw std::runtime_error("invalid fixture");
      std::vector<uint32_t> prompt,tokens;
      for(NSNumber *n in fixture[@"prompt_ids"]) prompt.push_back(n.unsignedIntValue);
      for(NSNumber *n in fixture[@"output_ids"]) tokens.push_back(n.unsignedIntValue);
      std::vector<uint64_t> drops;
      if(const char *path=std::getenv("Q2_DIAGNOSTIC_EVICTIONS")) {
        NSData *dropData=[NSData dataWithContentsOfFile:[NSString stringWithUTF8String:path]];
        NSArray *arr=[NSJSONSerialization JSONObjectWithData:dropData options:0 error:nil];
        if(!arr)throw std::runtime_error("invalid eviction list");
        for(NSNumber *n in arr)drops.push_back(n.unsignedLongLongValue);
      }
      prefill(executor,lanes[0],prompt);
'''+s[end:]
s=s.replace('12000000000ULL','15000000000ULL').replace('model::ExecutionLimits::prefillTokenBudget,','256,').replace('{"cached","miss"}','{"cached","partial"}').replace('if(std::string(cache)=="miss") store->diagnosticClearResidency();','if(std::string(cache)=="partial") store->diagnosticDiscardKeys(drops);')
p.write_text(s)
s=(OLD/'build_upstream.py').read_text();(P/'build_upstream.py').write_text(s)
print('Prepared isolated variable-width replay, original production Splash unchanged')
