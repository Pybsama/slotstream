from pathlib import Path
import json,csv,statistics,collections
P=Path(__file__).resolve().parent
phase='matched'
A=json.loads((P/(phase+'-ledger.json')).read_text())
def union(xs):
 ys=[]
 for a,b in sorted(xs):
  if b<=a:continue
  if ys and a<=ys[-1][1]:ys[-1][1]=max(ys[-1][1],b)
  else:ys.append([a,b])
 return ys
def length(xs):return sum(b-a for a,b in union(xs))
def overlap(x,y):return length([(max(a,c),min(b,d))for a,b in union(x)for c,d in union(y)if min(b,d)>max(a,c)])
out=[]
for a in A:
 commands=[{k:float(v)for k,v in r.items()}for r in csv.DictReader(l for l in next(P.glob(a['label']+'-commands*.csv')).open()if not l.startswith('#'))]
 rows=[]
 for r in a['runs']:
  if r['round']<2:continue
  lo,hi=(r['start_ns']/1e9,r['end_ns']/1e9)if a['arm']=='N'else(r['start'],r['end'])
  gpu=[(max(lo,c['start']),min(hi,c['end']))for c in commands if c['end']>lo and c['start']<hi]
  reads=[(max(lo,x['start_ns']/1e9),min(hi,x['end_ns']/1e9))for x in r['read_intervals']if 'read'in x['kind']]
  copies=[(max(lo,x['start_ns']/1e9),min(hi,x['end_ns']/1e9))for x in r['read_intervals']if 'copy'in x['kind']]
  row=dict(condition=r['condition'],round=r['round'],wall=(hi-lo)*1000,gpu=length(gpu)*1000,read=length(reads)*1000,copy=length(copies)*1000,read_gpu_overlap=overlap(reads,gpu)*1000,uncovered=((hi-lo)-length(gpu+reads+copies))*1000,commands=len(gpu),demand_records=r.get('records_read',r.get('records_fetched')),forecast_records=r.get('records_prefetched',r.get('records_adopted')),read_bytes=sum(x['bytes']for x in r['read_intervals']if 'read'in x['kind']))
  if a['arm']=='S':row.update(prepare=(r['prepared']-r['start'])*1000,submit=(r['submitted']-r['prepared'])*1000,read_work=r['read_work_seconds']*1000)
  else:
   groups=collections.defaultdict(dict)
   for e in r['trace']:groups[e['layer']][e['kind']]=e
   for name,begin,end in [('prepare','prepare_start','prepare_end'),('read_wait','prepare_end','reads_ready'),('route_wait','route_start','route_ready')]:
    ints=[(es[begin]['ns']/1e9,es[end]['ns']/1e9)for es in groups.values()if begin in es and end in es]
    row[name]=length(ints)*1000;row[name+'_without_gpu']=(length(ints)-overlap(ints,gpu))*1000
  rows.append(row)
 conditions={}
 for c in sorted(set(r['condition']for r in rows)):
  rs=[r for r in rows if r['condition']==c];conditions[c]={k:statistics.median(r[k]for r in rs)for k in rs[0]if k not in ['condition','round']}
 out.append(dict(label=a['label'],width=a['width'],arm=a['arm'],eligible=a['eligible'],conditions=conditions,runs=rows))
(P/'replay-analysis.json').write_text(json.dumps(out,indent=2));summary=[]
for w in [3,4]:
 for c in ['cached_off','partial_off','cached_on','partial_on']:
  line=dict(width=w,condition=c)
  for arm in ['N','S']:
   rows=[a['conditions'][c]for a in out if a['width']==w and a['arm']==arm]
   if rows:line[arm]={k:statistics.mean(r[k]for r in rows)for k in rows[0]}
  summary.append(line)
(P/'replay-summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
