from pathlib import Path
import json,collections
P=Path(__file__).resolve().parent;summary=[]
for width in [3,4]:
 n=json.loads((P/f'probe-{width}-0-N.json').read_text());s=json.loads((P/f'probe-{width}-1-S.json').read_text())
 nr=next(r for r in n['runs']if r['condition']=='cached_off'and r['round']==2)
 sr=next(r for r in s['runs']if r['condition']=='cached_off'and r['round']==2)
 native={e['layer']:set(e['ids'])for e in nr['trace']if e['kind']=='route_ready'}
 splash=collections.defaultdict(set)
 for key in sr['routes']:splash[key//512].add(key%512)
 fixture=json.loads((P/f'fixture-{width}.json').read_text());drops=[];layers=[]
 for l in range(48):
  common=sorted(native[l]&splash[l]);want=fixture['miss_counts'][str(l)];take=min(want,len(common));preferred=sorted(set(fixture["miss_keys"][str(l)])&set(common));ordered=preferred+[e for e in common if e not in preferred];drops.extend(l*512+e for e in ordered[:take])
  layers.append(dict(layer=l,native=len(native[l]),splash=len(splash[l]),common=len(common),requested=want,evicted=take))
 (P/f'evictions-{width}.json').write_text(json.dumps(drops));summary.append(dict(width=width,evicted=len(drops),layers=layers))
(P/'eviction-selection.json').write_text(json.dumps(summary,indent=2));print([(r['width'],r['evicted'])for r in summary])
