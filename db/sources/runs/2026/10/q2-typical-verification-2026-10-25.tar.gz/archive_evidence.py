from pathlib import Path
import hashlib,io,json,tarfile,subprocess,re
P=Path(__file__).resolve().parent;R=P.parents[1];OLD=P.parent/'native-replay-20261023'
# Runtime source and the restored default must exactly match the qualified baseline.
import importlib.util
spec=importlib.util.spec_from_file_location('identity',R/'Tools/build_identity.py');identity=importlib.util.module_from_spec(spec);spec.loader.exec_module(identity)
expected=json.loads((OLD/'v68/build-identity.json').read_text())
current={str(f.relative_to(R)):identity.sha(f)for f in identity.source_files(R)}
assert current==expected['source']
assert identity.sha(R/'.build/release/slotstream')=='db1af8ffd201d3dfb83d64b036db12383b08ac0a522d9079c3343acebe78c89b'
(P/'runtime-restoration-check.json').write_text(json.dumps(dict(source_files=len(current),all_source_hashes_equal_v68=True,default_binary_equal_v68=True,production_patch_reverted=True),indent=2)+'\n')
files={}
for f in P.rglob('*'):
 if f.is_file() and f.suffix in ['.json','.py','.log','.swift','.cpp','.hpp','.mm','.metal','.patch','.txt','.csv']:
  files[str(f.relative_to(P))]=f
for f in OLD.glob('typical-copy-q2-15-*-guard*'):
 if f.is_file():files['external-guards/'+f.name]=f
for name in ['guarded_run_io.py','q2_upstream_bench_io.py','metal_command_observer.mm','short-warm-384-cases.json','v29-profile-smart-q2-fixture.json','v68-combine-state-smart-q2-1.json']:
 files['reference/'+name]=OLD/name
files['reference/Splash-LICENSE.txt']=Path('/tmp/slotstream-splash-review.EJTswU/splash/LICENSE')
files['reference/thermal.py']=R/'.build/native-q2-20261021/thermal.py'
# Logits repeat byte-for-byte across modes/processes. Store each unique byte stream once,
# plus a map binding every original receipt filename to its content hash.
logits={};seen={}
for f in P.glob('*.f32'):
 h=identity.sha(f);logits[f.name]=dict(bytes=f.stat().st_size,sha256=h,stored_as=seen.setdefault(h,'logits/'+f.name))
 files[seen[h]]=f
(P/'logits-file-map.json').write_text(json.dumps(logits,indent=2)+'\n');files['logits-file-map.json']=P/'logits-file-map.json'
manifest={name:dict(bytes=f.stat().st_size,sha256=identity.sha(f))for name,f in files.items()}
raw=json.dumps(manifest,indent=2).encode()+b'\n'
dest=R/'db/sources/runs/2026/10/q2-typical-verification-2026-10-25.tar.gz';assert not dest.exists()
with tarfile.open(dest,'w:gz')as tar:
 for name,f in sorted(files.items()):tar.add(f,arcname=name,recursive=False)
 info=tarfile.TarInfo('archive-manifest.json');info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
with tarfile.open(dest)as tar:
 for name,m in manifest.items():
  raw=tar.extractfile(name).read();assert len(raw)==m['bytes'] and hashlib.sha256(raw).hexdigest()==m['sha256']
receipt=dict(path=str(dest.relative_to(R)),files=len(manifest),bytes=dest.stat().st_size,sha256=identity.sha(dest),readback_verified=True,unique_logits_files=len(seen))
(P/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
