from pathlib import Path
import json,shutil,sys,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1];OLD=R/'.build/q2-bottleneck-20261024'
sys.path.insert(0,str(R/'Tools'));from optimization_build import build
# Scoped diagnostics only, restored after freezing.
paths=['Sources/Slotstream/ExpertStore.swift','Sources/Slotstream/Layers.swift','Sources/slotstream-cli/Q2ProfileCommand.swift']
original={n:(R/n).read_bytes() for n in paths}
store=(P/'ExpertStore.swift').read_text()
anchor='    package func diagnosticDiscardResidency() throws {'
assert store.count(anchor)==1
store=store.replace(anchor,'''    package func diagnosticDiscardKeys(_ keys:[Int]) throws {
        guard pinned.count==0, inFlightCount==0 else { throw ModelError("diagnostic keys are still pinned") }
        eval(pools); adaptiveReplacement=nil
        for id in keys {
            let key=ExpertKey(id/cfg.numExperts,id%cfg.numExperts)
            guard let slot=map[key] else { throw ModelError("diagnostic requested key was not resident") }
            map.removeValue(forKey:key);keyOf[slot]=nil;refBit[slot]=false
        }
    }
'''+anchor)
cli=(OLD/'Q2ProfileCommand.swift').read_text()
cli=cli.replace('@Option var memoryGB: Double = 12','@Option var memoryGB: Double = 15\n    @Option var evictions: String?\n    @Option var width: Int = 4')
cli=cli.replace('memoryGB == 12','(12...15).contains(memoryGB)')
cli=cli.replace('prefix(8)','prefix(width)').replace('ids.count == 8','ids.count == width && (3...4).contains(width)')
cli=cli.replace('prefix.count <= 512','prefix.count <= 768')
cli=cli.replace('let machine = Machine.current()', '''let drops=try evictions.map { try JSONDecoder().decode([Int].self,from:Data(contentsOf:URL(fileURLWithPath:$0))) } ?? []
        let machine = Machine.current()''')
cli=cli.replace('["cached","miss"]','["cached","partial"]')
cli=cli.replace('if cache == "miss" { try model.pool.diagnosticDiscardResidency() }','if cache == "partial" { try model.pool.diagnosticDiscardKeys(drops) }')
cli=cli.replace('Q2DiagnosticReads.reset(enabled: traceReads)','Q2DiagnosticReads.reset(enabled: traceReads)\n                        Q2TypicalTrace.reset(enabled:true)')
cli=cli.replace('"read_intervals":Q2DiagnosticReads.take()', '"read_intervals":Q2DiagnosticReads.take(),"trace":Q2TypicalTrace.take()')
cli=cli.replace('"trace_reads":traceReads,','"trace_reads":traceReads,"evictions":drops,')
cli=cli.replace('Target-only fixed eight-row verification','Target-only fixed captured-width verification')
cli=cli.replace('Cold clears residency metadata only.','Partial misses discard explicit common routed keys only; tensor storage and capacity unchanged. Prefix is re-prefilled identically by chunk, not a byte-identical cross-engine state.')
# Ensure multiple same-size prefix chunks for comparable lower memory usage.
cli=cli.replace('eval(try model.lastLogitsChecked(prefix,state:state))','for lo in stride(from:0,to:prefix.count,by:256) { eval(try model.lastLogitsChecked(Array(prefix[lo..<min(lo+256,prefix.count)]),state:state)) }')
(P/'replay-Q2ProfileCommand.swift').write_text(cli);(P/'replay-ExpertStore.swift').write_text(store)
try:
 (R/paths[0]).write_text(store);(R/paths[1]).write_text((P/'Layers.swift').read_text());(R/paths[2]).write_text(cli)
 result=build(R,P/'replay-build',required_gb=10,jobs=4)
 print(json.dumps({k:v for k,v in result.items()if k in ['passed','error','elapsed_seconds']}),flush=True)
finally:
 for n,b in original.items():(R/n).write_bytes(b)
 (P/'replay-restored.json').write_text(json.dumps({n:hashlib.sha256((R/n).read_bytes()).hexdigest()for n in original},indent=2))
if not result['passed']:raise SystemExit(1)
