from pathlib import Path
import sys,json,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1];sys.path.insert(0,str(R/'Tools'));from optimization_build import build
store=(R/'Sources/Slotstream/ExpertStore.swift').read_text();base=(P/'originals/ExpertStore.swift').read_text()
assert store!=base
addition=store[store.index('        if isQ2, rawCopy, !usePackedLayout {'):store.index('        if nativeAffineTiles || (isQ2 && Q2PackedExperts.enabled) {',store.index('        if isQ2, rawCopy, !usePackedLayout {'))]
paths=['Sources/Slotstream/ExpertStore.swift','Sources/Slotstream/Layers.swift','Sources/slotstream-cli/Q2ProfileCommand.swift'];original={p:(R/p).read_bytes() for p in paths}
s=(P/'replay-ExpertStore.swift').read_text();anchor='        if nativeAffineTiles || (isQ2 && Q2PackedExperts.enabled) {';assert s.count(anchor)==2;s=s.replace(anchor,addition+anchor,1)
(P/'candidate-replay-ExpertStore.swift').write_text(s)
try:
 (R/paths[0]).write_text(s);(R/paths[1]).write_text((P/'Layers.swift').read_text());(R/paths[2]).write_text((P/'replay-Q2ProfileCommand.swift').read_text())
 result=build(R,P/'copy-replay-build',required_gb=10,jobs=4);print({k:v for k,v in result.items()if k in ['passed','error','elapsed_seconds']},flush=True)
finally:
 for p,b in original.items():(R/p).write_bytes(b)
 (P/'copy-replay-restored.json').write_text(json.dumps({p:hashlib.sha256((R/p).read_bytes()).hexdigest()for p in paths},indent=2))
if not result['passed']:raise SystemExit(1)
