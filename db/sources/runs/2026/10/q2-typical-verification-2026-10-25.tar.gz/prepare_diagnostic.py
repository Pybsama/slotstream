from pathlib import Path
import json,sys,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1];OLD=R/'.build/q2-bottleneck-20261024'
sys.path.insert(0,str(R/'Tools'));from optimization_build import build
names=['ExpertStore.swift','Layers.swift','DFlashGenerate.swift','NativeExpertSchedule.swift']
original={str(Path('Sources/Slotstream')/n):(R/'Sources/Slotstream'/n).read_bytes() for n in names}
original['Sources/slotstream-cli/SmartDFlashCommand.swift']=(R/'Sources/slotstream-cli/SmartDFlashCommand.swift').read_bytes()
(P/'originals').mkdir(exist_ok=False)
for n,b in original.items():(P/'originals'/Path(n).name).write_bytes(b)
text={n:b.decode() for n,b in original.items()}
def edit(name,old,new):
 k=next(k for k in text if k.endswith('/'+name));assert text[k].count(old)==1,(name,old,text[k].count(old));text[k]=text[k].replace(old,new)
# Reuse previous read-only interval instrumentation from its frozen source.
base=(OLD/'ExpertStore.swift').read_text();base=base.replace('public struct PackedLayoutReport:', '''package enum Q2TypicalTrace {
    private static let lock=NSLock()
    private static var events: [[String:Any]]=[]
    package static var enabled=false
    package static var pass = -1
    package static func reset(enabled:Bool) { lock.withLock { self.enabled=enabled; events=[]; pass = -1 } }
    package static func mark(_ kind:String,_ fields:[String:Any]=[:]) {
        guard enabled else { return }
        let t=RuntimeClock.now()
        lock.withLock { var e=fields; e["kind"]=kind;e["ns"]=t;e["pass"]=pass;events.append(e) }
    }
    package static func take() -> [[String:Any]] { lock.withLock { events } }
}
public struct PackedLayoutReport:''')
assert original['Sources/Slotstream/ExpertStore.swift']==(OLD/'native-original-v2/ExpertStore.swift').read_bytes()
text['Sources/Slotstream/ExpertStore.swift']=base
edit('Layers.swift','''        let routeIndices = idx.asType(.int32)''','''        Q2TypicalTrace.mark("route_start",["layer":layer,"width":B*S])
        let routeIndices = idx.asType(.int32)''')
edit('Layers.swift','''        let expertIds = routeIndices.asArray(Int32.self)  // B*S*topK''','''        let expertIds = routeIndices.asArray(Int32.self)  // B*S*topK
        Q2TypicalTrace.mark("route_ready",["layer":layer,"ids":expertIds])''')
edit('Layers.swift','''            _ = try pool.ensureScheduled(uniq, staging:''','''            Q2TypicalTrace.mark("ensure_start",["layer":layer,"unique":uniq.count,"misses":uniq.filter{!pool.isResident($0)}.map{$0.expert}])
            _ = try pool.ensureScheduled(uniq, staging:''')
edit('Layers.swift','''                pending = try schedule.submit(x,''','''                Q2TypicalTrace.mark("prepare_start",["layer":self.layer,"miss":awaitingReads])
                pending = try schedule.submit(x,''')
edit('Layers.swift','''                if awaitingReads, nativePrerequisite != nil { self.sharedPrelaunches += 1 }''','''                Q2TypicalTrace.mark("prepare_end",["layer":self.layer])
                if awaitingReads, nativePrerequisite != nil { self.sharedPrelaunches += 1 }''')
edit('Layers.swift','''            let output = try pending.value(afterRelease: nativeReleased)''','''            Q2TypicalTrace.mark("reads_ready",["layer":layer,"staged":pending.staging?.copiedSlots.count ?? 0,"forecast":pending.staging?.forecastSlots.count ?? 0])
            let output = try pending.value(afterRelease: nativeReleased)
            Q2TypicalTrace.mark("published",["layer":layer])''')
edit('Layers.swift','''            nativeScheduledPasses += 1''','''            Q2TypicalTrace.mark("layer_end",["layer":layer])
            nativeScheduledPasses += 1''')
edit('DFlashGenerate.swift','''            let verifyStart = RuntimeClock.now()''','''            Q2TypicalTrace.pass += 1
            Q2TypicalTrace.mark("verify_start",["tokens":input,"position":state.tokenCount])
            let verifyStart = RuntimeClock.now()''')
edit('DFlashGenerate.swift','''            eval(result.logits)''','''            eval(result.logits)
            Q2TypicalTrace.mark("verified")''')
edit('DFlashGenerate.swift','''            consumed.append(contentsOf: kept)''','''            Q2TypicalTrace.mark("reconciled",["kept":kept])
            consumed.append(contentsOf: kept)''')
edit('SmartDFlashCommand.swift','''                    let start = Date()''','''                    Q2TypicalTrace.reset(enabled:probe.id.hasPrefix("timed"))
                    Q2DiagnosticReads.reset(enabled:probe.id.hasPrefix("timed"))
                    let start = Date()''')
edit('SmartDFlashCommand.swift','''                    let after = ProcessMemory.vmActivity()''','''                    let after = ProcessMemory.vmActivity()
                    let trace=Q2TypicalTrace.take();Q2TypicalTrace.enabled=false
                    let readTrace=Q2DiagnosticReads.take()''')
edit('SmartDFlashCommand.swift','''rows.append(["id": probe.id,''','''rows.append(["trace":trace,"read_trace":readTrace,"id": probe.id,''')
for n,s in text.items():(P/Path(n).name).write_text(s)
try:
 for n,s in text.items():(R/n).write_text(s)
 result=build(R,P/'diagnostic-build',required_gb=10,jobs=4)
 print(json.dumps({k:v for k,v in result.items() if k in ['passed','error','elapsed_seconds']}),flush=True)
finally:
 for n,b in original.items():(R/n).write_bytes(b)
 (P/'restored.json').write_text(json.dumps({n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in original},indent=2))
if not result['passed']:raise SystemExit(1)
