from pathlib import Path
import json,collections,statistics
P=Path(__file__).resolve().parent
D=json.loads((P/'normal-native.json').read_text());result=[]
for width,name in [(3,'timed-3'),(4,'timed-2')]:
 r=next(r for r in D['runs']if r['id']==name);groups=collections.defaultdict(list)
 for e in r['trace']:groups[e['pass']].append(e)
 candidates=[];history=list(r['prompt_ids']);allcounts=[]
 for p,es in sorted(groups.items()):
  start=next((e for e in es if e['kind']=='verify_start'),None)
  end=next((e for e in es if e['kind']=='reconciled'),None)
  if not start:continue
  assert len(history)==start['position'],(p,len(history),start['position'])
  layers=[e for e in es if e['kind']=='ensure_start'];counts={e['layer']:len(e['misses'])for e in layers};allcounts.extend(counts.values())
  if len(start['tokens'])==width and p>=20 and end and len(layers)==48:
   candidates.append(dict(pass_id=p,position=start['position'],prompt_ids=history.copy(),output_ids=start['tokens'],miss_counts=counts,mean_misses=statistics.mean(counts.values()),source_request=name))
  if end:history.extend(end['kept'])
 target=statistics.mean(allcounts)
 candidate=min(candidates,key=lambda c:(abs(c['mean_misses']-target),c['pass_id']))
 (P/f'fixture-{width}.json').write_text(json.dumps(candidate,indent=2));result.append({k:v for k,v in candidate.items()if k not in ['prompt_ids','output_ids','miss_counts']})
print(json.dumps(result,indent=2))
