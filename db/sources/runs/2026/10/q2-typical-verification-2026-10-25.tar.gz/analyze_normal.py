from pathlib import Path
import json,csv,collections,statistics
P=Path(__file__).resolve().parent
D=json.loads((P/'normal-native.json').read_text())
commands=[{k:float(v) for k,v in r.items()} for r in csv.DictReader(l for l in next(P.glob('normal-commands*.csv')).open() if not l.startswith('#'))]
def union(xs):
 y=[]
 for a,b in sorted(xs):
  if b<=a:continue
  if y and a<=y[-1][1]:y[-1][1]=max(y[-1][1],b)
  else:y.append([a,b])
 return y
def duration(xs):return sum(b-a for a,b in union(xs))
def overlap(xs,ys):return duration([(max(a,c),min(b,d))for a,b in union(xs)for c,d in union(ys)if min(b,d)>max(a,c)])
results=[]
for req in D['runs']:
 if not req['id'].startswith('timed'):continue
 groups=collections.defaultdict(list)
 for e in req['trace']:groups[e['pass']].append(e)
 reads=req['read_trace'];passes=[];widths=collections.Counter();misses=collections.Counter();routes=collections.Counter()
 for p,es in groups.items():
  starts=[e for e in es if e['kind']=='verify_start'];ends=[e for e in es if e['kind']=='verified']
  if not starts or not ends:continue
  start,end=starts[0],ends[0];lo,hi=start['ns']/1e9,end['ns']/1e9;w=len(start['tokens']);widths[w]+=1
  g=[(max(lo,c['start']),min(hi,c['end']))for c in commands if c['end']>lo and c['start']<hi]
  active=[c for c in commands if c['end']>lo and c['start']<hi]
  rs=[(max(lo,r['start_ns']/1e9),min(hi,r['end_ns']/1e9)) for r in reads if 'read'in r['kind'] and r['end_ns']/1e9>lo and r['start_ns']/1e9<hi]
  cs=[(max(lo,r['start_ns']/1e9),min(hi,r['end_ns']/1e9)) for r in reads if 'copy'in r['kind'] and r['end_ns']/1e9>lo and r['start_ns']/1e9<hi]
  spans=collections.defaultdict(list);layers=collections.defaultdict(dict)
  for e in es:
   if 'layer'in e:layers[e['layer']][e['kind']]=e
  layerrows=[]
  for l,ev in layers.items():
   if 'ensure_start'not in ev:continue
   en=ev['ensure_start'];miss=len(en['misses']);misses[miss]+=1;routes[en['unique']]+=1
   row=dict(layer=l,miss=miss,unique=en['unique'])
   for name,a,b in [('route','route_start','route_ready'),('reserve','ensure_start','prepare_start'),('prepare','prepare_start','prepare_end'),('read_wait','prepare_end','reads_ready'),('publish','reads_ready','published'),('tail','published','layer_end')]:
    if a in ev and b in ev:
     span=(ev[a]['ns']/1e9,ev[b]['ns']/1e9);spans[name].append(span);row[name]=(span[1]-span[0])*1000
   layerrows.append(row)
  ms={k:duration(v)*1000 for k,v in spans.items()}
  for name in ['prepare','read_wait','route']:ms[name+'_without_gpu']=(duration(spans[name])-overlap(spans[name],g))*1000
  passes.append(dict(pass_id=p,width=w,ms=(hi-lo)*1000,gpu_interval_ms=duration(g)*1000,read_ms=duration(rs)*1000,copy_ms=duration(cs)*1000,read_gpu_overlap_ms=overlap(rs,g)*1000,neither_ms=((hi-lo)-duration(g+rs+cs))*1000,command_count=len(active),host_spans_ms=ms,layers=layerrows))
 vals={k:statistics.mean(p[k] for p in passes)for k in ['ms','gpu_interval_ms','read_ms','copy_ms','read_gpu_overlap_ms','neither_ms','command_count']}
 vals['host_spans_ms']={k:statistics.mean(p['host_spans_ms'].get(k,0)for p in passes)for k in passes[0]['host_spans_ms']}
 results.append(dict(id=req['id'],width_histogram=dict(widths),miss_histogram=dict(misses),unique_histogram=dict(routes),means=vals,passes=passes))
(P/'normal-analysis.json').write_text(json.dumps(results,indent=2))
print(json.dumps([{k:v for k,v in r.items()if k!='passes'}for r in results],indent=2))
