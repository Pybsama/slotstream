from pathlib import Path
import json,csv,collections,statistics
P=Path(__file__).resolve().parent;result=[]
for width,index in [(3,0),(3,3),(4,0),(4,3)]:
 label=f'matched-{width}-{index}-N';data=json.loads((P/(label+'.json')).read_text());cs=[{k:float(v)for k,v in r.items()}for r in csv.DictReader(l for l in next(P.glob(label+'-commands*.csv')).open()if not l.startswith('#'))]
 for r in data['runs']:
  if r['round']<2:continue
  layers=collections.defaultdict(dict)
  for e in r['trace']:layers[e['layer']][e['kind']]=e
  totals=collections.Counter();values=[]
  for c in cs:
   if not r['start_ns']/1e9<=c['submitted']<r['end_ns']/1e9:continue
   cat='other';l=-1
   for layer,ev in layers.items():
    if ev['prepare_start']['ns']/1e9<=c['submitted']<ev['prepare_end']['ns']/1e9:cat='expert';l=layer;break
    if ev['route_start']['ns']/1e9<=c['submitted']<ev['route_ready']['ns']/1e9:cat='route';l=layer;break
    prev=layers.get(layer-1)
    if prev and prev['published']['ns']/1e9<=c['submitted']<ev['route_start']['ns']/1e9:cat='attention';l=layer;break
   ms=(c['end']-c['start'])*1000;totals[cat]+=ms
   values.append(dict(category=cat,layer=l,ms=ms))
  result.append(dict(width=width,arm=index,condition=r['condition'],round=r['round'],totals=totals,commands=values))
(P/'command-attribution.json').write_text(json.dumps(result,indent=2))
for width in [3,4]:
 for cond in ['cached_off','partial_off','cached_on','partial_on']:
  rows=[r['totals']for r in result if r['width']==width and r['condition']==cond]
  print(width,cond,{k:round(statistics.median(r.get(k,0)for r in rows),3)for k in ['expert','attention','route','other']})
