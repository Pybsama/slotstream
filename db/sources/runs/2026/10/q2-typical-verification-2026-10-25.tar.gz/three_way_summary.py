import json,math,sys
from pathlib import Path
P=Path(__file__).resolve().parent;label='typical-copy-q2-15' if sys.argv[1]=='complete-q2-15' else sys.argv[1];out=P/(label+'-summary.json');assert not out.exists()
e=json.loads((P/(label+'-ledger.json')).read_text());complete=len(e)==6 and ''.join(x['arm']for x in e)=='ABCCBA'
eligible=complete and all(x.get('eligible') for x in e);tasks={}
for task in ['timed-2','timed-3']:
 arms={}
 for arm in 'ABC':
  rows=[r for x in e if x['arm']==arm for r in x['runs'] if r['id']==task];assert len(rows)==2
  arms[arm]={k:sum(r[k]for r in rows)/len(rows) for k in ['tps','request_seconds']}
 tasks[task]=dict(arms=arms,candidate_baseline_request_ratio=arms['B']['request_seconds']/arms['A']['request_seconds'],candidate_splash_request_ratio=arms['B']['request_seconds']/arms['C']['request_seconds'],candidate_splash_tps_ratio=arms['B']['tps']/arms['C']['tps'],baseline_splash_request_ratio=arms['A']['request_seconds']/arms['C']['request_seconds'],baseline_splash_tps_ratio=arms['A']['tps']/arms['C']['tps'])
geo=math.prod(x['candidate_baseline_request_ratio']for x in tasks.values())**.5
result=dict(complete_protocol=complete,all_arms_eligible=eligible,arms=[dict(label=x['label'],eligible=x.get('eligible'),process_paging=x.get('process_paging'),thermal_nominal=x.get('thermal_nominal'))for x in e],tasks=tasks,geometric_candidate_baseline_request_ratio=geo,candidate_gain=eligible and geo<=.98 and all(x['candidate_baseline_request_ratio']<=1 for x in tasks.values()),candidate_splash_parity=eligible and all(x['candidate_splash_request_ratio']<=1.05 and x['candidate_splash_tps_ratio']>=.95 for x in tasks.values()),baseline_splash_parity=eligible and all(x['baseline_splash_request_ratio']<=1.05 and x['baseline_splash_tps_ratio']>=.95 for x in tasks.values()),scope='Whole 6-arm matched protocol on this Mac and declared budget only. Excluded protocols establish no speed claim; no cherry-picked arm comparison.')
out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
