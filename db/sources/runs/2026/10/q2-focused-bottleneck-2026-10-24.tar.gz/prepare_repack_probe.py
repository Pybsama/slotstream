from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1]
s=(R/'Sources/Slotstream/NativeExpertSchedule.swift').read_text().split('private static func repackSource(hidden: Int, intermediate: Int) -> String {',1)[1].split('"""',2)[1]
s=s.replace(r'\(hidden)','2560').replace(r'\(intermediate)','640')
a=s.replace('native_repack_piece','original_piece').replace('native_repack','original_repack')
b=s.replace('native_repack_piece','parallel_piece').replace('native_repack','parallel_repack').replace('for(uint expert=position.y;expert<ready[1];expert+=4) {','uint expert=position.y;\n            if(expert<ready[1]) {')
(P/'repack-probe.metal').write_text('#include <metal_stdlib>\nusing namespace metal;\n'+a+b)
