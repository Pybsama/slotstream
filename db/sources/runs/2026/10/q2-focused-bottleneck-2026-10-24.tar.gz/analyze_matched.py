from pathlib import Path
import csv,json,statistics,hashlib,array,math
P=Path(__file__).resolve().parent
A=json.loads((P/'matched-ledger.json').read_text())
def union(xs):
 ys=[]
 for a,b in sorted(xs):
  if b<=a:continue
  if ys and a<=ys[-1][1]:ys[-1][1]=max(ys[-1][1],b)
  else:ys.append([a,b])
 return ys
def length(xs):return sum(b-a for a,b in union(xs))
def routes(r,arm):
 if arm=='N':return sorted((int(k),v) for k,vs in r['routes'].items() for v in vs)
 return sorted(set((x//512,x%512) for x in r['routes']))
route_ref=routes(A[1]['runs'][0],'S');assert len(route_ref)==1877
out={'arms':[], 'route_count':len(route_ref),'all_routes_exact':True}
for a in A:
 fs=list(P.glob(a['label']+'-commands*.csv'));assert len(fs)==1
 commands=[{k:float(v) for k,v in row.items()} for row in csv.DictReader(line for line in fs[0].open() if not line.startswith('#'))]
 rows=[]
 for r in a['runs']:
  if routes(r,a['arm'])!=route_ref:out['all_routes_exact']=False
  lo,hi=(r['start_ns']/1e9,r['end_ns']/1e9) if a['arm']=='N' else (r['start'],r['end'])
  cc=[c for c in commands if c['end']>lo and c['start']<hi]
  gpu=length([(max(lo,c['start']),min(hi,c['end'])) for c in cc])
  sub=length([(max(lo,c['submitted']),min(hi,c['start'])) for c in cc])
  row=dict(condition=r['condition'],round=r['round'],seconds=r['seconds'],command_intervals=gpu,without_command_interval=r['seconds']-gpu,submit_to_start_intervals=sub,commands=len(cc))
  if a['arm']=='S':row.update(preparation=r['prepared']-r['start'],submission=r['submitted']-r['prepared'],host_steps=r['host_seconds'],read_work=r['read_work_seconds'])
  rows.append(row)
 stats={}
 for condition in sorted(set(r['condition'] for r in rows)):
  rs=[r for r in rows if r['condition']==condition and r['round']>=2]
  stats[condition]={k:statistics.median(r[k] for r in rs) for k in rs[0] if k not in ['condition','round']}
 out['arms'].append(dict(label=a['label'],eligible=a['eligible'],peak_bytes=a['guard']['peak_combined_bytes'],conditions=stats,runs=rows))
print(json.dumps({**out,'arms':[{k:v for k,v in a.items() if k!='runs'}for a in out['arms']]},indent=2))
(P/'matched-analysis.json').write_text(json.dumps(out,indent=2)+'\n')
