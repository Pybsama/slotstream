from pathlib import Path
P=Path(__file__).resolve().parent;D=P/'upstream'
f=D/'include/model/RuntimeInstrumentation.hpp';s=f.read_text().replace('const engine::ModelBatchItem &item','const ModelBatchItem &item');f.write_text(s)
f=D/'Runtime.cpp';s=f.read_text().replace('const engine::ModelBatchItem &item','const ModelBatchItem &item');f.write_text(s)
f=D/'include/model/ExpertStore.hpp';s=f.read_text().replace('  void diagnosticClearResidency();','  void diagnosticClearResidency();\n  std::vector<uint64_t> diagnosticTakeRoutes();');f.write_text(s)
f=D/'ExpertStore.cpp';s=f.read_text().replace('  ExpertStoreStats counters;','  ExpertStoreStats counters;\n  std::vector<uint64_t> diagnosticRoutes;')
s=s.replace('      ++use.routed;','      ++use.routed;\n      diagnosticRoutes.push_back(uint64_t{index} * shape.experts + expert);')
s=s.replace('void ExpertStore::diagnosticClearResidency() {','std::vector<uint64_t> ExpertStore::diagnosticTakeRoutes() {\n  std::lock_guard lock(impl_->mutex); std::vector<uint64_t> result; result.swap(impl_->diagnosticRoutes); return result;\n}\nvoid ExpertStore::diagnosticClearResidency() {')
f.write_text(s)
f=D/'fixed_verify.mm';s=f.read_text().replace('          const auto before=store->stats().uses[1];','          (void)store->diagnosticTakeRoutes();\n          const auto before=store->stats().uses[1];')
s=s.replace('          std::ofstream file(path,std::ios::binary);file.write(reinterpret_cast<const char*>(logits.data()),logits.size_bytes());','''          if(round==2) { std::ofstream file(path,std::ios::binary);file.write(reinterpret_cast<const char*>(logits.data()),logits.size_bytes()); }
          std::printf("ROUTES %s %u",condition,round);
          for(auto id:store->diagnosticTakeRoutes()) std::printf(" %llu",(unsigned long long)id);
          std::printf("\\n");''')
f.write_text(s)
print('Upstream replay includes exact route identities and metadata-only reset')
