import ctypes,time,json
from pathlib import Path
lib=ctypes.CDLL('/usr/lib/libobjc.A.dylib')
ctypes.CDLL('/System/Library/Frameworks/Foundation.framework/Foundation')
lib.objc_getClass.argtypes=[ctypes.c_char_p];lib.objc_getClass.restype=ctypes.c_void_p
lib.sel_registerName.argtypes=[ctypes.c_char_p];lib.sel_registerName.restype=ctypes.c_void_p
send_object=ctypes.CFUNCTYPE(ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p)(('objc_msgSend',lib))
send_integer=ctypes.CFUNCTYPE(ctypes.c_long,ctypes.c_void_p,ctypes.c_void_p)(('objc_msgSend',lib))
def state():
 cls=lib.objc_getClass(b'NSProcessInfo');assert cls
 info=send_object(cls,lib.sel_registerName(b'processInfo'));assert info
 return send_integer(info,lib.sel_registerName(b'thermalState'))
def wait_nominal(log):
 start=time.monotonic();samples=[];streak=0
 while time.monotonic()-start<300:
  value=state();samples.append({'time':time.time(),'thermal_state':value});log.write_text(json.dumps(samples,indent=2))
  streak=streak+1 if value==0 else 0
  if streak>=3:return
  time.sleep(10)
 raise RuntimeError('thermal state did not settle within five minutes; no model launched')
if __name__=='__main__':print(state())
