from pathlib import Path
import hashlib,json,sys
P=Path(__file__).resolve().parent;R=P.parents[1]
sys.path.insert(0,str(R/'Tools'))
from optimization_build import build
paths=['Sources/slotstream-cli/Q2ProfileCommand.swift','Sources/Slotstream/ExpertStore.swift']
original={name:(R/name).read_bytes() for name in paths}
(P/'native-original-v2').mkdir(exist_ok=False)
for name,data in original.items():(P/'native-original-v2'/Path(name).name).write_bytes(data)
store=original[paths[1]].decode()
trace='''
package enum Q2DiagnosticReads {
    private static let lock=NSLock()
    private static var enabled=false
    private static var rows: [[String:Any]]=[]
    package static func reset(enabled:Bool) { lock.withLock { self.enabled=enabled; rows=[] } }
    package static func begin() -> UInt64 { enabled ? RuntimeClock.now() : 0 }
    package static func record(_ kind:String,_ start:UInt64,_ end:UInt64,_ bytes:Int) {
        guard start != 0 else { return }
        lock.withLock { rows.append(["kind":kind,"start_ns":start,"end_ns":end,"bytes":bytes]) }
    }
    package static func take() -> [[String:Any]] { lock.withLock { rows } }
}
'''
store=store.replace('public struct PackedLayoutReport:',trace+'\npublic struct PackedLayoutReport:',1)
start='''            let payload: UnsafeRawPointer
            if usePackedLayout'''
assert store.count(start)==1
store=store.replace(start,'''            let traceStart=Q2DiagnosticReads.begin()
            let payload: UnsafeRawPointer
            if usePackedLayout''')
old='''            guard shouldContinue() else { throw CheckpointReadError.cancelled }
            if rawCopy { memcpy(destination, payload, bytes) }
            else { repackPieceCPU(payload, into: destination, piece: piece) }
            return'''
new='''            let traceReadEnd=Q2DiagnosticReads.begin()
            guard shouldContinue() else { throw CheckpointReadError.cancelled }
            if rawCopy { memcpy(destination, payload, bytes) }
            else { repackPieceCPU(payload, into: destination, piece: piece) }
            let traceCopyEnd=Q2DiagnosticReads.begin()
            Q2DiagnosticReads.record("forecast_read",traceStart,traceReadEnd,bytes)
            Q2DiagnosticReads.record("forecast_copy",traceReadEnd,traceCopyEnd,bytes)
            return'''
assert store.count(old)==1;store=store.replace(old,new)
old='''                    let payload = try handle.readPageAlignedChecked(into: buffer, capacity: scratch.bytes,
                        offset: key.expert * bytes, count: bytes)
                    copyPiece(payload, bases[piece] + slots[record] * bytes, piece)'''
new='''                    let traceStart=Q2DiagnosticReads.begin()
                    let payload = try handle.readPageAlignedChecked(into: buffer, capacity: scratch.bytes,
                        offset: key.expert * bytes, count: bytes)
                    let traceReadEnd=Q2DiagnosticReads.begin()
                    copyPiece(payload, bases[piece] + slots[record] * bytes, piece)
                    let traceCopyEnd=Q2DiagnosticReads.begin()
                    Q2DiagnosticReads.record("demand_read",traceStart,traceReadEnd,bytes)
                    Q2DiagnosticReads.record("demand_copy",traceReadEnd,traceCopyEnd,bytes)'''
assert store.count(old)==1;store=store.replace(old,new)
(P/'ExpertStore.swift').write_text(store)
try:
    (R/paths[0]).write_bytes((P/'Q2ProfileCommand.swift').read_bytes())
    (R/paths[1]).write_text(store)
    result=build(R,P/'native-matched',required_gb=10,jobs=4)
    print(json.dumps({k:v for k,v in result.items() if k in ['passed','error','elapsed_seconds']}),flush=True)
finally:
    for name,data in original.items():(R/name).write_bytes(data)
    (P/'native-restored-v2.json').write_text(json.dumps({name:hashlib.sha256((R/name).read_bytes()).hexdigest() for name in paths},indent=2)+'\n')
if not result['passed']:raise SystemExit(1)
