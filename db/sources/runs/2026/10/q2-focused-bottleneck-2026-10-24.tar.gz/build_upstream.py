from pathlib import Path
import subprocess,sys,fcntl,os,json,hashlib,shutil
P=Path(__file__).resolve().parent;R=P.parents[1];D=P/'upstream'
W=Path('/var/folders/d4/t1c8ltbx5s3_11cs9y6gjh8m0000gp/T/slotstream-splash-host-ugnf26pi/source')
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
assert 'kHostStepSpin = std::chrono::milliseconds(0)' in (W/'runtime/metal/MetalBackend.mm').read_text()
commands=[]
preflight(10)
with open(f'/tmp/slotstream-model-{os.getuid()}.lock','a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 common=['xcrun','-sdk','macosx','clang++','-std=c++20','-O2','-mmacosx-version-min=26.4','-I'+str(D/'include'),'-I'+str(W/'runtime'),'-I'+str(W/'dev')]
 for name in ['Runtime','ExpertStore']:
  command=common+['-DSPLASH_RUNTIME_INSTRUMENTATION','-c',str(D/(name+'.cpp')),'-o',str(D/(name+'.o'))]
  with(D/(name+'-build.log')).open('w')as f:r=subprocess.run(command,cwd=W,stdout=f,stderr=subprocess.STDOUT)
  commands.append(dict(command=command,exit_code=r.returncode));(D/'build-ledger.json').write_text(json.dumps(commands,indent=2)+'\n')
  if r.returncode:raise SystemExit(r.returncode)
 command=common+['-fobjc-arc',str(D/'fixed_verify.mm'),str(D/'Runtime.o'),str(D/'ExpertStore.o'),str(W/'build/engine/metal/MetalBackendInstrumented.o'),str(W/'build/engine/libsplash.a'),'-framework','Foundation','-framework','Metal','-framework','IOKit','-framework','IOSurface','-o',str(D/'fixed-verify')]
 with(D/'link-build.log').open('w')as f:r=subprocess.run(command,cwd=W,stdout=f,stderr=subprocess.STDOUT)
 commands.append(dict(command=command,exit_code=r.returncode));(D/'build-ledger.json').write_text(json.dumps(commands,indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
 shutil.copyfile(R/'.build/smart-dflash-eval/upstream/splash-1.4.0-arm64-macos26/engine/splash.metallib',D/'splash.metallib')
 files=[p for p in D.rglob('*') if p.is_file() and p.suffix not in ['.json','.log']]
 (D/'identity.json').write_text(json.dumps({str(p.relative_to(D)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2)+'\n')
print('Built isolated target-only upstream diagnostic')
