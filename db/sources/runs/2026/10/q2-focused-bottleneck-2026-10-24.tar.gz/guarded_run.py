import argparse,ctypes,hashlib,json,os,subprocess,sys,time,fcntl
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight,vm_snapshot,terminate_child_tree,host_conditions
sys.path.insert(0,str(R/'.build/native-q2-20261021'));from thermal import state
ap=argparse.ArgumentParser();ap.add_argument('--fused-gdn',action='store_true');ap.add_argument('--label',required=True);ap.add_argument('--budget',type=float,default=10);ap.add_argument('--timeout',type=float,default=1800);ap.add_argument('command',nargs=argparse.REMAINDER);ap.add_argument('--env',action='append',default=[]);a=ap.parse_args();command=a.command
if command[0]=='--':command=command[1:]
assert command and not(P/(a.label+'.observer.json')).exists()
class U(ctypes.Structure):
 _fields_=[('uuid',ctypes.c_uint8*16)]+[(n,ctypes.c_uint64)for n in ('user_time','system_time','pkg_idle_wkups','interrupt_wkups','pageins','wired_size','resident_size','phys_footprint','proc_start_abstime','proc_exit_abstime','child_user_time','child_system_time','child_pkg_idle_wkups','child_interrupt_wkups','child_pageins','child_elapsed_abstime','diskio_bytesread','diskio_byteswritten')]
lib=ctypes.CDLL('/usr/lib/libproc.dylib');lib.proc_pid_rusage.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.c_void_p];lib.proc_pid_rusage.restype=ctypes.c_int
receipt={'command':command,'before':preflight(a.budget+3),'thermal_before':state(),'host':host_conditions(),'budget':a.budget,'peak_combined_bytes':0,'samples':[],'complete':False}
receipt['binary_sha256']=hashlib.sha256(Path(command[0]).read_bytes()).hexdigest()
env={k:v for k,v in os.environ.items() if not k.startswith(('SLOTSTREAM_','MLX_'))}
env.update(dict(item.split('=',1) for item in a.env))
if a.fused_gdn:env['SLOTSTREAM_OPT_GDN_RECORD']='1'
receipt['fused_gdn']=a.fused_gdn
receipt['environment_overrides']=dict(item.split('=',1) for item in a.env)
owned_lock=None
if Path(command[0]).name in ['fixed-verify','repack-probe']:
 owned_lock=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(owned_lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
start=time.monotonic()
with (P/(a.label+'.log')).open('x') as log:
 child=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True)
 try:
  while child.poll() is None:
   total=0
   children=subprocess.run(['pgrep','-P',str(child.pid)],capture_output=True,text=True)
   for pid in [child.pid,*map(int,children.stdout.split())]:
    u=U()
    if lib.proc_pid_rusage(pid,2,ctypes.byref(u))==0:total+=u.phys_footprint
   now=time.monotonic();vm=vm_snapshot();receipt['peak_combined_bytes']=max(receipt['peak_combined_bytes'],total)
   receipt['samples'].append({'seconds':now-start,'footprint':total,'reclaimable':vm['reclaimable_bytes']})
   if total>a.budget*1e9:raise RuntimeError('Physical ceiling exceeded')
   if vm['reclaimable_bytes']<1e9:raise RuntimeError('Headroom below one GB')
   if now-start>a.timeout:raise RuntimeError('Bounded timeout')
   time.sleep(.5)
  receipt['exit_code']=child.returncode;receipt['complete']=child.returncode==0
 except Exception as e:receipt['error']=str(e)
 finally:
  if child.poll() is None:terminate_child_tree(child)
  receipt['after']=vm_snapshot();receipt['thermal_after']=state();receipt['seconds']=time.monotonic()-start
  receipt['paging']=any(receipt['after'][k]!=receipt['before'][k]for k in ['swapins','swapouts'])
  (P/(a.label+'.observer.json')).write_text(json.dumps(receipt,indent=2))
print({k:v for k,v in receipt.items()if k not in ['samples','host','before','after','command']},flush=True)
raise SystemExit(0 if receipt['complete'] else 1)
