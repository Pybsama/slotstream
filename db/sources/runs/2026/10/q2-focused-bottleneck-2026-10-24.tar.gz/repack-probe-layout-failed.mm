#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#include "metal/abi/MoE.h"
#include "metal/abi/QuantFormat.h"
int main(int argc,const char **argv){@autoreleasepool {
 if(argc!=3)return 2;
 auto device=MTLCreateSystemDefaultDevice();NSError *error=nil;
 auto options=[MTLCompileOptions new];options.mathMode=MTLMathModeFast;
 auto library=[device newLibraryWithSource:[NSString stringWithContentsOfFile:@(argv[1]) encoding:NSUTF8StringEncoding error:&error] options:options error:&error];
 if(!library){fprintf(stderr,"%s\n",error.description.UTF8String);return 3;}
 auto splash=[device newLibraryWithFile:@(argv[2]) error:&error];
 if(!splash){fprintf(stderr,"%s\n",error.description.UTF8String);return 4;}
 std::vector<id<MTLComputePipelineState>> pipes;
 for(auto name:{@"original_repack",@"parallel_repack",@"moe_expert_load"}){
  auto f=[(name==@"moe_expert_load"?splash:library) newFunctionWithName:name];
  auto p=[device newComputePipelineStateWithFunction:f error:&error];
  if(!p){fprintf(stderr,"%s\n",error.description.UTF8String);return 5;}pipes.push_back(p);
 }
 const size_t piece=2560*640/64*18,capacity=80,slots=256;
 auto buffer=[&](size_t n){return [device newBufferWithLength:n options:MTLResourceStorageModeShared];};
 auto raw=buffer(3*piece*capacity),forecast=buffer(3*piece*capacity);
 auto packed=buffer(3*piece*slots),gold=buffer(3*piece*slots);
 auto dest=buffer(capacity*4),mask=buffer(capacity*4),ready=buffer(8),source=buffer(capacity*4),splashsource=buffer(capacity*3*8);
 for(size_t i=0;i<raw.length;++i)((uint8_t*)raw.contents)[i]=uint8_t((i*31+i/17)%251);
 memcpy(forecast.contents,raw.contents,raw.length);
 for(size_t i=0;i<capacity;++i){((int*)dest.contents)[i]=int((i*13)%slots);((int*)source.contents)[i]=int(i);}
 ((uint32_t*)ready.contents)[0]=1;
 MoeExpertLoadParams p{};
 for(int z=0;z<3;++z){auto &q=p.projections[z];q.format=GGUF_FMT_Q20;q.rows=z==2?2560:640;q.columns=z==2?640:2560;q.row_bytes=q.columns/64*18;q.planes[0]=z*slots*piece;q.planes[1]=q.planes[0];q.planes[2]=q.planes[0]+409600;q.slot_bytes[0]=q.slot_bytes[1]=q.slot_bytes[2]=piece;}
 auto queue=[device newCommandQueue];
 for(int n:{1,10,40,64,80})for(int mode:{0,1}) {
  ((uint32_t*)ready.contents)[1]=n;
  for(int i=0;i<n;++i){((int*)mask.contents)[i]=mode&&i%2?2:1;for(int z=0;z<3;++z)((uint64_t*)splashsource.contents)[i*3+z]=z*capacity*piece+i*piece;}
  auto submit=[&](int variant,int repeat){
   auto cmd=[queue commandBuffer];auto enc=[cmd computeCommandEncoder];[enc setComputePipelineState:pipes[variant]];
   if(variant<2){
    for(int z=0;z<3;++z){[enc setBuffer:raw offset:z*capacity*piece atIndex:z];[enc setBuffer:packed offset:z*slots*piece atIndex:3+z];[enc setBuffer:forecast offset:z*capacity*piece atIndex:9+z];}
    [enc setBuffer:dest offset:0 atIndex:6];[enc setBuffer:mask offset:0 atIndex:7];[enc setBuffer:ready offset:0 atIndex:8];[enc setBuffer:source offset:0 atIndex:12];
   }else{[enc setBuffer:raw offset:0 atIndex:0];[enc setBuffer:packed offset:0 atIndex:1];[enc setBuffer:dest offset:0 atIndex:2];[enc setBuffer:splashsource offset:0 atIndex:3];[enc setBytes:&p length:sizeof(p) atIndex:4];}
   for(int j=0;j<repeat;++j){
    if(variant<2)[enc dispatchThreads:MTLSizeMake(2560*640/64,variant==0?4:n,3) threadsPerThreadgroup:MTLSizeMake(256,1,1)];
    else [enc dispatchThreadgroups:MTLSizeMake(2560*640/32/256,n,3) threadsPerThreadgroup:MTLSizeMake(256,1,1)];
   }
   [enc endEncoding];[cmd commit];[cmd waitUntilCompleted];
   if(cmd.status!=MTLCommandBufferStatusCompleted)throw 9;
   return cmd.GPUEndTime-cmd.GPUStartTime;
  };
  memset(packed.contents,0xA5,packed.length);submit(0,1);memcpy(gold.contents,packed.contents,packed.length);
  for(int v=1;v<3;++v){memset(packed.contents,0xA5,packed.length);submit(v,1);if(memcmp(packed.contents,gold.contents,packed.length)){fprintf(stderr,"MISMATCH n=%d mode=%d variant=%d\n",n,mode,v);return 10;}}
  printf("EXACT n=%d forecast=%d bytes=%lu\n",n,mode,(unsigned long)packed.length);
  for(int round=0;round<10;++round)for(int step=0;step<3;++step){int v=round%2?2-step:step;double t=submit(v,8);printf("TIME n=%d forecast=%d round=%d variant=%d seconds=%.9f repetitions=8\n",n,mode,round,v,t);}
  fflush(stdout);
 }
 return 0;
}}
