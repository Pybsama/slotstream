#include <metal_stdlib>
using namespace metal;
template<uint N,uint K>
        inline void original_piece(device const uchar* raw, device uchar* packed,
            device const int* slots, device const int* filled, device const uint* ready,
            device const uchar* forecast, device const int* sources, uint2 position) {
            uint i=position.x;
            if(i>=N*K/64 || ready[0]!=1)return;
            for(uint expert=position.y;expert<ready[1];expert+=4) {
                if(filled[expert]==0)continue;
                bool predicted=filled[expert]==2;
                device const uchar* input=predicted?forecast:raw;
                uint row=i/(K/64), block=i%(K/64);
                size_t source=size_t(predicted?sources[expert]:expert)*N*K/64*18+size_t(i)*18;
                size_t base=size_t(slots[expert])*N*K/64*18;
                for(uint part=0;part<2;++part) {
                    size_t to=base+((size_t(row/64)*(K/32)+2*block+part)*64+row%64)*8;
                    for(uint b=0;b<8;++b)packed[to+b]=input[source+2+part*8+b];
                }
                size_t scale=base+N*K/4+((size_t(row/64)*(K/64)+block)*64+row%64)*2;
                packed[scale]=input[source];packed[scale+1]=input[source+1];
            }
        }
        kernel void original_repack(device const uchar* raw_gate [[buffer(0)]],
            device const uchar* raw_up [[buffer(1)]], device const uchar* raw_down [[buffer(2)]],
            device uchar* packed_gate [[buffer(3)]], device uchar* packed_up [[buffer(4)]],
            device uchar* packed_down [[buffer(5)]], device const int* slots [[buffer(6)]],
            device const int* filled [[buffer(7)]], device const uint* ready [[buffer(8)]],
            device const uchar* forecast_gate [[buffer(9)]], device const uchar* forecast_up [[buffer(10)]],
            device const uchar* forecast_down [[buffer(11)]], device const int* sources [[buffer(12)]],
            uint3 position [[thread_position_in_grid]]) {
            // Each piece has the same element count. Specialize its dimensions
            // so combining the grids does not introduce dynamic integer division.
            uint piece=position.z;
            if(piece==2) {
                original_piece<2560,640>(raw_down,packed_down,
                    slots,filled,ready,forecast_down,sources,position.xy);
            } else {
                original_piece<640,2560>(piece==0?raw_gate:raw_up,
                    piece==0?packed_gate:packed_up,slots,filled,ready,
                    piece==0?forecast_gate:forecast_up,sources,position.xy);
            }
        }

        
        template<uint N,uint K>
        inline void parallel_piece(device const uchar* raw, device uchar* packed,
            device const int* slots, device const int* filled, device const uint* ready,
            device const uchar* forecast, device const int* sources, uint2 position) {
            uint i=position.x;
            if(i>=N*K/64 || ready[0]!=1)return;
            uint expert=position.y;
            if(expert<ready[1]) {
                if(filled[expert]==0)return;
                bool predicted=filled[expert]==2;
                device const uchar* input=predicted?forecast:raw;
                uint row=i/(K/64), block=i%(K/64);
                size_t source=size_t(predicted?sources[expert]:expert)*N*K/64*18+size_t(i)*18;
                size_t base=size_t(slots[expert])*N*K/64*18;
                for(uint part=0;part<2;++part) {
                    size_t to=base+((size_t(row/64)*(K/32)+2*block+part)*64+row%64)*8;
                    for(uint b=0;b<8;++b)packed[to+b]=input[source+2+part*8+b];
                }
                size_t scale=base+N*K/4+((size_t(row/64)*(K/64)+block)*64+row%64)*2;
                packed[scale]=input[source];packed[scale+1]=input[source+1];
            }
        }
        kernel void parallel_repack(device const uchar* raw_gate [[buffer(0)]],
            device const uchar* raw_up [[buffer(1)]], device const uchar* raw_down [[buffer(2)]],
            device uchar* packed_gate [[buffer(3)]], device uchar* packed_up [[buffer(4)]],
            device uchar* packed_down [[buffer(5)]], device const int* slots [[buffer(6)]],
            device const int* filled [[buffer(7)]], device const uint* ready [[buffer(8)]],
            device const uchar* forecast_gate [[buffer(9)]], device const uchar* forecast_up [[buffer(10)]],
            device const uchar* forecast_down [[buffer(11)]], device const int* sources [[buffer(12)]],
            uint3 position [[thread_position_in_grid]]) {
            // Each piece has the same element count. Specialize its dimensions
            // so combining the grids does not introduce dynamic integer division.
            uint piece=position.z;
            if(piece==2) {
                parallel_piece<2560,640>(raw_down,packed_down,
                    slots,filled,ready,forecast_down,sources,position.xy);
            } else {
                parallel_piece<640,2560>(piece==0?raw_gate:raw_up,
                    piece==0?packed_gate:packed_up,slots,filled,ready,
                    piece==0?forecast_gate:forecast_up,sources,position.xy);
            }
        }

        