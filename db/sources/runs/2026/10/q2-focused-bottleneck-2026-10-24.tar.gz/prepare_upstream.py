from pathlib import Path
import json, hashlib
P=Path(__file__).resolve().parent
W=Path('/var/folders/d4/t1c8ltbx5s3_11cs9y6gjh8m0000gp/T/slotstream-splash-host-ugnf26pi/source')
old=P.parent/'native-replay-20261023'
D=P/'upstream'; D.mkdir(exist_ok=True); (D/'include/model').mkdir(parents=True,exist_ok=True)
header=(W/'runtime/model/RuntimeInstrumentation.hpp').read_text()
header=header.replace('public:\n','''public:
  struct FixedTiming { double start, prepared, submitted, ended, gpu, host; };
  static FixedTiming fixedVerify(Runtime &runtime, const engine::ModelBatchItem &item, std::span<const uint32_t> tokens);
''',1)
(D/'include/model/RuntimeInstrumentation.hpp').write_text(header)
source=(W/'runtime/model/Runtime.cpp').read_text()
method=r'''
#ifdef SPLASH_RUNTIME_INSTRUMENTATION
RuntimeInstrumentation::FixedTiming RuntimeInstrumentation::fixedVerify(Runtime &runtime,
    const engine::ModelBatchItem &item, std::span<const uint32_t> tokens) {
  if(tokens.size()!=8) throw std::invalid_argument("fixed target requires eight rows");
  auto now=[] {return double(AwakeClock::now().time_since_epoch().count())/1e9;};
  FixedTiming out{}; out.start=now();
  auto &impl=*runtime.impl_;
  auto &entry=impl.request(item.requestId);
  auto anchor=entry.pendingToken;
  entry.pendingToken=tokens[0];
  impl.prepareDecodeLane(entry,item,0);
  entry.pendingToken=anchor;
  auto d=[&](DecodeTensor t) {return impl.decodeArena->batchSlice(t,1);};
  std::copy(tokens.begin()+1,tokens.end(),contents<uint32_t>(d(DecodeTensor::ProposedTokens),"fixed proposals"));
  *contents<uint32_t>(d(DecodeTensor::VerifyRows),"fixed rows")=8;
  Runtime::Impl::Request *request=&entry;
  std::span<Runtime::Impl::Request *const> entries(&request,1);
  std::span<const ModelBatchItem> items(&item,1);
  auto reads=impl.decodeReads(items);
  CommandGraph graph;
  impl.addRopeTables(graph,d(DecodeTensor::Positions),8,d(DecodeTensor::DraftPositions),0,
      d(DecodeTensor::RopeCos),d(DecodeTensor::RopeSin),d(DecodeTensor::DraftRopeCos),d(DecodeTensor::DraftRopeSin));
  impl.encodeBatchVerifyInput(graph,1);
  impl.encodeBatchEmbedding(graph,DecodeTensor::InputTokens,DecodeTensor::Hidden0,1);
  impl.encodeTargetVerifyBatchForward(graph,entries,items,*reads);
  out.prepared=now();
  auto ticket=impl.backend.submitCommandAsync(graph.command());
  out.submitted=now();
  auto timing=ticket.wait(); out.ended=now();
  out.gpu=timing.gpuSeconds; out.host=timing.hostSeconds;
  // No acceptance/commit, sampling or draft forward. Prefix current state stays unchanged.
  return out;
}
#endif
'''
pos=source.rfind('} // namespace splash::model'); assert pos!=-1
source=source[:pos]+method+source[pos:]
(D/'Runtime.cpp').write_text(source)
header=(W/'runtime/model/ExpertStore.hpp').read_text().replace('  ~ExpertStore() override;','  ~ExpertStore() override;\n  void diagnosticClearResidency();')
(D/'include/model/ExpertStore.hpp').write_text(header)
source=(W/'runtime/model/ExpertStore.cpp').read_text()
method=r'''
void ExpertStore::diagnosticClearResidency() {
  std::lock_guard lock(impl_->mutex); Impl &impl=*impl_;
  if(impl.released) throw std::logic_error("diagnostic reset requires resident storage");
  impl.retireAhead(); impl.ahead.block=impl.plan.block=kNoSlot;
  for(auto &block:impl.blocks) {
    if(!impl.sizes[block.size].streams) throw std::logic_error("diagnostic reset requires streamed blocks");
    std::ranges::fill(block.slot,kNoSlot);
  }
  std::memset(impl.tables.contents(),0,impl.tables.sizeBytes());
  for(auto &size:impl.sizes) {
    std::ranges::fill(size.ownerBlock,kNoSlot); std::ranges::fill(size.ownerExpert,kNoSlot);
    size.recycling.reset();
  }
  impl.counters.resident=0; impl.publish();
}
'''
pos=source.rfind('} // namespace splash::model');source=source[:pos]+method+source[pos:]
(D/'ExpertStore.cpp').write_text(source)
source=(old/'splash-q2-target-profile/decode_profile.mm').read_text()
source=source.replace('#include "model/Runtime.hpp"','#include "model/Runtime.hpp"\n#include "model/RuntimeInstrumentation.hpp"\n#include "model/ExpertStore.hpp"\n#include <fstream>\n#include <cmath>')
source=source.replace('backend, 15000000000ULL, 1, 1,','backend, 12000000000ULL, 1, 1,')
start=source.index('      // Warm prefill and B1 decode')
end=source.index('      return 0;',start)
fixture=json.loads((old/'v29-profile-smart-q2-fixture.json').read_text())
body=r'''
      prefill(executor,lanes[0],prompt);
      const std::vector<uint32_t> tokens={TOKENS};
      ModelBatchItem item{lanes[0].id,lanes[0].position,0,lanes[0].pages,lanes[0].pageTableRevision};
      auto *store=model.expertStore(); if(!store) throw std::runtime_error("missing expert store");
      const auto storeStats=store->stats();
      std::printf("CONFIG slots=%llu arena=%llu staging=%llu\n",(unsigned long long)storeStats.slots,
        (unsigned long long)storeStats.arenaBytes,(unsigned long long)storeStats.stagingBytes);
      std::vector<float> reference;
      for(const char *condition: {"cached","miss"}) {
        for(uint32_t round=0;round<5;++round) {
          if(std::string(condition)=="miss") store->diagnosticClearResidency();
          const auto before=store->stats().uses[1];
          const auto timing=model::RuntimeInstrumentation::fixedVerify(executor,item,tokens);
          const auto after=store->stats().uses[1];
          const auto logits=model::RuntimeInstrumentation::lastLogits(executor,0);
          if(reference.empty()) reference.assign(logits.begin(),logits.end());
          double maxDiff=0;for(size_t i=0;i<logits.size();++i) maxDiff=std::max(maxDiff,double(std::abs(logits[i]-reference[i])));
          if(maxDiff!=0) throw std::runtime_error("fixed verify recurrent state or cache changed logits");
          const std::string path=dispatchList+"-"+condition+"-"+std::to_string(round)+".f32";
          std::ofstream file(path,std::ios::binary);file.write(reinterpret_cast<const char*>(logits.data()),logits.size_bytes());
          std::printf("ROW %s %u %.9f %.9f %.9f %.9f %.9f %.9f %llu %llu %llu %.9f %.9f %.9f %.9f\n",
            condition,round,timing.start,timing.prepared,timing.submitted,timing.ended,timing.gpu,timing.host,
            (unsigned long long)(after.read-before.read),(unsigned long long)(after.prefetched-before.prefetched),
            (unsigned long long)(after.readBytes-before.readBytes),
            (after.pickup.totalMilliseconds-before.pickup.totalMilliseconds)/1000,
            (after.work.totalMilliseconds-before.work.totalMilliseconds)/1000,
            (after.resume.totalMilliseconds-before.resume.totalMilliseconds)/1000,maxDiff);
          std::fflush(stdout);
        }
      }
      executor.end(lanes[0].id);
'''.replace('TOKENS',','.join(map(str,fixture['output_ids'][:8])))
source=source[:start]+body+source[end:]
(D/'fixed_verify.mm').write_text(source)
manifest={str(f.relative_to(D)):hashlib.sha256(f.read_bytes()).hexdigest() for f in D.rglob('*') if f.is_file()}
(D/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Prepared isolated upstream diagnostic sources',len(manifest))
