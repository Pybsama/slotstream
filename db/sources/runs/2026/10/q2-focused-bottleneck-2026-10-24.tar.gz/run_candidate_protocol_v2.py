from pathlib import Path
import subprocess,json,time,sys
P=Path(__file__).resolve().parent;R=P.parents[1];OLD=P.parent/'native-replay-20261023'
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight,vm_snapshot
manifest=P/'candidate-build/manifest.json'
start=time.monotonic()
while not manifest.exists():
 if time.monotonic()-start>600:raise RuntimeError('Build wait exceeded')
 time.sleep(2)
assert json.loads(manifest.read_text())['passed']
for name,command in [('correctness-v2',[sys.executable,str(P/'validate_candidate_v2.py')])]:
 print('START',name,flush=True)
 with(P/(name+'-protocol.log')).open('x')as f:r=subprocess.run(command,cwd=R,stdout=f,stderr=subprocess.STDOUT)
 print('END',name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
state=vm_snapshot();budget=15 if state['reclaimable_bytes']>=18e9 else 12
preflight(budget+3)
(P/'complete-budget.json').write_text(json.dumps(dict(budget_gb=budget,preflight=state),indent=2)+'\n')
label=f'complete-q2-{budget}'
command=[sys.executable,str(P/'complete_requests.py'),'--label',label,'--native',str(P/'candidate-build/candidate/slotstream'),'--baseline',str(OLD/'v68/slotstream'),'--model','smart-q2','--budget',str(budget),'--cases',str(OLD/'short-warm-384-cases.json')]
print('START complete requests',budget,flush=True)
with(P/'complete-driver.log').open('x')as f:r=subprocess.run(command,cwd=R,stdout=f,stderr=subprocess.STDOUT)
print('END complete requests',r.returncode,flush=True)
if r.returncode:raise SystemExit(r.returncode)
r=subprocess.run([sys.executable,str(P/'three_way_summary.py'),label],cwd=R)
raise SystemExit(r.returncode)
