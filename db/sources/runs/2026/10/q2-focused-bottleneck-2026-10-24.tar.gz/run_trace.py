from pathlib import Path
import sys,json,subprocess,os,fcntl,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1];old=P.parent/'native-replay-20261023'
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight,vm_snapshot,terminate_child_tree
sys.path.insert(0,str(R/'.build/native-q2-20261021'));from thermal import state,wait_nominal
fixture=old/'v29-profile-smart-q2-fixture.json'
model=R/'.build/smart-dflash-eval/upstream-prepared/.resolved/938d6d6879dac79e95a5eae858867e0af230dc252a18266c6aefb6732b65dee7'
observer=old/'metal_command_observer_mrc.dylib'
assert not(P/'trace-ledger.json').exists()
records=[];slots=None
for index,arm in enumerate('NS'):
 label=f'trace-{index}-{arm}'
 wait_nominal(P/(label+'-cooldown.json'));before=preflight(15);assert state()==0
 out=P/(label+'.json')
 if arm=='N':
  command=[str(P/'native-matched/candidate/slotstream'),'q2-profile','--fixture',str(fixture),'--output',str(out),'--memory-gb','12','--trace-reads']
 else:
  assert slots
  expert_memory=3*(slots*409600+((slots*51200+16383)//16384)*16384)+471859200+98304+14336+16+32*(512+22)*4
  command=[str(P/'upstream/fixed-verify'),str(P/'upstream/splash.metallib'),str(model),'--prompt-tokens',str(len(json.loads(fixture.read_text())['prompt_ids'])),'--cycles','3','--kv-format','bf16','--state-format','fp32','--expert-memory',str(expert_memory),'--ple-memory','51200000','--dispatch-list',str(P/label)]
 env=['--env','DYLD_INSERT_LIBRARIES='+str(observer),'--env','SLOTSTREAM_METAL_OBSERVER='+str(P/(label+'-commands'))]
 if arm=='S': env += ['--env','Q2_DIAGNOSTIC_READS=1']
 full=[sys.executable,str(P/'guarded_run.py'),'--label',label,'--budget','12','--timeout','600',*env,'--',*command]
 lock=None
 print('START',label,flush=True)
 with(P/(label+'-launcher.log')).open('x') as f:
  child=subprocess.Popen(full,cwd=R,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  try:rc=child.wait(timeout=660)
  finally:
   if child.poll() is None:terminate_child_tree(child)
 if lock:lock.close()
 after=vm_snapshot();guard=json.loads((P/(label+'.observer.json')).read_text())
 row=dict(label=label,arm=arm,command=full,exit_code=rc,before=before,after=after,guard=guard)
 if rc==0:
  if arm=='N':
   result=json.loads(out.read_text());observed=result['plan']['pool_slots']
   if slots is not None:assert slots==observed
   slots=observed
   row['runs']=result['runs']
  else:
   rows=[];routes={};observed=None
   for line in (P/(label+'.log')).read_text().splitlines():
    if line.startswith('CONFIG '):observed=int(dict(s.split('=',1) for s in line.split()[1:])['slots'])
    if line.startswith('ROUTES '):
     x=line.split();routes[(x[1],int(x[2]))]=list(map(int,x[3:]))
    if not line.startswith('ROW '):continue
    x=line.split();v=list(map(float,x[3:]))
    keys=['start','prepared','submitted','end','gpu_seconds','host_seconds','records_read','records_prefetched','read_bytes','pickup_seconds','read_work_seconds','resume_seconds','max_logit_difference']
    r=dict(zip(keys,v));r.update(condition=x[1],round=int(x[2]));r['seconds']=r['end']-r['start'];r['routes']=routes[(x[1],int(x[2]))];rows.append(r)
   assert observed==slots,(observed,slots)
   assert len(rows)==20
   result=dict(slots=slots,expert_memory=expert_memory,runs=rows)
   out.write_text(json.dumps(result,indent=2)+'\n');row['runs']=rows
  row['eligible']=not guard['paging'] and guard['thermal_before']==guard['thermal_after']==0 and guard['peak_combined_bytes']<=12e9
  for r in row['runs']:
   if r['condition'].startswith('cached') and r['round']>=2:
    assert r.get('records_fetched',r.get('records_read',-1))==0,r
 records.append(row);(P/'trace-ledger.json').write_text(json.dumps(records,indent=2)+'\n')
 print('END',label,'rc',rc,'eligible',row.get('eligible'),flush=True)
 if rc:raise SystemExit(rc)
print('Complete matched diagnostic protocol',flush=True)
