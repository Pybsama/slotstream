from pathlib import Path
import csv,json,statistics,collections
P=Path(__file__).resolve().parent
A=json.loads((P/'trace-ledger.json').read_text())
def union(xs):
 ys=[]
 for a,b in sorted(xs):
  if b<=a:continue
  if ys and a<=ys[-1][1]:ys[-1][1]=max(ys[-1][1],b)
  else:ys.append([a,b])
 return ys
def length(xs):return sum(b-a for a,b in union(xs))
def intersection(x,y):return length([(max(a,c),min(b,d)) for a,b in union(x) for c,d in union(y) if min(b,d)>max(a,c)])
out=[]
for a in A:
 commands=[{k:float(v) for k,v in row.items()}for row in csv.DictReader(l for l in next(P.glob(a['label']+'-commands*.csv')).open() if not l.startswith('#'))]
 reads=collections.defaultdict(list)
 if a['arm']=='S':
  for line in (P/(a['label']+'.log')).read_text().splitlines():
   if line.startswith('READ '):
    _,cond,r,lo,hi,n=line.split();reads[(cond,int(r))].append(dict(kind='read',start_ns=int(lo),end_ns=int(hi),bytes=int(n)))
 rows=[]
 for r in a['runs']:
  if r['round']<2:continue
  lo,hi=(r['start_ns']/1e9,r['end_ns']/1e9) if a['arm']=='N' else (r['start'],r['end'])
  gpu=[(max(lo,c['start']),min(hi,c['end']))for c in commands if c['end']>lo and c['start']<hi]
  rr=r['read_intervals'] if a['arm']=='N' else reads[(r['condition'],r['round'])]
  intervals={}
  for kind in set(x['kind'] for x in rr):intervals[kind]=[(max(lo,x['start_ns']/1e9),min(hi,x['end_ns']/1e9))for x in rr if x['kind']==kind]
  read=[v for k,vs in intervals.items() if 'read' in k for v in vs];copy=[v for k,vs in intervals.items() if 'copy' in k for v in vs]
  row=dict(condition=r['condition'],round=r['round'],seconds=hi-lo,gpu=length(gpu),read=length(read),copy=length(copy),read_gpu_overlap=intersection(read,gpu),copy_gpu_overlap=intersection(copy,gpu),gpu_without_read_or_copy=length(gpu)-intersection(read+copy,gpu),neither_gpu_nor_read_copy=hi-lo-length(gpu+read+copy),read_bytes=sum(x['bytes'] for x in rr if 'read' in x['kind']),copy_bytes=sum(x['bytes'] for x in rr if 'copy' in x['kind']))
  for kind,ints in intervals.items():row[kind+'_union']=length(ints)
  rows.append(row)
 stats={}
 for c in sorted(set(r['condition']for r in rows)):
  rs=[r for r in rows if r['condition']==c];keys=set().union(*(r.keys()for r in rs))-{'condition','round'}
  stats[c]={k:statistics.median(r.get(k,0) for r in rs)for k in sorted(keys)}
 out.append(dict(label=a['label'],eligible=a['eligible'],conditions=stats,runs=rows))
(P/'trace-analysis.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps([{k:v for k,v in x.items()if k!='runs'}for x in out],indent=2))
