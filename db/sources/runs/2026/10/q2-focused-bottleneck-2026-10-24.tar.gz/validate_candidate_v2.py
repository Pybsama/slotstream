from pathlib import Path
import json,subprocess,sys,time
P=Path(__file__).resolve().parent;R=P.parents[1];OLD=P.parent/'native-replay-20261023';B=P/'candidate-build/candidate/slotstream'
ledger=[]
def run(label,args,budget,timeout=600,env=[]):
 command=[sys.executable,str(P/'guarded_run.py'),'--label',label,'--budget',str(budget),'--timeout',str(timeout),*sum((['--env',x]for x in env),[]),'--',str(B),*args]
 print('START',label,flush=True)
 with(P/(label+'-driver.log')).open('x')as f:r=subprocess.run(command,cwd=R,stdout=f,stderr=subprocess.STDOUT)
 ledger.append(dict(label=label,command=command,exit_code=r.returncode));(P/'correctness-ledger-v2.json').write_text(json.dumps(ledger,indent=2)+'\n')
 print('END',label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
run('candidate-q2-pool-api',['q2-experts-check','--pool-model','smart-q2'],3,900,['MTL_DEBUG_LAYER=1'])
label='candidate-q2-state';out=P/(label+'.json')
run(label,['q2-profile','--model','smart-q2','--memory-gb','10','--rounds','1','--retained-prefix','3','--fixture',str(OLD/'v29-profile-smart-q2-fixture.json'),'--output',str(out)],10)
d=json.loads(out.read_text());old=json.loads((OLD/'v68-combine-state-smart-q2-1.json').read_text())
assert len(d['runs'])==16
for x in d['runs']:
 prior=next(r for r in old['runs']if r['width']==x['width']and r['traced']==x['traced'])
 assert x['max_logit_difference']==0 and x['argmax_equal']
 assert (x['logits_sha256'],x['recurrence_sha256'])==(prior['logits_sha256'],prior['recurrence_sha256'])
(P/'correctness-summary.json').write_text(json.dumps(dict(passed=True,pool='independent original bytes, demands/forecasts, cache transitions, cancellation, retry and Metal API validation',state='16 width/trace cases, partial speculative rollback; full FP32 logits and recurrent hashes equal frozen v68'),indent=2)+'\n')
print('Relevant correctness PASS',flush=True)
