from pathlib import Path
P=Path(__file__).resolve().parent;D=P/'upstream'
f=D/'include/model/ExpertStore.hpp';s=f.read_text().replace('#include <cstdint>','#include <cstdint>\n#include <array>')
s=s.replace('  std::vector<uint64_t> diagnosticTakeRoutes();','  std::vector<uint64_t> diagnosticTakeRoutes();\n  std::vector<std::array<uint64_t,3>> diagnosticTakeReads();');f.write_text(s)
f=D/'ExpertStore.cpp';s=f.read_text().replace('#include "model/ExpertStore.hpp"','#include "model/ExpertStore.hpp"\n#include "AwakeClock.hpp"\n#include <cstdlib>')
s=s.replace('  std::vector<uint64_t> diagnosticRoutes;','''  std::vector<uint64_t> diagnosticRoutes;
  const bool diagnosticReadsEnabled=std::getenv("Q2_DIAGNOSTIC_READS")!=nullptr;
  mutable std::mutex diagnosticReadMutex;
  mutable std::vector<std::array<uint64_t,3>> diagnosticReadRows;''')
old='  if (run.file) return run.file->readFile(run.offset + piece.from, to);'
new='''  if (run.file) {
    const auto start=diagnosticReadsEnabled?AwakeClock::now().time_since_epoch().count():0;
    run.file->readFile(run.offset + piece.from, to);
    if(diagnosticReadsEnabled) {
      const auto end=AwakeClock::now().time_since_epoch().count();
      std::lock_guard lock(diagnosticReadMutex);
      diagnosticReadRows.push_back({uint64_t(start),uint64_t(end),uint64_t(to.size())});
    }
    return;
  }'''
assert s.count(old)==1;s=s.replace(old,new)
s=s.replace('std::vector<uint64_t> ExpertStore::diagnosticTakeRoutes() {','''std::vector<std::array<uint64_t,3>> ExpertStore::diagnosticTakeReads() {
  std::lock_guard lock(impl_->diagnosticReadMutex);std::vector<std::array<uint64_t,3>> result;
  result.swap(impl_->diagnosticReadRows);return result;
}
std::vector<uint64_t> ExpertStore::diagnosticTakeRoutes() {''')
f.write_text(s)
f=D/'fixed_verify.mm';s=f.read_text().replace('(void)store->diagnosticTakeRoutes();','(void)store->diagnosticTakeRoutes(); (void)store->diagnosticTakeReads();')
s=s.replace('          std::fflush(stdout);','''          for(const auto &read:store->diagnosticTakeReads())
            std::printf("READ %s %u %llu %llu %llu\\n",condition,round,(unsigned long long)read[0],(unsigned long long)read[1],(unsigned long long)read[2]);
          std::fflush(stdout);''')
f.write_text(s)
