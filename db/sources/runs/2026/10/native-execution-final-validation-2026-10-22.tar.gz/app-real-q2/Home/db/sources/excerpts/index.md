---
type: index
scope: type-folder
folder: sources/excerpts
updated: 2026-10-23T00:40:49.830101Z
---

# sources/excerpts

- [[sources/excerpts/2026/10/55d40b87-f596-4531-a4eb-6d2422bff1c2-S1-99b3f474908f242ea05dae14]] — Immutable conversation event
- [[sources/excerpts/2026/10/1fdcb696-cd07-4185-bc28-c24bc9f7c327-S2-e32c1d47ed0ae7647dffb8aa]] — Immutable conversation event
- [[sources/excerpts/2026/10/1fdcb696-cd07-4185-bc28-c24bc9f7c327-S1-6580e39aed2d67a8ab4fb8e1]] — Immutable conversation event
- [[sources/excerpts/2026/10/d1cce6f0-e878-4afe-b253-df0dcd66dd3f-S1-283f6b91d0c0d54720f92dcb]] — Immutable conversation event
- [[sources/excerpts/2026/10/b9b638c5-843d-4bc1-b0ee-514479a30bd8-S1-8f367caa78d7ab4e03f5291e]] — Immutable conversation event
