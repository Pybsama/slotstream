---
type: index
scope: type-folder
folder: records/state
updated: 2026-10-23T00:42:05.499583Z
---

# records/state

- [[records/state/home]] — Slotstream Home state and conversation history
