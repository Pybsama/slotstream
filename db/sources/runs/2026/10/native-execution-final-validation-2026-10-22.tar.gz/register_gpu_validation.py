from pathlib import Path
import re,json,time,numpy as np
import mlx.core as mx
P=Path(__file__).resolve().parent;R=P.parents[1]
s=(R/'Sources/Slotstream/Q2ResidentKernelSources.swift').read_text()
def section(name):return re.search(r'static let '+name+r' = #"""\n(.*?)\n"""#',s,re.S)[1]
pack=mx.fast.metal_kernel(name='probe_q80_pack',input_names=['w'],output_names=['y'],header=section('header')+section('repack'),source='''uint t=thread_position_in_grid.x;if(t>=OUT*IN/32)return;uint n=t/(IN/32),g=t%(IN/32);gguf_repack_group(w+size_t(n)*RB,FMT,IN/32,n,g,y,y+P1,y+META);''')
h=(P/'register-header.metal').read_text();prep=mx.fast.metal_kernel(name='probe_table16',input_names=['input'],output_names=['table','sums'],header=h,source=(P/'register-prepare.metal').read_text())
mat=mx.fast.metal_kernel(name='probe_register_q80',input_names=['table','sums','w'],output_names=['y'],header=h+'\ntypedef FmtQ80 F;\n',source=(P/'register-matrix.metal').read_text())
n,k=320,10240
rng=np.random.default_rng(42);codes=rng.integers(-127,128,(n,k),dtype=np.int8);scales=rng.uniform(.0003,.003,(n,k//32)).astype(np.float16)
raw=np.empty((n,k//32,34),np.uint8);raw[:,:,:2]=scales.view(np.uint8).reshape(n,k//32,2);raw[:,:,2:]=codes.reshape(n,k//32,32).view(np.uint8)
w=pack(inputs=[mx.array(raw.reshape(-1))],template=[('IN',k),('OUT',n),('RB',k//32*34),('FMT',6),('P1',n*k),('META',n*k)],grid=(n*k//32,1,1),threadgroup=(256,1,1),output_shapes=[(raw.size,)],output_dtypes=[mx.uint8])[0]
mx.eval(w);weights=codes.astype(np.float64)*np.repeat(scales.astype(np.float64),32,axis=1);results=[]
for count in [1,2,4,8]:
 x=mx.array(rng.normal(0,.2,(count,k)).astype(np.float32)).astype(mx.bfloat16);mx.eval(x);expected=np.array(x.astype(mx.float32)).astype(np.float64)@weights.T
 for splits in [1,4,8,16]:
  def run():
   t,z=prep(inputs=[x],template=[('IN',k),('COUNT',count)],grid=(k//64*8//4*128,1,1),threadgroup=(128,1,1),output_shapes=[(k*8,),(k//16*8+k//32*8,)],output_dtypes=[mx.bfloat16,mx.float32])
   y=mat(inputs=[t,z,w],template=[('IN',k),('OUT',n),('SPLITS',splits),('P1',n*k),('META',n*k)],grid=(n//64*128,splits,1),threadgroup=(128,1,1),output_shapes=[(splits,8,n)],output_dtypes=[mx.float32])[0]
   return y.sum(axis=0)[:count]
  y=run();mx.eval(y);a=np.array(y);err=float(np.max(np.abs(a-expected)));scale=float(np.max(np.abs(expected)));assert err<max(2e-5,scale*2e-5),(count,splits,err,scale)
  times=[]
  for _ in range(5):
   start=time.perf_counter();z=run();mx.eval(z);times.append(time.perf_counter()-start)
  r=dict(count=count,splits=splits,max_error=err,scale=scale,seconds=times);results.append(r);print(r,flush=True)
(P/'register-gpu-validation-results.json').write_text(json.dumps(results,indent=2))
