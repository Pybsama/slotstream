---
type: index
scope: type-folder
folder: sources/excerpts
updated: 2026-10-23T00:37:39.940482Z
---

# sources/excerpts

- [[sources/excerpts/2026/10/f565e080-c57b-42e5-9120-a0457140122f-S1-99b3f474908f242ea05dae14]] — Immutable conversation event
- [[sources/excerpts/2026/10/a77d43fe-eff8-4ce9-8e38-939ea7eb9a1b-S1-bbc1014b0c8c88d5a662503e]] — Immutable conversation event
- [[sources/excerpts/2026/10/a31ac305-c500-4e05-a235-9bd7f91cdd16-S1-283f6b91d0c0d54720f92dcb]] — Immutable conversation event
- [[sources/excerpts/2026/10/8802561a-2f43-4161-8272-b77b56670677-S1-8f367caa78d7ab4e03f5291e]] — Immutable conversation event
