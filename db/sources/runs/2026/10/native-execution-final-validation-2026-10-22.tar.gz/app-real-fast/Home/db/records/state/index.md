---
type: index
scope: type-folder
folder: records/state
updated: 2026-10-23T00:38:08.463540Z
---

# records/state

- [[records/state/home]] — Slotstream Home state and conversation history
