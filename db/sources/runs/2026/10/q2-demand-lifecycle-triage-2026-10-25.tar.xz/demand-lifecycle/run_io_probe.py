from pathlib import Path
import csv,fcntl,hashlib,json,os,subprocess,sys,time
P=Path(__file__).resolve().parent;R=P.parents[1];sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight,vm_snapshot,host_conditions
lock=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(P/'io-probe-child.lock')
assert not(P/'io-probe-receipt.json').exists();before=preflight(4);host=host_conditions()
cmd=['xcrun','clang++','-std=c++17','-O2','-fobjc-arc','-framework','Metal','-framework','Foundation',str(P/'io_buffer_probe.mm'),'-o',str(P/'io-buffer-probe')]
r=subprocess.run(cmd,capture_output=True,text=True,timeout=120);(P/'io-probe-build.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stderr
command=[str(P/'io-buffer-probe'),str(R/'.build/smart-dflash-eval/gsq/Qwen3.8-Flash-Next-GSQ-RCO-Q2_0-00001-of-00002.gguf'),str(P/'io-fixture.txt')]
start=time.monotonic();r=subprocess.run(command,capture_output=True,text=True,timeout=120);(P/'io-probe.csv').write_text(r.stdout);(P/'io-probe.stderr').write_text(r.stderr);after=vm_snapshot()
receipt=dict(scope='Read-and-copy microprobe only, no model or GPU kernels, no inference speed/quality evidence. Same first128 recorded demand batches, fixed32static GCD lanes, perlane scratch acquired from36bufferpool, identical shared staging. Aalignedmalloc/BsharedMetal scratch. Original-byte SHA256 for every batch/round, outside timers. Two warmup rounds then ABBA twice. Excludes original foreground/background schedule, gaps, fstats, controller and GPU contention. No benchmark retries.',before=before,after=after,host=host,elapsed=time.monotonic()-start,command=command,build=cmd,exit_code=r.returncode,paging=any(before[k]!=after[k]for k in ['swapins','swapouts']),memory_bound_bytes=2*36*491520+96*460800,sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in [P/'io_buffer_probe.mm',P/'io-fixture.txt']})
(P/'io-probe-receipt.json').write_text(json.dumps(receipt,indent=2));print(r.stdout);assert r.returncode==0,r.stderr
