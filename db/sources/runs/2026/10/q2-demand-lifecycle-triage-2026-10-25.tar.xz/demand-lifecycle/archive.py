from pathlib import Path
import hashlib,io,json,re,tarfile,shutil
P=Path(__file__).resolve().parent;R=P.parents[1];K=P.parent/'q2-os-readahead-20261025';sha=lambda b:hashlib.sha256(b).hexdigest()
(K/'decision.json').write_text(json.dumps(dict(decision='Abandoned before model benchmarks; not a measured speed rejection.',reason='Pinned public XNU cluster_read_ext selects uncached direct/contiguous reads; its fallback cluster_read_copy disables readahead when IO_NOCACHE is set regardless of IO_RAOFF. Both engines request F_NOCACHE. This weakens the proposed F_RDAHEAD mechanism enough to avoid six full model arms. Public XNU source is not proof of the exact installed APFS implementation.',compiled=True,model_run=False,quality_run=False,production_retained=False,source_commit='f6217f891ac0bb64f3d375211650a4c1ff8ca1ea'),indent=2))
(P/'analysis-notes.json').write_text(json.dumps(dict(lane_assertion_repair='Unmatched read copies equal exactly3*prefillRecords and all precede every raw decodecopy. Prefill repacks onCPU, so the raw memcpy correlation correctly covers decode only. Asserted full decodecounts, unique3piecekeys, layer grouping and staticlane same-threadorder; zero skippedgroups.',scope_correction='Finished-worker/queued-job tail holds the observed preceding service fixed. It does not bound every alternate dynamic schedule or demonstrate CPU idleness.',probe_initial_refusals='First driver held global lock then checked it again; repaired by private child lock. First executable refused valid exact unaligned tensor-edge extents before timing; repaired extent validator. Both failures preserved, no favorable timed run selected.',fast='Unchanged',runtime='v68 restored509inputs5artifacts',next='Remaining useful question is concurrent I/O/GPU interaction in ordinary requests. Isolated scratch read/copy throughput and conditional lane-tail bounds do not establish its cause.'),indent=2))
refs=[]
for dirname,name,patterns in [
 ('q2-typical-20261025','q2-typical-verification-2026-10-25.tar.gz',['normal-native.json']),
 ('q2-host-profile-20261025','q2-ordinary-copies-attribution-2026-10-25.tar.xz',['ordinary-copies-15*.csv','ordinary-copies-15*.json']),
 ('q2-readiness-critical-20261025','q2-critical-readiness-attribution-2026-10-25.tar.xz',['detail.json','analyze.py']),
]:
 archive=R/'db/sources/runs/2026/10'/name
 with tarfile.open(archive)as t:
  manifest=json.load(t.extractfile('archive-manifest.json'))
  verified={}
  for pattern in patterns:
   for f in (R/'.build'/dirname).glob(pattern):
    if f.name not in manifest:continue
    h=sha(f.read_bytes());expected=manifest[f.name]['sha256'];assert h==expected,(f,h,expected)
    verified[f.name]=h
  assert verified
 refs.append(dict(archive=str(archive.relative_to(R)),sha256=sha(archive.read_bytes()),files=verified))
(P/'prior-evidence.json').write_text(json.dumps(refs,indent=2))
files={}
for base,prefix in [(P,'demand-lifecycle'),(K,'os-readahead')]:
 for f in base.rglob('*'):
  if not f.is_file()or'__pycache__'in f.parts or f.name=='archive-receipt.json':continue
  if f.suffix not in ['.py','.swift','.cpp','.mm','.c','.json','.csv','.log','.stderr','.txt']:continue
  files[prefix+'/'+str(f.relative_to(base))]=f
files['reference/v68-build-identity.json']=R/'.build/native-replay-20261023/v68/build-identity.json'
files['reference/gguf-header.json']=R/'.build/smart-dflash-eval/gsq-header.json'
secret=re.compile(rb'(?:ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{25,}|sk-(?:proj-)?[A-Za-z0-9_-]{30,}|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----)')
manifest={}
for n,f in files.items():
 b=f.read_bytes();assert not secret.search(b),n;manifest[n]=dict(bytes=len(b),sha256=sha(b))
dest=R/'db/sources/runs/2026/10/q2-demand-lifecycle-triage-2026-10-25.tar.xz';assert not dest.exists();raw=json.dumps(manifest,indent=2).encode()
with tarfile.open(dest,'w:xz',preset=3)as t:
 for n,f in sorted(files.items()):t.add(f,arcname=n,recursive=False)
 info=tarfile.TarInfo('archive-manifest.json');info.size=len(raw);t.addfile(info,io.BytesIO(raw))
seen={}
with tarfile.open(dest,'r|xz')as t:
 for m in t:
  b=t.extractfile(m).read()
  if m.name=='archive-manifest.json':assert json.loads(b)==manifest
  else:seen[m.name]=dict(bytes=len(b),sha256=sha(b))
assert seen==manifest
receipt=dict(path=str(dest.relative_to(R)),files=len(manifest),bytes=dest.stat().st_size,sha256=sha(dest.read_bytes()),readback_verified=True,credential_pattern_matches=0,prior_refs=refs,excluded='Executables/libraries/model weights and duplicate full build source archive. Original ordinary traces referenced by verified archive/member hashes.')
(P/'archive-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps({k:v for k,v in receipt.items()if k!='prior_refs'},indent=2))
