from pathlib import Path
import bisect,collections,csv,json,re
P=Path(__file__).resolve().parent;R=P.parents[1];H=P.parent/'q2-host-profile-20261025';label='ordinary-copies-15-0-A'
def rows(p):
 with p.open()as f:out=list(csv.DictReader(x for x in f if not x.startswith('#')))
 with p.open('rb')as f:f.seek(max(0,p.stat().st_size-512));foot=dict(x.split('=',1)for x in f.read().decode().splitlines()[-1][2:].split())
 assert int(foot['total'])<int(foot['cap'])
 return out
def union(xs):
 out=[]
 for a,b in sorted(xs):
  if b<=a:continue
  if not out or a>out[-1][1]:out.append([a,b])
  else:out[-1][1]=max(out[-1][1],b)
 return out
def length(xs):return sum(b-a for a,b in xs)
def inter(a,b):
 out=[];i=j=0
 while i<len(a)and j<len(b):
  lo,hi=max(a[i][0],b[j][0]),min(a[i][1],b[j][1])
  if hi>lo:out.append([lo,hi])
  if a[i][1]<b[j][1]:i+=1
  else:j+=1
 return out
header=json.loads((R/'.build/smart-dflash-eval/gsq-header.json').read_text());extents=[]
for t in header['tensors']:
 m=re.fullmatch(r'blk\.(\d+)\.ffn_(gate|up|down)_exps\.weight',t['name'])
 if m:extents.append(dict(start=11024672+t['offset'],end=11024672+t['offset']+512*460800,layer=int(m[1]),piece={'gate':0,'up':1,'down':2}[m[2]]))
assert len(extents)==144;extents.sort(key=lambda e:e['start']);starts=[x['start']for x in extents]
reads=[];bythread=collections.defaultdict(list)
for x in rows(next(H.glob(label+'-reads.*.csv'))):
 r={k:float(v)if k in ['start','end']else int(v)for k,v in x.items()}
 if r['result']<65536:continue
 middle=r['offset']+r['result']/2;i=bisect.bisect_right(starts,middle)-1
 if i<0:continue
 t=extents[i]
 if not t['start']<=middle<t['end']:continue
 expert=int((middle-t['start'])//460800);payload=t['start']+expert*460800
 if not r['offset']<=payload or not payload+460800<=r['offset']+r['result']:continue
 r.update(layer=t['layer'],piece=t['piece'],expert=expert,payload=payload)
 reads.append(r);bythread[r['thread']].append(r)
for v in bythread.values():v.sort(key=lambda r:r['end'])
ends={k:[r['end']for r in v]for k,v in bythread.items()}
for x in rows(next(H.glob(label+'-copies.*.csv'))):
 if int(x['bytes'])!=460800:continue
 t=int(x['thread']);a,b=float(x['start']),float(x['end']);i=bisect.bisect_right(ends.get(t,[]),a)-1
 if i<0:continue
 r=bythread[t][i]
 if int(x['source'])-r['destination']+r['offset']==r['payload']:
  assert 'copy_end'not in r
  r.update(copy_start=a,copy_end=b)
counts=collections.Counter(r['destination']for r in reads);forecast={x for x,n in counts.most_common(4)}
signals=sorted(float(e['stamp'])for e in rows(next(H.glob(label+'-commands.*.events.csv')))if e['kind']=='S')
ss=rows(next(H.glob(label+'-commands.*.stages.csv')))
assert all(int(s['gpu_end'])>int(s['gpu_start'])>0 for s in ss)
gpu=union((int(s['gpu_start'])/1e9,int(s['gpu_end'])/1e9)for s in ss)
data=json.loads((H/(label+'.json')).read_text());reports=[]
for r in data['runs']:
 if not r['id'].startswith('timed'):continue
 lo,hi=r['request_started_mach_ns']/1e9,r['request_ended_mach_ns']/1e9
 demand=[x for x in reads if lo<=x['start']<hi and x['destination']not in forecast]
 expected=(r['stats']['prefillRecords']+r['stats']['decodeRecords'])*3
 assert len(demand)==expected,(r['id'],len(demand),expected)
 missing=[x for x in demand if 'copy_end'not in x]
 assert len(missing)==3*r['stats']['prefillRecords'],(r['id'],len(missing),r['stats']['prefillRecords'])
 demand=[x for x in demand if 'copy_end'in x]
 assert len(demand)==3*r['stats']['decodeRecords']
 assert max(x['end']for x in missing)<min(x['start']for x in demand)
 # Prefill repacks rather than raw-copying: all unmatched reads precede decode.
 groups=collections.defaultdict(list)
 for x in demand:groups[bisect.bisect_left(signals,x['copy_end'])].append(x)
 batches=[];skipped=collections.Counter()
 for signal,group in groups.items():
  if len({x['layer']for x in group})!=1:skipped['mixed_layer_pieces']+=len(group);continue
  keys=sorted({x['expert']for x in group});mapping={(x['expert'],x['piece']):x for x in group}
  if len(mapping)!=len(group)or len(group)!=len(keys)*3:skipped['non_unique_or_incomplete_record_pieces']+=len(group);continue
  for offset in range(0,len(keys),32):
   kk=keys[offset:offset+32];jobs=[mapping[(k,p)]for k in kk for p in range(3)];lanes=min(32,len(jobs));partition=[jobs[i::lanes]for i in range(lanes)]
   if not all(len({x['thread']for x in lane})==1 and all(a['copy_end']<=b['start']for a,b in zip(lane,lane[1:]))for lane in partition):
    skipped['static_partition_validation_failed_pieces']+=len(jobs);continue
   workers=collections.defaultdict(list)
   for x in jobs:workers[x['thread']].append(x)
   # Even granting that a worker is free at its last copy (before scratch
   # release/return), this interval is an opportunity for stealing work
   # after the first observed worker finishes, holding prior service fixed.
   # It does not bound alternate schedules or predict speedup/CPU idleness.
   earliest_finished=min(max(x['copy_end']for x in v)for v in workers.values())
   last_started=max(x['start']for x in jobs);tail=union([[earliest_finished,last_started]])
   multi=len(jobs)>lanes
   batches.append(dict(signal=signal,layer=group[0]['layer'],records=len(kk),workers=len(workers),lanes=lanes,multi=multi,read_copy_span=max(x['copy_end']for x in jobs)-min(x['start']for x in jobs),tail_seconds=length(tail),tail_outside_gpu=length(tail)-length(inter(tail,gpu)),tail=tail))
 selected=[b for b in batches if b['multi']]
 out=dict(id=r['id'],request_seconds=hi-lo,decode_demand_pieces=len(demand),prefill_repacked_pieces_excluded=len(missing),matches_prefill_and_decode_counters=True,classified_forecast_destinations=sorted(forecast),skipped=dict(skipped),validated_batches=len(batches),multi_job_batches=len(selected),multi_read_copy_span=sum(b['read_copy_span']for b in selected),observed_finished_worker_queued_tail_seconds=sum(b['tail_seconds']for b in selected),observed_tail_outside_gpu_seconds=sum(b['tail_outside_gpu']for b in selected),max_single_tail=max((b['tail_seconds']for b in selected),default=0),batch_data=batches)
 reports.append(out);print(json.dumps({k:v for k,v in out.items()if k!='batch_data'},indent=2),flush=True)
(P/'lane-tail-analysis.json').write_text(json.dumps(dict(scope='Offline conditional opportunity from clean ordinary native copy/read/stage traces. Forecast destinations are the four dominant scratch buffers; demand counts independently match prefill+decode record counters. Layer groups use the next host publication; exclude ambiguous groups and assert unique3piece records and same-thread static stride order. A released worker may be busy elsewhere; copy completion is earlier than actual callback return. Not a bound on alternate earlier ordering or read-service changes. No causal speedup, no transfer to another cache budget, no arithmetic change.',requests=reports),indent=2))
