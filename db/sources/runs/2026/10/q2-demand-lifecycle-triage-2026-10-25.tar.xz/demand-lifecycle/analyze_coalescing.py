from pathlib import Path
import json,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1];source=R/'.build/q2-typical-20261025/normal-native.json';data=json.loads(source.read_text());results=[]
for r in data['runs']:
 if not r['id'].startswith('timed'):continue
 events=[x for x in r['trace']if x['kind']=='ensure_start'and x['pass']>=0];counts={cap:0 for cap in [8,9]};total=0;adjacent=0;maximum=0
 for e in events:
  ids=sorted(e['misses']);assert len(ids)==len(set(ids));total+=len(ids);runs=[]
  for v in ids:
   if runs and v==runs[-1][-1]+1:runs[-1].append(v);adjacent+=1
   else:runs.append([v])
  maximum=max([maximum]+[len(x)for x in runs])
  for cap in counts:counts[cap]+=sum((len(x)+cap-1)//cap for x in runs)
 results.append(dict(id=r['id'],expert_batches=len(events),all_missing_experts=total,consecutive_groups_capped_eight=counts[8],groups_capped_nine=counts[9],saved_group_fraction_before_forecast_adoption=1-counts[8]/total,adjacent_pairs=adjacent,longest_run=maximum))
report=dict(source=str(source.relative_to(R)),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),scope='Captured true missing keys before forecast adoption, not actual demanded read jobs or a predicted time saving. A fraction before adoption is not a bound on the fraction after adoption. Groups stay within layer/call; cap8 conservative and cap9 sensitivity for upstream4MiBpieces. Original payload460800bytes.',results=results)
(P/'coalescing-opportunity.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
