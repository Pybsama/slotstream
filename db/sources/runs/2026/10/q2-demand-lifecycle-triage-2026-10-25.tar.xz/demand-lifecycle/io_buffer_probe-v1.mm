#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <CommonCrypto/CommonDigest.h>
#include <dispatch/dispatch.h>
#include <sys/stat.h>
#include <sys/resource.h>
#include <fcntl.h>
#include <unistd.h>
#include <algorithm>
#include <array>
#include <chrono>
#include <cstdio>
#include <fstream>
#include <mutex>
#include <stdexcept>
#include <vector>
using Clock=std::chrono::steady_clock;
constexpr size_t payload=460800, capacity=491520, buffers=36;
struct Job {off_t offset;size_t count,skip;};
using Hash=std::array<unsigned char,CC_SHA256_DIGEST_LENGTH>;
struct Scratch {
 std::mutex mutex;std::vector<void*> free,owned;NSMutableArray<id<MTLBuffer>>* metal;
 Scratch(id<MTLDevice> device,bool gpu):metal([NSMutableArray new]) {
  for(size_t i=0;i<buffers;i++) {void *p=nullptr;
   if(gpu) {id<MTLBuffer>b=[device newBufferWithLength:capacity options:MTLResourceStorageModeShared];if(!b)throw std::runtime_error("Metal allocation");[metal addObject:b];p=b.contents;}
   else {if(posix_memalign(&p,16384,capacity))throw std::runtime_error("host allocation");owned.push_back(p);}
   if((uintptr_t)p%16384)throw std::runtime_error("unaligned buffer");memset(p,0,capacity);free.push_back(p);
  }
 }
 ~Scratch(){for(auto p:owned)std::free(p);}
 void* acquire(){std::lock_guard lock(mutex);if(free.empty())throw std::runtime_error("scratch exhausted");auto p=free.back();free.pop_back();return p;}
 void release(void*p){std::lock_guard lock(mutex);free.push_back(p);}
};
void readexact(int fd,void*p,size_t n,off_t at){size_t done=0;while(done<n){ssize_t got=pread(fd,(char*)p+done,n-done,at+done);if(got<0&&errno==EINTR)continue;if(got<=0)throw std::runtime_error("pread");done+=got;}}
int main(int argc,char**argv){@autoreleasepool{try{
 if(argc!=3)throw std::runtime_error("args: shard fixture");
 int fd=open(argv[1],O_RDONLY|O_CLOEXEC);if(fd<0||fcntl(fd,F_NOCACHE,1)||fcntl(fd,F_RDAHEAD,0))throw std::runtime_error("open flags");struct stat initial{};if(fstat(fd,&initial))throw std::runtime_error("stat");
 std::ifstream in(argv[2]);size_t n;in>>n;if(n!=128)throw std::runtime_error("batch count");std::vector<std::vector<Job>> batches(n);uint64_t totalbytes=0,totaljobs=0;
 for(auto&batch:batches){size_t count;in>>count;if(!count||count>96||count%3)throw std::runtime_error("jobs");batch.resize(count);for(auto&j:batch){in>>j.offset>>j.count>>j.skip;if(!in||j.offset<0||j.offset%16384||j.count>capacity||j.skip+payload>j.count||j.offset+(off_t)j.count>initial.st_size)throw std::runtime_error("extent");totalbytes+=j.count;totaljobs++;}}
 id<MTLDevice> device=MTLCreateSystemDefaultDevice();if(!device)throw std::runtime_error("device");Scratch host(device,false),shared(device,true);id<MTLBuffer> staging=[device newBufferWithLength:96*payload options:MTLResourceStorageModeShared];if(!staging)throw std::runtime_error("staging");char*to=(char*)staging.contents;
 std::vector<Hash> reference;reference.reserve(n);
 for(const auto&batch:batches){for(size_t j=0;j<batch.size();j++)readexact(fd,to+j*payload,payload,batch[j].offset+batch[j].skip);Hash hash{};CC_SHA256(to,(CC_LONG)(batch.size()*payload),hash.data());reference.push_back(hash);}
 // Both warmed, then fixed ABBA twice. No model/GPU compute or timed hashes.
 const char*order="ABABBAABBA";
 printf("round,arm,wall_seconds,cpu_seconds,read_bytes,jobs,hashes_match\n");
 for(int round=0;order[round];round++){Scratch*scratch=order[round]=='A'?&host:&shared;double wall=0,cpu=0;size_t ix=0;
  for(const auto&batch:batches){size_t jobs=batch.size(),lanes=std::min<size_t>(32,jobs);const Job*work=batch.data();__block std::exception_ptr failure;std::mutex failmutex;std::mutex*fm=&failmutex;struct rusage before{},after{};getrusage(RUSAGE_SELF,&before);auto begin=Clock::now();
   dispatch_apply(lanes,dispatch_get_global_queue(QOS_CLASS_USER_INITIATED,0),^(size_t lane){void*p=nullptr;try{p=scratch->acquire();for(size_t j=lane;j<jobs;j+=lanes){readexact(fd,p,work[j].count,work[j].offset);memcpy(to+j*payload,(char*)p+work[j].skip,payload);}}catch(...){std::lock_guard lock(*fm);if(!failure)failure=std::current_exception();}if(p)scratch->release(p);});
   wall+=std::chrono::duration<double>(Clock::now()-begin).count();getrusage(RUSAGE_SELF,&after);cpu+=(after.ru_utime.tv_sec-before.ru_utime.tv_sec)+(after.ru_stime.tv_sec-before.ru_stime.tv_sec)+((after.ru_utime.tv_usec-before.ru_utime.tv_usec)+(after.ru_stime.tv_usec-before.ru_stime.tv_usec))/1e6;
   if(failure)std::rethrow_exception(failure);Hash hash{};CC_SHA256(to,(CC_LONG)(jobs*payload),hash.data());if(hash!=reference[ix++])throw std::runtime_error("byte mismatch");
  }
  printf("%d,%c,%.9f,%.9f,%llu,%llu,true\n",round,order[round],wall,cpu,(unsigned long long)totalbytes,(unsigned long long)totaljobs);fflush(stdout);
 }
 struct stat last{};if(fstat(fd,&last)||last.st_size!=initial.st_size||last.st_mtimespec.tv_sec!=initial.st_mtimespec.tv_sec||last.st_mtimespec.tv_nsec!=initial.st_mtimespec.tv_nsec||last.st_ctimespec.tv_sec!=initial.st_ctimespec.tv_sec||last.st_ctimespec.tv_nsec!=initial.st_ctimespec.tv_nsec)throw std::runtime_error("source changed");close(fd);return 0;
 }catch(const std::exception&e){fprintf(stderr,"%s\n",e.what());return 1;}}}
