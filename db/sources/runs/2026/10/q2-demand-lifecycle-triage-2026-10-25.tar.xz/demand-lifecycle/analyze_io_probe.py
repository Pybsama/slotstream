from pathlib import Path
import csv,json,statistics
P=Path(__file__).resolve().parent;rows=list(csv.DictReader((P/'io-probe.csv').open()));assert ''.join(r['arm']for r in rows)=='ABABBAABBA';assert all(r['hashes_match']=='true'and r['jobs']=='2814'and r['read_bytes']=='1342773248'for r in rows)
r=json.loads((P/'io-probe-receipt.json').read_text());assert r['exit_code']==0
values={arm:[float(x['wall_seconds'])for x in rows[2:]if x['arm']==arm]for arm in 'AB'}
report=dict(scope=r['scope'],paging=r['paging'],exact_original_byte_hashes=128*len(rows),controlled_scratch_and_staging_bytes=r['memory_bound_bytes'],not_total_process_peak=True,median_seconds={k:statistics.median(v)for k,v in values.items()},median_shared_over_malloc=statistics.median(values['B'])/statistics.median(values['A']),paired_ratios=[float(rows[b]['wall_seconds'])/float(rows[a]['wall_seconds'])for a,b in [(2,3),(5,4),(6,7),(9,8)]],inference_claim=False,decision='No meaningful read/copy gain in this narrow workload; do not add Metal-backed scratch to production or infer whole-request parity.')
(P/'io-probe-analysis.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
