from pathlib import Path
import json,collections,bisect,hashlib,contextlib,io
P=Path(__file__).resolve().parent
source=(P/'analyze_lane_tail.py').read_text();source=source[:source.index('data=json.loads')]
exec(compile(source,str(P/'analyze_lane_tail.py'),'exec'),globals());P=Path(__file__).resolve().parent
request=next(r for r in json.loads((H/(label+'.json')).read_text())['runs']if r['id']=='timed-2')
lo,hi=request['request_started_mach_ns']/1e9,request['request_ended_mach_ns']/1e9
demand=[r for r in reads if lo<=r['start']<hi and r['destination']not in forecast and 'copy_end'in r]
groups=collections.defaultdict(list)
for r in demand:groups[bisect.bisect_left(signals,r['copy_end'])].append(r)
batches=[]
for signal,group in sorted(groups.items()):
 assert len({r['layer']for r in group})==1
 keys=sorted({r['expert']for r in group});mapping={(r['expert'],r['piece']):r for r in group}
 assert len(mapping)==len(group)==len(keys)*3
 for offset in range(0,len(keys),32):
  kk=keys[offset:offset+32];jobs=[mapping[(k,p)]for k in kk for p in range(3)];lanes=min(32,len(jobs))
  assert all(len({r['thread']for r in jobs[lane::lanes]})==1 for lane in range(lanes))
  batches.append(dict(layer=group[0]['layer'],records=len(kk),jobs=[dict(offset=r['offset'],count=r['result'],skip=r['payload']-r['offset'],expert=r['expert'],piece=r['piece'])for r in jobs]))
# Fixed first128ordinarydecodebatches, no best-case selection.
batches=batches[:128];lines=[str(len(batches))]
for batch in batches:
 lines.append(str(len(batch['jobs'])))
 for j in batch['jobs']:lines.append(f"{j['offset']} {j['count']} {j['skip']}")
(P/'io-fixture.txt').write_text('\n'.join(lines)+'\n')
(P/'io-fixture.json').write_text(json.dumps(dict(scope='First128 validated actual decode demand batches from ordinary-copies-15-0-A timed-2. Reads are replayed without GPU execution, forecasts, original gaps or model state. Memory/physical I/O microprobe only, not performance parity.',batches=batches),indent=2))
print('batches',len(batches),'jobs',sum(len(b['jobs'])for b in batches),'bytes',sum(j['count']for b in batches for j in b['jobs']))
