from pathlib import Path
import bisect,csv,json,collections
P=Path(__file__).resolve().parent;I=P.parent/'q2-readiness-critical-20261025'
exec((I/'analyze.py').read_text().split('results=[];details=[]')[0],globals());P=Path(__file__).resolve().parent
all_details=json.loads((I/'detail.json').read_text());out=[]
for item in all_details:
 label=item['label']
 if not label.startswith('ordinary-copies-15-'):continue
 base=P.parent/'q2-host-profile-20261025'
 rr=rows(next(base.glob(label+'-reads.*.csv')));ss=rows(next(base.glob(label+'-commands.*.stages.csv')))
 io=union((float(r['start']),float(r['end']))for r in rr if int(r['result'])>0)
 gpu=union((int(s['gpu_start'])/1e9,int(s['gpu_end'])/1e9)for s in ss if int(s['gpu_end'])>int(s['gpu_start'])>0)
 iends=[b for a,b in io];groups=collections.defaultdict(list);counts=collections.Counter()
 for m in item['matches']:
  a,b=m['unready']
  if b<=a:continue
  inside=[];ix=bisect.bisect_right(iends,a)
  while ix<len(io)and io[ix][0]<b:
   inside.append([max(a,io[ix][0]),min(b,io[ix][1])]);ix+=1
  if not inside:groups['no_observed_read'].append([a,b]);counts['no_observed_read']+=1;continue
  groups['before_first_read'].append([a,inside[0][0]]);groups['after_last_read'].append([inside[-1][1],b])
  for left,right in zip(inside,inside[1:]):groups['between_reads'].append([left[1],right[0]])
  counts['with_reads']+=1
 report=dict(label=label,id=item['id'],counts=dict(counts),groups={})
 for name,spans in groups.items():
  u=union(spans);report['groups'][name]=dict(seconds=length(u),outside_measured_gpu_seconds=length(u)-length(inter(u,gpu)),nonzero_intervals=len(u),max_interval=max((b-a for a,b in u),default=0))
 out.append(report);print(json.dumps(report,indent=2),flush=True)
(P/'readiness-gap-analysis.json').write_text(json.dumps(dict(scope='Offline decomposition of previously paired readiness windows from clean ordinary copy trace. Windows start at preceding GPU boundary/submission and end at host publication or GPU start. All positive observed preads are unioned, including forecast and resident reads. Before/after/between name temporal positions, not caller scopes or causal CPU categories. Unrelated overlapping reads can hide host gaps. Splash has missing encoder boundaries as reported in prior readiness analysis. Not a speed estimate, not equal adaptive work.',results=out),indent=2))
