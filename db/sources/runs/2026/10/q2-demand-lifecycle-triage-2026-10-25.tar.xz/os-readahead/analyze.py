from pathlib import Path
import json,statistics
P=Path(__file__).resolve().parent;label='ordinary-osread-15'
es=json.loads((P/(label+'-ledger.json')).read_text());assert ''.join(e['arm']for e in es)=='ABCCBA';all_eligible=all(e['eligible']for e in es);rows=[]
for req in ['timed-2','timed-3']:
 def r(e):return next(x for x in e['runs']if x['id']==req)
 by={arm:[r(e)['request_seconds']for e in es if e['arm']==arm]for arm in 'ABC'}
 med={k:statistics.median(v)for k,v in by.items()}
 pairs=[by['B'][i]/by['A'][i]for i in range(2)]
 cs=[by['B'][i]/by['C'][i]for i in range(2)]
 rows.append(dict(id=req,request_seconds=by,median=med,candidate_over_baseline_pairs=pairs,candidate_over_splash_pairs=cs,candidate_over_baseline_median=med['B']/med['A'],candidate_over_splash_median=med['B']/med['C']))
for e in es:
 d=json.loads((P/(e['label']+'.json')).read_text())
 if e['arm']in 'AB':
  for r in d['runs']:assert r['text']==r['streamed']and len(r['tokens'])==384 and not r['stats'].get('runtimeError')
retained=all_eligible and all(all(p<1 for p in r['candidate_over_baseline_pairs'])for r in rows)
parity=all_eligible and all(r['candidate_over_splash_median']<=1.05 for r in rows)
result=dict(scope='One frozen complete ABCCBA experiment. A v68 timestamp-only CLI, B same runtime plus joint Q2 greedy decisions, C published Splash. Actual4067slots15GB8192context. No observer injection. All arms count; no retry. Same requested tasks and tokens, different adaptive work; no equal internal work/semantic quality claim.',eligible=all_eligible,retention_gate=retained,within_five_percent=parity,requests=rows,guards=[{k:e.get(k)for k in ['label','eligible','process_paging','thermal_nominal','external_build_samples','complete','exit_code','actual_cache_slots']}for e in es])
(P/'analysis.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
