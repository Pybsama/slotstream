from pathlib import Path
import json,shutil,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1];G=P.parent/'q2-batch-greedy-20261025'
assert not(P/'plan.json').exists()
for name in ['cases.json','quiet_guarded_run.py','q2_upstream_bench_io.py','SmartDFlashCommand-request-clock.swift','analyze.py','analyze_work.py','check_restoration.py']:
 shutil.copy2(G/name,P/name)
s=(R/'Sources/Slotstream/Checkpoint.swift').read_text()
s=s.replace('Self.openForStreaming(file)','Self.openForStreaming(file, readAhead: q2 != nil)').replace('replica.appendingPathComponent(file.lastPathComponent)))','replica.appendingPathComponent(file.lastPathComponent), readAhead: q2 != nil))')
s=s.replace('private static func openForStreaming(_ file: URL) throws -> Int32 {','private static func openForStreaming(_ file: URL, readAhead: Bool) throws -> Int32 {')
s=s.replace('_ = fcntl(f, F_RDAHEAD, 0)','_ = fcntl(f, F_RDAHEAD, readAhead ? 1 : 0)')
assert s.count('readAhead: q2 != nil')==2
(P/'Checkpoint-candidate.swift').write_text(s)
s=(R/'Sources/Slotstream/Q2GGUFFile.swift').read_text().replace('_ = fcntl(fd, F_RDAHEAD, 0)','_ = fcntl(fd, F_RDAHEAD, 1)')
(P/'Q2GGUFFile-candidate.swift').write_text(s)
s=(G/'build.py').read_text();start=s.index('replacements=');end=s.index('\noriginals=',start)
s=s[:start]+"replacements={'Sources/Slotstream/Checkpoint.swift':'Checkpoint-candidate.swift','Sources/Slotstream/Q2GGUFFile.swift':'Q2GGUFFile-candidate.swift','Sources/slotstream-cli/SmartDFlashCommand.swift':'SmartDFlashCommand-request-clock.swift'}"+s[end:]
(P/'build.py').write_text(s)
s=(G/'run.py').read_text().replace('Q2 joint batched greedy verification decisions','Q2 OS file read-ahead enabled, retaining F_NOCACHE')
(P/'run.py').write_text(s)
s=(P/'analyze.py').read_text().replace('ordinary-greedy-15','ordinary-osread-15');(P/'analyze.py').write_text(s)
s=(P/'analyze_work.py').read_text().replace('ordinary-greedy-15','ordinary-osread-15');(P/'analyze_work.py').write_text(s)
plan=dict(hypothesis='Q2 streamed file handles request F_RDAHEAD0, while pinned Splash WeightSource requests F_NOCACHE1 and leaves OS readahead at its default. Both use the same original GGUF inode paths. Ordinary trace showed more native read-union time, but did not isolate this flag. Test this small policy change before any reader rewrite.',change='Enable F_RDAHEAD1 on Q2 shard and Q2-index streaming descriptors only. Leave F_NOCACHE1, scratch/copy, geometry, weights, precision, controller, forecast configuration and Fast untouched.',scope='One untraced complete-request ABCCBA at15GB4067slots8192context. Two warmup requests perprocess then384token code/prose. Fullprotocol environmental exclusions, no retries or best-arm selection.',retention='Require candidate/baseline median time <=0.98 for each task and improvement in both forward/reverse pairs. Parity separately requires candidate/Splash median <=1.05 for each task. Revert if no repeatable benefit. Existing quality failures remain. No production adoption before relevant byte/correctness and complete quality controls.',prior_trace='q2-host-profile-20261025/ordinary-copies-15-ledger.json',runtime_baseline='v68 db1af8ffd201d3dfb83d64b036db12383b08ac0a522d9079c3343acebe78c89b',candidate_sources={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in P.glob('*candidate.swift')})
(P/'plan.json').write_text(json.dumps(plan,indent=2));print(json.dumps(plan,indent=2))
