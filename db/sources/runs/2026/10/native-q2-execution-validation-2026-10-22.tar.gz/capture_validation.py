import hashlib,io,json,pathlib,subprocess,tarfile
P=pathlib.Path(__file__).resolve().parent;R=P.parents[1]
assert (P/'final-static-gates-v2.log').read_text().rstrip().endswith('STATIC GATES PASS')
identity=json.loads((P/'native-packed-v17/build-identity.json').read_text())
changed=[name for name,h in identity['source'].items() if hashlib.sha256((R/name).read_bytes()).hexdigest()!=h]
assert not changed,changed
app=json.loads((P/'final-app-identity.json').read_text())
assert all(hashlib.sha256((R/name).read_bytes()).hexdigest()==h for name,h in app['sources'].items())
assert subprocess.check_output(['git','status','--porcelain'],cwd=R/'.build/checkouts/mlx-swift',text=True)==''
receipt={'cli_build_inputs_unchanged':True,'app_build_inputs_unchanged':True,'mlx_dependency_clean':True,'cli_sha256':identity['binary_sha256'],'catalogue_sha256':hashlib.sha256((R/'.build/release/slotstream-checks').read_bytes()).hexdigest(),'static_exit_code':0,'catalogue_t0':89,'catalogue_t1':18,'real_app_jobs':6,'scope':'The static entry fixture was corrected after the frozen source build. No compiled engine or app inputs changed.'}
(P/'final-validation.json').write_text(json.dumps(receipt,indent=2))
files={name:P/name for name in ['final-validation.json','final-static-gates.log','final-static-gates-v2.log','final-brain-gates.log','final-app-input-check.log','final-catalogue.log','final-catalogue-t1.log','final-app-audit.json','capture_validation.py','archive-receipt.json']}
for name in ['Tools/static_gates.sh','Tools/static_gates_binary_test.py']:
 files[name]=R/name
manifest={name:{'size':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for name,p in files.items()}
out=R/'db/sources/runs/2026/10/native-q2-execution-validation-2026-10-22.tar.gz';assert not out.exists()
with tarfile.open(out,'w:gz')as t:
 b=json.dumps(manifest,indent=2).encode();i=tarfile.TarInfo('MANIFEST.json');i.size=len(b);t.addfile(i,io.BytesIO(b))
 for name,p in files.items():t.add(p,arcname=name,recursive=False)
with tarfile.open(out)as t:
 for name,m in manifest.items():
  b=t.extractfile(name).read();assert len(b)==m['size'] and hashlib.sha256(b).hexdigest()==m['sha256']
r={'path':str(out.relative_to(R)),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'files':len(files),'all_payloads_verified':True}
(P/'validation-archive-receipt.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
