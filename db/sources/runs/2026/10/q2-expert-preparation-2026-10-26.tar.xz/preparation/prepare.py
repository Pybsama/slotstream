from pathlib import Path
import hashlib,json,shutil,subprocess
P=Path(__file__).resolve().parent;R=P.parents[1];D=P.parent/'q2-required-dependencies-20261026'
def replace(s,old,new):
 assert s.count(old)==1,(old,s.count(old));return s.replace(old,new)
rep={}
def save(name,s):
 local=Path(name).name;rep[name]=local;(P/local).write_text(s)
for n in ['DependencyProbe.hpp','Q2ProfileCommand.swift','build_native.py','quiet_guarded_run.py','timed-2.json','check_restoration.py']:shutil.copy2(D/n,P/n)
rep['Sources/CNativeSchedule/DependencyProbe.hpp']='DependencyProbe.hpp';rep['Sources/slotstream-cli/Q2ProfileCommand.swift']='Q2ProfileCommand.swift'
s=(D/'NativeSchedule-probe.cpp').read_text()
s=replace(s,'extern "C" {','extern "C" {\nvoid ss_dependency_mark(uint32_t phase) { ssdep::emit(phase,ssdep::next_id()); }')
s=replace(s,'    auto work = std::make_shared<Job>(stream, awaiting_reads);','    ss_dependency_mark(74);\n    auto work = std::make_shared<Job>(stream, awaiting_reads);')
s=replace(s,'    inputs.emplace_back(order, Shape{rows});','    ss_dependency_mark(75);\n    inputs.emplace_back(order, Shape{rows});')
s=replace(s,'    // The shared expert is an ordering dependency, not another expert weight.','    ss_dependency_mark(76);\n    // The shared expert is an ordering dependency, not another expert weight.')
save('Sources/CNativeSchedule/NativeSchedule.cpp',s)
s=(R/'Sources/CNativeSchedule/include/NativeSchedule.h').read_text();s=replace(s,'void *ss_schedule_plan(', 'void ss_dependency_mark(uint32_t phase);\nvoid *ss_schedule_plan(');save('Sources/CNativeSchedule/include/NativeSchedule.h',s)
s=(R/'Sources/Slotstream/Layers.swift').read_text();s='import CNativeSchedule\n'+s
for old,new in [
 ('            eval([routeIndices] + queue.arrays)','            ss_dependency_mark(40)\n            eval([routeIndices] + queue.arrays)\n            ss_dependency_mark(41)'),
 ('            queue.drain(waited: RuntimeClock.seconds(since: waitStart))','            queue.drain(waited: RuntimeClock.seconds(since: waitStart))\n            ss_dependency_mark(42)'),
 ('        let expertIds = routeIndices.asArray(Int32.self)  // B*S*topK','        ss_dependency_mark(43)\n        let expertIds = routeIndices.asArray(Int32.self)  // B*S*topK\n        ss_dependency_mark(44)'),
 ('            pool.advancePinGeneration()','            ss_dependency_mark(45)\n            pool.advancePinGeneration()\n            ss_dependency_mark(46)'),
 ('        let (B, S) = (x.dim(0), x.dim(1))\n        // Splash\'s long-chunk threshold:','        ss_dependency_mark(60)\n        let (B, S) = (x.dim(0), x.dim(1))\n        // Splash\'s long-chunk threshold:'),
 ('            let schedule = try NativeExpertSchedule.plan(hidden: cfg.hiddenSize, intermediate: cfg.moeIntermediate,','            ss_dependency_mark(61)\n            let schedule = try NativeExpertSchedule.plan(hidden: cfg.hiddenSize, intermediate: cfg.moeIntermediate,'),
 ('            let bindings = try pool.scheduledBindings(for: schedule)','            let bindings = try pool.scheduledBindings(for: schedule)\n            ss_dependency_mark(62)'),
 ('                let slots = expertIds.map { Int32(slotOf[seen[ExpertKey(self.layer, Int($0))]!]) }','                ss_dependency_mark(69)\n                let slots = expertIds.map { Int32(slotOf[seen[ExpertKey(self.layer, Int($0))]!]) }\n                ss_dependency_mark(70)'),
 ('                if awaitingReads, nativePrerequisite != nil { self.sharedPrelaunches += 1 }','                if awaitingReads, nativePrerequisite != nil { self.sharedPrelaunches += 1 }\n                ss_dependency_mark(80)'),
]:s=replace(s,old,new)
save('Sources/Slotstream/Layers.swift',s)
s=(R/'Sources/Slotstream/ExpertStore.swift').read_text();s='import CNativeSchedule\n'+s
for old,new in [
 ('        guard supportsScheduledDemand, currentPoolBases() != nil else {','        ss_dependency_mark(63)\n        guard supportsScheduledDemand, currentPoolBases() != nil else {'),
 ('        let epoch = poolWriteEpoch','        ss_dependency_mark(64)\n        let epoch = poolWriteEpoch'),
 ('                            staging: (() -> NativeExpertSchedule.Staging?)? = nil) throws -> [Int] {','                            staging: (() -> NativeExpertSchedule.Staging?)? = nil) throws -> [Int] {\n        ss_dependency_mark(65)'),
 ('        if useAdaptive {\n            if adaptiveReplacement == nil','        ss_dependency_mark(66)\n        if useAdaptive {\n            if adaptiveReplacement == nil'),
 ('        func selectVictim(_ key: ExpertKey) throws -> Int {','        ss_dependency_mark(67)\n        func selectVictim(_ key: ExpertKey) throws -> Int {'),
 ('            if let prepare {\n                var planned = result','            if let prepare {\n                ss_dependency_mark(68)\n                var planned = result'),
]:s=replace(s,old,new)
save('Sources/Slotstream/ExpertStore.swift',s)
s=(R/'Sources/Slotstream/NativeExpertSchedule.swift').read_text()
for old,new in [
 ('        try autoreleasepool {\n            guard !ids.isEmpty','        ss_dependency_mark(71)\n        return try autoreleasepool {\n            guard !ids.isEmpty'),
 ('            let x = contiguous(input)','            ss_dependency_mark(72)\n            let x = contiguous(input)'),
 ('            let result = withExtendedLifetime((x, weightOwners, prerequisite, forecastArena, stream)) {','            ss_dependency_mark(73)\n            let result = withExtendedLifetime((x, weightOwners, prerequisite, forecastArena, stream)) {'),
 ('            guard result == 0, let output, let job else {','            ss_dependency_mark(77)\n            guard result == 0, let output, let job else {'),
 ('            if !awaitingReads { ss_schedule_publish(job, true) }','            ss_dependency_mark(78)\n            if !awaitingReads { ss_schedule_publish(job, true) }'),
 ('            if awaitingReads || Self.earlySubmission { asyncEval(value) }','            if awaitingReads || Self.earlySubmission { asyncEval(value) }\n            ss_dependency_mark(79)'),
]:s=replace(s,old,new)
save('Sources/Slotstream/NativeExpertSchedule.swift',s)
(P/'replacements.json').write_text(json.dumps(rep,indent=2))
s=(D/'run.py').read_text().replace("'NS' if validation else 'NnSs'","'N' if validation else 'Nn'")
s=s.replace('Both instrumented engines match111full-logithashes','Instrumented native engine matches111full-logithashes')
(P/'run.py').write_text(s)
plan=dict(scope='Attribute the repeatable native pre-expert gap to actual host preparation phases. Diagnostic only; no arithmetic, I/O, ownership, schedule, controller or Fast production change.',evidence='q2-required-dependencies-20261026: clean control markers under1percent in both engines; every required payload joined. Native residual0.992/0.961s versusSplash0.334/0.327s. Native pre-expert encoder gaps before job creation0.390/0.379s.',protocol='One native validation111full-logithashes/proposals/selected against own frozenF. Fixed off/on native tracing with one warmup+two observed rounds,15GBphysical4067slots8192context,BF16/FP32. Same existing observers; new host markers only on. Two percent median sensitivity; preserve exclusions; no product speed claim.',source_revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),sources={n:hashlib.sha256((P/f).read_bytes()).hexdigest()for n,f in rep.items()},phases={40:'before router eval',41:'after router eval',42:'after deferred queue drain',43:'before route asArray',44:'after route asArray',45:'before pin advance',46:'after pin advance',60:'cached begin',61:'unique route list ready',62:'schedule bindings ready',63:'ensureScheduled begins',64:'pool bases checked',65:'ensureCore begins',66:'hit/miss maps and pin preparation done',67:'adaptive hit touches done',68:'victims claimed before prepare closure',69:'prepare closure enter',70:'route slot map ready',71:'schedule submit enter',72:'native tile grouping done',73:'C bridge inputs ready',74:'C bridge validation/stream ready',75:'C arrays/geometry checked',76:'C metadata arrays and staging ready',1:'C job ready',77:'C call returned',78:'pending staging metadata ready',79:'asyncEval returned',80:'prepare closure returns'})
(P/'plan.json').write_text(json.dumps(plan,indent=2));print('prepared',len(rep),'source inputs')
