import ArgumentParser
import Foundation
import CryptoKit
import MLX
import Slotstream

/// Diagnostic only: keep real proposal/target/selection/rollback work while
/// teacher-forcing recorded target inputs and accepted prefixes. No policy or
/// user-facing inference path changes. Validation hashes are outside timing mode.
struct Q2ProfileCheck: ParsableCommand {
    static let configuration = CommandConfiguration(commandName: "q2-profile")
    @Option var fixture: String
    @Option var output: String
    @Option var memoryGB: Double = 15
    @Option var rounds: Int = 3
    @Flag var validate = false
    struct Step: Decodable { let position: Int; let tokens: [Int]; let kept: Int }
    struct Fixture: Decodable { let prompt_ids: [Int]; let steps: [Step] }
    func run() throws {
        guard memoryGB == 15, (1...3).contains(rounds), !FileManager.default.fileExists(atPath: output) else { throw ValidationError("Use frozen 15GB settings, 1–3 rounds and a new output") }
        let input=try JSONDecoder().decode(Fixture.self,from:Data(contentsOf:URL(fileURLWithPath:fixture)))
        guard (1...256).contains(input.prompt_ids.count), (1...512).contains(input.steps.count), input.prompt_ids.allSatisfy({(0..<248320).contains($0)}) else {throw ValidationError("Invalid bounded fixture")}
        var position=input.prompt_ids.count
        for s in input.steps {
            guard s.position==position,(1...8).contains(s.tokens.count),(1...s.tokens.count).contains(s.kept),s.tokens.allSatisfy({(0..<248320).contains($0)}) else {throw ValidationError("Invalid frozen step")}
            position+=s.kept
        }
        let machine=Machine.current()
        guard (machine.availableGB ?? 0)>=18 else {throw ModelError("18GB reclaimable required")}
        let plan=try Planner.plan(resources:.q2,expertsPerLayer:nil,poolGB:nil,memoryGB:memoryGB,
            ramGB:machine.ramGB,workingSetGB:machine.workingSetGB,availableGB:machine.availableGB,
            mtp:.off,mtpAvailable:false,vision:.off,visionAvailable:false,maxContextTokens:8192,
            qualification:false,decodeLookahead:.reserved(bytes:NativeInputReadAhead.reserveBytes),mtpExperts:.automatic)
        let sem=DispatchSemaphore(value:0);var outcome:Result<Void,Error> = .success(())
        Task {
            do {
                let engine=try await Engine(modelDir:ModelLocator.resolve("smart-q2"),plan:plan)
                let model=engine.model
                guard let draft=model.dflash,plan.slots==4067 else {throw ModelError("Missing draft or mismatched cache")}
                var reports:[[String:Any]]=[]
                for round in 0..<rounds {
                    model.lookahead?.requestFinished();model.lookahead=nil
                    model.beginDraftCapture()
                    let state=model.makeState()
                    eval(try model.lastLogitsChecked(input.prompt_ids,state:state))
                    guard let features=model.draftPrefillFeatures ?? model.draftFeatures,features.end==state.tokenCount else {throw ModelError("Missing prefill draft context")}
                    model.accumulatingDraftPrefill=false
                    let context=DFlashDraft.Context()
                    draft.append(features.rows,endingAt:features.end,to:context)
                    model.draftPrefillFeatures=nil
                    try model.enableNativeInputReadAhead(reservedBytes:plan.lookaheadReserveBytes)
                    var rows:[[String:Any]]=[]
                    let requestStart=RuntimeClock.now()
                    for (index,step) in input.steps.enumerated() {
                        guard state.tokenCount==step.position else {throw ModelError("Frozen target/draft context moved")}
                        let checkpoint=state.checkpoint();state.setRecording(true)
                        model.pool.resetStats();model.lookahead?.prefetch?.resetObservation()
                        let scheduled=model.nativeExpertScheduledPasses,forecast=model.nativeGPUForecastRecords
                        let started=RuntimeClock.now()
                        let guesses=try draft.propose(anchor:step.tokens[0],depth:7,target:model,context:context,captureConfidence:true)
                        guard guesses.count==7,draft.proposalConfidence.count==7 else {throw ModelError("Real proposal not executed")}
                        let proposed=RuntimeClock.now()
                        model.lookahead?.beginPass(phase:.mainVerify,tokens:step.tokens,features:[])
                        let result=try model.allLogitsWithMultiChecked(step.tokens,state:state)
                        eval(result.logits)
                        let verified=RuntimeClock.now()
                        // Execute ordinary greedy decisions, then discard them for
                        // the frozen accepted-prefix control. Store the real IDs.
                        var selected:[Int]=[]
                        for row in 0..<step.kept {selected.append(argMax(result.logits[0...,row..<(row+1),0...]).item(Int.self))}
                        let sampled=RuntimeClock.now()
                        guard let captured=model.draftFeatures,captured.end==step.position+step.tokens.count else {throw ModelError("Missing target capture")}
                        try state.rollbackChecked(keeping:step.kept,of:step.tokens,from:checkpoint,ngramWindow:model.cfg.ngramSize-1)
                        model.lookahead?.passReconciled(kept:step.kept);model.lookahead?.endPass()
                        draft.append(captured.rows[0...,0..<step.kept,0...],endingAt:state.tokenCount,to:context)
                        let ended=RuntimeClock.now()
                        var row:[String:Any]=["round":round,"step":index,"width":step.tokens.count,"kept":step.kept,
                            "start_ns":started,"end_ns":ended,"seconds":Double(ended-started)/1e9,
                            "draft_seconds":Double(proposed-started)/1e9,"verify_seconds":Double(verified-proposed)/1e9,
                            "sample_seconds":Double(sampled-verified)/1e9,"commit_seconds":Double(ended-sampled)/1e9,
                            "actual_guesses":guesses,"actual_selected":selected,"records_fetched":model.pool.recordsFetched,
                            "records_adopted":model.pool.recordsAdopted,"scheduled_passes":model.nativeExpertScheduledPasses-scheduled,
                            "gpu_forecast_records":model.nativeGPUForecastRecords-forecast]
                        if validate {
                            let values=result.logits.asType(.float32).asArray(Float.self)
                            row["logits_sha256"]=values.withUnsafeBytes{SHA256.hash(data:Data($0)).map{String(format:"%02x",$0)}.joined()}
                        }
                        rows.append(row)
                    }
                    let requestEnd=RuntimeClock.now()
                    model.lookahead?.requestFinished();model.endDraftCapture()
                    guard ProcessMemory.peakResidentGB<=memoryGB,(ProcessMemory.vmActivity()?.reclaimableBytes ?? 0)>1_000_000_000 else {throw ModelError("Physical ceiling or headroom exceeded")}
                    reports.append(["round":round,"start_ns":requestStart,"end_ns":requestEnd,"seconds":Double(requestEnd-requestStart)/1e9,"steps":rows])
                    let report:[String:Any]=["complete":round==rounds-1,"fixture":fixture,"validate":validate,"plan":plan.json(),"peak_gb":ProcessMemory.peakResidentGB,"rounds":reports,
                        "scope":"Teacher-forced cycle diagnostic with real seven-token draft proposals, fixed target inputs/width/retention, greedy decisions and actual target/draft state commits. No controller choices, tokenizer/server/streaming or product-speed claim. Validation full-logit readback is never a timing arm."]
                    try JSONSerialization.data(withJSONObject:report,options:[.prettyPrinted,.sortedKeys]).write(to:URL(fileURLWithPath:output),options:.atomic)
                    print("round \(round): \(rows.count) real proposal/target/commit cycles")
                }
            }catch {outcome = .failure(error)}
            sem.signal()
        }
        sem.wait();try outcome.get()
    }
}
