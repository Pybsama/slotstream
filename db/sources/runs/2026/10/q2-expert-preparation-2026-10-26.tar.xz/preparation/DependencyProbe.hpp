#pragma once
// Temporary diagnostic only. Never changes work, ordering or ownership.
#include <algorithm>
#include <array>
#include <atomic>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <mach/mach_time.h>
#include <pthread.h>
#include <unistd.h>
namespace ssdep {
constexpr size_t capacity=1048576;
struct Row {uint64_t time,thread,id,address,bytes,aux0,aux1;uint32_t kind,index;};
static_assert(sizeof(Row)==64);
inline Row rows[capacity];
inline std::atomic<size_t> count{0};
inline std::atomic<uint64_t> serial{0};
inline const char* prefix=nullptr;
inline thread_local uint64_t last_load=0;
inline uint64_t thread_id(){static thread_local uint64_t v=[] {uint64_t t=0;pthread_threadid_np(nullptr,&t);return t;}();return v;}
inline uint64_t next_id(){return prefix?serial.fetch_add(1,std::memory_order_relaxed)+1:0;}
inline void emit(uint32_t kind,uint64_t id,uint64_t address=0,uint64_t bytes=0,uint64_t aux0=0,uint64_t aux1=0,uint32_t index=0){
  if(!prefix || !id)return;
  const size_t n=count.fetch_add(1,std::memory_order_relaxed);
  if(n<capacity)rows[n]={mach_absolute_time(),thread_id(),id,address,bytes,aux0,aux1,kind,index};
}
inline void dump(){
  if(!prefix)return;char path[4096];const size_t n=count.load();
  if(snprintf(path,sizeof(path),"%s.%d.bin",prefix,getpid())>=int(sizeof(path)))return;
  FILE*f=fopen(path,"wbx");if(!f)return;const size_t wrote=fwrite(rows,sizeof(Row),std::min(n,capacity),f);fclose(f);
  if(snprintf(path,sizeof(path),"%s.%d.json",prefix,getpid())>=int(sizeof(path)))return;
  f=fopen(path,"wx");if(!f)return;mach_timebase_info_data_t t;mach_timebase_info(&t);
  fprintf(f,"{\"rows\":%zu,\"written\":%zu,\"cap\":%zu,\"row_bytes\":64,\"numer\":%u,\"denom\":%u,\"ids\":%llu,\"layout\":\"little-endian7uint64+2uint32:time,thread,id,address,bytes,aux0,aux1,kind,index\"}\n",n,wrote,capacity,t.numer,t.denom,(unsigned long long)serial.load());fclose(f);
}
struct Init {Init(){prefix=getenv("SLOTSTREAM_DEPENDENCY_OBSERVER");if(prefix)atexit(dump);}};
inline Init init;
struct LoadScope {
  uint64_t id=next_id();uint32_t block,rows,round,phase;
  LoadScope(uint32_t b,uint32_t r,uint32_t d,uint32_t p):block(b),rows(r),round(d),phase(p){last_load=id;emit(10,id,block,rows,round,phase);}
  ~LoadScope(){emit(11,id,block,rows,round,phase);}
};
}
