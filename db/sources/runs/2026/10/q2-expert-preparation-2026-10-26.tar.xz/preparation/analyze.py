from pathlib import Path
import ast,bisect,collections,csv,json,statistics,struct,subprocess
P=Path(__file__).resolve().parent;D=P.parent/'q2-required-dependencies-20261026'
assert not subprocess.run(['pgrep','-f',str(P/'native-build/candidate/slotstream')],capture_output=True,text=True).stdout.strip()
scope={'bisect':bisect,'collections':collections,'csv':csv,'PAGE':65536}
exec(compile(ast.Module(body=[n for n in ast.parse((D/'analyze_dependencies.py').read_text()).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))],type_ignores=[]),'analysis-defs','exec'),scope)
rows,footer,Coverage=map(scope.get,['csv_rows','footer','Coverage'])
ledger=json.loads((P/'trace-ledger.json').read_text());assert len(ledger)==2
label='trace-1-N';d=json.loads((P/(label+'.json')).read_text());meta=json.loads(next(P.glob(label+'-dependencies.*.json')).read_text());assert meta['rows']==meta['written']<meta['cap']
scale=meta['numer']/meta['denom']/1e9;marks=[]
for stamp,tid,id,address,size,a0,a1,kind,index in struct.iter_unpack('<7Q2I',next(P.glob(label+'-dependencies.*.bin')).read_bytes()):
 if kind>=40 or kind==1:marks.append(dict(time=stamp*scale,thread=tid,id=id,phase=kind))
marks.sort(key=lambda x:x['time']);names=json.loads((P/'plan.json').read_text())['phases']
stage_path=next(P.glob(label+'-commands.*.stages.csv'));foot=footer(stage_path);assert foot['cpu_initial']==foot['gpu_initial']and foot['cpu_final']==foot['gpu_final']
stages=list(rows(stage_path));assert all(int(r['gpu_end'])>int(r['gpu_start'])>0 for r in stages)
gpu=Coverage([(int(r['gpu_start'])/1e9,int(r['gpu_end'])/1e9)for r in stages])
windows=[(s['start_ns']/1e9,s['end_ns']/1e9,rd['round'],s['step'])for rd in d['rounds']for s in rd['steps']];starts=[x[0]for x in windows]
groups=[];pending=[];errors=[]
for m in marks:
 if m['phase']==40:pending=[m]
 elif m['phase']==43:
  if pending and pending[-1]['phase']==42:pending.append(m)
  else:pending=[m]
 elif pending:pending.append(m)
 if m['phase']!=80 or not pending:continue
 wi=bisect.bisect_right(starts,pending[0]['time'])-1
 if wi<0 or pending[0]['time']>=windows[wi][1]or windows[wi][2]==0:pending=[];continue
 w=windows[wi];phases=[x['phase']for x in pending]
 assert len(set(phases))==len(phases),(w,phases)
 assert all(k in phases for k in [43,44,45,46,60,61,62,63,64,65,66,67,69,70,71,72,73,74,75,76,1,77,78,79,80]),(w,phases)
 assert len(set(x['thread']for x in pending))==1
 timings=[]
 for a,b in zip(pending,pending[1:]):
  lo,hi=a['time'],b['time'];timings.append(dict(start=lo,end=hi,from_phase=a['phase'],to_phase=b['phase'],description=names[str(a['phase'])]+' -> '+names[str(b['phase'])],seconds=hi-lo,outside_gpu=max(0.,hi-lo-gpu.between(lo,hi))))
 groups.append(dict(round=w[2],step=w[3],job_id=next(x['id']for x in pending if x['phase']==1),timings=timings));pending=[]
summary=[]
for rd in (1,2):
 selected=[g for g in groups if g['round']==rd];assert len(selected)==111*48,(rd,len(selected))
 totals=collections.defaultdict(collections.Counter)
 for g in selected:
  for t in g['timings']:totals[t['description']].update(seconds=t['seconds'],outside_gpu=t['outside_gpu'],calls=1)
 report=dict(round=rd,seconds=d['rounds'][rd]['seconds'],jobs=len(selected),phases=sorted([dict(phase=k,**v)for k,v in totals.items()],key=lambda x:-x['outside_gpu']))
 summary.append(report);print(json.dumps(report,indent=2),flush=True)
med={e['dependencies']:statistics.median(r['seconds']for r in e['rounds']if r['round']>0)for e in ledger};control=dict(on=med[True],off=med[False],ratio=med[True]/med[False],within_two_percent=abs(med[True]/med[False]-1)<=.02)
(P/'analysis.json').write_text(json.dumps(dict(scope='Actual host boundaries around native expert preparation. Outside observed GPU counters is not proof of GPU idleness or guaranteed removable cost. Markers bracket real calls without changing their behavior. Same frozen full-cycle workload; Fast unchanged.',environment_eligible=all(e['eligible']for e in ledger),control=control,rounds=summary,jobs=groups),indent=2));print('CONTROL',control,flush=True)
