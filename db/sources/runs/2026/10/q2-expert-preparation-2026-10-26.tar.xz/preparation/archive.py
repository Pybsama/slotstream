from pathlib import Path
import fcntl,hashlib,io,json,os,re,subprocess,sys,tarfile
P=Path(__file__).resolve().parent;R=P.parents[1];D=P.parent/'q2-required-dependencies-20261026'
assert (P/'analysis.json').exists()and(D/'residual-analysis.json').exists()
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
preflight(4)
reservation=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(reservation,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert not subprocess.run(['pgrep','-f',str(D/'native-build/candidate/slotstream')+'|'+str(D/'upstream/full-cycle')+'|'+str(P/'native-build/candidate/slotstream')],capture_output=True,text=True).stdout.strip()
sha=lambda b:hashlib.sha256(b).hexdigest()
allowed=['.py','.swift','.h','.hpp','.cpp','.mm','.json','.jsonl','.csv','.log','.stderr','.txt','.bin']
secret=re.compile(rb'(?:ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{25,}|sk-(?:proj-)?[A-Za-z0-9_-]{30,}|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----)')
parts={'required-native':{},'required-splash':{},'expert-preparation':{}}
for prefix,root in [('required',D),('preparation',P)]:
 for f in root.rglob('*'):
  if not f.is_file()or any(n in f.parts for n in ['source-reference','__pycache__'])or f.name.startswith('archive-receipt')or(f.name.startswith('archive-')and f.suffix=='.log'):continue
  if f.suffix not in allowed:continue
  if f.suffix=='.bin'and'-dependencies.'not in f.name:continue
  part='expert-preparation'if root==P else ('required-splash'if f.name.startswith(('trace-2-S','trace-3-S','validation-1-S'))or'upstream'in f.relative_to(root).parts else 'required-native')
  parts[part][prefix+'/'+str(f.relative_to(root))]=f
for part,files in parts.items():
 receipt_path=P/('archive-receipt-'+part+'.json')
 if receipt_path.exists():
  receipt=json.loads(receipt_path.read_text());assert sha((R/receipt['path']).read_bytes())==receipt['sha256'];print('PRESERVE VERIFIED',part,flush=True);continue
 files['reference/v68-build-identity.json']=R/'.build/native-replay-20261023/v68/build-identity.json'
 files['reference/full-cycle-build-identity.json']=R/'.build/q2-full-cycle-20261025/native-build/candidate/build-identity.json'
 for n in ['copy_observer.cpp','named_stage_observer.mm']:files['reference/observers/'+n]=R/'.build/q2-sequence-20261025'/n
 files['reference/observers/read_observer.cpp']=R/'.build/q2-handoff-20261025/read_observer.cpp'
 files['reference/NativeSchedule.cpp']=R/'Sources/CNativeSchedule/NativeSchedule.cpp'
 files['reference/ExpertStore.swift']=R/'Sources/Slotstream/ExpertStore.swift'
 files['reference/NativeExpertSchedule.swift']=R/'Sources/Slotstream/NativeExpertSchedule.swift'
 files['reference/LICENSE']=R/'LICENSE'
 if part.startswith('required'):
  for n in ['runtime/model/ExpertStore.cpp','runtime/model/ExpertStore.hpp','runtime/model/SsdReaders.cpp','runtime/model/SsdReaders.hpp','LICENSE']:files['reference/splash/'+n]=D/'source-reference'/n
 manifest={}
 for n,f in files.items():
  b=f.read_bytes();assert not secret.search(b),n;manifest[n]=dict(bytes=len(b),sha256=sha(b))
 dest=R/'db/sources/runs/2026/10'/('q2-'+part+'-2026-10-26.tar.xz');assert not dest.exists();raw=json.dumps(manifest,indent=2).encode()
 print('ARCHIVING',part,len(files),sum(x['bytes']for x in manifest.values()),flush=True)
 with tarfile.open(dest,'w:xz',preset=3)as t:
  for n,f in sorted(files.items()):t.add(f,arcname=n,recursive=False)
  info=tarfile.TarInfo('archive-manifest.json');info.size=len(raw);t.addfile(info,io.BytesIO(raw))
 seen={}
 with tarfile.open(dest,'r|xz')as t:
  for m in t:
   b=t.extractfile(m).read()
   if m.name=='archive-manifest.json':assert json.loads(b)==manifest
   else:seen[m.name]=dict(bytes=len(b),sha256=sha(b))
 assert seen==manifest
 assert dest.stat().st_size<100_000_000
 receipt=dict(path=str(dest.relative_to(R)),files=len(manifest),bytes=dest.stat().st_size,sha256=sha(dest.read_bytes()),readback_verified=True,credential_pattern_matches=0,excluded='Executables, libraries, weights, pycache, complete source archives and recovered Splash clone/git. Binary members are bounded dependency/phase records containing no tensor payload.')
 (P/('archive-receipt-'+part+'.json')).write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt),flush=True)
