from pathlib import Path
import json
P=Path(__file__).resolve().parent;R=P.parents[1]
S=Path('/var/folders/d4/t1c8ltbx5s3_11cs9y6gjh8m0000gp/T/slotstream-splash-host-ugnf26pi/source')
U=P/'submission';U.mkdir(exist_ok=False)
src=(S/'runtime/metal/MetalBackend.mm').read_text()
assert 'kHostStepSpin = std::chrono::milliseconds(0)' in src
needle='''        hostStepRunner->add(steps, steps->steps.back());
        return next;'''
assert src.count(needle)==1
replacement='''        hostStepRunner->add(steps, steps->steps.back());
        // Diagnostic ablation: retain actual kernels and reads, but do not
        // encode the following GPU segment while this host step is running.
        // The unchanged runner still owns reads and the event signal.
        static const bool serialHost = std::getenv("Q2_SERIAL_HOST_ENCODING") != nullptr;
        if (serialHost) {
            const auto deadline = AwakeClock::now() + std::chrono::seconds(30);
            while (![steps->ranEvent waitUntilSignaledValue:ready timeoutMS:10]) {
                if (AwakeClock::now() >= deadline)
                    failEncoding("diagnostic host encoding wait timed out");
            }
        }
        return next;'''
(U/'MetalBackend.mm').write_text(src.replace(needle,replacement))
(U/'MetalBackend-original.mm').write_text(src)
(P/'submission-plan.json').write_text(json.dumps(dict(hypothesis='Splash can encode and queue subsequent useful GPU work while its existing runner fetches experts. Native advances layers around synchronous router and demand-read boundaries. Does removing that encoding overlap from Splash explain a meaningful fraction of the frozen-sequence gap?',scope='Upstream-only diagnostic ablation, one identical binary with an env flag. Kernels, arithmetic, cache capacity, reads and dedicated runner unchanged. B waits for host-step completion before encoding following segments. A normal scheduling. CPU polling remains zero and GPU spin library absent. ABBA, 111 captured code passes, two rounds with first warmup, 15GB/4067slots. Not a parity claim against a modified competitor.',limits='This delays all host boundaries, including fully cached steps. It tests whether scheduling depth matters, not whether native can attain the same depth or whether all original differences have been isolated. No production change or clock manipulation.',required='All full FP32 logit hashes exact across arms; all clean eligibility guards; compare to unmodified upstream fixture. A meaningful slowdown warrants native useful-work scheduling investigation; no slowdown rules out this specific queueing hypothesis.'),indent=2))
runner=(P/'run_gdn_order.py').read_text()
runner=runner.replace("if arm!='S':env+=['--env','Q2_PENDING_LOAD_ORDER='+('1'if arm=='B'else'0'),'--env','DYLD_INSERT_LIBRARIES='+str(P/'gdn_load_order.dylib'),'--env','Q2_GDN_SOURCE_DIR='+str(P/'gdn-sources')]", "if arm=='B':env+=['--env','Q2_SERIAL_HOST_ENCODING=1']")
runner=runner.replace("if arm!='S':",'if False:')
runner=runner.replace("str(P/'upstream/fixed-verify')", "str(P/'submission/fixed-verify')")
runner='\n'.join(l for l in runner.splitlines() if "if arm=='B':assert 'changed=0'" not in l)+'\n'
(P/'run_submission.py').write_text(runner)
clock=(P/'run_gdn_clock.py').read_text().replace("label='gdn-order'","label='submission'").replace('run_gdn_order.py','run_submission.py').replace("'ABSSBA'","'ABBA'")
(P/'run_submission_clock.py').write_text(clock)
analysis=(P/'analyze_protocol.py').read_text().replace("native=event['arm']!='S'","native=False")
analysis=analysis.replace("if all(a in medians for a in ['A','B','S']):result.update(candidate_over_native=medians['B']/medians['A'],candidate_over_Splash=medians['B']/medians['S'])", "result.update(serial_over_normal=medians['B']/medians['A'])")
(P/'analyze_submission.py').write_text(analysis)
print('Prepared isolated source, protocol and runner')
