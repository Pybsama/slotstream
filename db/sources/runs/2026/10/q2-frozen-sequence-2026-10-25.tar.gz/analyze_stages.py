from pathlib import Path
import json,csv,bisect,statistics,sys
P=Path(__file__).resolve().parent;results=[]
for arm in ['N','S']:
 files=list(P.glob('stages-*-'+arm+'.json'))
 for f in files:
  d=json.loads(f.read_text());label=f.stem;sf=next(P.glob(label+'-commands.*.stages.csv'));lines=sf.read_text().splitlines();footer=dict(x.split('=')for x in lines[-1][2:].split());assert int(footer['total'])<int(footer['cap']);assert footer['cpu_initial']==footer['gpu_initial'] and footer['cpu_final']==footer['gpu_final']
  ss=[dict(encoded=float(x['encoded']),start=int(x['gpu_start'])/1e9,end=int(x['gpu_end'])/1e9)for x in csv.DictReader(l for l in lines if not l.startswith('#'))];ss.sort(key=lambda x:x['encoded']);starts=[x['encoded']for x in ss];rows=[]
  for r in d['runs']:
   if r['round']!=1:continue
   lo,hi=(r['start_ns']/1e9,r['end_ns']/1e9)if arm=='N'else(r['start'],r['end'])
   stages=ss[bisect.bisect_left(starts,lo):bisect.bisect_left(starts,hi)]
   assert all(s['end']>s['start']>0 for s in stages)
   durations=[(s['end']-s['start'])*1000 for s in stages]
   row=dict(step=r['step'],width=r['width'],wall_ms=r['seconds']*1000,count=len(stages),stage_sum_ms=sum(durations))
   if arm=='N' and len(stages)==147:
    row.update(resident_ms=sum(durations[0:144:3]),route_ms=sum(durations[1:144:3]),expert_ms=sum(durations[2:144:3]),tail_ms=sum(durations[144:]),resident_layers=durations[0:144:3],expert_layers=durations[2:144:3])
   rows.append(row)
  summary={k:sum(r.get(k,0)for r in rows)for k in ['wall_ms','stage_sum_ms']+(['resident_ms','route_ms','expert_ms','tail_ms']if arm=='N'else[])}
  results.append(dict(label=label,arm=arm,summary=summary,passes=rows));print(label,summary)
(P/'stages-analysis.json').write_text(json.dumps(results,indent=2))
