from pathlib import Path
import json,collections,hashlib,shutil
P=Path(__file__).resolve().parent;R=P.parents[1];PREV=R/'.build/q2-typical-20261025'
d=json.loads((PREV/'normal-native.json').read_text())
for r in d['runs'][2:]:
 groups=collections.defaultdict(list)
 for e in r['trace']:groups[e['pass']].append(e)
 steps=[];history=list(r['prompt_ids'])
 for p,es in sorted(groups.items()):
  start=next((e for e in es if e['kind']=='verify_start'),None)
  end=next((e for e in es if e['kind']=='reconciled'),None)
  if not start:continue
  assert end and len(history)==start['position'] and start['tokens'][:len(end['kept'])]==end['kept']
  steps.append(dict(pass_id=p,position=len(history),tokens=start['tokens'],kept=len(end['kept'])))
  history.extend(end['kept'])
 assert history[len(r['prompt_ids']):]==r['tokens'][:len(history)-len(r['prompt_ids'])]
 fixture=dict(source=str(PREV/'normal-native.json'),source_sha256=hashlib.sha256((PREV/'normal-native.json').read_bytes()).hexdigest(),source_request=r['id'],prompt_ids=r['prompt_ids'],steps=steps,output_ids=r['tokens'],scope='Frozen verification inputs from instrumented full request. No sampling/controller/draft proposals. Natural cache evolution; routes may differ between engines.')
 (P/(r['id']+'.json')).write_text(json.dumps(fixture,indent=2))
 print(r['id'],len(steps),len(history),collections.Counter(len(s['tokens'])for s in steps))
D=P/'upstream';D.mkdir(exist_ok=True)
shutil.copytree(PREV/'upstream/include',D/'include',dirs_exist_ok=True)
for name in ['Runtime.cpp','ExpertStore.cpp','fixed_verify.mm']:
 shutil.copyfile(PREV/'upstream'/name,D/name)
r=(D/'Runtime.cpp').read_text();h=(D/'include/model/RuntimeInstrumentation.hpp').read_text()
h=h.replace('  // The PLE rows','  static double fixedCommit(Runtime &runtime, const ModelBatchItem &item, std::span<const uint32_t> tokens, uint32_t retained);\n  // The PLE rows',1)
commit='''
double RuntimeInstrumentation::fixedCommit(Runtime &runtime, const ModelBatchItem &item,
    std::span<const uint32_t> tokens, uint32_t retained) {
  if(!retained || retained>tokens.size()) throw std::invalid_argument("invalid frozen retention");
  auto now=[] {return double(AwakeClock::now().time_since_epoch().count())/1e9;};
  const auto start=now(); auto &impl=*runtime.impl_; auto &entry=impl.request(item.requestId);
  auto d=[&](DecodeTensor t) {return impl.decodeArena->batchSlice(t,1);};
  *contents<uint32_t>(d(DecodeTensor::RetainedCount),"frozen retained")=retained;
  Runtime::Impl::Request *request=&entry;
  std::span<Runtime::Impl::Request *const> entries(&request,1);
  std::span<const ModelBatchItem> items(&item,1);
  CommandGraph graph;
  impl.addRopeTables(graph,d(DecodeTensor::Positions),0,d(DecodeTensor::DraftPositions),8,
      d(DecodeTensor::RopeCos),d(DecodeTensor::RopeSin),d(DecodeTensor::DraftRopeCos),d(DecodeTensor::DraftRopeSin));
  impl.encodeTargetStateCommit(graph,entries);
  impl.encodeDraftStateCommitBatch(graph,entries,items);
  impl.backend.submitCommandAsync(graph.command()).wait();
  impl.states.swapDecodeParity(entry.stateLane,retained);
  const auto nextLength=item.logicalPosition+retained;
  impl.states.updateLengths(entry.stateLane,
      advanceDraftContext(impl.states.metadata(entry.stateLane).lengths,nextLength,item.logicalPosition,nextLength,false,false));
  // Teacher forcing: append the known consumed input prefix. No sample or budget update.
  entry.tokens.insert(entry.tokens.end(),tokens.begin(),tokens.begin()+retained);
  entry.pendingToken=tokens.front();
  return now()-start;
}
'''
r=r.replace('#endif\n} // namespace splash::model',commit+'#endif\n} // namespace splash::model')
(D/'Runtime.cpp').write_text(r);(D/'include/model/RuntimeInstrumentation.hpp').write_text(h)
m=(D/'fixed_verify.mm').read_text();m='#include <CommonCrypto/CommonDigest.h>\n'+m
m=m.replace('request.maxNewTokens = 256;','request.maxNewTokens = 512;').replace('(promptTokens + 256 +','(promptTokens + 512 +')
start=m.index('      prefill(executor,lanes[0],prompt);');end=m.index('      executor.end(lanes[0].id);',start)
m=m[:start]+'''      auto *store=model.expertStore(); if(!store) throw std::runtime_error("missing expert store");
      const auto storeStats=store->stats();
      std::printf("CONFIG slots=%llu arena=%llu staging=%llu\\n",(unsigned long long)storeStats.slots,
        (unsigned long long)storeStats.arenaBytes,(unsigned long long)storeStats.stagingBytes);
      store->diagnosticReadAhead(std::getenv("Q2_SEQUENCE_AHEAD") == nullptr || std::string(std::getenv("Q2_SEQUENCE_AHEAD"))!="0");
      for(uint32_t round=0;round<cycles;++round) {
        prefill(executor,lanes[0],prompt);
        uint32_t step=0;
        for(NSDictionary *row in fixture[@"steps"]) {
          tokens.clear();for(NSNumber *n in row[@"tokens"])tokens.push_back(n.unsignedIntValue);
          const uint32_t retained=[row[@"kept"] unsignedIntValue];
          if(lanes[0].position!=[row[@"position"] unsignedLongLongValue])throw std::runtime_error("frozen position mismatch");
          ModelBatchItem item{lanes[0].id,lanes[0].position,0,lanes[0].pages,lanes[0].pageTableRevision};
          (void)store->diagnosticTakeRoutes();(void)store->diagnosticTakeReads();
          const auto before=store->stats().uses[1];
          const auto timing=model::RuntimeInstrumentation::fixedVerify(executor,item,tokens);
          const auto after=store->stats().uses[1];
          const auto logits=model::RuntimeInstrumentation::lastLogits(executor,0).first(tokens.size()*model.geometry().target.vocabularySize);
          unsigned char digest[CC_SHA256_DIGEST_LENGTH];CC_SHA256(logits.data(),CC_LONG(logits.size_bytes()),digest);
          std::string hash;char hex[3];for(auto b:digest){snprintf(hex,sizeof(hex),"%02x",b);hash+=hex;}
          const auto commit=model::RuntimeInstrumentation::fixedCommit(executor,item,tokens,retained);
          std::printf("ROW %u %u %zu %u %.9f %.9f %.9f %.9f %.9f %.9f %.9f %llu %llu %llu %.9f %.9f %.9f %s\\n",
            round,step,tokens.size(),retained,timing.start,timing.prepared,timing.submitted,timing.ended,timing.gpu,timing.host,commit,
            (unsigned long long)(after.read-before.read),(unsigned long long)(after.prefetched-before.prefetched),
            (unsigned long long)(after.readBytes-before.readBytes),
            (after.pickup.totalMilliseconds-before.pickup.totalMilliseconds)/1000,
            (after.work.totalMilliseconds-before.work.totalMilliseconds)/1000,
            (after.resume.totalMilliseconds-before.resume.totalMilliseconds)/1000,hash.c_str());
          lanes[0].position+=retained;++step;
        }
        executor.end(lanes[0].id);std::fflush(stdout);
      }
''' +m[end:]
m=m.replace('      executor.end(lanes[0].id);\n      return 0;','      return 0;')
# Same target vocabulary geometry as the validated fixed driver.
m=m.replace('model.geometry().target.vocabularySize','248320')
(D/'fixed_verify.mm').write_text(m)
(P/'build_upstream.py').write_text((PREV/'build_upstream.py').read_text())
