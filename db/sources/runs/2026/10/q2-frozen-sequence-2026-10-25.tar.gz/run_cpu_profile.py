from pathlib import Path
import subprocess,sys,time,json,os
P=Path(__file__).resolve().parent;R=P.parents[1];sys.path.insert(0,str(R/'Tools'));from prefill_bench import terminate_child_tree
label='cpu-profile';cmd=[sys.executable,str(P/'run_sequence.py'),'--label',label,'--order','N','--fixture','timed-2','--rounds','2'];children=[]
(P/(label+'-plan.json')).write_text(json.dumps(dict(question='Locate user-space CPU work during frozen natural-cache verification; native process consumes about 4.9 CPU seconds against 0.7 Splash in ~12/9.6s windows. Profile is diagnostic only.',command=cmd),indent=2))
with(P/(label+'-driver.log')).open('x')as log:
 try:
  c=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);children.append(c)
  deadline=time.monotonic()+500;receipt=P/(label+'-0-N.json')
  while not receipt.exists() and c.poll()is None and time.monotonic()<deadline:time.sleep(.15)
  if not receipt.exists():raise RuntimeError('No first round receipt')
  assert not json.loads(receipt.read_text())['complete']
  found=subprocess.check_output(['pgrep','-f',str(P/'native-build-v3/candidate/slotstream')+' q2-profile'],text=True).split()
  assert len(found)==1,found
  s=subprocess.Popen(['sample',found[0],'10','5','-file',str(P/(label+'-sample.txt'))],stdout=log,stderr=subprocess.STDOUT,start_new_session=True);children.append(s)
  s.wait(timeout=30);c.wait(timeout=180)
 finally:
  for c0 in reversed(children):
   if c0.poll()is None:terminate_child_tree(c0)
raise SystemExit(c.returncode)
