import Foundation
for round in 0..<200 {
  let n=[0,1,2,3,7,17,31,32,33,80][round % 10]
  let lock=NSLock();var seen=Array(repeating:0,count:n)
  DispatchQueue.concurrentPerform(iterations:n){ i in
    if i % 7 == 0 { usleep(30) }
    lock.lock();seen[i]+=1;lock.unlock()
  }
  precondition(seen.allSatisfy{$0==1})
}
print("synchronous noescape and exactly-once callbacks: 200 rounds passed")
