from pathlib import Path
import re,subprocess,json,difflib
P=Path(__file__).resolve().parent;R=P.parents[1];D=P/'padded-src';D.mkdir(exist_ok=False)
patch=(P.parent/'q2-handoff-20261025/aligned.patch').read_text();paths=re.findall(r'^--- a/(.*)$',patch,re.M)
for path in paths:
 f=D/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes((R/path).read_bytes())
r=subprocess.run(['patch','-p1','-d',str(D)],input=patch,text=True,capture_output=True);(P/'padded-base-application.json').write_text(json.dumps(dict(code=r.returncode,out=r.stdout,err=r.stderr),indent=2));assert r.returncode==0

def edit(path,old,new):
 f=D/path;s=f.read_text();assert s.count(old)==1,(path,s.count(old),old[:80]);f.write_text(s.replace(old,new))
C='Sources/CNativeSchedule/NativeSchedule.cpp';H='Sources/CNativeSchedule/include/NativeSchedule.h';N='Sources/Slotstream/NativeExpertSchedule.swift';E='Sources/Slotstream/ExpertStore.swift';F='Sources/Slotstream/ExpertPrefetch.swift'
edit(C,'  int staged = 0;','  int staged = 0;\n  int staging_stride = 0, staging_piece_bytes = 0;')
edit(C,'    staged = count; ready.data<uint32_t>()[1] = count;','    staged = count; ready.data<uint32_t>()[1] = count;\n    staging_piece_bytes=piece_bytes; staging_stride=((piece_bytes+16383)/16384+1)*16384;')
edit(C,'raw.emplace_back(allocator::malloc(size_t(count) * piece_bytes), Shape{count, piece_bytes}, uint8);','raw.emplace_back(allocator::malloc(size_t(count) * staging_stride), Shape{count, staging_stride}, uint8);')
needle='void *ss_schedule_stage_base(void *j, int piece) {'
edit(C,needle,'''int ss_schedule_stage_stride(void *j) {
  if (!j) return 0;
  auto& work=**static_cast<std::shared_ptr<Job> *>(j);
  return work.staged && !work.published.load(std::memory_order_acquire)?work.staging_stride:0;
}
int ss_schedule_stage_offset(void *j, int index, int piece, int offset) {
  try {
    if(!j)throw std::invalid_argument("Missing staged job");
    auto& work=**static_cast<std::shared_ptr<Job> *>(j);
    if(work.published.load(std::memory_order_acquire) || index<0 || index>=work.staged || piece<0 || piece>=3 ||
       offset<0 || offset>=16384 || offset>work.staging_stride-work.staging_piece_bytes ||
       work.mask->data<int32_t>()[index]!=0)throw std::invalid_argument("Invalid raw staging offset");
    work.sources->data<int32_t>()[index*4+piece+1]=offset;
    return 0;
  }catch(const std::exception& e){last_error=e.what();return 1;}
}
'''+needle)
edit(H,'void *ss_schedule_stage_base(void *job, int piece);','int ss_schedule_stage_stride(void *job);\nint ss_schedule_stage_offset(void *job, int index, int piece, int offset);\nvoid *ss_schedule_stage_base(void *job, int piece);')
edit(N,'package static let gpuStagingReserveBytes = 110_592_000','package static let gpuStagingReserveBytes = 80 * (3 * 491_520 + 5 * 4)')
edit(N,'stagedSlots.count * 3 * hidden * intermediate / 64 * 18 <= Self.gpuStagingReserveBytes','stagedSlots.count * (3 * ((hidden * intermediate / 64 * 18 + 16383) / 16384 + 1) * 16384 + 5 * 4) <= Self.gpuStagingReserveBytes')
edit(N,'size_t source=predicted?size_t(sources[expert*4])*forecast_stride+size_t(sources[expert*4+piece+1]):size_t(expert)*raw_stride;','size_t source=(predicted?size_t(sources[expert*4]):size_t(expert))*forecast_stride+size_t(sources[expert*4+piece+1]);')
edit(N,'        package let bases: [UnsafeMutableRawPointer]','        package let bases: [UnsafeMutableRawPointer]\n        package let stride: Int')
edit(N,'            self.ticket = ticket\n            self.forecastArena = forecastArena','            self.ticket = ticket\n            self.stride = Int(ss_schedule_stage_stride(ticket.handle))\n            guard stride > 0 else { throw ModelError("Invalid native staging stride") }\n            self.forecastArena = forecastArena')
edit(N,'        package func markCopied(_ slots: [Int]) throws {','''        package func setOffset(index: Int, piece: Int, offset: Int) throws {
            guard ss_schedule_stage_offset(ticket.handle, Int32(index), Int32(piece), Int32(offset)) == 0 else {
                throw ModelError(String(cString: ss_schedule_error()))
            }
        }
        package func markCopied(_ slots: [Int]) throws {''')
edit(E,'    private var readHandles: [[TensorReadHandle]]?','''    package static let diagnosticAlignedDirect: Bool = {
        let enabled = ProcessInfo.processInfo.environment["SLOTSTREAM_Q2_ALIGNED_DIRECT"] == "1"
        if enabled { print("Q2_ALIGNED_DIRECT enabled=1") }
        return enabled
    }()
    private var readHandles: [[TensorReadHandle]]?''')
edit(E,'finishReaders: (() -> Void)? = nil, rawCopy: Bool = false) throws {','finishReaders: (() -> Void)? = nil, rawCopy: Bool = false, rawStaging: NativeExpertSchedule.Staging? = nil) throws {')
edit(E,'        let lanes = min(max(queueDepth, 1), jobs)\n        if let finishReaders {','''        let lanes = min(max(queueDepth, 1), jobs)
        if isQ2, rawCopy, let rawStaging, finishReaders == nil {
            // Both diagnostic arms use the same padded allocation. Only B
            // reads into it directly; A preserves the old scratch/copy work.
            let direct = Self.diagnosticAlignedDirect
            DispatchQueue.concurrentPerform(iterations: lanes) { lane in
                let acquired = direct ? nil : scratch.acquire()
                if !direct && acquired == nil { failure.record(ModelError("No demand scratch")); return }
                defer { if let acquired { scratch.release(acquired.0, temporary: acquired.1) } }
                var j = lane
                while j < jobs {
                    let (record, piece) = (j / pieceCount, j % pieceCount)
                    let key = keys[record], bytes = rowBytes[piece]
                    let destination = bases[piece] + slots[record] * rawStaging.stride
                    do {
                        try readFault?.beforeRead()
                        let handle = readHandles?[key.layer][piece] ?? index.readHandle(for: refs[key.layer][piece])
                        let buffer = direct ? destination : acquired!.0
                        let payload = try handle.readPageAlignedChecked(into: buffer,
                            capacity: direct ? rawStaging.stride : scratch.bytes, offset: key.expert * bytes, count: bytes)
                        if direct {
                            try rawStaging.setOffset(index: slots[record], piece: piece,
                                offset: destination.distance(to: UnsafeMutableRawPointer(mutating: payload)))
                        } else { memcpy(destination, payload, bytes) }
                    } catch { failure.record(error) }
                    j += lanes
                }
            }
            try failure.finish()
            return
        }
        if let finishReaders {''')
edit(E,'finishReaders: readersPending ? finishResidentReaders : nil, rawCopy: raw != nil)','finishReaders: readersPending ? finishResidentReaders : nil, rawCopy: raw != nil, rawStaging: raw)')
edit(F,'            if let arena = nativeForecastArena, arena.pageAligned {','            if ExpertStore.diagnosticAlignedDirect, let arena = nativeForecastArena, arena.pageAligned {')
# Diagnostic CLI has the same captured continuation and checks.
q=D/'Sources/slotstream-cli/Q2ProfileCommand.swift';q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes((P/'Q2ProfileCommand-v4.swift').read_bytes());paths.append(str(q.relative_to(D)))
(P/'padded-paths.json').write_text(json.dumps(paths,indent=2))
(P/'padded-reads.patch').write_text(''.join(''.join(difflib.unified_diff((R/f).read_text().splitlines(True),(D/f).read_text().splitlines(True),fromfile='a/'+f,tofile='b/'+f)) for f in paths))
(P/'padded-reads-plan.json').write_text(json.dumps(dict(hypothesis='Extra CPU staging copies causally slow upstream; direct unaligned native reads regress. Preserve page-aligned read extents while eliminating copies into both demanded and forecast Q2 staging.',scope='Q2-only candidate. Reuse the earlier checked forecast-padding experiment, add padded demand staging and per-piece payload offsets. Readiness gates, exact reads, failure handling and byte arithmetic unchanged. Padded A keeps copies; padded B reads directly. Both reserve the full larger demand staging before cache sizing, 117966400B versus110592000B; expected4062slots at15GB. Match Splash to4062. Fast raw staging absent and its path unchanged. Candidate stays diagnostic until full-request benefit.',required='Installed-source expert/pool failure, retry, resize, forecast and arithmetic checks with Metal validation; then clean ABSSBA111passcode with full FP32 hashes exact across arms and previous native fixture; at least2%repeatable improvement before complete requests.',limits='Additional padded buffers reduce cache by five slots at this budget. This is a matched-capacity diagnostic; keep earlier4067slot results separate. Forecast-only direct reads previously failed whole-request qualification, so the combined intervention needs its own complete-request evidence.'),indent=2))
print('prepared',len(paths),'files')
