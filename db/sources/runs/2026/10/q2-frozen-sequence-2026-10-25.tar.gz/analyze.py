from pathlib import Path
import json,statistics,collections,sys
P=Path(__file__).resolve().parent;label=sys.argv[1];fixture=json.loads((P/(sys.argv[2]+'.json')).read_text());ledger=json.loads((P/(label+'-ledger.json')).read_text())
result=dict(label=label,eligible=all(e.get('eligible')for e in ledger),arms=[])
rowsbyarm={}
for event in ledger:
 rows=json.loads((P/(event['label']+'.json')).read_text())['runs'];rowsbyarm.setdefault(event['arm'],[]).append(rows)
 timed=[r for r in rows if r['round']>0];bywidth={};byquarter={}
 for key,selector in [('width',lambda r:r['width']),('quarter',lambda r:min(3,r['step']*4//len(fixture['steps'])) )]:
  groups=collections.defaultdict(list)
  for r in timed:groups[selector(r)].append(r)
  dest=bywidth if key=='width'else byquarter
  for k,rs in groups.items():dest[k]=dict(passes=len(rs),mean_ms=statistics.mean(r['seconds']for r in rs)*1000,mean_demand=statistics.mean(r['records_fetched']for r in rs),mean_adopted=statistics.mean(r['records_adopted']for r in rs))
 trials=correct=0
 for row in rows:
  if row['round']!=0:continue
  step=fixture['steps'][row['step']]
  expected=step['tokens'][1:step['kept']]
  if row['step']+1<len(fixture['steps']):expected+=[fixture['steps'][row['step']+1]['tokens'][0]]
  trials+=len(expected);correct+=sum(x==y for x,y in zip(expected,row['top1']))
 result['arms'].append(dict(label=event['label'],arm=event['arm'],rounds=event.get('rounds'),widths=bywidth,quarters=byquarter,captured_next_token_agreement=dict(correct=correct,total=trials)))
if set(rowsbyarm)=={'N','S'}:
 n=rowsbyarm['N'][0];s=rowsbyarm['S'][0];n={r['step']:r for r in n if r['round']==0};s={r['step']:r for r in s if r['round']==0}
 agree=total=0
 for k in n:
  total+=len(n[k]['top1']);agree+=sum(x==y for x,y in zip(n[k]['top1'],s[k]['top1']))
 result['cross_engine_top1']=dict(correct=agree,total=total)
 def metric(arm):return statistics.mean(statistics.mean(r['seconds']for r in event['rounds']if r['round']>0)for event in ledger if event['arm']==arm)
 result['native_mean_seconds']=metric('N');result['splash_mean_seconds']=metric('S');result['native_over_splash']=metric('N')/metric('S')
(P/(label+'-analysis.json')).write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
