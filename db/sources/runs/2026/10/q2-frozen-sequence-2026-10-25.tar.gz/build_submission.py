from pathlib import Path
import json,subprocess,sys,hashlib,fcntl,os,time
P=Path(__file__).resolve().parent;R=P.parents[1];U=P/'submission'
S=Path('/var/folders/d4/t1c8ltbx5s3_11cs9y6gjh8m0000gp/T/slotstream-splash-host-ugnf26pi/source')
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
preflight(10);lock=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
obj=U/'MetalBackend.o'
commands=[['xcrun','-sdk','macosx','clang++','-std=c++20','-O3','-Wall','-Wextra','-Werror','-mmacosx-version-min=26.4','-fobjc-arc','-I'+str(S/'runtime'),'-I'+str(S/'runtime/metal'),'-DSPLASH_BACKEND_INSTRUMENTATION=1','-c',str(U/'MetalBackend.mm'),'-o',str(obj)]]
old=json.loads((P/'upstream/build-ledger.json').read_text())[-1]['command']
commands.append([str(obj)if x.endswith('/MetalBackendInstrumented.o')else str(U/'fixed-verify')if x==str(P/'upstream/fixed-verify')else x for x in old])
ledger=[]
for i,cmd in enumerate(commands):
 t=time.monotonic()
 with(U/f'build-{i}.log').open('x')as f:rc=subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT).returncode
 ledger.append(dict(command=cmd,exit_code=rc,seconds=time.monotonic()-t));(U/'build-ledger.json').write_text(json.dumps(ledger,indent=2));print(i,rc,flush=True)
 if rc:raise SystemExit(rc)
(U/'identity.json').write_text(json.dumps({f.name:hashlib.sha256(f.read_bytes()).hexdigest()for f in U.iterdir()if f.is_file()},indent=2))
