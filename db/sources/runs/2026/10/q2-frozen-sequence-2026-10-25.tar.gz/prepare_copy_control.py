from pathlib import Path
import json
P=Path(__file__).resolve().parent;R=P.parents[1];U=P/'copy-control';U.mkdir(exist_ok=False)
src=(P/'upstream/ExpertStore.cpp').read_text()
needle='    run.file->readFile(run.offset + piece.from, to);'
assert src.count(needle)==1
replacement='''    static const bool copyReads=std::getenv("Q2_COPY_READS")!=nullptr;
    if (copyReads) {
      // Diagnostic: native's demand/forecast path copies an aligned read
      // into GPU-readable staging. Give upstream the same extra copy while
      // leaving all original read extents, kernels and ownership unchanged.
      struct Scratch {
        void *data=nullptr;
        Scratch() { if (posix_memalign(&data,16384,kLoadStepBytes)!=0) throw std::bad_alloc(); }
        ~Scratch() { std::free(data); }
      };
      thread_local Scratch scratch;
      if(to.size()>kLoadStepBytes)throw std::logic_error("diagnostic copy bound");
      run.file->readFile(run.offset+piece.from,{static_cast<uint8_t*>(scratch.data),to.size()});
      std::memcpy(to.data(),scratch.data,to.size());
    } else { run.file->readFile(run.offset + piece.from, to); }'''
(U/'ExpertStore.cpp').write_text(src.replace(needle,replacement))
(P/'copy-control-plan.json').write_text(json.dumps(dict(hypothesis='Native demand and forecast paths read to aligned CPU scratch then copy payload into GPU-visible staging; Splash reads directly to staging. Test whether the extra CPU memory traffic explains the residual slowdown before implementing padded native staging.',scope='Same upstream binary in both arms. A original direct read; B one aligned thread-local scratch read plus memcpy per original read piece, preserving file checks/read extents/cache/arithmetic and the existing scheduler. 4MiB maximum scratch per used thread, actual15GBceiling/4067slots, ABBA,111capturedpasses,two roundsfirstwarmup. No native production edits or Fast changes.',limits='Splash original coalesced read pieces and padded page extents differ from native, so this is a causal sensitivity check for copying, not an exact native emulator or parity comparison. All output hashes must remain exact and whole protocol clean.'),indent=2))
runner=(P/'run_submission.py').read_text().replace('Q2_SERIAL_HOST_ENCODING=1','Q2_COPY_READS=1').replace("str(P/'submission/fixed-verify')","str(P/'copy-control/fixed-verify')")
(P/'run_copy_control.py').write_text(runner)
clock=(P/'run_submission_clock.py').read_text().replace("label='submission'","label='copy-control'").replace('run_submission.py','run_copy_control.py')
(P/'run_copy_clock.py').write_text(clock)
