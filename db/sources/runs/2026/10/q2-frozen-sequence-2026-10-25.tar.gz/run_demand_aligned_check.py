from pathlib import Path
import os,fcntl,subprocess,json,sys
P=Path(__file__).resolve().parent;R=P.parents[1]
lock=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
inner=P/'demand-aligned-check-child.lock';os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(inner)
cmd=[sys.executable,str(P/'quiet_guarded_run.py'),'--label','demand-aligned-check','--budget','10','--timeout','300','--env','SLOTSTREAM_MODEL_LOCK_PATH='+str(inner),'--env','SLOTSTREAM_Q2_ALIGNED_DIRECT=1','--env','MTL_DEBUG_LAYER=1','--',str(P/'native-demand-aligned-build/candidate/slotstream'),'q2-experts-check','--pool-model','smart-q2']
(P/'demand-aligned-check-command.json').write_text(json.dumps(cmd,indent=2))
with(P/'demand-aligned-check-launcher.log').open('x')as f:rc=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT).returncode
print('check exit',rc,flush=True)
if rc==0:assert 'Q2_ALIGNED_DIRECT enabled=1' in(P/'demand-aligned-check.log').read_text()
raise SystemExit(rc)
