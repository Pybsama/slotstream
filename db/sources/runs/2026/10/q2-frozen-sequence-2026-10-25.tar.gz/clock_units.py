import ctypes,time,resource,os,json,pathlib
class Timebase(ctypes.Structure):_fields_=[('numer',ctypes.c_uint32),('denom',ctypes.c_uint32)]
class U(ctypes.Structure):_fields_=[('uuid',ctypes.c_uint8*16)]+[(n,ctypes.c_uint64)for n in ('user_time','system_time','pkg_idle_wkups','interrupt_wkups','pageins','wired_size','resident_size','phys_footprint','proc_start_abstime','proc_exit_abstime','child_user_time','child_system_time','child_pkg_idle_wkups','child_interrupt_wkups','child_pageins','child_elapsed_abstime','diskio_bytesread','diskio_byteswritten')]
l=ctypes.CDLL('/usr/lib/libSystem.B.dylib');l.mach_absolute_time.restype=ctypes.c_uint64;tb=Timebase();l.mach_timebase_info(ctypes.byref(tb));ratio=tb.numer/tb.denom
p=ctypes.CDLL('/usr/lib/libproc.dylib');p.proc_pid_rusage.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.c_void_p]
u=U();p.proc_pid_rusage(os.getpid(),2,ctypes.byref(u));r=resource.getrusage(resource.RUSAGE_SELF)
mapping=dict(numer=tb.numer,denom=tb.denom,mach_seconds=l.mach_absolute_time()*ratio/1e9,unix=time.time(),python_monotonic=time.monotonic(),user_ticks=u.user_time,system_ticks=u.system_time,user_converted=u.user_time*ratio/1e9,system_converted=u.system_time*ratio/1e9,getrusage_user_s=r.ru_utime,getrusage_system_s=r.ru_stime)
pathlib.Path(__file__).with_name('clock-units.json').write_text(json.dumps(mapping,indent=2));print(mapping)
