#import <Foundation/Foundation.h>
#import <dispatch/dispatch.h>
#include <atomic>
#include <condition_variable>
#include <mutex>
#include <thread>
#include <vector>
#include <pthread/qos.h>
#include <dlfcn.h>
#include <cstdio>
#include <cstdlib>

// Diagnostic only: replace synchronous GCD apply with bounded dedicated readers.
// Same 1..32 lane callbacks, same Swift striding/read/copy/error code. No forecast
// scheduler rewrite. The caller also claims work, as Splash does.
namespace {
struct Batch {
 size_t count; dispatch_block_t unused=nullptr; void (^body)(size_t);
 std::atomic<size_t> next{0}; size_t done=0;
 std::mutex mutex; std::condition_variable ended;
 Batch(size_t n, void (^b)(size_t)):count(n),body(b){}
 // dispatch_apply is synchronous: all callbacks return before run returns.
 // Borrow the noescape block; never copy or retain its Swift closure.
 ~Batch()=default;
 void work(){ for(size_t i;(i=next.fetch_add(1,std::memory_order_relaxed))<count;){@autoreleasepool{body(i);}std::lock_guard<std::mutex> g(mutex);if(++done==count)ended.notify_all();} }
 void wait(){std::unique_lock<std::mutex> g(mutex);ended.wait(g,[&]{return done==count;});}
};
struct Pool {
 std::mutex submit,mutex;std::condition_variable wake;std::vector<std::thread> workers;
 std::shared_ptr<Batch> batch; bool stopped=false;uint64_t generation=0;
 std::atomic<size_t> calls{0};
 Pool(){workers.reserve(32);for(int i=0;i<32;i++)workers.emplace_back([this]{
  pthread_set_qos_class_self_np(QOS_CLASS_USER_INITIATED,0);uint64_t seen=0;
  for(;;){std::shared_ptr<Batch> current;{
   std::unique_lock<std::mutex> lock(mutex);wake.wait(lock,[&]{return stopped||seen!=generation;});
   if(stopped)return;seen=generation;current=batch;
  }current->work();}
 });}
 ~Pool(){{std::lock_guard<std::mutex> lock(mutex);stopped=true;}wake.notify_all();for(auto&t:workers)t.join();fprintf(stderr,"DEMAND_POOL calls=%zu readers=32\n",calls.load());}
 void run(size_t count,void(^body)(size_t)){
  std::lock_guard<std::mutex> serial(submit);auto next=std::make_shared<Batch>(count,body);
  {std::lock_guard<std::mutex> lock(mutex);batch=next;++generation;}++calls;
  if(count>1)wake.notify_all();next->work();next->wait();
  // Keep the published batch alive until the next generation; late awakened workers may still take it.
 }
};
}
extern "C" void diagnostic_apply(size_t count, dispatch_queue_t queue, void(^body)(size_t)) {
 if(count>0&&count<=32&&getenv("Q2_DEMAND_POOL")) {static Pool pool;pool.run(count,body);return;}
 if(!count)return;
 dispatch_apply_f(count,queue,(void*)body,[](void* context,size_t index){ ((void(^)(size_t))context)(index); });
}
__attribute__((used)) static struct {const void*replacement;const void*original;} mapping __attribute__((section("__DATA,__interpose")))={(const void*)&diagnostic_apply,(const void*)&dispatch_apply};
