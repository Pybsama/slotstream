import argparse, ast, json, re
from pathlib import Path

P = Path(__file__).resolve().parent
ap = argparse.ArgumentParser()
ap.add_argument('--label', default='copy-quality')
a = ap.parse_args()
left, right = [json.loads((P / (a.label + '-' + arm + '.json')).read_text()) for arm in 'AB']
assert left['complete'] and right['complete'] and left['draft_disabled'] and right['draft_disabled']
result = {'scope': json.loads((P / 'copy-quality-plan.json').read_text())['scope'], 'cases': []}
for old, new in zip(left['runs'], right['runs']):
    assert old['id'] == new['id']
    row = {'id': old['id'], 'exact': {key: old[key] == new[key] for key in
           ['prompt_ids', 'tokens', 'text', 'streamed', 'tool_calls', 'malformed_tool_call']},
           'successful_terminals': all(r['stats']['finishReason'] == 'stop' and not r['stats'].get('runtimeError') for r in [old, new]),
           'stream_matches_text': all(r['text'] == r['streamed'] for r in [old, new]),
           'peak_gb': [r['stats']['peakMemoryGB'] for r in [old, new]],
           'quality': {}}
    for arm, r in [('A', old), ('B', new)]:
        text = r['text'].strip()
        # Code fences affect instruction-following separately from executable content.
        plain = re.sub(r'^```(?:json|python)?\s*\n?|\n?```$', '', text).strip()
        q = {}
        try:
            if r['id'] == 'extract_invoice':
                value = json.loads(plain)
                q = {'correct_values': value == {'vendor': 'Cedar Tools', 'due_date': '2026-11-05', 'total': 148.50},
                     'only_json': text == plain}
            elif r['id'] == 'draft_delivery':
                q = {'manual_review_required': True, 'text': text}
            elif r['id'] == 'python_clamp':
                tree = ast.parse(plain)
                allowed = (ast.Module, ast.FunctionDef, ast.arguments, ast.arg, ast.Return,
                           ast.Call, ast.Name, ast.Load, ast.If, ast.Compare, ast.Lt, ast.Gt,
                           ast.LtE, ast.GtE, ast.IfExp, ast.Constant)
                bounded = (len(list(ast.walk(tree))) <= 100 and len(tree.body) == 1 and
                           isinstance(tree.body[0], ast.FunctionDef) and tree.body[0].name == 'clamp' and
                           [x.arg for x in tree.body[0].args.args] == ['value', 'low', 'high'] and
                           not tree.body[0].decorator_list and not tree.body[0].args.defaults and
                           all(isinstance(n, allowed) for n in ast.walk(tree)) and
                           all(isinstance(n.func, ast.Name) and n.func.id in ['min', 'max'] and not n.keywords for n in ast.walk(tree) if isinstance(n, ast.Call)))
                q = {'safe_bounded_ast': bounded, 'only_code': text == plain}
                if bounded:
                    ns = {'__builtins__': {}, 'min': min, 'max': max}
                    exec(compile(tree, '<reviewed-bounded-clamp>', 'exec'), ns)
                    cases = [(5, 0, 10, 5), (-2, 0, 10, 0), (20, 0, 10, 10),
                             (0, 0, 10, 0), (10, 0, 10, 10), (2, 3, 3, 3), (-4, -5, -2, -4), (.5, 0., 1., .5)]
                    q['independent_function_cases'] = [ns['clamp'](v, lo, hi) == want for v, lo, hi, want in cases]
            elif r['id'] == 'search_notes_tool':
                calls = r['tool_calls']
                args = json.loads(calls[0]['arguments_json']) if len(calls) == 1 else {}
                query = args.get('query', '')
                q = {'valid_call': len(calls) == 1 and calls[0]['name'] == 'search_notes' and
                     set(args) == {'query'} and isinstance(query, str) and 'dishwasher' in query.lower() and
                     'warranty' in query.lower() and not r['malformed_tool_call']}
        except Exception as exc:
            q['error'] = str(exc)
        row['quality'][arm] = q
    result['cases'].append(row)
result['exact_control_pass'] = all(all(r['exact'].values()) and r['successful_terminals'] and r['stream_matches_text'] and max(r['peak_gb']) <= 15 for r in result['cases'])
(P / (a.label + '-summary.json')).write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
