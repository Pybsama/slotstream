import argparse, fcntl, json, os, subprocess, sys
from pathlib import Path

P = Path(__file__).resolve().parent
R = P.parents[1]
ap = argparse.ArgumentParser()
ap.add_argument('--candidate', required=True)
ap.add_argument('--label', default='copy-quality')
ap.add_argument('--default', action='store_true')
a = ap.parse_args()
lock = open(f'/tmp/slotstream-model-{os.getuid()}.lock', 'a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
inner = P / (a.label + '-child.lock')
os.environ['SLOTSTREAM_MODEL_LOCK_PATH'] = str(inner)
events = []
for arm, binary in [('A', R / '.build/native-replay-20261023/v68/slotstream'), ('B', Path(a.candidate).resolve())]:
    label = a.label + '-' + arm
    output = P / (label + '.json')
    assert not output.exists()
    cmd = [sys.executable, str(P / 'quiet_guarded_run.py'), '--label', label,
           '--budget', '15', '--env', 'SLOTSTREAM_MODEL_LOCK_PATH=' + str(inner)]
    if arm == 'B' and not a.default:
        cmd += ['--env', 'SLOTSTREAM_Q2_ALIGNED_DIRECT=1']
    cmd += ['--', str(binary), 'smart-dflash-check', '--method', 'q2', '--model', 'smart-q2',
            '--memory-gb', '15', '--max-context', '8192', '--native-read-ahead', 'on',
            '--disable-draft', '--cases', str(P / 'copy-quality-cases.json'), '--output', str(output)]
    print('START', label, flush=True)
    with (P / (label + '-launcher.log')).open('x') as log:
        rc = subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT).returncode
    event = dict(arm=arm, command=cmd, exit_code=rc)
    events.append(event)
    (P / (a.label + '-ledger.json')).write_text(json.dumps(events, indent=2))
    print('END', label, rc, flush=True)
    if rc:
        raise SystemExit(rc)
