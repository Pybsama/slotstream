import json, statistics
from pathlib import Path

P = Path(__file__).resolve().parent
events = json.loads((P / 'padded-complete-15-ledger.json').read_text())
assert [e['arm'] for e in events] == list('ABCCBA')
result = dict(eligible=all(e['eligible'] for e in events),
              capacity_note='A frozen v68 has 4067 slots; B and Splash have 4062 slots. All have 15 GB total budgets. Padding is charged before cache sizing.', tasks={})
for task in ['timed-2', 'timed-3']:
    rows = {}
    for arm in 'ABC':
        runs = [next(r for r in e['runs'] if r['id'] == task) for e in events if e['arm'] == arm]
        rows[arm] = dict(request_seconds=[r['request_seconds'] for r in runs],
                         tps=[r['tps'] for r in runs],
                         median_request_seconds=statistics.median(r['request_seconds'] for r in runs),
                         median_tps=statistics.median(r['tps'] for r in runs))
    rows['candidate_over_baseline'] = rows['B']['median_request_seconds'] / rows['A']['median_request_seconds']
    rows['candidate_over_splash'] = rows['B']['median_request_seconds'] / rows['C']['median_request_seconds']
    rows['baseline_over_splash'] = rows['A']['median_request_seconds'] / rows['C']['median_request_seconds']
    rows['pair_candidate_over_baseline'] = [b / old for b, old in zip(rows['B']['request_seconds'], rows['A']['request_seconds'])]
    result['tasks'][task] = rows
result['retention_gate'] = result['eligible'] and all(t['candidate_over_baseline'] <= .98 and all(p < 1 for p in t['pair_candidate_over_baseline']) for t in result['tasks'].values())
result['goal_timing_gate'] = result['eligible'] and all(t['candidate_over_splash'] <= 1.05 for t in result['tasks'].values())
(P / 'padded-complete-15-summary.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
