from pathlib import Path
import json,csv,bisect,statistics,collections
P=Path(__file__).resolve().parent
ledger=json.loads((P/'observed-ledger.json').read_text());report=[]
def parse(path):
 with path.open()as f:
  lines=(l for l in f if not l.startswith('#'))
  return list(csv.DictReader(lines))
def union(xs):
 out=[]
 for lo,hi in sorted(xs):
  if hi<=lo:continue
  if not out or lo>out[-1][1]:out.append([lo,hi])
  else:out[-1][1]=max(hi,out[-1][1])
 return out
def total(xs):return sum(b-a for a,b in xs)
def overlap(a,b):
 i=j=0;result=0
 while i<len(a)and j<len(b):
  result+=max(0,min(a[i][1],b[j][1])-max(a[i][0],b[j][0]))
  if a[i][1]<b[j][1]:i+=1
  else:j+=1
 return result
for e in ledger:
 label=e['label'];data=json.loads((P/(label+'.json')).read_text());rows=[r for r in data['runs']if r['round']==1]
 rp=next(P.glob(label+'-reads.*.csv'));cp=next(P.glob(label+'-commands.*.csv'))
 for path in [rp,cp]:
  with path.open('rb')as f:
   f.seek(max(0,path.stat().st_size-200));tail=f.read().decode().splitlines()[-1]
  footer=dict(x.split('=')for x in tail[2:].split());assert int(footer['total'])<int(footer['cap'])
 reads=sorted([(float(r['start']),float(r['end']),int(r['bytes']),int(r['thread']),int(r['qos']))for r in parse(rp)if int(r['bytes'])>4096]);starts=[r[0]for r in reads]
 commands=sorted([(float(r['start']),float(r['end']),float(r['submitted']))for r in parse(cp)if int(r['status'])==4]);cstarts=[r[0]for r in commands]
 metrics=[]
 for r in rows:
  lo,hi=(r['start_ns']/1e9,r['end_ns']/1e9)if e['arm']=='N'else(r['start'],r['end'])
  rs=[x for x in reads[bisect.bisect_left(starts,lo-1):bisect.bisect_left(starts,hi)]if x[1]>lo]
  cs=[x for x in commands[bisect.bisect_left(cstarts,lo-1):bisect.bisect_left(cstarts,hi)]if x[1]>lo]
  ru=union([(max(lo,x[0]),min(hi,x[1]))for x in rs]);cu=union([(max(lo,x[0]),min(hi,x[1]))for x in cs]);ov=overlap(ru,cu)
  active=peak=0
  for _,delta in sorted([(max(lo,x[0]),1)for x in rs]+[(min(hi,x[1]),-1)for x in rs]):active+=delta;peak=max(peak,active)
  metrics.append(dict(step=r['step'],width=r['width'],wall_ms=(hi-lo)*1000,gpu_union_ms=total(cu)*1000,read_union_ms=total(ru)*1000,overlap_ms=ov*1000,uncovered_ms=((hi-lo)-total(cu)-total(ru)+ov)*1000,read_bytes=sum(x[2]for x in rs if x[0]>=lo),reads=len(rs),commands=len(cs),peak_read_concurrency=peak,read_mean_us=statistics.mean((x[1]-x[0])*1e6 for x in rs)if rs else 0))
 summary={k:sum(r[k]for r in metrics)for k in ['wall_ms','gpu_union_ms','read_union_ms','overlap_ms','uncovered_ms','read_bytes','reads','commands']}
 summary['peak_read_concurrency']=max(r['peak_read_concurrency']for r in metrics)
 report.append(dict(label=label,arm=e['arm'],eligible=e.get('eligible'),summary=summary,passes=metrics))
 print(label,summary,flush=True)
(P/'observed-analysis.json').write_text(json.dumps(report,indent=2))
