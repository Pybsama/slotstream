from pathlib import Path
import difflib, json

P = Path(__file__).resolve().parent
R = P.parents[1]
paths = ['Sources/Slotstream/NativeExpertSchedule.swift',
         'Sources/CNativeSchedule/NativeSchedule.cpp',
         'Sources/CNativeSchedule/include/NativeSchedule.h',
         'Sources/Slotstream/ExpertStore.swift',
         'Sources/slotstream-cli/Q2ProfileCommand.swift']
src = {f: (P / 'padded-src' / f).read_text() for f in paths}

def replace(path, before, after):
    assert src[path].count(before) == 1, (path, before)
    src[path] = src[path].replace(before, after)

f = paths[0]
replace(f, 'size_t source=(predicted?size_t(sources[expert*4]):size_t(expert))*forecast_stride+size_t(sources[expert*4+piece+1]);',
           'size_t source=predicted ? size_t(sources[expert*4])*raw_stride : size_t(expert)*forecast_stride+size_t(sources[expert*4+piece+1]);')
replace(f, 'Int32(lease.index), lease.offsets.map(Int32.init),', 'Int32(lease.index),')
f = paths[1]
replace(f, 'a.shape(1) != ((plan->hidden * plan->intermediate / 64 * 18 + 16383) / 16384 + 1) * 16384',
           'a.shape(1) != plan->hidden * plan->intermediate / 64 * 18')
replace(f, 'int index, int source, const int32_t *offsets, void *context', 'int index, int source, void *context')
replace(f, 'if (!j || !offsets || !context || !release)', 'if (!j || !context || !release)')
replace(f, '    for(int piece=0;piece<3;++piece) if(offsets[piece]<0 || offsets[piece]>=16384) throw std::invalid_argument("Invalid forecast payload offset");\n', '')
replace(f, '    std::copy_n(offsets,3,work.sources->data<int32_t>()+index*4+1);\n', '')
replace(paths[2], 'int index, int source, const int32_t *offsets, void *context', 'int index, int source, void *context')
f = paths[3]
start = src[f].index('    package func forecastPayloadOffsets(')
end = src[f].index('    /// Whole-record speculative reads', start)
src[f] = src[f][:start] + src[f][end:]
for f in paths:
    target = P / 'demand-aligned-src' / f
    target.parent.mkdir(parents=True, exist_ok=True)
    assert not target.exists()
    target.write_text(src[f])
(P / 'demand-aligned-paths.json').write_text(json.dumps(paths, indent=2))
(P / 'demand-aligned.patch').write_text(''.join(''.join(difflib.unified_diff(
    (R/f).read_text().splitlines(True), src[f].splitlines(True), fromfile='a/'+f, tofile='b/'+f)) for f in paths))
plan = dict(hypothesis='Aligned direct copies help the frozen target sequence, but changing forecast and demand together regressed complete code requests. Preserve the original forecast arena, offsets and reader behavior; remove only the demanded staging copy.',
            change='Four engine files plus the same isolated diagnostic CLI. Demand staging remains padded/charged, 4062 slots at15GB. Forecast path is byte-for-byte baseline apart from source-table indexing in the common repack kernel. A and B differ only by SLOTSTREAM_Q2_ALIGNED_DIRECT.',
            gates='Installed-byte/pool checks under Metal validation, exact complete frozen logits across off/on and previous reference; then ABCCBA ordinary adaptive requests against v68 and Splash at15GB, matched candidate/Splash slots. Retain only >=2%median improvement on both timed tasks, improvement in both orders, and no correctness regression. Goal requires <=5%Splash onboth tasks. No retries to replace a failed clean protocol.',
            scope='Fast unchanged. No production adoption, Smart promotion, release or full app claim.')
(P / 'demand-aligned-plan.json').write_text(json.dumps(plan, indent=2))
