import pathlib,json,statistics,datetime
p=pathlib.Path(__file__).resolve().parent;l=json.loads((p/'coalesced-ledger.json').read_text());freq=[json.loads(s)for s in(p/'coalesced-frequency.jsonl').read_text().splitlines()];ref=None;out=[];mapping=json.loads((p/'clock-units.json').read_text());offset=mapping['unix']-mapping['mach_seconds'];ratio=mapping['numer']/mapping['denom']
for e in l:
 d=json.loads((p/(e['label']+'.json')).read_text());rows=[r for r in d['runs']if r['round']==1];g=e['guard'];ss=[s for s in g['samples']if s['user_ns']+s['system_ns']>0]
 if e['arm']!='S':
  hs=[r['logits_sha256']for r in rows]
  if ref is None:ref=hs
  assert hs==ref
  t0=rows[0]['start_ns']/1e9;t1=rows[-1]['end_ns']/1e9
 else:t0=rows[0]['start'];t1=rows[-1]['end']
 ss=[dict(s,monotonic=s['unix']-offset)for s in ss]
 c0=max(t0,ss[0]['monotonic']);c1=min(t1,ss[-1]['monotonic'])
 def at(t,k):
  for a,b in zip(ss,ss[1:]):
   if a['monotonic']<=t<=b['monotonic']:
    x=(t-a['monotonic'])/(b['monotonic']-a['monotonic']);return a[k]+x*(b[k]-a[k])
  raise ValueError(t)
 cpu={k:(at(c1,k)-at(c0,k))*ratio/1e9 for k in ['user_ns','system_ns']}
 ff=[f for f in freq if t0+offset+1<=datetime.datetime.fromisoformat(f['timestamp']).timestamp()<=t1+offset-1]
 out.append(dict(label=e['label'],eligible=e['eligible'],verify_s=sum(r['seconds']for r in rows),commit_s=sum(r['commit_seconds']for r in rows),window_s=t1-t0,cpu_window_s=c1-c0,**cpu,frequency_samples=len(ff),**{k:statistics.mean(f[k]for f in ff)for k in ['gpu_freq_mhz','gpu_active_ratio','cpu_power','gpu_power']}))
result=dict(eligible=all(e['eligible']for e in l),native_logits_exact=True,arms=out,limits='Raw fields named user_ns/system_ns are Mach ticks; converted by measured 125/3 ratio. Clock alignment uses a post-protocol wall/absolute-clock mapping, assumes no system clock adjustment/sleep. CPU counters interpolated at .5s within observed time range, last <.5s may be absent; whole-device 1Hz frequencies, not causal GPU clock proof; timing excludes inter-pass hashes/commits')
(p/'coalesced-analysis.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
