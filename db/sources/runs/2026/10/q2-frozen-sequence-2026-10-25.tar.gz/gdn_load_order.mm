#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#import <objc/runtime.h>
#include <atomic>
#include <mutex>
#include <set>
#include <string>
#include <cstdio>
#include <cstdlib>
#include <unistd.h>
namespace {
std::mutex mutex;std::set<Class> devices;std::atomic<size_t> found{0},changed{0};
void dump(){fprintf(stderr,"GDN_LOAD_ORDER found=%zu changed=%zu\n",found.load(),changed.load());}
void device(id<MTLDevice> object){
 if(!object||!getenv("Q2_PENDING_LOAD_ORDER"))return;
 std::lock_guard<std::mutex> lock(mutex);Class cls=object_getClass(object);if(!devices.insert(cls).second)return;
 SEL sel=@selector(newLibraryWithSource:options:error:);Method method=class_getInstanceMethod(cls,sel);IMP original=method_getImplementation(method);
 IMP replacement=imp_implementationWithBlock(^id(id d,NSString*source,MTLCompileOptions*options,NSError**error){
  std::string text(source.UTF8String);size_t first=text.find("float upcoming[2][4] = {};");size_t last=text.find("// Same FP32 order",first);size_t destination=text.find("if constexpr(DEFER){",last);
  if(first!=std::string::npos&&last!=std::string::npos&&destination!=std::string::npos){
   size_t index=found.fetch_add(1);const char*dir=getenv("Q2_GDN_SOURCE_DIR");
   if(dir){char path[4096];snprintf(path,sizeof(path),"%s/%d-%zu-original.metal",dir,getpid(),index);FILE*f=fopen(path,"wx");if(f){fwrite(text.data(),1,text.size(),f);fclose(f);}}
   if(atoi(getenv("Q2_PENDING_LOAD_ORDER"))==1){
    std::string loads=text.substr(first,last-first);text.erase(first,last-first);destination=text.find("if constexpr(DEFER){",first);text.insert(destination,loads);
    source=[NSString stringWithUTF8String:text.c_str()];changed.fetch_add(1);
    if(dir){char path[4096];snprintf(path,sizeof(path),"%s/%d-%zu-candidate.metal",dir,getpid(),index);FILE*f=fopen(path,"wx");if(f){fwrite(text.data(),1,text.size(),f);fclose(f);}}
   }
  }
  return reinterpret_cast<id(*)(id,SEL,id,id,NSError**)>(original)(d,sel,source,options,error);
 });
 class_replaceMethod(cls,sel,replacement,method_getTypeEncoding(method));
}
__attribute__((constructor))void initialize(){atexit(dump);}
}
extern "C" id<MTLDevice> gdnDevice(){id<MTLDevice>d=MTLCreateSystemDefaultDevice();device(d);return d;}
extern "C" NSArray<id<MTLDevice>>*gdnDevices(){NSArray<id<MTLDevice>>*d=MTLCopyAllDevices();for(id<MTLDevice>x in d)device(x);return d;}
__attribute__((used))static const struct{const void*replacement;const void*original;}mapping[]__attribute__((section("__DATA,__interpose")))={
{(const void*)&gdnDevice,(const void*)&MTLCreateSystemDefaultDevice},{(const void*)&gdnDevices,(const void*)&MTLCopyAllDevices}};
