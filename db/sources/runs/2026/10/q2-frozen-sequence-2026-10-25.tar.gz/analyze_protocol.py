from pathlib import Path
import json,statistics,datetime,sys
P=Path(__file__).resolve().parent;label=sys.argv[1];ledger=json.loads((P/(label+'-ledger.json')).read_text());frequencies=[json.loads(s)for s in(P/(label+'-frequency.jsonl')).read_text().splitlines()];out=[];refs={}
for event in ledger:
 rows=json.loads((P/(event['label']+'.json')).read_text())['runs'];native=event['arm']!='S';group='native'if native else'Splash'
 for r in rows:
  if group not in refs:refs[group]={}
  if r['step']in refs[group]:assert refs[group][r['step']]==r['logits_sha256']
  else:refs[group][r['step']]=r['logits_sha256']
 guard=event['guard'];ss=[s for s in guard['samples']if s['user_ns']+s['system_ns']>0]
 ratio=guard['rusage_ticks_per_nanosecond']['numer']/guard['rusage_ticks_per_nanosecond']['denom']
 ss=[dict(s,mach=s['mach_ns']/1e9)for s in ss];offset=statistics.median(s['unix']-s['mach']for s in ss)
 for roundid in sorted({r['round']for r in rows if r['round']>0}):
  rs=[r for r in rows if r['round']==roundid]
  lo=rs[0]['start_ns']/1e9 if native else rs[0]['start'];hi=rs[-1]['end_ns']/1e9 if native else rs[-1]['end'];c0=max(lo,ss[0]['mach']);c1=min(hi,ss[-1]['mach'])
  def at(t,k):
   for a,b in zip(ss,ss[1:]):
    if a['mach']<=t<=b['mach']:
     x=(t-a['mach'])/(b['mach']-a['mach']);return a[k]+x*(b[k]-a[k])
   raise ValueError(t)
  ff=[f for f in frequencies if lo+offset+1<=datetime.datetime.fromisoformat(f['timestamp']).timestamp()<=hi+offset-1]
  out.append(dict(label=event['label'],arm=event['arm'],round=roundid,eligible=event['eligible'],verify_s=sum(r['seconds']for r in rs),commit_s=sum(r['commit_seconds']for r in rs),window_s=hi-lo,cpu_window_s=c1-c0,user_s=(at(c1,'user_ns')-at(c0,'user_ns'))*ratio/1e9,system_s=(at(c1,'system_ns')-at(c0,'system_ns'))*ratio/1e9,frequency_samples=len(ff),**{k:statistics.mean(f[k]for f in ff)for k in ['gpu_freq_mhz','gpu_active_ratio','cpu_power','gpu_power']}))
medians={a:statistics.median(r['verify_s']for r in out if r['arm']==a)for a in sorted({r['arm']for r in out})}
result=dict(eligible=all(e['eligible']for e in ledger),same_engine_logits_exact=True,arms=out,median_verify_seconds=medians,limits='Frozen target-only work, not complete requests. Whole-device passive clocks only. CPU counters sum concurrent threads, overlap wall work, and are not wall-time percentages. Half-second CPU samples interpolate only interior observed range; 1Hz frequency excludes edges.')
if all(a in medians for a in ['A','B','S']):result.update(candidate_over_native=medians['B']/medians['A'],candidate_over_Splash=medians['B']/medians['S'])
(P/(label+'-analysis.json')).write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
