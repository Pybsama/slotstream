from pathlib import Path
import os,fcntl,subprocess,json,sys
P=Path(__file__).resolve().parent;R=P.parents[1]
lock=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
inner=P/'padded-check-child.lock';os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(inner)
cmd=[sys.executable,str(P/'quiet_guarded_run.py'),'--label','padded-reads-check','--budget','10','--timeout','300','--env','SLOTSTREAM_MODEL_LOCK_PATH='+str(inner),'--env','SLOTSTREAM_Q2_ALIGNED_DIRECT=1','--env','MTL_DEBUG_LAYER=1','--',str(P/'native-padded-build/candidate/slotstream'),'q2-experts-check','--pool-model','smart-q2']
(P/'padded-check-command.json').write_text(json.dumps(cmd,indent=2))
with(P/'padded-check-launcher.log').open('x')as f:rc=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT).returncode
print('check exit',rc,flush=True)
if rc==0:assert 'Q2_ALIGNED_DIRECT enabled=1' in(P/'padded-reads-check.log').read_text()
raise SystemExit(rc)
