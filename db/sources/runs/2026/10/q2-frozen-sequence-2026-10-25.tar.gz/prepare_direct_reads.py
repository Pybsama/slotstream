from pathlib import Path
import difflib,json
P=Path(__file__).resolve().parent;R=P.parents[1]
f=R/'Sources/Slotstream/ExpertStore.swift';old=f.read_text()
s=old.replace('    private var readHandles: [[TensorReadHandle]]?', '''    // Diagnostic only: Q2 raw staging already has independent ownership and
    // remains gated until every checked read succeeds. Avoid the second CPU
    // copy without changing GPU layout or reading outside the tensor extent.
    private static let diagnosticRawDirect: Bool = {
        let enabled = ProcessInfo.processInfo.environment["SLOTSTREAM_Q2_RAW_DIRECT_READ"] == "1"
        if enabled { print("Q2_RAW_DIRECT_READ enabled=1") }
        return enabled
    }()
    private var readHandles: [[TensorReadHandle]]?''')
needle='''        let bytes = pieceRowBytes[piece]
        if nativeAffineTiles || (isQ2 && Q2PackedExperts.enabled) {'''
replacement='''        let bytes = pieceRowBytes[piece]
        if isQ2, rawCopy, Self.diagnosticRawDirect {
            try readFault?.beforeRead()
            let handle = readHandles?[key.layer][piece] ?? index.readHandle(for: refs[key.layer][piece])
            try handle.readChecked(into: destination, offset: key.expert * bytes,
                count: bytes, shouldContinue: shouldContinue)
            guard shouldContinue() else { throw CheckpointReadError.cancelled }
            return
        }
        if nativeAffineTiles || (isQ2 && Q2PackedExperts.enabled) {'''
assert s.count(needle)==1;s=s.replace(needle,replacement)
needle='''        let lanes = min(max(queueDepth, 1), jobs)
        if let finishReaders {'''
replacement='''        let lanes = min(max(queueDepth, 1), jobs)
        if isQ2, rawCopy, Self.diagnosticRawDirect, finishReaders == nil {
            DispatchQueue.concurrentPerform(iterations: lanes) { lane in
                var j = lane
                while j < jobs {
                    let (record, piece) = (j / pieceCount, j % pieceCount)
                    let key = keys[record], bytes = rowBytes[piece]
                    do {
                        try readFault?.beforeRead()
                        let handle = readHandles?[key.layer][piece] ?? index.readHandle(for: refs[key.layer][piece])
                        try handle.readChecked(into: bases[piece] + slots[record] * bytes,
                            offset: key.expert * bytes, count: bytes)
                    } catch { failure.record(error) }
                    j += lanes
                }
            }
            try failure.finish()
            return
        }
        if let finishReaders {'''
assert s.count(needle)==1;s=s.replace(needle,replacement)
(P/'ExpertStore-direct.swift').write_text(s);(P/'ExpertStore-original.swift').write_text(old)
(P/'direct-reads.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='a/Sources/Slotstream/ExpertStore.swift',tofile='b/Sources/Slotstream/ExpertStore.swift')))
(P/'direct-reads-plan.json').write_text(json.dumps(dict(hypothesis='The native raw staging path unnecessarily copies every Q2 demanded and forecast piece from aligned scratch. Upstream copy-only ablation tests this cause. The smallest native test reads exact tensor bytes directly into already-owned raw staging, keeping readiness, cancellation, file checks, cache and GPU repacking.',scope='Diagnostic Q2-only flag, both demand/forecast. No layout, capacity, Fast or production default change. Existing raw staging is private until success publication. File offsets and destination addresses can be unaligned; this may cost SSD speed, so do not assume improvement. First installed-byte pool failure/ownership checks with Metal validation, then clean ABSSBA captured-code comparison at15GB/4067slots. If repeatable>=2% improvement and exact hashes, qualify complete requests.',limits='Alignment and eliminated scratch ownership both differ; this tests the simplest safe copy-removal implementation. A regression does not refute a padded direct-read design. No retained production path without complete requests.'),indent=2))
runner=(P/'run_gdn_order.py').read_text()
runner=runner.replace("if arm!='S':env+=['--env','Q2_PENDING_LOAD_ORDER='+('1'if arm=='B'else'0'),'--env','DYLD_INSERT_LIBRARIES='+str(P/'gdn_load_order.dylib'),'--env','Q2_GDN_SOURCE_DIR='+str(P/'gdn-sources')]", "if arm=='B':env+=['--env','SLOTSTREAM_Q2_RAW_DIRECT_READ=1']")
runner=runner.replace("P/'native-build-v4/candidate/slotstream'","P/'native-direct-build/candidate/slotstream'")
runner='\n'.join(l for l in runner.splitlines() if "if arm=='B':assert 'changed=0'" not in l)+'\n'
(P/'run_direct_reads.py').write_text(runner)
(P/'run_direct_clock.py').write_text((P/'run_gdn_clock.py').read_text().replace("label='gdn-order'","label='direct-reads'").replace('run_gdn_order.py','run_direct_reads.py'))
b=(P/'build_native_v4.py').read_text().replace("source=R/'Sources/slotstream-cli/Q2ProfileCommand.swift';original=source.read_bytes()", "source=R/'Sources/slotstream-cli/Q2ProfileCommand.swift';original=source.read_bytes();expert=R/'Sources/Slotstream/ExpertStore.swift';expertOriginal=expert.read_bytes()")
b=b.replace(" source.write_bytes((P/'Q2ProfileCommand-v4.swift').read_bytes())", " source.write_bytes((P/'Q2ProfileCommand-v4.swift').read_bytes());expert.write_bytes((P/'ExpertStore-direct.swift').read_bytes())")
b=b.replace(" source.write_bytes(original)"," source.write_bytes(original);expert.write_bytes(expertOriginal)")
b=b.replace('native-build-v4','native-direct-build').replace('restored-v4.json','restored-direct.json')
(P/'build_direct_reads.py').write_text(b)
print('Prepared diagnostic Q2-only patch, build and protocol')
