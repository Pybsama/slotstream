from pathlib import Path
import subprocess,sys,json,time
P=Path(__file__).resolve().parent;R=P.parents[1]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import terminate_child_tree
label='demand-pool3';children=[]
with(P/(label+'-frequency.jsonl')).open('x')as f,(P/(label+'-frequency.stderr')).open('x')as err,(P/(label+'-driver.log')).open('x')as log:
 try:
  monitor=subprocess.Popen([str(R/'.build/native-monitor/macmon'),'pipe','-s','1800','-i','1000','--soc-info'],stdout=f,stderr=err,start_new_session=True);children.append(monitor)
  cmd=[sys.executable,str(P/'run_demand_pool.py'),'--label',label,'--fixture','timed-2','--rounds','2','--order','ABSSBA']
  child=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);children.append(child)
  rc=child.wait(timeout=1800)
 finally:
  for c in reversed(children):
   if c.poll()is None:terminate_child_tree(c)
  (P/(label+'-completion.json')).write_text(json.dumps(dict(exit_code=child.returncode,unix=time.time(),command=cmd),indent=2))
raise SystemExit(rc)
