import pathlib,json,hashlib,tarfile,io,subprocess
P=pathlib.Path(__file__).resolve().parent;R=P.parents[1]
names=['cycle-cost-audit.json','final-restored-build.log','final-restored-build-audit.json','restored-catalogue-t0.log','restored-catalogue-t1.log','hosted-status-snapshot.json','hosted-ci-watch.log','capture_closeout.py']
files={n:P/n for n in names};manifest={n:{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}for n,f in files.items()}
out=R/'db/sources/runs/2026/10/native-q2-execution-closeout-2026-10-22.tar.gz';assert not out.exists()
with tarfile.open(out,'w:gz')as t:
 b=json.dumps(manifest,indent=2).encode();i=tarfile.TarInfo('MANIFEST.json');i.size=len(b);t.addfile(i,io.BytesIO(b))
 for n,f in files.items():t.add(f,arcname=n,recursive=False)
with tarfile.open(out)as t:
 for n,m in manifest.items():
  b=t.extractfile(n).read();assert len(b)==m['bytes'] and hashlib.sha256(b).hexdigest()==m['sha256']
sha=hashlib.sha256(out.read_bytes()).hexdigest();body=P/'closeout-body.md'
body.write_text(f'''# Native Q2 execution checkpoint

The immutable [closeout archive](native-q2-execution-closeout-2026-10-22.tar.gz) has SHA-256 `{sha}`. Its eight payloads were read back against their manifest.

`cycle-cost-audit.json` derives per-cycle means and accepted-draft counts from the already archived clean v15 pair. The arithmetic supports execution cost as the remaining problem in that fixture, not a shortage of useful draft tokens. It does not isolate a single scheduler change or establish performance parity.

After rejecting v18, a local release rebuild completes successfully and matches every qualified v17 source input. Its executable is not byte-identical, so the exact previously tested v17 CLI, source archive and identity are restored as the default local CLI output. The rebuilt catalogue separately passes all 89 T0 and 18 T1 checks. The app source and binaries remain the separately qualified v17 build.

Code checkpoint [3b6a307](https://github.com/carloslfu/slotstream/commit/3b6a30745159031fb4b656ccb5d46cca91002f19) is pushed to main. At this captured snapshot, [documentation](https://github.com/carloslfu/slotstream/actions/runs/39841948142) and [context contracts](https://github.com/carloslfu/slotstream/actions/runs/39841948081) have passed. The external-library job has passed. The remaining [engine CI](https://github.com/carloslfu/slotstream/actions/runs/39841947972) and [Mac app CI](https://github.com/carloslfu/slotstream/actions/runs/39841948146) are still running and are not claimed as passes. The local CLI watch process is stopped; the hosted workflows are left running. A later outcome requires its own verification.

No release or Smart promotion is made. Performance parity remains unfinished. Core qualification and preserved failures are in [[sources/runs/2026/10/2026-10-22-native-q2-execution]] and its linked follow-ups.
''')
args=['dbmd','write','sources/runs/2026/10/2026-10-22-native-q2-execution-closeout.md','--type','run','--dir',str(R/'db'),'--json','--summary','Pushed native Q2 checkpoint; exact tested local CLI restored, rebuilt catalogue passes, hosted engine and app CI still pending at capture','--fm','title=Native Q2 execution checkpoint and hosted status','--fm','tool=Native release build, catalogue, identity audit and GitHub Actions status','--fm','command=make build; catalogue T0 and T1; exact-head gh run list and gh run watch','--fm','binary=Qualified default CLI f6c979e088384622291bd9b3c277b2d9f4ba014bbebf1caa85e12bfb984808e3','--fm','machines=[[records/machines/macbook-pro-m5-pro-48gb]]','--fm','captured_at=2026-10-22','--fm','discarded=false','--body-file',str(body)]
print(subprocess.check_output(args,text=True))
