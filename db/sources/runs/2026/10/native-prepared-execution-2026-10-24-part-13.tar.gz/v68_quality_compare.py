import json,sys
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1]
sys.path.insert(0,str(R/'.build/native-q2-20261021'));from grade_v2 import grade
rows=[]
for model in ['fast','smart-q2']:
 native=P/f'v68-native-quality-{model}.json';upstream=P/f'matched9-splash-quality-{model}.json'
 a=grade(native);b=grade(upstream);prior=grade(P/f'v61-native-quality-{model}.json')
 key=lambda d:[(r['id'],r['semantic'],r['strict'])for r in d['rows']]
 result=dict(model=model,native=native.name,upstream=upstream.name,total=a['total'],native_semantic=a['semantic'],native_strict=a['strict'],identical_upstream_per_case_grades=key(a)==key(b),identical_v61_per_case_grades=key(a)==key(prior),failures=[r['id']for r in a['rows']if not r['semantic']])
 rows.append(result)
 assert result['identical_upstream_per_case_grades'] and result['identical_v61_per_case_grades']
(P/'v68-upstream-quality-comparison.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows,indent=2))
