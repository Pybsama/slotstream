import json,os,subprocess,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];B=P/'v9/slotstream';rows=[]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
# Wait for the specific controller already running this task's v8 study.
started=time.monotonic()
while True:
 r=subprocess.run(['ps','-p','1335','-o','command='],capture_output=True,text=True)
 if r.returncode:break
 if 'v8_sequence.py' not in r.stdout:raise RuntimeError('Controller PID changed ownership')
 if time.monotonic()-started>3600:raise RuntimeError('Bounded predecessor wait expired')
 time.sleep(10)
print('V8 CONTROLLER ENDED',flush=True)
def run(label,cmd,heavy=False):
 if heavy:preflight(12)
 print('START',label,flush=True)
 with (P/(label+'-driver.log')).open('x') as log:r=subprocess.run(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT)
 rows.append(dict(label=label,command=cmd,exit_code=r.returncode));(P/'v9-sequence-ledger.json').write_text(json.dumps(rows,indent=2)+'\n')
 print('END',label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
run('v9-build',['make','build','SLOTSTREAM_BUILD_JOBS=4'],True)
run('v9-freeze',[sys.executable,str(P/'freeze.py'),'v9'])
for model in ['fast','smart-q2']:
 label='v9-pool-'+model
 run(label,[sys.executable,str(P/'guarded_run.py'),'--label',label,'--budget','3','--timeout','300','--env','SLOTSTREAM_NATIVE_PROJECTION_SCHEDULE=1','--',str(B),'q2-experts-check','--pool-model',model])
run('v9-formats',[sys.executable,str(P/'guarded_run.py'),'--label','v9-formats','--budget','3','--timeout','240','--env','SLOTSTREAM_NATIVE_PROJECTION_SCHEDULE=1','--',str(B),'q2-format-check','--fixtures','bench/q2/formats.json','--policy-fixtures','bench/q2/verify-budget.json','--mix-fixtures','bench/q2/mix-quantization.json'])
run('v9-plain',[sys.executable,str(P/'v9_plain.py')])
for model in ['fast','smart-q2']:
 label='v9-commit-plain-'+model
 run(label,[sys.executable,str(P/'commit_ablation.py'),'--label',label,'--native',str(B),'--model',model,'--budget','9','--order','AB','--plain','--cases',str(P/'plain-equivalence-cases.json')])
 a=json.loads((P/(label+'-0-A.json')).read_text());b=json.loads((P/(label+'-1-B.json')).read_text())
 checks=[{key:x[key]==y[key]for key in ['prompt_ids','tokens','text']}for x,y in zip(a['runs'],b['runs'])]
 (P/(label+'-equivalence.json')).write_text(json.dumps(checks,indent=2)+'\n')
 assert len(a['runs'])==len(b['runs'])==2 and all(all(x.values())for x in checks)
for model in ['smart-q2','fast']:
 label='v9-commit-'+model
 run(label,[sys.executable,str(P/'commit_ablation.py'),'--label',label,'--native',str(B),'--model',model,'--budget','9'])
