import json,subprocess,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];rows=[]
for model,budget in [('fast',15),('smart-q2',12),('smart-q2',15)]:
 label=f'v68-final-{model}-{budget}'
 cmd=[sys.executable,str(P/'controlled_driver.py'),'--label',label,'--budget',str(budget),'--',sys.executable,str(P/'native_splash_compare_v61.py'),'--label',label,'--native',str(P/'v68/slotstream'),'--model',model,'--budget',str(budget),'--cases',str(P/'short-warm-384-cases.json')]
 print('START',label,flush=True)
 with(P/(label+'-outer.log')).open('x')as log:r=subprocess.run(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT)
 rows.append(dict(label=label,exit_code=r.returncode));(P/'v68-final-comparison-ledger.json').write_text(json.dumps(rows,indent=2)+'\n')
 print('END',label,r.returncode,flush=True)
 if r.returncode:continue
 summary=subprocess.run([sys.executable,str(P/'comparison_summary.py'),label],stdout=subprocess.PIPE,text=True,cwd=R)
 if summary.returncode:raise SystemExit(summary.returncode)
 d=json.loads((P/(label+'-summary.json')).read_text());print('SUMMARY',label,'eligible',d['all_arms_eligible'],'parity',d['parity_or_better'],flush=True)

raise SystemExit(int(any(row["exit_code"] for row in rows)))
