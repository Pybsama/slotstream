import json, subprocess, sys
from pathlib import Path
P=Path(__file__).resolve().parent; R=P.parents[1]
old=P/'v1c/slotstream'
new=P/'v6/slotstream'
results=[]
for model,method in [('fast','fast'),('smart-q2','q2')]:
 rows={}
 for version,binary,ahead in [('old',old,'on' if model=='smart-q2' else 'off'),('new',new,'on' if model=='smart-q2' else 'off')]:
  label='v6-mlx-plain-'+model+'-'+version; out=P/(label+'.json')
  command=[sys.executable,str(P/'guarded_run.py'),'--label',label,'--budget','9','--env','SLOTSTREAM_NATIVE_EXPERT_SCHEDULE='+('0' if version=='old' else '1'),'--env','SLOTSTREAM_PREPARED_PROJECTIONS='+('0' if version=='old' else '1'),'--',str(binary),'smart-dflash-check','--disable-draft','--method',method,'--model',model,'--memory-gb','9','--max-context','8192','--cases',str(P/'plain-equivalence-cases.json'),'--output',str(out)]
  if ahead:command+=['--native-read-ahead',ahead]
  print('START',label,flush=True);r=subprocess.run(command,cwd=R)
  if r.returncode:raise SystemExit(r.returncode)
  data=json.loads(out.read_text());assert data['complete']
  assert all(x['tokens'] and not x['stats'].get('runtimeError') and not x['stats']['memoryPressureCancelled'] and x['stats']['peakMemoryGB']<=9 for x in data['runs'])
  rows[version]={x['id']:x for x in data['runs']}
 for case in rows['old']:
  original=rows['old'][case]
  for version in ['new']:
   candidate=rows[version][case]
   entry=dict(model=model,case=case,version=version,prompt_equal=original['prompt_ids']==candidate['prompt_ids'],tokens_equal=original['tokens']==candidate['tokens'],text_equal=original['text']==candidate['text'],old_tokens=len(original['tokens']),new_tokens=len(candidate['tokens']),read_ahead_issued=candidate['stats'].get('expertPrefetch',{}).get('issued',0))
   results.append(entry)
 (P/'v6-mlx-plain-equivalence.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2),flush=True)
assert all(x['prompt_equal'] and x['tokens_equal'] and x['text_equal'] for x in results)
assert all(x['read_ahead_issued']>0 for x in results if x['model']=='smart-q2')
