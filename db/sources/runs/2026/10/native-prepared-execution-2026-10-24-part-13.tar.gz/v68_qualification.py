import subprocess,sys,json,time
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];rows=[]
for script in ['v68_core.py','v68_combine_state_probe.py','v68_plain.py','v68_native_quality.py','app_v68_qualification.py']:
 print('START',script,flush=True);start=time.monotonic()
 with(P/(script+'.driver.log')).open('x')as log:r=subprocess.run([sys.executable,str(P/script)],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 rows.append(dict(script=script,exit_code=r.returncode,seconds=time.monotonic()-start));(P/'v68-qualification-ledger.json').write_text(json.dumps(rows,indent=2)+'\n');print('END',script,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
