import fcntl,os,sys
lock=open(os.environ.get("SLOTSTREAM_MODEL_LOCK_PATH")or f"/tmp/slotstream-model-{os.getuid()}.lock","a")
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
os.set_inheritable(lock.fileno(),True)
os.execv(sys.argv[1],sys.argv[1:])
