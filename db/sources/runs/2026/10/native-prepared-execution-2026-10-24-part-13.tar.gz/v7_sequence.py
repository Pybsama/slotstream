import json,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];B=P/'v7/slotstream'
rows=[]
def run(label,cmd):
 print('START',label,flush=True)
 with (P/(label+'-driver.log')).open('x') as log:r=subprocess.run(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT)
 rows.append(dict(label=label,command=cmd,exit_code=r.returncode));(P/'v7-sequence-ledger.json').write_text(json.dumps(rows,indent=2)+'\n')
 print('END',label,r.returncode,flush=True);return r.returncode
for kind,args in [('kernels',['q2-experts-check']),('formats',['q2-format-check','--fixtures','bench/q2/formats.json','--policy-fixtures','bench/q2/verify-budget.json','--mix-fixtures','bench/q2/mix-quantization.json'])]:
 if run('v7-'+kind,[sys.executable,str(P/'guarded_run.py'),'--label','v7-'+kind,'--budget','3','--timeout','240','--env','SLOTSTREAM_NATIVE_PROJECTION_SCHEDULE=1','--',str(B),*args]):raise SystemExit(1)
if run('v7-plain',[sys.executable,str(P/'v7_plain.py')]):raise SystemExit(1)
for model in ['smart-q2','fast']:
 run('v7-'+model+'9-splash',[sys.executable,str(P/'native_splash_compare.py'),'--label','v7-'+model+'9-splash','--native',str(B),'--model',model,'--budget','9'])
raise SystemExit(int(any(x['exit_code'] for x in rows)))
