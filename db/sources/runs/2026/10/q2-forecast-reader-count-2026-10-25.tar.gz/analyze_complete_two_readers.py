import json, statistics
from pathlib import Path

P = Path(__file__).resolve().parent
import sys
label = sys.argv[1] if len(sys.argv)>1 else 'demand-complete-15'
events = json.loads((P / (label+'-ledger.json')).read_text())
assert [e['arm'] for e in events] == list('ABCCBA')
result = dict(eligible=all(e['eligible'] for e in events),
              capacity_note='All engines use the same cache slots at the chosen budget, original layout, 8192 context, normal adaptive decoding and read-ahead. B uses two forecast readers; A uses four.', tasks={})
for task in ['timed-2', 'timed-3']:
    rows = {}
    for arm in 'ABC':
        runs = [next(r for r in e['runs'] if r['id'] == task) for e in events if e['arm'] == arm]
        rows[arm] = dict(request_seconds=[r['request_seconds'] for r in runs],
                         tps=[r['tps'] for r in runs],
                         median_request_seconds=statistics.median(r['request_seconds'] for r in runs),
                         median_tps=statistics.median(r['tps'] for r in runs))
    rows['candidate_over_baseline'] = rows['B']['median_request_seconds'] / rows['A']['median_request_seconds']
    rows['candidate_over_splash'] = rows['B']['median_request_seconds'] / rows['C']['median_request_seconds']
    rows['baseline_over_splash'] = rows['A']['median_request_seconds'] / rows['C']['median_request_seconds']
    rows['pair_candidate_over_baseline'] = [b / old for b, old in zip(rows['B']['request_seconds'], rows['A']['request_seconds'])]
    result['tasks'][task] = rows
result['retention_gate'] = result['eligible'] and all(t['candidate_over_baseline'] <= .98 and all(p < 1 for p in t['pair_candidate_over_baseline']) for t in result['tasks'].values())
result['goal_timing_gate'] = result['eligible'] and all(t['candidate_over_splash'] <= 1.05 for t in result['tasks'].values())
(P / (label+'-summary.json')).write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
