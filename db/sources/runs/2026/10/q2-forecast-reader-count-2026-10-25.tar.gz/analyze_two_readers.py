from pathlib import Path
import json,statistics
P=Path(__file__).resolve().parent
ledger=json.loads((P/'two-readers-ledger.json').read_text());assert ''.join(e['arm']for e in ledger)=='ABSSBA'
refs={};summary=[]
previous={r['step']:r['logits_sha256']for r in json.loads((P/'sequence-code-0-N.json').read_text())['runs']if r['round']==1}
for event in ledger:
 data=json.loads((P/(event['label']+'.json')).read_text());rows=data['runs'];assert len(rows)==222
 engine='Splash' if event['arm']=='S'else'native';refs.setdefault(engine,{})
 for row in rows:
  h=row['logits_sha256'];step=row['step']
  if step in refs[engine]:assert refs[engine][step]==h
  else:refs[engine][step]=h
  if engine=='native':assert previous[step]==h
 measured=[r for r in rows if r['round']==1]
 summary.append(dict(label=event['label'],arm=event['arm'],eligible=event['eligible'],verify_seconds=sum(r['seconds']for r in measured),commit_seconds=sum(r['commit_seconds']for r in measured),fetched=sum(r['records_fetched']for r in measured),adopted=sum(r['records_adopted']for r in measured),peak_gb=event['guard']['peak_combined_bytes']/1e9))
medians={a:statistics.median(r['verify_seconds']for r in summary if r['arm']==a)for a in ['A','B','S']}
pairs=[summary[1]['verify_seconds']/summary[0]['verify_seconds'],summary[4]['verify_seconds']/summary[5]['verify_seconds']]
result=dict(scope='Trace-disabled frozen target-only evolving continuation. Real rollback/cache state, but no draft/sampling/adaptive controller. No complete-request speed qualification.',eligible=all(e['eligible']for e in ledger),same_engine_logits_exact=True,all_native_logits_equal_previous_v68=True,arms=summary,median_verify_seconds=medians,candidate_over_native=medians['B']/medians['A'],candidate_over_Splash=medians['B']/medians['S'],paired_candidate_over_native=pairs)
result['component_gate_passed']=result['eligible']and result['candidate_over_native']<=.98 and all(r<1 for r in pairs)
(P/'two-readers-analysis.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
