from pathlib import Path
import json,subprocess,sys
P=Path(__file__).resolve().parent;R=P.parents[1]
assert json.loads((P/'native-two-readers-build/manifest.json').read_text())['passed']
for label,args in [('two-readers-lifetime-check',['expert-lookahead-check']),('two-readers-experts-check',['q2-experts-check','--pool-model','smart-q2'])]:
 command=[sys.executable,str(P/'quiet_guarded_run.py'),'--label',label,'--budget','15','--timeout','600','--env','MTL_DEBUG_LAYER=1','--',str(P/'native-two-readers-build/candidate/slotstream'),*args]
 result=subprocess.run(command,cwd=R);assert result.returncode==0
 log=(P/(label+'.log')).read_text();assert'FAIL'not in log and 'error:'not in log.lower()
raise SystemExit(subprocess.run([sys.executable,str(P/'run_two_readers.py'),'--label','two-readers','--order','ABSSBA','--rounds','2'],cwd=R).returncode)
