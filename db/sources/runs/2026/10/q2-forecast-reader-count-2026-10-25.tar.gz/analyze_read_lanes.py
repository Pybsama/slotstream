from pathlib import Path
import bisect,collections,csv,hashlib,heapq,json,math,re,statistics,struct
P=Path(__file__).resolve().parent;R=P.parents[1]
path=R/'.build/smart-dflash-eval/gsq/Qwen3.8-Flash-Next-GSQ-RCO-Q2_0-00001-of-00002.gguf'
f=path.open('rb')
def unpack(fmt):
 b=f.read(struct.calcsize('<'+fmt));return struct.unpack('<'+fmt,b)[0]
def string():
 n=unpack('Q');assert n<64*1024*1024;return f.read(n).decode()
def value(kind,keep=True):
 if kind==8:return string()
 if kind==9:
  t=unpack('I');n=unpack('Q');assert n<10000000
  for _ in range(n):value(t,False)
  return None
 return unpack({0:'B',1:'b',2:'H',3:'h',4:'I',5:'i',6:'f',7:'?',10:'Q',11:'q',12:'d'}[kind])
assert f.read(4)==b'GGUF'and unpack('I')==3
nt,nk=unpack('Q'),unpack('Q');alignment=32
for _ in range(nk):
 k=string();v=value(unpack('I'))
 if k=='general.alignment':alignment=v
tensors=[]
for _ in range(nt):
 name=string();dims=[unpack('Q')for _ in range(unpack('I'))];kind=unpack('I');offset=unpack('Q');tensors.append(dict(name=name,dimensions=dims,type=kind,offset=offset))
header_bytes=f.tell();data_start=math.ceil(header_bytes/alignment)*alignment;f.seek(0);header_hash=hashlib.sha256(f.read(data_start)).hexdigest();f.close()
old=json.loads((R/'.build/smart-dflash-eval/gsq-header.json').read_text());assert old['tensors']==tensors and old['header_bytes']==header_bytes
experts=[]
for t in tensors:
 m=re.fullmatch(r'blk\.(\d+)\.ffn_(gate|up|down)_exps\.weight',t['name'])
 if not m:continue
 assert t['type']==42 and sorted(t['dimensions'][:2])==[640,2560]and t['dimensions'][2]==512
 start=data_start+t['offset'];experts.append(dict(start=start,end=start+512*460800,layer=int(m[1]),piece={'gate':0,'up':1,'down':2}[m[2]]))
assert len(experts)==144;experts.sort(key=lambda e:e['start']);starts=[e['start']for e in experts]
steps=[r for r in json.loads((P/'observed-0-N.json').read_text())['runs']if r['round']==1];lo=steps[0]['start_ns']/1e9;hi=steps[-1]['end_ns']/1e9
reads=[]
with(P/'observed-0-N-reads.95083.csv').open()as f:
 for x in csv.DictReader(line for line in f if not line.startswith('#')):
  start,end=float(x['start']),float(x['end']);n=int(x['result'])
  if not lo<=start<hi or n<65536:continue
  mid=int(x['offset'])+n/2;t=experts[bisect.bisect_right(starts,mid)-1];assert t['start']<=mid<t['end']
  expert=int((mid-t['start'])//460800);payload=t['start']+expert*460800
  assert int(x['offset'])<=payload and int(x['offset'])+n>=payload+460800
  reads.append(dict(start=start,end=end,seconds=end-start,destination=int(x['destination']),thread=int(x['thread']),layer=t['layer'],piece=t['piece'],expert=expert))
counts=collections.Counter(r['destination']for r in reads);forecast={k for k,v in counts.most_common(4)}
rs=sorted(reads,key=lambda r:r['start']);read_starts=[r['start']for r in rs];batches=[]
def scheduled(work,workers):
 h=[0.0]*workers;heapq.heapify(h)
 for seconds in work:
  t=heapq.heappop(h);heapq.heappush(h,t+seconds)
 return max(h)
for step in steps:
 batch=rs[bisect.bisect_left(read_starts,step['start_ns']/1e9):bisect.bisect_left(read_starts,step['end_ns']/1e9)]
 demand=[r for r in batch if r['destination']not in forecast]
 assert len(demand)==3*step['records_fetched'],(step['step'],len(demand),step['records_fetched'])
 for layer in range(48):
  layer_reads=[r for r in demand if r['layer']==layer];keys=sorted({r['expert']for r in layer_reads});assert len(layer_reads)==len(keys)*3
  mapping={(r['expert'],r['piece']):r for r in layer_reads};assert len(mapping)==len(layer_reads)
  for offset in range(0,len(keys),32):
   kk=keys[offset:offset+32];jobs=[mapping[(k,p)]for k in kk for p in range(3)];lanes=min(32,len(jobs));workers=min(18,lanes)
   lane_jobs=[jobs[lane::lanes]for lane in range(lanes)]
   assert all(all(a['end']<=b['start']for a,b in zip(ll,ll[1:]))for ll in lane_jobs),'job order does not fit assumed lane partition'
   lane_order=sorted(range(lanes),key=lambda lane:lane_jobs[lane][0]['start'])
   static=scheduled([sum(r['seconds']for r in lane_jobs[lane])for lane in lane_order],workers)
   dynamic=scheduled([r['seconds']for r in jobs],workers)
   batches.append(dict(step=step['step'],layer=layer,offset=offset,records=len(kk),read_span_seconds=max(r['end']for r in jobs)-min(r['start']for r in jobs),pread_work_seconds=sum(r['seconds']for r in jobs),model_static_seconds=static,model_dynamic_seconds=dynamic,model_difference_seconds=static-dynamic))
result=dict(scope='Offline model of already paging-excluded observer data. Exact destinations are classified by four dominant buffers, then validated against demand counters in every pass; GGUF header maps logical pieces. Only pread service times are modeled. CPU copying, task overhead, GCD policy, I/O latency changes under alternate scheduling and GPU overlap are omitted. This is hypothesis triage, NOT measured speedup or proof of idle CPU/GPU.',header=dict(path=str(path),bytes=data_start,sha256=header_hash,tensors_match_prior_header=True),validation=dict(demand_reads_match_all_pass_counters=True,three_unique_pieces_per_record=True,observed_read_order_matches_static_lanes=True),destinations=len(counts),forecast_destinations=sorted(forecast),demand_destinations=len(counts)-4,batches=len(batches),multijob_batches=sum(b['records']*3>32 for b in batches),totals={k:sum(b[k]for b in batches)for k in ['read_span_seconds','pread_work_seconds','model_static_seconds','model_dynamic_seconds','model_difference_seconds']},batch_data=batches)
(P/'read-lane-analysis.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items()if k!='batch_data'},indent=2))
