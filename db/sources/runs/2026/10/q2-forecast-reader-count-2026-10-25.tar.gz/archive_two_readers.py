from pathlib import Path
import hashlib,io,importlib.util,json,re,tarfile
P=Path(__file__).resolve().parent;R=P.parents[1];OLD=R/'.build/native-replay-20261023/v68'
result=json.loads((P/'two-readers-analysis.json').read_text());assert not result['component_gate_passed']
spec=importlib.util.spec_from_file_location('identity',R/'Tools/build_identity.py');identity=importlib.util.module_from_spec(spec);spec.loader.exec_module(identity)
source=json.loads((OLD/'build-identity.json').read_text())['source'];assert source=={str(f.relative_to(R)):identity.sha(f)for f in identity.source_files(R)}
artifacts={n:identity.sha(R/'.build/release'/n)==identity.sha(OLD/n)for n in ['slotstream','slotstream-checks','mlx.metallib','build-identity.json','build-source.tar.gz']};assert all(artifacts.values())
(P/'two-readers-final-state.json').write_text(json.dumps(dict(runtime_inputs_equal_v68=len(source),default_artifacts=artifacts,retained_runtime_changes=False,fast_changed=False,complete_request_control_run=False,reason='Frozen component gate fails:924global swap-inpages in finalA,raw paired directions reverse. Entireprotocol excluded; no qualified gain or repeat.'),indent=2))
files={f.name:f for f in P.glob('two-readers-*')if f.is_file()and f.suffix in ['.json','.log','.patch']and'archive-receipt'not in f.name}
for name in ['prepare_two_forecast_readers.py','build_two_readers.py','qualify_two_readers.py','run_two_readers.py','analyze_two_readers.py','complete_two_readers.py','analyze_complete_two_readers.py','check_two_reader_lifetime.py','archive_two_readers.py','quiet_guarded_run.py','restored-two-readers.json','analyze_read_lanes.py','read-lane-analysis.json','forecast-waste-attribution.json']:
 files[name]=P/name
for f in(P/'two-readers-src').rglob('*'):
 if f.is_file():files[str(f.relative_to(P))]=f
for n in ['build.txt','manifest.json','candidate/build-identity.json','candidate/build-source.tar.gz']:
 f=P/'native-two-readers-build'/n;files[str(f.relative_to(P))]=f
for n,f in [('baseline-build-identity.json',P/'native-build-v4/candidate/build-identity.json'),('splash-fixed-build-identity.json',P/'upstream/identity.json'),('cost-demand-archive.json',P/'cost-demand-archive-receipt.json'),('frozen-sequence-archive.json',P/'archive-receipt.json')]:files['reference/'+n]=f
secret=re.compile(rb'(?:ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{25,}|sk-(?:proj-)?[A-Za-z0-9_-]{30,}|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----)')
for f in files.values():assert f.exists()and not secret.search(f.read_bytes()),f
manifest={n:dict(bytes=f.stat().st_size,sha256=identity.sha(f))for n,f in files.items()};raw=json.dumps(manifest,indent=2).encode()+b'\n'
dest=R/'db/sources/runs/2026/10/q2-forecast-reader-count-2026-10-25.tar.gz';assert not dest.exists()
with tarfile.open(dest,'w:gz')as t:
 for n,f in sorted(files.items()):t.add(f,arcname=n,recursive=False)
 info=tarfile.TarInfo('archive-manifest.json');info.size=len(raw);t.addfile(info,io.BytesIO(raw))
with tarfile.open(dest)as t:
 for n,m in manifest.items():
  raw=t.extractfile(n).read();assert len(raw)==m['bytes']and hashlib.sha256(raw).hexdigest()==m['sha256']
receipt=dict(path=str(dest.relative_to(R)),files=len(manifest),bytes=dest.stat().st_size,sha256=identity.sha(dest),readback_verified=True,credential_pattern_matches=0)
(P/'two-readers-archive-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
