from pathlib import Path
import fcntl, hashlib, json, os, shlex, shutil, subprocess, sys

P = Path(__file__).resolve().parent
R = P.parents[1]
D = P / 'two-reader-lifetime'
assert not D.exists()
D.mkdir()
sys.path.insert(0, str(R / 'Tools'))
from prefill_bench import preflight

lock = open(f'/tmp/slotstream-model-{os.getuid()}.lock', 'a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
before = preflight(4)
source = (R / 'Sources/slotstream-cli/NativePieceReaderChecks.swift').read_text()
source = source.replace('func checkNativePieceReaders() throws {', 'func checkNativePieceReaders(queueCount: Int) throws {')
source = source.replace('(0..<4).map', '(0..<queueCount).map')
source = source.replace('speculativeLanes: 4', 'speculativeLanes: queueCount')
source = source.replace('for _ in sizes { try wait(entered) }', 'for _ in 0..<min(sizes.count, queueCount) { try wait(entered) }')
source = source.replace('lanes.snapshot.speculativeInUse == 3', 'lanes.snapshot.speculativeInUse == min(sizes.count, queueCount)')
source += '''
@main struct PieceChecksMain {
    static func main() throws {
        for queues in [2, 4] {
            for _ in 0..<20 { try checkNativePieceReaders(queueCount: queues) }
            print("CHECK queues=\\(queues) iterations=20 PASS")
        }
    }
}
'''
src = D / 'PieceChecks.swift'
src.write_text(source)
release = R / '.build/release'
objects = [shlex.split(s)[0] for s in (release / 'slotstream.product/Objects.LinkFileList').read_text().splitlines() if '/slotstream_cli.build/' not in s]
(D / 'objects.txt').write_text('\n'.join(shlex.quote(o) for o in objects) + '\n')
desc = json.loads((release / 'description.json').read_text())
module = next(v for v in desc['swiftCommands'].values() if v.get('moduleName') == 'Slotstream')
args = module['otherArguments']
cc = []
for i, arg in enumerate(args[:-1]):
    if arg == '-Xcc': cc.extend([arg, args[i+1]])
binary = D / 'piece-checks'
cmd = ['xcrun', 'swiftc', '-O', '-parse-as-library', '-swift-version', '5', '-package-name', 'slotstream', '-target', 'arm64-apple-macosx14.0', '-I', str(release / 'Modules'), *cc, str(src), '@' + str(D / 'objects.txt'), '-lc++', '-framework', 'Metal', '-framework', 'Accelerate', '-o', str(binary)]
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
receipt = dict(command=cmd, before=before, source_sha256=sha(src), objects={str(Path(o).relative_to(R)):sha(o) for o in objects}, scope='Actual last-build engine objects; parameterized existing piece ownership check. No model or performance measurement.')
(D / 'build-inputs.json').write_text(json.dumps(receipt, indent=2))
with (D / 'build.log').open('w') as log:
    subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT, check=True, timeout=120)
shutil.copy2(release / 'mlx.metallib', D / 'mlx.metallib')
with (D / 'run.log').open('w') as log:
    subprocess.run([str(binary)], stdout=log, stderr=subprocess.STDOUT, check=True, timeout=120)
receipt = dict(passed=True, binary_sha256=sha(binary), log_sha256=sha(D / 'run.log'), queue_counts=[2,4], iterations_each=20)
(D / 'result.json').write_text(json.dumps(receipt, indent=2))
print(json.dumps(receipt))
