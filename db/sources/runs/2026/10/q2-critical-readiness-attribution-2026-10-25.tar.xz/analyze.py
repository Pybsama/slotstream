from pathlib import Path
import csv,json,collections,bisect
P=Path(__file__).resolve().parent
def rows(p):
 with p.open()as f:r=list(csv.DictReader(l for l in f if not l.startswith('#')))
 with p.open('rb')as f:f.seek(max(0,p.stat().st_size-512));foot=dict(x.split('=',1)for x in f.read().decode().splitlines()[-1][2:].split())
 assert int(foot['total'])<int(foot['cap'])
 if 'gpu_initial'in foot:assert foot['gpu_initial']==foot['cpu_initial']and foot['gpu_final']==foot['cpu_final']
 return r
def union(xs):
 out=[]
 for a,b in sorted(xs):
  if b<=a:continue
  if not out or a>out[-1][1]:out.append([a,b])
  else:out[-1][1]=max(out[-1][1],b)
 return out
def length(xs):return sum(b-a for a,b in xs)
def inter(a,b):
 out=[];i=j=0
 while i<len(a)and j<len(b):
  lo,hi=max(a[i][0],b[j][0]),min(a[i][1],b[j][1])
  if hi>lo:out.append([lo,hi])
  if a[i][1]<b[j][1]:i+=1
  else:j+=1
 return out
results=[];details=[]
for dirname,ledger in [('q2-host-profile-20261025','ordinary-copies-15-ledger.json'),('q2-graph-profile-20261025','ordinary-graph-15-ledger.json'),('q2-request-profile-20261025','ordinary-traced-15-ledger.json')]:
 base=P.parent/dirname
 for e in json.loads((base/ledger).read_text()):
  label=e['label'];cp=next(p for p in base.glob(label+'-commands.*.csv')if not any(n in p.name for n in ['events','stages','assignments','pipelines']))
  prefix=cp.name[:-4];cc=rows(cp);ee=rows(base/(prefix+'.events.csv'));ss=rows(base/(prefix+'.stages.csv'));rr=rows(next(base.glob(label+'-reads.*.csv')))
  bybuf=collections.defaultdict(list);events=collections.defaultdict(list);signals=collections.defaultdict(list)
  for c in cc:
   c.update(submitted=float(c['submitted']),start=float(c['start']),end=float(c['end']),stages=[],events=[]);bybuf[c['buffer']].append(c)
  for vv in bybuf.values():vv.sort(key=lambda c:c['submitted'])
  times={b:[c['submitted']for c in v]for b,v in bybuf.items()}
  for s in ss:
   s.update(encoded=float(s['encoded']),start=int(s['gpu_start'])/1e9,end=int(s['gpu_end'])/1e9)
   i=bisect.bisect_left(times[s['buffer']],s['encoded']);bybuf[s['buffer']][i]['stages'].append(s)
  for ev in ee:
   ev['stamp']=float(ev['stamp'])
   if ev['kind']in ['S','R']:signals[(ev['event'],ev['value'],ev['kind'])].append(ev['stamp'])
   elif ev['kind']=='W':
    i=bisect.bisect_left(times[ev['buffer']],ev['stamp']);bybuf[ev['buffer']][i]['events'].append(ev)
  for v in signals.values():v.sort()
  measured=sorted((s for s in ss if s['end']>s['start']>0),key=lambda s:s['start'])
  gpu_starts=[s['start']for s in measured];prior_end=[];edge=0
  for s in measured:prior_end.append(edge);edge=max(edge,s['end'])
  matches=[];counts=collections.Counter()
  for c in cc:
   stages=sorted(c['stages'],key=lambda s:s['encoded']);ts=[s['encoded']for s in stages]
   for w in c['events']:
    if not stages:continue # warmup or otherwise outside selected windows
    counts['waits']+=1;j=bisect.bisect_right(ts,w['stamp'])
    if j==len(stages):counts['no_next_encoder']+=1;continue
    s=stages[j];prev=stages[j-1]if j else None
    if s['start']==0 or(prev and prev['end']==0):counts['missing_encoder_boundary']+=1;continue
    starts=signals.get((w['event'],w['value'],'S'),[]);ends=signals.get((w['event'],w['value'],'R'),[])
    # Upstream creates fresh events whose pointer/value pairs can be reused.
    # Bind to the first publication after this wait, bounded by this command.
    # A publication before encoding needs a separate ownership proof; omit it.
    k=bisect.bisect_left(starts,w['stamp'])
    if k==len(starts)or starts[k]>c['end']:counts['no_post_wait_publication']+=1;continue
    signal=starts[k];k=bisect.bisect_left(ends,signal)
    if k==len(ends):counts['missing_signal_return']+=1;continue
    returned=ends[k]
    if not signal<=returned<=c['end']:counts['invalid_signal_time']+=1;continue
    counts['matched']+=1
    # Metal command GPUStartTime can be after the host event publication.
    # Bound a first wait by submission and the prior measured GPU encoder,
    # not by GPUStartTime (which would hide queued dependency delay).
    ix=bisect.bisect_left(gpu_starts,s['start'])
    begin=prev['end']if prev else max(c['submitted'],prior_end[ix]);end=s['start']
    assert begin<=end+1e-6,(label,begin,end)
    matches.append(dict(submitted=c['submitted'],first=prev is None,start=begin,end=end,signal=signal,returned=returned,unready=[begin,min(end,signal)],setter=[max(begin,signal),min(end,returned)],ready=[max(begin,returned),end]))
  gpu=union((s['start'],s['end'])for s in ss if s['end']>s['start']>0);read=union((float(r['start']),float(r['end']))for r in rr if int(r['result'])>0)
  data=json.loads((base/(label+'.json')).read_text())
  for r in data['runs']:
   if not r['id'].startswith('timed'):continue
   lo,hi=r['request_started_mach_ns']/1e9,r['request_ended_mach_ns']/1e9;ms=[m for m in matches if lo<=m['submitted']<hi];groups={}
   for kind in ['unready','setter','ready']:
    u=inter(union(m[kind]for m in ms),[[lo,hi]])
    groups[kind]=dict(union_seconds=length(u),outside_encoders=length(u)-length(inter(u,gpu)),outside_encoders_and_reads=length(u)-length(inter(u,union(gpu+read))),read_overlap=length(inter(u,read)))
   result=dict(label=label,id=r['id'],eligible=e['eligible'],request_seconds=hi-lo,matched=len(ms),internal=sum(not m['first']for m in ms),groups=groups,process_counts=dict(counts))
   results.append(result);details.append(dict(label=label,id=r['id'],matches=ms));print(json.dumps(result),flush=True)
(P/'analysis.json').write_text(json.dumps(dict(scope='Existing diagnostic traces only. Match each shared-event wait to the following measured encoder and preceding encoder in its command. First waits start at max(command submission, prior measured encoder end), because GPUStartTime can follow publication. Remove overlaps with measured encoder intervals and all positive reads. Internal-boundary waits with missing timestamps are excluded and explicitly counted; other missing encoder samples may overestimate the uncovered intervals. These intervals identify queued dependency readiness but are not causal estimates of a faster reader or a complete-request speed result.',results=results),indent=2))
(P/'detail.json').write_text(json.dumps(details,indent=2))
