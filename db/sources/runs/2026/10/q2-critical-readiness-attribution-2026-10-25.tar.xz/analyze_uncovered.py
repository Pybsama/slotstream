from pathlib import Path
import csv,json,collections,bisect
P=Path(__file__).resolve().parent;B=P.parent/'q2-graph-profile-20261025'
exec((P/'analyze.py').read_text().split('results=[];details=[]')[0],globals());P=Path(__file__).resolve().parent
label='ordinary-graph-15-0-A';data=json.loads((B/(label+'.json')).read_text());sf=next(B.glob(label+'-commands.*.stages.csv'));ss=rows(sf);reads=rows(next(B.glob(label+'-reads.*.csv')))
gpu=union((int(s['gpu_start'])/1e9,int(s['gpu_end'])/1e9)for s in ss if int(s['gpu_end'])>int(s['gpu_start'])>0);io=union((float(r['start']),float(r['end']))for r in reads if int(r['result'])>0)
reports=[]
for request in data['runs']:
 if not request['id'].startswith('timed'):continue
 lo,hi=request['request_started_mach_ns']/1e9,request['request_ended_mach_ns']/1e9
 hh=rows(B/(label+'.json.'+request['id']+'.host.csv'))
 for h in hh:h.update(start=int(h['start_ns'])/1e9,end=int(h['end_ns'])/1e9)
 starts=sorted(hh,key=lambda h:h['start']);ends=sorted(hh,key=lambda h:h['end']);ts=[h['start']for h in starts];te=[h['end']for h in ends]
 active=inter(union(gpu+io+[[h['start'],h['end']]for h in hh]),[[lo,hi]]);gaps=[];edge=lo
 for a,b in active+[[hi,hi]]:
  if a>edge:
   mid=(edge+a)/2;i=bisect.bisect_right(te,mid)-1;j=bisect.bisect_left(ts,mid)
   prev=ends[i]['kind']if i>=0 else 'REQUEST_START';nxt=starts[j]['kind']if j<len(starts)else 'REQUEST_END'
   gaps.append(dict(start=edge-lo,end=a-lo,seconds=a-edge,previous=prev,next=nxt))
  edge=max(edge,b)
 groups=collections.defaultdict(list)
 for g in gaps:groups[(g['previous'],g['next'])].append(g)
 summary=sorted([dict(previous=k[0],next=k[1],count=len(v),seconds=sum(g['seconds']for g in v),max_seconds=max(g['seconds']for g in v))for k,v in groups.items()],key=lambda g:-g['seconds'])
 out=dict(id=request['id'],uncovered_seconds=sum(g['seconds']for g in gaps),groups=summary,largest=sorted(gaps,key=lambda g:-g['seconds'])[:20]);reports.append(out)
 print(request['id'],out['uncovered_seconds'])
 for g in summary[:14]:print(g)
(P/'uncovered-analysis.json').write_text(json.dumps(dict(scope='Offline localization of intervals outside every measured host scope, positive read and GPU encoder. Names identify nearest adjacent host scopes, not a causal stack or exclusive CPU attribution.',requests=reports),indent=2))
