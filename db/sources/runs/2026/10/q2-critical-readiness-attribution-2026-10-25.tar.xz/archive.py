from pathlib import Path
import hashlib,io,json,re,tarfile
P=Path(__file__).resolve().parent;R=P.parents[1]
sha=lambda b:hashlib.sha256(b).hexdigest()
refs=[]
for name,archive,patterns in [
 ('q2-host-profile-20261025','q2-ordinary-copies-attribution-2026-10-25.tar.xz',['ordinary-copies-15*']),
 ('q2-host-profile-20261025','q2-ordinary-host-attribution-2026-10-25.tar.xz',['analyze_ready.py']),
 ('q2-request-profile-20261025','q2-ordinary-request-and-submission-diagnosis-2026-10-25.tar.xz',['ordinary-traced-15*','analyze_trace.py','analyze_gaps.py','gap-analysis.json','SmartDFlashCommand-request-clock.swift']),
]:
 base=R/'.build'/name;prior=R/'db/sources/runs/2026/10'/archive
 manifest=None
 with tarfile.open(prior,'r|xz')as t:
  for m in t:
   if m.name=='archive-manifest.json':manifest=json.load(t.extractfile(m))
 assert manifest is not None
 needed={}
 for pattern in patterns:
  for f in base.glob(pattern):
   if not f.is_file()or f.suffix in ['.bin','.lock']:continue
   if f.name not in manifest:continue
   h=sha(f.read_bytes());assert h==manifest[f.name]['sha256'],f;needed[f.name]=h
 assert needed
 refs.append(dict(archive=str(prior.relative_to(R)),sha256=sha(prior.read_bytes()),files=needed))
(P/'prior-evidence.json').write_text(json.dumps(refs,indent=2))
groups=[('q2-graph-profile-20261025','q2-graph-and-small-read-attribution'),('q2-embedding-dedup-20261025','q2-embedding-dedup-rejected'),('q2-batch-greedy-20261025','q2-joint-greedy-rejected'),('q2-readiness-critical-20261025','q2-critical-readiness-attribution'),('q2-tail-profile-20261025','q2-demand-and-tail-attribution')]
secret=re.compile(rb'(?:ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{25,}|sk-(?:proj-)?[A-Za-z0-9_-]{30,}|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----)')
receipts=[]
for dirname,stem in groups:
 base=R/'.build'/dirname;files={}
 for f in base.rglob('*'):
  if not f.is_file()or'__pycache__'in f.parts or f.name=='archive-receipt.json':continue
  if f.suffix not in ['.py','.swift','.cpp','.mm','.json','.jsonl','.csv','.log','.stderr','.txt']and f.name!='build-source.tar.gz':continue
  files[str(f.relative_to(base))]=f
 if dirname=='q2-readiness-critical-20261025':files['reference/v68-build-identity.json']=R/'.build/native-replay-20261023/v68/build-identity.json'
 dest=R/'db/sources/runs/2026/10'/(stem+'-2026-10-25.tar.xz');assert not dest.exists()
 manifest={}
 for n,f in files.items():
  b=f.read_bytes();assert not secret.search(b),n;manifest[n]=dict(bytes=len(b),sha256=sha(b))
 raw=json.dumps(manifest,indent=2).encode()+b'\n'
 with tarfile.open(dest,'w:xz',preset=3)as t:
  for n,f in sorted(files.items()):t.add(f,arcname=n,recursive=False)
  info=tarfile.TarInfo('archive-manifest.json');info.size=len(raw);t.addfile(info,io.BytesIO(raw))
 seen={}
 with tarfile.open(dest,'r|xz')as t:
  for m in t:
   b=t.extractfile(m).read()
   if m.name=='archive-manifest.json':assert json.loads(b)==manifest
   else:seen[m.name]=dict(bytes=len(b),sha256=sha(b))
 assert seen==manifest
 receipt=dict(path=str(dest.relative_to(R)),files=len(manifest),bytes=dest.stat().st_size,sha256=sha(dest.read_bytes()),readback_verified=True,credential_pattern_matches=0)
 assert receipt['bytes']<90000000
 receipts.append(receipt);print(json.dumps(receipt),flush=True)
(P/'archive-receipt.json').write_text(json.dumps(dict(parts=receipts,prior_refs=refs,excluded='Executables, dylibs, metallibs, model weights, transient window files and pycache. Prior traces referenced by verified archive member hashes.'),indent=2))
