from pathlib import Path
import json,subprocess
P=Path(__file__).resolve().parent;R=P.parents[1];DB=R/'db';tool='/Users/carlos/.dbmd/bin/dbmd'
def write(path,kind,title,fields,body):
 f=P/(Path(path).name+'.body.md');f.write_text(body.strip()+'\n')
 cmd=[tool,'write',path,'--dir',str(DB),'--json','--type',kind,'--summary',title,'--fm','title='+title,'--body-file',str(f)]
 for k,v in fields.items():cmd+=['--fm',k+'='+str(v)]
 print(subprocess.run(cmd,check=True,capture_output=True,text=True).stdout.strip())
 if not(DB/path).exists():
  found=list(DB.rglob(Path(path).name));assert len(found)==1
  print(subprocess.run([tool,'rename',str(found[0].relative_to(DB)),path,'--dir',str(DB),'--json'],check=True,capture_output=True,text=True).stdout.strip())
a=json.loads((P/'archive-receipt.json').read_text());parts=[]
for p in a['parts']:
 n=Path(p['path']).name;parts.append(f"- [{n}]({n}): {p['files']} files, {p['bytes']} bytes, SHA-256 `{p['sha256']}`.")
source='sources/runs/2026/10/2026-10-25-q2-small-work-and-readiness.md'
write(source,'run','Q2 small-work controls and dependency attribution',dict(tool='Native diagnostic builds, bounded host/read/Metal observers, passive macmon, uninstrumented complete-request comparisons',command='Exact commands, frozen plans, source snapshots, build identities, raw outputs, guards, ledgers and analyses in linked archives',binary='v68 plus diagnostic CLI for baseline; isolated Q2 embedding or greedy candidates; published Splash1.4.0; separately bounded host-probe builds. Production restored.',captured_at='2026-10-25',machines='[[records/machines/macbook-pro-m5-pro-48gb]]',discarded='false'),f'''
{chr(10).join(parts)}

Archive members are read back and hash-checked, with no credential-pattern
matches. Executables, libraries, metallibs, weights and transient windows are
excluded. Prior read/encoder traces and helper sources are referenced by
verified archive and member hashes in `prior-evidence.json`.

Both ABCCBA complete-request protocols are clean; their candidates fail the
frozen repeatability gate. A failed optimization is not an environmental
exclusion. Neither is retained. The dedup test helper's initial compile failure
and repaired source are preserved; the runtime candidate did not change.

Host/read/encoder diagnostics are attribution only. Scopes and CPU workers
overlap. Metal intervals include scheduling and stalls. Missing upstream stage
timestamps are explicitly counted. The short greedy component test's sampled
process footprint misses its true peak and must not be presented as that peak.
Its bounded arithmetic checks and the complete-request memory guards are separate.

The record links these experiments without claiming numerical identity between
engines, quantization quality, full task-quality success or app readiness.
''')
body=(P/'measurement.body.md').read_text()
write('records/measurements/q2-small-work-and-readiness.md','measurement','Q2 small-work controls and dependency localization',dict(date='2026-10-25',doc='measurements',level=2,machines='[[records/machines/macbook-pro-m5-pro-48gb]]',order=1905,runs='[['+source[:-3]+']]',status='measured'),body)
old=DB/'records/measurements/q2-ordinary-host-attribution.md';text=old.read_text();body=text.split('---',2)[2].lstrip('\n')
body+='''

## Read-size scope clarification

The read intervals in this record include calls of at least 64 KiB. Smaller
token-embedding and PLE reads were outside that union; an uncovered interval
therefore was not necessarily host computation. The all-positive-read analysis
in [[records/measurements/q2-small-work-and-readiness]] refines that attribution,
preserving these original observations and raw traces. Overlapped copying and
preparation may still affect the critical path or contend for memory; small
exposed time alone does not prove that their implementation is optimal.
'''
f=P/'prior-record-clarification.body.md';f.write_text(body)
print(subprocess.run([tool,'--json','body','set','records/measurements/q2-ordinary-host-attribution.md','--body-file',str(f)],cwd=DB,check=True,capture_output=True,text=True).stdout.strip())
