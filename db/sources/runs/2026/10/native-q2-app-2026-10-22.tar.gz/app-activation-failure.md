# Explicit candidate activation failure

The corrected six-case harness loaded the Q2 engine, but the app could not publish its configuration identity because AppliedModelConfiguration admitted only the normal supported-model list. Q2 had deliberately been removed from that list to protect automatic selection. The run is retained under app-real-q2; it was stopped after repeated identical activation failures, before spending more time reloading the same weights.

The fix admits the exact pinned explicit candidate at the configuration boundary while leaving normal setup and automatic incumbent selection unchanged. The corrected real workflow run must verify actual model identity, memory ceiling and complete tasks again.
