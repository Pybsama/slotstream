# Explicit candidate label

The first delivered GUI showed the exact candidate title in Settings but the composer mapped every non-Fast pack to Smart. The composer now labels an already-selected Q2 pack as Q2 candidate. Normal users still see only Fast and Smart; the extra label exists only while that explicit engineering pack is selected. This does not promote the checkpoint or change inference arithmetic. Rebuild and visually verify the label after the first GUI inference test.
