# Selected-model harness correction

The first six-case app run requested Q2 in the outer runtime but constructed LocalInference with the older memory-only convenience initializer. That initializer uses Fast. The actual model-identity assertions caught all six mismatches. These outputs remain preserved under app-real-final and are not Q2 qualification.

The production AppModel.makeHomeRuntime already passes the same selected preferences to both owners. The check now uses LocalInference(preferences: preferences), matching production. The corrected run uses a new Home and retains the original identity assertions. No product model choice, runtime policy or quality assertion was weakened.
