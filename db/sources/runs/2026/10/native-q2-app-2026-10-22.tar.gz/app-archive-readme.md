# Native Q2 app qualification follow-up

Three retained app arms: the first incorrectly selected Fast, the second exposed a Q2 activation identity bug, and the corrected third passed all six workflows with the actual Q2 pack and memory ceiling asserted. First and second arms are diagnostic failures, not successful Q2 qualification.

Source and binary identities bind final app builds independently of CLI tests. The final label build changes only ContentView.swift relative to the successful activation build. The visible app completed NATIVE-Q2-READY before that display-only change; the rebuilt app visibly shows Q2 candidate. GUI instances use a separate defaults domain and synthetic Homes. The owned activation journal was moved out and the original absence restored; the test defaults domain was removed.

All real-model timing occurred with recorded global paging and is excluded from clean performance claims. The results establish bounded functional integration on one 48 GB Mac, not a public release, broad model quality, vision capability or 16/64 GB physical qualification.

Archives contain source, logs, synthetic fixtures, screenshots, results and observer receipts. Model weights, binaries, cache payloads, Home databases and credentials are excluded.
