import ctypes, hashlib, json, os, signal, subprocess, sys, time
from pathlib import Path

P = Path(__file__).resolve().parent
ROOT = P.parents[1]
sys.path.insert(0, str(ROOT / 'Tools'))
from prefill_bench import preflight, vm_snapshot, terminate_child_tree

class RUsage(ctypes.Structure):
    _fields_ = [('uuid', ctypes.c_uint8 * 16)] + [(n, ctypes.c_uint64) for n in (
        'user_time', 'system_time', 'pkg_idle_wkups', 'interrupt_wkups', 'pageins',
        'wired_size', 'resident_size', 'phys_footprint', 'proc_start_abstime',
        'proc_exit_abstime', 'child_user_time', 'child_system_time',
        'child_pkg_idle_wkups', 'child_interrupt_wkups', 'child_pageins',
        'child_elapsed_abstime', 'diskio_bytesread', 'diskio_byteswritten')]

binary = ROOT / 'apps/macos/.build/release/slotstream-mac-checks'
helper = binary.with_name('slotstream-extract')
home = P / 'app-real-final'
out = P / 'app-real-final-observer.json'
assert not home.exists() and not out.exists()
cases = 'writing,pdf,ocr_receipt,csv,code_edit,history_recall'
command = [str(binary), '--real-capabilities', '--q2', '--memory-gb', '10',
           '--case', cases, '--home', str(home)]
receipt = dict(command=command, binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
    helper_sha256=hashlib.sha256(helper.read_bytes()).hexdigest(),
    before=preflight(13), sample_interval_seconds=0.25, physical_limit_bytes=10_000_000_000,
    peak_root_bytes=0, peak_combined_bytes=0, samples=[], complete=False)
lib = ctypes.CDLL('/usr/lib/libproc.dylib')
lib.proc_pid_rusage.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_void_p]
lib.proc_pid_rusage.restype = ctypes.c_int
env = dict(os.environ, SLOTSTREAM_EXTRACT=str(helper))
started = time.monotonic()
with (P / 'app-real-final.log').open('x') as log:
    child = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, env=env, start_new_session=True)
    receipt['pid'] = child.pid
    try:
        last_vm = 0
        while child.poll() is None:
            children = subprocess.run(['pgrep', '-P', str(child.pid)], capture_output=True, text=True, timeout=3)
            values = {}
            for pid in [child.pid, *map(int, children.stdout.split())]:
                usage = RUsage()
                if lib.proc_pid_rusage(pid, 2, ctypes.byref(usage)) == 0:
                    values[pid] = usage.phys_footprint
            now = time.monotonic()
            root = values.get(child.pid, 0)
            total = sum(values.values())
            receipt['peak_root_bytes'] = max(receipt['peak_root_bytes'], root)
            receipt['peak_combined_bytes'] = max(receipt['peak_combined_bytes'], total)
            sample = dict(seconds=now-started, root_bytes=root, combined_bytes=total)
            receipt['samples'].append(sample)
            if total > receipt['physical_limit_bytes']:
                raise RuntimeError('App and helpers exceeded the explicit ten-GB envelope')
            if now-last_vm > 2:
                state = vm_snapshot()
                sample['reclaimable_bytes'] = state['reclaimable_bytes']
                last_vm = now
                if state['reclaimable_bytes'] < 1_000_000_000:
                    raise RuntimeError('Less than one GB reclaimable remains')
            if now-started > 2700:
                raise RuntimeError('Bounded app workflow timeout')
            time.sleep(0.25)
        receipt['exit_code'] = child.returncode
        receipt['complete'] = True
    except Exception as error:
        receipt['error'] = str(error)
    finally:
        if child.poll() is None:
            terminate_child_tree(child)
        receipt['after'] = vm_snapshot()
        receipt['seconds'] = time.monotonic()-started
        out.write_text(json.dumps(receipt, indent=2) + '\n')
print({k:v for k,v in receipt.items() if k in ['complete','error','exit_code','seconds','peak_root_bytes','peak_combined_bytes']}, flush=True)
raise SystemExit(receipt.get('exit_code', 1))
