import argparse,json,os,subprocess,sys,time,hashlib
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight,vm_snapshot,host_conditions,terminate_child_tree
sys.path.insert(0,str(R/'.build/native-q2-20261021'));from thermal import state,wait_nominal
ap=argparse.ArgumentParser();ap.add_argument('--label',required=True);ap.add_argument('--native',required=True);ap.add_argument('--baseline',required=True);ap.add_argument('--order',default='ABCCBA');ap.add_argument('--budget',type=float,default=9);ap.add_argument('--cases',default=str(P/'short-warm-cases.json'));ap.add_argument('--context',type=int,default=8192);ap.add_argument('--ahead',default='off',choices=['off','reserve','on']);ap.add_argument('--model',required=True,choices=['fast','smart-q2']);ap.add_argument('--schedule',choices=['0','1'],default='1');a=ap.parse_args()
limits={c['id']:c['maxTokens'] for c in json.loads(Path(a.cases).read_text())};assert all(v==384 for v in limits.values())
ledger=P/(a.label+'-ledger.json');assert not ledger.exists();events=[];cache_path=P/(a.label+'-cache.json');tokenpath=P/(a.label+'-tokens.json')
for index,arm in enumerate(a.order):
 label=a.label+'-'+str(index)+'-'+arm;out=P/(label+'.json');assert not out.exists()
 wait_nominal(P/(label+'-cooldown.json'))
 before=dict(vm=preflight(a.budget+3),thermal=state(),host=host_conditions());assert before['thermal']==0
 if arm in ('A','B'):
  command=[sys.executable,str(P/'guarded_run_io.py'),'--label',label+'-guard','--budget',str(a.budget),'--env','SLOTSTREAM_NATIVE_GDN_BLOCK='+('1' if arm=='B' else '0'),'--',str(Path(a.native if arm=='B' else a.baseline).resolve()),'smart-dflash-check','--native-read-ahead','on' if a.model=='smart-q2' else 'off','--method','q2' if a.model=='smart-q2' else 'fast','--model',a.model,'--memory-gb',str(a.budget),'--max-context',str(a.context),'--cases',str(Path(a.cases).resolve()),'--output',str(out)]
 else:
  cache=json.loads(cache_path.read_text())
  command=[sys.executable,str(P/('q2_upstream_bench_io.py' if a.model=='smart-q2' else 'upstream_bench_io.py')),'--memory-gb',str(a.budget),'--verify','auto','--kv','bf16','--cases',str(Path(a.cases).resolve()),'--tokens',str(tokenpath),'--output',str(out),'--context',str(a.context),'--expert-memory',str(cache['expert_memory']),'--ple-memory','51200000','--expected-slots',str(cache['slots'])]
 print('START',label,flush=True)
 with (P/(label+'-launcher.log')).open('x') as log:
  child=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:rc=child.wait(timeout=1800)
  finally:
   if child.poll() is None:terminate_child_tree(child)
 after=dict(vm=vm_snapshot(),thermal=state());event=dict(label=label,arm=arm,command=command,before=before,after=after,exit_code=rc,runs=[])
 if out.exists():
  d=json.loads(out.read_text())
  if arm in ('A','B'):
   assert all(r['stats']['nativeExecution'].get('pendingRecurrenceFolds',0)>0 for r in d['runs'])
   if a.model=='smart-q2':
    assert all((r.get('native_gdn_block_calls',0)>0)==(arm=='B') for r in d['runs'])
    assert all((r['stats'].get('dflashCalibrationCyclesBefore')or 0)>0 for r in d['runs'][1:])
    assert any((r['stats'].get('dflashBonusObservations')or 0)>0 for r in d['runs'])
   else:
    assert all((r['stats'].get('dflashCalibrationCyclesBefore')or 0)==0 and (r['stats'].get('dflashBonusObservations')or 0)==0 for r in d['runs'])
   if a.model=='smart-q2':assert all(r['stats']['nativeExecution'].get('hyperCombinations',0)>0 for r in d['runs'])
   assert all(r['stats']['nativeExecution'].get('routerRetirementPasses',0)>0 for r in d['runs'])
   assert all(r['native_draft_convolutions']>0 and r['draft_packed_projections']>0 for r in d['runs'])
   if a.model=='smart-q2':assert all((r['stats'].get('expertPrefetch',{}).get('parallelPieceRecords')or 0)>0 and r['stats']['nativeExecution']['gpuRepackedRecords']>0 and r['stats']['nativeExecution']['gpuForecastRecords']>0 and r['stats']['nativeExecution']['hyperConnections']>0 and r['native_mixed_expert_submissions']>0 for r in d['runs'])
   assert all(r['stats']['nativeExecution'].get('deferredExpertPasses',0)==0 for r in d['runs']);assert all(r['native_projection_schedule_failures']==0 and r['stats']['nativeExecution']['projectionFailures']==0 and r['stats']['nativeExecution']['adaptiveCacheClaims']>0 for r in d['runs']);slots=d['plan']['pool_slots'];cache={'slots':slots,'expert_memory':(3*(slots*409600+((slots*51200+16383)//16384)*16384)+471859200+98304+14336+16+32*(512+22)*4 if a.model=='smart-q2' else slots*1769472+465567744+40960+7168+16+32*(257+18)*4+4096)};tokens={'runs':[dict(id=r['id'],prompt_ids=r['prompt_ids'])for r in d['runs']]}
   for file,value in [(cache_path,cache),(tokenpath,tokens)]:
    if file.exists() and d.get('complete'):assert json.loads(file.read_text())==value
    else:file.write_text(json.dumps(value,indent=2))
   for row in d['runs']:
    s=row['stats'];assert row['native_expert_scheduled_passes']>0 if a.schedule=='1' else row['native_expert_scheduled_passes']==0;event['runs'].append(dict(id=row['id'],tokens=len(row['tokens']),tps=(s['decodeTokens']-1)/s['decodeSeconds'],request_seconds=row['elapsed_seconds'],prefill_seconds=s['prefillSeconds'],reused=s['reusedPrefixTokens'],paging=bool(row['swapins_delta']or row['swapouts_delta']),peak_gb=s['peakMemoryGB']))
  else:
   assert d['status_ready']['streamed_experts']['slots']==json.loads(cache_path.read_text())['slots']
   for row in d['runs']:
    t=row['timings'];event['runs'].append(dict(id=row['id'],tokens=row['usage']['completion_tokens'],tps=row['metrics']['decode']['tokens']/(t['predicted_ms']/1000),request_seconds=row['elapsed_seconds'],prefill_seconds=t['prompt_ms']/1000,reused=t['cache_n'],paging=bool(row['swapins_delta']or row['swapouts_delta']),peak_gb=d['peak_combined_bytes']/1e9))
  event['complete']=d.get('complete',False)
  event['process_paging']=any(after['vm'][k]!=before['vm'][k]for k in ['swapins','swapouts'])
  event['thermal_nominal']=before['thermal']==after['thermal']==0
  event['eligible']=not event['process_paging'] and all(not r['paging']for r in event['runs']) and rc==0 and event['complete'] and len([r for r in event['runs']if r['id'].startswith('timed')])==2 and event['thermal_nominal'] and all(not r['paging'] and r['reused']==0 and r['tokens']==limits[r['id']] and r['peak_gb']<=a.budget for r in event['runs']if r['id'].startswith('timed'))
 events.append(event);ledger.write_text(json.dumps(events,indent=2));print('END',label,'eligible',event.get('eligible'),'rates',[(r['id'],round(r['tps'],2),r['paging'],r['reused'])for r in event['runs']],flush=True)
 if rc:raise SystemExit(rc)
