from pathlib import Path
import json,subprocess,sys
P=Path(__file__).resolve().parent;R=P.parents[1]
arms=[];references={}
for model in ['smart-q2']:
 for enabled in [0,1]:
  label=f'v65c-combine-state-{model}-{enabled}'
  cmd=[sys.executable,str(P/'guarded_run.py'),'--label',label,'--budget','10','--timeout','600','--env','SLOTSTREAM_NATIVE_GDN_BLOCK=1','--env','SLOTSTREAM_NATIVE_HYPER_COMBINE='+str(enabled),'--',str(P/'v65c/slotstream'),'q2-profile','--model',model,'--memory-gb','10','--rounds','1','--retained-prefix','3','--fixture',str(P/('v29-profile-'+model+'-fixture.json')),'--output',str(P/(label+'.json'))]
  print('START',label,flush=True)
  with(P/(label+'-driver.log')).open('x')as f:r=subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT)
  if r.returncode:raise SystemExit(r.returncode)
  d=json.loads((P/(label+'.json')).read_text());o=json.loads((P/(label+'.observer.json')).read_text())
  assert len(d['runs'])==16 and all(x['max_logit_difference']==0 and x['argmax_equal']for x in d['runs'])
  for x in d['runs']:
   key=(model,x['width']);hashes=(x['logits_sha256'],x['recurrence_sha256'])
   original=json.loads((P/('v58b-combine-state-'+model+'-'+str(enabled)+'.json')).read_text())
   prior=next(r for r in original['runs']if r['width']==x['width'] and r['traced']==x['traced'])
   assert hashes==(prior['logits_sha256'],prior['recurrence_sha256']),('changed arithmetic against frozen schedule',label,key)
   references.setdefault(key,hashes);assert references[key]==hashes,('trained state or logits differ',label,key)
   assert (x['native_gdn_block_calls']>0) == (x['width']>1 and not x['traced']), (label, x)
   assert (x['native_hyper_combinations']>0)==(enabled==1),(label,x)
  arms.append(dict(label=label,complete=True,full_logits_and_recurrence_equal=True,branch_proven=True,peak=o['peak_combined_bytes']/1e9,paging=o['paging']))
  (P/'v65c-combine-state-summary.json').write_text(json.dumps(dict(complete=len(arms)==2,arms=arms,scope='Correctness only: trained fixed prefix, eight-row proposal retaining three rows, continued at widths 1/2/4/8, traced/untraced and enabled/disabled. Full FP32 logits and recurrent state hashes equal across every arm. This is not a serving speed comparison.'),indent=2)+'\n')
  print('END',arms[-1],flush=True)
