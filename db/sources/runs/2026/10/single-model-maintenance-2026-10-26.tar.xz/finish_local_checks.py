import os, sys, json, time, subprocess, hashlib
from pathlib import Path
root=Path.cwd(); out=root/'.build/single-model-20261026'
sys.path.insert(0,str(root/'Tools'))
from prefill_bench import preflight,vm_snapshot
while True:
    try: os.kill(59219,0)
    except ProcessLookupError: break
    time.sleep(3)
log=(out/'app-checks.txt').read_text()
assert 'FAILED SUITE:' not in log and '\nFAIL:' not in log, 'App checks report a failure'
assert 'archived-q2, rendered controls' in log and 'archived-fast, rendered controls' in log, 'Migration UI checks did not finish'
def run(name,args,env=None):
    with (out/(name+'.txt')).open('w') as f:
        result=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,env=env)
    (out/(name+'-status.json')).write_text(json.dumps({'command':args,'exit_code':result.returncode},indent=2)+'\n')
    print(name, result.returncode, flush=True)
    if result.returncode: raise SystemExit(result.returncode)
run('app-final-freshness',['python3','Tools/prepare_slotstream_build.py','--configuration','release','--check'])
(out/'bundle-admission.json').write_text(json.dumps(preflight(7),indent=2)+'\n')
run('bundle-build',['bash','Tools/build_slotstream_mac.sh'])
run('bundle-signature',['codesign','--verify','--deep','--strict','.build/Slotstream.app'])
actual=json.loads(subprocess.check_output(['python3','Tools/mac_build_inputs.py',str(Path.home()/'.dbmd/bin/dbmd')],text=True))
embedded=json.loads((root/'.build/Slotstream.app/Contents/Resources/build-inputs.json').read_text())
assert actual==embedded, 'Bundle inputs differ from final source'
identity={'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'manifest_matches':True,'manifest':embedded,'artifacts':{}}
for name in ['.build/release/slotstream','apps/macos/.build/release/slotstream-mac-checks','.build/Slotstream.app/Contents/MacOS/Slotstream','.build/Slotstream.app/Contents/MacOS/mlx.metallib','.build/Slotstream.app/Contents/Helpers/slotstream-extract']:
    identity['artifacts'][name]=hashlib.sha256((root/name).read_bytes()).hexdigest()
(out/'build-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
(out/'real-admission.json').write_text(json.dumps(preflight(13),indent=2)+'\n')
env=os.environ.copy(); env['SLOTSTREAM_EXTRACT']=str(root/'.build/Slotstream.app/Contents/Helpers/slotstream-extract')
run('real-workflows',['apps/macos/.build/release/slotstream-mac-checks','--real-capabilities','--home',str(out/'real-workflows'),'--memory-gb','10','--case','csv,code_edit,history_recall'],env)
(out/'real-after.json').write_text(json.dumps(vm_snapshot(),indent=2)+'\n')
print('LOCAL VERIFICATION COMPLETE',flush=True)
