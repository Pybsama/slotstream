from pathlib import Path
import json,struct,numpy as np
h=json.loads(Path('.build/smart-dflash-eval/gsq-header.json').read_text()); start=(h['header_bytes']+31)//32*32
p=Path.home()/'.slotstream/models/qwen38-flash-next-mlx-4bit'
refs={}
for f in p.glob('model-*.safetensors'):
 with f.open('rb') as s:
  n=struct.unpack('<Q',s.read(8))[0]; hdr=json.loads(s.read(n))
  for name,t in hdr.items():
   if not name=='__metadata__': refs[name.removeprefix('language_model.')]=(f,8+n,t)
def original(name):
 f,start,t=refs[name]
 with f.open('rb') as s:s.seek(start+t['data_offsets'][0]);b=s.read(t['data_offsets'][1]-t['data_offsets'][0])
 if t['dtype']=='BF16':return (np.frombuffer(b,np.uint16).astype(np.uint32)<<16).view(np.float32).reshape(t['shape'])
 return np.frombuffer(b,{'F32':'<f4','F16':'<f2'}[t['dtype']]).reshape(t['shape'])
pairs=[('blk.0.hc_attn_norm.weight','model.layers.0.attn_hyper_connection.hc_norm.weight'),('blk.0.ssm_a','model.layers.0.linear_attn.A_log'),('blk.0.ssm_conv1d.weight','model.layers.0.linear_attn.conv1d.weight'),('blk.3.attn_q_norm.weight','model.layers.3.self_attn.q_norm.weight'),('blk.0.hc_attn_inject.weight','model.layers.0.attn_hyper_connection.block_inject_weight.weight')]
with open('.build/smart-dflash-eval/gsq/Qwen3.8-Flash-Next-GSQ-RCO-Q2_0-00001-of-00002.gguf','rb') as s:
 for src,dst in pairs:
  t=next(t for t in h['tensors'] if t['name']==src);s.seek(start+t['offset']);n=int(np.prod(t['dimensions']));b=s.read(n*(4 if t['type']==0 else 2))
  a=np.frombuffer(b,'<f4') if t['type']==0 else (np.frombuffer(b,np.uint16).astype(np.uint32)<<16).view(np.float32)
  o=original(dst).ravel()
  print(src,'shape',t['dimensions'],'gguf',a[:6],'original',o[:6],'maxdiff',np.max(np.abs(a-o)))
  if src.endswith('ssm_a'): print('A exp residual',np.max(np.abs(-np.exp(o)-a)))
