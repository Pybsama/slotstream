import argparse,json,os,subprocess,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent;ROOT=P.parents[1]
sys.path.insert(0,str(ROOT/'Tools'))
from prefill_bench import preflight,vm_snapshot,host_conditions,terminate_child_tree,digest
from thermal import state
ap=argparse.ArgumentParser();ap.add_argument('--budget',type=float,default=10);ap.add_argument('--label',required=True);ap.add_argument('--arm',choices=['q2','smart'],default='q2');ap.add_argument('--no-budget',action='store_true');ap.add_argument('--native-dir',default='native-v1');ap.add_argument('--baseline-dir',default='baseline');args=ap.parse_args()
binary=P/(args.native_dir if args.arm=='q2' else args.baseline_dir)/'slotstream'
case=json.loads((P/'performance-cases.json').read_text())[0]
prompt=P/'performance-prompt.txt'
if not prompt.exists():prompt.write_text(case['prompt'])
out=P/f'{args.arm}-{args.budget:g}-{args.label}.json';assert not out.exists()
raw=out.with_name(out.stem+'-raw.json');assert not raw.exists()
def observe():
 return {'vm':vm_snapshot(),'thermal':state(),'host':host_conditions(),'processes':subprocess.check_output(['ps','-axo','pid,ppid,rss,comm'],text=True)}
preflight(args.budget+3);before=observe()
assert before['thermal']<2,'serious or critical thermal state'
env=dict(os.environ)
if args.no_budget:env['SLOTSTREAM_Q2_VERIFY_BUDGET']='0'
command=[str(binary),'run','--model','smart-q2' if args.arm=='q2' else 'smart','--memory-gb',str(args.budget),'--max-context','8192','--vision','off','--max-tokens',str(case['maxTokens']),'--prompt-file',str(prompt),'--greedy','--sample-footprint','--stats-json',str(raw)]
start=time.monotonic()
with out.with_suffix('.log').open('x') as log:
 child=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True)
 try:rc=child.wait(timeout=1200)
 finally:
  if child.poll() is None:terminate_child_tree(child)
after=observe();receipt={'arm':args.arm,'budget_gb':args.budget,'command':command,'binary_sha256':digest(binary),'exit_code':rc,'wall_seconds':time.monotonic()-start,'before':before,'after':after,'verify_budget_disabled':args.no_budget}
if raw.exists():
 d=json.loads(raw.read_text());receipt['result']=d
 s=d['stats'];receipt['functional']=rc==0 and s['peakMemoryGB']<=args.budget and not s['memoryPressureCancelled'] and not s.get('runtimeError')
 receipt['decode_tps']=s['decodeTokens']/s['decodeSeconds']
 receipt['paging']=any(after['vm'][k]!=before['vm'][k] for k in ['swapins','swapouts'])
 receipt['nominal_thermal']=before['thermal']==after['thermal']==0
out.write_text(json.dumps(receipt,indent=2)+'\n')
print({k:receipt.get(k) for k in ['arm','budget_gb','exit_code','wall_seconds','decode_tps','functional','paging','nominal_thermal']},flush=True)
if rc:raise SystemExit(rc)
