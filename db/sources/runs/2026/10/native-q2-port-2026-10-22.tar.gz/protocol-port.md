# Native Q2 port qualification

Exact pinned target shards and Smart DFlash2 run inside Swift/MLX/Metal. No Splash or Python runtime is launched by Slotstream. Frozen binaries and their complete source manifests are retained for each tested implementation.

One model at a time; explicit ten-GB functional targets, target plus three GB reclaimable preflight. Sixteen-GB runs are capacity/performance diagnostics only. The other Splash session is left untouched. Global paging excludes clean timing, but does not independently fail correctness or process-memory acceptance. No GPU spin, power-state intervention, memory-hog process or forced availability is used.

The twenty-four pre-existing quality cases and rubric stay fixed. Semantic and strict-format results stay separate. Six additional frozen probes exercise continuation, cancellation recovery, stop buffering and tool-call decoding. Simulated RAM reports only check planning; they do not establish physical hardware qualification.

Production throughput controls use greedy non-thinking generation, the same 1,024-token coding cap, requested 8K context, vision off and process-footprint sampling. Reaching the cap is not a completed correct coding job. Diagnostic quality uses the separately priced 32K context and capped 256-token prompt chunks.

The app candidate must use its actual compiled engine, installation manifests, planner, Home, tool and review boundaries. Scripted UI/runtime regressions are separate from real-model job receipts. Default promotion requires a useful complete-work tradeoff and preserved capabilities; one successful answer or a component numerical check cannot grant it.

This method summary was written after the v2 functional runs. It is a retrospective protocol record, not preregistration. The cases themselves predate the corresponding generations. The later v3 kernel trial extends shared-weight dense computation to short verification batches; its results must be recorded separately.
