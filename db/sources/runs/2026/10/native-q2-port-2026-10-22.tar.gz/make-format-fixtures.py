import sys,json,base64,struct,hashlib
from pathlib import Path
import numpy as np
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'oracle'))
from gguf.quants import dequantize
from gguf.constants import GGMLQuantizationType,GGML_QUANT_SIZES
header=json.loads(Path('.build/smart-dflash-eval/gsq-header.json').read_text())
start=(header['header_bytes']+31)//32*32
source=Path('.build/smart-dflash-eval/gsq/Qwen3.8-Flash-Next-GSQ-RCO-Q2_0-00001-of-00002.gguf')
cases=[]
with source.open('rb') as f:
 for kind in sorted({t['type'] for t in header['tensors']}):
  t=next(t for t in header['tensors'] if t['type']==kind and np.prod(t['dimensions'])>=2048)
  block,size=(64,18) if kind==42 else GGML_QUANT_SIZES[GGMLQuantizationType(kind)]
  columns=256;rows=8
  f.seek(start+t['offset']); raw=f.read(rows*columns//block*size)
  arr=np.frombuffer(raw,np.uint8).reshape(rows,-1)
  if kind==42:
   b=arr.reshape(-1,18);sc=b[:,:2].copy().view('<f2').astype(np.float32)
   q=((b[:,2:,None]>>np.array([0,2,4,6],np.uint8))&3).reshape(-1,64).astype(np.float32)
   decoded=(sc*(q-1)).reshape(rows,columns)
  else: decoded=dequantize(arr,GGMLQuantizationType(kind)).reshape(rows,columns)
  x=(np.arange(columns,dtype=np.float32)%13-6)/8
  expected=(decoded@x).astype(np.float32)
  cases.append(dict(format=kind,bytes=base64.b64encode(raw).decode(),columns=columns,rows=rows,
   expected=decoded.ravel().tolist(),input=x.tolist(),product=expected.tolist(),source=t['name']))
(root/'format-fixtures.json').write_text(json.dumps(cases))
print('fixtures',len(cases),'sha256',hashlib.sha256((root/'format-fixtures.json').read_bytes()).hexdigest())
