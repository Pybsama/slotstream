from pathlib import Path
def change(path,old,new):
 p=Path(path);s=p.read_text();assert old in s,(path,old[:90]);p.write_text(s.replace(old,new))
p='Sources/Slotstream/Checkpoint.swift'
change(p,'    private let authenticatedFiles: [URL: VQTensorFile]','    package private(set) var q2: Q2Checkpoint?\n    private let authenticatedFiles: [URL: VQTensorFile]')
change(p,'    /// Tensor offsets from the primary are reused on every replica.', '''    package init(q2Directory directory: URL) throws {
        let source = try Q2Checkpoint(directory: directory)
        self.q2 = source; self.dir = directory; self.config = source.config
        self.mirrorDirs = []; self.mirror = MirrorRouter(replicaCount: 1)
        self.authenticatedFiles = [:]; self.affineExpertArtifact = nil
        self.authenticatedStorageIdentity = PinnedQ2Model.revision
        for (name, tensor) in source.mapped where name.contains(".switch_mlp.") {
            tensors[name] = TensorRef(file: tensor.file.url, dtype: "U8",
                shape: [512, tensor.shape[1], tensor.rowBytes], byteOffset: tensor.offset, byteCount: tensor.byteCount)
        }
        for file in source.files {
            let descriptor = dup(file.fd)
            guard descriptor >= 0 else { throw ModelError("Cannot retain Q2 read descriptor") }
            fds[file.url] = [descriptor]
        }
    }

    /// Tensor offsets from the primary are reused on every replica.''')
change(p,'    package func verifyAuthenticatedFilesUnchanged() throws {','    package func verifyAuthenticatedFilesUnchanged() throws {\n        for file in q2?.files ?? [] { try file.verifyUnchanged() }')
p='Sources/Slotstream/Weights.swift'
change(p,'    public let bits: Int\n','    public let bits: Int\n    package var gguf: Q2GGUFLinear? = nil\n')
change(p,'    public func callAsFunction(_ x: MLXArray) -> MLXArray {','    public func callAsFunction(_ x: MLXArray) -> MLXArray {\n        if let gguf { return gguf(x) }')
change(p,'        let w = tensor(base + ".weight")','''        if let packed = (self as? ResidentWeights)?.ggufLinears[base] {
            var value = QLinear(w: packed.bytes, scales: nil, biases: nil, groupSize: 64, bits: 2)
            value.gguf = packed; return value
        }
        let w = tensor(base + ".weight")''')
change(p,'    private let embeddingRows: EmbeddingRows?','    private let embeddingRows: EmbeddingRows?\n    private let q2: Q2Checkpoint?\n    package let ggufLinears: [String: Q2GGUFLinear]')
change(p,'        self.config = index.config','''        self.config = index.config
        self.q2 = index.q2
        if let q2 = index.q2 {
            self.embeddingRows = nil; self.packedGDNProjections = [:]
            let loaded = try q2.residents()
            self.arrays = loaded.arrays; self.ggufLinears = loaded.linears
            return
        }
        self.ggufLinears = [:]''')
change(p,'    public func embedChecked(_ ids: MLXArray) throws -> MLXArray {','''    public func embedChecked(_ ids: MLXArray) throws -> MLXArray {
        if let q2 { return try q2.embedding(ids.asType(.int64).asArray(Int64.self).map(Int.init), shape: ids.shape) }''')
change(p,'    package func embedChecked(_ ids: [Int], shape: [Int]) throws -> MLXArray {','''    package func embedChecked(_ ids: [Int], shape: [Int]) throws -> MLXArray {
        if let q2 { return try q2.embedding(ids, shape: shape) }''')
p='Sources/Slotstream/NgramStore.swift'
change(p,'        for s in 0 ..< cfg.splitNgramParts {','''        if index.q2 != nil {
            self.wRowBytes = 90; self.sRowBytes = 0
            self.rowReader = RowReader(index: index, rowsPerShard: rowsPerShard, headDim: headDim, qGroup: cfg.ngramQGroup,
                wRefs: [], sRefs: [], bRefs: [], wRowBytes: 90, sRowBytes: 0)
            return
        }
        for s in 0 ..< cfg.splitNgramParts {''')
change(p,'            guard let value = Int(exactly: gid)', '''            if let q2 = index.q2 {
                guard shouldContinue() else { throw CheckpointReadError.cancelled }
                try fault?.beforeRead()
                return try q2.pleRow(gid)
            }
            guard let value = Int(exactly: gid)''')
p='Sources/Slotstream/ExpertStore.swift'
change(p,'    package let quantization: AffineQuantization','    package var isQ2: Bool { index.q2 != nil }\n    package var pieceCount: Int { refs[0].count }\n    package let quantization: AffineQuantization')
change(p,'        refs[0][0 ..< 9].map { r in','        refs[0].map { r in')
change(p,'r.dtype == "U32" ? DType.uint32 : DType.bfloat16','r.dtype == "U8" ? DType.uint8 : r.dtype == "U32" ? DType.uint32 : DType.bfloat16')
change(p,'        self.downQuantization = down','''        self.downQuantization = down
        if index.q2 != nil {
            for layer in 0..<cfg.numLayers {
                refs.append(["gate_proj", "up_proj", "down_proj"].map {
                    index.ref("model.layers.\\(layer).mlp.switch_mlp." + $0 + ".weight")
                })
            }
            pieceRowBytes = refs[0].map { $0.rowBytes }
            return
        }''')
s=Path(p).read_text(); split=s.index('public final class SlotPool')
a,b=s[:split],s[split:]
a=a.replace('0 ..< 9','0 ..< pieceCount').replace('refs[0][0 ..< pieceCount]','refs[0]')
a=a.replace('bases.count == 9, pieceRowBytes.count == 9','bases.count == pieceCount, pieceRowBytes.count == pieceCount').replace('n * 9','n * pieceCount').replace('j / 9','j / pieceCount').replace('j % 9','j % pieceCount').replace('runs.count * 9','runs.count * pieceCount')
a=a.replace('case "U32": dtype = .uint32','case "U8": dtype = .uint8\n            case "U32": dtype = .uint32')
b=b.replace('0 ..< 9','0 ..< pools.count').replace('0..<9','0..<pools.count').replace('count: 9)','count: pools.count)').replace('guard pools.count == 9 else','guard pools.count == store.pieceCount else')
Path(p).write_text(a+b)
p='Sources/Slotstream/Model.swift'
change(p,'        if index.config.isFast {','        if index.config.isFast || index.q2 != nil {')
change(p,'            self.optimizations.layerExpertWorkspace = false','''            self.optimizations.layerExpertWorkspace = false
            if index.q2 != nil {
                self.optimizations.fusedGDNProjection = false
                self.optimizations.fusedPrefillWorkspace = false
            }''')
# Small verify batches and the sweep both use packed Q2, sharing the same cache and accounting.
p='Sources/Slotstream/Layers.swift'
change(p,'            let xe = x.expandedDimensions(axes: [-2, -3])','''            let xe = x.expandedDimensions(axes: [-2, -3])
            if pool.expertStore.isQ2 {
                return q2Experts(x, weights: pool.pools, ids: slotIdx, repeatInput: count)
                    .reshaped([B, S, count, cfg.hiddenSize])
            }''')
start=Path(p).read_text().index('                    let g = gatherQuantizedMM(',Path(p).read_text().index('private func sweep('))
s=Path(p).read_text();end=s.index('                    let d = pad > 0',start)
old=s[start:end]
new='''                    let dAll: MLXArray
                    if pool.expertStore.isQ2 {
                        dAll = q2Experts(xg, weights: w, ids: ridx, repeatInput: 1).expandedDimensions(axis: 1)
                    } else {
'''+old.replace('                    let dAll =','                    dAll =')+'''                    }
'''
s=s[:start]+new+s[end:];Path(p).write_text(s)
change(p,'    /// The pool path: pin the routed experts', '''    private func q2Experts(_ x: MLXArray, weights: [MLXArray], ids: MLXArray, repeatInput: Int) -> MLXArray {
        let g = Q2GGUFLinear.gather(x, bytes: weights[0], format: .q20, rows: cfg.moeIntermediate,
            columns: cfg.hiddenSize, indices: ids, repeatInput: repeatInput)
        let u = Q2GGUFLinear.gather(x, bytes: weights[1], format: .q20, rows: cfg.moeIntermediate,
            columns: cfg.hiddenSize, indices: ids, repeatInput: repeatInput)
        return Q2GGUFLinear.gather(MLXNN.silu(g) * u, bytes: weights[2], format: .q20, rows: cfg.hiddenSize,
            columns: cfg.moeIntermediate, indices: ids, repeatInput: 1)
    }

    /// The pool path: pin the routed experts''')
