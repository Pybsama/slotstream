from pathlib import Path
def change(path,old,new):
 p=Path(path);s=p.read_text();assert old in s,(path,old[:80]);p.write_text(s.replace(old,new))
p='Sources/Slotstream/Q2GGUFLinear.swift'
change(p,'    let columns: Int\n','    let columns: Int\n    var inputOrder: MLXArray?\n    var outputOrder: MLXArray?\n')
change(p,'        let n = x.size / columns','        let input = inputOrder.map { take(x, $0, axis: -1) } ?? x\n        let n = input.size / columns')
change(p,'        return Self.gather(x, bytes: bytes','        let output = Self.gather(input, bytes: bytes')
change(p,'            indices: ids, repeatInput: 1).reshaped(Array(x.shape.dropLast()) + [rows])','            indices: ids, repeatInput: 1).reshaped(Array(x.shape.dropLast()) + [rows])\n        return outputOrder.map { take(output, $0, axis: -1) } ?? output')
p='Sources/Slotstream/Q2Checkpoint.swift'
change(p,'        var arrays: [String: MLXArray] = [:], linears:', '''        // GGUF groups the j-th value head of all key heads together. Native
        // recurrence groups the three value heads belonging to each key.
        let grouped = (0..<48).map { ($0 % 3) * 16 + $0 / 3 }
        let tiled = (0..<48).map { ($0 % 16) * 3 + $0 / 16 }
        func channels(_ heads: [Int]) -> [Int32] { heads.flatMap { h in (0..<128).map { Int32(h * 128 + $0) } } }
        let valueOrder = channels(grouped), outputOrder = MLXArray(channels(tiled))
        let qkvOrder = MLXArray((0..<4096).map(Int32.init) + valueOrder.map { $0 + 4096 })
        var arrays: [String: MLXArray] = [:], linears:''')
change(p,'                linears[String(name.dropLast(7))] = Q2GGUFLinear(bytes: packed, format: tensor.format,\n                    rows: tensor.rows, columns: tensor.columns)','''                var projection = Q2GGUFLinear(bytes: packed, format: tensor.format,
                    rows: tensor.rows, columns: tensor.columns)
                if name.hasSuffix("linear_attn.in_proj_qkv.weight") { projection.outputOrder = qkvOrder }
                if name.hasSuffix("linear_attn.in_proj_z.weight") { projection.outputOrder = MLXArray(valueOrder) }
                if name.hasSuffix("linear_attn.out_proj.weight") { projection.inputOrder = outputOrder }
                linears[String(name.dropLast(7))] = projection''')
change(p,'                if name.hasSuffix(".A_log") { a = log(-a) }\n                else if name.hasSuffix("conv1d.weight") { a = a.expandedDimensions(axis: -1).asType(.bfloat16) }','''                if name.contains(".linear_attn.") {
                    if name.hasSuffix(".A_log") || name.hasSuffix(".dt_bias")
                        || name.hasSuffix("in_proj_a.weight") || name.hasSuffix("in_proj_b.weight") {
                        a = take(a, MLXArray(grouped.map(Int32.init)), axis: 0)
                    }
                    if name.hasSuffix("conv1d.weight") { a = take(a, qkvOrder, axis: 0) }
                }
                if name.hasSuffix(".A_log") { a = log(-a) }
                else if name.hasSuffix("conv1d.weight") {
                    a = a.expandedDimensions(axis: -1).asType(name.contains(".ple.") ? .float32 : .bfloat16)
                }''')
change(p,'else if name.hasSuffix(".dt_bias") || name.contains("norm") { a = a.asType(.bfloat16) }','else if name.hasSuffix(".dt_bias") { a = a.asType(.bfloat16) }')
p='Sources/Slotstream/Layers.swift'
change(p,'    func callAsFunction(_ x: MLXArray, compiledFinish: Bool = false) -> MLXArray {','''    func callAsFunction(_ x: MLXArray, compiledFinish: Bool = false) -> MLXArray {
        if weight.dtype == .float32 {
            let value = x.asType(.float32)
            let grouped = groupSize.map { value.reshaped(Array(x.shape.dropLast()) + [-1, $0]) } ?? value
            let normalized = grouped * rsqrt(grouped.square().mean(axis: -1, keepDims: true) + eps)
            return (normalized.reshaped(x.shape) * weight).asType(x.dtype)
        }''')
change(p,'        let out = MLXFast.rmsNorm(x, weight: weight, eps: eps)','        let out = MLXFast.rmsNorm(weight.dtype == .float32 ? x.asType(.float32) : x, weight: weight, eps: eps)')
change(p,'return MLXNN.silu(conv1d(window, convWeight, dilation: dilation, groups: convWeight.dim(0)))','return MLXNN.silu(conv1d(window.asType(convWeight.dtype), convWeight, dilation: dilation, groups: convWeight.dim(0))).asType(x.dtype)')
