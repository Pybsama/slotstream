import Foundation
struct Row: Decodable {let confidence:[Float];let depth:Int;let accepted:Int;let seconds:Double}
let sequence = try JSONDecoder().decode([Row].self,from:Data(contentsOf:URL(fileURLWithPath:CommandLine.arguments[1])))
var policy=DFlashVerifyBudget()
for (i,row) in sequence.enumerated(){
 let actual=policy.depth(confidence:row.confidence)
 guard actual==row.depth else{fatalError("Mismatch at \(i): \(actual) expected \(row.depth)")}
 policy.observe(confidence:row.confidence,verified:row.depth,accepted:row.accepted,seconds:row.seconds)
}
print("PASS \(sequence.count) cycles including two online refits")
