from pathlib import Path
def change(path,old,new):
 p=Path(path);s=p.read_text();assert old in s,(path,old[:90]);p.write_text(s.replace(old,new))
p='Sources/Slotstream/PackMemoryProfile.swift'
change(p,'    package static let smartDFlash =', '''    package static let q2 = Self(identity: "gsq-q2-native-memory-v1",
        expertRecordBytes: 1_382_400, residentReserveBytes: 1_600_000_000,
        maximumPrefill: 512, maximumContext: 32_768, usesBaselineSpeedEvidence: false,
        supportsStreamedDraft: false, supportsVision: false, automaticOptimizations: false)

    package static let smartDFlash =''')
p='Sources/Slotstream/ModelPackStartupDefaults.swift'
change(p,'    package static let original =', '''    package static let q2 = Self(id: "gsq-q2-native-startup-v1",
        automaticCeilingBytes: Int64(Planner.usefulCeilingGB * 1e9), contextTokens: 32768,
        draftMode: .off, draftPlacement: .automatic, draftDepth: 0,
        lookahead: .off, prefixCacheEnabled: true,
        shortPromptTokens: 1536, shortPromptChunk: 256,
        reference: "db/records/decisions/smart-dflash-and-target-quantization.md")

    package static let original =''')
p='Sources/Slotstream/ModelPackRegistry.swift'
change(p,'    public static let supported: [ModelPack] = [fast, baseline]', '''    /// Explicit qualification candidate. The Smart alias remains unchanged
    /// until complete native workflow, speed and quality gates pass.
    public static let q2Candidate = ModelPack(id: PinnedQ2Model.name, title: "Smart Q2 candidate",
        checkpointRevision: baseline.checkpointRevision, conversionRevision: PinnedQ2Model.revision,
        deployment: PinnedQ2Model.deployment, memoryProfile: .q2, startupDefaults: .q2,
        directoryName: PinnedQ2Model.directoryName, layout: "gsq-rco-mixed-gguf-q2-native-v1",
        compatibility: "slotstream-qwen38-gsq-q2-v1",
        supportEvidence: ["db/records/decisions/smart-dflash-and-target-quantization.md"],
        qualifiedAutomaticProfiles: [], decodeForecastFiles: [])

    public static let supported: [ModelPack] = [fast, baseline, q2Candidate]''')
change(p,'        case "fast", PinnedFastModel.name', '        case "smart-q2", PinnedQ2Model.name, PinnedQ2Model.directoryName: return q2Candidate\n        case "fast", PinnedFastModel.name')
change(p,'ModelPackRegistry.baseline, ModelPackRegistry.researchStandalone]', 'ModelPackRegistry.baseline, ModelPackRegistry.q2Candidate, ModelPackRegistry.researchStandalone]')
change(p,'        let draftRows = usesDFlash ? DFlashDeployment.files.sorted', '        let draftRows = usesDFlash ? draftFiles.sorted')
change(p,'"files": rows + draftRows]', '"files": rows + draftRows + (id == PinnedQ2Model.name ? PinnedQ2Model.metadataFiles.map { [$0.path, String($0.size), $0.sha256!, "required"] } : [])]')
p='Sources/Slotstream/DFlashDeployment.swift'
change(p,'var usesDFlash: Bool { id == PinnedFastModel.name }','var usesDFlash: Bool { id == PinnedFastModel.name || id == PinnedQ2Model.name }\n    var draftFiles: [PinnedModel.File] { id == PinnedQ2Model.name ? SmartDFlashDeployment.files : DFlashDeployment.files }')
change(p,'var installationBytes: Int64 { totalBytes + (usesDFlash ? DFlashDeployment.deployment.totalBytes : 0) }','''var installationBytes: Int64 { totalBytes + (usesDFlash ? draftFiles.reduce(0) { $0 + $1.size } : 0)
        + (id == PinnedQ2Model.name ? PinnedQ2Model.metadataDeployment.totalBytes : 0) }''')
change(p,'[WeightStore(modelDirectory: directory, pack: self)] + (usesDFlash ? [DFlashDeployment.store(for: directory)] : [])','''[WeightStore(modelDirectory: directory, pack: self)]
            + (id == PinnedQ2Model.name ? [WeightStore(modelDirectory: directory, deployment: PinnedQ2Model.metadataDeployment)] : [])
            + (usesDFlash ? [id == PinnedQ2Model.name ? SmartDFlashDeployment.store(for: directory) : DFlashDeployment.store(for: directory)] : [])''')
change(p,'files.map { directory.appendingPathComponent($0.path) } + (usesDFlash\n            ? DFlashDeployment.files.map','(files + (id == PinnedQ2Model.name ? PinnedQ2Model.metadataFiles : [])).map { directory.appendingPathComponent($0.path) } + (usesDFlash\n            ? draftFiles.map')
p='Sources/Slotstream/WeightDownload.swift'
change(p,'        if ["fast", PinnedFastModel.name', '        if ["smart-q2", PinnedQ2Model.name, PinnedQ2Model.directoryName].contains(spec) {\n            return userModelsDir.appendingPathComponent(PinnedQ2Model.directoryName)\n        }\n        if ["fast", PinnedFastModel.name')
p='Sources/Slotstream/Engine.swift'
change(p,'    package var modelQuantization: String {','    package var modelQuantization: String {\n        if resources == .q2 { return "GSQ-RCO mixed precision / Q2_0 experts" }')
change(p,'    package var modelDigest: String {','    package var modelDigest: String {\n        if resources == .q2 { return "sha256:" + ModelPackRegistry.q2Candidate.manifestDigest }')
change(p,'    package func acceptsModelName(_ requested: String) -> Bool {','    package func acceptsModelName(_ requested: String) -> Bool {\n        if resources == .q2 { return [modelName, "smart-q2", PinnedQ2Model.directoryName].contains(requested) }')
change(p,'(plan?.resources == .smartDFlash ? .smartDFlash : .original)))','(plan?.resources == .q2 ? .q2 : (plan?.resources == .smartDFlash ? .smartDFlash : .original))))')
change(p,'if resources == .smartDFlash, plan?.mtpEnabled != false','if resources == .smartDFlash || resources == .q2, plan?.mtpEnabled != false')
change(p,'affineSource?.artifact.modelName ?? (resources == .fast ? PinnedFastModel.name : PinnedModel.name)','affineSource?.artifact.modelName ?? (resources == .q2 ? PinnedQ2Model.name : resources == .fast ? PinnedFastModel.name : PinnedModel.name)')
change(p,'        } else { index = try CheckpointIndex(dir: modelDir, mirrors: mirrors) }','''        } else if resources == .q2 {
            guard mirrors.isEmpty else { throw ModelError("Q2 checkpoint mirrors are not supported") }
            _ = try PinnedTokenizerMetadata(directory: modelDir)
            index = try CheckpointIndex(q2Directory: modelDir)
        } else { index = try CheckpointIndex(dir: modelDir, mirrors: mirrors) }''')
change(p,'if resources == .smartDFlash || (resources == .fast','if resources == .smartDFlash || resources == .q2 || (resources == .fast')
change(p,'let store = resources == .smartDFlash ?','let store = resources == .smartDFlash || resources == .q2 ?')
p='Sources/Slotstream/Q2Checkpoint.swift'
change(p,'else if name.hasSuffix(".dt_bias") { a = a.asType(.bfloat16) }','else if name.hasSuffix(".dt_bias") || name.contains("norm") { a = a.asType(.bfloat16) }')
