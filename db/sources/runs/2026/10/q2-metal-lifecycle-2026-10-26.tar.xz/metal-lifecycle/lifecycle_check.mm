#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <atomic>
#include <cstdio>
static std::atomic<int> callbacks{0};
int main(){ @autoreleasepool{
 id<MTLDevice>d=MTLCreateSystemDefaultDevice();NSError*error=nil;
 id<MTLLibrary>lib=[d newLibraryWithSource:@"#include <metal_stdlib>\nusing namespace metal; kernel void lifecycle_check(device uint* a [[buffer(0)]],uint i [[thread_position_in_grid]]) {a[i]=i+7;}" options:nil error:&error];
 if(!lib){fprintf(stderr,"%s\n",error.description.UTF8String);return 1;}
 id<MTLFunction>fn=[lib newFunctionWithName:@"lifecycle_check"];id<MTLComputePipelineState>p=[d newComputePipelineStateWithFunction:fn error:&error];if(!p)return 2;
 id<MTLBuffer>b=[d newBufferWithLength:4096 options:MTLResourceStorageModeShared];id<MTLCommandQueue>q=[d newCommandQueue];
 for(int j=0;j<3;++j){
  MTLCommandBufferDescriptor*desc=[MTLCommandBufferDescriptor new];
  id<MTLCommandBuffer>cb=j==0?[q commandBuffer]:j==1?[q commandBufferWithUnretainedReferences]:[q commandBufferWithDescriptor:desc];[desc release];
  id<MTLComputeCommandEncoder>e=[cb computeCommandEncoder];[e setComputePipelineState:p];[e setBuffer:b offset:0 atIndex:0];[e dispatchThreads:MTLSizeMake(1024,1,1) threadsPerThreadgroup:MTLSizeMake(128,1,1)];[e endEncoding];
  [cb addCompletedHandler:^(id<MTLCommandBuffer>done){callbacks.fetch_add(1);}];
  [cb addCompletedHandler:^(id<MTLCommandBuffer>done){callbacks.fetch_add(1);}];
  [cb commit];[cb waitUntilCompleted];if(cb.status!=MTLCommandBufferStatusCompleted)return 3;
  for(unsigned i=0;i<1024;++i)if(((unsigned*)b.contents)[i]!=i+7)return 4;
 }
 if(callbacks.load()!=6)return 5;
 puts("LIFECYCLE_BYTES_AND_CALLBACKS_PASS");return 0;
}}
