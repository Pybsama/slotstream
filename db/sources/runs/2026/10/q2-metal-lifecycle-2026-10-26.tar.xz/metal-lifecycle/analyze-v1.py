from pathlib import Path
import csv,json,collections,statistics
P=Path(__file__).resolve().parent;F=P.parent/'q2-full-cycle-20261025'
def read(path):
 lines=path.read_text().splitlines();foot=dict(x.split('=',1)for x in lines[-1][2:].split());assert int(foot['total'])<int(foot['cap']),(path,foot)
 return list(csv.DictReader(x for x in lines if not x.startswith('#'))),foot
def union(xs):
 out=[]
 for a,b in sorted(xs):
  if b<=a:continue
  if not out or a>out[-1][1]:out.append([a,b])
  else:out[-1][1]=max(out[-1][1],b)
 return out
def inter(a,b):
 out=[];i=j=0
 while i<len(a)and j<len(b):
  lo,hi=max(a[i][0],b[j][0]),min(a[i][1],b[j][1])
  if hi>lo:out.append([lo,hi])
  if a[i][1]<b[j][1]:i+=1
  else:j+=1
 return out
def length(xs):return sum(b-a for a,b in xs)
reports=[]
for e in json.loads((P/'trace-ledger.json').read_text()):
 label=e['label'];d=json.loads((P/(label+'.json')).read_text());steps=d['rounds'][0]['steps'];native=e['arm']=='N'
 ref=json.loads((F/('validation-0-N.json'if native else'validation-s-0-S.json')).read_text())['rounds'][0]['steps']
 assert len(steps)==len(ref)==111
 for row,expected in zip(steps,ref):
  assert row['actual_selected']==expected['actual_selected'] and row['actual_guesses']==expected['actual_guesses'],(label,row['step'])
 hosts,hfoot=read(next(P.glob(label+'-commands.*.host.csv')))
 stages,sfoot=read(next(P.glob(label+'-commands.*.stages.csv')))
 assert sfoot['cpu_initial']==sfoot['gpu_initial']and sfoot['cpu_final']==sfoot['gpu_final']
 reads,_=read(next(P.glob(label+'-reads.*.csv')))
 gpu=union((int(s['gpu_start'])/1e9,int(s['gpu_end'])/1e9)for s in stages if int(s['gpu_end'])>int(s['gpu_start'])>0)
 rd=union((float(r['start']),float(r['end']))for r in reads if int(r['result'])>0)
 busy=union(gpu+rd)
 for h in hosts:h.update(start=float(h['start']),end=float(h['end']))
 assert bool(hosts)==e['host_calls']
 selected=[]
 def metrics(hh,window):
  chosen=[h for h in hh if any(a<=h['start']<b for a,b in window)]
  u=inter(union((h['start'],h['end'])for h in chosen),window)
  return dict(count=len(chosen),summed_service_seconds=sum(h['end']-h['start']for h in chosen),union_seconds=length(u),overlap_gpu_seconds=length(inter(u,gpu)),overlap_reads_seconds=length(inter(u,rd)),outside_gpu_and_reads_seconds=length(u)-length(inter(u,busy)),largest_calls=[dict(kind=h['kind'],start=h['start'],seconds=h['end']-h['start'],object=h['object'],thread=h['thread'])for h in sorted(chosen,key=lambda h:h['end']-h['start'],reverse=True)[:8]])
 for row in steps:
  lo,hi=(row['start_ns']/1e9,row['end_ns']/1e9)if native else(row['start'],row['end'])
  selected.append([lo,hi])
 windows={name:[v for i,v in enumerate(selected)if i>=start]for name,start in [('all111',0),('after20',20)]}
 groups={}
 for name,window in windows.items():
  groups[name]=dict(seconds=length(window),all_calls=metrics(hosts,window),by_kind={kind:metrics([h for h in hosts if h['kind']==kind],window)for kind in ['H','Q','E','X','C']},gpu_union_seconds=length(inter(gpu,window)),read_union_seconds=length(inter(rd,window)),missing_gpu_intervals=sum(any(a<=float(s['encoded'])<b for a,b in window)and not(int(s['gpu_end'])>int(s['gpu_start'])>0)for s in stages))
 phases={}
 if native:
  for name in ['draft_seconds','verify_seconds','sample_seconds','commit_seconds']:
   window=[]
   for r in steps:
    lo=r['start_ns']/1e9
    for part in ['draft_seconds','verify_seconds','sample_seconds','commit_seconds']:
     hi=lo+r[part]
     if part==name:window.append([lo,hi]);break
     lo=hi
   phases[name]=metrics(hosts,window)
 reports.append(dict(label=label,arm=e['arm'],host_calls=e['host_calls'],environment_eligible=e['eligible'],exact_proposals_and_selected=True,round_seconds=d['rounds'][0]['seconds'],groups=groups,native_phases=phases,process_host_counts=dict(collections.Counter(h['kind']for h in hosts))))
sensitivities={}
for arm in ['N','S']:
 pair=[r for r in reports if r['arm']==arm]
 if len(pair)==2:
  on=next(r for r in pair if r['host_calls']);off=next(r for r in pair if not r['host_calls'])
  sensitivities[arm]=dict(on_seconds=on['round_seconds'],off_seconds=off['round_seconds'],ratio=on['round_seconds']/off['round_seconds'],within_two_percent=abs(on['round_seconds']/off['round_seconds']-1)<=.02,scope='One control pair per engine, opposite order. This includes natural variation and is not a pure estimate of tracing overhead or a speed result.')
out=dict(scope='Original Metal method service during fixed real cycles. Union and read/GPU overlap prevent adding concurrent times. Callback capture-set construction, destruction after completion, and unhooked encoding work remain outside this observation. Instrumented durations do not qualify product speed.',complete=len(reports)==4,arms=reports,control_sensitivity=sensitivities)
(P/'analysis.json').write_text(json.dumps(out,indent=2))
for r in reports:
 print(r['label'],r['environment_eligible'],r['round_seconds'],[(k,v['count'],round(v['summed_service_seconds'],6),round(v['outside_gpu_and_reads_seconds'],6))for k,v in r['groups']['all111']['by_kind'].items()],flush=True)
print(sensitivities)
