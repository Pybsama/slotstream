from pathlib import Path
import json,shutil,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1];B=P.parent/'q2-sequence-20261025';F=P.parent/'q2-full-cycle-20261025'
s=(B/'named_stage_observer.mm').read_text()
s=s.replace('#include <unistd.h>','#include <unistd.h>\n#include <pthread.h>')
needle='constexpr size_t pipelineLimit=16384, assignmentLimit=2097152;'
addition='''// Observe original Metal method service only. Observer bookkeeping and
// the observer's own completion handler are excluded from these intervals.
constexpr size_t hostLimit=1048576;
struct HostRecord { double start=0,end=0; uintptr_t object=0; uint64_t thread=0; char kind=0; };
HostRecord hosts[hostLimit]; std::atomic<size_t> hostNext{0};
thread_local unsigned observerHandler=0, commandCreateDepth=0;
bool hostEnabled() { static const bool enabled=[] { const char* v=getenv("SLOTSTREAM_HOST_CALLS");return v && strcmp(v,"1")==0; }();return enabled; }
struct HostTimer {
  char kind;uintptr_t object;double start=0;bool active;
  HostTimer(char k,id obj):kind(k),object((uintptr_t)obj),active(hostEnabled() && observerHandler==0) {if(active)start=now();}
  ~HostTimer(){if(!active)return;const double end=now();const size_t i=hostNext.fetch_add(1);
    if(i<hostLimit){static thread_local uint64_t thread=[] {uint64_t t=0;pthread_threadid_np(nullptr,&t);return t;}();hosts[i]={start,end,object,thread,kind};}}
};
void dumpHosts(const char* prefix) {
 char path[4096];snprintf(path,sizeof(path),"%s.%d.host.csv",prefix,getpid());FILE*f=fopen(path,"wx");if(!f)return;
 fprintf(f,"kind,start,end,object,thread\\n");const size_t n=hostNext.load();
 for(size_t i=0;i<std::min(n,hostLimit);++i){const auto&r=hosts[i];fprintf(f,"%c,%.9f,%.9f,%llu,%llu\\n",r.kind,r.start,r.end,(unsigned long long)r.object,(unsigned long long)r.thread);}
 fprintf(f,"# total=%zu cap=%zu\\n",n,hostLimit);fclose(f);
}

'''
assert s.count(needle)==1;s=s.replace(needle,addition+needle)
needle='  });class_replaceMethod(cls,sel,wrapped,method_getTypeEncoding(method));\n}\nvoid dumpPipelines'
new='''  });class_replaceMethod(cls,sel,wrapped,method_getTypeEncoding(method));
  SEL endSel=@selector(endEncoding);Method endMethod=class_getInstanceMethod(cls,endSel);
  if(endMethod){const IMP originalEnd=method_getImplementation(endMethod);
    IMP wrappedEnd=imp_implementationWithBlock(^(id encoder){HostTimer timer('X',encoder);reinterpret_cast<void(*)(id,SEL)>(originalEnd)(encoder,endSel);});
    class_replaceMethod(cls,endSel,wrappedEnd,method_getTypeEncoding(endMethod));}
}
void dumpPipelines'''
assert s.count(needle)==1;s=s.replace(needle,new)
needle='  const size_t i=nextStage.fetch_add(1);\n'
s=s.replace(needle,'''  auto invoke=[&](MTLComputePassDescriptor* desc){HostTimer timer('E',buffer);return reinterpret_cast<id(*)(id,SEL,id)>(original)(buffer,selector,desc);};
'''+needle)
s=s.replace('return reinterpret_cast<id(*)(id,SEL,id)>(original)(buffer,selector,input);','return invoke(input);')
s=s.replace('id encoder=reinterpret_cast<id(*)(id,SEL,id)>(original)(buffer,selector,desc);','id encoder=invoke(desc);')
s=s.replace('  dumpStages(path);','  dumpHosts(path);\n  dumpStages(path);')
needle='  if(!commands.insert(cls).second) return;\n'
addition='''  {
    SEL handlerSel=@selector(addCompletedHandler:);Method handlerMethod=class_getInstanceMethod(cls,handlerSel);
    if(handlerMethod){const IMP originalHandler=method_getImplementation(handlerMethod);
      IMP wrappedHandler=imp_implementationWithBlock(^(id buffer,MTLCommandBufferHandler handler){
        HostTimer timer('H',buffer);reinterpret_cast<void(*)(id,SEL,MTLCommandBufferHandler)>(originalHandler)(buffer,handlerSel,handler);
      });class_replaceMethod(cls,handlerSel,wrappedHandler,method_getTypeEncoding(handlerMethod));}
  }
'''
assert s.count(needle)==1;s=s.replace(needle,needle+addition)
s=s.replace('      [buffer addCompletedHandler:', '      ++observerHandler;\n      [buffer addCompletedHandler:')
s=s.replace('records[i].status=unsigned(done.status);\n      }];','records[i].status=unsigned(done.status);\n      }];\n      --observerHandler;')
needle='    reinterpret_cast<void(*)(id,SEL)>(original)(buffer,sel);'
assert s.count(needle)==1;s=s.replace(needle,"    HostTimer timer('C',buffer);\n"+needle)
for tail,args in [('','q,sel'),(',id','q,sel,descriptor')]:
 old=f'id result=reinterpret_cast<id(*)(id,SEL{tail})>(original)({args}); command(result); return result;'
 new=f'''const bool outer=commandCreateDepth++==0;id result;
      {{HostTimer timer('Q',q);timer.active=timer.active && outer;result=reinterpret_cast<id(*)(id,SEL{tail})>(original)({args});timer.object=(uintptr_t)result;}}
      --commandCreateDepth;if(outer)command(result);return result;'''
 assert s.count(old)==1;s=s.replace(old,new)
(P/'lifecycle_observer.mm').write_text(s)
for n in ['quiet_guarded_run.py','timed-2.json','validation-result.json']:shutil.copy2(F/n,P/n)
s=(F/'trace.py').read_text()
s=s.replace("enumerate('NS')","enumerate('NnSs')")
s=s.replace("label=f'{a.mode}-{i}-{arm}';out=P/(label+'.json');assert not out.exists()", "host=arm in ('n','S');arm=arm.upper();label=f'{a.mode}-{i}-{arm}';out=P/(label+'.json');assert not out.exists()")
s=s.replace("str(R/'.build/q2-sequence-20261025/named_stage_observer.dylib')","str(P/'lifecycle_observer.dylib')")
s=s.replace("env=['--env','SLOTSTREAM_MODEL_LOCK_PATH='+str(inner),", "env=['--env','SLOTSTREAM_HOST_CALLS='+('1' if host else '0'),'--env','SLOTSTREAM_MODEL_LOCK_PATH='+str(inner),")
s=s.replace("str(P/'native-build/candidate/slotstream')","str(P.parent/'q2-full-cycle-20261025/native-build/candidate/slotstream')")
s=s.replace("str(P/'upstream/full-cycle')","str(P.parent/'q2-full-cycle-20261025/upstream/full-cycle')").replace("str(P/'upstream/splash.metallib')","str(P.parent/'q2-full-cycle-20261025/upstream/splash.metallib')")
s=s.replace('event=dict(label=label,arm=arm,', 'event=dict(label=label,arm=arm,host_calls=host,')
(P/'run.py').write_text(s)
(P/'plan.json').write_text(json.dumps(dict(scope='Diagnose original Metal call service during the same111 real draft/verify/commit cycles. No production, Fast, arithmetic, controller, priority, reader or GPU-work change.',arms=['native host-counter off','native host-counter on','Splash host-counter on','Splash host-counter off'],conditions=dict(memory_gb=15,slots=4067,native_context=8192,Splash_context='Existing bounded fixture arena, diagnostic only',precision='BF16 activations/KV; FP32 recurrence',preflight_gb=18,physical_ceiling_gb=15,read_copy_gpu_hooks='Same observer chain in every arm; lifecycle counters toggled only'),measured=dict(H='Original addCompletedHandler service, excluding this observer own handler',Q='Outermost original command buffer creation, excluding hook installation',E='Original encoder creation with same stage-timestamp descriptor',X='Original endEncoding service',C='Original commit service'),limits='Does not measure constructing C++ captured buffer sets before registration, callback destruction after completion, or every command encoding method. Counts/service sums are not removable wall time. Align with union of all reads and measured GPU intervals. Missing samples/cap overflows invalidate attribution. These runs do not qualify product speed.',gates=dict(observer='Weights-free actual Metal output plus exact app handler/command/stage counts; own handlers excluded; counter-off remains zero.',correctness='All111real proposals and selected tokens equal each engine prior validation. Full logits were separately validated for these unchanged binaries.',advance='Investigate a mechanism only if a meaningful exposed contribution is observed, nominally at least0.1seconds over111cycles; quantify instrumentation sensitivity with the counter-off arms. No substantial optimization from total call counts or summed times.',exclusions='No timing result from paging, competing build or thermal failures. Preserve every arm; no retries.'),observer_source_sha256=hashlib.sha256((P/'lifecycle_observer.mm').read_bytes()).hexdigest()),indent=2))
print('prepared lifecycle observer and fixed-work four-arm protocol')
