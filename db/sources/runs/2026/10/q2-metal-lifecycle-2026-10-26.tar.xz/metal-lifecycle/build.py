from pathlib import Path
import csv,collections,fcntl,hashlib,json,os,subprocess,sys
P=Path(__file__).resolve().parent;R=P.parents[1]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
lock=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(P/'build-child.lock');before=preflight(4)
assert not(P/'observer-build.json').exists()
flags=['xcrun','clang++','-std=c++17','-O2','-framework','Foundation','-framework','Metal']
cmds=[flags+['-dynamiclib',str(P/'lifecycle_observer.mm'),'-o',str(P/'lifecycle_observer.dylib')],flags+[str(P/'lifecycle_check.mm'),'-o',str(P/'lifecycle-check')]]
for i,cmd in enumerate(cmds):
 r=subprocess.run(cmd,capture_output=True,text=True,timeout=120);(P/f'observer-build-{i}.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stderr
checks=[]
for mode in [False,True]:
 label='observer-check-'+('on'if mode else'off')
 env={k:v for k,v in os.environ.items()if not k.startswith(('SLOTSTREAM_','MLX_','DYLD_'))};env.update(DYLD_INSERT_LIBRARIES=str(P/'lifecycle_observer.dylib'),SLOTSTREAM_METAL_OBSERVER=str(P/label),SLOTSTREAM_HOST_CALLS='1'if mode else'0')
 r=subprocess.run([str(P/'lifecycle-check')],env=env,capture_output=True,text=True,timeout=30);(P/(label+'.log')).write_text(r.stdout+r.stderr);assert r.returncode==0 and 'LIFECYCLE_BYTES_AND_CALLBACKS_PASS'in r.stdout
 rows={}
 for kind in ['pipelines','assignments','stages','host']:
  path=next(P.glob(label+'.*.'+kind+'.csv'));lines=path.read_text().splitlines();foot=dict(x.split('=')for x in lines[-1][2:].split());assert int(foot['total'])<int(foot['cap']);rows[kind]=list(csv.DictReader(x for x in lines if not x.startswith('#')))
 assert len(rows['pipelines'])==1 and rows['pipelines'][0]['name']=='lifecycle_check'
 assert len(rows['assignments'])==len(rows['stages'])==3
 assert all(int(r['gpu_end'])>int(r['gpu_start'])>0 for r in rows['stages'])
 counts=collections.Counter(r['kind']for r in rows['host'])
 assert counts==({'Q':3,'E':3,'X':3,'H':6,'C':3}if mode else{}),counts
 checks.append(dict(mode=mode,counts=counts,passed=True))
receipt=dict(before=before,commands=cmds,passed=True,checks=checks,scope='Three real Metal output checks and six caller callbacks. All creation APIs, exact lifecycle counts and own-handler exclusion pass. Counter-off records no host calls. No model loaded.',files={n:hashlib.sha256((P/n).read_bytes()).hexdigest()for n in ['lifecycle_observer.mm','lifecycle_check.mm','lifecycle_observer.dylib','lifecycle-check']})
(P/'observer-build.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt['checks']))
