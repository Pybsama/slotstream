from pathlib import Path
import hashlib,io,importlib.util,json,re,tarfile
P=Path(__file__).resolve().parent;R=P.parents[1];OLD=R/'.build/native-replay-20261023/v68'
result=json.loads((P/'copy-causal-frozen-12-summary.json').read_text());assert not result['copy_benefit_gate']
spec=importlib.util.spec_from_file_location('identity',R/'Tools/build_identity.py');identity=importlib.util.module_from_spec(spec);spec.loader.exec_module(identity)
source=json.loads((OLD/'build-identity.json').read_text())['source'];assert source=={str(f.relative_to(R)):identity.sha(f)for f in identity.source_files(R)}
artifacts={n:identity.sha(R/'.build/release'/n)==identity.sha(OLD/n)for n in ['slotstream','slotstream-checks','mlx.metallib','build-identity.json','build-source.tar.gz']};assert all(artifacts.values())
(P/'copy-causal-frozen-12-final-state.json').write_text(json.dumps(dict(runtime_inputs_equal_v68=len(source),default_artifacts=artifacts,retained_runtime_changes=False,fast_changed=False,complete_request_control_run=False,reason='12GBheld-workABBA fails whole-protocol paging and raw prose direction consistency. All16outputs and core work match reference; no adaptive follow-up, retry or default change.'),indent=2))
files={f.name:f for f in P.glob('copy-causal-frozen-12-*')if f.is_file()and f.suffix in ['.json','.log','.patch']and'archive-receipt'not in f.name}
for name in ['copy-causal-12-plan.json','copy-causal-12-choices.json','complete_copy_causal_frozen.py','complete_copy_causal_adaptive.py','analyze_copy_causal_frozen.py','analyze_copy_causal_adaptive.py','archive_copy_causal_12.py','quiet_guarded_run.py']:
 files[name]=P/name
for n,f in [('candidate-build-identity.json',P/'native-cost-trace-build/candidate/build-identity.json'),('recorded-request.json',P/'cost-trace-adaptive-12-0-A.json'),('cost-demand-archive.json',P/'cost-demand-archive-receipt.json')]:files['reference/'+n]=f
secret=re.compile(rb'(?:ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{25,}|sk-(?:proj-)?[A-Za-z0-9_-]{30,}|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----)')
for f in files.values():assert f.exists()and not secret.search(f.read_bytes()),f
manifest={n:dict(bytes=f.stat().st_size,sha256=identity.sha(f))for n,f in files.items()};raw=json.dumps(manifest,indent=2).encode()+b'\n'
dest=R/'db/sources/runs/2026/10/q2-matched-work-12gb-2026-10-25.tar.gz';assert not dest.exists()
with tarfile.open(dest,'w:gz')as t:
 for n,f in sorted(files.items()):t.add(f,arcname=n,recursive=False)
 info=tarfile.TarInfo('archive-manifest.json');info.size=len(raw);t.addfile(info,io.BytesIO(raw))
with tarfile.open(dest)as t:
 for n,m in manifest.items():
  raw=t.extractfile(n).read();assert len(raw)==m['bytes']and hashlib.sha256(raw).hexdigest()==m['sha256']
receipt=dict(path=str(dest.relative_to(R)),files=len(manifest),bytes=dest.stat().st_size,sha256=identity.sha(dest),readback_verified=True,credential_pattern_matches=0)
(P/'copy-causal-frozen-12-archive-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
