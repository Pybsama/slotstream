from pathlib import Path
import hashlib,json
P=Path(__file__).resolve().parent;F=P.parent/'q2-full-cycle-20261025'
paths=[F/'validation-0-N.json',F/'validation-s-0-S.json'];N,S=[json.loads(p.read_text())['rounds'][0]['steps']for p in paths]
results={}
for key in ['actual_guesses','actual_selected']:
 pairs=[(n['step'],i,a,b)for n,s in zip(N,S)for i,(a,b)in enumerate(zip(n[key],s[key]))]
 different=[dict(step=t,position=i,native=a,splash=b)for t,i,a,b in pairs if a!=b]
 results[key]=dict(total=len(pairs),different=len(different),examples=different)
results['inputs']={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in paths}
results['limit']='Same111teacher-forcedtargetcycles and own-referenceexactness; cross-engine greedy IDs differ. Does not establish semantic quality loss or explain traffic without actual route measurements.'
(P/'token-comparison.json').write_text(json.dumps(results,indent=2));print({k:{x:v[x]for x in ['total','different']}for k,v in results.items()if k.startswith('actual')})
