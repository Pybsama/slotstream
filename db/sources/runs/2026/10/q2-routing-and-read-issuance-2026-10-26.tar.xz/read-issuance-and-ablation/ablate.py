from pathlib import Path
import argparse,fcntl,json,os,shutil,subprocess,sys
P=Path(__file__).resolve().parent;R=P.parents[1];E=P.parent/'q2-early-expert-20261026';F=P.parent/'q2-full-cycle-20261025'
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight,terminate_child_tree
sys.path.insert(0,str(R/'.build/native-q2-20261021'));from thermal import wait_nominal
ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['validation','timing']);a=ap.parse_args();validation=a.mode=='validation'
shutil.copy2(E/'quiet_guarded_run.py',P/'quiet_guarded_run.py')
reservation=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(reservation,fcntl.LOCK_EX|fcntl.LOCK_NB)
inner=P/(a.mode+'-child.lock');os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(inner)
ledger=P/(a.mode+'-ledger.json');assert not ledger.exists();events=[]
if not validation:assert json.loads((P/'validation-result.json').read_text())['passed']
ref=json.loads((F/'validation-0-N.json').read_text())['rounds'][0]['steps']
for i,arm in enumerate('B'if validation else 'ABBA'):
    label=f'{a.mode}-{i}-{arm}';out=P/(label+'.json');assert not out.exists()
    wait_nominal(P/(label+'-cooldown.json'));preflight(18)
    binary=E/'native-build-v2/candidate/slotstream'if arm=='B'else F/'native-build/candidate/slotstream'
    env=['--env','SLOTSTREAM_MODEL_LOCK_PATH='+str(inner),'--env','SLOTSTREAM_Q2_EARLY_EXPERT=0']
    if validation:env+=['--env','MTL_DEBUG_LAYER=1']
    cmd=[str(binary),'q2-profile','--fixture',str(E/'timed-2.json'),'--output',str(out),'--memory-gb','15','--rounds','1'if validation else'3']
    if validation:cmd+=['--validate']
    full=[sys.executable,str(P/'quiet_guarded_run.py'),'--label',label,'--budget','15','--timeout','600',*env,'--',*cmd]
    print('START',label,flush=True)
    with(P/(label+'-launcher.log')).open('x')as log:
        child=subprocess.Popen(full,cwd=R,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        try:rc=child.wait(timeout=660)
        finally:
            if child.poll()is None:terminate_child_tree(child)
    g=json.loads((P/(label+'.observer.json')).read_text())
    e=dict(label=label,arm=arm,exit_code=rc,command=full,eligible=rc==0 and g['complete']and not g['paging']and not g['external_build_samples']and g['thermal_before']==g['thermal_after']==0 and g['peak_combined_bytes']<=15e9)
    events.append(e);ledger.write_text(json.dumps(events,indent=2))
    if rc:raise SystemExit(rc)
    d=json.loads(out.read_text());assert d['complete']and d['plan']['pool_slots']==4067
    if arm=='B':assert d['deferred_stats']==[0,0,0,0],d['deferred_stats']
    for rd in d['rounds']:
        assert len(rd['steps'])==111
        for s,r in zip(rd['steps'],ref):
            for k in ['step','width','kept','actual_guesses','actual_selected']+(['logits_sha256']if validation else[]):assert s[k]==r[k],(label,rd['round'],s['step'],k)
    e['rounds']=[dict(round=rd['round'],cycle_seconds=sum(s['seconds']for s in rd['steps']),phases={p:sum(s[p]for s in rd['steps'])for p in ['draft_seconds','verify_seconds','sample_seconds','commit_seconds']},fetched=sum(s['records_fetched']for s in rd['steps']),adopted=sum(s['records_adopted']for s in rd['steps']))for rd in d['rounds']]
    ledger.write_text(json.dumps(events,indent=2));print('END',label,e['eligible'],e['rounds'],flush=True)
if validation:(P/'validation-result.json').write_text(json.dumps(dict(passed=True,scope='Early-scheduling-disabled candidate exactly matches111frozenfull-logithashes,proposals,selectedIDs; zero early prepared/refused/bound and zero live staging at round end, Metalvalidation,15GB4067slots8192context.')))
print('PROTOCOL FINISHED',flush=True)
