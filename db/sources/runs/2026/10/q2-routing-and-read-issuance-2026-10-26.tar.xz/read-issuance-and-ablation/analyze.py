from pathlib import Path
import collections,csv,hashlib,json,statistics
P=Path(__file__).resolve().parent;R=P.parents[1];D=P.parent/'q2-required-dependencies-20261026'
def union(xs):
    out=[]
    for a,b in sorted(xs):
        if b<=a:continue
        if out and a<=out[-1][1]:out[-1]=(out[-1][0],max(b,out[-1][1]))
        else:out.append((a,b))
    return out
def intersect(a,b):
    i=j=0;out=[]
    while i<len(a)and j<len(b):
        lo=max(a[i][0],b[j][0]);hi=min(a[i][1],b[j][1])
        if hi>lo:out.append((lo,hi))
        if a[i][1]<b[j][1]:i+=1
        else:j+=1
    return out
def length(xs):return sum(b-a for a,b in xs)
out=[];inputs={}
for label in ['trace-1-N','trace-2-S']:
    path=D/(label+'-dependency-analysis.json');rawpath=D/(label+'.json');stagepath=next(D.glob(label+'-commands.*.stages.csv'))
    for f in [path,rawpath,stagepath]:inputs[str(f.relative_to(R))]=hashlib.sha256(f.read_bytes()).hexdigest()
    d=json.loads(path.read_text());raw=json.loads(rawpath.read_text());assert d['missing_or_ambiguous_dependencies']==[]
    rows=list(csv.DictReader(l for l in stagepath.read_text().splitlines()if not l.startswith('#')))
    gpu=union([(int(r['gpu_start'])/1e9,int(r['gpu_end'])/1e9)for r in rows if int(r['gpu_end'])>int(r['gpu_start'])>0])
    for rd in [1,2]:
        steps=raw['rounds'][rd]['steps'];windows=union([(s['start_ns']/1e9,s['end_ns']/1e9)if label.endswith('N')else(s['start'],s['end'])for s in steps])
        jobs=[j for j in d['jobs']if j['round']==rd and j['payloads']]
        fresh=[j for j in jobs if j['first_new_required_read']is not None]
        spans=intersect(union([(j['begin'],j['first_new_required_read'])for j in fresh]),windows)
        seconds=length(spans);exposed=seconds-length(intersect(spans,gpu))
        latencies=sorted(j['first_new_required_read']-j['begin']for j in fresh)
        out.append(dict(label=label,round=rd,payload_jobs=len(jobs),jobs_with_required_read_started_after_begin=len(fresh),job_begin_to_first_new_required_read_sum_seconds=sum(latencies),clipped_union_seconds=seconds,outside_recorded_gpu_seconds=exposed,median_us=statistics.median(latencies)*1e6,p95_us=latencies[int(len(latencies)*.95)]*1e6,fully_read_before_begin=sum(j['fully_read_before_begin']for j in jobs)))
result=dict(source_inputs=inputs,rows=out,scope='Offline extension of already archived exact required-payload ancestry. First new required read includes useful forecast reads as well as demand reads. Job begin is native C job creation versus Splash load entry, not identical router-ready boundaries. Coverage is not a causal savings budget. No new model run or candidate.')
(P/'analysis.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
