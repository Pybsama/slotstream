from pathlib import Path
import collections,hashlib,json,statistics
P=Path(__file__).resolve().parent;E=P.parent/'q2-early-expert-20261026'
events=json.loads((E/'timing-fixed-ledger.json').read_text());assert len(events)==4 and all(e['eligible']for e in events)
phases=['draft_seconds','verify_seconds','sample_seconds','commit_seconds']
arms=[];inputs={}
for event in events:
    path=E/(event['label']+'.json');inputs[path.name]=hashlib.sha256(path.read_bytes()).hexdigest();d=json.loads(path.read_text())
    rounds=[]
    for rd in d['rounds'][1:]:
        totals={p:sum(s[p]for s in rd['steps'])for p in phases}
        width={str(w):dict(steps=sum(s['width']==w for s in rd['steps']),seconds=sum(s['seconds']for s in rd['steps']if s['width']==w),phases={p:sum(s[p]for s in rd['steps']if s['width']==w)for p in phases},fetched=sum(s['records_fetched']for s in rd['steps']if s['width']==w),adopted=sum(s['records_adopted']for s in rd['steps']if s['width']==w))for w in range(1,9)}
        rounds.append(dict(round=rd['round'],phases=totals,width=width))
    arms.append(dict(label=event['label'],arm=event['arm'],rounds=rounds))
means=[{p:statistics.mean(r['phases'][p]for r in a['rounds'])for p in phases}for a in arms]
summary={p:dict(seconds=[m[p]for m in means],candidate_over_baseline_directions=[means[1][p]/means[0][p],means[2][p]/means[3][p]],pooled_difference_seconds=statistics.mean([means[1][p],means[2][p]])-statistics.mean([means[0][p],means[3][p]]))for p in phases}
width=[]
for w in range(1,9):
    vals=[statistics.mean(r['width'][str(w)]['phases']['verify_seconds']for r in a['rounds'])for a in arms]
    width.append(dict(width=w,steps=arms[0]['rounds'][0]['width'][str(w)]['steps'],verify_seconds=vals,candidate_over_baseline_directions=[vals[1]/vals[0],vals[2]/vals[3]],pooled_difference_seconds=statistics.mean(vals[1:3])-statistics.mean([vals[0],vals[3]])))
result=dict(source_inputs=inputs,phases=summary,width=width,arms=arms,scope='Offline phase localization of the original clean ABBA rejection. Same frozen steps, widths and retention. Source-read/adoption timing can differ; unmodified phases are context, not a causal normalization. No selected arm or new model retry.')
(P/'candidate-phase-analysis.json').write_text(json.dumps(result,indent=2));print(json.dumps(dict(phases=summary,width=width),indent=2))
