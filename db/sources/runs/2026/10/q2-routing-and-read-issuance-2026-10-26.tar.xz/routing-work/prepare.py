from pathlib import Path
import hashlib,json,shutil
P=Path(__file__).resolve().parent;R=P.parents[1];F=P.parent/'q2-full-cycle-20261025';D=P.parent/'q2-required-dependencies-20261026'
def replace(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b)
trace='''
// Temporary bounded work diagnostic. Existing CPU-visible routes only; no GPU readbacks.
package enum Q2RouteWorkTrace {
    private static let lock = NSLock()
    private static var round = -1
    private static var step = -1
    private static var width = 0
    private static var events: [[String: Any]] = []
    package static func mark(round: Int, step: Int, width: Int) {
        lock.lock(); defer { lock.unlock() }
        self.round = round; self.step = step; self.width = width
    }
    package static func routes(layer: Int, ids: [Int32], topK: Int, resident: (ExpertKey) -> Bool) {
        lock.lock(); defer { lock.unlock() }
        guard step >= 0 else { return }
        precondition(events.count < 16000 && ids.count <= 80)
        var counts: [Int32: Int] = [:]
        for id in ids { counts[id, default: 0] += 1 }
        let entries = counts.keys.sorted().map { [Int($0), counts[$0]!, resident(ExpertKey(layer, Int($0))) ? 1 : 0] }
        events.append(["round": round, "step": step, "kind": 0, "layer": layer, "rows": ids.count/topK, "entries": entries, "ranked_ids": ids.map(Int.init)])
    }
    package static func forecast(target: Int, ids: [Int32], resident: (ExpertKey) -> Bool) {
        lock.lock(); defer { lock.unlock() }
        guard step >= 0 else { return }
        precondition(events.count < 16000 && ids.count <= 80)
        events.append(["round": round, "step": step, "kind": 1, "layer": target, "rows": width,
            "entries": ids.map { [Int($0), 0, resident(ExpertKey(target, Int($0))) ? 1 : 0] }])
    }
    package static func write(to path: String) throws {
        lock.lock(); defer { lock.unlock() }
        try JSONSerialization.data(withJSONObject: ["events": events, "scope": "Bounded existing CPU-visible routes; no speed evidence"], options: [.sortedKeys]).write(to: URL(fileURLWithPath: path), options: .atomic)
    }
}
'''
rep={}
def out(path,s):
 name=Path(path).name; (P/name).write_text(s); rep[path]=name
s=(R/'Sources/Slotstream/NativeInputReadAhead.swift').read_text();out('Sources/Slotstream/NativeInputReadAhead.swift',s+trace)
s=(R/'Sources/Slotstream/Layers.swift').read_text();s=replace(s,'        routerObserver?(layer, expertIds)','        Q2RouteWorkTrace.routes(layer: layer, ids: expertIds, topK: cfg.topK, resident: pool.isResident)\n        routerObserver?(layer, expertIds)');out('Sources/Slotstream/Layers.swift',s)
s=(R/'Sources/Slotstream/ExpertPrefetch.swift').read_text();s=replace(s,'    package func forecast(target: Int, ids: [Int32], margins: [Float]) {','    package func forecast(target: Int, ids: [Int32], margins: [Float]) {\n        Q2RouteWorkTrace.forecast(target: target, ids: ids, resident: isResident)');out('Sources/Slotstream/ExpertPrefetch.swift',s)
s=(F/'Q2ProfileCommand.swift').read_text();s=replace(s,'                    model.lookahead?.requestFinished();model.lookahead=nil','                    Q2RouteWorkTrace.mark(round: round, step: -1, width: 0)\n                    model.lookahead?.requestFinished();model.lookahead=nil');s=replace(s,'                        guard state.tokenCount==step.position','                        Q2RouteWorkTrace.mark(round: round, step: index, width: step.tokens.count)\n                        guard state.tokenCount==step.position');s=replace(s,'                    print("round \\(round):','                    try Q2RouteWorkTrace.write(to: output + ".routes.json")\n                    print("round \\(round):');out('Sources/slotstream-cli/Q2ProfileCommand.swift',s)
(P/'replacements.json').write_text(json.dumps(rep,indent=2))
s=(P.parent/'q2-early-expert-20261026/build_native.py').read_text().replace("native-build-v2","native-build");(P/'build_native.py').write_text(s)
U=P/'upstream';U.mkdir(exist_ok=True);shutil.copytree(F/'upstream/include',U/'include',dirs_exist_ok=True)
for n in ['Runtime.cpp','Runtime.o','MetalBackend.mm','MetalBackend.o','splash.metallib']:
 shutil.copy2(F/'upstream'/n,U/n)
header='''#pragma once
#include <array>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <stdexcept>
#include <vector>
namespace routework {
struct Event {int round,step,kind;uint32_t layer,rows;std::vector<std::array<uint32_t,3>> entries;};
inline int round=-1,step=-1;
inline std::vector<Event> events;
inline void mark(int r,int s){round=r;step=s;}
inline void add(Event e){if(step<0)return;if(events.size()>=16000||e.entries.size()>80)throw std::runtime_error("route trace bound");events.push_back(std::move(e));}
inline void dump(){const char*path=std::getenv("Q2_ROUTE_OUTPUT");if(!path)throw std::runtime_error("missing route output");FILE*f=std::fopen(path,"wx");if(!f)throw std::runtime_error("route output exists");std::fputs("{\\"events\\":[",f);bool first=true;for(const auto&e:events){if(!first)std::fputc(',',f);first=false;std::fprintf(f,"{\\"round\\":%d,\\"step\\":%d,\\"kind\\":%d,\\"layer\\":%u,\\"rows\\":%u,\\"entries\\":[",e.round,e.step,e.kind,e.layer,e.rows);bool f2=true;for(const auto&a:e.entries){if(!f2)std::fputc(',',f);f2=false;std::fprintf(f,"[%u,%u,%u]",a[0],a[1],a[2]);}std::fputs("]}",f);}std::fputs("]}\\n",f);std::fclose(f);}
}
'''
(U/'RouteWork.hpp').write_text(header)
s=(D/'source-reference/runtime/model/ExpertStore.cpp').read_text();s='#include "RouteWork.hpp"\n'+s
s=replace(s,'      route(index, partTiles, phase, rows, use);','''      if (routework::step >= 0) {
        routework::Event e{routework::round,routework::step,0,index,rows,{}};
        for (const auto &part : partTiles) for (uint32_t i=0;i<part.size();++i) {
          const auto &d=part[i];
          if(d.expert<shape.experts)e.entries.push_back({d.expert,d.rows,blocks[index].slot[d.expert]!=kNoSlot?1u:0u});
        }
        routework::add(std::move(e));
      }
      route(index, partTiles, phase, rows, use);''')
s=replace(s,'      for (const uint32_t expert : predictedExperts(rows, verifyRows))','''      const auto predictedOrder = predictedExperts(rows, verifyRows);
      if (routework::step >= 0) {
        routework::Event e{routework::round,routework::step,1,index+1,rows,{}};
        for (const auto expert : predictedOrder)e.entries.push_back({expert,0,blocks[index+1].slot[expert]!=kNoSlot?1u:0u});
        routework::add(std::move(e));
      }
      for (const uint32_t expert : predictedOrder)''')
(U/'ExpertStore.cpp').write_text(s)
s=(F/'upstream/full_cycle.mm').read_text();s='#include "RouteWork.hpp"\n'+s;s=replace(s,'        prefill(executor,lanes[0],prompt);','        routework::mark(round,-1);\n        prefill(executor,lanes[0],prompt);');s=replace(s,'          const auto timing=model::RuntimeInstrumentation::fixedCycle','          routework::mark(round,step);\n          const auto timing=model::RuntimeInstrumentation::fixedCycle');s=replace(s,'      return 0;\n    } catch (const std::exception &error)', '      routework::dump();\n      return 0;\n    } catch (const std::exception &error)');(U/'full_cycle.mm').write_text(s)
plan=dict(scope='Diagnostic only: actual expert histograms, cache residency at route demand, and ordered forecasts for identical111frozenfullcycles. CPU-visible data only; no extra GPU readback, no public observer that disables native router retirement. Not timing evidence.',hypothesis='Small arithmetic differences can change route/cache/forecast work, which may confound the remaining gap. Measure material differences before another scheduling change.',protocol='One NS validation sequence at15GB4067slots, native8192context, Metalvalidation, both own frozen111logits/proposals/selected exact. One model/build at a time;18GB preflight; physical15GB ceiling. No speed gate or product parity claim.',sources={n:hashlib.sha256((R/n).read_bytes()).hexdigest()for n in rep},fixture_sha256=hashlib.sha256((F/'timed-2.json').read_bytes()).hexdigest())
(P/'plan.json').write_text(json.dumps(plan,indent=2));shutil.copy2(F/'timed-2.json',P/'timed-2.json');shutil.copy2(D/'quiet_guarded_run.py',P/'quiet_guarded_run.py')
print('Prepared bounded diagnostic source copies; live sources unchanged')
