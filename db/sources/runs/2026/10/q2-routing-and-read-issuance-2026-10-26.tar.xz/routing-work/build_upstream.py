from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess,sys
P=Path(__file__).resolve().parent;R=P.parents[1];U=P/'upstream';D=P.parent/'q2-required-dependencies-20261026';W=D/'source-reference';F=P.parent/'q2-full-cycle-20261025'
library=Path('/var/folders/d4/t1c8ltbx5s3_11cs9y6gjh8m0000gp/T/slotstream-splash-host-ugnf26pi/source/build/engine/libsplash.a')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=json.loads((F/'upstream/identity.json').read_text());assert sha(library)==identity[str(library)]
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()=='1482f6bbc2abf12375332725302019594150b6cb'
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
with open(f'/tmp/slotstream-model-{os.getuid()}.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);os.environ["SLOTSTREAM_MODEL_LOCK_PATH"]=str(P/"upstream-build-child.lock");preflight(10)
 common=['xcrun','-sdk','macosx','clang++','-std=c++20','-O2','-mmacosx-version-min=26.4','-I'+str(U/'include'),'-I'+str(U),'-I'+str(W/'runtime'),'-I'+str(W/'dev'),'-I'+str(W/'runtime/metal')]
 commands=[common+['-DSPLASH_RUNTIME_INSTRUMENTATION','-c',str(U/'Runtime.cpp'),'-o',str(U/'Runtime.o')],common+['-fobjc-arc','-DSPLASH_BACKEND_INSTRUMENTATION','-c',str(U/'MetalBackend.mm'),'-o',str(U/'MetalBackend.o')],[x for x in common if x!='-O2']+['-O3','-Wall','-Wextra','-Werror','-c',str(U/'ExpertStore.cpp'),'-o',str(U/'ExpertStore.o')],common+['-fobjc-arc',str(U/'full_cycle.mm'),str(U/'Runtime.o'),str(U/'MetalBackend.o'),str(U/'ExpertStore.o'),str(library),'-framework','Foundation','-framework','Metal','-framework','IOKit','-framework','IOSurface','-o',str(U/'full-cycle')]]
 ledger=[]
 for i,cmd in enumerate(commands):
  with(U/f'build-{i}.log').open('w')as log:r=subprocess.run(cmd,cwd=W,stdout=log,stderr=subprocess.STDOUT)
  ledger.append(dict(command=cmd,exit_code=r.returncode));(U/'build-ledger.json').write_text(json.dumps(ledger,indent=2))
  if r.returncode:raise SystemExit(r.returncode)
 paths=[U/n for n in ['Runtime.cpp','MetalBackend.mm','ExpertStore.cpp','RouteWork.hpp','full_cycle.mm','include/model/RuntimeInstrumentation.hpp','full-cycle','splash.metallib']]+[library]
 (U/'identity.json').write_text(json.dumps({str(p):sha(p)for p in paths},indent=2));print('Built routing-work diagnostic')
