from pathlib import Path
import fcntl,hashlib,io,json,os,re,sys,tarfile
P=Path(__file__).resolve().parent;R=P.parents[1];I=P.parent/'q2-read-issue-20261026'
assert json.loads((P/'validation-result.json').read_text())['passed']
assert (P/'analysis.json').exists() and (I/'ablation-analysis.json').exists()
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
reservation=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(reservation,fcntl.LOCK_EX|fcntl.LOCK_NB);os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(P/'archive-child.lock');preflight(4)
sha=lambda b:hashlib.sha256(b).hexdigest();files={};allowed={'.py','.swift','.h','.hpp','.cpp','.mm','.json','.jsonl','.csv','.log','.stderr','.txt'}
secret=re.compile(rb'(?:ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{25,}|sk-(?:proj-)?[A-Za-z0-9_-]{30,}|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----)')
for prefix,root in [('read-issuance-and-ablation',I),('routing-work',P)]:
 for f in root.rglob('*'):
  if not f.is_file()or '__pycache__'in f.parts or f.suffix not in allowed or f.name.startswith('archive-receipt')or(f.name.startswith('archive')and f.suffix=='.log'):continue
  files[prefix+'/'+str(f.relative_to(root))]=f
for label,path in [('v68',R/'.build/native-replay-20261023/v68/build-identity.json'),('full-cycle',R/'.build/q2-full-cycle-20261025/native-build/candidate/build-identity.json'),('early-disabled',R/'.build/q2-early-expert-20261026/native-build-v2/candidate/build-identity.json')]:files['reference/'+label+'-build-identity.json']=path
F=R/'.build/q2-full-cycle-20261025'
for n in ['validation-0-N.json','validation-s-0-S.json']:files['reference/'+n]=F/n
S=R/'.build/q2-required-dependencies-20261026/source-reference'
files['reference/Splash-LICENSE']=S/'LICENSE';files['reference/Slotstream-LICENSE']=R/'LICENSE';files['reference/Splash-MoE.h']=S/'runtime/metal/abi/MoE.h'
manifest={}
for n,f in files.items():
 b=f.read_bytes();assert not secret.search(b),n;manifest[n]=dict(bytes=len(b),sha256=sha(b))
dest=R/'db/sources/runs/2026/10/q2-routing-and-read-issuance-2026-10-26.tar.xz';assert not dest.exists();raw=json.dumps(manifest,indent=2).encode()
with tarfile.open(dest,'w:xz',preset=3)as t:
 for n,f in sorted(files.items()):t.add(f,arcname=n,recursive=False)
 info=tarfile.TarInfo('archive-manifest.json');info.size=len(raw);t.addfile(info,io.BytesIO(raw))
seen={}
with tarfile.open(dest,'r|xz')as t:
 for m in t:
  b=t.extractfile(m).read()
  if m.name=='archive-manifest.json':assert json.loads(b)==manifest
  else:seen[m.name]=dict(bytes=len(b),sha256=sha(b))
assert seen==manifest and dest.stat().st_size<100_000_000
receipt=dict(path=str(dest.relative_to(R)),files=len(manifest),bytes=dest.stat().st_size,sha256=sha(dest.read_bytes()),readback_verified=True,credential_pattern_matches=0,excluded='Executables, libraries, weights, pycache, duplicate source archives and active archive-driver output. Reused dependency traces remain in their previously verified archives; analysis paths identify them.')
(P/'archive-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt),flush=True)
