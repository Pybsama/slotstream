#pragma once
#include <array>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <stdexcept>
#include <vector>
namespace routework {
struct Event {int round,step,kind;uint32_t layer,rows;std::vector<std::array<uint32_t,3>> entries;};
inline int round=-1,step=-1;
inline std::vector<Event> events;
inline void mark(int r,int s){round=r;step=s;}
inline void add(Event e){if(step<0)return;if(events.size()>=16000||e.entries.size()>80)throw std::runtime_error("route trace bound");events.push_back(std::move(e));}
inline void dump(){const char*path=std::getenv("Q2_ROUTE_OUTPUT");if(!path)throw std::runtime_error("missing route output");FILE*f=std::fopen(path,"wx");if(!f)throw std::runtime_error("route output exists");std::fputs("{\"events\":[",f);bool first=true;for(const auto&e:events){if(!first)std::fputc(',',f);first=false;std::fprintf(f,"{\"round\":%d,\"step\":%d,\"kind\":%d,\"layer\":%u,\"rows\":%u,\"entries\":[",e.round,e.step,e.kind,e.layer,e.rows);bool f2=true;for(const auto&a:e.entries){if(!f2)std::fputc(',',f);f2=false;std::fprintf(f,"[%u,%u,%u]",a[0],a[1],a[2]);}std::fputs("]}",f);}std::fputs("]}\n",f);std::fclose(f);}
}
