from pathlib import Path
import json
P=Path(__file__).resolve().parent;D=P.parent/'q2-required-dependencies-20261026'
d=json.loads((D/'residual-analysis.json').read_text());summary=[]
for arm in d['arms']:
 if not arm['label'].endswith('N'):continue
 for name,predicate in [('contains_mixture',lambda s:'grouped_moe_combine' in s),('starts_expert',lambda s:s.startswith('native_repack') or s.startswith('native_gather')),('contains_router',lambda s:'q2_routes' in s)]:
  selected=[g for g in arm['groups']if predicate(g['signature'])]
  summary.append(dict(round=arm['round'],category=name,seconds=sum(g['seconds']for g in selected),before_encoder=sum(g['before_encoder']for g in selected),encoding_to_submit=sum(g['encoding_to_submit']for g in selected),after_submit=sum(g['after_submit']for g in selected),count=sum(g['count']for g in selected)))
result=dict(scope='Offline localization in existing clean dependency trace. Categories can overlap. Following encoder names are not proof of the preceding cause. Does not measure a new candidate.',rows=summary)
(P/'mixture-localization.json').write_text(json.dumps(result,indent=2))
