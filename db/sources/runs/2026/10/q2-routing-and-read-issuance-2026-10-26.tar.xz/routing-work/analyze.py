from pathlib import Path
import collections,hashlib,json
P=Path(__file__).resolve().parent
files=[P/'validation-0-N.json.routes.json',P/'validation-1-S.json.routes.json']
reports={};traces=[]
fixture=json.loads((P/'timed-2.json').read_text())['steps']
for name,path in zip(['native','splash'],files):
 data=json.loads(path.read_text())['events'];by={}
 for e in data:
  k=(e['round'],e['step'],e['kind'],e['layer']);assert k not in by,k;by[k]=e
  assert 1<=e['rows']<=8 and len(e['entries'])==len(set(a[0]for a in e['entries']))
  if e['kind']==0:assert sum(a[1]for a in e['entries'])==len(fixture[e['step']]['tokens'])*10
  e['active_rows']=len(fixture[e['step']]['tokens'])
 assert len(by)==10545
 cur=[e for e in data if e['kind']==0];fore=[e for e in data if e['kind']==1]
 metrics=dict(current_events=len(cur),forecast_events=len(fore),routed_rows=sum(sum(a[1]for a in e['entries'])for e in cur),unique_experts=sum(len(e['entries'])for e in cur),cache_misses=sum(sum(a[2]==0 for a in e['entries'])for e in cur),forecast_candidates=sum(len(e['entries'])for e in fore),forecast_nonresident=sum(sum(a[2]==0 for a in e['entries'])for e in fore))
 useful=0;misses=0;rank_total=0;ranked_count=0;forecast_only=0
 for f in fore:
  current=by[(f['round'],f['step'],0,f['layer'])]
  demand={a[0]for a in current['entries']if not a[2]};ordered=[a[0]for a in f['entries']if not a[2]];possible=set(ordered)
  hits=demand&possible;useful+=len(hits);misses+=len(demand);forecast_only+=len(possible-demand)
  for i,id in enumerate(ordered):
   if id in hits:rank_total+=i;ranked_count+=1
 metrics.update(forecast_covered_current_misses=useful,current_misses_after_first_layer=misses,possible_unused_forecasts=forecast_only,mean_zero_based_useful_forecast_rank=rank_total/ranked_count)
 reports[name]=metrics;traces.append(by)
N,S=traces;assert N.keys()==S.keys();diff=collections.Counter();examples=[];bylayer=collections.defaultdict(collections.Counter)
for k,n in N.items():
 s=S[k];assert n['active_rows']==s['active_rows']
 diff['different_capacity_rows']+=int(n['rows']!=s['rows'])
 ne={a[0]:a[1]for a in n['entries']};se={a[0]:a[1]for a in s['entries']};nn=set(ne);ss=set(se)
 nm={a[0]for a in n['entries']if not a[2]};sm={a[0]for a in s['entries']if not a[2]}
 prefix='current'if n['kind']==0 else'forecast';d=bylayer[n['layer']]
 for key,amount in [('events',1),('different_sets',int(nn!=ss)),('native_only_experts',len(nn-ss)),('splash_only_experts',len(ss-nn)),('different_miss_sets',int(nm!=sm)),('native_only_misses',len(nm-sm)),('splash_only_misses',len(sm-nm)),('different_histogram',int(ne!=se)),('different_order',int([a[0]for a in n['entries']]!=[a[0]for a in s['entries']]))]:
  diff[prefix+'_'+key]+=amount;d[prefix+'_'+key]+=amount
 if nn!=ss or nm!=sm:
  examples.append(dict(round=k[0],step=k[1],kind=k[2],layer=k[3],native_only_experts=sorted(nn-ss),splash_only_experts=sorted(ss-nn),native_only_misses=sorted(nm-sm),splash_only_misses=sorted(sm-nm)))
result=dict(scope='Work comparison only, no timing claims. Native rank IDs versus Splash grouped descriptor counts; forecasts preserve ordered candidate lists. Residency captured before current demand claims, forecast residency at forecast publication. Source reports8capacityrows and masks inactive verify rows; native reports actual1..8rows. Histograms are asserted against frozen active row count, preserving this execution difference. Source fixture arena differs from product context reservation.',reports=reports,differences=dict(diff),by_layer={str(k):dict(v)for k,v in bylayer.items()},differences_by_event=examples,inputs={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in files})
(P/'analysis.json').write_text(json.dumps(result,indent=2));print(json.dumps(dict(reports=reports,differences=dict(diff)),indent=2))
