from pathlib import Path
import hashlib, io, importlib.util, json, re, subprocess, tarfile
P=Path(__file__).resolve().parent;R=P.parents[1];OLD=R/'.build/native-replay-20261023/v68'
assert (P/'demand-shape-analysis.json').exists()
spec=importlib.util.spec_from_file_location('identity',R/'Tools/build_identity.py'); identity=importlib.util.module_from_spec(spec);spec.loader.exec_module(identity)
expected=json.loads((OLD/'build-identity.json').read_text())['source'];current={str(f.relative_to(R)):identity.sha(f)for f in identity.source_files(R)}
assert expected==current
artifacts={n:identity.sha(R/'.build/release'/n)==identity.sha(OLD/n)for n in ['slotstream','slotstream-checks','mlx.metallib','build-identity.json','build-source.tar.gz']};assert all(artifacts.values())
(P/'cost-demand-restoration.json').write_text(json.dumps(dict(runtime_sources_equal_v68=True,count=len(current),artifacts=artifacts,head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),production_changes_retained=False,fast_changed=False),indent=2))
files={}
for pattern in ['cost-trace-*','cost-policy-*','demand-shape-*','cost-demand-*']:
 for f in P.glob(pattern):
  if f.is_file()and f.suffix in ['.json','.jsonl','.log','.patch']and'archive-receipt'not in f.name:files[f.name]=f
for name in ['prepare_cost_trace.py','prepare_cost_trace-v1-failed.py','build_cost_trace.py','complete_cost_trace_frozen.py','complete_cost_trace.py','analyze_cost_trace.py','summarize_cost_policy.py','analyze_duplicate_reads.py','analyze_duplicate_reads-v1-footer-error.py','physical-duplicate-read-analysis.json','read-traffic-accounting.json','prepare_demand_shape.py','build_demand_shape.py','run_demand_shape.py','analyze_demand_shape.py','Q2ProfileCommand-demand-shape.swift','archive_cost_and_demand.py','quiet_guarded_run.py','restored-cost-trace.json','restored-demand-shape.json']:
 files[name]=P/name
for directory in ['cost-trace-src','cost-policy-replay']:
 for f in(P/directory).rglob('*'):
  if f.is_file()and f.suffix in ['.swift','.cpp','.h','.hpp','.txt']:files[str(f.relative_to(P))]=f
for build in ['native-cost-trace-build','native-demand-shape-build']:
 for name in ['build.txt','manifest.json','candidate/build-identity.json','candidate/build-source.tar.gz']:
  f=P/build/name;files[str(f.relative_to(P))]=f
for name,path in [('recorded-choices.json',P/'replay-choice-input.json'),('captured-complete-request.json',P/'padding-only-complete-15-1-B.json'),('baseline-build-identity.json',OLD/'build-identity.json'),('complete-controls-archive.json',P/'complete-control-archive-receipt.json'),('sequence-archive.json',P/'archive-receipt.json')]:files['reference/'+name]=path
references={}
for name in ['observed-0-N.json','observed-1-S.json','observed-0-N-reads.95083.csv','observed-1-S-reads.95551.csv','sequence-code-0-N.json','timed-2.json']:
 f=P/name; references[name]=dict(sha256=identity.sha(f),bytes=f.stat().st_size,archive='q2-frozen-sequence-2026-10-25.tar.gz')
(P/'cost-demand-prior-inputs.json').write_text(json.dumps(references,indent=2));files['reference/prior-inputs.json']=P/'cost-demand-prior-inputs.json'
secret=re.compile(rb'(?:ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{25,}|sk-(?:proj-)?[A-Za-z0-9_-]{30,}|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----)')
for f in files.values():assert f.exists()and not secret.search(f.read_bytes()),f
manifest={n:dict(bytes=f.stat().st_size,sha256=identity.sha(f))for n,f in files.items()};raw=json.dumps(manifest,indent=2).encode()+b'\n'
dest=R/'db/sources/runs/2026/10/q2-cost-and-demand-diagnosis-2026-10-25.tar.gz';assert not dest.exists()
with tarfile.open(dest,'w:gz')as tar:
 for n,f in sorted(files.items()):tar.add(f,arcname=n,recursive=False)
 info=tarfile.TarInfo('archive-manifest.json');info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
with tarfile.open(dest)as tar:
 for n,m in manifest.items():
  raw=tar.extractfile(n).read();assert len(raw)==m['bytes']and hashlib.sha256(raw).hexdigest()==m['sha256']
receipt=dict(path=str(dest.relative_to(R)),files=len(manifest),bytes=dest.stat().st_size,sha256=identity.sha(dest),readback_verified=True,credential_pattern_matches=0)
(P/'cost-demand-archive-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
