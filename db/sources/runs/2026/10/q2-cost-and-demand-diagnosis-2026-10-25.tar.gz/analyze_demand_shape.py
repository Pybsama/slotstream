from pathlib import Path
import json, math, statistics
P=Path(__file__).resolve().parent
label='demand-shape-15-0-N'
d=json.loads((P/(label+'.json')).read_text())
base=json.loads((P/'sequence-code-0-N.json').read_text())
reference={r['step']:r['logits_sha256'] for r in base['runs']if r['round']==1}
assert len(reference)==111 and all(r['logits_sha256']==reference[r['step']]for r in d['runs'])
out=dict(scope='Buffered demand observer. Diagnostic execution and counter accounting, not trace-disabled speed qualification. Event duration upper-bounds the time a batch-splitting change could affect and overlaps GPU execution.',all_logits_exact=True,rounds=[])
for rnd in sorted({r['round']for r in d['runs']}):
 rows=[r for r in d['runs']if r['round']==rnd]; events=[]
 for r in rows:
  es=r['demand_events']; assert len(es)==48 and all(not e['mixed']for e in es)
  for e in es:
   assert len(set(e['misses']))==len(e['misses']);assert set(e['adopted'])<=set(e['misses'])
   n=len(e['misses'])-len(e['adopted']);events.append(dict(step=r['step'],width=r['width'],layer=e['layer'],misses=len(e['misses']),adopted=len(e['adopted']),demand=n,seconds=(e['end_ns']-e['start_ns'])/1e9))
  assert sum(len(e['misses'])-len(e['adopted'])for e in es)==r['records_fetched']
  assert sum(len(e['adopted'])for e in es)==r['records_adopted']
 large=[e for e in events if e['demand']>32]
 groups={}
 for width in range(1,9):
  ee=[e for e in events if e['width']==width]; ll=[e for e in ee if e['demand']>32]
  if ee:groups[str(width)]=dict(layers=len(ee),large_layers=len(ll),max_demand=max(e['demand']for e in ee),large_layer_seconds=sum(e['seconds']for e in ll))
 out['rounds'].append(dict(round=rnd,layers=len(events),demand_records=sum(e['demand']for e in events),logical_misses=sum(e['misses']for e in events),adopted=sum(e['adopted']for e in events),large_layers=len(large),max_demand=max(e['demand']for e in events),direct_batches=sum(r['direct_batches']for r in rows),minimum_one_batch_per_layer=sum(e['demand']>0 for e in events),ceil32_batches=sum(math.ceil(e['demand']/32)for e in events),large_layer_seconds=sum(e['seconds']for e in large),verification_seconds=sum(r['seconds']for r in rows),by_width=groups,large_events=large))
(P/'demand-shape-analysis.json').write_text(json.dumps(out,indent=2))
print(json.dumps({**out,'rounds':[{k:v for k,v in r.items()if k!='large_events'}for r in out['rounds']]},indent=2))
