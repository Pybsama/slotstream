from pathlib import Path
import csv,json,bisect,statistics
P=Path(__file__).resolve().parent
result=dict(scope='Offline physical-read accounting from the earlier symmetric observer protocol. That protocol is paging-excluded for speed. Exact repeated file extents and concurrent repeats are observations; neither proves lost wall time or that all repeats are avoidable. Per-engine descriptors remain owned during verification. No cross-engine descriptor mapping assumed.',engines=[])
for engine,prefix in [('native','observed-0-N'),('splash','observed-1-S')]:
 d=json.loads((P/(prefix+'.json')).read_text());passes=[r for r in d['runs']if r['round']==1];assert len(passes)==111
 reads=[];errors=0
 with next(P.glob(prefix+'-reads.*.csv')).open()as f:
  for r in csv.DictReader(f):
   n=int(r['result'])
   if n<=0:errors+=1;continue
   if n<65536:continue
   reads.append(dict(start=float(r['start']),end=float(r['end']),offset=int(r['offset']),bytes=n,fd=int(r['fd'])))
 reads.sort(key=lambda x:x['start']);starts=[r['start']for r in reads];rows=[];gaps=[]
 for step in passes:
  lo,hi=((step['start_ns']/1e9,step['end_ns']/1e9)if engine=='native'else(step['start'],step['end']))
  batch=reads[bisect.bisect_left(starts,lo):bisect.bisect_left(starts,hi)]
  previous={};duplicates=[];overlap=[]
  for r in batch:
   key=r['fd'],r['offset'],r['bytes']
   if key in previous:
    old=previous[key];gap=r['start']-old['end'];gaps.append(gap);duplicates.append(r)
    if gap<0:overlap.append(r)
   previous[key]=r
  rows.append(dict(step=step['step'],reads=len(batch),bytes=sum(r['bytes']for r in batch),exact_duplicate_reads=len(duplicates),exact_duplicate_bytes=sum(r['bytes']for r in duplicates),concurrent_duplicate_reads=len(overlap),concurrent_duplicate_bytes=sum(r['bytes']for r in overlap)))
 totals={k:sum(r[k]for r in rows)for k in rows[0]if k!='step'}
 totals['exact_duplicate_byte_fraction']=totals['exact_duplicate_bytes']/totals['bytes']
 totals['concurrent_duplicate_byte_fraction']=totals['concurrent_duplicate_bytes']/totals['bytes']
 result['engines'].append(dict(engine=engine,totals=totals,duplicate_gap_seconds=dict(count=len(gaps),median=statistics.median(gaps)if gaps else None,overlap=sum(x<0 for x in gaps),under_1ms=sum(0<=x<.001 for x in gaps),under_5ms=sum(0<=x<.005 for x in gaps)),steps=rows))
(P/'physical-duplicate-read-analysis.json').write_text(json.dumps(result,indent=2));print(json.dumps({**result,'engines':[{k:v for k,v in e.items()if k!='steps'}for e in result['engines']]},indent=2))
