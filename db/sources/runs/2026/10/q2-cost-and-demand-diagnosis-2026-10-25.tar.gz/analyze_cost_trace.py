from pathlib import Path
import json,statistics,sys,ctypes
P=Path(__file__).resolve().parent
label=sys.argv[1]
events=json.loads((P/(label+'-ledger.json')).read_text())
ref=json.loads((P/'padding-only-complete-15-1-B.json').read_text())['runs']
f32=lambda x:ctypes.c_float(x).value
lib=ctypes.CDLL('/usr/lib/libSystem.B.dylib')
for n in ['logf','expf']:
 f=getattr(lib,n);f.argtypes=[ctypes.c_float];f.restype=ctypes.c_float

def select(c, costs=None):
 d=c['decision'];costs=list(map(f32,costs or d['costs']));theta=d['theta'];survival=f32(1);expected=f32(1)
 scores=[f32(1/costs[0])]
 for i,confidence in enumerate(c['confidence']):
  p=max(f32(1e-6),min(f32(1-f32(1e-6)),f32(confidence)))
  z=f32(f32(f32(theta[0])*lib.logf(f32(p/f32(1-p))))+f32(theta[i+1]))
  survival=f32(survival*f32(1/f32(1+lib.expf(-z))))
  expected=f32(expected+survival);scores.append(f32(expected/costs[i+1]))
 choice=max(range(len(scores)),key=lambda k:scores[k])
 if d['cycles']%32==31:choice=len(c['confidence'])
 return choice,scores

out=dict(label=label,scope='Behavioral/functional trace analysis. Trace overhead and global paging prohibit treating these values as qualified speed comparisons. Prior seed costs have arbitrary units until the first cost observation.',arms=[],divergences=[])
traces={}
for e in events:
 d=json.loads((P/(e['label']+'.json')).read_text());records=[json.loads(s)for s in (P/(e['label']+'-cost.jsonl')).read_text().splitlines()]
 assert len(records)==len(d['runs'])==4
 checks=[];rows=[]
 for row,trace in zip(d['runs'],records):
  s=row['stats'];cycles=trace['cycles'];assert not trace['truncated'];assert trace['prompt_ids']==row['prompt_ids'];assert len(cycles)==s['verifyPasses']
  assert [c['chosen']for c in cycles]==s['adaptiveDraftDepths'];assert sum(c['accepted']for c in cycles)==s['acceptedDrafts'];assert sum(c['emitted']for c in cycles)==len(row['tokens'])-1
  assert all(c['decision']['cycles']==s['dflashCalibrationCyclesBefore']+i for i,c in enumerate(cycles))
  frozen='functional' in label
  if frozen:
   old=next(x for x in ref if x['id']==row['id']);assert all(old[k]==row[k]for k in ['id','prompt_ids','tokens','text','streamed','tool_calls','malformed_tool_call']);assert all(old['stats'][k]==s[k]for k in ['verifyPasses','draftedTokens','acceptedDrafts','decodeModelTokens','adaptiveDraftDepths'])
  checks.append(dict(task=row['id'],cycles=len(cycles),frozen_output_exact=frozen))
  selected=[dict(cycle=c['cycle'],actual=c['chosen'],reconstructed=select(c)[0],scores=select(c)[1])for c in cycles if select(c)[0]!=c['chosen']]
  first=[]
  for c in cycles[:12]:
   pred=c['decision']['costs'][c['chosen']]
   first.append(dict(cycle=c['cycle'],width=c['chosen']+1,prepared=c['prepared'],seconds=c['seconds'],predicted=pred if c['decision']['cycles']>0 else None,model_choice=select(c)[0]+1,confidence=c['confidence'],hits=c['hits'],misses=c['misses']))
  groups={}
  for width in range(1,9):
   subset=[c for c in cycles if c['chosen']+1==width and c['decision']['cycles']>0 and not c['prepared']]
   if subset:groups[str(width)]=dict(count=len(subset),median_actual_over_predicted=statistics.median(c['seconds']/c['decision']['costs'][width-1]for c in subset),median_seconds=statistics.median(c['seconds']for c in subset),median_prediction=statistics.median(c['decision']['costs'][width-1]for c in subset))
  rows.append(dict(task=row['id'],first=first,by_width=groups,reconstructed_mismatches=selected))
 traces[e['label']]=records
 out['arms'].append(dict(label=e['label'],budget=d['memory_gb'] if 'memory_gb'in d else None,clean=e['eligible'],cache_slots=e['actual_cache_slots'],checks=checks,tasks=rows))
if len(events)>=2:
 a=traces[events[0]['label']];b=traces[events[1]['label']]
 for ia,ib,row in zip(a,b,ref):
  for ca,cb in zip(ia['cycles'],ib['cycles']):
   if ca['chosen']!=cb['chosen']:
    out['divergences'].append(dict(task=row['id'],cycleA=ca['cycle'],cycleB=cb['cycle'],same_confidence=ca['confidence']==cb['confidence'],same_acceptance=ca['decision']['theta']==cb['decision']['theta'],A=ca,B=cb,A_with_B_costs=select(ca,cb['decision']['costs'])[0],B_with_A_costs=select(cb,ca['decision']['costs'])[0]));break
(P/(label+'-analysis.json')).write_text(json.dumps(out,indent=2))
print(json.dumps(dict(arms=[dict(label=a['label'],clean=a['clean'],slots=a['cache_slots'],checks=a['checks'],policy_choice_differences=sum(len(t['reconstructed_mismatches'])for t in a['tasks']))for a in out['arms']],divergences=[{k:v for k,v in d.items()if k not in ['A','B']}for d in out['divergences']]),indent=2))
