from pathlib import Path
import json, statistics, math
P=Path(__file__).resolve().parent
arms=[]
for name in ['cost-policy-replay-A','cost-policy-replay-B','cost-policy-adaptive-A','cost-policy-adaptive-B']:
    d=json.loads((P/(name+'.json')).read_text()); rows=d['rows']; groups=[]
    for request in sorted({r['request'] for r in rows}):
        rr=[r for r in rows if r['request']==request]
        valid=[r for r in rr if r['global_cycle']>0 and not r['prepared']]
        groups.append(dict(request=request,cycles=len(rr),choice_changes=sum(r['baseline_choice']!=r['omitted_choice'] for r in rr),max_relative_cost_change=max(abs(a-b)/a for r in rr for a,b in zip(r['baseline_costs'],r['omitted_costs'])),mean_abs_log_cost_error=statistics.mean(abs(math.log(r['seconds']/r['baseline_costs'][r['chosen_width']-1])) for r in valid),omitted_mean_abs_log_cost_error=statistics.mean(abs(math.log(r['seconds']/r['omitted_costs'][r['chosen_width']-1])) for r in valid)))
    arms.append(dict(name=name,cycles=len(rows),snapshot_mismatches=d['baseline_snapshot_mismatches'],held_labels=d['acceptance_and_cycles_identical'],requests=groups))
result=dict(scope='Actual Swift replay, held observed work and labels. Omission of prepared sample affects counterfactual cost tables, not actual alternate execution. No timing/speed prediction.',total_snapshots=sum(x['cycles'] for x in arms),arms=arms)
(P/'cost-policy-all-summary.json').write_text(json.dumps(result,indent=2))
print(json.dumps(dict(total_snapshots=result['total_snapshots'],snapshot_mismatches=sum(a['snapshot_mismatches']for a in arms))))
