from pathlib import Path
import json
P=Path(__file__).resolve().parent; R=P.parents[1]
s=(P/'Q2ProfileCommand-v4.swift').read_text()
observer='''
private final class DemandShapeObserver: ExpertLookaheadObserver {
    var events: [[String: Any]] = []
    func beginPass(id: Int, phase: ExpertLookaheadPhase, tokens: [Int], features: [ExpertLookaheadStartFeature], nanos: UInt64) { events.removeAll(keepingCapacity: true) }
    func routes(pass: Int, layer: Int, rows: Int, topK: Int, ids: [Int32]) {}
    func layerCompleted(pass: Int, layer: Int, x2: MLXArray, nanos: UInt64) {}
    func demand(_ e: ExpertLookaheadDemandEvent) {
        events.append(["layer": e.layer, "mixed": e.mixedLayers, "unique": e.uniqueExperts,
            "hits": e.hitExperts, "misses": e.missExperts, "adopted": e.adoptedExperts,
            "promoted": e.promotedExperts, "start_ns": e.startNanos, "read_ns": e.readNanos,
            "adopt_ns": e.adoptNanos, "end_ns": e.endNanos])
    }
    func admissions(pass: Int, layer: Int, experts: [Int32]) {}
    func residency(_ snapshot: ExpertLookaheadResidency, afterPass: Int) {}
    func passReconciled(id: Int, kept: Int) {}
    func endPass(id: Int, nanos: UInt64, aborted: Bool) {}
}
'''
s+=observer
needle='let model=engine.model'; assert s.count(needle)==1
s=s.replace(needle,needle+'\n                let demandObserver = DemandShapeObserver()')
needle='if ahead==1 {try model.enableNativeInputReadAhead(reservedBytes:plan.lookaheadReserveBytes)}'; assert s.count(needle)==1
s=s.replace(needle,needle+'\n                    model.lookahead?.observer = demandObserver')
needle='"read_handles":model.readHandleCount])'; assert s.count(needle)==1
s=s.replace(needle,'''"read_handles":model.readHandleCount,
                            "direct_batches":model.pool.slotDirectBatches, "demand_events":demandObserver.events,
                            "forecast":try JSONSerialization.jsonObject(with: JSONEncoder().encode(model.lookahead?.prefetch?.observation))])''')
(P/'Q2ProfileCommand-demand-shape.swift').write_text(s)
b=(P/'build_native_v4.py').read_text().replace("'Q2ProfileCommand-v4.swift'","'Q2ProfileCommand-demand-shape.swift'").replace("'native-build-v4'","'native-demand-shape-build'").replace("'restored-v4.json'","'restored-demand-shape.json'")
(P/'build_demand_shape.py').write_text(b)
plan=dict(question='How often do real Q2 demand batches exceed 32 after forecast adoption? Account for physical extra read bytes versus actual logical misses.',protocol='One native frozen 111-pass continuation, two rounds first warmup, baseline v68 runtime with existing demand observer and buffered per-pass counters. 15 GB/4067 slots/8192 context. No per-read logger or model arithmetic changes. Diagnostic timing only. Compare every logit hash with previous baseline.',hypothesis='Native splits demand every 32 even when the Q2 native stage already owns room for all <=80 misses; Splash stages the complete pass. Only pursue a bounded batch fix if observed events show meaningful extra barriers.',decision='Do not use extra physical bytes or waits alone to infer GPU idleness or speed. Small fixed demand count differences and cancellation/read overlap must be retained. Fast unchanged. No scheduler rewrite from this observation.')
(P/'demand-shape-plan.json').write_text(json.dumps(plan,indent=2))
