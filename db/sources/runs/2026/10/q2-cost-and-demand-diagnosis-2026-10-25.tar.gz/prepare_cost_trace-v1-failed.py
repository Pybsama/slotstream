from pathlib import Path
import json,difflib
P=Path(__file__).resolve().parent;R=P.parents[1]
paths=json.loads((P/'replay-choice-paths.json').read_text())+['Sources/Slotstream/DFlashVerifyBudget.swift']
sources={f:(P/'replay-choice-src'/f).read_text() for f in paths[:-1]}
f=paths[-1];s=(R/f).read_text();marker='    package func depth(confidence: [Float]) -> Int {'
insert='''    // Temporary diagnostic snapshot; never changes the selected depth.
    package struct Diagnostic: Encodable {
        let cycles: Int
        let costs: [Float]
        let theta: [Double]
    }
    package func diagnosticSnapshot() -> Diagnostic {
        Diagnostic(cycles: cycles, costs: (1...8).map { cost($0) }, theta: theta)
    }
'''
assert s.count(marker)==1;sources[f]=s.replace(marker,insert+marker)
f='Sources/Slotstream/DFlashGenerate.swift';s=sources[f]
marker='        let environment = ProcessInfo.processInfo.environment'
insert='''
        let costTracePath = model.pool.expertStore.isQ2 ? environment["SLOTSTREAM_Q2_COST_TRACE"] : nil
        struct CostCycle: Encodable {
            let cycle: Int
            let context: Int
            let decision: DFlashVerifyBudget.Diagnostic
            let confidence: [Float]
            let chosen: Int
            let accepted: Int
            let emitted: Int
            let bonus: Bool?
            let labelsValid: Bool
            let prepared: Bool
            let seconds: Double
            let draftSeconds: Double
            let verifySeconds: Double
            let hits: Int
            let misses: Int
        }
        struct CostTrace: Encodable {
            let prompt_ids: [Int]
            let cycles: [CostCycle]
            let truncated: Bool
        }
        let tracePrompt = costTracePath == nil ? [] : consumed
        var costCycles: [CostCycle] = []
        if costTracePath != nil { costCycles.reserveCapacity(min(params.maxTokens, 8192)) }
'''
assert s.count(marker)==1;s=s.replace(marker,marker+insert)
marker='            let pipelinesBefore = q2Calibration ? NativeProjectionSchedule.pipelineCount : 0'
insert='''            let traceContext = state.tokenCount
            let traceHits = costTracePath == nil ? 0 : model.pool.hits
            let traceMisses = costTracePath == nil ? 0 : model.pool.misses
            let traceDraft = stats.draftSeconds, traceVerify = stats.verifySeconds
'''
assert s.count(marker)==1;s=s.replace(marker,insert+marker)
marker='            let chosen: Int'
assert s.count(marker)==1;s=s.replace(marker,'            let decision = costTracePath == nil ? nil : verifyBudget?.diagnosticSnapshot()\n'+marker)
old='''            verifyBudget?.observe(confidence: draft.proposalConfidence, verified: proposals.count,
                accepted: accepted, seconds: RuntimeClock.seconds(since: started),
                labelsValid: labelsValid, bonusAccepted: bonusAccepted)'''
new='''            let cycleSeconds = RuntimeClock.seconds(since: started)
            if let decision, costCycles.count < 8192 {
                costCycles.append(CostCycle(cycle: stats.verifyPasses - 1, context: traceContext,
                    decision: decision, confidence: draft.proposalConfidence, chosen: proposals.count,
                    accepted: accepted, emitted: out.count - emittedBefore, bonus: bonusAccepted,
                    labelsValid: labelsValid, prepared: preparedPipelines, seconds: cycleSeconds,
                    draftSeconds: stats.draftSeconds - traceDraft,
                    verifySeconds: stats.verifySeconds - traceVerify,
                    hits: model.pool.hits - traceHits, misses: model.pool.misses - traceMisses))
            }
            verifyBudget?.observe(confidence: draft.proposalConfidence, verified: proposals.count,
                accepted: accepted, seconds: cycleSeconds,
                labelsValid: labelsValid, bonusAccepted: bonusAccepted)'''
assert s.count(old)==1;s=s.replace(old,new)
ending='''        }
    }
}
'''
assert s.endswith(ending)
s=s[:-len(ending)]+'''        }
        if let costTracePath {
            let trace = CostTrace(prompt_ids: tracePrompt, cycles: costCycles,
                truncated: stats.verifyPasses > costCycles.count)
            var bytes = try JSONEncoder().encode(trace); bytes.append(0x0a)
            if !FileManager.default.fileExists(atPath: costTracePath) {
                guard FileManager.default.createFile(atPath: costTracePath, contents: nil) else {
                    throw ModelError("Cannot create diagnostic cost trace")
                }
            }
            let file = try FileHandle(forWritingTo: URL(fileURLWithPath: costTracePath))
            defer { try? file.close() }
            try file.seekToEnd(); try file.write(contentsOf: bytes)
        }
    }
}
'''
sources[f]=s
for f,s in sources.items():
 dest=P/'cost-trace-src'/f;dest.parent.mkdir(parents=True,exist_ok=True);assert not dest.exists();dest.write_text(s)
(P/'cost-trace-paths.json').write_text(json.dumps(paths,indent=2))
(P/'cost-trace.patch').write_text(''.join(''.join(difflib.unified_diff((R/f).read_text().splitlines(True),s.splitlines(True),fromfile='a/'+f,tofile='b/'+f))for f,s in sources.items()))
(P/'build_cost_trace.py').write_text((P/'build_replay_choice.py').read_text().replace('replay-choice','cost-trace'))
plan=dict(status='Prepared before build/results',purpose='Observe ordinary Q2 selector decisions and costs, without changing them. Inspect first divergence and residual errors before any proposed policy change.',bounded='8192cyclesmaximum, atmost384inourcases. Costs/confidences/coefficients and integer work stored in memory; JSONserialization occurs once after eachrequest. No perread tracing or new GPUreadbacks. Decision observation and actualduration share the same existing cycle boundary.',validation='First run captured-choice replay with tracing on and compare every output/corework to the prior trace-disabled captured reference. Then ordinary ABBAcopy/direct in the same diagnosticbinary; behavioral/data analysis only, not a speedqualification. No untraced shipping gain inferred. Preserve allpaging and adverse outcomes.',limits='Recorded costs are model predictions. Observational residuals and firstdivergences alone do not prove an improved selector. Arithmetic and output remain target-owned. Traceoverhead may influence ordinary timing-basedchoices. Fast and production sources/defaultartifacts restorev68.')
(P/'cost-trace-plan.json').write_text(json.dumps(plan,indent=2))
print('Prepared bounded cost-only instrumentation in diagnostic source')
