import Foundation
struct InputDecision: Decodable { let cycles: Int; let costs: [Float]; let theta: [Double] }
struct InputCycle: Decodable {
    let cycle: Int; let decision: InputDecision; let confidence: [Float]
    let chosen: Int; let accepted: Int; let seconds: Double
    let prepared: Bool; let labelsValid: Bool; let bonus: Bool?
}
struct InputTrace: Decodable { let cycles: [InputCycle] }
let arguments = CommandLine.arguments
precondition(arguments.count >= 3)
var baseline = DFlashVerifyBudget(), omitted = DFlashVerifyBudget()
var measuredCost = false
var rows: [[String: Any]] = []
var mismatches = 0
for file in arguments.dropFirst(2) {
    let text = try String(contentsOfFile: file, encoding: .utf8)
    for (request, line) in text.split(separator: "\n").enumerated() {
        let trace = try JSONDecoder().decode(InputTrace.self, from: Data(line.utf8))
        for value in trace.cycles {
            let decision = value.decision
            let confidence = value.confidence, costs = decision.costs, theta = decision.theta
            let chosen = value.chosen, accepted = value.accepted, seconds = value.seconds
            let prepared = value.prepared, labelsValid = value.labelsValid, bonus = value.bonus
            let before = baseline.diagnosticSnapshot(), alternative = omitted.diagnosticSnapshot()
            let exact = before.cycles == decision.cycles && before.costs == costs && before.theta == theta
            if !exact { mismatches += 1 }
            precondition(before.theta == alternative.theta && baseline.labelCount == omitted.labelCount && baseline.cycleCount == omitted.cycleCount)
            var row: [String: Any] = ["file": URL(fileURLWithPath: file).lastPathComponent,
                "request": request, "cycle": value.cycle, "global_cycle": before.cycles,
                "prepared": prepared, "chosen_width": chosen + 1, "seconds": seconds,
                "baseline_costs": before.costs, "omitted_costs": alternative.costs,
                "baseline_choice": baseline.depth(confidence: confidence),
                "omitted_choice": omitted.depth(confidence: confidence), "baseline_exact": exact, "costs_exact": before.costs == costs,
                "baseline_theta": before.theta, "recorded_theta": theta,
                "max_theta_error": zip(before.theta,theta).map { abs($0 - $1) }.max()!]
            if measuredCost && before.cycles > 0 {
                row["baseline_log_error"] = abs(log(seconds / Double(before.costs[chosen])))
                row["omitted_log_error"] = abs(log(seconds / Double(alternative.costs[chosen])))
            }
            rows.append(row)
            baseline.observe(confidence: confidence, verified: chosen, accepted: accepted,
                seconds: seconds, labelsValid: labelsValid, bonusAccepted: bonus)
            omitted.observe(confidence: confidence, verified: chosen, accepted: accepted,
                seconds: prepared ? .nan : seconds, labelsValid: labelsValid, bonusAccepted: bonus)
            if !prepared && seconds.isFinite && seconds > 0 { measuredCost = true }
        }
    }
}
let result: [String: Any] = ["scope": "Offline real Swift policy replay on held observed widths, durations and labels. Omitting preparation cost changes only the fit; no alternate model work is executed. Not a generation speed estimate.",
    "baseline_snapshot_mismatches": mismatches, "acceptance_and_cycles_identical": true, "rows": rows]
let data = try JSONSerialization.data(withJSONObject: result, options: [.prettyPrinted, .sortedKeys])
try data.write(to: URL(fileURLWithPath: arguments[1]))
print("replayed \(rows.count) cycles; baseline snapshot mismatches \(mismatches); acceptance and cycle counts identical")
precondition(mismatches == 0)
