from pathlib import Path
import subprocess,sys,fcntl,os,json,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1];D=R/'.build/q2-typical-20261025/upstream'
W=Path('/var/folders/d4/t1c8ltbx5s3_11cs9y6gjh8m0000gp/T/slotstream-splash-host-ugnf26pi/source')
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
preflight(10)
assert 'kHostStepSpin = std::chrono::milliseconds(0)' in (W/'runtime/metal/MetalBackend.mm').read_text()
with open(f'/tmp/slotstream-model-{os.getuid()}.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 command=['xcrun','-sdk','macosx','clang++','-std=c++20','-O2','-mmacosx-version-min=26.4','-I'+str(D/'include'),'-I'+str(W/'runtime'),'-I'+str(W/'dev'),'-fobjc-arc',str(P/'frequency-cache-upstream.mm'),str(D/'Runtime.o'),str(D/'ExpertStore.o'),str(W/'build/engine/metal/MetalBackendInstrumented.o'),str(W/'build/engine/libsplash.a'),'-framework','Foundation','-framework','Metal','-framework','IOKit','-framework','IOSurface','-o',str(P/'frequency-cache-fixed-verify')]
 with(P/'frequency-cache-upstream-build.log').open('x')as f:result=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
 inputs=[P/'frequency-cache-upstream.mm',D/'Runtime.o',D/'ExpertStore.o',W/'build/engine/metal/MetalBackendInstrumented.o',W/'build/engine/libsplash.a',D/'splash.metallib']
 if not result.returncode:inputs.append(P/'frequency-cache-fixed-verify')
 (P/'frequency-cache-upstream-identity.json').write_text(json.dumps(dict(command=command,exit_code=result.returncode,sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in inputs}),indent=2))
 raise SystemExit(result.returncode)
