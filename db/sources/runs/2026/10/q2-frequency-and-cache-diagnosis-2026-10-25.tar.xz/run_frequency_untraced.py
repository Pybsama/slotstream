from pathlib import Path
import json,sys,subprocess,fcntl,os,argparse,time,statistics
P=Path(__file__).resolve().parent;R=P.parents[1]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight,terminate_child_tree
sys.path.insert(0,str(R/'.build/native-q2-20261021'));from thermal import wait_nominal
ap=argparse.ArgumentParser();ap.add_argument('--label',required=True);ap.add_argument('--order',default='NSSN');ap.add_argument('--fixture',default='timed-2');ap.add_argument('--rounds',type=int,default=3);ap.add_argument('--ahead',type=int,default=1);a=ap.parse_args()
reservation=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(reservation,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert a.rounds==2 and a.order=='NSSN' and a.ahead==1
inner=P/(a.label+'-child.lock');os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(inner);ledger=P/(a.label+'-ledger.json');assert not ledger.exists();events=[]
protocol=dict(scope='Observer-disabled control for frequency-stages localization; fixed inputs and natural partial misses. Not complete-request qualification or causal frequency intervention.',order=a.order,rounds=a.rounds,interval_ms=200,budget_gb=15,observer='macmon 0.10.0 IOReport only; no injected GPU or read observers; no power, priority or workload changes',analysis='Whole protocol eligibility; compare native and Splash and within-engine order. Frequency samples are whole device; evaluate association with window boundary uncertainty. Warmup round excluded from primary totals.')
(P/(a.label+'-protocol.json')).write_text(json.dumps(protocol,indent=2))
fixture=P/(a.fixture+'.json');data=json.loads(fixture.read_text());slots=4067
expert=3*(slots*409600+((slots*51200+16383)//16384)*16384)+471859200+98304+14336+16+32*(512+22)*4
model=R/'.build/smart-dflash-eval/upstream-prepared/.resolved/938d6d6879dac79e95a5eae858867e0af230dc252a18266c6aefb6732b65dee7'
for i,arm in enumerate(a.order):
 label=f'{a.label}-{i}-{arm}';out=P/(label+'.json');assert not out.exists()
 wait_nominal(P/(label+'-cooldown.json'));preflight(18)
 env=['--env','SLOTSTREAM_MODEL_LOCK_PATH='+str(inner),'--env','DYLD_INSERT_LIBRARIES=']
 if arm=='N':
  cmd=[str(P/'native-build-v4/candidate/slotstream'),'q2-profile','--fixture',str(fixture),'--output',str(out),'--memory-gb','15','--rounds',str(a.rounds),'--ahead',str(a.ahead)]
 else:
  cmd=[str(P/'upstream/fixed-verify'),str(P/'upstream/splash.metallib'),str(model),'--prompt-tokens',str(len(data['prompt_ids'])),'--cycles',str(a.rounds),'--kv-format','bf16','--state-format','fp32','--expert-memory',str(expert),'--ple-memory','51200000']
  env+=['--env','Q2_DIAGNOSTIC_FIXTURE='+str(fixture),'--env','Q2_SEQUENCE_AHEAD='+str(a.ahead)]
 full=[sys.executable,str(P/'quiet_guarded_run.py'),'--label',label,'--budget','15','--timeout','600',*env,'--',*cmd]
 print('START',label,flush=True)
 children=[]
 with(P/(label+'-launcher.log')).open('x')as f,(P/(label+'-frequency.jsonl')).open('x')as freq,(P/(label+'-frequency.stderr')).open('x')as ferr:
  try:
   monitor=subprocess.Popen([str(R/'.build/native-monitor/macmon'),'pipe','-s','3300','-i','200','--soc-info'],stdout=freq,stderr=ferr,start_new_session=True);children.append(monitor)
   child=subprocess.Popen(full,cwd=R,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);children.append(child)
   rc=child.wait(timeout=660)
  finally:
   for c in reversed(children):
    if c.poll()is None:terminate_child_tree(c)
 guard=json.loads((P/(label+'.observer.json')).read_text());event=dict(label=label,arm=arm,exit_code=rc,guard=guard,command=full)
 if rc==0:
  if arm=='N':
   result=json.loads(out.read_text());assert result['plan']['pool_slots']==slots;rows=result['runs']
  else:
   rows=[];top1={};observed=None
   for line in(P/(label+'.log')).read_text().splitlines():
    x=line.split()
    if line.startswith('CONFIG '):observed=int(dict(s.split('=',1)for s in x[1:])['slots'])
    if line.startswith('TOP1 '):top1[(int(x[1]),int(x[2]))]=list(map(int,x[3:]))
    if not line.startswith('ROW '):continue
    assert len(x)==19,(len(x),x)
    row=dict(zip(['round','step','width','kept'],map(int,x[1:5])))
    row.update(zip(['start','prepared','submitted','end','gpu_seconds','host_seconds','commit_seconds'],map(float,x[5:12])))
    row.update(zip(['records_fetched','records_adopted','read_bytes'],map(int,x[12:15])))
    row.update(zip(['pickup_seconds','read_work_seconds','resume_seconds'],map(float,x[15:18])))
    row['logits_sha256']=x[18];row['seconds']=row['end']-row['start'];rows.append(row)
   for row in rows:row['top1']=top1[(row['round'],row['step'])]
   assert observed==slots;out.write_text(json.dumps(dict(slots=slots,runs=rows),indent=2))
  assert len(rows)==a.rounds*len(data['steps'])
  reference={r['step']:r['logits_sha256']for r in rows if r['round']==0}
  assert all(reference[r['step']]==r['logits_sha256']for r in rows),'frozen output changed across rounds'
  event['rounds']=[dict(round=j,seconds=sum(r['seconds']for r in rows if r['round']==j),records=sum(r['records_fetched']for r in rows if r['round']==j),adopted=sum(r['records_adopted']for r in rows if r['round']==j),commit_seconds=sum(r['commit_seconds']for r in rows if r['round']==j))for j in range(a.rounds)]
  event['eligible']=not guard['external_build_samples'] and not guard['paging'] and guard['thermal_before']==guard['thermal_after']==0 and guard['peak_combined_bytes']<=15e9
 events.append(event);ledger.write_text(json.dumps(events,indent=2));print('END',label,'rc',rc,'eligible',event.get('eligible'),'rounds',event.get('rounds'),flush=True)
 if rc:raise SystemExit(rc)
