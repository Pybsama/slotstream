from pathlib import Path
import hashlib,io,json,re,tarfile,subprocess
P=Path(__file__).resolve().parent;R=P.parents[1]
assert not (R/'db/sources/runs/2026/10/q2-frequency-and-cache-diagnosis-2026-10-25.tar.xz').exists()
files={}
patterns=['frequency-stages-*','frequency-untraced-*','frequency-cache-*','next-pass-clock-probe.*']
for pattern in patterns:
 for f in P.glob(pattern):
  if f.is_file() and f.suffix in ['.json','.jsonl','.log','.csv','.mm','.swift','.stderr'] and 'archive-receipt' not in f.name:files[f.name]=f
for n in ['run_frequency_stages.py','run_frequency_untraced.py','run_frequency_cache.py','analyze_frequency_stages.py','analyze_frequency_untraced.py','analyze_frequency_cache.py','analyze_frequency_cache_details.py','build_frequency_cache.py','build_frequency_cache_upstream.py','Q2ProfileCommand-frequency-cache.swift','ExpertStore-frequency-cache.swift','quiet_guarded_run.py','timed-2.json','Q2ProfileCommand-v4.swift','named_stage_observer.mm','archive_frequency_diagnosis.py','restored-frequency-cache.json']:
 files[n]=P/n
for n in ['manifest.json','build.txt']:
 files['cache-build/'+n]=P/'native-frequency-cache-build'/n
for n in ['build-identity.json','build-source.tar.gz']:
 files['cache-build/candidate/'+n]=P/'native-frequency-cache-build/candidate'/n
files['reference/native-v68-build-identity.json']=R/'.build/native-replay-20261023/v68/build-identity.json'
files['reference/native-v4-build-identity.json']=P/'native-build-v4/candidate/build-identity.json'
files['reference/cached-fixture.json']=R/'.build/q2-handoff-20261025/fixture-4.json'
files['reference/cached-evictions.json']=R/'.build/q2-handoff-20261025/evictions-4.json'
files['reference/macmon-readme.md']=R/'.build/native-monitor/readme.md'
files['reference/macmon-LICENSE']=R/'.build/native-monitor/LICENSE'
files['reference/read_observer.cpp']=R/'.build/q2-handoff-20261025/read_observer.cpp'
files['cached/native-fixed-logits.f32']=P/'frequency-cache-4-0-N.json-cached_off.f32'
files['cached/splash-fixed-logits.f32']=P/'frequency-cache-4-1-S-cached_off-2.f32'
secret=re.compile(rb'(?:ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{25,}|sk-(?:proj-)?[A-Za-z0-9_-]{30,}|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----)')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for f in files.values():assert f.exists() and not secret.search(f.read_bytes()),f
manifest={n:dict(bytes=f.stat().st_size,sha256=sha(f))for n,f in files.items()};raw=json.dumps(manifest,indent=2).encode()+b'\n'
dest=R/'db/sources/runs/2026/10/q2-frequency-and-cache-diagnosis-2026-10-25.tar.xz'
with tarfile.open(dest,'w:xz',preset=3) as t:
 for n,f in sorted(files.items()):t.add(f,arcname=n,recursive=False)
 info=tarfile.TarInfo('archive-manifest.json');info.size=len(raw);t.addfile(info,io.BytesIO(raw))
seen={}
with tarfile.open(dest,'r|xz') as t:
 for member in t:
  data=t.extractfile(member).read()
  if member.name=='archive-manifest.json':assert json.loads(data)==manifest
  else:seen[member.name]=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
assert seen==manifest
receipt=dict(path=str(dest.relative_to(R)),files=len(manifest),bytes=dest.stat().st_size,sha256=sha(dest),readback_verified=True,credential_pattern_matches=0)
(P/'frequency-diagnosis-archive-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
