from pathlib import Path
import json,statistics,datetime
P=Path(__file__).resolve().parent
x=json.loads((P/'frequency-cache-analysis.json').read_text());report=[]
for arm in x['arms']:
 label=arm['label'];r=json.loads((P/(label+'.json')).read_text());g=json.loads((P/(label+'.observer.json')).read_text());offset=arm['clock_offset_seconds']
 freq=[json.loads(l)for l in(P/(label+'-frequency.jsonl')).read_text().splitlines()]
 times=[datetime.datetime.fromisoformat(v['timestamp']).timestamp()-offset for v in freq];wins=[(times[i-1]if i else t-arm['sample_interval_seconds'],t,v)for i,(t,v)in enumerate(zip(times,freq))]
 conditions={}
 for c in ['cached_off','partial_off','cached_on','partial_on']:
  rows=[z for z in r['runs']if z['condition']==c and z['round']>=2];assert len(rows)==64
  spans=[(z['start_ns']/1e9,z['end_ns']/1e9)if'start_ns'in z else(z['start'],z['end'])for z in rows]
  weighted={k:0.0 for k in ['cpu_power','gpu_power','cpu_temp_avg','gpu_temp_avg']};covered=0
  for lo,hi,v in wins:
   dt=sum(max(0,min(hi,b)-max(lo,a))for a,b in spans)
   covered+=dt
   for k in weighted:weighted[k]+=dt*(v['temp'][k]if'temp'in k else v[k])
  total=sum(b-a for a,b in spans);assert abs(covered-total)<.01
  stats=dict(**arm['by_condition'][c],mean_aux={k:v/covered for k,v in weighted.items()},quartile_median_ms=[statistics.median(z['seconds']for z in rows[i:i+16])*1000 for i in range(0,64,16)])
  if arm['arm']=='N':
   assert all(z['logits_sha256']=='c6cc487735173af3198566071fbc3a2016f3e970a1f576523f046386cea94d22'for z in r['runs'])
   assert all(z['records_fetched']+z['records_adopted']==(393 if c.startswith('partial')else 0)for z in rows)
   stats['forecasted_records_mean']=statistics.mean(z['gpu_forecast_records']for z in rows)
   stats['issued_records_mean']=statistics.mean(z.get('prefetch',{}).get('issued',0)for z in rows)
   stats['wasted_bytes_mean']=statistics.mean(z.get('prefetch',{}).get('wastedBytes',0)for z in rows)
  else:assert all(z['max_logit_difference']==0 for z in r['runs'])
  conditions[c]=stats
 report.append(dict(label=label,arm=arm['arm'],eligible=arm['eligible'],conditions=conditions))
summary=dict(whole_protocol_eligible=x['whole_protocol_eligible'],scope='Fixed condition order is a confound: cached_off, partial_off, cached_on, partial_on. Temperature association cannot establish or rule out governor behavior. No production change.',arms=report)
if len(report)==4:
 summary['medians_by_engine']={engine:{c:dict(pass_ms=statistics.median(a['conditions'][c]['median_seconds']for a in report if a['arm']==engine)*1000,mhz=statistics.median(a['conditions'][c]['frequency']['gpu_freq_mhz']for a in report if a['arm']==engine))for c in report[0]['conditions']}for engine in ['N','S']}
(P/'frequency-cache-details.json').write_text(json.dumps(summary,indent=2));print(json.dumps({k:v for k,v in summary.items()if k!='arms'},indent=2))
