from pathlib import Path
import argparse,bisect,collections,csv,datetime,json,statistics
P=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--label',default='frequency-untraced');a=ap.parse_args()
def union(xs):
 out=[]
 for lo,hi in sorted(xs):
  if hi<=lo:continue
  if not out or lo>out[-1][1]:out.append([lo,hi])
  else:out[-1][1]=max(hi,out[-1][1])
 return out
def length(xs):return sum(b-a for a,b in xs)
def intersection(a,b):
 out=[];i=j=0
 while i<len(a) and j<len(b):
  lo,hi=max(a[i][0],b[j][0]),min(a[i][1],b[j][1])
  if hi>lo:out.append([lo,hi])
  if a[i][1]<b[j][1]:i+=1
  else:j+=1
 return out
def csvrows(path):
 with path.open()as f:
  for x in csv.DictReader(line for line in f if not line.startswith('#')):yield x
 with path.open('rb')as f:
  f.seek(max(0,path.stat().st_size-1024));tail=f.read().decode().splitlines()[-1]
 foot=dict(x.split('=')for x in tail[2:].split());assert int(foot['total'])<int(foot['cap'])
 if 'gpu_initial'in foot:assert foot['gpu_initial']==foot['cpu_initial'] and foot['gpu_final']==foot['cpu_final']
def limits(r):return (r['start_ns']/1e9,r['end_ns']/1e9)if'start_ns'in r else(r['start'],r['end'])
ledger=json.loads((P/(a.label+'-ledger.json')).read_text());report=[]
reference={(r['round'],r['step']):r['logits_sha256']for r in json.loads((P/'commit-relaxed-0-B.json').read_text())['runs']}
for event in ledger:
 label,arm=event['label'],event['arm'];data=json.loads((P/(label+'.json')).read_text());steps=[r for r in data['runs']if r['round']==1]
 if arm=='N':assert all(r['logits_sha256']==reference[(r['round'],r['step'])]for r in data['runs'])
 windows=[limits(r)for r in steps];lo,hi=windows[0][0],windows[-1][1]
 guard=event['guard'];offsets=[x['unix']-x['mach_ns']/1e9 for x in guard['samples']];offset=statistics.median(offsets)
 raw=[json.loads(line)for line in(P/(label+'-frequency.jsonl')).read_text().splitlines()]
 ticks=[datetime.datetime.fromisoformat(x['timestamp']).timestamp()-offset for x in raw]
 delta=statistics.median(b-a for a,b in zip(ticks,ticks[1:]));assert .15<delta<.5,(label,delta)
 samples=[(ticks[i-1] if i else t-delta,t,x)for i,(t,x) in enumerate(zip(ticks,raw))]
 def frequency(intervals,shift=0):
  weighted=collections.defaultdict(float);covered=0;count=0
  for b,e,x in samples:
   overlap=length(intersection(intervals,[(b+shift,e+shift)]))
   if not overlap:continue
   covered+=overlap;count+=1
   for key in ['gpu_freq_mhz','gpu_active_ratio','gpu_scaled_ratio','gpu_power','gpu_ram_power']:
    weighted[key]+=overlap*x[key]
  if not shift:assert abs(covered-length(intervals))<.01,(label,covered,length(intervals))
  return dict(covered_seconds=covered,coverage_ratio=covered/length(intervals),samples=count,**{k:v/covered for k,v in weighted.items()} if covered else {},frequency_time_million_cycles=weighted['gpu_freq_mhz'])
 def measure(intervals):
  return dict(verify_seconds=length(intervals),frequency=frequency(intervals),frequency_shift_sensitivity={str(s):frequency(intervals,s)for s in [-delta,delta]})
 result=dict(label=label,arm=arm,eligible=event['eligible'],native_full_hashes_exact=arm=='N',scope='No injected read or GPU observer. Whole-device frequency association only; 200 ms sampling cannot resolve individual kernels. Partial-miss verification only, not complete requests.',clock_offset_seconds=offset,clock_offset_range_seconds=max(offsets)-min(offsets),sample_interval_seconds=delta,summary=measure(windows),records_fetched=sum(r['records_fetched']for r in steps),records_adopted=sum(r['records_adopted']for r in steps),by_width={str(w):measure([limits(r)for r in steps if r['width']==w])for w in sorted({r['width']for r in steps})},passes=[dict(step=r['step'],width=r['width'],**measure([limits(r)]))for r in steps])
 report.append(result);print(json.dumps({k:v for k,v in result.items()if k not in ['by_width','passes']},indent=2))
(P/(a.label+'-analysis.json')).write_text(json.dumps(dict(whole_protocol_eligible=len(report)==4 and all(x['eligible']for x in report),arms=report),indent=2))
