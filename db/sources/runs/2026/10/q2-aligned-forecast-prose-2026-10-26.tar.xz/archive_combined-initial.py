from pathlib import Path
import fcntl,hashlib,io,json,os,re,sys,tarfile
P=Path(__file__).resolve().parent;R=P.parents[1];F=P.parent/'q2-full-cycle-20261025'
assert len(json.loads((P/'analysis.json').read_text())['arms'])==6
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
reservation=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(reservation,fcntl.LOCK_EX|fcntl.LOCK_NB);os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(P/'archive-child.lock');preflight(4)
sha=lambda b:hashlib.sha256(b).hexdigest();allowed={'.py','.cpp','.hpp','.json','.jsonl','.csv','.log','.stderr','.txt','.swift','.h','.patch'}
secret=re.compile(rb'(?:ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{25,}|sk-(?:proj-)?[A-Za-z0-9_-]{30,}|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----)');files={}
for f in P.rglob('*'):
 if not f.is_file()or '__pycache__'in f.parts or f.suffix not in allowed or f.name.startswith('archive-receipt')or(f.name.startswith('archive')and f.suffix=='.log'):continue
 files[str(f.relative_to(P))]=f
for name,path in [('Slotstream-LICENSE',R/'LICENSE'),('MLX-LICENSE',R/'.build/checkouts/mlx-swift/LICENSE'),('THIRD_PARTY_NOTICES.md',R/'THIRD_PARTY_NOTICES.md'),('splash-NOTICE.txt',R/'Licenses/splash-NOTICE.txt'),('validation-0-N.json',F/'validation-0-N.json'),('validation-s-0-S.json',F/'validation-s-0-S.json'),('native-identity.json',F/'native-build/candidate/build-identity.json'),('Splash-identity.json',F/'upstream/identity.json'),('v68-identity.json',R/'.build/native-replay-20261023/v68/build-identity.json')]:files['reference/'+name]=path
# Include the candidate build and the stopped wrong-fixture attempt as evidence.
for f in C.rglob('*'):
 if not f.is_file()or '__pycache__'in f.parts or f.suffix not in allowed or f.name.startswith('archive-receipt')or(f.name.startswith('archive')and f.suffix=='.log'):continue
 files['candidate-build-and-stopped-code/'+str(f.relative_to(C))]=f
files['reference/ordinary-request-analysis.json']=Q/'analysis.json'
files['reference/fast-scope-clarification.json']=Q/'fast-scope-clarification.json'
manifest={}
for n,f in files.items():
 b=f.read_bytes();assert not secret.search(b),n;manifest[n]=dict(bytes=len(b),sha256=sha(b))
dest=R/'db/sources/runs/2026/10/q2-aligned-forecast-prose-2026-10-26.tar.xz';assert not dest.exists();raw=json.dumps(manifest,indent=2).encode()
with tarfile.open(dest,'w:xz',preset=3)as t:
 for n,f in sorted(files.items()):t.add(f,arcname=n,recursive=False)
 info=tarfile.TarInfo('archive-manifest.json');info.size=len(raw);t.addfile(info,io.BytesIO(raw))
seen={}
with tarfile.open(dest,'r|xz')as t:
 for m in t:
  b=t.extractfile(m).read()
  if m.name=='archive-manifest.json':assert json.loads(b)==manifest
  else:seen[m.name]=dict(bytes=len(b),sha256=sha(b))
assert seen==manifest and dest.stat().st_size<100_000_000
receipt=dict(path=str(dest.relative_to(R)),files=len(manifest),bytes=dest.stat().st_size,sha256=sha(dest.read_bytes()),readback_verified=True,credential_pattern_matches=0,excluded='Executables, libraries, model weights, pycache and active archive output. All validation/timing arms, sources, guards, candidate rejection and reference identities retained.')
(P/'archive-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt,indent=2),flush=True)
