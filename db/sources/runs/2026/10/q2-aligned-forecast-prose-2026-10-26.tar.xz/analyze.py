from pathlib import Path
import json,statistics
P=Path(__file__).resolve().parent
v=json.loads((P/'validation-result.json').read_text());assert v['passed']
events=json.loads((P/'timing-ledger.json').read_text());assert [e['arm']for e in events]==list('ABSSBA')
rows=[]
for e in events:
 g=json.loads((P/(e['label']+'.observer.json')).read_text())
 row=dict(label=e['label'],arm=e['arm'],eligible=e['eligible'],warmup=e['rounds'][0],measured=e['rounds'][1:],peak_gb=g['peak_combined_bytes']/1e9,minimum_headroom_gb=min(s['reclaimable']for s in g['samples'])/1e9,swapins=g['after']['swapins']-g['before']['swapins'],swapouts=g['after']['swapouts']-g['before']['swapouts'])
 assert len(row['measured'])==2 and row['minimum_headroom_gb']>=1
 row['mean_seconds']=statistics.mean(r['seconds']for r in row['measured']);rows.append(row)
t=[r['mean_seconds']for r in rows];ab=[t[1]/t[0],t[4]/t[5]];bs=[t[1]/t[2],t[4]/t[3]];am,bm,sm=[statistics.mean([t[i],t[j]])for i,j in [(0,5),(1,4),(2,3)]]
eligible=all(e['eligible']for e in rows)
out=dict(environment_eligible=eligible,arms=rows,mean_seconds=dict(baseline=am,candidate=bm,splash=sm),candidate_over_baseline_directions=ab,candidate_over_baseline_pooled=bm/am,candidate_over_splash_directions=bs,candidate_over_splash_pooled=bm/sm,fixed_work_gain_supported=eligible and all(r<1 for r in ab)and bm/am<=.98,fixed_work_within_five_percent=eligible and all(r<=1.05 for r in bs),ordinary_request_retention=False,scope='Frozen full cycles including real draft/sampling/commit, identical requested target inputs/widths/retained prefixes. All arms and rounds retained. Own-engine output equality; cross-engine state and routes differ. Does not reverse failed normal-adaptive request retention or prior target-only component exclusion.')
(P/'analysis.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
