import json,subprocess,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];binary=str(P/'v21/slotstream');label='v21-q2-profile';out=P/(label+'.json')
env=['--env', 'SLOTSTREAM_NATIVE_EXPERT_SCHEDULE=1','--env','SLOTSTREAM_NATIVE_PROJECTION_SCHEDULE=1','--env','SLOTSTREAM_ADAPTIVE_REPLACEMENT=1','--env','SLOTSTREAM_NATIVE_GPU_STAGING=1','--env','SLOTSTREAM_NATIVE_FORECAST_ARENA=1','--env','SLOTSTREAM_DFLASH_PERSISTENT_CALIBRATION=1','--env','SLOTSTREAM_DFLASH_BONUS_CALIBRATION=1']
cmd=[sys.executable,str(P/'guarded_run_io.py'),'--label',label,'--budget','9',*env,'--',binary,'smart-dflash-check','--native-read-ahead','on','--method','q2','--model','smart-q2','--memory-gb','9','--max-context','8192','--cases',str(P/'v21-profile-cases.json'),'--output',str(out)]
sampled=False;scope=dict(purpose='Diagnostic CPU stack locations during warmed prose decoding. Instrumented time is excluded from all speed claims; CPU samples do not establish GPU idle time.',command=cmd)
with (P/(label+'-driver.log')).open('x')as log:
 child=subprocess.Popen(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT)
 while child.poll()is None:
  if not sampled and out.exists():
   d=json.loads(out.read_text())
   if len(d.get('runs',[]))>=2:
    time.sleep(5)
    rows=subprocess.check_output(['ps','-axo','pid=,comm='],text=True).splitlines()
    matches=[int(r.strip().split(None,1)[0])for r in rows if r.strip().split(None,1)[-1]==binary]
    if len(matches)==1:
     with (P/(label+'-sample-driver.log')).open('x')as capture:
      result=subprocess.run(['sample',str(matches[0]),'5','1','-file',str(P/(label+'.sample.txt'))],stdout=capture,stderr=subprocess.STDOUT)
     sampled=True;scope.update(sample_exit=result.returncode,pid=matches[0])
  time.sleep(1)
 scope.update(exit_code=child.returncode,sampled=sampled);(P/(label+'-scope.json')).write_text(json.dumps(scope,indent=2)+'\n')
raise SystemExit(child.returncode or int(not sampled))
