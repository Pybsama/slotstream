import json,subprocess,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1]
binary=str(P/'v19/slotstream');sampled=False
with (P/'v19-native-quality-driver.log').open('x')as log:
 child=subprocess.Popen([sys.executable,str(P/'v19_native_quality.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 while child.poll() is None:
  f=P/'v19-native-quality-smart-q2.json'
  if not sampled and f.exists():
   try:d=json.loads(f.read_text())
   except ValueError:d={}
   if len(d.get('runs',[]))>=2:
    processes=subprocess.check_output(['ps','-axo','pid=,comm='],text=True).splitlines()
    matches=[int(row.strip().split(None,1)[0])for row in processes if row.strip().split(None,1)[-1]==binary]
    if len(matches)==1:
     with (P/'v19-q2-profile-driver.log').open('x')as profilelog:r=subprocess.run(['sample',str(matches[0]),'5','1','-file',str(P/'v19-q2-cpu.sample.txt')],stdout=profilelog,stderr=subprocess.STDOUT)
     sampled=True
     (P/'v19-q2-profile-scope.json').write_text(json.dumps({'purpose':'Diagnostic CPU wait and active-stack locations during the functional quality suite; all performance numbers in that run are unqualified','pid':matches[0],'sample_exit':r.returncode,'seconds':5,'binary':binary},indent=2)+'\n')
  time.sleep(1)
 print('QUALITY EXIT',child.returncode,'PROFILED',sampled,flush=True)
 raise SystemExit(child.returncode)
