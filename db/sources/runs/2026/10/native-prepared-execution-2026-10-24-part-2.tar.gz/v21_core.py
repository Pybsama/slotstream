import json,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];B=P/'v21/slotstream';events=[]
env=['--env', 'SLOTSTREAM_NATIVE_EXPERT_SCHEDULE=1','--env','SLOTSTREAM_NATIVE_PROJECTION_SCHEDULE=1','--env','SLOTSTREAM_ADAPTIVE_REPLACEMENT=1','--env','SLOTSTREAM_NATIVE_GPU_STAGING=1','--env','SLOTSTREAM_NATIVE_FORECAST_ARENA=1','--env','SLOTSTREAM_DFLASH_PERSISTENT_CALIBRATION=1','--env','SLOTSTREAM_DFLASH_BONUS_CALIBRATION=1']
def run(label,cmd):
 print('START',label,flush=True)
 with (P/(label+'-driver.log')).open('x')as log:r=subprocess.run(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT)
 events.append(dict(label=label,command=cmd,exit_code=r.returncode));(P/'v21-core-ledger.json').write_text(json.dumps(events,indent=2)+'\n')
 print('END',label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
run('v21-freeze',[sys.executable,str(P/'freeze.py'),'v21'])
for kind,fixture in [('old','bench/q2/verify-budget.json'),('complete','bench/q2/verify-budget-complete.json')]:
 label='v21-policy-'+kind
 run(label,[sys.executable,str(P/'guarded_run.py'),'--label',label,'--budget','3',*env,'--',str(B),'q2-format-check','--fixtures','bench/q2/formats.json','--policy-fixtures',fixture,'--mix-fixtures','bench/q2/mix-quantization.json'])
for model,method in [('fast','fast'),('smart-q2','q2')]:
 label='v21-calibration-'+model;out=P/(label+'.json')
 run(label,[sys.executable,str(P/'guarded_run.py'),'--label',label,'--budget','9',*env,'--',str(B),'smart-dflash-check','--native-read-ahead','on'if method=='q2'else'off','--method',method,'--model',model,'--memory-gb','9','--max-context','8192','--cases',str(P/'v21-calibration-cases.json'),'--output',str(out)])
 d=json.loads(out.read_text());rows=d['runs'];assert d['complete']and len(rows)==3
 s=[r['stats']for r in rows];assert all(not x.get('runtimeError')and not x['memoryPressureCancelled']and x['peakMemoryGB']<=9 for x in s)
 assert s[0]['dflashCalibrationCyclesBefore']==0 and s[0]['dflashCalibrationCyclesAfter']>0
 assert s[1]['dflashCalibrationCyclesBefore']==s[0]['dflashCalibrationCyclesAfter']
 assert s[2]['dflashCalibrationCyclesBefore']==0 and sum(x.get('dflashBonusObservations',0)for x in s)>0
 assert all(x['nativeExecution']['projectionFailures']==0 for x in s)
 (P/(label+'-audit.json')).write_text(json.dumps(dict(passed=True,cycles=[dict(before=x['dflashCalibrationCyclesBefore'],after=x['dflashCalibrationCyclesAfter'],bonus=x.get('dflashBonusObservations',0))for x in s]),indent=2)+'\n')
