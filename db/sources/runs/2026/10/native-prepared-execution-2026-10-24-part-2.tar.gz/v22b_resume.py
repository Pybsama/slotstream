import json,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];events=[]
for label,script in [('v22b-capacity','v22b_capacity.py'),('v22-app','app_default_qualification.py')]:
 print('START',label,flush=True)
 with(P/(label+'-driver.log')).open('x')as log:r=subprocess.run([sys.executable,str(P/script)],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 events.append(dict(label=label,script=script,exit_code=r.returncode));(P/'v22b-resume-ledger.json').write_text(json.dumps(events,indent=2)+'\n')
 print('END',label,r.returncode,flush=True)
 if r.returncode and label!='v22-app':raise SystemExit(r.returncode)
