# Supersedes the unexecuted v21 extended plan after its calibration ablation.
# Keep v21b_extended_compare.original.py as evidence of the earlier plan.
import subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent
raise SystemExit(subprocess.run([sys.executable,str(P/'v22_qualification.py')]).returncode)
