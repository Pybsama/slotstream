import json,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];events=[]
def run(label,cmd):
 print('START',label,flush=True)
 with (P/(label+'-driver.log')).open('x')as log:r=subprocess.run(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT)
 events.append(dict(label=label,command=cmd,exit_code=r.returncode));(P/'v21-pipeline-ledger.json').write_text(json.dumps(events,indent=2)+'\n')
 print('END',label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
for label,script in [('v20b-native-quality','v20b_native_quality.py'),('v21-build','v21_build.py'),('v21-core','v21_core.py')]:run(label,[sys.executable,str(P/script)])
for model in ['fast','smart-q2']:
 label='v21-'+model+'9-splash'
 run(label,[sys.executable,str(P/'native_splash_compare_v21.py'),'--label',label,'--native',str(P/'v21/slotstream'),'--model',model,'--budget','9'])
 run(label+'-summary',[sys.executable,str(P/'comparison_summary.py'),label])
run('v21-native-quality',[sys.executable,str(P/'v21_native_quality.py')])
