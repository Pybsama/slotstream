import json,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1]
assert len(json.loads((P/'v21-calibration-ablation-q29-ledger.json').read_text()))==4
for name in ['v21b_compare.py','v21b_extended_compare.py']:
 print('START',name,flush=True)
 result=subprocess.run([sys.executable,str(P/name)],cwd=R)
 print('END',name,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
