# Remaining source differences inspected during v22 qualification

These are hypotheses, not measured causes or adoption decisions.

- Splash Qwen4ExpTarget encodes the entire verification graph and uses host-load callbacks within it. Native MLX builds a graph up to route readback on each layer, then submits a prepared expert section before reading demand bytes. The CPU profile locates the route-completion dependency; it does not isolate GPU idle time.
- Splash MoE groups its shared expert alongside routed experts in one gate/up and down launch, including mixed weight formats. Native uses the qualified register/shared program independently before the demand-ready event, then grouped routed experts. Combining these would change shared-expert arithmetic from register to staged and needs independent original-weight and full-quality evidence.
- Splash register projections use coherent device partials, a last-arriving workgroup counter, ordered split summation and in-kernel epilogues. Native programs keep invocation-owned partials and explicit reductions. v22 fuses adjacent reduction/activation steps but does not reuse a mutable cross-command partial/counter workspace. Do not introduce atomic scratch reuse without proving initial state, same-stream hazards, failure and cancellation ownership.
- Native still scatters grouped expert outputs before ordered MoE combination. Fusing those two removes a dispatch and transient copy while preserving rank order; it is smaller in scope than a whole-route callback port. Not implemented yet.
- Full-route host callbacks would move cache mutation off the generation thread. They must serialize cache state, publish route completion before waiting for the CPU, keep demand pins through GPU readers, propagate failure/cancellation, and avoid MLX allocator/evaluation deadlocks. No implementation exists in this study.

A previous simple extra forecast submission is not useful: forecast indices and weights are already submitted alongside current routing. No spin or power-state work is proposed.

## Further bounded candidates, not implemented

Q2Checkpoint.residents currently installs outputOrder on GDN QKV and Z projections. Every forward therefore takes output rows again. Permuting the original compressed tensor rows once at loading would preserve each original row's bytes, its K reduction and output rounding, while eliminating repeated row copies. GDN out_proj has a column permutation; do not treat that as a row permutation or cut through quantization blocks. Qualify actual checkpoint formats and target goldens before adoption.

GDNLayer calls QKV and Z as separate wide staged GGUF projections. Splash stores them as segments of its input projection. A prepared staged-pair program could dispatch both matrices together while retaining each one's own split count and rounding, then combine reductions only when needed. All 36 actual Q2 GDN layer pairs, each format, and 1/2/3/8 rows need exact independent checks. Do not accidentally call the existing register-only pair on wide staged matrices. Full-model plan capacity and physical memory must pass again; the present 488-plan maximum is already close to the finite 512 ceiling.

A suspected prepacked-disk advantage was disproved by source inspection: Splash ExpertStore also reads native GGUF records into staging and GPU-repacks them into its expert arenas. Creating a duplicate SSD artifact would not reproduce a missing upstream mechanism. No such artifact is proposed.

The guard receipt's historical fused_gdn boolean describes the generic environment override. Q2/Fast already enter Q2GatedDelta in GDNLayer before that generic branch, so false is not proof that these models lack fused recurrence. Read actual code/path evidence, not that diagnostic in isolation.
