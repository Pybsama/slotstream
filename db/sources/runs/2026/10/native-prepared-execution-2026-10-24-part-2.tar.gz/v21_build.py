import json,subprocess,sys,time,hashlib
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];U=Path('/tmp/slotstream-splash-review.EJTswU/splash')
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
assert len(json.loads((P/'v20-smart-q29-splash-ledger.json').read_text()))==4
for model in ['fast','smart-q2']:
 assert json.loads((P/('v20b-native-quality-'+model+'-functional.json')).read_text())['passed']
receipt={'preflight':preflight(12),'commands':[]}
cmd=['clang++','-std=c++20','-O2','-I'+str(U/'runtime'),str(P/'verify-budget-complete-oracle.cpp'),str(U/'runtime/model/VerifyBudget.cpp'),'-o',str(P/'verify-budget-complete-oracle')]
start=time.monotonic()
with (P/'v21-policy-reference-build.log').open('x') as log:result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
receipt['commands'].append(dict(command=cmd,exit_code=result.returncode));assert result.returncode==0
fixture=R/'bench/q2/verify-budget-complete.json';assert not fixture.exists()
with fixture.open('x')as output:subprocess.run([str(P/'verify-budget-complete-oracle')],stdout=output,check=True)
rows=json.loads(fixture.read_text());assert len(rows)==2048 and any(x['depth']==0 for x in rows) and max(x['expectedLabels']for x in rows)==4096
receipt['fixture']={'path':str(fixture.relative_to(R)),'sha256':hashlib.sha256(fixture.read_bytes()).hexdigest(),'rows':len(rows)}
receipt['upstream_sources']={str(f.relative_to(U)):hashlib.sha256(f.read_bytes()).hexdigest()for f in [U/'runtime/model/VerifyBudget.cpp',U/'runtime/model/VerifyBudget.hpp',U/'runtime/metal/abi/ExecutionGeometry.h']}
cmd=['make','build','SLOTSTREAM_BUILD_JOBS=4']
with (P/'v21-build.log').open('x') as log:result=subprocess.run(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT)
receipt['commands'].append(dict(command=cmd,exit_code=result.returncode));receipt.update(exit_code=result.returncode,seconds=time.monotonic()-start)
(P/'v21-build-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
raise SystemExit(result.returncode)
