import json,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];B=P/'v22/slotstream';events=[]
for model,method,budget,cases in [('smart-q2','q2',8.9,'v22-floor-cases.json'),('smart-q2','q2',10,'v22-long-prefix-cases.json'),('smart','plain',8.1,'v22-floor-cases.json')]:
 label='v22b-capacity-'+model+'-'+str(budget);out=P/(label+'.json')
 cmd=[sys.executable,str(P/'guarded_run.py'),'--label',label,'--budget',str(budget),'--',str(B),'smart-dflash-check','--method',method,'--model',model,'--memory-gb',str(budget),'--max-context','8192','--cases',str(P/cases),'--output',str(out)]
 if method=='q2':cmd+=['--native-read-ahead','on']
 print('START',label,flush=True)
 with(P/(label+'-driver.log')).open('x')as log:result=subprocess.run(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT)
 audit=dict(label=label,exit_code=result.returncode,passed=False)
 if result.returncode==0:
  d=json.loads(out.read_text());rows=d['runs'];by_id={r['id']:r for r in rows}
  checks=dict(complete=d['complete'],bounded=all(r['stats']['peakMemoryGB']<=budget and not r['stats'].get('runtimeError')and not r['stats']['memoryPressureCancelled']for r in rows),stream=all(r['streamed']==r['text']for r in rows))
  if method in ['fast','q2']:
   checks.update(schedule=any(r['native_expert_scheduled_passes']>0 for r in rows),zero_fallback=all(r['native_projection_schedule_failures']==0 and r['stats']['nativeExecution']['projectionFailures']==0 for r in rows))
  if cases=='v22-floor-cases.json':
   checks.update(cancellation=by_id['cancel']['callbacks']==12,recovery=json.loads(by_id['after-cancel']['text'])=={'ok':True},stop=by_id['stop-string']['text'].strip()=='one two three')
   tools=by_id['native-tool']['tool_calls'];checks['tool']=len(tools)==1 and tools[0]['name']=='lookup_record' and json.loads(tools[0]['arguments_json'])=={'key':'CEDAR-2481'}
  else:
   checks.update(retrieval=all(json.loads(r['text'])=={'audit_code':'PINE-3926'}for r in rows),retention=by_id['long-retrieval-repeat']['stats']['reusedPrefixTokens']>0)
  audit.update(checks=checks,passed=all(checks.values()),peak=max(r['stats']['peakMemoryGB']for r in rows))
 events.append(audit);(P/'v22b-capacity-ledger.json').write_text(json.dumps(events,indent=2)+'\n');print('END',json.dumps(audit),flush=True)
 if not audit['passed']:raise SystemExit(1)
