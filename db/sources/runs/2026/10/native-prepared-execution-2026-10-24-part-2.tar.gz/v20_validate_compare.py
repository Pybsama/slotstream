import json,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1]
assert json.loads((P/'v20-build-receipt.json').read_text())['exit_code']==0
commands=[('v20-core',[sys.executable,str(P/'v20_core.py')]),('v20-smart-q29-splash',[sys.executable,str(P/'native_splash_compare_v20.py'),'--label','v20-smart-q29-splash','--native',str(P/'v20/slotstream'),'--model','smart-q2','--budget','9']),('v20-native-quality',[sys.executable,str(P/'v20_native_quality.py')])]
for label,command in commands:
 print('START',label,flush=True)
 with (P/(label+'-driver.log')).open('x')as log:r=subprocess.run(command,cwd=R,stdout=log,stderr=subprocess.STDOUT)
 print('END',label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
 if label=='v20-smart-q29-splash':subprocess.run([sys.executable,str(P/'comparison_summary.py'),label],cwd=R,check=True)
