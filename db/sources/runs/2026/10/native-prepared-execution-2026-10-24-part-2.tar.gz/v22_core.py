import json,subprocess,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];B=P/'v22/slotstream';rows=[]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
preflight(12)
def run(label,cmd):
 print('START',label,flush=True)
 start=time.monotonic()
 with(P/(label+'-driver.log')).open('x')as log:r=subprocess.run(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT)
 rows.append(dict(label=label,command=cmd,exit_code=r.returncode,seconds=time.monotonic()-start));(P/'v22-core-ledger.json').write_text(json.dumps(rows,indent=2)+'\n')
 print('END',label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
run('v22-build',['make','build','SLOTSTREAM_BUILD_JOBS=4'])
run('v22-freeze',[sys.executable,str(P/'freeze.py'),'v22'])
for model in ['smart-q2','fast']:
 label='v22-pool-'+model
 run(label,[sys.executable,str(P/'guarded_run.py'),'--label',label,'--budget','3','--timeout','300','--',str(B),'q2-experts-check','--pool-model',model])
run('v22-formats',[sys.executable,str(P/'guarded_run.py'),'--label','v22-formats','--budget','3','--timeout','240','--',str(B),'q2-format-check','--fixtures','bench/q2/formats.json','--policy-fixtures','bench/q2/verify-budget.json','--policy-fixtures','bench/q2/verify-budget-complete.json','--mix-fixtures','bench/q2/mix-quantization.json'])
run('v22-catalogue',[sys.executable,str(P/'guarded_run.py'),'--label','v22-catalogue','--budget','4','--timeout','300','--',str(P/'v22/slotstream-checks'),'--tier','t0','--tier','t1'])
run('v22-plain',[sys.executable,str(P/'v22_plain.py')])
run('v22-quality',[sys.executable,str(P/'v22_native_quality.py')])
