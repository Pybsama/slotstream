import json,pathlib,subprocess,time,sys,os
P=pathlib.Path(__file__).resolve().parent;R=P.parents[1]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight,terminate_child_tree
preflight(19)
protocol=dict(scope='Diagnostic CPU stack sample during the third Q2 request, after two warmups. Instrumentation invalidates speed claims; this is not another benchmark.',binary='v7/slotstream',budget_gb=15,cases='short-warm-cases.json',sample_seconds=10,sample_interval_ms=1)
(P/'host-profile-protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
label='host-profile-q2';out=P/(label+'.json');assert not out.exists()
cmd=[sys.executable,str(P/'guarded_run.py'),'--label',label,'--budget','15','--',str(P/'v7/slotstream'),'smart-dflash-check','--method','q2','--model','smart-q2','--memory-gb','15','--max-context','8192','--cases',str(P/'short-warm-cases.json'),'--output',str(out)]
record={'command':cmd,'sampled':False};start=time.monotonic()
with (P/(label+'-driver.log')).open('x')as log:
 proc=subprocess.Popen(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:
  while proc.poll()is None:
   if time.monotonic()-start>1200:raise RuntimeError('Diagnostic deadline')
   if not record['sampled']and out.exists():
    d=json.loads(out.read_text())
    if len(d['runs'])>=2:
     pids=subprocess.check_output(['pgrep','-P',str(proc.pid)],text=True).split();assert len(pids)==1
     sample=['sample',pids[0],'10','1','-file',str(P/'host-profile-q2-stacks.txt')]
     record['sample_command']=sample
     result=subprocess.run(sample,stdout=log,stderr=subprocess.STDOUT,timeout=30)
     record['sample_exit']=result.returncode;record['sampled']=True
   time.sleep(.25)
  record['exit_code']=proc.returncode
 finally:
  if proc.poll()is None:terminate_child_tree(proc)
  record['seconds']=time.monotonic()-start;(P/'host-profile-receipt.json').write_text(json.dumps(record,indent=2)+'\n')
print(record)
raise SystemExit(record.get('exit_code',1))
