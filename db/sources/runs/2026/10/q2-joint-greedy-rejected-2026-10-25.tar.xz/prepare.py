from pathlib import Path
import json,shutil,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1];O=P.parent/'q2-request-profile-20261025';D=P.parent/'q2-embedding-dedup-20261025'
s=(R/'Sources/Slotstream/Generate.swift').read_text();needle='''    public mutating func next(
        _ logits: MLXArray, params: SampleParams, generated: Set<Int>
    ) -> Int {''';assert s.count(needle)==1
s=s.replace(needle,'''    /// Independent greedy rows can share one device evaluation. History-based
    /// penalties and random draws must retain the sequential sampler.
    package static func greedyRows(_ logits: MLXArray, params: SampleParams) -> [Int]? {
        guard params.temperature <= 0, params.presencePenalty == 0,
              logits.ndim == 3, logits.dim(0) == 1,
              (1...8).contains(logits.dim(1)), logits.dim(2) > 0 else { return nil }
        return argMax(logits.asType(.float32), axis: -1).asArray(UInt32.self).map(Int.init)
    }

'''+needle);(P/'Generate-candidate.swift').write_text(s)
s=(R/'Sources/Slotstream/DFlashGenerate.swift').read_text();needle='''            let result = try model.allLogitsWithMultiChecked(input, state: state)
            eval(result.logits)''';assert s.count(needle)==1
s=s.replace(needle,'''            let result = try model.allLogitsWithMultiChecked(input, state: state)
            // Only Q2's independent greedy decisions take this path. Evaluating
            // their IDs also completes the target logits, without a separate
            // host wait for the head and each accepted token. Verification time
            // includes the joint greedy reduction when it shares that evaluation.
            let greedy = model.pool.expertStore.isQ2 ? Sampler.greedyRows(result.logits, params: params) : nil
            if greedy == nil { eval(result.logits) }''')
needle='''                let sampled = sample(result.logits[0..., position..<(position + 1), 0...], params: params, generated: generated)''';assert s.count(needle)==1
s=s.replace(needle,'''                let sampled = greedy?[position] ?? sample(result.logits[0..., position..<(position + 1), 0...], params: params, generated: generated)''');(P/'DFlashGenerate-candidate.swift').write_text(s)
s=(R/'Sources/slotstream-cli/Q2ExpertsCheck.swift').read_text();s=s.replace('''    func run() throws {
        if pieceOnly {''','''    @Flag(help: "Check batched greedy choices against the sequential sampler")
    var greedyOnly = false
    func run() throws {
        if greedyOnly {
            guard !draftOnly, !sharedOnly, !pieceOnly, poolModel == nil else { throw ValidationError("Greedy checks do not load expert pools") }
            try ModelProcessGuard.acquire()
            MLX.Memory.cacheLimit = 128 << 20
            var checked = 0
            for width in [32, 257, 1025, 248320] {
                for count in [1, 2, 3, 7, 8] {
                    for mode in 0..<5 {
                        try autoreleasepool {
                            var values = [Float](repeating: 0, count: count * width)
                            for row in 0..<count {
                                for column in 0..<width {
                                    values[row * width + column] = Float((column * 71 + row * 29) % 997 - 498) / 128
                                }
                                if mode == 1 { values[row * width + row % width] = 100; values[(row + 1) * width - 1] = 100 }
                                if mode == 2 { for column in 0..<width { values[row * width + column] = -Float.infinity } }
                                if mode == 3 { values[row * width + row % width] = Float.infinity; values[(row + 1) * width - 1] = Float.infinity }
                                if mode == 4 { values[row * width + row % width] = Float.nan }
                            }
                            let original = MLXArray(values, [1, count, width])
                            for dtype in [DType.float32, .bfloat16] {
                                let logits = original.asType(dtype)
                                var sampler = Sampler(seed: 17)
                                let before = sampler.rngState
                                let expected = (0..<count).map { sampler.next(logits[0..., $0..<($0 + 1), 0...], params: .greedy, generated: []) }
                                guard let actual = Sampler.greedyRows(logits, params: .greedy), actual == expected,
                                      sampler.rngState == before else { throw ValidationError("Batched greedy changed row, tie, nonfinite or RNG behavior: \\(width)/\\(count)/\\(mode)/\\(dtype)") }
                                checked += 1
                            }
                        }
                    }
                }
            }
            let logits = MLXArray([Float(0), 1, 2, 3], [1, 2, 2])
            for penalty: Float in [-1, 1] {
                var p = SampleParams.greedy; p.presencePenalty = penalty
                guard Sampler.greedyRows(logits, params: p) == nil else { throw ValidationError("History-dependent sampling entered batch path") }
            }
            var random = SampleParams.greedy; random.temperature = 0.7
            guard Sampler.greedyRows(logits, params: random) == nil,
                  Sampler.greedyRows(logits.reshaped([2, 1, 2]), params: .greedy) == nil,
                  Sampler.greedyRows(MLXArray.zeros([1, 9, 2]), params: .greedy) == nil else { throw ValidationError("Unsupported batch admitted") }
            print("Batched greedy: \\(checked) sequential-sampler equality cases; ties/nonfinite/BF16/FP32/RNG, penalties/random/geometry fallback PASS")
            return
        }
        if pieceOnly {''');(P/'Q2ExpertsCheck-candidate.swift').write_text(s)
for n in ['quiet_guarded_run.py','q2_upstream_bench_io.py','cases.json','check_restoration.py','SmartDFlashCommand-request-clock.swift']:shutil.copy2(O/n,P/n)
s=(D/'run.py').read_text().replace('per-lookup duplicate embedding read elimination','Q2 joint batched greedy verification decisions');(P/'run.py').write_text(s)
s=(D/'build.py').read_text();b=s.index('replacements=');e=s.index('\noriginals=',b);s=s[:b]+"replacements={'Sources/Slotstream/Generate.swift':'Generate-candidate.swift','Sources/Slotstream/DFlashGenerate.swift':'DFlashGenerate-candidate.swift','Sources/slotstream-cli/Q2ExpertsCheck.swift':'Q2ExpertsCheck-candidate.swift','Sources/slotstream-cli/SmartDFlashCommand.swift':'SmartDFlashCommand-request-clock.swift'}"+s[e:];(P/'build.py').write_text(s)
s=(D/'analyze.py').read_text().replace('ordinary-dedup-15','ordinary-greedy-15').replace('per-lookup duplicate Q2 token reads eliminated','joint Q2 greedy decisions');(P/'analyze.py').write_text(s)
s=(D/'analyze_work.py').read_text().replace('ordinary-dedup-15','ordinary-greedy-15');(P/'analyze_work.py').write_text(s)
(P/'plan.json').write_text(json.dumps(dict(scope='Only Q2 DFlash verification with greedy temperature and zero presence penalty. Compute independent row argmax choices together with the target logits; consume them through unchanged sequential acceptance/EOS/cancellation/rollback. Fast, random sampling and history-dependent penalties remain on their current paths. No duplicate embedding fix carried forward.',evidence='Prior clean ordinary traces show384 separate argmax boundaries with about72-74ms preceding exposed gaps. Fusing the target/logit evaluation boundary with one row-wise argmax removes redundant host waits; no new custom GPU kernels or power changes.',qualification='200 reference cases across1/2/3/7/8rows and small/irregular/full vocabulary dimensions, FP32/BF16, ties/infinities/NaNs; assert unchanged greedy RNG and fallback for penalties/random/unsupportedgeometry. Then one frozen ABCCBA15GB4067slots8192context baseline/candidate/Splash. No retry; all per-fixture forward/reverse ratios must improve to retain.',limitations='Verify timing includes the joint greedy reduction; use complete request wall time for performance. Extra unused row choices are never emitted and do not advance RNG.',sources={f.name:hashlib.sha256(f.read_bytes()).hexdigest()for f in P.glob('*-candidate.swift')}),indent=2))
