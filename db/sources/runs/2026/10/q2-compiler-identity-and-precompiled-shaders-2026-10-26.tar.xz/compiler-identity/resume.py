from pathlib import Path
import json,sys,subprocess,fcntl,os,hashlib,signal
P=Path(__file__).resolve().parent;R=P.parents[1];N=R/'.build/q2-cold-passes-20261026';M=R/'.build/q2-runtime-row-counts-20261026'
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight,terminate_child_tree
sys.path.insert(0,str(R/'.build/native-q2-20261021'));from thermal import wait_nominal
reservation=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(reservation,fcntl.LOCK_EX|fcntl.LOCK_NB)
inner=P/'protocol-child.lock';os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(inner)
ledger=P/'ledger.json';events=json.loads(ledger.read_text());assert len(events)==2 and events[0]['checks_passed'] and events[1]['exit_code']==0 and 'checks_passed'not in events[1]
binaries={a:N/('build-'+a)/'candidate/slotstream'for a in 'AB'};binaries['C']=M/'build-C/candidate/slotstream'
fixture=N/'first-24.json';ref=json.loads((N/'validation-0-A.json').read_text())['rounds'][0]['steps']
identity=json.loads((P/'frozen-identity.json').read_text())
sequence=[('control','A',p)for p in [False,True,True,False]]+[('ordinary',a,True)for a in 'ABCCBA']+[('fixed','C',True),('fixed','C',True)]
for i,(mode,arm,probe)in enumerate(sequence):
 label=f'{i:02d}-{mode}-{arm}';out=P/(label+'.json')
 if i==0:continue
 if i>1:assert not out.exists()
 assert all(hashlib.sha256(Path(n).read_bytes()).hexdigest()==h for n,h in identity.items())
 if i==1:
  full=events[1]['command'];rc=events[1]['exit_code']
 else:
  wait_nominal(P/(label+'-cooldown.json'));preflight(18)
  env=['--env','SLOTSTREAM_MODEL_LOCK_PATH='+str(inner),'--env','DYLD_INSERT_LIBRARIES='+(str(P/'compile_observer.dylib')if probe else '')]
  if probe:env+=['--env','Q2_COMPILE_TRACE='+str(P/(label+'-compile.jsonl'))]
  if mode=='ordinary':
   cmd=[str(binaries[arm]),'smart-dflash-check','--native-read-ahead','on','--method','q2','--model','smart-q2','--memory-gb','15','--max-context','8192','--cases',str(P/'cases.json'),'--output',str(out)]
   if arm in 'AB':env+=['--env','SLOTSTREAM_Q2_COST_TRACE='+str(P/(label+'-decisions.jsonl'))]
  else:cmd=[str(binaries[arm]),'q2-profile','--fixture',str(fixture),'--output',str(out),'--memory-gb','15','--rounds','3']
  full=[sys.executable,str(P/'quiet_guarded_run.py'),'--label',label,'--budget','15','--timeout','600',*env,'--',*cmd]
  print('START',label,'probe',probe,flush=True)
  with(P/(label+'-launcher.log')).open('x')as log,(P/(label+'-frequency.jsonl')).open('x')as freq,(P/(label+'-frequency.stderr')).open('x')as ferr:
   monitor=subprocess.Popen([str(R/'.build/native-monitor/macmon'),'pipe','-s','3300','-i','200','--soc-info'],stdout=freq,stderr=ferr,start_new_session=True)
   child=subprocess.Popen(full,cwd=R,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
   try:rc=child.wait(timeout=660)
   finally:
    try:
     if child.poll()is None:terminate_child_tree(child)
    finally:
     if monitor.poll()is None:
      try:os.killpg(monitor.pid,signal.SIGTERM)
      except ProcessLookupError:pass
      try:monitor.wait(timeout=5)
      except subprocess.TimeoutExpired:
       try:os.killpg(monitor.pid,signal.SIGKILL)
       except ProcessLookupError:pass
       monitor.wait(timeout=5)
 guard=json.loads((P/(label+'.observer.json')).read_text());event=dict(label=label,mode=mode,arm=arm,probe=probe,exit_code=rc,command=full,eligible=not guard['external_build_samples']and not guard['paging']and guard['thermal_before']==guard['thermal_after']==0 and guard['peak_combined_bytes']<=15e9 and rc==0)
 if i==1:events[1]=event
 else:events.append(event)
 ledger.write_text(json.dumps(events,indent=2));assert rc==0
 d=json.loads(out.read_text());assert d['complete']and d['plan']['pool_slots']==4067
 if mode=='ordinary':
  assert len(d['runs'])==1;run=d['runs'][0];assert len(run['tokens'])==384 and run['stats']['reusedPrefixTokens']==0
  event.update(seconds=run['elapsed_seconds'],load_seconds=d['load_seconds'],prefill=run['stats']['prefillSeconds'],decode=run['stats']['decodeSeconds'],passes=run['stats']['verifyPasses'],anchors=run['stats'].get('dflashAnchorOnlyCycles'))
 else:
  rows=[row for rd in d['rounds']for row in rd['steps']];assert len(rows)==72
  for row in rows:
   for k in ['actual_guesses','actual_selected']:assert row[k]==ref[row['step']][k],(label,row['round'],row['step'],k)
  event['rounds']=[dict(round=rd['round'],seconds=rd['seconds'],cycle_seconds=sum(r['seconds']for r in rd['steps']))for rd in d['rounds']]
 if probe:
  tr=[json.loads(s)for s in(P/(label+'-compile.jsonl')).read_text().splitlines()];assert not tr[0]['overflow']and all(tr[0][k]for k in ['library_hook','pipeline_hook','descriptor_hook']);assert len(tr)-1==tr[0]['count']and all(r['done']and r['ok']for r in tr[1:]);assert all((not r['metadata_truncated']or(len(r['functions'])==2047 and len(json.dumps(r['options'],sort_keys=True,separators=(',',':')))<4095))and len(r['source_sha256'])==64 and r['source_bytes']<2**32 for r in tr[1:]if r['kind']==0);event['compile_calls']=tr[0]['count']
 event['checks_passed']=True;ledger.write_text(json.dumps(events,indent=2));print('END',label,'clean',event['eligible'],'seconds',event.get('seconds',event.get('rounds')),flush=True)
print('PROTOCOL FINISHED',flush=True)
