from pathlib import Path
import json,hashlib
P=Path(__file__).resolve().parent
s=(P/'run.py').read_text()
s=s.replace("ledger=P/'ledger.json';assert not ledger.exists();events=[]","ledger=P/'ledger.json';events=json.loads(ledger.read_text());assert len(events)==2 and events[0]['checks_passed'] and events[1]['exit_code']==0 and 'checks_passed'not in events[1]")
start="identity={str(x):hashlib.sha256(x.read_bytes()).hexdigest()for x in [*binaries.values(),fixture,P/'cases.json',P/'plan.json',P/'run.py',P/'quiet_guarded_run.py',P/'compile_observer.mm',P/'compile_observer.dylib']};(P/'frozen-identity.json').write_text(json.dumps(identity,indent=2))"
s=s.replace(start,"identity=json.loads((P/'frozen-identity.json').read_text())")
s=s.replace(" label=f'{i:02d}-{mode}-{arm}';out=P/(label+'.json');assert not out.exists()"," label=f'{i:02d}-{mode}-{arm}';out=P/(label+'.json')\n if i==0:continue\n if i>1:assert not out.exists()")
a=s.index(" wait_nominal(P/(label+'-cooldown.json'))");b=s.index(" guard=json.loads",a)
block=s[a:b];s=s[:a]+" if i==1:\n  full=events[1]['command'];rc=events[1]['exit_code']\n else:\n"+''.join(' '+line+'\n'for line in block.splitlines())+s[b:]
s=s.replace(" events.append(event);ledger.write_text", " if i==1:events[1]=event\n else:events.append(event)\n ledger.write_text")
s=s.replace("not r['metadata_truncated']and len(r['source_sha256'])==64", "(not r['metadata_truncated']or(len(r['functions'])==2047 and len(json.dumps(r['options'],sort_keys=True,separators=(',',':')))<4095))and len(r['source_sha256'])==64")
(P/'resume.py').write_text(s)
(P/'parser-repair.json').write_text(json.dumps(dict(reason='Two generated function-name lists exceed display buffer2048. Source SHA256 and serialized compiler options were complete and valid. No observer or model change. Keep both completed controls and resume without rerunning them.',completed_arms=['00-control-A','01-control-A'],original_identity='frozen-identity.json',resume_sha256=hashlib.sha256(s.encode()).hexdigest(),validation='Allow name-list truncation only when function buffer is exactly2047characters and decoded complete JSON options serialize below4095bytes. Source hash always64hex,bytes<2^32. Functions only labels, hashes/options are identities.'),indent=2))
