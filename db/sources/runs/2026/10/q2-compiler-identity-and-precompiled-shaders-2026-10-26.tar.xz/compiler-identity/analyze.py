from pathlib import Path
from collections import Counter,defaultdict
import json,math
P=Path(__file__).resolve().parent
es=json.loads((P/'ledger.json').read_text());assert len(es)==12 and all(e['checks_passed']for e in es)
def union(xs):
 a=b=total=0
 for c,d in sorted(xs):
  if c>b:total+=b-a;a,b=c,d
  else:b=max(b,d)
 return (total+b-a)/1e9
def key(r):return (r['source_sha256'],json.dumps(r['options'],sort_keys=True,separators=(',',':')),r['device'])
def trace(label):return [json.loads(s)for s in(P/(label+'-compile.jsonl')).read_text().splitlines()][1:]
control=[]
for j in range(3):
 vals=[e['rounds'][j]['cycle_seconds']for e in es[:4]]
 ratios=[vals[1]/vals[0],vals[2]/vals[3]]
 control.append(dict(round=j,off_on_on_off=vals,pairs=ratios,pooled=(vals[1]+vals[2])/(vals[0]+vals[3]),sensitive=any(abs(r-1)>.02 for r in ratios)))
rows=[];libs={};sets={}
for e in es:
 if not e['probe']:continue
 t=trace(e['label']);d=json.loads((P/(e['label']+'.json')).read_text());lib=[r for r in t if r['kind']==0];libs[e['label']]=lib;sets[e['label']]=Counter(key(r)for r in lib)
 x=dict(label=e['label'],mode=e['mode'],arm=e['arm'],clean=e['eligible'],calls=len(t),library_calls=len(lib),unique_libraries=len(sets[e['label']]),library_cpu=sum(r['end_ns']-r['start_ns']for r in lib)/1e9,all_creation_cpu_union=union([(r['start_ns'],r['end_ns'])for r in t]),metadata=sum(r['metadata_ns']for r in lib)/1e9,source_bytes=sum(r['source_bytes']for r in lib))
 if e['mode']=='ordinary':
  run=d['runs'][0];a,b=run['request_started_mach_ns'],run['request_ended_mach_ns'];inside=[r for r in t if a<=r['start_ns']and r['end_ns']<=b]
  x.update(seconds=e['seconds'],load_seconds=e['load_seconds'],prefill=e['prefill'],decode=e['decode'],passes=e['passes'],request_calls=len(inside),request_creation_cpu_union=union([(r['start_ns'],r['end_ns'])for r in inside]))
  dec=P/(e['label']+'-decisions.jsonl')
  if dec.exists():
   cycles=json.loads(dec.read_text())['cycles'];x['anchors']=sum(c['chosen']==0 for c in cycles);x['first_cycles']=[{k:c[k]for k in ['cycle','chosen','prepared','seconds']}for c in cycles[:4] if False]
 elif e['mode']in('control','fixed'):
  x['rounds']=[dict(seconds=rd['seconds'],prefill_seconds=(rd['prefill_end_ns']-rd['prefill_start_ns'])/1e9,creation_cpu_union=union([(r['start_ns'],r['end_ns'])for r in t if rd['start_ns']<=r['start_ns']and r['end_ns']<=rd['end_ns']]))for rd in d['rounds']]
 x['slowest_libraries']=[{k:r[k]for k in ['source_sha256','source_bytes','functions','options']}|dict(seconds=(r['end_ns']-r['start_ns'])/1e9)for r in sorted(lib,key=lambda r:r['end_ns']-r['start_ns'],reverse=True)[:12]]
 rows.append(x)
comparisons=[]
for left,right in [(es[4],es[9]),(es[5],es[8]),(es[6],es[7]),(es[6],es[10]),(es[7],es[11]),(es[1],es[4]),(es[2],es[9])]:
 a,b=left['label'],right['label'];ca,cb=sets[a],sets[b];same=ca&cb
 common=set(same);per=[]
 for k in common:
  aa=[r for r in libs[a]if key(r)==k];bb=[r for r in libs[b]if key(r)==k];ta=sum(r['end_ns']-r['start_ns']for r in aa)/1e9;tb=sum(r['end_ns']-r['start_ns']for r in bb)/1e9
  per.append(dict(hash=k[0],functions=aa[0]['functions'],counts=[len(aa),len(bb)],seconds=[ta,tb],difference=ta-tb))
 comparisons.append(dict(left=a,right=b,exact_multiset=ca==cb,common_occurrences=sum(same.values()),left_only=sum((ca-cb).values()),right_only=sum((cb-ca).values()),common_library_seconds=[sum(x['seconds'][i]for x in per)for i in range(2)],largest_difference=sorted(per,key=lambda x:abs(x['difference']),reverse=True)[:15]))
result=dict(complete=True,all_clean=all(e['eligible']for e in es),control=control,observer_sensitivity_passed=not any(c['sensitive']for c in control),arms=rows,comparisons=comparisons,limits='Diagnostic compilation CPU wall time may overlap useful GPU/read work. Source/options equality proves requested compilation input equality, not OS compiler cache state. All first-request timings include probe and are not product speed gates.')
(P/'analysis.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items()if k not in ['arms','comparisons']},indent=2))
for x in rows:print({k:v for k,v in x.items()if k not in ['slowest_libraries','first_cycles']})
for x in comparisons:print({k:v for k,v in x.items()if k!='largest_difference'})
