#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <cstdio>
#include <cstring>
#include <chrono>
#ifndef PROBE_BUILD
#define PROBE_BUILD 0
#endif
using Clock=std::chrono::steady_clock;
double elapsed(Clock::time_point a){return std::chrono::duration<double>(Clock::now()-a).count();}
int main(int argc,char**argv){@autoreleasepool{
 if(argc!=3)return 9;int count=atoi(argv[2]);if(count<1||count>192)return 8;
 NSError*e=nil;NSString*header=[NSString stringWithContentsOfFile:[NSString stringWithUTF8String:argv[1]] encoding:NSUTF8StringEncoding error:&e];if(!header||e)return 7;
 id<MTLDevice>d=MTLCreateSystemDefaultDevice();id<MTLCommandQueue>q=[d newCommandQueue];
 id<MTLBuffer>w=[d newBufferWithLength:18 options:MTLResourceStorageModeShared];memset(w.contents,0,18);((unsigned char*)w.contents)[1]=0x3c;
 id<MTLBuffer>y=[d newBufferWithLength:32*sizeof(float) options:MTLResourceStorageModeShared];
 MTLCompileOptions*o=[MTLCompileOptions new];o.languageVersion=MTLLanguageVersion4_0;o.mathMode=MTLMathModeSafe;o.enableLogging=YES;
 printf("{\"build\":%d,\"device\":%llu,\"count\":%d,\"rows\":[",PROBE_BUILD,(unsigned long long)d.registryID,count);
 for(int i=0;i<count;++i){@autoreleasepool{
  NSString*name=[NSString stringWithFormat:@"check_%d",i];NSString*body=[NSString stringWithFormat:@"\nkernel void check_%d(device const uchar*w [[buffer(0)]],device float*y [[buffer(1)]],uint i [[thread_position_in_grid]]){y[i]=GgufEmbedQ40::decode(w,i)+%d.0f;}\n",i,i];NSString*source=[header stringByAppendingString:body];
  auto t=Clock::now();id<MTLLibrary>lib=[d newLibraryWithSource:source options:o error:&e];double ls=elapsed(t);if(!lib||e){fprintf(stderr,"library: %s\n",e.description.UTF8String);return 1;}
  id<MTLFunction>f=[lib newFunctionWithName:name];t=Clock::now();id<MTLComputePipelineState>p=[d newComputePipelineStateWithFunction:f error:&e];double ps=elapsed(t);if(!p||e)return 2;
  id<MTLCommandBuffer>c=[q commandBuffer];id<MTLComputeCommandEncoder>enc=[c computeCommandEncoder];[enc setComputePipelineState:p];[enc setBuffer:w offset:0 atIndex:0];[enc setBuffer:y offset:0 atIndex:1];[enc dispatchThreads:MTLSizeMake(32,1,1) threadsPerThreadgroup:MTLSizeMake(32,1,1)];[enc endEncoding];[c commit];[c waitUntilCompleted];if(c.error)return 3;
  for(int j=0;j<32;++j)if(((float*)y.contents)[j]!=float(i-8))return 4;
  printf("%s{\"index\":%d,\"library_seconds\":%.9f,\"pipeline_seconds\":%.9f,\"exact\":true}",i?",":"",i,ls,ps);[p release];[f release];[lib release];
 }}
 puts("]}");[o release];[y release];[w release];[q release];[d release];return 0;
}}
