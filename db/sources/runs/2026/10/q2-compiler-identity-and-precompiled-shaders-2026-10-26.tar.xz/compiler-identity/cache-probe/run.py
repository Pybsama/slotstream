from pathlib import Path
import subprocess,sys,os,fcntl,json,shutil,hashlib,time
P=Path(__file__).resolve().parent;R=P.parents[2]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight,host_conditions,vm_snapshot
lock=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(P/'child.lock');preflight(7)
raw=(R/'Sources/Slotstream/Q2GGUFKernelSources.swift').read_text();header='#include <metal_stdlib>\nusing namespace metal;\n'+raw.split('static let header = #"""',1)[1].split('"""#',1)[0];(P/'header.metal').write_text(header)
plan=dict(hypothesis='Alternating distinct executable identities with the same basename invalidates or partitions Metal shader caches. Diagnostic, no runtime mutation or OS cache deletion.',protocol='Two distinct build IDs, same source/options/device, original and copied/renamed executables. Two fixed library counts4 and192. Every library output checked against independently computed q4_0 values from exact bytes. Same build/path repeated before switches. No injected observer. Original unmodified macOS shader cache behavior.',source_sha256=hashlib.sha256(header.encode()).hexdigest(),options=dict(language='metal4.0',math='safe',logging=True),orders={'4':'A A B B A A B B Acopy A Aname Aname Bname Bname Aname Bname A B','192':'A A B B A A B B Acopy A Aname Aname Bname Bname Aname Bname A B'})
(P/'plan.json').write_text(json.dumps(plan,indent=2));bins={}
for i,a in enumerate('AB',1):
 path=P/a/'probe';path.parent.mkdir(exist_ok=True);cmd=['xcrun','clang++','-std=c++17','-O2','-fno-objc-arc',f'-DPROBE_BUILD={i}','-framework','Foundation','-framework','Metal',str(P/'probe.mm'),'-o',str(path)]
 x=subprocess.run(cmd,capture_output=True,text=True);(P/f'build-{a}.log').write_text(x.stdout+x.stderr);assert x.returncode==0,x.stderr;bins[a]=path
for a,src,dest in [('Acopy','A',P/'Acopy/probe'),('Aname','A',P/'A/probe_A'),('Bname','B',P/'B/probe_B')]:
 dest.parent.mkdir(exist_ok=True,parents=True);shutil.copy2(bins[src],dest);bins[a]=dest
identity={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in [*bins.values(),P/'header.metal',P/'probe.mm',P/'run.py',P/'plan.json']};(P/'identity.json').write_text(json.dumps(identity,indent=2))
env={k:v for k,v in os.environ.items()if not k.startswith(('DYLD_','MTL_','Q2_','MLX_','SLOTSTREAM_'))};ledger=[];before=dict(host=host_conditions(),vm=vm_snapshot())
for count,order in plan['orders'].items():
 for i,arm in enumerate(order.split()):
  label=f'{count}-{i:02d}-{arm}';assert not(P/(label+'.json')).exists();cmd=[str(bins[arm]),str(P/'header.metal'),count]
  r=subprocess.run(cmd,capture_output=True,text=True,env=env,timeout=180);(P/(label+'.stdout')).write_text(r.stdout);(P/(label+'.stderr')).write_text(r.stderr);assert r.returncode==0,(label,r.returncode,r.stderr)
  d=json.loads(r.stdout);assert len(d['rows'])==int(count)and all(x['exact']for x in d['rows']);(P/(label+'.json')).write_text(json.dumps(d,indent=2))
  e=dict(label=label,arm=arm,count=int(count),library_seconds=sum(x['library_seconds']for x in d['rows']),pipeline_seconds=sum(x['pipeline_seconds']for x in d['rows']),exact=True,command=cmd)
  ledger.append(e);(P/'ledger.json').write_text(json.dumps(ledger,indent=2));print(e,flush=True)
(P/'conditions.json').write_text(json.dumps(dict(before=before,after=vm_snapshot()),indent=2));print('CACHE PROBE FINISHED',flush=True)
