from pathlib import Path
import json,shutil
P=Path(__file__).resolve().parent;R=P.parents[1];N=R/'.build/q2-cold-passes-20261026'
s=(N/'compile_observer.mm').read_text()
s=s.replace('#include <atomic>','#include <atomic>\n#include <CommonCrypto/CommonDigest.h>')
s=s.replace('char name[160];','char name[160]; char source_hash[65]{}; uint64_t source_bytes=0,device=0,metadata_ns=0; char options[4096]{}; char functions[2048]{}; bool metadata_truncated=false;')
old='id<MTLLibrary> library(id self,SEL cmd,NSString *source,MTLCompileOptions *options,NSError **error){auto*r=begin(0,@"source-library");auto v=originalLibrary(self,cmd,source,options,error);end(r,v!=nil);return v;}'
new=r'''void copyText(char *dest,size_t size,NSString *s,Row *r){const char*t=s?[s UTF8String]:"";size_t n=t?std::strlen(t):0;r->metadata_truncated|=n>=size;std::snprintf(dest,size,"%s",t?t:"");}
id<MTLLibrary> library(id self,SEL cmd,NSString *source,MTLCompileOptions *options,NSError **error){
 auto*r=begin(0,@"source-library");
 if(r){uint64_t m=now();@autoreleasepool{
  NSData *data=[source dataUsingEncoding:NSUTF8StringEncoding];r->source_bytes=data.length;
  unsigned char hash[CC_SHA256_DIGEST_LENGTH];CC_SHA256(data.bytes,(CC_LONG)data.length,hash);
  for(unsigned i=0;i<CC_SHA256_DIGEST_LENGTH;++i)std::sprintf(r->source_hash+2*i,"%02x",hash[i]);
  r->device=[(id<MTLDevice>)self registryID];
  if(!options)copyText(r->options,sizeof(r->options),@"null",r);
  else {
   NSMutableDictionary *d=[NSMutableDictionary dictionaryWithDictionary:@{
    @"language":@((NSUInteger)options.languageVersion),@"fast_math":@(options.fastMathEnabled),
    @"math_mode":@((NSUInteger)options.mathMode),@"math_functions":@((NSUInteger)options.mathFloatingPointFunctions),
    @"library_type":@((NSUInteger)options.libraryType),@"preserve_invariance":@(options.preserveInvariance),
    @"optimization":@((NSUInteger)options.optimizationLevel),@"visibility":@((NSUInteger)options.compileSymbolVisibility),
    @"undefined_symbols":@(options.allowReferencingUndefinedSymbols),@"max_threads":@(options.maxTotalThreadsPerThreadgroup),
    @"logging":@(options.enableLogging),@"macros":options.preprocessorMacros?:@{},@"install_name":options.installName?:@""
   }];
   if(@available(macOS 26.0,*)){MTLSize z=options.requiredThreadsPerThreadgroup;d[@"required_threads"]=@[@(z.width),@(z.height),@(z.depth)];}
   NSMutableArray *libs=[NSMutableArray array];for(id<MTLDynamicLibrary>lib in options.libraries){[libs addObject:@{@"install_name":lib.installName?:@"",@"label":lib.label?:@""}];}d[@"dynamic_libraries"]=libs;
   NSData *j=[NSJSONSerialization dataWithJSONObject:d options:NSJSONWritingSortedKeys error:nil];
   NSString *str=[[NSString alloc]initWithData:j encoding:NSUTF8StringEncoding];copyText(r->options,sizeof(r->options),str,r);[str release];
  }
 }r->metadata_ns=now()-m;r->start=now();}
 auto v=originalLibrary(self,cmd,source,options,error);end(r,v!=nil);
 if(r&&v){@autoreleasepool{copyText(r->functions,sizeof(r->functions),[[[v functionNames]sortedArrayUsingSelector:@selector(compare:)]componentsJoinedByString:@","],r);}}
 return v;
}'''
assert old in s;s=s.replace(old,new)
old='quoted(f,r.name);fputs("}\\n",f);'
new=r'''quoted(f,r.name);if(r.kind==0){fprintf(f,",\"source_bytes\":%llu,\"device\":%llu,\"metadata_ns\":%llu,\"metadata_truncated\":%s,\"source_sha256\":",(unsigned long long)r.source_bytes,(unsigned long long)r.device,(unsigned long long)r.metadata_ns,r.metadata_truncated?"true":"false");quoted(f,r.source_hash);fputs(",\"options\":",f);fputs(r.options[0]?r.options:"null",f);fputs(",\"functions\":",f);quoted(f,r.functions);}fputs("}\n",f);'''
assert old in s;s=s.replace(old,new)
(P/'compile_observer.mm').write_text(s)
for name in ['compile_check.mm','quiet_guarded_run.py']:shutil.copy2(N/name,P/name)
s=(N/'build_observer.py').read_text().replace("['compile_observer.mm','compile_observer.dylib','compile_check.mm','compile-check']","['compile_observer.mm','compile_observer.dylib','compile_check.mm','compile-check']")
s=s.replace("(P/'observer-check-result.json').write_text", "assert rows[1]['source_sha256']==hashlib.sha256(b'#include <metal_stdlib>\\nusing namespace metal; kernel void check(device uint *x [[buffer(0)]]){x[0]=x[0]*3+1;}').hexdigest() and rows[1]['options']is None and rows[1]['functions']=='check' and not rows[1]['metadata_truncated']\n(P/'observer-check-result.json').write_text")
(P/'build_observer.py').write_text(s)
shutil.copy2(N/'capture-cases.json',P/'cases.json')
(P/'plan.json').write_text(json.dumps(dict(scope='Diagnostic source and compiler-option identity across ordinary first requests and fixed-input replay. No production change or speed claim.',binary_arms={'A':'N/nativeA v68 plus bounded cost/input trace','B':'N/nativeB aligned forecast plus same diagnostic','C':'M runtime row counts candidate'},control='Fixed first24 passes, expert metadata reset before each of 3 rounds. A off/on/on/off, exact proposals and selected tokens; modified observer must satisfy <=2% each forward/reverse pair per round before timing attribution.',ordinary='A B C C B A, one warm0 code384 request per fresh process, 15GB/4067 slots,8192 context,BF16KV/FP32state, existing actual adaptivecontroller, same source/options hash observer. No favorable retries. No forced cache flush or file-cache claim.',fixed_followup='C fixed first24 replay twice, same existing fixture and 3resetrounds. Compare source/options multiset with ordinary C. Diagnostic only.',limits='CPU library/pipeline call durations overlap GPU and I/O; never count all CPU waits as idle GPU. Source identity does not prove OS cache residency. No change based on timing alone. Source hash collection overhead is outside call timing but within request; explicit control required.',retain='No shipping change in this experiment. Use findings to select smallest justified next fix; measure prep plus first request if moving preparation before ready.'),indent=2))
print(P)
