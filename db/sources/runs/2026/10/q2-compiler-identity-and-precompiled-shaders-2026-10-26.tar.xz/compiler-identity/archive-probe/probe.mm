#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <cstdio>
#include <string>
int main(int argc,char**argv){@autoreleasepool{
 if(argc!=3)return 9;bool capture=std::string(argv[1])=="capture";NSError*e=nil;id<MTLDevice>d=MTLCreateSystemDefaultDevice();
 MTL4LibraryFunctionDescriptor*f=[MTL4LibraryFunctionDescriptor new];f.name=@"check";MTL4ComputePipelineDescriptor*p=[MTL4ComputePipelineDescriptor new];p.computeFunctionDescriptor=f;p.label=@"check-pipeline";
 id<MTLComputePipelineState>pipeline=nil;id<MTL4PipelineDataSetSerializer>ser=nil;
 if(capture){
  MTL4PipelineDataSetSerializerDescriptor*sd=[MTL4PipelineDataSetSerializerDescriptor new];sd.configuration=MTL4PipelineDataSetSerializerConfigurationCaptureDescriptors|MTL4PipelineDataSetSerializerConfigurationCaptureBinaries;ser=[d newPipelineDataSetSerializerWithDescriptor:sd];
  MTL4CompilerDescriptor*cd=[MTL4CompilerDescriptor new];cd.pipelineDataSetSerializer=ser;id<MTL4Compiler>compiler=[d newCompilerWithDescriptor:cd error:&e];if(!compiler){fprintf(stderr,"compiler %s\n",e.description.UTF8String);return 1;}
  MTL4LibraryDescriptor*ld=[MTL4LibraryDescriptor new];ld.source=@"#include <metal_stdlib>\nusing namespace metal;kernel void check(device uint*x[[buffer(0)]]){x[0]=x[0]*3+1;}";ld.name=@"archive-probe";
  id<MTLLibrary>lib=[compiler newLibraryWithDescriptor:ld error:&e];if(!lib){fprintf(stderr,"library %s\n",e.description.UTF8String);return 2;}f.library=lib;p.computeFunctionDescriptor=f;
  pipeline=[compiler newComputePipelineStateWithDescriptor:p compilerTaskOptions:nil error:&e];if(!pipeline){fprintf(stderr,"pipeline %s\n",e.description.UTF8String);return 3;}
  if(![ser serializeAsArchiveAndFlushToURL:[NSURL fileURLWithPath:[NSString stringWithUTF8String:argv[2]]] error:&e]){fprintf(stderr,"serialize %s\n",e.description.UTF8String);return 4;}
  NSData*script=[ser serializeAsPipelinesScriptWithError:&e];if(script)[script writeToFile:[[NSString stringWithUTF8String:argv[2]]stringByAppendingString:@".script"]atomically:YES];
 }else{
  id<MTL4Archive>a=[d newArchiveWithURL:[NSURL fileURLWithPath:[NSString stringWithUTF8String:argv[2]]]error:&e];if(!a){fprintf(stderr,"load %s\n",e.description.UTF8String);return 5;}
  pipeline=[a newComputePipelineStateWithDescriptor:p error:&e];if(!pipeline){fprintf(stderr,"lookup %s\n",e.description.UTF8String);return 6;}
 }
 id<MTLCommandQueue>q=[d newCommandQueue];id<MTLBuffer>x=[d newBufferWithLength:4 options:MTLResourceStorageModeShared];*(uint32_t*)x.contents=2;id<MTLCommandBuffer>c=[q commandBuffer];id<MTLComputeCommandEncoder>enc=[c computeCommandEncoder];[enc setComputePipelineState:pipeline];[enc setBuffer:x offset:0 atIndex:0];[enc dispatchThreads:MTLSizeMake(1,1,1) threadsPerThreadgroup:MTLSizeMake(1,1,1)];[enc endEncoding];[c commit];[c waitUntilCompleted];if(c.error||*(uint32_t*)x.contents!=7){fprintf(stderr,"execution %s value%u\n",c.error.description.UTF8String,*(uint32_t*)x.contents);return 7;}
 printf("EXACT %s\n",capture?"capture":"lookup");return 0;
}}
