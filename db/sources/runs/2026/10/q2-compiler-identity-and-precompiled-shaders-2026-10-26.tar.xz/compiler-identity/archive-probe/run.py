from pathlib import Path
import subprocess,fcntl,os,json
P=Path(__file__).resolve().parent
lock=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
cmd=['xcrun','clang++','-std=c++17','-O2','-fno-objc-arc','-framework','Foundation','-framework','Metal',str(P/'probe.mm'),'-o',str(P/'probe')]
r=subprocess.run(cmd,capture_output=True,text=True);(P/'build.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stderr
rows=[]
for mode in ['capture','lookup']:
 r=subprocess.run([str(P/'probe'),mode,str(P/'archive.bin')],capture_output=True,text=True,timeout=30)
 (P/(mode+'.log')).write_text(r.stdout+r.stderr);rows.append(dict(mode=mode,returncode=r.returncode,output=r.stdout+r.stderr));print(rows[-1],flush=True)
 if r.returncode:break
(P/'result.json').write_text(json.dumps(rows,indent=2))
