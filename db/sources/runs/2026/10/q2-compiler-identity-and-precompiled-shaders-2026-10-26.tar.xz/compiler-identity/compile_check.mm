#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <cstdio>
int main(){@autoreleasepool{
 id<MTLDevice>d=MTLCreateSystemDefaultDevice();NSError*e=nil;
 NSString*s=@"#include <metal_stdlib>\nusing namespace metal; kernel void check(device uint *x [[buffer(0)]]){x[0]=x[0]*3+1;}";
 id<MTLLibrary>l=[d newLibraryWithSource:s options:nil error:&e];if(!l||e)return 1;
 id<MTLFunction>f=[l newFunctionWithName:@"check"];
 id<MTLComputePipelineState>a=[d newComputePipelineStateWithFunction:f error:&e];if(!a||e)return 2;
 MTLComputePipelineDescriptor*desc=[MTLComputePipelineDescriptor new];desc.computeFunction=f;
 id<MTLComputePipelineState>b=[d newComputePipelineStateWithDescriptor:desc options:MTLPipelineOptionNone reflection:nil error:&e];if(!b||e)return 3;
 id<MTLBuffer>x=[d newBufferWithLength:4 options:MTLResourceStorageModeShared];*(uint32_t*)x.contents=2;
 id<MTLCommandQueue>q=[d newCommandQueue];id<MTLCommandBuffer>c=[q commandBuffer];id<MTLComputeCommandEncoder>enc=[c computeCommandEncoder];[enc setComputePipelineState:a];[enc setBuffer:x offset:0 atIndex:0];[enc dispatchThreads:MTLSizeMake(1,1,1) threadsPerThreadgroup:MTLSizeMake(1,1,1)];[enc endEncoding];[c commit];[c waitUntilCompleted];if(c.error||*(uint32_t*)x.contents!=7)return 4;
 puts("COMPILE_OBSERVER_KERNEL_EXACT_PASS");[q release];[x release];[b release];[desc release];[a release];[f release];[l release];[d release];return 0;
}}
