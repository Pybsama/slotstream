from pathlib import Path
import shutil,json
P=Path(__file__).resolve().parent;BASE=P.parent
s=(BASE/'compile_observer.mm').read_text()
s=s.replace('bool metadata_truncated=false;', 'bool metadata_truncated=false; NSData *captured=nullptr;')
s=s.replace('Row rows[limit];', 'constexpr uint64_t captureLimit=32*1024*1024;std::atomic<uint64_t>captureBytes{0};std::atomic<bool>captureOverflow{false};const char*capturePath=nullptr;\nRow rows[limit];')
s=s.replace('NSData *data=[source dataUsingEncoding:NSUTF8StringEncoding];r->source_bytes=data.length;', 'NSData *data=[source dataUsingEncoding:NSUTF8StringEncoding];r->source_bytes=data.length;\n  if(capturePath){uint64_t at=captureBytes.fetch_add(data.length);if(at+data.length<=captureLimit)r->captured=[data retain];else captureOverflow.store(true);}')
s=s.replace('mach_timebase_info(&scale);@autoreleasepool', 'capturePath=getenv("Q2_CAPTURE_SOURCES");mach_timebase_info(&scale);@autoreleasepool')
s=s.replace('fclose(f);}', r'''fclose(f);if(capturePath){@autoreleasepool{unsigned saved=0;bool ok=!captureOverflow.load();for(unsigned i=0;i<n&&i<limit;++i){auto&r=rows[i];if(!r.captured)continue;NSString*name=[NSString stringWithFormat:@"%s/%s.metal",capturePath,r.source_hash];if(![[NSFileManager defaultManager]fileExistsAtPath:name]){ok=ok&&[r.captured writeToFile:name atomically:YES];++saved;}[r.captured release];r.captured=nullptr;}NSString*receipt=[NSString stringWithFormat:@"{\"saved\":%u,\"bytes\":%llu,\"limit\":%llu,\"complete\":%s}\n",saved,(unsigned long long)captureBytes.load(),(unsigned long long)captureLimit,ok?"true":"false"];[receipt writeToFile:[NSString stringWithFormat:@"%s/capture.json",capturePath]atomically:YES encoding:NSUTF8StringEncoding error:nil];}}}''')
(P/'compile_observer.mm').write_text(s)
print('Source capture after completion only,32MiB limit')
