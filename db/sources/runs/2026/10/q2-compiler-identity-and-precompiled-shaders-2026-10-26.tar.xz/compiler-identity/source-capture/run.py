from pathlib import Path
import sys,os,subprocess,fcntl,json,hashlib
P=Path(__file__).resolve().parent;BASE=P.parent;R=P.parents[2];N=R/'.build/q2-cold-passes-20261026';M=R/'.build/q2-runtime-row-counts-20261026'
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
sys.path.insert(0,str(R/'.build/native-q2-20261021'));from thermal import wait_nominal
lock=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);inner=P/'child.lock';os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(inner);preflight(7)
cmd=['xcrun','clang++','-std=c++17','-O2','-fno-objc-arc','-framework','Foundation','-framework','Metal','-dynamiclib',str(P/'compile_observer.mm'),'-o',str(P/'compile_observer.dylib')];r=subprocess.run(cmd,capture_output=True,text=True);(P/'build.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stderr
out=P/'fixed.json';assert not out.exists();source=P/'sources';source.mkdir();wait_nominal(P/'cooldown.json');preflight(18)
command=[sys.executable,str(BASE/'quiet_guarded_run.py'),'--label','source-capture-fixed','--budget','15','--timeout','600','--env','SLOTSTREAM_MODEL_LOCK_PATH='+str(inner),'--env','DYLD_INSERT_LIBRARIES='+str(P/'compile_observer.dylib'),'--env','Q2_COMPILE_TRACE='+str(P/'compile.jsonl'),'--env','Q2_CAPTURE_SOURCES='+str(source),'--',str(M/'build-C/candidate/slotstream'),'q2-profile','--fixture',str(N/'first-24.json'),'--output',str(out),'--memory-gb','15','--rounds','3']
(P/'plan.json').write_text(json.dumps(dict(scope='Source capture only. No timing attribution or performance comparison. Exact source passed to the Metal API, retained at most32MiB then written only after inference completes. Use existing fixed first24 fixture,3expertresetrounds,compare exact proposed/selected token arrays to validated native baseline. Runtime source and original options unchanged; no private source tokens/weights.',command=command,files={str(x):hashlib.sha256(x.read_bytes()).hexdigest()for x in [P/'compile_observer.mm',P/'compile_observer.dylib',M/'build-C/candidate/slotstream',N/'first-24.json']}),indent=2))
with(P/'launcher.log').open('x')as f:r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,cwd=R)
assert r.returncode==0
ref=json.loads((N/'validation-0-A.json').read_text())['rounds'][0]['steps'];d=json.loads(out.read_text());assert d['complete']and d['plan']['pool_slots']==4067
for rd in d['rounds']:
 for row in rd['steps']:
  for k in ['actual_guesses','actual_selected']:assert row[k]==ref[row['step']][k]
receipt=json.loads((source/'capture.json').read_text());assert receipt['complete']and receipt['bytes']<=receipt['limit']
tr=list(map(json.loads,(P/'compile.jsonl').read_text().splitlines()));assert not tr[0]['overflow']and len(tr)-1==tr[0]['count']and all(x['done']and x['ok']for x in tr[1:]);libs=[x for x in tr[1:]if x['kind']==0]
for x in libs:
 data=(source/(x['source_sha256']+'.metal')).read_bytes();assert len(data)==x['source_bytes']and hashlib.sha256(data).hexdigest()==x['source_sha256']
g=json.loads((BASE/'source-capture-fixed.observer.json').read_text());clean=not g['paging']and not g['external_build_samples']and g['thermal_before']==g['thermal_after']==0
(P/'result.json').write_text(json.dumps(dict(complete=True,exact=True,clean=clean,libraries=len(libs),unique_sources=receipt['saved'],bytes=receipt['bytes'],peak_gb=g['peak_combined_bytes']/1e9),indent=2));print('Source capture exact and hashed',receipt,flush=True)
