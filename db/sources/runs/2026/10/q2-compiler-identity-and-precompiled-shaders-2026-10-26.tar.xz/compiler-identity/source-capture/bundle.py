from pathlib import Path
import json,hashlib,tarfile,io,fcntl,os
P=Path(__file__).resolve().parent;R=P.parents[2];out=R/'Tools/fixtures/q2-shader-compilation';out.mkdir(parents=True,exist_ok=True)
lock=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
sha=lambda b:hashlib.sha256(b).hexdigest();assert json.loads((P/'result.json').read_text())['complete']
rows=[r for r in map(json.loads,(P/'compile.jsonl').read_text().splitlines())if r.get('kind')==0]
units=[];files={}
for r in rows:
 h=r['source_sha256'];b=(P/'sources'/(h+'.metal')).read_bytes();assert sha(b)==h and b'PRIVATE KEY'not in b
 opts=json.dumps(r['options'],sort_keys=True,separators=(',',':'));unit=h+'-'+sha(opts.encode())[:16]
 units.append(dict(id=unit,source_sha256=h,source_bytes=len(b),options=r['options'],function_label=r['functions'][:180],function_label_truncated=len(r['functions'])>180))
 files['sources/'+h+'.metal']=b
assert len(units)==len({u['id']for u in units})==174
manifest=dict(schema_version=1,qualification='Diagnostic inputs, not a shipped kernel bundle. Capture C fixed first24/3rounds, exact original Metal sources/options. Runtime fallback remains required for unseen source/options. No model weights or user data. See q2-compiler-identity experiment.',model='smart-q2',minimum_os='26.1',units=sorted(units,key=lambda u:u['id']))
files['manifest.json']=json.dumps(manifest,indent=2).encode()
for n,p in [('LICENSE-slotstream.txt',R/'LICENSE'),('LICENSE-mlx.txt',R/'.build/checkouts/mlx-swift/LICENSE'),('LICENSE-splash.txt',R/'Licenses/splash-Apache-2.0.txt'),('NOTICE-splash.txt',R/'Licenses/splash-NOTICE.txt')]:files[n]=p.read_bytes()
archive=out/'q2-fixed-shaders-20261026.tar.xz';assert not archive.exists()
with tarfile.open(archive,'w:xz',preset=3)as t:
 for name,b in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;t.addfile(info,io.BytesIO(b))
with tarfile.open(archive,'r:xz')as t:assert {m.name:t.extractfile(m).read()for m in t}==files
receipt=dict(schema_version=1,archive=archive.name,sha256=sha(archive.read_bytes()),bytes=archive.stat().st_size,units=174,source_bytes=sum(len(b)for n,b in files.items()if n.endswith('.metal')),role='Experimental compiler fixture only. Never load automatically into the app or engine.')
(out/'fixture.json').write_text(json.dumps(receipt,indent=2)+'\n');(P/'bundle-receipt.json').write_text(json.dumps(receipt,indent=2));print(receipt)
