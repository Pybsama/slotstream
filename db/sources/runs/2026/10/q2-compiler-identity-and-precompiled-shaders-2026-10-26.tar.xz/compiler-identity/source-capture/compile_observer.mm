#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#import <objc/runtime.h>
#include <atomic>
#include <CommonCrypto/CommonDigest.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <mach/mach_time.h>
#include <pthread.h>
namespace {
constexpr unsigned limit=16384;
struct Row { std::atomic<unsigned> done{0}; unsigned kind; uint64_t start,end,thread; bool main,ok; char name[160]; char source_hash[65]{}; uint64_t source_bytes=0,device=0,metadata_ns=0; char options[4096]{}; char functions[2048]{}; bool metadata_truncated=false; NSData *captured=nullptr; };
constexpr uint64_t captureLimit=32*1024*1024;std::atomic<uint64_t>captureBytes{0};std::atomic<bool>captureOverflow{false};const char*capturePath=nullptr;
Row rows[limit]; std::atomic<unsigned> next{0}; const char *path=nullptr; mach_timebase_info_data_t scale{};
using Lib=id<MTLLibrary>(*)(id,SEL,NSString*,MTLCompileOptions*,NSError**);
using Pipe=id<MTLComputePipelineState>(*)(id,SEL,id<MTLFunction>,NSError**);
using Desc=id<MTLComputePipelineState>(*)(id,SEL,MTLComputePipelineDescriptor*,MTLPipelineOption,MTLComputePipelineReflection**,NSError**);
Lib originalLibrary=nullptr; Pipe originalPipeline=nullptr; Desc originalDescriptor=nullptr;
uint64_t now(){return mach_absolute_time()*uint64_t(scale.numer)/scale.denom;}
Row *begin(unsigned kind,NSString *name){unsigned i=next.fetch_add(1,std::memory_order_relaxed);if(i>=limit)return nullptr;auto *r=&rows[i];r->kind=kind;r->main=pthread_main_np();pthread_threadid_np(nullptr,&r->thread);const char *n=name?[name UTF8String]:"";std::snprintf(r->name,sizeof(r->name),"%s",n?n:"");r->start=now();return r;}
void end(Row*r,bool ok){if(!r)return;r->end=now();r->ok=ok;r->done.store(1,std::memory_order_release);}
void copyText(char *dest,size_t size,NSString *s,Row *r){const char*t=s?[s UTF8String]:"";size_t n=t?std::strlen(t):0;r->metadata_truncated|=n>=size;std::snprintf(dest,size,"%s",t?t:"");}
id<MTLLibrary> library(id self,SEL cmd,NSString *source,MTLCompileOptions *options,NSError **error){
 auto*r=begin(0,@"source-library");
 if(r){uint64_t m=now();@autoreleasepool{
  NSData *data=[source dataUsingEncoding:NSUTF8StringEncoding];r->source_bytes=data.length;
  if(capturePath){uint64_t at=captureBytes.fetch_add(data.length);if(at+data.length<=captureLimit)r->captured=[data retain];else captureOverflow.store(true);}
  unsigned char hash[CC_SHA256_DIGEST_LENGTH];CC_SHA256(data.bytes,(CC_LONG)data.length,hash);
  for(unsigned i=0;i<CC_SHA256_DIGEST_LENGTH;++i)std::sprintf(r->source_hash+2*i,"%02x",hash[i]);
  r->device=[(id<MTLDevice>)self registryID];
  if(!options)copyText(r->options,sizeof(r->options),@"null",r);
  else {
   NSMutableDictionary *d=[NSMutableDictionary dictionaryWithDictionary:@{
    @"language":@((NSUInteger)options.languageVersion),@"fast_math":@(options.fastMathEnabled),
    @"math_mode":@((NSUInteger)options.mathMode),@"math_functions":@((NSUInteger)options.mathFloatingPointFunctions),
    @"library_type":@((NSUInteger)options.libraryType),@"preserve_invariance":@(options.preserveInvariance),
    @"optimization":@((NSUInteger)options.optimizationLevel),@"visibility":@((NSUInteger)options.compileSymbolVisibility),
    @"undefined_symbols":@(options.allowReferencingUndefinedSymbols),@"max_threads":@(options.maxTotalThreadsPerThreadgroup),
    @"logging":@(options.enableLogging),@"macros":options.preprocessorMacros?:@{},@"install_name":options.installName?:@""
   }];
   if(@available(macOS 26.0,*)){MTLSize z=options.requiredThreadsPerThreadgroup;d[@"required_threads"]=@[@(z.width),@(z.height),@(z.depth)];}
   NSMutableArray *libs=[NSMutableArray array];for(id<MTLDynamicLibrary>lib in options.libraries){[libs addObject:@{@"install_name":lib.installName?:@"",@"label":lib.label?:@""}];}d[@"dynamic_libraries"]=libs;
   NSData *j=[NSJSONSerialization dataWithJSONObject:d options:NSJSONWritingSortedKeys error:nil];
   NSString *str=[[NSString alloc]initWithData:j encoding:NSUTF8StringEncoding];copyText(r->options,sizeof(r->options),str,r);[str release];
  }
 }r->metadata_ns=now()-m;r->start=now();}
 auto v=originalLibrary(self,cmd,source,options,error);end(r,v!=nil);
 if(r&&v){@autoreleasepool{copyText(r->functions,sizeof(r->functions),[[[v functionNames]sortedArrayUsingSelector:@selector(compare:)]componentsJoinedByString:@","],r);}}
 return v;
}
id<MTLComputePipelineState> pipeline(id self,SEL cmd,id<MTLFunction>function,NSError**error){auto*r=begin(1,[function name]);auto v=originalPipeline(self,cmd,function,error);end(r,v!=nil);return v;}
id<MTLComputePipelineState> descriptor(id self,SEL cmd,MTLComputePipelineDescriptor *desc,MTLPipelineOption opts,MTLComputePipelineReflection **reflection,NSError**error){auto*r=begin(2,[[desc computeFunction]name]);auto v=originalDescriptor(self,cmd,desc,opts,reflection,error);end(r,v!=nil);return v;}
IMP hook(Class cls,SEL sel,IMP replacement){Method m=class_getInstanceMethod(cls,sel);if(!m)return nullptr;IMP original=method_getImplementation(m);const char *types=method_getTypeEncoding(m);if(!class_addMethod(cls,sel,replacement,types))class_replaceMethod(cls,sel,replacement,types);return original;}
void quoted(FILE*f,const char*s){fputc('"',f);for(;*s;++s){unsigned char c=*s;if(c=='"'||c=='\\')fputc('\\',f);if(c>=32)fputc(c,f);else fprintf(f,"\\u%04x",c);}fputc('"',f);}
__attribute__((constructor))void setup(){path=getenv("Q2_COMPILE_TRACE");if(!path||!*path){path=nullptr;return;}capturePath=getenv("Q2_CAPTURE_SOURCES");mach_timebase_info(&scale);@autoreleasepool{id<MTLDevice>d=MTLCreateSystemDefaultDevice();Class cls=object_getClass(d);originalLibrary=reinterpret_cast<Lib>(hook(cls,@selector(newLibraryWithSource:options:error:),reinterpret_cast<IMP>(library)));originalPipeline=reinterpret_cast<Pipe>(hook(cls,@selector(newComputePipelineStateWithFunction:error:),reinterpret_cast<IMP>(pipeline)));originalDescriptor=reinterpret_cast<Desc>(hook(cls,@selector(newComputePipelineStateWithDescriptor:options:reflection:error:),reinterpret_cast<IMP>(descriptor)));[d release];}}
__attribute__((destructor))void dump(){if(!path)return;FILE*f=fopen(path,"wx");if(!f)return;unsigned n=next.load();fprintf(f,"{\"summary\":true,\"count\":%u,\"capacity\":%u,\"overflow\":%s,\"library_hook\":%s,\"pipeline_hook\":%s,\"descriptor_hook\":%s}\n",n,limit,n>limit?"true":"false",originalLibrary?"true":"false",originalPipeline?"true":"false",originalDescriptor?"true":"false");for(unsigned i=0;i<n&&i<limit;++i){auto&r=rows[i];bool done=r.done.load(std::memory_order_acquire);fprintf(f,"{\"index\":%u,\"done\":%s,\"kind\":%u,\"start_ns\":%llu,\"end_ns\":%llu,\"thread\":%llu,\"main\":%s,\"ok\":%s,\"name\":",i,done?"true":"false",r.kind,(unsigned long long)r.start,(unsigned long long)r.end,(unsigned long long)r.thread,r.main?"true":"false",r.ok?"true":"false");quoted(f,r.name);if(r.kind==0){fprintf(f,",\"source_bytes\":%llu,\"device\":%llu,\"metadata_ns\":%llu,\"metadata_truncated\":%s,\"source_sha256\":",(unsigned long long)r.source_bytes,(unsigned long long)r.device,(unsigned long long)r.metadata_ns,r.metadata_truncated?"true":"false");quoted(f,r.source_hash);fputs(",\"options\":",f);fputs(r.options[0]?r.options:"null",f);fputs(",\"functions\":",f);quoted(f,r.functions);}fputs("}\n",f);}fclose(f);if(capturePath){@autoreleasepool{unsigned saved=0;bool ok=!captureOverflow.load();for(unsigned i=0;i<n&&i<limit;++i){auto&r=rows[i];if(!r.captured)continue;NSString*name=[NSString stringWithFormat:@"%s/%s.metal",capturePath,r.source_hash];if(![[NSFileManager defaultManager]fileExistsAtPath:name]){ok=ok&&[r.captured writeToFile:name atomically:YES];++saved;}[r.captured release];r.captured=nullptr;}NSString*receipt=[NSString stringWithFormat:@"{\"saved\":%u,\"bytes\":%llu,\"limit\":%llu,\"complete\":%s}\n",saved,(unsigned long long)captureBytes.load(),(unsigned long long)captureLimit,ok?"true":"false"];[receipt writeToFile:[NSString stringWithFormat:@"%s/capture.json",capturePath]atomically:YES encoding:NSUTF8StringEncoding error:nil];}}}
}
