from pathlib import Path
import fcntl,hashlib,json,os,subprocess,sys,time
P=Path(__file__).resolve().parent;R=P.parents[1]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight,terminate_child_tree
lock=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(P/'bundle-inner.lock')
pre=preflight(13);(P/'app-bundle-final-preflight.json').write_text(json.dumps(pre,indent=2))
start=time.time()
with (P/'app-bundle-final.log').open('x')as f:
 c=subprocess.Popen(['bash','Tools/build_slotstream_mac.sh'],cwd=R,env=os.environ,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 try:rc=c.wait(timeout=900)
 finally:
  if c.poll()is None:terminate_child_tree(c)
assert rc==0
app=R/'.build/Slotstream.app';manifest=json.loads((app/'Contents/Resources/build-inputs.json').read_text())
identity=json.loads((P/'recall-final-identity.json').read_text())
assert manifest['files']==identity['files'] and manifest['dbmd_sha256']==identity['dbmd_sha256']
subprocess.run(['codesign','--verify','--deep','--strict',str(app)],check=True)
files={str(f.relative_to(R)):hashlib.sha256(f.read_bytes()).hexdigest()for f in [app/'Contents/MacOS/Slotstream',app/'Contents/MacOS/mlx.metallib',app/'Contents/Resources/build-inputs.json',app/'Contents/Helpers/slotstream-extract',app/'Contents/Helpers/slotstream-home']}
(P/'app-bundle-final-receipt.json').write_text(json.dumps(dict(passed=True,seconds=time.time()-start,inputs_match_real_model_check=True,built_files=files,scope='Ad-hoc signed local development bundle. Scripted production UI and real runtime checks; not public release qualification.'),indent=2));print('BUNDLE PASS',flush=True)
