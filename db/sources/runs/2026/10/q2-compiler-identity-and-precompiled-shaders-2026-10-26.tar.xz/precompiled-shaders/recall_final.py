from pathlib import Path
import json,os,sys,fcntl,subprocess,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1];V=R/'.build/native-replay-20261023'
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
lock=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);inner=P/'recall-child.lock';os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(inner)
binary=R/'apps/macos/.build/release/slotstream-mac-checks';helper=binary.with_name('slotstream-extract')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs=json.loads(subprocess.check_output([sys.executable,'Tools/mac_build_inputs.py',str(Path.home()/'.dbmd/bin/dbmd')],cwd=R,text=True))
inputs['checks']={str(f.relative_to(R)):sha(f)for f in sorted((R/'apps/macos/Checks').glob('*.swift'))}
inputs['binary_sha256']=sha(binary);inputs['helper_sha256']=sha(helper)
(P/'recall-final-identity.json').write_text(json.dumps(inputs,indent=2))
plan=dict(scope='Final app relevance candidate with byte-bounded Unicode lookbehind; engine sources unchanged. Normal Fast runs original six app workflows plus Fast to Q2 to Fast history preservation. Separate target-only control uses original reduced writing/recall fixture. The answer and seed remain unchanged. Recall now accepts quoted, ID-bound initial retrieval as well as history.search; neither relaxes the required correct answer. Functional checks only, no speed claim.',order=['draft','plain'],budget_gb=10,preflight_gb=13,binary_sha256=sha(binary))
(P/'recall-final-plan.json').write_text(json.dumps(plan,indent=2));events=[]
for arm in plan['order']:
 label='recall-final-'+arm;home=P/(label+'-home');assert not home.exists();preflight(13)
 cmd=[sys.executable,str(P/'quiet_guarded_run.py'),'--label',label,'--budget','10','--timeout','900','--env','SLOTSTREAM_MODEL_LOCK_PATH='+str(inner),'--env','SLOTSTREAM_EXTRACT='+str(helper),'--env','SLOTSTREAM_DFLASH='+('0'if arm=='plain'else'1'),'--env','DYLD_INSERT_LIBRARIES=','--',str(binary),'--real-capabilities','--require-native-schedule','--require-adaptive-replacement','--memory-gb','10','--case',('writing,pdf,ocr_receipt,csv,code_edit,history_recall'if arm=='draft'else'writing,history_recall'),'--home',str(home)]
 if arm=='draft':cmd.append('--switch-q2')
 print('START',arm,flush=True)
 with(P/(label+'-launcher.log')).open('x')as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,cwd=R)
 guard=json.loads((P/(label+'.observer.json')).read_text());out=home/'results.json';d=json.loads(out.read_text())if out.exists()else{};row=dict(arm=arm,command=cmd,exit_code=r.returncode,guard_complete=guard['complete'],guard_error=guard.get('error'),peak_bytes=guard['peak_combined_bytes'],paging=guard['paging'],results=d);events.append(row);(P/'recall-final-ledger.json').write_text(json.dumps(events,indent=2));print('END',arm,r.returncode,d.get('failures'),flush=True)
 if guard.get('error'):raise SystemExit('Functional control stopped on process safety failure')
print('RECALL FINAL COMPLETE',flush=True)
