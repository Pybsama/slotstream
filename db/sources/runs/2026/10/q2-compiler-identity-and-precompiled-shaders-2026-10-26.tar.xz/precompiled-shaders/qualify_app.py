from pathlib import Path
import hashlib,json,re
P=Path(__file__).resolve().parent;R=P.parents[1]
old=json.loads((P/'recall-ledger.json').read_text());new=json.loads((P/'recall-candidate-ledger.json').read_text())
assert len(old)==2 and len(new)==2
assert all(x['exit_code']==1 and x['results']['failures']==['model retrieves a detail outside the initial history window'] and not x['guard_error'] for x in old)
assert all(x['exit_code']==0 and x['guard_complete'] and not x['guard_error'] and x['results']['failures']==[] for x in new)
assert [len(x['results']['runs']) for x in new]==[8,2]
observations=[]
for arm in new:
 for run in arm['results']['runs']:
  found=set(re.findall(r'\[(S[0-9]+)\]',run['answer']));known={x['id']for x in run['excerpts']}
  if found-known:observations.append(dict(arm=arm['arm'],name=run['name'],markers=sorted(found-known),answer=run['answer'],trace=run['trace'],source_excerpts=run['excerpts']))
identity=json.loads((P/'recall-candidate-identity.json').read_text())
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
assert all(sha(R/n)==h for n,h in identity['files'].items())
assert all(sha(R/n)==h for n,h in identity['checks'].items())
assert sha(R/'apps/macos/.build/release/slotstream-mac-checks')==identity['binary_sha256']
assert json.loads((P/'app-check-receipt.json').read_text())['exit_code']==0
result=dict(mechanical_workflow_checks_passed=True,real_jobs=10,baseline_controls_failed_recall=2,candidate_controls_passed_recall=2,model_switches_passed=['Fast to Q2','Q2 to Fast'],peak_combined_gb={x['arm']:x['peak_bytes']/1e9 for x in new},paging={x['arm']:x['paging']for x in new},inputs_still_exact=True,quality_observations=observations,quality_limit='Correct factual recall does not establish perfect output quality. The model emits an unsupported literal [S1] marker without source excerpts in the listed replies. The renderer leaves unknown markers unlinked; source ownership is not broadened. Preserve this as an open output-quality issue alongside earlier strict-format/semantic failures.',scope='10GB functional tests on 48GB Mac; not new timing evidence or qualification on physical16/64GB hardware.')
(P/'app-qualification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
