from pathlib import Path
import json,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1];I=R/'.build/q2-compiler-identity-20261026'
s=(I/'compile_observer.mm').read_text()
s=s.replace('bool metadata_truncated=false;', 'bool metadata_truncated=false; bool precompiled=false; char unit[82]{};')
s=s.replace('const char *path=nullptr;', 'const char *path=nullptr;const char*precompiledDir=nullptr;')
s=s.replace('mach_timebase_info(&scale);@autoreleasepool', 'precompiledDir=getenv("Q2_PRECOMPILED_DIR");mach_timebase_info(&scale);@autoreleasepool')
old=' auto v=originalLibrary(self,cmd,source,options,error);end(r,v!=nil);'
new=r''' id<MTLLibrary>v=nil;
 if(r&&precompiledDir&&*precompiledDir){
  unsigned char hash[CC_SHA256_DIGEST_LENGTH];CC_SHA256(r->options,(CC_LONG)std::strlen(r->options),hash);char optionsHash[65];for(unsigned i=0;i<CC_SHA256_DIGEST_LENGTH;++i)std::sprintf(optionsHash+2*i,"%02x",hash[i]);
  std::snprintf(r->unit,sizeof(r->unit),"%s-%.16s",r->source_hash,optionsHash);
  @autoreleasepool{NSString*file=[NSString stringWithFormat:@"%s/%s.metallib",precompiledDir,r->unit];
   if([[NSFileManager defaultManager]fileExistsAtPath:file]){r->precompiled=true;v=[(id<MTLDevice>)self newLibraryWithFile:file error:error];}
  }
 }
 if(!r||!r->precompiled)v=originalLibrary(self,cmd,source,options,error);end(r,v!=nil);'''
assert s.count(old)==1;s=s.replace(old,new)
s=s.replace('fputs(",\\\"functions\\\":",f);quoted(f,r.functions);', 'fprintf(f,",\\\"precompiled\\\":%s,\\\"unit\\\":",r.precompiled?"true":"false");quoted(f,r.unit);fputs(",\\\"functions\\\":",f);quoted(f,r.functions);')
assert '\\"precompiled\\"'in s
(P/'loader.mm').write_text(s)
(P/'scope.json').write_text(json.dumps(dict(scope='Isolated API substitution experiment only, never production swizzling. Same original executable and original source/options; look up offline libraries by exact source SHA256 plus canonical compile-options identity. Unknown shaders use original JIT; present but unloadable artifacts fail without hidden retry. Artifact hashes verified by driver before launch. On/off wrapper identical except directory. Full exact-logit validation required before timing. After evidence, native implementation must use an explicit Q2-only library provider and retain correct fallback, without altering Fast.',source_sha256=hashlib.sha256(s.encode()).hexdigest(),compiler_run=40337513761,head='3594ace0b2e6e8d8b6b5a5c06164f5918f3a3cd2'),indent=2))
print('Prepared isolated compiled-library substitution probe')
