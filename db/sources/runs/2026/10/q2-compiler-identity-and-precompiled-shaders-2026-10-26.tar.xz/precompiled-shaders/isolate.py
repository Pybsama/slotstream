from pathlib import Path
import json,sys,os,subprocess,fcntl,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1];I=R/'.build/q2-compiler-identity-20261026';N=R/'.build/q2-cold-passes-20261026';M=R/'.build/q2-runtime-row-counts-20261026'
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
sys.path.insert(0,str(R/'.build/native-q2-20261021'));from thermal import wait_nominal
lock=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);inner=P/'isolate-child.lock';os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(inner)
artifact=P/'artifact';result=json.loads((artifact/'result.json').read_text());assert result['complete'];groups={k:[]for k in ['native','custom','mlx']}
for u in result['units']:
 p=artifact/u['library'];assert hashlib.sha256(p.read_bytes()).hexdigest()==u['library_sha256'];label=u['function_label'];group='native'if label=='run'else 'custom'if label.startswith('custom_kernel_slotstream_')else 'mlx';groups[group].append(u)
for k,us in groups.items():
 d=P/('group-'+k);d.mkdir()
 for u in us:os.link(artifact/u['library'],d/(u['id']+'.metallib'))
plan=dict(reason='All174 offline libraries preserve format/kernel checks but fail72full-logit checks,45draft arrays and12selected arrays. Stop speed testing. Validate original JIT with identical wrapper/debug settings, then isolate three disjoint source families. No timing use, no retry selection.',groups={k:[u['id']for u in us]for k,us in groups.items()},order=['jit','native','custom','mlx'],reference='N validation0A exact per-step logits/draft/selection',group_definition='native=single run function from NativeProjection; custom=custom_kernel_slotstream_ prefix; mlx=remaining core or fused MLX libraries')
(P/'isolation-plan.json').write_text(json.dumps(plan,indent=2));ledger=[];assert not(P/'isolation-ledger.json').exists()
ref=json.loads((N/'validation-0-A.json').read_text())['rounds'][0]['steps']
for group in plan['order']:
 label='isolate-'+group;wait_nominal(P/(label+'-cooldown.json'));preflight(18)
 full=[sys.executable,str(I/'quiet_guarded_run.py'),'--label',label,'--budget','15','--timeout','600','--env','SLOTSTREAM_MODEL_LOCK_PATH='+str(inner),'--env','MTL_DEBUG_LAYER=1','--env','DYLD_INSERT_LIBRARIES='+str(P/'loader.dylib'),'--env','Q2_COMPILE_TRACE='+str(P/(label+'-compile.jsonl')),'--env','Q2_PRECOMPILED_DIR='+(''if group=='jit'else str(P/('group-'+group))),'--',str(M/'build-C/candidate/slotstream'),'q2-profile','--fixture',str(N/'first-24.json'),'--output',str(P/(label+'.json')),'--memory-gb','15','--rounds','3','--validate']
 print('START',group,flush=True)
 with(P/(label+'-launcher.log')).open('x')as f:r=subprocess.run(full,stdout=f,stderr=subprocess.STDOUT,cwd=R)
 g=json.loads((I/(label+'.observer.json')).read_text());e=dict(group=group,command=full,exit_code=r.returncode,clean=not g['paging']and not g['external_build_samples']and g['thermal_before']==g['thermal_after']==0,peak_gb=g['peak_combined_bytes']/1e9);ledger.append(e);(P/'isolation-ledger.json').write_text(json.dumps(ledger,indent=2));assert r.returncode==0
 d=json.loads((P/(label+'.json')).read_text());bad=[]
 for rd in d['rounds']:
  for row in rd['steps']:
   for k in ['logits_sha256','actual_guesses','actual_selected']:
    if row[k]!=ref[row['step']][k]:bad.append(dict(round=row['round'],step=row['step'],field=k))
 tr=list(map(json.loads,(P/(label+'-compile.jsonl')).read_text().splitlines()));assert not tr[0]['overflow']and all(x['done']and x['ok']for x in tr[1:]);e.update(mismatches=bad,exact=not bad,precompiled=sum(x.get('precompiled',False)for x in tr[1:]));(P/'isolation-ledger.json').write_text(json.dumps(ledger,indent=2));print('END',group,'clean',e['clean'],'precompiled',e['precompiled'],'mismatch',len(bad),flush=True)
 if group=='jit':assert not bad,'Current JIT does not match saved reference; stop family comparison'
(P/'isolation-result.json').write_text(json.dumps(dict(complete=True,all_clean=all(e['clean']for e in ledger),groups=[dict(group=e['group'],exact=e['exact'],precompiled=e['precompiled'],mismatches=len(e['mismatches']))for e in ledger]),indent=2));print('ISOLATION COMPLETE',flush=True)
