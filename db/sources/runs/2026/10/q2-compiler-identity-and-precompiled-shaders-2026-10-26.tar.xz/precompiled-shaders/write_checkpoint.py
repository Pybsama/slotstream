from pathlib import Path
import json,subprocess
P=Path(__file__).resolve().parent;R=P.parents[1];DB=R/'db';tool='/Users/carlos/.dbmd/bin/dbmd'
ar=json.loads((P/'archive-receipt.json').read_text());a=json.loads((P/'focused-analysis.json').read_text());app=json.loads((P/'app-qualification-final.json').read_text());bundle=json.loads((P/'app-bundle-final-receipt.json').read_text())
assert ar['readback_verified'] and a['gates']['clean'] and not a['retention_gate'] and app['mechanical_workflow_checks_passed'] and bundle['passed']
def call(args):
 p=subprocess.run([tool,*args,'--dir',str(DB),'--json'],check=True,capture_output=True,text=True);print(p.stdout.strip())
def write(path,kind,title,fm,body):
 f=P/(Path(path).name+'.body.md');f.write_text(body.strip()+'\n');args=['write',path,'--type',kind,'--summary',title,'--fm','title='+title,'--body-file',str(f)]
 for k,v in fm.items():args+=['--fm',k+'='+str(v)]
 call(args)
 if not(DB/path).exists():
  found=list(DB.rglob(Path(path).name));assert len(found)==1;call(['rename',str(found[0].relative_to(DB)),path])
run='sources/runs/2026/10/2026-10-26-q2-compiler-and-workflow-checkpoint.md';machine='[[records/machines/macbook-pro-m5-pro-48gb]]'
write(run,'run','Q2 compiler isolation, complete requests and app recall qualification',dict(tool='Native v68, isolated runtime-count candidate, offline Metal fixture, published Splash and native Mac app',command='Archived identity controls; validation and library isolation; request_focused.py ABCSSCBA; recall_control.py; recall_candidate.py; Unicode red/green; recall_final.py; app checks and bundle verification',binary='Exact source, executable, toolchain and bundle identities in archive; production engine preserved',captured_at='2026-10-26',machines=machine,discarded='false'),f'''
[Raw evidence]({Path(ar['path']).name}): {ar['files']} members, {ar['bytes']} bytes, SHA-256 `{ar['sha256']}`. Every member was read back and hash-verified; credential-pattern matches are zero.

Preserves compiler identity observations and sensitivity failures, original source/options, all offline correctness treatments including the failing shared-library group, all 174 compiled libraries with CI/toolchain provenance, the exact Q2-only treatment, the excluded interrupted protocol, the independently frozen eight-arm complete protocol, resource guards, raw outputs and analysis. The first-round observer sensitivity gate fails; these instrumented performance results do not qualify an uninstrumented product.

The complete comparison passes its environmental guards but fails retention and all-request Splash parity. Native production and Fast engine code are unchanged. The manual compilation CI and prior exact-head engine/context CI succeeded at 3594ace0b2e6e8d8b6b5a5c06164f5918f3a3cd2. The compiler run is [40337513761](https://github.com/carloslfu/slotstream/actions/runs/40337513761).

App evidence includes both original failing recall controls, the complete scripted suite, first candidate workflows, the reproduced and fixed Unicode boundary failure, final ten real-model jobs, unsupported citation observations, exact input identities and the verified development bundle. Final peaks are {app['peak_combined_gb']['draft']:.6f} GB with drafting/model switches and {app['peak_combined_gb']['plain']:.6f} GB in the target-only control, each under the explicit 10 GB functional ceiling. No global paging was observed in those final arms. No inference process is retained after the tests.

The wrapper is a completed mixed-evidence checkpoint, not a declaration that every archived experiment passed. All failed or excluded arms retain their original verdicts. Executables, weights, observer dylibs, object files, duplicate library copies and disposable Home internals are excluded; result receipts and the source needed to reconstruct the checks remain.
''')
for path,title,order,body in [
 ('q2-compiler-identity-and-precompiled-shaders','Q2 compilation spikes isolated; offline treatment does not earn integration',1924,'performance.body.md'),
 ('relevant-conversation-excerpts','Relevant conversation excerpts repair tested factual recall; citation quality remains open',1925,'recall.body.md')]:
 write('records/measurements/'+path+'.md','measurement',title,dict(date='2026-10-26',doc='measurements',level=2,order=order,status='measured',machines=machine,runs=f'[[{run[:-3]}]]'),(P/body).read_text())
write('records/decisions/q2-precompilation-stays-experimental.md','decision','Keep Q2 precompilation experimental',dict(decided_on='2026-10-26',status='standing',evidence='[[records/measurements/q2-compiler-identity-and-precompiled-shaders]]',reversible_if='Exact full-model validation and repeatable complete startup/first/subsequent request benefit justify a bounded production implementation within the target hardware envelope.'),'''
Do not integrate the tested offline shader loader, broaden porting, or promote Q2 to Smart on this checkpoint. Preserve the qualified native v68 gains and Fast execution path. Keep the frozen compiler workflow and raw experiments available for reproduction, without adding a production loader or a user-facing optimization switch.

The treatment removes a real source of first-use spikes but fails its repeatability and all-request retention gates. Shared-library substitution also changed full-model results despite passing small kernel checks. The next performance investigation should attribute the larger startup interval across checkpoint authentication, resident conversion, allocation and GPU preparation before proposing another change. Preserve verification and cancellation guarantees.

Native ownership gives control over the stack; it does not guarantee lower latency. Judge an optimization by complete useful work, correctness, resource use and maintenance cost. Include setup and the first answer, preserve negative results, and stop repeating comparisons once the agreed experiment has answered its question. Track model-output quality separately from throughput and successful integration checks. The bounded app retrieval change and its remaining citation defect are recorded in [[records/measurements/relevant-conversation-excerpts]].
''')
call(['index','rebuild'])
call(['log','update','records/measurements/q2-compiler-identity-and-precompiled-shaders.md','-m','Closed bounded compiler investigation: preserve exact source/options evidence, failed shared-library arithmetic and all request arms. Q2-only offline treatment passes frozen logits but fails repeatable retention and Splash parity; no engine change. Profile startup phases next.'])
call(['log','update','records/measurements/relevant-conversation-excerpts.md','-m','Reproduced Fast recall failure with and without drafting. Retained bounded relevant excerpts with Unicode byte-boundary correction, passing context/privacy checks and final real app workflows including model switches. Keep unsupported citation markers and prior quality failures open; no release or Smart promotion.'])
