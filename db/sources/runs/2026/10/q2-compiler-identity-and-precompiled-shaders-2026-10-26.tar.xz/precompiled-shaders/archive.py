from pathlib import Path
import fcntl,hashlib,io,json,os,re,sys,tarfile
P=Path(__file__).resolve().parent;R=P.parents[1];I=R/'.build/q2-compiler-identity-20261026'
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
lock=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(P/'archive-inner.lock');preflight(4)
sha=lambda b:hashlib.sha256(b).hexdigest();allowed={'.md','.py','.swift','.cpp','.h','.hpp','.mm','.metal','.json','.jsonl','.log','.stderr','.stdout','.txt','.patch'};files={}
for prefix,root in [('compiler-identity',I),('precompiled-shaders',P)]:
 for f in root.rglob('*'):
  if not f.is_file()or'__pycache__'in f.parts or f.name.startswith('archive-receipt')or(f.name.startswith('archive')and f.suffix=='.log'):continue
  if any(x.endswith('-home')for x in f.parts)and f.name!='results.json':continue
  keep=f.suffix in allowed or (root==P and f.parent==P/'artifact/libraries'and f.suffix=='.metallib')
  if keep:files[prefix+'/'+str(f.relative_to(root))]=f
for name in ['LICENSE','Licenses/splash-NOTICE.txt','THIRD_PARTY_NOTICES.md','Tools/q2_shader_compilation.py','Tools/fixtures/q2-shader-compilation/fixture.json','Tools/fixtures/q2-shader-compilation/q2-fixed-shaders-20261026.tar.xz','.github/workflows/q2-shader-qualification.yml','apps/macos/Checks/RealCapabilityChecks.swift','apps/macos/Checks/ContextChecks.swift','apps/macos/Runtime/ConversationContext.swift','apps/macos/Runtime/Recall.swift','apps/macos/Runtime/Tools.swift']:
 files['reference/'+name]=R/name
for name,path in [('MLX-LICENSE.txt','.build/checkouts/mlx-swift/LICENSE'),('v68-identity.json','.build/native-replay-20261023/v68/build-identity.json'),('runtime-count-analysis.json','.build/q2-runtime-row-counts-20261026/analysis.json'),('app-v68-identity.json','.build/native-replay-20261023/app-v68-final-identity.json'),('app-v68-fast-results.json','.build/native-replay-20261023/app-v68-real-fast/results.json'),('app-v68-q2-results.json','.build/native-replay-20261023/app-v68-real-q2/results.json'),('MLX-device.cpp','.build/checkouts/mlx-swift/Source/Cmlx/mlx/mlx/backend/metal/device.cpp'),('MLX-custom_kernel.cpp','.build/checkouts/mlx-swift/Source/Cmlx/mlx/mlx/backend/metal/custom_kernel.cpp')]:files['reference/'+name]=R/path
pattern=re.compile(rb'(?:ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{25,}|sk-(?:proj-)?[A-Za-z0-9_-]{30,}|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----)');manifest={}
for n,f in files.items():
 b=f.read_bytes();assert not pattern.search(b),n;manifest[n]=dict(bytes=len(b),sha256=sha(b))
dest=R/'db/sources/runs/2026/10/q2-compiler-identity-and-precompiled-shaders-2026-10-26.tar.xz';assert not dest.exists()
with tarfile.open(dest,'w:xz',preset=3)as t:
 for n,f in sorted(files.items()):
  b=f.read_bytes();info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;t.addfile(info,io.BytesIO(b))
 data=json.dumps(manifest,indent=2).encode();info=tarfile.TarInfo('archive-manifest.json');info.size=len(data);t.addfile(info,io.BytesIO(data))
seen={}
with tarfile.open(dest,'r|xz')as t:
 for m in t:
  b=t.extractfile(m).read()
  if m.name=='archive-manifest.json':assert json.loads(b)==manifest
  else:seen[m.name]=dict(bytes=len(b),sha256=sha(b))
assert seen==manifest and dest.stat().st_size<100_000_000
receipt=dict(path=str(dest.relative_to(R)),files=len(manifest),bytes=dest.stat().st_size,sha256=sha(dest.read_bytes()),readback_verified=True,credential_pattern_matches=0,excluded='Model weights, executables, observer dylibs, object files, duplicate hardlinked shader libraries, pycache and disposable Home internals. Includes original source/options, all controls and failures, full request protocols, 174 compiled treatment libraries with compiler provenance, independent recall controls and restoration receipts.')
(P/'archive-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt,indent=2))
