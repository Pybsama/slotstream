from pathlib import Path
import json,os,sys,fcntl,subprocess,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1];V=R/'.build/native-replay-20261023'
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
lock=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);inner=P/'recall-child.lock';os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(inner)
identity=json.loads((V/'app-v68-final-identity.json').read_text());binary=R/'apps/macos/.build/release/slotstream-mac-checks';helper=binary.with_name('slotstream-extract')
assert hashlib.sha256(binary.read_bytes()).hexdigest()==identity['built_files'][str(binary.relative_to(R))]
assert hashlib.sha256(helper.read_bytes()).hexdigest()==identity['built_files']['.build/Slotstream.app/Contents/Helpers/slotstream-extract']
plan=dict(scope='Separate Fast functional diagnosis, no engine or app change, no speed claim. Reduced frozen workflow keeps original synthetic60-message Home and original writing/admitted-memory setup, then original recall question. Compare normal DFlash with target-only to distinguish a speculation-specific failure. It is not an exact replay of all six previous app jobs or a model-switch qualification.',order=['draft','plain'],budget_gb=10,preflight_gb=13,ceiling='combined process footprint10GB; globalpagingdiagnostic forfunctionalchecks',binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest())
(P/'recall-plan.json').write_text(json.dumps(plan,indent=2));events=[]
for arm in plan['order']:
 label='recall-'+arm;home=P/(label+'-home');assert not home.exists();preflight(13)
 cmd=[sys.executable,str(P/'quiet_guarded_run.py'),'--label',label,'--budget','10','--timeout','900','--env','SLOTSTREAM_MODEL_LOCK_PATH='+str(inner),'--env','SLOTSTREAM_EXTRACT='+str(helper),'--env','SLOTSTREAM_DFLASH='+('0'if arm=='plain'else'1'),'--env','DYLD_INSERT_LIBRARIES=','--',str(binary),'--real-capabilities','--require-native-schedule','--require-adaptive-replacement','--memory-gb','10','--case','writing,history_recall','--home',str(home)]
 print('START',arm,flush=True)
 with(P/(label+'-launcher.log')).open('x')as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,cwd=R)
 guard=json.loads((P/(label+'.observer.json')).read_text());out=home/'results.json';d=json.loads(out.read_text())if out.exists()else{};row=dict(arm=arm,command=cmd,exit_code=r.returncode,guard_complete=guard['complete'],guard_error=guard.get('error'),peak_bytes=guard['peak_combined_bytes'],paging=guard['paging'],results=d);events.append(row);(P/'recall-ledger.json').write_text(json.dumps(events,indent=2));print('END',arm,r.returncode,d.get('failures'),flush=True)
 if guard.get('error'):raise SystemExit('Functional control stopped on process safety failure')
print('RECALL CONTROL COMPLETE',flush=True)
