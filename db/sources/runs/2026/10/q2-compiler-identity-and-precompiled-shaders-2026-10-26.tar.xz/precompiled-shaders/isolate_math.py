from pathlib import Path
import json,sys,os,subprocess,fcntl,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1];I=R/'.build/q2-compiler-identity-20261026';N=R/'.build/q2-cold-passes-20261026';M=R/'.build/q2-runtime-row-counts-20261026'
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
sys.path.insert(0,str(R/'.build/native-q2-20261021'));from thermal import wait_nominal
lock=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);inner=P/'math-child.lock';os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(inner)
result=json.loads((P/'artifact/result.json').read_text());old=json.loads((P/'isolation-plan.json').read_text());groups={k:[]for k in ['q2','expert','matrix','elementwise']}
for u in result['units']:
 label=u['function_label'];g='q2'if u['id']not in old['groups']['mlx']else'expert'if label.startswith('native_down,')else'matrix'if label.startswith(('gemv_','steel_','affine_','block_softmax_'))else'elementwise';groups[g].append(u)
for g,us in groups.items():
 d=P/('math-'+g);d.mkdir()
 for u in us:
  p=P/'artifact'/u['library'];assert hashlib.sha256(p.read_bytes()).hexdigest()==u['library_sha256'];os.link(p,d/p.name)
plan=dict(scope='Correctness-only family isolation. Previous remaining/MLX bucket also includes native expert library. Separately qualify the combined129native-projection/custom libraries for3rounds. Isolate expert, matrix/softmax/affine, elementwise/compiled libraries forone24passround each. No performance or quality-loss claim.',groups={g:[u['id']for u in us]for g,us in groups.items()},order=['q2','expert','matrix','elementwise'],rounds={'q2':3,'expert':1,'matrix':1,'elementwise':1})
(P/'math-plan.json').write_text(json.dumps(plan,indent=2));ledger=[];ref=json.loads((N/'validation-0-A.json').read_text())['rounds'][0]['steps'];assert not(P/'math-ledger.json').exists()
for group in plan['order']:
 label='math-'+group;wait_nominal(P/(label+'-cooldown.json'));preflight(18)
 cmd=[sys.executable,str(I/'quiet_guarded_run.py'),'--label',label,'--budget','15','--timeout','600','--env','SLOTSTREAM_MODEL_LOCK_PATH='+str(inner),'--env','MTL_DEBUG_LAYER=1','--env','DYLD_INSERT_LIBRARIES='+str(P/'loader.dylib'),'--env','Q2_COMPILE_TRACE='+str(P/(label+'-compile.jsonl')),'--env','Q2_PRECOMPILED_DIR='+str(P/label),'--',str(M/'build-C/candidate/slotstream'),'q2-profile','--fixture',str(N/'first-24.json'),'--output',str(P/(label+'.json')),'--memory-gb','15','--rounds',str(plan['rounds'][group]),'--validate']
 print('START',group,flush=True)
 with(P/(label+'-launcher.log')).open('x')as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,cwd=R)
 guard=json.loads((I/(label+'.observer.json')).read_text());e=dict(group=group,command=cmd,exit_code=r.returncode,clean=not guard['paging']and not guard['external_build_samples']and guard['thermal_before']==guard['thermal_after']==0,peak_gb=guard['peak_combined_bytes']/1e9);ledger.append(e);(P/'math-ledger.json').write_text(json.dumps(ledger,indent=2));assert r.returncode==0
 d=json.loads((P/(label+'.json')).read_text());bad=[]
 for rd in d['rounds']:
  for row in rd['steps']:
   for k in ['logits_sha256','actual_guesses','actual_selected']:
    if row[k]!=ref[row['step']][k]:bad.append(dict(round=row['round'],step=row['step'],field=k))
 tr=list(map(json.loads,(P/(label+'-compile.jsonl')).read_text().splitlines()));assert not tr[0]['overflow']and all(x['done']and x['ok']for x in tr[1:]);e.update(mismatches=bad,exact=not bad,precompiled=sum(x.get('precompiled',False)for x in tr[1:]),rounds=plan['rounds'][group]);(P/'math-ledger.json').write_text(json.dumps(ledger,indent=2));print('END',group,'clean',e['clean'],'precompiled',e['precompiled'],'mismatch',len(bad),flush=True)
print('MATH ISOLATION COMPLETE',flush=True)
