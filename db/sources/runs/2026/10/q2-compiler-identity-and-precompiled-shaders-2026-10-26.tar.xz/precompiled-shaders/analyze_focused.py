from pathlib import Path
import json,hashlib
P=Path(__file__).resolve().parent
ledger=json.loads((P/'focused-ledger.json').read_text());assert len(ledger)==8 and ''.join(e['arm']for e in ledger)=='ABCSSCBA'
rows=[]
for e in ledger:
 d=json.loads((P/(e['label']+'.json')).read_text());native=e['arm']!='S';row=dict(label=e['label'],arm=e['arm'],eligible=e['eligible'],load_seconds=d['load_seconds'] if native else d['startup_seconds'],runs=e['runs'])
 if native:
  tr=list(map(json.loads,(P/(e['label']+'-compile.jsonl')).read_text().splitlines()));assert not tr[0]['overflow']and all(x['done']and x['ok']for x in tr[1:]);libs=[x for x in tr[1:]if x['kind']==0]
  row['libraries']=dict(count=len(libs),precompiled=sum(x.get('precompiled',False)for x in libs),cpu_wall_seconds=sum((x['end_ns']-x['start_ns'])/1e9 for x in libs),note='Includes model loading. CPU call wall time may overlap useful work; not exposed GPU idle time.')
  for r,raw in zip(row['runs'],d['runs']):
   assert r['id']==raw['id'];s=raw['stats'];r.update(text_sha256=hashlib.sha256(raw['text'].encode()).hexdigest(),passes=s.get('verifyPasses'),anchors=s.get('adaptiveDraftDepths',[]).count(0),prepared=s.get('nativeExecution',{}).get('projectionPipelines'))
 row['load_plus_first']=row['load_seconds']+row['runs'][0]['request_seconds'];rows.append(row)
by={a:[r for r in rows if r['arm']==a] for a in 'ABCS'};ratios={}
for target in 'ABS':
 ratios['C_over_'+target]=[[by['C'][i]['runs'][j]['request_seconds']/by[target][i]['runs'][j]['request_seconds']for j in range(4)]for i in range(2)]
ratios['C_over_B_load_plus_first']=[by['C'][i]['load_plus_first']/by['B'][i]['load_plus_first'] for i in range(2)]
clean=all(r['eligible']for r in rows)
gates=dict(clean=clean,C_over_S_each_request=all(v<=1.05 for row in ratios['C_over_S']for v in row),C_over_A_each_request=all(v<=1.02 for row in ratios['C_over_A']for v in row),C_over_B_first=all(row[0]<=.95 for row in ratios['C_over_B']),C_over_B_later=all(v<=1.02 for row in ratios['C_over_B']for v in row[1:]))
result=dict(scope='Matched-instrumentation causal substitution study. Not a native uninstrumented production qualification; warm OS compiler caches are not a cold-install test. No speed proof from invalid aggregate or selected subset.',arms=rows,ratios=ratios,gates=gates,retention_gate=all(gates.values()),production_changed=False,Fast_changed=False)
(P/'focused-analysis.json').write_text(json.dumps(result,indent=2))
print('GATES',gates)
for r in rows: print(r['label'],'clean',r['eligible'],'load',round(r['load_seconds'],3),'requests',[round(x['request_seconds'],3)for x in r['runs']],r.get('libraries'))
print('RATIOS',json.dumps(ratios))
