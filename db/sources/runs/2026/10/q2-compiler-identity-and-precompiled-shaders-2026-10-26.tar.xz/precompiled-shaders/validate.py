from pathlib import Path
import json,sys,os,subprocess,fcntl,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1];I=R/'.build/q2-compiler-identity-20261026';N=R/'.build/q2-cold-passes-20261026';M=R/'.build/q2-runtime-row-counts-20261026'
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
sys.path.insert(0,str(R/'.build/native-q2-20261021'));from thermal import wait_nominal
lock=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);inner=P/'validation-child.lock';os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(inner)
artifact=P/'artifact';result=json.loads((artifact/'result.json').read_text());fixture=json.loads((R/'Tools/fixtures/q2-shader-compilation/fixture.json').read_text());assert result['complete']and result['fixture']==fixture and len(result['units'])==174
for unit in result['units']:
 b=(artifact/unit['library']).read_bytes();assert len(b)==unit['library_bytes']and hashlib.sha256(b).hexdigest()==unit['library_sha256']
(P/'artifact-validation.json').write_text(json.dumps(dict(complete=True,units=174,artifact_result_sha256=hashlib.sha256((artifact/'result.json').read_bytes()).hexdigest(),fixture_sha256=fixture['sha256']),indent=2))
binary=M/'build-C/candidate/slotstream';commands=[('formats',7,[str(binary),'q2-format-check','--fixtures',str(R/'bench/q2/formats.json'),'--policy-fixtures',str(R/'bench/q2/verify-budget.json'),'--policy-fixtures',str(R/'bench/q2/verify-budget-complete.json'),'--mix-fixtures',str(R/'bench/q2/mix-quantization.json')]),('kernels',7,[str(binary),'q2-experts-check','--pool-model','smart-q2']),('fixed',15,[str(binary),'q2-profile','--fixture',str(N/'first-24.json'),'--output',str(P/'fixed-validation.json'),'--memory-gb','15','--rounds','3','--validate'])]
ledger=[];assert not(P/'validation-ledger.json').exists()
for label,budget,cmd in commands:
 wait_nominal(P/(label+'-cooldown.json'));preflight(budget+3)
 full=[sys.executable,str(I/'quiet_guarded_run.py'),'--label','precompiled-'+label,'--budget',str(budget),'--timeout','900','--env','SLOTSTREAM_MODEL_LOCK_PATH='+str(inner),'--env','MTL_DEBUG_LAYER=1','--env','DYLD_INSERT_LIBRARIES='+str(P/'loader.dylib'),'--env','Q2_COMPILE_TRACE='+str(P/(label+'-compile.jsonl')),'--env','Q2_PRECOMPILED_DIR='+str(artifact/'libraries'),'--',*cmd]
 print('START',label,flush=True)
 with(P/(label+'-launcher.log')).open('x')as f:r=subprocess.run(full,stdout=f,stderr=subprocess.STDOUT,cwd=R)
 guard=json.loads((I/('precompiled-'+label+'.observer.json')).read_text());e=dict(label=label,command=full,exit_code=r.returncode,clean=not guard['paging']and not guard['external_build_samples']and guard['thermal_before']==guard['thermal_after']==0 and guard['peak_combined_bytes']<=budget*1e9);ledger.append(e);(P/'validation-ledger.json').write_text(json.dumps(ledger,indent=2));assert r.returncode==0
 tr=list(map(json.loads,(P/(label+'-compile.jsonl')).read_text().splitlines()));assert not tr[0]['overflow']and len(tr)-1==tr[0]['count']and all(x['done']and x['ok']for x in tr[1:]);libs=[x for x in tr[1:]if x['kind']==0];e.update(libraries=len(libs),precompiled=sum(x['precompiled']for x in libs),fallback=sum(not x['precompiled']for x in libs));(P/'validation-ledger.json').write_text(json.dumps(ledger,indent=2));print('END',label,e['clean'],'precompiled',e['precompiled'],'fallback',e['fallback'],flush=True)
 if label=='fixed':
  d=json.loads((P/'fixed-validation.json').read_text());ref=json.loads((N/'validation-0-A.json').read_text())['rounds'][0]['steps'];mismatches=[]
  for rd in d['rounds']:
   for row in rd['steps']:
    for k in ['logits_sha256','actual_guesses','actual_selected']:
     if row[k]!=ref[row['step']][k]:mismatches.append(dict(round=row['round'],step=row['step'],field=k,expected=ref[row['step']][k],actual=row[k]))
  e['mismatches']=mismatches;e['exact']=not mismatches;e['slots']=d['plan']['pool_slots'];(P/'validation-ledger.json').write_text(json.dumps(ledger,indent=2));assert not mismatches and e['slots']==4067
(P/'validation-result.json').write_text(json.dumps(dict(complete=True,exact=True,clean=all(e['clean']for e in ledger),units_verified=174,fixed_passes=72,precompiled_fixed=ledger[-1]['precompiled'],fallback_fixed=ledger[-1]['fallback']),indent=2));print('VALIDATION COMPLETE',flush=True)
