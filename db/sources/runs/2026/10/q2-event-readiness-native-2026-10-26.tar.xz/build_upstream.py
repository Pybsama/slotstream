from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess,sys
P=Path(__file__).resolve().parent;R=P.parents[1];D=P/'upstream';W=P.parent/'q2-required-dependencies-20261026/source-reference';F=P.parent/'q2-full-cycle-20261025'
library=Path('/var/folders/d4/t1c8ltbx5s3_11cs9y6gjh8m0000gp/T/slotstream-splash-host-ugnf26pi/source/build/engine/libsplash.a')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(library)==json.loads((F/'upstream/identity.json').read_text())[str(library)]
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()=='1482f6bbc2abf12375332725302019594150b6cb'
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
preflight(10)
with open(f'/tmp/slotstream-model-{os.getuid()}.lock','a')as lock:
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    common=['xcrun','-sdk','macosx','clang++','-std=c++20','-O2','-mmacosx-version-min=26.4','-I'+str(D/'include'),'-I'+str(D),'-I'+str(W/'runtime'),'-I'+str(W/'dev'),'-I'+str(W/'runtime/metal')]
    commands=[['xcrun','clang++','-std=c++20','-O2','-dynamiclib','-fblocks',str(P/'event_stage_observer.mm'),'-framework','Foundation','-framework','Metal','-o',str(P/'event_stage_observer.dylib')],common+['-DSPLASH_RUNTIME_INSTRUMENTATION','-c',str(D/'Runtime.cpp'),'-o',str(D/'Runtime.o')],common+['-fobjc-arc','-DSPLASH_BACKEND_INSTRUMENTATION','-c',str(D/'MetalBackend.mm'),'-o',str(D/'MetalBackend.o')],[x for x in common if x!='-O2']+['-O3','-Wall','-Wextra','-Werror','-c',str(D/'ExpertStore.cpp'),'-o',str(D/'ExpertStore.o')],common+['-fobjc-arc',str(D/'full_cycle.mm'),str(D/'Runtime.o'),str(D/'MetalBackend.o'),str(D/'ExpertStore.o'),str(library),'-framework','Foundation','-framework','Metal','-framework','IOKit','-framework','IOSurface','-o',str(D/'full-cycle')]]
    ledger=[]
    for i,cmd in enumerate(commands):
        with(D/f'build-{i}.log').open('w')as log:r=subprocess.run(cmd,cwd=W,stdout=log,stderr=subprocess.STDOUT)
        ledger.append(dict(command=cmd,exit_code=r.returncode));(D/'build-ledger.json').write_text(json.dumps(ledger,indent=2))
        if r.returncode:raise SystemExit(r.returncode)
    shutil.copy2(F/'upstream/splash.metallib',D/'splash.metallib')
    paths=[D/'Runtime.cpp',D/'MetalBackend.mm',D/'ExpertStore.cpp',D/'DependencyProbe.hpp',D/'full_cycle.mm',D/'include/model/RuntimeInstrumentation.hpp',D/'full-cycle',D/'splash.metallib',library]
    (D/'identity.json').write_text(json.dumps({str(p):sha(p)for p in paths},indent=2));print('Built unchanged-arithmetic Splash dependency diagnostic')
