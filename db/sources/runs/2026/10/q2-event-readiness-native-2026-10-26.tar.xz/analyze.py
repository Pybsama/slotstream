from pathlib import Path
import ast,bisect,collections,csv,json,statistics,struct
P=Path(__file__).resolve().parent;D=P.parent/'q2-required-dependencies-20261026'
scope={'bisect':bisect,'collections':collections,'csv':csv,'PAGE':65536}
exec(compile(ast.Module(body=[n for n in ast.parse((D/'analyze_dependencies.py').read_text()).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))],type_ignores=[]),'analysis-defs','exec'),scope)
rows,footer,Coverage,union,length=map(scope.get,['csv_rows','footer','Coverage','union','length'])
ledger=json.loads((P/'trace-ledger.json').read_text());assert len(ledger)==4
controls={}
for engine in ['N','S']:
 e=[x for x in ledger if x['arm']==engine];values={x['readiness_probe']:statistics.median(r['cycle_seconds']for r in x['rounds']if r['round']>0)for x in e}
 controls[engine]=dict(off=values[False],on=values[True],ratio=values[True]/values[False],within_two_percent=abs(values[True]/values[False]-1)<=.02)
report=[]
for label in ['trace-1-N','trace-2-S']:
 native=label.endswith('N');raw=json.loads((P/(label+'.json')).read_text())
 windows=[(s['start_ns']/1e9,s['end_ns']/1e9,rd['round'],s['step'])if native else(s['start'],s['end'],rd['round'],s['step'])for rd in raw['rounds']for s in rd['steps']];starts=[w[0]for w in windows]
 def window(t):
  i=bisect.bisect_right(starts,t)-1
  return windows[i]if i>=0 and t<windows[i][1]else None
 meta=json.loads(next(P.glob(label+'-dependencies.*.json')).read_text());assert meta['rows']==meta['written']<meta['cap'];scale=meta['numer']/meta['denom']/1e9
 marks=[dict(time=t*scale,thread=th,id=id,address=address,bytes=size,aux0=a0,aux1=a1,kind=kind,index=index)for t,th,id,address,size,a0,a1,kind,index in struct.iter_unpack('<7Q2I',next(P.glob(label+'-dependencies.*.bin')).read_bytes())];marks.sort(key=lambda x:x['time'])
 cp=next(p for p in P.glob(label+'-commands.*.csv')if not any(n in p.name for n in ['events','stages','assignments','pipelines']));footer(cp);commands=collections.defaultdict(list)
 for x in rows(cp):
  c={k:float(x[k])for k in ['submitted','start','end','completed']};c.update(buffer=int(x['buffer']),status=int(x['status']),index=int(x['index']),stages=[]);commands[c['buffer']].append(c)
 for v in commands.values():v.sort(key=lambda x:x['submitted'])
 submitted={k:[c['submitted']for c in v]for k,v in commands.items()}
 def command(buffer,t):
  v=commands.get(buffer,[]);i=bisect.bisect_left(submitted.get(buffer,[]),t)
  return v[i]if i<len(v)else None
 sp=next(P.glob(label+'-commands.*.stages.csv'));foot=footer(sp);assert foot['cpu_initial']==foot['gpu_initial']and foot['cpu_final']==foot['gpu_final'];stages=[]
 for x in rows(sp):
  s=dict(encoded=float(x['encoded']),start=int(x['gpu_start'])/1e9,end=int(x['gpu_end'])/1e9,index=int(x['index']))
  c=command(int(x['buffer']),s['encoded']);assert c is not None;c['stages'].append(s)
  if s['end']>s['start']>0:stages.append(s)
  else:assert not(window(s['encoded'])and window(s['encoded'])[2]>0)
 gpu=Coverage([(s['start'],s['end'])for s in stages])
 ep=next(P.glob(label+'-commands.*.events.csv'));footer(ep);events=[];signals=collections.defaultdict(list);pending=collections.defaultdict(list);waits=[]
 for x in rows(ep):
  e=dict(kind=x['kind'],time=float(x['stamp']),buffer=int(x['buffer']),event=int(x['event']),value=int(x['value']),thread=int(x['thread']));events.append(e)
 events.sort(key=lambda e:e['time'])
 for e in events:
  key=(e['thread'],e['event'],e['value'])
  if e['kind']=='G':signals[(e['event'],e['value'])].append(e)
  if e['kind']=='B':pending[key].append(e)
  elif e['kind']in('A','T'):
   assert pending[key],e;b=pending[key].pop();waits.append(dict(start=b['time'],end=e['time'],event=e['event'],value=e['value'],thread=e['thread'],success=e['kind']=='A'))
 assert not any(pending.values())
 signal_times={k:[e['time']for e in v]for k,v in signals.items()}
 def resolve(event,value,t):
  key=(event,value);v=signals.get(key,[]);i=bisect.bisect_right(signal_times.get(key,[]),t)-1
  if i<0:return dict(error='missing signal')
  e=v[i];c=command(e['buffer'],e['time'])
  if c is None:return dict(error='missing command')
  before=[s for s in c['stages']if s['encoded']<=e['time']and s['end']>s['start']>0];after=[s for s in c['stages']if s['encoded']>e['time']]
  return dict(signal_encoded=e['time'],command_submitted=c['submitted'],command_start=c['start'],command_end=c['end'],command_status=c['status'],command_index=c['index'],last_pre_signal_encoder_end=max((s['end']for s in before),default=None),encoders_after_signal=len(after))
 observations=[];unmatched=[]
 if native:
  groups=[];part=[]
  for m in marks:
   k=m['kind']
   if k==40:part=[m]
   elif k==43:
    if part and part[-1]['kind']==42:part.append(m)
    else:part=[m]
   elif part and(k>=40 or k==1):part.append(m)
   if k!=80 or not part:continue
   w=window(part[0]['time'])
   if w and w[2]>0:
    assert len(set(m['thread']for m in part))==1
    by={m['kind']:m for m in part};assert len(by)==len(part)
    assert 1 in by and 44 in by;groups.append((w,by))
   part=[]
  assert len(groups)==10656,len(groups)
  waits.sort(key=lambda x:x['start']);waitstarts=[w['start']for w in waits]
  for w,g in groups:
   begin=g[40]['time']if 40 in g else g[43]['time'];end=g[44]['time'];th=g[44]['thread'];lo=bisect.bisect_left(waitstarts,begin)
   inside=[]
   while lo<len(waits)and waits[lo]['start']<end:
    x=waits[lo]
    if x['thread']==th and x['end']<=end:inside.append(x)
    lo+=1
   if not inside:
    unmatched.append(dict(round=w[2],step=w[3],reason='no blocking Metal wait in route scope',job_id=g[1]['id']));continue
   # The final completed wait is the last CPU-readiness dependency of this route scope.
   x=max(inside,key=lambda x:x['end']);v=resolve(x['event'],x['value'],x['end'])
   observations.append(dict(round=w[2],step=w[3],job_id=g[1]['id'],scope_start=begin,scope_end=end,wait_start=x['start'],pickup=x['end'],job_start=g[1]['time'],success=x['success'],waits_in_scope=len(inside),**v))
 else:
  ready={};latest={}
  for m in marks:
   if m['kind']==18:ready[m['id']]=m
   elif m['kind']==19:
    assert m['id']in ready;latest[m['thread']]=(ready[m['id']],m)
   elif m['kind']==10:
    w=window(m['time'])
    if not w or w[2]==0:continue
    pair=latest.pop(m['thread'],None)
    if not pair:unmatched.append(dict(round=w[2],step=w[3],reason='no paired readiness marker',job_id=m['id']));continue
    b,e=pair;v=resolve(e['address'],e['bytes'],e['time'])
    observations.append(dict(round=w[2],step=w[3],job_id=m['id'],scope_start=b['time'],scope_end=e['time'],wait_start=b['time'],pickup=e['time'],job_start=m['time'],success=e['aux0']==1,**v))
  assert len(observations)+len(unmatched)==10656,(len(observations),len(unmatched))
 summaries=[]
 for rd in (1,2):
  selected=[x for x in observations if x['round']==rd];valid=[x for x in selected if 'error'not in x and x['success']and x['last_pre_signal_encoder_end']is not None and x['last_pre_signal_encoder_end']<=x['pickup']+1e-6 and x['command_status']==4]
  numbers=collections.defaultdict(list);intervals=collections.defaultdict(list)
  for x in valid:
   end=x['last_pre_signal_encoder_end'];start=max(x['wait_start'],end)
   for key,(a,b)in dict(readiness_tail=(start,x['pickup']),post_pickup_to_job=(x['pickup'],x['job_start']),encoder_end_to_job=(end,x['job_start'])).items():
    assert b>=a-1e-6,(key,x);b=max(a,b);numbers[key].append(b-a);intervals[key].append((a,b))
  stats={k:dict(sum_seconds=sum(v),median_us=statistics.median(v)*1e6,p95_us=sorted(v)[int(.95*(len(v)-1))]*1e6,union_seconds=length(union(intervals[k])),outside_gpu_seconds=sum(max(0,b-a-gpu.between(a,b))for a,b in union(intervals[k])))for k,v in numbers.items()}
  valid_ids={x['job_id']for x in valid};bad=[x for x in selected if x['job_id']not in valid_ids]
  summaries.append(dict(round=rd,observations=len(selected),valid=len(valid),unmatched=[x for x in unmatched if x['round']==rd],invalid_reasons=collections.Counter(x.get('error','missing encoder, failed wait/status, or pickup preceding encoder end')for x in bad),post_signal_encoder_commands=sum(x.get('encoders_after_signal',0)>0 for x in selected),stats=stats))
 result=dict(label=label,rounds=summaries,observations=observations,unmatched=unmatched)
 (P/(label+'-readiness-analysis.json')).write_text(json.dumps(result,indent=2));report.append(dict(label=label,rounds=summaries))
out=dict(scope='Exact event/value and command ancestry. Last pre-signal encoder end is a lower bound on event visibility; readiness tail includes driver signaling plus wakeup/poll pickup, not pure OS wakeup. Same-process encoder coverage does not prove global GPU idle time. Missing/ambiguous dependencies stay visible. No candidate or product-speed claim.',environment_eligible=all(e['eligible']for e in ledger),controls=controls,arms=report)
(P/'analysis.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
