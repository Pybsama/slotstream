from pathlib import Path
import hashlib,json,shutil
P=Path(__file__).resolve().parent;R=P.parents[1];D=P.parent/'q2-required-dependencies-20261026';H=P.parent/'q2-expert-preparation-20261026';F=P.parent/'q2-full-cycle-20261025'
def replace(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b)
s=(R/'.build/q2-sequence-20261025/named_stage_observer.mm').read_text();s=s.replace('#include <unistd.h>','#include <unistd.h>\n#include <pthread.h>')
s=s.replace('uint64_t value=0; };','uint64_t value=0,thread=0; };')
s=s.replace("eventRecords[i]={kind,now(),(uintptr_t)buffer,(uintptr_t)event,value};", "eventRecords[i]={kind,now(),(uintptr_t)buffer,(uintptr_t)event,value,[] {static thread_local uint64_t t=[] {uint64_t v=0;pthread_threadid_np(nullptr,&v);return v;}();return t;}()};")
a='  class_replaceMethod(cls,sel,wrapped,method_getTypeEncoding(method));\n}\n\nconstexpr size_t stageLimit'
b='''  class_replaceMethod(cls,sel,wrapped,method_getTypeEncoding(method));
  SEL waitSel=@selector(waitUntilSignaledValue:timeoutMS:);Method waitMethod=class_getInstanceMethod(cls,waitSel);
  if(waitMethod){const IMP originalWait=method_getImplementation(waitMethod);
    IMP wrappedWait=imp_implementationWithBlock(^BOOL(id event,uint64_t value,uint64_t timeout){
      recordEvent('B',nil,event,value);
      BOOL result=reinterpret_cast<BOOL(*)(id,SEL,uint64_t,uint64_t)>(originalWait)(event,waitSel,value,timeout);
      recordEvent(result?'A':'T',nil,event,value);return result;
    });class_replaceMethod(cls,waitSel,wrappedWait,method_getTypeEncoding(waitMethod));}
}

constexpr size_t stageLimit'''
s=replace(s,a,b)
s=s.replace('kind,stamp,buffer,event,value\\n','kind,stamp,buffer,event,value,thread\\n').replace('"%c,%.9f,%llu,%llu,%llu\\n",r.kind,r.stamp,(unsigned long long)r.buffer,(unsigned long long)r.event,(unsigned long long)r.value);','"%c,%.9f,%llu,%llu,%llu,%llu\\n",r.kind,r.stamp,(unsigned long long)r.buffer,(unsigned long long)r.event,(unsigned long long)r.value,(unsigned long long)r.thread);')
s=replace(s,'    SEL waitSel=@selector(encodeWaitForEvent:value:);', '''    SEL signalSel=@selector(encodeSignalEvent:value:);Method signalMethod=class_getInstanceMethod(cls,signalSel);
    if(signalMethod){const IMP originalSignal=method_getImplementation(signalMethod);
      IMP wrappedSignal=imp_implementationWithBlock(^(id buffer,id<MTLSharedEvent> event,uint64_t value){
        sharedEvent(event);recordEvent('G',buffer,event,value);
        reinterpret_cast<void(*)(id,SEL,id,uint64_t)>(originalSignal)(buffer,signalSel,event,value);
      });class_replaceMethod(cls,signalSel,wrappedSignal,method_getTypeEncoding(signalMethod));}
    SEL waitSel=@selector(encodeWaitForEvent:value:);''')
(P/'event_stage_observer.mm').write_text(s)
U=P/'upstream';U.mkdir(exist_ok=True);shutil.copytree(D/'upstream/include',U/'include',dirs_exist_ok=True)
for name in ['DependencyProbe.hpp','Runtime.cpp','ExpertStore.cpp','full_cycle.mm','splash.metallib']:shutil.copy2(D/'upstream'/name,U/name)
s=(D/'upstream/MetalBackend.mm').read_text()
s=replace(s,'                const bool ready = before && reached(steps.readyEvent, step.ready, before) &&','''                static const bool readinessProbe=std::getenv("SLOTSTREAM_EVENT_READY_PROBE")!=nullptr;
                const uint64_t readinessID=readinessProbe?ssdep::next_id():0;
                ssdep::emit(18,readinessID,reinterpret_cast<uint64_t>((__bridge void*)steps.readyEvent),step.ready);
                const bool ready = before && reached(steps.readyEvent, step.ready, before) &&''')
s=replace(s,'                if (ready && !steps.halted) {','''                ssdep::emit(19,readinessID,reinterpret_cast<uint64_t>((__bridge void*)steps.readyEvent),step.ready,ready?1:0);
                if (ready && !steps.halted) {''')
(U/'MetalBackend.mm').write_text(s)
s=(D/'build_upstream.py').read_text().replace("W=P/'source-reference'", "W=P.parent/'q2-required-dependencies-20261026/source-reference'")
# The source build's preflight precedes its reservation as in the archived driver.
(P/'build_upstream.py').write_text(s)
for name in ['timed-2.json','quiet_guarded_run.py']:shutil.copy2(D/name,P/name)
s=(D/'run.py').read_text();s=s.replace("host=validation or arm in ('n','S');arm=arm.upper();", "probe=validation or arm in ('n','S');host=True;arm=arm.upper();")
s=s.replace(" if not validation:\n  env[-1]", " if True:\n  env[-1]")
s=s.replace("str(R/'.build/q2-sequence-20261025/named_stage_observer.dylib')", "str(P/'event_stage_observer.dylib' if probe else R/'.build/q2-sequence-20261025/named_stage_observer.dylib')")
s=s.replace(" if host:env+=", " if probe:env+=['--env','SLOTSTREAM_EVENT_READY_PROBE=1']\n if host:env+=")
s=s.replace("str(P/'native-build/candidate/slotstream')", "str(P.parent/'q2-expert-preparation-20261026/native-build/candidate/slotstream')")
s=s.replace('dependencies=host,exit_code=rc', 'dependencies=host,readiness_probe=probe,exit_code=rc')
s=s.replace('Both instrumented engines match111full-logithashes,proposals,selectedtokens against own frozen reference;', 'Readiness-instrumented engines match111full-logithashes,proposals,selectedtokens against own frozen reference;')
(P/'run.py').write_text(s)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
plan=dict(scope='Match CPU readiness waits to the exact signaling GPU command and last pre-signal encoder. Existing native preparation instrument reused; Splash adds paired host readiness markers. No new wait, polling, scheduling, arithmetic or Fast production change.',hypothesis='Earlier last-GPU-before-job tails combine event handoff with unrelated operations. Exact event/value/command ancestry can distinguish completion-to-host pickup from metadata/submission work.',protocol='Separate NS full111logit/proposal/token validation under Metalvalidation; then Noff,Non,Son,Soff fixed3rounds (firstwarmup),allhost dependency markers on, only readiness extensions toggled. Existingcopy/read/stage observers in all arms. Two-percent median added-probe sensitivity and clean whole protocol.15GB4067slots,native8192context,BF16/FP32,18GBpreflight. Single reservation, no model retry selection. No speed or parity claim.',limitations='Last pre-signal encoder GPU end is a lower bound on event visibility, not a direct timestamp of visibility. Command completion may include later work; retain both boundaries and reject ambiguous joins. CPU spinning in pinned Splash remains as-is, not ported.',inputs={str(p):sha(p)for p in [H/'native-build/candidate/slotstream',H/'native-build/candidate/build-identity.json',P/'timed-2.json',P/'event_stage_observer.mm',U/'MetalBackend.mm']})
(P/'plan.json').write_text(json.dumps(plan,indent=2));print('Readiness probe prepared; production unchanged')
