from pathlib import Path
import csv,json,struct,subprocess
P=Path(__file__).resolve().parent
assert not subprocess.run(['pgrep','-f',str(P/'native-build/candidate/slotstream')],capture_output=True,text=True).stdout.strip()
def read(path):
    lines=path.read_text().splitlines();foot=dict(x.split('=',1)for x in lines[-1][2:].split())
    assert int(foot['total'])<int(foot['cap']),(path,foot)
    return list(csv.DictReader(x for x in lines if not x.startswith('#'))),foot
def union(xs):
    out=[]
    for a,b in sorted(xs):
        if b<=a:continue
        if not out or a>out[-1][1]:out.append([a,b])
        else:out[-1][1]=max(out[-1][1],b)
    return out
def inter(a,b):
    out=[];i=j=0
    while i<len(a)and j<len(b):
        lo,hi=max(a[i][0],b[j][0]),min(a[i][1],b[j][1])
        if hi>lo:out.append([lo,hi])
        if a[i][1]<b[j][1]:i+=1
        else:j+=1
    return out
def subtract(a,b):
    out=[];j=0
    for lo,hi in a:
        while j<len(b)and b[j][1]<=lo:j+=1
        i=j;cursor=lo
        while i<len(b)and b[i][0]<hi:
            if cursor<b[i][0]:out.append([cursor,min(hi,b[i][0])])
            cursor=max(cursor,b[i][1]);i+=1
        if cursor<hi:out.append([cursor,hi])
    return out
def length(xs):return sum(b-a for a,b in xs)
label='trace-1-on';data=json.loads((P/(label+'.json')).read_text());steps=data['rounds'][-1]['steps']
windows=union((r['start_ns']/1e9,r['end_ns']/1e9)for r in steps)
meta=json.loads((P/(label+'.json.mlx-host.json')).read_text());scale=meta['numer']/meta['denom']/1e9
pm=json.loads((P/(label+'.json.mlx-host.phases.json')).read_text())
assert pm['owner']==meta['owner'] and 0<pm['rows']<pm['cap'] and pm['row_bytes']==32
raw=(P/(label+'.json.mlx-host.phases.bin')).read_bytes();assert len(raw)==pm['rows']*32
names=json.loads((P/'plan.json').read_text())['fields'];groups={k:[]for k in names}
for a,b,tid,kind,reserved in struct.iter_unpack('<3Q2I',raw):
    assert 0<a<=b and tid==pm['owner'] and reserved==0 and str(kind)in names
    groups[str(kind)].append((a*scale,b*scale))
gpu_eval=union((r[0]*scale,r[7]*scale)for r in struct.iter_unpack('<9Q2I',(P/(label+'.json.mlx-host.bin')).read_bytes()))
stages,sfoot=read(next(P.glob(label+'-commands.*.stages.csv')))
assert sfoot['cpu_initial']==sfoot['gpu_initial'] and sfoot['cpu_final']==sfoot['gpu_final']
reads,rfoot=read(next(P.glob(label+'-reads.*.csv')))
gpu=union((int(s['gpu_start'])/1e9,int(s['gpu_end'])/1e9)for s in stages if int(s['gpu_end'])>int(s['gpu_start'])>0)
rd=union((float(r['start']),float(r['end']))for r in reads if int(r['result'])>0);busy=union(gpu+rd)
def metrics(xs):
    u=inter(union(xs),windows)
    return dict(union_seconds=length(u),outside_gpu_and_reads_seconds=length(subtract(u,busy)),overlap_gpu_seconds=length(inter(u,gpu)),overlap_read_seconds=length(inter(u,rd)))
metrics_by_kind={k:dict(name=names[k],count=len(xs),summed_seconds=length(xs),**metrics(xs))for k,xs in groups.items()}
unions={k:union(v)for k,v in groups.items()}
residuals={
    'executor_minus_gpu_eval_scheduler_and_event_wait':subtract(unions['5'],union(gpu_eval+unions['7']+unions['10'])),
    'graph_setup_minus_degree_tape_and_event_construction':subtract(unions['2'],union(unions['3']+unions['4']+unions['8'])),
    'impl_cleanup_outside_prepare_execute_finalize':subtract(unions['1'],union(unions['2']+unions['5']+unions['6'])),
    'sync_wrapper_outside_impl_and_event_wait':subtract(unions['14'],union(unions['1']+unions['10'])),
    'async_wrapper_outside_impl':subtract(unions['13'],unions['1']),
    'all_observed_mlx_scopes':union(gpu_eval+[x for group in groups.values()for x in group]),
}
result=dict(scope='Direct graph/Metal event phases on the model-owner thread. Parent/child scopes overlap. Residuals subtract actual nested intervals; observed CPU waiting and GPU-encoder gaps are not proof of GPU idleness or removable time. Off-owner callback activity is outside this scope.',metadata=pm,fields=metrics_by_kind,residuals={k:metrics(v)for k,v in residuals.items()},cycle_seconds=length(windows),outside_gpu_and_reads_seconds=length(subtract(windows,busy)),outside_all_observed_mlx_gpu_and_reads_seconds=length(subtract(windows,union(busy+residuals['all_observed_mlx_scopes']))),footers=dict(stages=sfoot,reads=rfoot),control=json.loads((P/'trace-ledger.json').read_text()))
(P/'phase-analysis.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items()if k not in ['control','footers']},indent=2))
