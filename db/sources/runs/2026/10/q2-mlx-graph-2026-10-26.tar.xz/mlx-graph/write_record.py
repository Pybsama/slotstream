from pathlib import Path
import json,subprocess
P=Path(__file__).resolve().parent;R=P.parents[1];DB=R/'db';tool='/Users/carlos/.dbmd/bin/dbmd'
def write(path,kind,title,fields,body):
    f=P/(Path(path).name+'.body.md');f.write_text(body.strip()+'\n')
    cmd=[tool,'write',path,'--dir',str(DB),'--json','--type',kind,'--summary',title,'--fm','title='+title,'--body-file',str(f)]
    for k,v in fields.items():cmd+=['--fm',k+'='+str(v)]
    print(subprocess.run(cmd,check=True,capture_output=True,text=True).stdout.strip())
    if not(DB/path).exists():
        found=list(DB.rglob(Path(path).name));assert len(found)==1
        print(subprocess.run([tool,'rename',str(found[0].relative_to(DB)),path,'--dir',str(DB),'--json'],check=True,capture_output=True,text=True).stdout.strip())
archives=[json.loads((P/('archive-receipt-'+part+'.json')).read_text())for part in ['metal-lifecycle','mlx-ownership','mlx-graph']];o=json.loads((P.parent/'q2-mlx-ownership-20261026/analysis.json').read_text());g=json.loads((P/'phase-analysis.json').read_text());c=json.loads((P/'control-analysis.json').read_text())
archive='\n'.join(f"- [Raw archive {i+1}]({Path(a['path']).name}): {a['files']} members, {a['bytes']} bytes, SHA-256 `{a['sha256']}`."for i,a in enumerate(archives))+'\n\nEvery member is read back and hash-checked; credential-pattern matches are zero. Timestamp-only binary records are included; executables, model weights and duplicate full source archives are excluded. The initial 115,940,388-byte combined archive was never registered and is preserved locally; these independently readable protocol archives keep each Git object below the host limit.'
common=dict(tool='Bounded Metal interposition and explicit temporary MLX source probes',command='Archived prepare/build/run/analyze scripts',binary='v68 diagnostic baseline and source-built Splash full-cycle reference; temporary MLX probe identities bind the actual modified dependency sources',captured_at='2026-10-26',machines='[[records/machines/macbook-pro-m5-pro-48gb]]')
l='sources/runs/2026/10/2026-10-26-q2-metal-lifecycle.md';own='sources/runs/2026/10/2026-10-26-q2-mlx-ownership.md';graph='sources/runs/2026/10/2026-10-26-q2-mlx-graph.md'
write(l,'run','Q2 Metal lifecycle observation and excluded comparison',dict(**common,discarded='true'),f"""
{archive}

The `metal-lifecycle/` directory preserves an observer checked with three real
GPU outputs, all command creation APIs and six caller callbacks. Its own
registration is excluded, and disabled host counters record zero rows.
The four-arm native-off/native-on/Splash-on/Splash-off comparison is excluded:
analysis was mistakenly launched before the model protocol ended and consumed
one CPU core during a possible overlap with the first Splash arm. It completed
naturally before the attempted stop. No model was restarted. The native
control also shifts by about twenty percent because its first arm contains a
large early setup interval; it fails the declared sensitivity gate.

Unaffected native original-method service and per-engine token identity checks
remain diagnostic evidence. The raw protocol, initial partial analysis,
contamination receipt and corrected post-model analysis are all preserved.
There is no clean native/Splash speed claim from this protocol.
""")
write(own,'run','Q2 direct MLX buffer-ownership observation',dict(**common,discarded='false'),f"""
{archive}

The `mlx-ownership/` directory binds the exact modified dependency source to its
diagnostic executable. The first build attempt encountered the read-only
SwiftPM source before changing it; the corrected builder restores exact bytes
and modes, the dependency's clean Git state and all default artifacts.
Metal validation preserves all 111 full-logit hashes, real draft proposals and
selected IDs. Four global swap-in pages exclude validation timing only.

Both separate counter-off/on processes pass environmental and physical-memory
guards. Each performs a warmup and one observed round. On/off is
{o['control']['observed_ratio']:.6f}, within the declared two-percent sensitivity
limit. All 594,394 rows are monotonic, nonoverlapping, within capacity and from
one owner. No GPU stage timestamps are missing. Pipeline attribution uses the
actual observed assignments, not inferred C++ operation types. This is
attribution evidence, not a product speed or quality qualification.
""")
write(graph,'run','Q2 MLX graph and wait phases with sensitivity limit',dict(**common,discarded='true'),f"""
{archive}

The `mlx-graph/` directory adds graph preparation, executor, event lifecycle and
actual Metal wait scopes while retaining every operation and wait. All three
modified dependency files are explicitly bound to the binary. Exact Metal
validation again preserves 111 full-logit hashes, proposals and selected IDs;
eight global swap-in pages exclude validation timing only.

The separate warmed counter-off/on pair passes environmental guards, but its
observed ratio {c['on_over_off']:.6f} fails the declared two-percent sensitivity
limit. Its actual intervals locate work; they are not representative timing,
causal savings or product speed evidence. Both rounds in each arm retain exact
proposals and selected tokens. The first offline analyzer had a tuple/list
sorting error; its failure and corrected analysis of the same raw bytes are
preserved. All analysis ran after model processes ended. No timing retry occurs.
""")
table='| MLX GPU-operation scope | Total observed s | Outside observed reads and GPU encoders s |\n| --- | ---: | ---: |\n'
for name,key in [('Whole operation','total'),('Primitive encoding','primitive'),('Captured buffer-owner construction','hold'),('Cleanup registration or split/commit','registration'),('Front setup','front'),('Local cleanup and autorelease-pool tail','tail')]:
    v=o['fields'][key];table+=f"| {name} | {v['union_seconds']:.6f} | {v['outside_gpu_and_reads_seconds']:.6f} |\n"
gt='| Graph/event scope | Calls | Observed s | Outside observed reads and GPU encoders s |\n| --- | ---: | ---: | ---: |\n'
for key in ['2','3','4','8','9','6','7','10']:
    v=g['fields'][key];gt+=f"| {v['name']} | {v['count']:,} | {v['union_seconds']:.6f} | {v['outside_gpu_and_reads_seconds']:.6f} |\n"
body=f"""
Buffer-lifetime bookkeeping does not justify a production rewrite. No runtime
change is retained; v68, Fast, Smart selection and app packaging remain unchanged.
The complete-request parity target remains unmet. This follows
[[records/measurements/q2-forecast-requests-and-mask-reuse]]. Raw evidence and
exclusions are [[{l[:-3]}]], [[{own[:-3]}]] and [[{graph[:-3]}]].

## Scope and controls

Use the existing 111 real draft/target/commit cycles: 84 prompt IDs, widths one
through eight, 472 target rows and 384 retained tokens. Each native process has
4,067 cache slots, a 15 GB physical ceiling, 8,192-token context, BF16
activations/KV and FP32 recurrence. This fixes proposal/target inputs and retained
prefixes, not forecast completion timing or adaptive production behavior.
The original frozen native/Splash references are checked against their archived
member hashes before reuse. Source-built Splash keeps its existing bounded
fixture arena, so that first lifecycle comparison is diagnostic only.

The initial four-arm lifecycle protocol is excluded for accidental concurrent
analysis and an excessive native control shift. Preserve its unaffected native
localization without promoting it to a clean native/Splash result. The two
later native-only probes each use one warmup before the observed round, with
no simultaneous model, build or analysis. Their separate correctness runs
pass under Metal API validation; four/eight global swap-in pages exclude those
validation timings. Both timing pairs pass environment and memory guards.

## Direct buffer ownership and operation setup

The initial unaffected native trace records 639,836 caller completion-handler
registrations. Their original Metal service totals 35.316 ms, with 4.508 ms
outside observed reads and GPU encoders. All five measured command lifecycle
methods together total 175.113 ms, with 30.986 ms outside those intervals.
These calls exclude C++ capture construction and later callback destruction.
Counts alone are not grounds for a scheduler port.

The direct MLX probe then separates those missing ownership costs from primitive
encoding, registration and local cleanup. Its warmed off/on round times are
11.607052 and 11.719758 seconds, a {100*(o['control']['observed_ratio']-1):.2f}%
shift within the declared sensitivity limit. All 594,394 rows are complete and
ordered; 6,080 operations take the split/commit branch. The whole-operation
row contains the other rows and must not be added to them.

{table}
The entire captured-owner construction is only 34 ms, so it cannot account
for the remaining roughly half-second fixed-cycle gap. Event registration,
autorelease-pool removal, a new buffer-owner container and fewer callback counts
do not have a measured case for adoption. The direct primitive interval also
includes allocation, binding and dispatch work; it is not pure CPU utilization.

The pipeline join finds no large single exposed encoding signature. The
repack/gather/gate-up/down signature has about 19.853 ms outside reads/GPU;
417,246 operations have no observed pipeline assignment and together contribute
about 10.797 ms of whole-operation time outside those intervals. No assignment
does not mean no necessary work. Debug buffer labeling is compiled behind
`MLX_METAL_DEBUG`, which the actual release recipe does not enable.

## Graph traversal and actual waiting

The follow-up records 162,066 graph/event scopes. Its warmed off/on passes take
11.890739 and 11.557855 seconds. The {100*(c['on_over_off']-1):.2f}% shift exceeds
the two-percent sensitivity gate, so these are actual instrumented observations,
not representative costs or a speed improvement. Preserve that limitation.
Parent/child scopes in the following table overlap.

{gt}
There are no `scheduler::wait_for_one` calls in this pass: MLX's task-count or
active-memory throttle is not observed blocking it. Executor work outside the
GPU-operation scopes and scheduler/event waits totals 106.563 ms, only 8.299 ms
outside observed reads/GPU. Synchronous wrapper work outside graph evaluation
and the actual Metal wait totals about 0.813 ms.

Of 5.502 seconds inside Metal event waits, 5.042 seconds overlaps observed GPU
encoder intervals. About 0.223 seconds overlaps neither reads nor encoders.
The full wait is not wasted host work, and the uncovered part is not an isolated
wakeup delay. Existing CPU-polling controls and rejected prepared-block tests
remain authoritative; this does not justify busy waiting or another broad port.

Across this graph trace, observed MLX scopes cover about 0.379 of the 0.738 seconds
outside reads/GPU, leaving 0.359 seconds outside these scopes. All-positive-read
overlap includes speculative reads that may not serve the current dependency.
Consequently, uncovered intervals are neither pure idle time nor an upper bound
on potential gains: overlapping work can still delay the critical dependency or
compete for memory bandwidth. Do not add service sums or rule out such effects
solely because a forecast read was active.

## Next focused action and retained state

Do not implement an ownership-container, event-pool or generic graph scheduler
rewrite from these counts. The next comparison should bind each expert readiness
event to its actual demanded records, adopted forecasts and last required read
or copy, then compare that dependency path in native and Splash. Reuse existing
traces where they have the necessary identities; collect only missing identities
otherwise. Distinguish useful adoption from unrelated background reads before
changing reader scheduling. A new candidate still needs a justified mechanism,
exact checks and clean complete requests against v68 and published Splash.

Both probe builds restore the dependency's exact source bytes and modes and its
clean Git state; all 509 production inputs and five default v68 artifacts match.
There is no optional runtime knob, release or Smart promotion. The known Fast
recall and Q2 strict-format failures remain separate; frozen logits do not prove
semantic quality or complete app readiness.
"""
write('records/measurements/q2-mlx-ownership-and-graph.md','measurement','Q2 MLX ownership and graph diagnosis',dict(date='2026-10-26',doc='measurements',level='2',order='1912',machines='[[records/machines/macbook-pro-m5-pro-48gb]]',runs=', '.join('[['+p[:-3]+']]'for p in [l,own,graph]),status='measured'),body)
