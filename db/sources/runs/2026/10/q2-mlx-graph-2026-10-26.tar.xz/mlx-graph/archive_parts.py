from pathlib import Path
import fcntl,hashlib,io,json,os,re,subprocess,sys,tarfile
P=Path(__file__).resolve().parent;R=P.parents[1];files={};sha=lambda b:hashlib.sha256(b).hexdigest()
assert (P/'phase-analysis.json').exists()
assert not subprocess.run(['pgrep','-f',str(P/'native-build/candidate/slotstream')],capture_output=True,text=True).stdout.strip()
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
preflight(4)
reservation=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(reservation,fcntl.LOCK_EX|fcntl.LOCK_NB)
for prefix,root in [('metal-lifecycle',P.parent/'q2-command-lifecycle-20261026'),('mlx-ownership',P.parent/'q2-mlx-ownership-20261026'),('mlx-graph',P)]:
    for f in root.rglob('*'):
        if not f.is_file()or'__pycache__'in f.parts or f.name=='archive-receipt.json':continue
        if f.suffix not in ['.py','.swift','.h','.cpp','.mm','.json','.jsonl','.csv','.log','.stderr','.txt'] and not (f.name.endswith('.mlx-host.bin')or f.name.endswith('.mlx-host.phases.bin')):continue
        files[prefix+'/'+str(f.relative_to(root))]=f
files['reference/v68-build-identity.json']=R/'.build/native-replay-20261023/v68/build-identity.json'
files['reference/full-cycle-build-identity.json']=R/'.build/q2-full-cycle-20261025/native-build/candidate/build-identity.json'
files['reference/LICENSE']=R/'LICENSE'
mlx=R/'.build/checkouts/mlx-swift/Source/Cmlx/mlx'
for n in ['mlx/transforms.cpp','mlx/backend/metal/eval.cpp','mlx/backend/metal/event.cpp','mlx/backend/metal/device.cpp','mlx/backend/metal/utils.h','LICENSE']:files['reference/actual-mlx/'+n]=mlx/n
for n in ['copy_observer.cpp','named_stage_observer.mm']:files['reference/observers/'+n]=R/'.build/q2-sequence-20261025'/n
files['reference/observers/read_observer.cpp']=R/'.build/q2-handoff-20261025/read_observer.cpp'
part=sys.argv[1];assert part in ['metal-lifecycle','mlx-ownership','mlx-graph']
files={n:f for n,f in files.items()if n.startswith(part+'/')or n.startswith('reference/')}
secret=re.compile(rb'(?:ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{25,}|sk-(?:proj-)?[A-Za-z0-9_-]{30,}|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----)');manifest={}
for n,f in files.items():
    b=f.read_bytes();assert not secret.search(b),n;manifest[n]=dict(bytes=len(b),sha256=sha(b))
dest=R/('db/sources/runs/2026/10/q2-'+part+'-2026-10-26.tar.xz');assert not dest.exists();raw=json.dumps(manifest,indent=2).encode()
with tarfile.open(dest,'w:xz',preset=3)as t:
    for n,f in sorted(files.items()):t.add(f,arcname=n,recursive=False)
    info=tarfile.TarInfo('archive-manifest.json');info.size=len(raw);t.addfile(info,io.BytesIO(raw))
seen={}
with tarfile.open(dest,'r|xz')as t:
    for m in t:
        b=t.extractfile(m).read()
        if m.name=='archive-manifest.json':assert json.loads(b)==manifest
        else:seen[m.name]=dict(bytes=len(b),sha256=sha(b))
assert seen==manifest
receipt=dict(path=str(dest.relative_to(R)),files=len(manifest),bytes=dest.stat().st_size,sha256=sha(dest.read_bytes()),readback_verified=True,credential_pattern_matches=0,excluded='Executables, libraries, model weights, pycache, duplicate complete source archives. The .bin members included here contain only bounded timestamp/phase records, not models or executables.')
(P/('archive-receipt-'+part+'.json')).write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt,indent=2))
