// Copyright © 2024 Apple Inc.

#include "mlx/backend/metal/event.h"
#include "mlx/scheduler.h"


#include <cstdint>
extern "C" uint64_t ss_mlx_phase_probe_now();
extern "C" void ss_mlx_phase_probe_record(unsigned,uint64_t);
namespace {
struct SSPhaseScope {
  unsigned kind;uint64_t start;
  explicit SSPhaseScope(unsigned k):kind(k),start(ss_mlx_phase_probe_now()){}
  void finish(){if(start){ss_mlx_phase_probe_record(kind,start);start=0;}}
  ~SSPhaseScope(){finish();}
};
}

namespace mlx::core {

///////////////////////////////////////////////////////////////////////////////
// EventImpl implementations
///////////////////////////////////////////////////////////////////////////////

namespace metal {

EventImpl::EventImpl(Device& d) {
  SSPhaseScope scope(8);
  auto p = new_scoped_memory_pool();
  mtl_event_ = NS::TransferPtr(d.mtl_device()->newSharedEvent());
  if (!mtl_event_) {
    throw std::runtime_error(
        "[Event::Event] Failed to create Metal shared event.");
  }
}

EventImpl::~EventImpl() {
  SSPhaseScope scope(9);
  auto p = new_scoped_memory_pool();
  mtl_event_.reset();
}

void EventImpl::wait(uint64_t value) {
  SSPhaseScope scope(10);
  mtl_event_->waitUntilSignaledValue(value, -1); // never times out
}

void EventImpl::signal(uint64_t value) {
  SSPhaseScope scope(11);
  mtl_event_->setSignaledValue(value);
}

} // namespace metal

///////////////////////////////////////////////////////////////////////////////
// Event implementations
///////////////////////////////////////////////////////////////////////////////

Event::Event(Stream stream) : stream_(stream) {
  event_ = std::make_shared<metal::EventImpl>(metal::device(stream.device));
}

void Event::wait() {
  check_error();
  cast<metal::EventImpl>().wait(value());
  check_error();
}

void Event::wait(Stream stream) {
  if (stream.device == Device::cpu) {
    scheduler::wait_event(stream, *this, [value = value()](Event& self) {
      self.cast<metal::EventImpl>().wait(value);
    });
  } else {
    auto& encoder = metal::get_command_encoder(stream);
    encoder.wait_event(*this, value());
  }
}

void Event::signal(Stream stream) {
  if (stream.device == Device::cpu) {
    scheduler::signal_event(stream, *this, [value = value()](Event& self) {
      self.cast<metal::EventImpl>().signal(value);
    });
  } else {
    auto& encoder = metal::get_command_encoder(stream);
    encoder.signal_event(*this, value());
  }
}

bool Event::is_signaled() const {
  auto* mtl_event = cast<metal::EventImpl>().mtl_event();
  return mtl_event->signaledValue() >= value();
}

std::atomic<Error*>& Event::error() {
  return cast<metal::EventImpl>().error();
}

} // namespace mlx::core
