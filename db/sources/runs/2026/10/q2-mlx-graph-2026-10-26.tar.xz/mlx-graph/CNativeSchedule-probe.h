#pragma once
#include "NativeSchedule.h"
#include "NativeProgram.h"
#include "AdaptiveReplacement.h"

// Temporary MLX host-evaluation diagnostic API, not a production interface.
#ifdef __cplusplus
extern "C" {
#endif
void ss_mlx_eval_probe_begin(void);
int ss_mlx_eval_probe_end(const char* prefix);
#ifdef __cplusplus
}
#endif
