from pathlib import Path
import json,shutil,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1];O=P.parent/'q2-mlx-ownership-20261026'
for n in ['build.py','run.py','quiet_guarded_run.py','timed-2.json','check_restoration.py','CNativeSchedule-probe.h','Q2ProfileCommand-probe.swift']:
    shutil.copy2(O/n,P/n)
base='.build/checkouts/mlx-swift/Source/Cmlx/mlx/mlx/'
extra='''
namespace {
constexpr size_t ss_phase_cap=262144;
struct SSPhaseRow {uint64_t begin,end,thread;uint32_t kind,reserved;};
static_assert(sizeof(SSPhaseRow)==32);
SSPhaseRow ss_phase_rows[ss_phase_cap];size_t ss_phase_next=0;
}
extern "C" uint64_t ss_mlx_phase_probe_now(){
  return ss_probe_recording.load(std::memory_order_acquire) && ss_probe_thread()==ss_probe_owner ? mach_absolute_time() : 0;
}
extern "C" void ss_mlx_phase_probe_record(unsigned kind,uint64_t begin){
  if(!begin)return;
  const uint64_t end=mach_absolute_time();const size_t i=ss_phase_next++;
  if(i<ss_phase_cap)ss_phase_rows[i]={begin,end,ss_probe_owner,kind,0};
}
'''
s=(O/'eval-probe.cpp').read_text();needle='extern "C" void ss_mlx_eval_probe_begin(){';assert s.count(needle)==1
s=s.replace(needle,extra+'\n'+needle+'\n  ss_phase_next=0;')
s=s.replace('if(n>=ss_probe_cap || foreign)return -3;','if(n>=ss_probe_cap || foreign || ss_phase_next>=ss_phase_cap)return -3;')
needle='  fclose(f);return 0;';assert s.count(needle)==1
s=s.replace(needle,'''  fclose(f);
  length=snprintf(path,sizeof(path),"%s.phases.bin",prefix);if(length<0 || size_t(length)>=sizeof(path))return -9;
  f=fopen(path,"wbx");if(!f)return -10;
  const bool phases_ok=fwrite(ss_phase_rows,sizeof(SSPhaseRow),ss_phase_next,f)==ss_phase_next;fclose(f);if(!phases_ok)return -11;
  length=snprintf(path,sizeof(path),"%s.phases.json",prefix);if(length<0 || size_t(length)>=sizeof(path))return -12;
  f=fopen(path,"wx");if(!f)return -13;
  fprintf(f,"{\\"rows\\":%zu,\\"cap\\":%zu,\\"row_bytes\\":32,\\"owner\\":%llu,\\"layout\\":\\"little-endian3uint64+2uint32:begin,end,thread,kind,reserved\\"}\\n",ss_phase_next,ss_phase_cap,(unsigned long long)ss_probe_owner);fclose(f);return 0;''')
(P/'eval-probe.cpp').write_text(s)
header='''
#include <cstdint>
extern "C" uint64_t ss_mlx_phase_probe_now();
extern "C" void ss_mlx_phase_probe_record(unsigned,uint64_t);
namespace {
struct SSPhaseScope {
  unsigned kind;uint64_t start;
  explicit SSPhaseScope(unsigned k):kind(k),start(ss_mlx_phase_probe_now()){}
  void finish(){if(start){ss_mlx_phase_probe_record(kind,start);start=0;}}
  ~SSPhaseScope(){finish();}
};
}
'''
s=(R/(base+'transforms.cpp')).read_text();(P/'transforms-original.cpp').write_text(s)
anchor='array eval_impl(std::vector<array> outputs, bool async) {'
s=s.replace(anchor,header+'\n'+anchor+'\n  SSPhaseScope whole(1);\n  SSPhaseScope prepare(2);',1)
pairs=[('    // Record the degree of each input','    SSPhaseScope degree(3);\n    // Record the degree of each input'),('    // Build the tape in BFS order with a width limit','    degree.finish();\n    SSPhaseScope tape_build(4);\n    // Build the tape in BFS order with a width limit'),('  std::set<Stream> open_streams;','  prepare.finish();\n  SSPhaseScope execute(5);\n  std::set<Stream> open_streams;'),('  // Signal the event in its stream','  execute.finish();\n  SSPhaseScope finalization(6);\n  // Signal the event in its stream'),('void async_eval(std::vector<array> outputs) {','void async_eval(std::vector<array> outputs) {\n  SSPhaseScope outer(13);'),('void eval(std::vector<array> outputs) {','void eval(std::vector<array> outputs) {\n  SSPhaseScope outer(14);')]
for old,new in pairs:assert s.count(old)==1,(old,s.count(old));s=s.replace(old,new)
assert s.count('scheduler::wait_for_one();')==2
s=s.replace('scheduler::wait_for_one();','{ SSPhaseScope wait(7); scheduler::wait_for_one(); }')
(P/'transforms-probe.cpp').write_text(s)
s=(R/(base+'backend/metal/event.cpp')).read_text();(P/'event-original.cpp').write_text(s)
s=s.replace('namespace mlx::core {',header+'\nnamespace mlx::core {',1)
for old,kind in [('EventImpl::EventImpl(Device& d) {',8),('EventImpl::~EventImpl() {',9),('void EventImpl::wait(uint64_t value) {',10),('void EventImpl::signal(uint64_t value) {',11)]:
    assert s.count(old)==1;s=s.replace(old,old+'\n  SSPhaseScope scope('+str(kind)+');')
(P/'event-probe.cpp').write_text(s)
rep={base+'backend/metal/eval.cpp':'eval-probe.cpp',base+'transforms.cpp':'transforms-probe.cpp',base+'backend/metal/event.cpp':'event-probe.cpp','Sources/CNativeSchedule/include/CNativeSchedule.h':'CNativeSchedule-probe.h','Sources/slotstream-cli/Q2ProfileCommand.swift':'Q2ProfileCommand-probe.swift'}
s=(R/'Tools/build_identity.py').read_text();needle='    if any(p.is_symlink() for p in candidates):';assert s.count(needle)==1
s=s.replace(needle,'    # Explicit diagnostic dependency overrides, archived with this binary.\n'+''.join('    candidates.append(root/'+repr(n)+')\n'for n in rep if n.startswith('.build/'))+needle)
(P/'build_identity-probe.py').write_text(s);rep['Tools/build_identity.py']='build_identity-probe.py'
(P/'replacements.json').write_text(json.dumps(rep,indent=2))
s=(P/'build.py').read_text();s=s.replace("assert identity['source'][name]==hashlib.sha256((P/'eval-probe.cpp').read_bytes()).hexdigest()","for name,f in rep.items():assert identity['source'][name]==hashlib.sha256((P/f).read_bytes()).hexdigest()")
(P/'build.py').write_text(s)
plan=dict(scope='Following the negative buffer-ownership localization, directly separate MLX graph degree/tape preparation, executor bookkeeping, finalization and actual event waits. Keep all arithmetic, lifetimes, order and waits. Temporary diagnosis only; Fast and production remain unchanged.',fields={'1':'whole eval_impl including local cleanup','2':'setup and graph preparation','3':'degree DFS','4':'BFS tape build and local cache cleanup','5':'execution loop, includes GPU eval and scheduler waits','6':'event signals and stream finalization','7':'scheduler wait_for_one','8':'event construction','9':'event destruction','10':'actual Metal waitUntilSignaledValue','11':'CPU event signal','13':'async_eval wrapper','14':'synchronous eval wrapper'},gates=dict(configuration='Existing111realcycles,4067slots,15GBphysical,8192nativecontext,BF16KV/activation,FP32recurrence. Preflight18GB; no overlapping model/build/analysis.',validation='111full-logithashes,realproposals,selectedtokens,Metalvalidation; scope rows bounds and one owner. Async callback-thread activity is outside these main-owner scopes.',timing='Separate off/on processes, one warmup plus one measured pass. No repeated retry on exclusion. Two percent sensitivity. Probe durations are not product speed. Parent/child intervals must not be added.'),source_hashes={n:hashlib.sha256((P/f).read_bytes()).hexdigest()for n,f in rep.items()})
(P/'plan.json').write_text(json.dumps(plan,indent=2));print('prepared graph-owner diagnostic')
