from pathlib import Path
import json,subprocess,fcntl,os,hashlib
P=Path(__file__).resolve().parent
s=(P/'named_stage_observer.mm').read_text().replace('#include <sys/mman.h>','#include <sys/mman.h>\n#include <execinfo.h>\n#include <dlfcn.h>')
s=s.replace('Record records[limit];', '''constexpr size_t stackLimit=8192;
struct StackRecord { size_t command=0; int depth=0; void* frames[32]={}; };
StackRecord stackRecords[stackLimit];std::atomic<size_t> stackNext{0}, selectedCommits{0};
void captureStack(size_t command){if(!windowActive() || selectedCommits.fetch_add(1)%8)return;size_t i=stackNext.fetch_add(1);if(i>=stackLimit)return;stackRecords[i].command=command;stackRecords[i].depth=backtrace(stackRecords[i].frames,32);}
void dumpStacks(const char* prefix){char path[4096];snprintf(path,sizeof(path),"%s.%d.stacks.csv",prefix,getpid());FILE*f=fopen(path,"wx");if(!f)return;fprintf(f,"sample,command,frame,address,image_base,symbol_address,symbol,image\\n");const size_t n=stackNext.load();for(size_t i=0;i<std::min(n,stackLimit);++i)for(int j=0;j<stackRecords[i].depth;++j){void* p=stackRecords[i].frames[j];Dl_info info{};dladdr(p,&info);fprintf(f,"%zu,%zu,%d,%llu,%llu,%llu,\\"%s\\",\\"%s\\"\\n",i,stackRecords[i].command,j,(unsigned long long)p,(unsigned long long)info.dli_fbase,(unsigned long long)info.dli_saddr,info.dli_sname?:"",info.dli_fname?:"");}fprintf(f,"# total=%zu cap=%zu selected_commits=%zu\\n",n,stackLimit,selectedCommits.load());fclose(f);}
Record records[limit];''')
s=s.replace('  dumpStages(path);','  dumpStacks(path);\n  dumpStages(path);',1).replace('    const size_t i=next.fetch_add(1);','    const size_t i=next.fetch_add(1);captureStack(i);',1)
(P/'stack_stage_observer.mm').write_text(s)
lock=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
cmd=['xcrun','clang++','-std=c++17','-O2','-framework','Foundation','-framework','Metal','-dynamiclib',str(P/'stack_stage_observer.mm'),'-o',str(P/'stack_stage_observer.dylib')]
r=subprocess.run(cmd,capture_output=True,text=True,timeout=90);(P/'stack-build.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stderr
s=(P/'run_trace.py').read_text().replace("a.order=='AC'","a.order=='A'").replace("P/'named_stage_observer.dylib'","P/'stack_stage_observer.dylib'")
s=s.replace('Request timestamps plus identical read and named Metal encoder observers.', 'Native-only follow-up: named Metal/read observer plus sampled CPU commit backtraces, one in8duringtimedrequests, bound8192stacks. Diagnose zero-duration command spans and submission origins, not speed. No new runtime candidate or parity comparison.')
(P/'run_stacks.py').write_text(s);compile(s,'run_stacks.py','exec')
env={k:v for k,v in os.environ.items()if not k.startswith(('SLOTSTREAM_','MLX_','DYLD_','Q2_TRACE_'))};env.update(DYLD_INSERT_LIBRARIES=str(P/'stack_stage_observer.dylib'),SLOTSTREAM_METAL_OBSERVER=str(P/'stack-check'))
r=subprocess.run([str(P/'named-stage-check')],env=env,capture_output=True,text=True,timeout=30);(P/'stack-check.log').write_text(r.stdout+r.stderr);assert r.returncode==0 and 'ERROR'not in r.stderr
assert next(P.glob('stack-check.*.stacks.csv')).stat().st_size>200
(P/'stack-build.json').write_text(json.dumps(dict(passed=True,command=cmd,byte_check_pass=True,scope='SampledCPUbacktraceofrealcommits,notpowerwork.NoSpeedQualification.',source_sha256=hashlib.sha256((P/'stack_stage_observer.mm').read_bytes()).hexdigest()),indent=2));print('STACK_CHECK_PASS')
