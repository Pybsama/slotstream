from pathlib import Path
import subprocess,json,os,csv,fcntl,hashlib
P=Path(__file__).resolve().parent
lock=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
s=(P/'named_stage_check.mm').read_text().replace('#include <cstdio>','#include <cstdio>\n#include <unistd.h>\n#include <fcntl.h>')
s=s.replace('for(int j=0;j<2;++j){','for(int j=0;j<3;++j){int fd=open(getenv("Q2_TRACE_WINDOW"),O_WRONLY);uint32_t active=j==1; if(fd<0 || pwrite(fd,&active,4,0)!=4)return 5;close(fd);')
(P/'window_check.mm').write_text(s)
cmd=['xcrun','clang++','-std=c++17','-O2','-framework','Foundation','-framework','Metal',str(P/'window_check.mm'),'-o',str(P/'window-check')]
r=subprocess.run(cmd,capture_output=True,text=True);assert r.returncode==0,r.stderr
flag=P/'window-check.bin';flag.write_bytes(bytes(4096))
env={k:v for k,v in os.environ.items()if not k.startswith(('SLOTSTREAM_','MLX_','DYLD_','Q2_TRACE_'))};env.update(DYLD_INSERT_LIBRARIES=str(P/'named_stage_observer.dylib'),SLOTSTREAM_METAL_OBSERVER=str(P/'window-check'),Q2_TRACE_WINDOW=str(flag))
r=subprocess.run([str(P/'window-check')],env=env,capture_output=True,text=True,timeout=20);(P/'window-check.log').write_text(r.stdout+r.stderr);assert r.returncode==0 and 'ERROR'not in r.stderr
f=next(P.glob('window-check.*.stages.csv'));rows=list(csv.DictReader(x for x in f.read_text().splitlines()if not x.startswith('#')));assert len(rows)==1 and int(rows[0]['gpu_end'])>int(rows[0]['gpu_start'])>0
(P/'window-check.json').write_text(json.dumps(dict(passed=True,commands=[cmd],all_three_outputs_exact=True,recorded_active_stages=1,scope='One active of three correct encoders; shared flag changes in same process, observer writes only selected stage counters.',source_sha256=hashlib.sha256((P/'named_stage_observer.mm').read_bytes()).hexdigest()),indent=2));print('WINDOW_PASS')
