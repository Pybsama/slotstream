from pathlib import Path
import json,subprocess
P=Path(__file__).resolve().parent;R=P.parents[1];DB=R/'db';tool='/Users/carlos/.dbmd/bin/dbmd'
def write(path,kind,title,fields,body):
 f=P/(Path(path).name+'.body.md');f.write_text(body.strip()+'\n')
 cmd=[tool,'write',path,'--dir',str(DB),'--json','--type',kind,'--summary',title,'--fm','title='+title,'--body-file',str(f)]
 for k,v in fields.items():cmd+=['--fm',k+'='+str(v)]
 print(subprocess.run(cmd,check=True,capture_output=True,text=True).stdout.strip())
 if not(DB/path).exists():
  found=list(DB.rglob(Path(path).name));assert len(found)==1
  print(subprocess.run([tool,'rename',str(found[0].relative_to(DB)),path,'--dir',str(DB),'--json'],check=True,capture_output=True,text=True).stdout.strip())
a=json.loads((P/'archive-receipt.json').read_text());submission=json.loads((P/'submission-analysis.json').read_text())
assert len(submission['arms'])==6
source='sources/runs/2026/10/2026-10-25-q2-ordinary-request-and-submission-diagnosis.md'
write(source,'run','Q2 ordinary-request frequency, overlap and submission controls',dict(tool='Timestamp-only native CLI, published Splash, bounded read/Metal observations and sampled CPU commit stacks',command='Exact commands, protocols, cases, sources, identities, guards and analyses in archive',binary='Production v68 runtime with diagnostic CLI only; published Splash1.4.0; per-process cap ablation uses identical native executable',captured_at='2026-10-25',machines='[[records/machines/macbook-pro-m5-pro-48gb]]',discarded='true'),f'''
Evidence: [{Path(a['path']).name}]({Path(a['path']).name}), {a['files']} files,
{a['bytes']} bytes, SHA-256 `{a['sha256']}`. Every archive member is read back
and its hash verified. Credential-pattern screening reports no matches.
Executable binaries and model weights are excluded; source archives and build
identities remain. All runtime source and default artifact hashes equal v68.

Discarded is true because the timestamp-only ACCA and later submission-cap
ABCCBA both have whole-protocol paging exclusions. The read/Metal pair and
sampled-stack follow-up pass environmental guards, but remain instrumented
attribution, never speed qualifications. Each original verdict and raw arm
is preserved. No favorable replacement retry is made.

Every complete request uses identical prompt IDs, two warmups followed by code
and prose, 384-token limits, normal adaptive verification, greedy sampling,
8,192 context, BF16 KV, FP32 state and 4,067 actual slots. The physical ceiling
is 15 GB, with an independent 18 GB reclaimable preflight and 1 GB remaining
headroom guard. Splash includes frontend and engine memory. One global model
reservation covers each protocol. Published Splash retains CPU polling, has no
GPU spin library and allows idle sleep. No other application is stopped.

The native CLI first adds only request-boundary timestamps. The later trace
CLI additionally writes a four-byte diagnostic flag before and after timed
requests, limiting Metal counters to those windows. Neither attaches a model
inference observer. The original runtime and CLI are restored after building.
A passive whole-device frequency observer samples at 200 ms. The named-stage
observer and read observer have bounded storage, checked counts and deferred
output. An isolated three-encoder byte check proves the active-window gate.

Two rejected observer preparations are retained: too many counter buffers fail
allocation, and a larger per-buffer sample count exceeds the device's reported
32,768-byte limit. No model runs use those failed preparations. The working
observer uses its original 32 buffers and 4,096 samples per buffer. Splash has
187 zero-timestamp encoder observations; they are retained as missing values
and bounded by their successfully completed enclosing command spans, rather
than counted as zero execution. All named pipeline assignments resolve.

The native-only follow-up samples one in eight real command submissions, with
an 8,192-stack bound. All 6,492 samples are retained and symbolicated against
the exact diagnostic executable. This identifies origins, not saved time.
The archive also contains a reanalysis of earlier command-threshold controls,
including their raw command timelines, exact outputs and original guards.

The final ABCCBA uses the timestamp-only executable with no injected GPU/read
or stack observer. Only B sets MLX's automatic split thresholds to 100,000
operations and 65,536 MiB in that isolated Q2 process. Physical memory guards
remain unchanged. This is a structural diagnostic, not a proposed global
setting, Fast change or production optimization. Full capped streams complete;
this is not semantic task quality or app readiness.
''')
rows=[]
for arm in submission['arms']:
 vals=[next(r['request_seconds']for r in arm['rows']if r['id']==case)for case in ['timed-2','timed-3']]
 rows.append(f"| {arm['label'].removeprefix('ordinary-submit-15-')} | {vals[0]:.3f} | {vals[1]:.3f} | {'pass' if arm['eligible'] else 'excluded'} |")
table='\n'.join(rows)
ratios=submission['median_ratios']
write('records/measurements/q2-ordinary-request-and-submission-diagnosis.md','measurement','Q2 ordinary requests and submission boundaries',dict(doc='measurements',order=1903,level=2,date='2026-10-25',status='measured',machines='[[records/machines/macbook-pro-m5-pro-48gb]]',runs='[['+source[:-3]+']]'),f'''
Q2 parity remains unachieved. No production change is retained and Fast remains
unchanged. This follows [[records/measurements/q2-order-executor-and-validation]];
raw observations, instrumentation checks and exclusions are preserved in
[[{source[:-3]}]].

## Fixed-pass behavior does not establish ordinary-request behavior

A timestamp-only ACCA compares normal complete requests under the same 15 GB
ceiling, actual cache capacity, context and precision. Native timed-request
frequencies range from about 1,144 to 1,184 MHz, while Splash ranges from about
1,101 to 1,189 MHz. The much lower native clock seen in the earlier fixed-pass
control does not carry directly into these ordinary requests. Frequency is a
whole-device observation, not arithmetic utilization or a proven cause.

The whole ACCA timing aggregate is excluded by paging in C1 and A3. Its raw
request times cannot qualify parity. Both engines also produce different texts
across their own repeated adaptive requests. Pass counts therefore measure
actual work but do not isolate an efficiency defect by themselves.

Splash's public speculation `cycles` counter excludes anchor-only passes;
native's verification counter includes them. Use the change in Splash's target
scheduler batch counter, checked against 48 expert-layer loads per batch.
Comparing the two public cycle counters directly would miscount the work.
No product counter or controller is changed.

## Ordinary-request overlap observation

A separate native/Splash pair uses bounded read and named Metal encoder
observations. Both pass the environmental guards. It remains an instrumented
diagnostic with different adaptive work, not an eligible speed comparison.

| Timed request | Native encoder union s | Splash encoder union s | Native outside both reads and encoders s | Splash outside both s |
| --- | ---: | ---: | ---: | ---: |
| Code | 6.404 | 6.465–6.484 | 1.167 | 0.443–0.462 |
| Prose | 7.010 | 6.916–6.934 | 1.199 | 0.484–0.502 |

Splash ranges bound missing encoder timestamps by their completed enclosing
command spans. The bounds are conservative. Encoder intervals include hardware
scheduling and stalls; neither their sum nor their complement is pure compute
or recoverable CPU delay. Reads overlap encoder execution and each other.
Native's read time outside encoder intervals is about 5.10 and 5.40 seconds,
versus Splash's upper bounds of about 4.59 and 5.02 seconds. These are observed
interval unions, not additive syscall service times.

The largest native gap group precedes expert repack/gather/execution. Its
portion outside observed reads totals about 0.42–0.44 seconds per request.
Smaller gaps precede draft graph execution and per-token sampling. This locates
further investigation at host preparation and handoff, but does not establish
that all of those gaps are removable. Unequal work and higher native observer
call counts limit differential attribution.

## Submission origin and a bounded control

Native's two traced timed requests contain 2,506 and 2,978 successful command
submissions with zero-length public GPU spans and no observed compute-encoder
creation or host-readiness wait. That is not proof that they are useless: the
observer does not capture every event signal or blit.

A clean native-only sampled-stack follow-up identifies 763 sampled zero-span
submissions. Of those, 718 originate in `NativeExpertSchedule.submit`, through
MLX asynchronous evaluation's finalizer. MLX can split the real work at its
automatic thresholds and then submit a separate completion signal. Removing
that signal without preserving completion, error and resource ownership is
unsafe.

Reanalysis of the earlier fixed-work control confirms that raising both split
thresholds reduces command count from 22,393 to 16,427 and zero-span submissions
from 2,764 to zero. Its verification time remains approximately 11.91 versus
11.85 seconds. This is a structural observation, not a paired speed win. It
does not justify a global cap change.

One new untraced ABCCBA tests whether that reduction helps ordinary requests.
A uses production thresholds, B uses high thresholds only in its isolated Q2
process, and C is published Splash. All use the same native runtime where
applicable. The protocol has a paging exclusion and is retained in full:

| Arm | Code request s | Prose request s | Environmental guard |
| --- | ---: | ---: | --- |
{table}

Median B/A ratios are {ratios['timed-2']['B_over_A']:.4f} for code and
{ratios['timed-3']['B_over_A']:.4f} for prose. These excluded raw values cannot
qualify a speed claim, and the paired directions must be assessed together.
No threshold setting or production change is adopted. Do not repeat the
protocol merely to find a favorable aggregate.

## Remaining work

The ordinary-request observations narrow the next question to useful host
work around expert handoff and draft preparation. Measure CPU copying and
preparation against the already observed read/GPU intervals in ordinary
requests, without treating overlapped service time as delay. Establish the
avoidable part before another reader architecture or prepared-block port.
Do not transfer the fixed-pass clock gap to the product, count unequal cycle
metrics as equal work, or remove completion signals because their GPU span is
zero. Native language choice still does not promise parity.

All 509 runtime inputs and five default build artifacts match v68. Capped
streams, memory and instrumentation checks pass within their declared scope;
no new semantic quality or complete app qualification follows. Existing Fast
recall failures and the Q2 strict-format failure remain separate gates in
[[records/measurements/native-prepared-execution]] and
[[records/measurements/q2-continuation-and-copy-diagnosis]].
''')
