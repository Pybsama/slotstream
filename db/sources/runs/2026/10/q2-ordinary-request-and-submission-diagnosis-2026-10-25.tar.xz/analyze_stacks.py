from pathlib import Path
import csv,json,collections,subprocess
P=Path(__file__).resolve().parent
f=next(P.glob('ordinary-stacks-15-0-A-commands.*.stacks.csv'));prefix=f.name[:-len('.stacks.csv')]
def rows(f):
 with f.open()as h:return list(csv.DictReader(s for s in h if not s.startswith('#')))
cc={int(c['index']):c for c in rows(P/(prefix+'.csv'))};ss=rows(f);samples=collections.defaultdict(list)
for s in ss:samples[int(s['command'])].append(s)
for vv in samples.values():vv.sort(key=lambda x:int(x['frame']))
# Symbolize local PIE frames against the exact diagnostic executable, using observed image base.
native=[s for s in ss if Path(s['image']).name=='slotstream'];bases={s['image_base']for s in native};assert len(bases)==1
binary=P/'native-trace-build/candidate/slotstream';addresses=sorted({s['address']for s in native},key=int)
symbols={}
for start in range(0,len(addresses),100):
 part=addresses[start:start+100];cmd=['atos','-o',str(binary),'-l',hex(int(next(iter(bases)))),*[hex(int(a))for a in part]]
 result=subprocess.run(cmd,capture_output=True,text=True,check=True);lines=result.stdout.splitlines();assert len(lines)==len(part),(lines,len(part));symbols.update(zip(part,lines))
groups=collections.defaultdict(list)
for command,frames in samples.items():
 c=cc[command];zero=float(c['start'])==float(c['end']);names=[]
 for s in frames:
  if Path(s['image']).name=='slotstream':names.append(symbols[s['address']])
 key=(zero,tuple(names));groups[key].append(command)
report=sorted([dict(zero_gpu_span=k[0],frames=list(k[1]),samples=len(v),command_examples=v[:5])for k,v in groups.items()],key=lambda x:(not x['zero_gpu_span'],-x['samples']))
foot=f.read_text().splitlines()[-1];meta=dict(x.split('=',1)for x in foot[2:].split());assert int(meta['total'])<int(meta['cap'])
out=dict(scope='Sampled1in8commitsduringtimedrequests. Callstacks identify origin, not saved time. Zero-length GPU spans are successful event-only/unknown-work observations, not proof removal is safe. Exact diagnostic executable symbolication.',metadata=meta,sampled_commands=len(samples),zero_gpu_span_samples=sum(g['samples']for g in report if g['zero_gpu_span']),groups=report,symbols=symbols)
(P/'stack-analysis.json').write_text(json.dumps(out,indent=2))
print(json.dumps({k:v for k,v in out.items()if k not in ['groups','symbols']},indent=2))
for g in report[:12]:print(g['zero_gpu_span'],g['samples'],'\n'+'\n'.join(g['frames'][:15]))
