from pathlib import Path
import json,hashlib,shutil,subprocess,fcntl,os,sys
P=Path(__file__).resolve().parent;R=P.parents[1];OLD=R/'.build/q2-sequence-20261025'
s=(OLD/'named_stage_observer.mm').read_text().replace('constexpr size_t stageLimit=65536;','constexpr size_t stageLimit=262144;')
assert 'stageLimit=262144' in s
(P/'named_stage_observer.mm').write_text(s)
shutil.copy2(OLD/'named_stage_check.mm',P/'named_stage_check.mm')
shutil.copy2(R/'.build/q2-handoff-20261025/read_observer.cpp',P/'read_observer.cpp')
s=(OLD/'build_named_stages.py').read_text().replace("for i,cmd in enumerate(cmds):", "cmds.append(['xcrun','clang++','-std=c++17','-O2','-dynamiclib',str(P/'read_observer.cpp'),'-o',str(P/'read_observer.dylib')])\nfor i,cmd in enumerate(cmds):")
(P/'build_trace.py').write_text(s)
s=(P/'q2_upstream_bench_io.py').read_text().replace("ap.add_argument('--expected-slots',type=int);", "ap.add_argument('--expected-slots',type=int);ap.add_argument('--trace-prefix');")
s=s.replace("  process=subprocess.Popen(command,cwd=BUNDLE,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);", "  env=dict(os.environ)\n  if a.trace_prefix:env.update(DYLD_INSERT_LIBRARIES=str(P/'named_stage_observer.dylib')+':'+str(P/'read_observer.dylib'),SLOTSTREAM_METAL_OBSERVER=a.trace_prefix+'-commands',SLOTSTREAM_READ_OBSERVER=a.trace_prefix+'-reads')\n  receipt['trace_environment']={k:v for k,v in env.items()if k in ['DYLD_INSERT_LIBRARIES','SLOTSTREAM_METAL_OBSERVER','SLOTSTREAM_READ_OBSERVER']}\n  process=subprocess.Popen(command,cwd=BUNDLE,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,env=env);")
(P/'q2_upstream_trace.py').write_text(s)
s=(P/'run.py').read_text().replace("a.order=='ACCA'","a.order=='AC'")
s=s.replace('Request-boundary timestamps only; no inference observer, full-logit inspection or GPU/read injection. Passive macmon200ms.', 'Request timestamps plus identical read and named Metal encoder observers. No inference observer or full-logit inspection. Passive macmon200ms. Instrumented attribution only, never speed qualification; compare to prior untraced ACCA for observer effects.')
s=s.replace("'--env','DYLD_INSERT_LIBRARIES=','--',", "'--env','DYLD_INSERT_LIBRARIES='+str(P/'named_stage_observer.dylib')+':'+str(P/'read_observer.dylib'),'--env','SLOTSTREAM_METAL_OBSERVER='+str(P/(label+'-commands')),'--env','SLOTSTREAM_READ_OBSERVER='+str(P/(label+'-reads')),'--',")
s=s.replace("P/'q2_upstream_bench_io.py'","P/'q2_upstream_trace.py'").replace("'--expected-slots',str(cache['slots'])]","'--expected-slots',str(cache['slots']),'--trace-prefix',str(P/label)]")
(P/'run_trace.py').write_text(s)
for n in ['run_trace.py','q2_upstream_trace.py','build_trace.py']:compile((P/n).read_text(),n,'exec')
