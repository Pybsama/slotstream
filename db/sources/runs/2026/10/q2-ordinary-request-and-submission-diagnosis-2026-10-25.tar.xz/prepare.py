from pathlib import Path
import json,hashlib,shutil
P=Path(__file__).resolve().parent;R=P.parents[1]
source=R/'Sources/slotstream-cli/SmartDFlashCommand.swift';s=source.read_text()
s=s.replace('                    let start = Date()\n                    let (text, tokens, stats)', '                    let startMach=RuntimeClock.now()\n                    let start = Date()\n                    let (text, tokens, stats)',1)
s=s.replace('                    let after = ProcessMemory.vmActivity()\n                    if let conversation', '                    let endMach=RuntimeClock.now()\n                    let endDate=Date()\n                    let after = ProcessMemory.vmActivity()\n                    if let conversation',1)
s=s.replace('                    rows.append(["id": probe.id, "prompt_ids": ids,', '                    rows.append(["request_started_unix":start.timeIntervalSince1970,"request_ended_unix":endDate.timeIntervalSince1970,"request_started_mach_ns":startMach,"request_ended_mach_ns":endMach,"id": probe.id, "prompt_ids": ids,',1)
assert s.count('request_started_unix')==1 and s.count('let startMach=')==1
(P/'SmartDFlashCommand-request-clock.swift').write_text(s)
old=R/'.build/native-replay-20261023'
s=(old/'q2_upstream_bench_io.py').read_text()
s=s.replace(' start=time.monotonic();chunks=', ' start_unix=time.time();start=time.monotonic();chunks=',1)
s=s.replace("  return {'text':''.join(parts)", "  return {'request_started_unix':start_unix,'request_ended_unix':time.time(),'text':''.join(parts)",1)
s=s.replace("sample={'seconds':time.monotonic()-started,", "sample={'unix':time.time(),'seconds':time.monotonic()-started,",1)
(P/'q2_upstream_bench_io.py').write_text(s)
shutil.copy2(old/'short-warm-384-cases.json',P/'cases.json')
shutil.copy2(R/'.build/q2-sequence-20261025/quiet_guarded_run.py',P/'quiet_guarded_run.py')
(P/'instrumentation.json').write_text(json.dumps({'scope':'Request-boundary timestamps only. No inference observer, full-logit readback, GPU/read injection, power or priority intervention. Native runtime remains v68; only the test command is rebuilt. Splash published executable is unchanged.','native_original_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'native_diagnostic_sha256':hashlib.sha256((P/'SmartDFlashCommand-request-clock.swift').read_bytes()).hexdigest(),'upstream_original_sha256':hashlib.sha256((old/'q2_upstream_bench_io.py').read_bytes()).hexdigest(),'upstream_timestamped_sha256':hashlib.sha256((P/'q2_upstream_bench_io.py').read_bytes()).hexdigest()},indent=2))
