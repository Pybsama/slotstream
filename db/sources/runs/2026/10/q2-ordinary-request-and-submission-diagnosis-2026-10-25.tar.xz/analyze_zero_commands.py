from pathlib import Path
import csv,json,collections,bisect,statistics
P=Path(__file__).resolve().parent
exec((P/'analyze_trace.py').read_text().split('ledger=json.loads')[0],globals())
f=next(P.glob('ordinary-traced-15-0-A-commands.*.stages.csv'));prefix=f.name[:-len('.stages.csv')]
cc=list(rows(P/(prefix+'.csv')));ee=list(rows(P/(prefix+'.events.csv')))
bybuffer=collections.defaultdict(list)
for c in cc:c.update(submitted=float(c['submitted']),start=float(c['start']),end=float(c['end']),completed=float(c['completed']),events=[]);bybuffer[c['buffer']].append(c)
for vv in bybuffer.values():vv.sort(key=lambda c:c['submitted'])
times={k:[c['submitted']for c in vv]for k,vv in bybuffer.items()}
for e in ee:
 if e['kind']not in ['E','W']:continue
 t=float(e['stamp']);i=bisect.bisect_left(times.get(e['buffer'],[]),t)
 if i<len(bybuffer[e['buffer']]):bybuffer[e['buffer']][i]['events'].append(e)
report=[]
data=json.loads((P/'ordinary-traced-15-0-A.json').read_text())
for r in data['runs']:
 if not r['id'].startswith('timed'):continue
 lo,hi=r['request_started_mach_ns']/1e9,r['request_ended_mach_ns']/1e9
 z=[c for c in cc if lo<=c['submitted']<hi and c['start']==c['end']];assert all(int(c['status'])==4 for c in z)
 classes=collections.Counter(tuple(sorted(e['kind']for e in c['events']))for c in z)
 live=union((c['submitted'],c['completed'])for c in z)
 report.append(dict(case=r['id'],zero_length_gpu_span_commands=len(z),completed_successfully=True,event_classes=[dict(events=list(k),count=v)for k,v in classes.items()],submitted_to_completion_median_ms=statistics.median(c['completed']-c['submitted']for c in z)*1000,submitted_to_completion_union_seconds=length(live),scope='Zero-length public GPU timestamp spans are not proof of empty/no-op buffers. Observer sees compute encoder creation and host-readiness waits, not blits or GPU event signals. Submission-to-completion intervals overlap useful work and are not recoverable delay.'))
print(json.dumps(report,indent=2));(P/'zero-command-analysis.json').write_text(json.dumps(report,indent=2))
