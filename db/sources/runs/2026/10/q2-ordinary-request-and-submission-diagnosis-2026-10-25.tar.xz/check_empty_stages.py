from pathlib import Path
import csv,json,bisect,collections
P=Path(__file__).resolve().parent;f=next(P.glob('ordinary-traced-15-1-C-commands.*.stages.csv'));prefix=f.name[:-len('.stages.csv')]
def rows(f):return list(csv.DictReader(s for s in f.read_text().splitlines()if not s.startswith('#')))
ss=rows(f);aa=rows(P/(prefix+'.assignments.csv'));cc=rows(P/(prefix+'.csv'));by_e=collections.defaultdict(list)
for s in ss:s['encoded']=float(s['encoded']);s['assignments']=[];by_e[s['encoder']].append(s)
for vv in by_e.values():vv.sort(key=lambda x:x['encoded'])
times={k:[s['encoded']for s in vv]for k,vv in by_e.items()}
for a in aa:
 i=bisect.bisect_right(times.get(a['encoder'],[]),float(a['stamp']))-1
 if i>=0:by_e[a['encoder']][i]['assignments'].append(a)
bad=[s for s in ss if not int(s['gpu_end'])>int(s['gpu_start'])>0]
report=[]
for s in bad:
 # Find next later encoder creation on same object; timeline bounds pointer reuse.
 after=[float(c['submitted'])for c in cc if c['buffer']==s['buffer']and float(c['submitted'])>=s['encoded']]
 report.append(dict(index=s['index'],encoded=s['encoded'],gpu_start=s['gpu_start'],gpu_end=s['gpu_end'],assignment_count=len(s['assignments']),first_commit_after=min(after)if after else None))
(P/'empty-stage-audit.json').write_text(json.dumps(dict(total=len(ss),zero_stages=len(bad),zero_stage_assignments=sum(len(s['assignments'])for s in bad),zero_both=all(int(s['gpu_start'])==int(s['gpu_end'])==0 for s in bad),rows=report),indent=2));print('bad',len(bad),'assignments',[len(s['assignments'])for s in bad][:30]);print('span',min(s['encoded']for s in bad),max(s['encoded']for s in bad));print('with_assignments',[(s['index'],s['assignments'][:2])for s in bad if s['assignments']][:4])
