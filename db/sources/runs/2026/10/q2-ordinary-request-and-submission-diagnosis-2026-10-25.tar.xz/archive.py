from pathlib import Path
import hashlib,io,json,re,tarfile,subprocess
P=Path(__file__).resolve().parent;R=P.parents[1];OLD=R/'.build/q2-sequence-20261025'
assert json.loads((P/'ordinary-submit-15-ledger.json').read_text())[-1]['label']=='ordinary-submit-15-5-A'
dest=R/'db/sources/runs/2026/10/q2-ordinary-request-and-submission-diagnosis-2026-10-25.tar.xz';assert not dest.exists()
files={}
for f in P.rglob('*'):
 if not f.is_file() or '__pycache__'in f.parts:continue
 if f.suffix in ['.py','.swift','.cpp','.mm','.json','.jsonl','.csv','.log','.stderr','.txt']or f.name=='build-source.tar.gz':
  if f.name in ['archive-receipt.json']:continue
  files[str(f.relative_to(P))]=f
files['reference/native-v68-build-identity.json']=R/'.build/native-replay-20261023/v68/build-identity.json'
for label in ['commit-threshold-0-A','commit-threshold-1-B','commit-ops-0-B','commit-relaxed-0-B']:
 for name in [label+'.json',label+'.observer.json']:
  files['reference/q2-sequence-20261025/'+name]=OLD/name
 for f in OLD.glob(label+'-commands.*.csv'):
  if re.fullmatch(re.escape(label)+r'-commands\.\d+\.csv',f.name):files['reference/q2-sequence-20261025/'+f.name]=f
W=Path('/var/folders/d4/t1c8ltbx5s3_11cs9y6gjh8m0000gp/T/slotstream-splash-host-ugnf26pi/source')
for name in ['runtime/model/Runtime.cpp','runtime/model/ExpertStore.cpp','runtime/model/DraftCheckpoint.cpp','runtime/model/GgufPreparation.cpp','runtime/model/VerifyBudget.cpp','runtime/engine/Engine.cpp']:
 files['reference/splash/'+name]=W/name
for name in ['device.cpp','eval.cpp']:
 files['reference/mlx/'+name]=R/'.build/checkouts/mlx-swift/Source/Cmlx/mlx/mlx/backend/metal'/name
files['reference/mlx/transforms.cpp']=R/'.build/checkouts/mlx-swift/Source/Cmlx/mlx/mlx/transforms.cpp'
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
secret=re.compile(rb'(?:ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{25,}|sk-(?:proj-)?[A-Za-z0-9_-]{30,}|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----)')
for f in files.values():assert not secret.search(f.read_bytes()),f
manifest={n:dict(bytes=f.stat().st_size,sha256=sha(f))for n,f in files.items()};raw=json.dumps(manifest,indent=2).encode()+b'\n'
with tarfile.open(dest,'w:xz',preset=3)as t:
 for n,f in sorted(files.items()):t.add(f,arcname=n,recursive=False)
 info=tarfile.TarInfo('archive-manifest.json');info.size=len(raw);t.addfile(info,io.BytesIO(raw))
seen={}
with tarfile.open(dest,'r|xz')as t:
 for m in t:
  b=t.extractfile(m).read()
  if m.name=='archive-manifest.json':assert json.loads(b)==manifest
  else:seen[m.name]=dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
assert seen==manifest
receipt=dict(path=str(dest.relative_to(R)),files=len(manifest),bytes=dest.stat().st_size,sha256=sha(dest),readback_verified=True,credential_pattern_matches=0,excluded='Executable binaries, metallibs, model weights, ephemeral window/lock files and pycache.')
(P/'archive-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
