from pathlib import Path
import csv,json,re
P=Path(__file__).resolve().parent;p=P.parent/'q2-sequence-20261025';out=[]
for label in ['commit-threshold-0-A','commit-threshold-1-B','commit-ops-0-B','commit-relaxed-0-B']:
 f=next(f for f in p.glob(label+'-commands.*.csv')if re.fullmatch(re.escape(label)+r'-commands\.\d+\.csv',f.name));rows=list(csv.DictReader(s for s in f.read_text().splitlines()if not s.startswith('#')))
 d=json.loads((p/(label+'.json')).read_text());rr=[r for r in d['runs']if r['round']==1];lo,hi=rr[0]['start_ns']/1e9,rr[-1]['end_ns']/1e9
 selected=[c for c in rows if lo<=float(c['submitted'])<hi];zero=[c for c in selected if float(c['start'])==float(c['end'])];guard=json.loads((p/(label+'.observer.json')).read_text())
 r=dict(label=label,commands=len(selected),zero_spans=len(zero),verify_seconds=sum(r['seconds']for r in rr),guard_paging=guard['paging'],overrides=guard['environment_overrides']);out.append(r);print({k:v for k,v in r.items()if k!='overrides'})
(P/'prior-command-threshold-reanalysis.json').write_text(json.dumps(out,indent=2))
