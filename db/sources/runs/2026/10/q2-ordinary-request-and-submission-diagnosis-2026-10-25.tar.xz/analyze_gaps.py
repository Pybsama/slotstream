from pathlib import Path
import csv,json,collections,bisect,statistics
P=Path(__file__).resolve().parent
exec((P/'analyze_trace.py').read_text().split('ledger=json.loads')[0],globals())
results=[]
for event in json.loads((P/'ordinary-traced-15-ledger.json').read_text()):
 label=event['label'];native=event['arm']=='A';data=json.loads((P/(label+'.json')).read_text());f=next(P.glob(label+'-commands.*.stages.csv'));prefix=f.name[:-len('.stages.csv')]
 ss=list(rows(f));aa=list(rows(P/(prefix+'.assignments.csv')));pp=list(rows(P/(prefix+'.pipelines.csv')));rr=list(rows(P/(prefix.replace('-commands.','-reads.')+'.csv')));cc=list(rows(P/(prefix+'.csv')))
 by_e=collections.defaultdict(list);by_p=collections.defaultdict(list)
 for s in ss:s.update(t=float(s['encoded']),start=int(s['gpu_start'])/1e9,end=int(s['gpu_end'])/1e9,names=[]);by_e[s['encoder']].append(s)
 for vv in by_e.values():vv.sort(key=lambda x:x['t'])
 et={k:[s['t']for s in vv]for k,vv in by_e.items()}
 for p in pp:p['stamp']=float(p['stamp']);by_p[p['pipeline']].append(p)
 for vv in by_p.values():vv.sort(key=lambda p:p['stamp'])
 pt={k:[p['stamp']for p in vv]for k,vv in by_p.items()}
 for a in aa:
  t=float(a['stamp']);i=bisect.bisect_right(et.get(a['encoder'],[]),t)-1;j=bisect.bisect_right(pt.get(a['pipeline'],[]),t)-1
  if i>=0 and j>=0:by_e[a['encoder']][i]['names'].append((t,by_p[a['pipeline']][j]['name']))
 for r in data['runs']:
  if not r['id'].startswith('timed'):continue
  lo,hi=r['request_started_mach_ns']/1e9,r['request_ended_mach_ns']/1e9
  stages=sorted([s for s in ss if lo<=s['t']<hi and s['end']>s['start']>0],key=lambda s:s['start']);reads=union((max(lo,float(x['start'])),min(hi,float(x['end'])))for x in rr if float(x['end'])>lo and float(x['start'])<hi and int(x['result'])>=65536)
  readends=[b for a,b in reads]
  groups=collections.defaultdict(list);gaps=[];last=lo;previous=[]
  for s in stages+[dict(start=hi,end=hi,t=hi,names=[(hi,'REQUEST_END')])]:
   names=[n for t,n in s['names']if lo<=t<=hi]
   if s['start']>last:
    a,b=last,s['start'];ri=bisect.bisect_right(readends,a);rj=bisect.bisect_right(readends,b)+1;overlap=length(intersection([[a,b]],reads[ri:rj]));gap=dict(start=a,end=b,seconds=b-a,outside_reads=b-a-overlap,before=previous,after=names)
    gaps.append(gap);sig=tuple(names);groups[sig].append(gap)
   if s['end']>last:last=s['end'];previous=names
  command_summary=collections.Counter()
  intervals=collections.defaultdict(float)
  for c in cc:
   if not lo<=float(c['submitted'])<hi:continue
   b,e=float(c['start']),float(c['end'])
   command_summary['positive_device_span'if e>b>0 else'zero_device_span']+=1
  gs=sorted([dict(next_signature=list(k),count=len(v),gap_seconds=sum(g['seconds']for g in v),outside_read_seconds=sum(g['outside_reads']for g in v),max_outside_read=max(g['outside_reads']for g in v))for k,v in groups.items()],key=lambda x:-x['outside_read_seconds'])
  row=dict(label=label,id=r['id'],command_summary=dict(command_summary),groups=gs,largest_gaps=sorted(gaps,key=lambda x:-x['outside_reads'])[:20]);results.append(row)
  print(label,r['id'],dict(command_summary))
  for g in gs[:12]:print(g['count'],round(g['gap_seconds'],5),round(g['outside_read_seconds'],5),' | '.join(g['next_signature'])[:240])
(P/'gap-analysis.json').write_text(json.dumps(results,indent=2))
