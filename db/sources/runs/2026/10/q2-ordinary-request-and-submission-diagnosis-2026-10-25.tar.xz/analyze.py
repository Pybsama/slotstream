from pathlib import Path
import bisect,collections,datetime,hashlib,json,statistics
P=Path(__file__).resolve().parent
ledger=json.loads((P/'ordinary-15-ledger.json').read_text())
report=[]
for event in ledger:
    label=event['label'];native=event['arm']=='A';data=json.loads((P/(label+'.json')).read_text())
    raw=[json.loads(s)for s in (P/(label+'-frequency.jsonl')).read_text().splitlines()]
    ticks=[datetime.datetime.fromisoformat(r['timestamp']).timestamp()for r in raw]
    period=statistics.median(b-a for a,b in zip(ticks,ticks[1:]));assert .15<period<.5
    windows=[(ticks[i-1]if i else t-period,t,r)for i,(t,r)in enumerate(zip(ticks,raw))]
    def frequency(start,end,shift=0):
        sums=collections.defaultdict(float);covered=0
        for lo,hi,r in windows:
            dt=max(0,min(hi+shift,end)-max(lo+shift,start));covered+=dt
            for k in ['gpu_freq_mhz','gpu_active_ratio','gpu_power','cpu_power']:sums[k]+=dt*r[k]
        if shift==0:assert abs(covered-(end-start))<.01,(label,covered,end-start)
        return {'coverage_ratio':covered/(end-start),**{k:v/covered for k,v in sums.items()}}
    if native:
        guard=json.loads((P/(label+'-guard.observer.json')).read_text())
        samples=[(s['unix'],s['user_ns']+s['system_ns'])for s in guard['samples']]
        scale=guard['rusage_ticks_per_nanosecond']['numer']/guard['rusage_ticks_per_nanosecond']['denom']/1e9
    else:
        samples=[(s['unix'],sum(v['user_time']+v['system_time']for v in s['rusage'].values()))for s in data['memory_samples']]
        # Same measured host timebase as the native guard, not an assumed nanosecond unit.
        g=json.loads((P/'ordinary-15-0-A-guard.observer.json').read_text())
        scale=g['rusage_ticks_per_nanosecond']['numer']/g['rusage_ticks_per_nanosecond']['denom']/1e9
    sample_times=[s[0]for s in samples]
    def cpu(at):
        i=bisect.bisect_left(sample_times,at)
        if i==0 or i==len(samples):return None
        lo,a=samples[i-1];hi,b=samples[i]
        return (a+(b-a)*(at-lo)/(hi-lo))*scale
    rows=[]
    for r in data['runs']:
        start,end=r['request_started_unix'],r['request_ended_unix'];assert end>start
        c0,c1=cpu(start),cpu(end)
        row={'id':r['id'],'window_seconds':end-start,'request_seconds':r['elapsed_seconds'],
             'text_sha256':hashlib.sha256(r['text'].encode()).hexdigest(),
             'frequency':frequency(start,end),
             'frequency_shift_sensitivity':{str(s):frequency(start,end,s)for s in [-period,period]},
             'frequency_halves':[frequency(start,(start+end)/2),frequency((start+end)/2,end)],
             'cpu_service_seconds':None if c0 is None or c1 is None else c1-c0}
        if native:
            s=r['stats'];assert r['streamed']==r['text'];assert len(r['tokens'])==384
            assert s['reusedPrefixTokens']==0 and not s.get('runtimeError') and s['finishReason']=='length'
            row.update(tokens=len(r['tokens']),decode_seconds=s['decodeSeconds'],prefill_seconds=s['prefillSeconds'],
                       target_passes=s['decodeForwardPasses'],target_rows=s['decodeModelTokens'],
                       drafted_tokens=s['draftedTokens'],accepted_draft_tokens=s['acceptedDrafts'],
                       verify_seconds=s['verifySeconds'],draft_seconds=s['draftSeconds'],
                       reconcile_seconds=s['reconciliationSeconds'],callback_seconds=s['tokenCallbackSeconds'],
                       verification_widths=dict(collections.Counter(d+1 for d in s['adaptiveDraftDepths'])),
                       demand_read_bytes=s['decodeReadBytes'],forecast_issued_bytes=s['expertPrefetch']['issuedBytes'],
                       forecast_wasted_bytes=s['expertPrefetch']['wastedBytes'])
            row['unassigned_decode_seconds']=s['decodeSeconds']-sum(s[k]for k in ['verifySeconds','draftSeconds','reconciliationSeconds'])
        else:
            assert r['usage']['completion_tokens']==384 and r['timings']['cache_n']==0
            assert r['finish_reason']=='length'
            a,b=r['status_after'],r['status_before'];sp=r['metrics']['speculation']
            loads=a['streamed_experts']['decode']['loads']-b['streamed_experts']['decode']['loads']
            batches=a['scheduler']['decode_batches']-b['scheduler']['decode_batches']
            assert loads==48*batches,(loads,batches)
            row.update(tokens=384,decode_seconds=r['timings']['predicted_ms']/1000,prefill_seconds=r['timings']['prompt_ms']/1000,
                       target_passes=batches,nonzero_draft_cycles=sp['cycles'],
                       drafted_tokens=sp['drafted_tokens'],accepted_draft_tokens=sp['accepted_draft_tokens'],
                       expert_layer_loads=loads,
                       combined_read_bytes=a['streamed_experts']['decode']['read_bytes']-b['streamed_experts']['decode']['read_bytes'],
                       model_command_gpu_span_seconds=(a['model_timing']['decode']['total_gpu_ms']-b['model_timing']['decode']['total_gpu_ms'])/1000,
                       host_step_seconds={k:(a['streamed_experts']['decode']['host_steps'][k]['total']-b['streamed_experts']['decode']['host_steps'][k]['total'])/1000 for k in ['pickup_ms','work_ms','resume_ms']})
        rows.append(row)
    report.append({'label':label,'engine':'native'if native else'Splash','eligible':event['eligible'],'rows':rows})
out={'whole_protocol_eligible':len(report)==4 and all(a['eligible']for a in report),'scope':'Ordinary production requests, timestamp-only CLI diagnostic and passive whole-device frequency. Native sums separate target, draft and reconciliation; Splash command spans include host waits. CPU service sums across threads, not wall-time attribution. Splash speculation.cycles excludes zero-draft passes, so target passes use scheduler batches confirmed by48expert-layerloads each. Fixed output limits are throughput completion, not quality qualification.','arms':report}
if len(report)==4:
    out['medians']={engine:{case:{k:statistics.median(r[k]for a in report if a['engine']==engine for r in a['rows']if r['id']==case)for k in ['request_seconds','decode_seconds','prefill_seconds','target_passes','drafted_tokens','accepted_draft_tokens']}for case in ['timed-2','timed-3']}for engine in ['native','Splash']}
    out['output_variation']={engine:{case:len({r['text_sha256']for a in report if a['engine']==engine for r in a['rows']if r['id']==case})for case in ['timed-2','timed-3']}for engine in ['native','Splash']}
(P/'analysis.json').write_text(json.dumps(out,indent=2))
print(json.dumps({k:v for k,v in out.items()if k!='arms'},indent=2))
for a in report:
    for r in a['rows']:
        if r['id'].startswith('timed'):
            print(a['label'],a['eligible'],r['id'],round(r['request_seconds'],3),round(r['frequency']['gpu_freq_mhz']),r['target_passes'])
