from pathlib import Path
import json,statistics,hashlib
P=Path(__file__).resolve().parent
ledger=json.loads((P/'ordinary-submit-15-ledger.json').read_text());report=[]
for e in ledger:
 d=json.loads((P/(e['label']+'.json')).read_text());rows=[]
 for r in d['runs']:
  n=e['arm']!='C'
  if n:
   assert r['streamed']==r['text'] and len(r['tokens'])==384 and not r['stats'].get('runtimeError')and r['stats']['finishReason']=='length'
   assert r['stats']['reusedPrefixTokens']==0 and d['plan']['pool_slots']==4067
   s=r['stats'];passes=s['decodeForwardPasses'];decode=s['decodeSeconds'];prefill=s['prefillSeconds'];draft=s['draftSeconds'];accepted=s['acceptedDrafts']
  else:
   assert r['usage']['completion_tokens']==384 and r['finish_reason']=='length'and r['timings']['cache_n']==0
   a,b=r['status_after'],r['status_before'];passes=a['scheduler']['decode_batches']-b['scheduler']['decode_batches'];assert a['streamed_experts']['decode']['loads']-b['streamed_experts']['decode']['loads']==48*passes
   decode=r['timings']['predicted_ms']/1000;prefill=r['timings']['prompt_ms']/1000;draft=None;accepted=r['metrics']['speculation']['accepted_draft_tokens']
  rows.append(dict(id=r['id'],request_seconds=r['elapsed_seconds'],decode_seconds=decode,prefill_seconds=prefill,draft_seconds=draft,target_passes=passes,accepted_draft_tokens=accepted,text_sha256=hashlib.sha256(r['text'].encode()).hexdigest()))
 report.append(dict(label=e['label'],arm=e['arm'],eligible=e['eligible'],rows=rows))
out=dict(scope='Single frozen ABCCBA, untraced actual requests. B only isolatedQ2process automaticcommitcaps; same code and model. No global/Fast changes. Whole protocol exclusion on anyguardfailure. Different adaptive outputs are preserved; no token-exact acrossruns/enginesclaim.',whole_protocol_eligible=len(report)==6 and all(r['eligible']for r in report),arms=report)
if len(report)==6:
 med={arm:{case:statistics.median(r['request_seconds']for a in report if a['arm']==arm for r in a['rows']if r['id']==case)for case in ['timed-2','timed-3']}for arm in 'ABC'}
 pairs=[]
 for ids in [(0,1,2),(5,4,3)]:
  row={}
  for case in ['timed-2','timed-3']:
   vs=[next(r['request_seconds']for r in report[i]['rows']if r['id']==case)for i in ids];row[case]=dict(A=vs[0],B=vs[1],C=vs[2],B_over_A=vs[1]/vs[0],B_over_C=vs[1]/vs[2])
  pairs.append(row)
 out.update(median_request_seconds=med,pairs=pairs,median_ratios={case:dict(B_over_A=med['B'][case]/med['A'][case],B_over_C=med['B'][case]/med['C'][case],A_over_C=med['A'][case]/med['C'][case])for case in ['timed-2','timed-3']},repeatable_per_fixture_B_gain=all(p[c]['B_over_A']<1 for p in pairs for c in ['timed-2','timed-3']),retained_runtime_change=False)
(P/'submission-analysis.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items()if k!='arms'},indent=2))
for a in report:
 print(a['label'],a['eligible'],[(r['id'],round(r['request_seconds'],3),r['target_passes'])for r in a['rows']])
