from pathlib import Path
import json
P=Path(__file__).resolve().parent;R=P.parents[1];OLD=R/'.build/q2-sequence-20261025'
for f in P.glob('named-stage-*'):
 if f.suffix=='.log' or '.csv' in f.name:f.rename(f.with_name('attempt2-'+f.name))
s=(OLD/'named_stage_observer.mm').read_text()
s=s.replace('#include <unistd.h>','#include <unistd.h>\n#include <fcntl.h>\n#include <sys/mman.h>')
s=s.replace('namespace {','namespace {\nvolatile uint32_t* windowFlag=nullptr;\nbool windowActive(){return !windowFlag || *windowFlag==1;}\n',1)
s=s.replace('  const size_t i=nextStage.fetch_add(1);','  if(!windowActive()) return reinterpret_cast<id(*)(id,SEL,id)>(original)(buffer,selector,input);\n  const size_t i=nextStage.fetch_add(1);',1)
s=s.replace('__attribute__((constructor)) void initialize() { atexit(dump); }','__attribute__((constructor)) void initialize() {\n  if(const char* path=getenv("Q2_TRACE_WINDOW")){int fd=open(path,O_RDONLY);if(fd<0)abort();void* p=mmap(nullptr,4096,PROT_READ,MAP_SHARED,fd,0);close(fd);if(p==MAP_FAILED)abort();windowFlag=(volatile uint32_t*)p;}\n  atexit(dump);\n}')
(P/'named_stage_observer.mm').write_text(s)
s=(P/'SmartDFlashCommand-request-clock.swift').read_text()
s=s.replace('                    let startMach=RuntimeClock.now()', '''                    let traceWindow = ProcessInfo.processInfo.environment["Q2_TRACE_WINDOW"].map { URL(fileURLWithPath: $0) }
                    if let traceWindow {
                        let h = try FileHandle(forWritingTo: traceWindow)
                        try h.write(contentsOf: Data([probe.id.hasPrefix("timed") ? 1 : 0, 0, 0, 0])); try h.close()
                    }
                    let startMach=RuntimeClock.now()''',1)
s=s.replace('                    let endDate=Date()', '''                    let endDate=Date()
                    if let traceWindow {
                        let h = try FileHandle(forWritingTo: traceWindow)
                        try h.write(contentsOf: Data([0, 0, 0, 0])); try h.close()
                    }''',1)
(P/'SmartDFlashCommand-trace-window.swift').write_text(s)
s=(P/'build.py').read_text().replace('SmartDFlashCommand-request-clock.swift','SmartDFlashCommand-trace-window.swift').replace("P/'native-build'","P/'native-trace-build'").replace("P/'restored.json'","P/'restored-trace.json'")
(P/'build_trace_cli.py').write_text(s)
s=(P/'q2_upstream_trace.py').read_text()
s=s.replace("SLOTSTREAM_READ_OBSERVER=a.trace_prefix+'-reads')","SLOTSTREAM_READ_OBSERVER=a.trace_prefix+'-reads',Q2_TRACE_WINDOW=a.trace_prefix+'-window.bin')")
s=s.replace("   row={'id':case['id']", "   if a.trace_prefix:\n    with open(a.trace_prefix+'-window.bin','r+b',buffering=0)as flag:flag.write(bytes([int(case['id'].startswith('timed')),0,0,0]))\n   row={'id':case['id']")
s=s.replace("   row['status_after']=request('/status');", "   if a.trace_prefix:\n    with open(a.trace_prefix+'-window.bin','r+b',buffering=0)as flag:flag.write(bytes(4))\n   row['status_after']=request('/status');")
(P/'q2_upstream_trace.py').write_text(s)
s=(P/'run_trace.py').read_text().replace(" wait_nominal(P/(label+'-cooldown.json'))", " (P/(label+'-window.bin')).write_bytes(bytes(4096))\n wait_nominal(P/(label+'-cooldown.json'))")
s=s.replace("'--env','SLOTSTREAM_READ_OBSERVER='+str(P/(label+'-reads')),'--',", "'--env','SLOTSTREAM_READ_OBSERVER='+str(P/(label+'-reads')),'--env','Q2_TRACE_WINDOW='+str(P/(label+'-window.bin')),'--',")
(P/'run_trace.py').write_text(s)
for n in ['q2_upstream_trace.py','run_trace.py','build_trace_cli.py']:compile((P/n).read_text(),n,'exec')
(P/'trace-window-design.json').write_text(json.dumps(dict(reason='Hardware rejects128counterbuffers and>4096samples perbuffer. Keep original32buffers4096samples; activate encoder timestamps only for two timed requests through a shared4byte diagnosticflag. Full requests/controller unchanged. Reads observed throughout. No speed qualification.',failed_attempts=['128buffersCannotAllocate','16384samplesInvalid32768byteMaximum'],stage_limit=65536),indent=2))
