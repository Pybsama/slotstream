from pathlib import Path
import fcntl,hashlib,io,json,os,re,sys,tarfile
P=Path(__file__).resolve().parent;R=P.parents[1];E=P.parent/'q2-event-readiness-20261026'
assert json.loads((P/'candidate-validation-result.json').read_text())['passed']
assert json.loads((E/'validation-result.json').read_text())['passed']
assert (P/'analysis.json').exists() and (E/'analysis.json').exists()
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
reservation=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(reservation,fcntl.LOCK_EX|fcntl.LOCK_NB);os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(P/'archive-child.lock');preflight(4)
sha=lambda b:hashlib.sha256(b).hexdigest()
allowed={'.py','.swift','.h','.hpp','.cpp','.mm','.json','.jsonl','.csv','.bin','.log','.stderr','.txt'}
secret=re.compile(rb'(?:ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{25,}|sk-(?:proj-)?[A-Za-z0-9_-]{30,}|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----)')
groups={'q2-event-readiness-native':{},'q2-event-readiness-splash':{},'q2-packed-routing-metadata':{}}
for root in [E,P]:
 for f in root.rglob('*'):
  if not f.is_file() or '__pycache__'in f.parts or f.suffix not in allowed or f.name.startswith('archive-receipt') or(f.name.startswith('archive')and f.suffix=='.log'):continue
  rel=str(f.relative_to(root))
  if root==P:key='q2-packed-routing-metadata'
  elif rel.startswith(('upstream/','trace-2-S','trace-3-S','validation-1-S')):key='q2-event-readiness-splash'
  else:key='q2-event-readiness-native'
  groups[key][rel]=f
F=R/'.build/q2-full-cycle-20261025';H=R/'.build/q2-expert-preparation-20261026';S=R/'.build/q2-required-dependencies-20261026/source-reference'
groups['q2-event-readiness-native']['reference/native-build-identity.json']=H/'native-build/candidate/build-identity.json'
groups['q2-event-readiness-native']['reference/validation-0-N.json']=F/'validation-0-N.json'
groups['q2-event-readiness-splash']['reference/validation-s-0-S.json']=F/'validation-s-0-S.json'
groups['q2-event-readiness-splash']['reference/Splash-LICENSE']=S/'LICENSE'
groups['q2-packed-routing-metadata']['reference/v68-build-identity.json']=R/'.build/native-replay-20261023/v68/build-identity.json'
groups['q2-packed-routing-metadata']['reference/full-cycle-build-identity.json']=F/'native-build/candidate/build-identity.json'
groups['q2-packed-routing-metadata']['reference/validation-0-N.json']=F/'validation-0-N.json'
groups['q2-packed-routing-metadata']['reference/NativeSchedule-baseline.cpp']=R/'Sources/CNativeSchedule/NativeSchedule.cpp'
receipts=[]
for label,files in groups.items():
 files['reference/Slotstream-LICENSE']=R/'LICENSE';manifest={}
 for n,f in files.items():
  b=f.read_bytes();assert not secret.search(b),n;manifest[n]=dict(bytes=len(b),sha256=sha(b))
 dest=R/('db/sources/runs/2026/10/'+label+'-2026-10-26.tar.xz');assert not dest.exists();raw=json.dumps(manifest,indent=2).encode()
 with tarfile.open(dest,'w:xz',preset=3)as t:
  for n,f in sorted(files.items()):t.add(f,arcname=n,recursive=False)
  info=tarfile.TarInfo('archive-manifest.json');info.size=len(raw);t.addfile(info,io.BytesIO(raw))
 seen={}
 with tarfile.open(dest,'r|xz')as t:
  for m in t:
   b=t.extractfile(m).read()
   if m.name=='archive-manifest.json':assert json.loads(b)==manifest
   else:seen[m.name]=dict(bytes=len(b),sha256=sha(b))
 assert seen==manifest and dest.stat().st_size<100_000_000
 receipt=dict(path=str(dest.relative_to(R)),files=len(manifest),bytes=dest.stat().st_size,sha256=sha(dest.read_bytes()),readback_verified=True,credential_pattern_matches=0,excluded='Executables, libraries, weights, pycache, duplicate source archives and active archive-driver output. Reused prior instruments/traces remain in their registered archives.')
 receipts.append(receipt);print(json.dumps(receipt),flush=True)
(P/'archive-receipts.json').write_text(json.dumps(receipts,indent=2))
