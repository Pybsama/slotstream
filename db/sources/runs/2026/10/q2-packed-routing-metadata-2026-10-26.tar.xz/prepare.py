from pathlib import Path
import json,hashlib,shutil,subprocess
P=Path(__file__).resolve().parent;R=P.parents[1];M=P.parent/'q2-mask-reuse-20261026';F=P.parent/'q2-full-cycle-20261025'
rep={}
def replace(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b)
def save(name,s):
 out=Path(name).name;(P/out).write_text(s);rep[name]=out
s=(R/'Sources/CNativeSchedule/NativeSchedule.cpp').read_text()
s=replace(s,'#include <functional>','#include <functional>\n#include <cstdlib>')
s=replace(s,'  int staged = 0;','  int staged = 0;\n  bool packed_metadata = false;')
s=replace(s,'    const int slots = order + 2, live = order + 3, ready = order + 4;', '''    const int slots = order + 2, live = order + 3;
    const int ready = order + (job_->packed_metadata ? 1 : 4);
    const int offsets[] = {0, rows_, rows_ + routes_, rows_ + routes_ + rows_ / 8};
    auto bind_metadata = [&](int field, int binding) {
      if (job_->packed_metadata)
        enc.set_input_array(in[order], binding, int64_t(offsets[field]) * sizeof(int32_t));
      else enc.set_input_array(in[order + field], binding);
    };''')
s=replace(s,'                       const array& indices, array& y, uint32_t n) {','                       int metadata_field, array& y, uint32_t n) {')
s=replace(s,'      enc.set_input_array(x, 0); enc.set_input_array(indices, 1);','      enc.set_input_array(x, 0); bind_metadata(metadata_field, 1);')
s=replace(s,'      for (int i = 0; i < 8; ++i) enc.set_input_array(in[inputs[i]], i + 1);','''      for (int i = 0; i < 6; ++i) enc.set_input_array(in[inputs[i]], i + 1);
      bind_metadata(2, 7); bind_metadata(3, 8);''')
s=replace(s,'reorder(p.gather.get(), in[0], in[order], grouped, rows_ * p.hidden);','reorder(p.gather.get(), in[0], 0, grouped, rows_ * p.hidden);')
s=replace(s,'reorder(p.scatter.get(), projected, in[inverse], out[0], routes_ * p.hidden);','reorder(p.scatter.get(), projected, 1, out[0], routes_ * p.hidden);')
s=replace(s,'''    inputs.emplace_back(order, Shape{rows});
    inputs.emplace_back(inverse, Shape{routes});
    inputs.emplace_back(slots, Shape{rows / 8});
    inputs.emplace_back(live, Shape{rows / 8});''','''    // Immutable per-pass routing tables share one ordinary MLX allocation.
    // Its array remains a graph input and owns all four offset bindings until
    // the GPU finishes. Mutable ready/staging/forecast state stays separate.
    static const bool packed_enabled = [] {
      const char* value = std::getenv("SLOTSTREAM_Q2_PACKED_METADATA");
      return !value || std::string(value) != "0";
    }();
    work->packed_metadata = plan->mixed_shared && packed_enabled;
    if (work->packed_metadata) {
      array metadata(allocator::malloc(size_t(rows + routes + rows / 4) * sizeof(int32_t)),
                     Shape{rows + routes + rows / 4}, int32);
      auto* dst = metadata.data<int32_t>();
      std::copy_n(order, rows, dst);
      std::copy_n(inverse, routes, dst + rows);
      std::copy_n(slots, rows / 8, dst + rows + routes);
      std::copy_n(live, rows / 8, dst + rows + routes + rows / 8);
      inputs.push_back(std::move(metadata));
    } else {
      inputs.emplace_back(order, Shape{rows});
      inputs.emplace_back(inverse, Shape{routes});
      inputs.emplace_back(slots, Shape{rows / 8});
      inputs.emplace_back(live, Shape{rows / 8});
    }''')
save('Sources/CNativeSchedule/NativeSchedule.cpp',s)
# Runtime candidate changes only the C++ schedule. Commands are diagnostics.
save('Sources/slotstream-cli/Q2ProfileCommand.swift',(F/'Q2ProfileCommand.swift').read_text())
save('Sources/slotstream-cli/SmartDFlashCommand.swift',(P.parent/'q2-request-profile-20261025/SmartDFlashCommand-request-clock.swift').read_text())
for name in ['build.py','run.py','validate.py','quiet_guarded_run.py','check_restoration.py','timed-2.json','request_run.py','q2_upstream_bench_io.py','cases.json']:
 shutil.copy2(M/name,P/name)
s=(P/'validate.py').read_text().replace('Q2 reuses one immutable decoded draft mask row; no reader scheduling change.','Q2 mixed expert passes pack four immutable routing metadata arrays into one MLX-owned input with offset bindings; no arithmetic or read policy change.');(P/'validate.py').write_text(s)
s=(P/'request_run.py').read_text().replace('Q2 immutable draft-mask reuse with16KiB reserve','Q2 immutable routing metadata packing');(P/'request_run.py').write_text(s)
(P/'replacements.json').write_text(json.dumps(rep,indent=2))
(P/'plan.json').write_text(json.dumps(dict(scope='One targeted Q2 mixed-expert C++ change: four immutable metadata arrays become one owned MLX input with byte-offset Metal bindings. Fast and nonmixed schedule keep separate arrays. Mutable staging/forecast state and all geometry validation remain unchanged. No alternate allocator, buffer pool, threads, polling or arithmetic changes.',hypothesis='Clean H attribution exposes about0.021s C metadata preparation and0.153s asyncEval outside same-process encoder coverage. Removing three allocations, graph inputs and lifetime entries per pass may reduce this work. Grouping alone is only about0.031s and is left unchanged. Event readiness trace resolves ancestry but fails native sensitivity; not used as quantified cause.',correctness='Original compressed-byte Q2 pool tests include mixed path, preparation/read failure, retry, resize, forecast ownership; Metal validation.111 full-logit hashes, real proposals and retained IDs exactly match frozenv68. Memory15GB,4067slots8192nativecontext. Packing has independent ownership and no reused mutable storage.',protocol='Single fixed ABBA full-cycle comparison, one warmup and two observed rounds. Require clean all arms, both direction improvements and pooled>=1% before complete-request ABCCBA against v68 and publishedSplash. Complete requests must improve both directions per fixture and pooled>=1%; parity target<=5%. Preserve every arm and failure, no retries to pick favorable timing. Reject if not repeatable.',source_revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),sources={n:hashlib.sha256((P/f).read_bytes()).hexdigest()for n,f in rep.items()}),indent=2))
print('Prepared isolated metadata candidate',len(rep),'inputs')
