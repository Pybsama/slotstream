from pathlib import Path
import json,statistics
P=Path(__file__).resolve().parent;F=P.parent/'q2-full-cycle-20261025'
ref=json.loads((F/'validation-0-N.json').read_text())['rounds'][0]['steps']
ledger=json.loads((P/'candidate-timing-ledger.json').read_text());assert [e['arm']for e in ledger]==list('ABBA')
means=[];exact=[]
for e in ledger:
 d=json.loads((P/(e['label']+'.json')).read_text());assert len(d['rounds'])==3
 for rd in d['rounds']:
  assert len(rd['steps'])==111
  for row,want in zip(rd['steps'],ref):
   for key in ['actual_guesses','actual_selected']:assert row[key]==want[key],(e['label'],rd['round'],row['step'],key)
 means.append(statistics.mean(r['cycle_seconds']for r in e['rounds'][1:]))
 exact.append(dict(label=e['label'],rounds=3,exact_steps=333))
directions=[means[1]/means[0],means[2]/means[3]];pooled=(means[1]+means[2])/(means[0]+means[3]);clean=all(e['eligible']for e in ledger)
result=dict(scope='Uninstrumented frozen111cycle ABBA, one warmup+two observed perprocess,15GB4067slots8192nativecontext. Ordinary product requests are a separate gate.',environment_eligible=clean,means=means,directions=directions,pooled=pooled,exact=exact,advance=clean and all(r<1 for r in directions)and pooled<=.99)
(P/'analysis.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
