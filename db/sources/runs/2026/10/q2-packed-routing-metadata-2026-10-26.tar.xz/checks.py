from pathlib import Path
import json,sys,subprocess,os,fcntl
P=Path(__file__).resolve().parent;R=P.parents[1]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
reservation=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(reservation,fcntl.LOCK_EX|fcntl.LOCK_NB)
inner=P/'checks-child.lock';os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(inner)
preflight(10)
command=[sys.executable,str(P/'quiet_guarded_run.py'),'--label','checks','--budget','6','--timeout','600','--env','SLOTSTREAM_MODEL_LOCK_PATH='+str(inner),'--env','MTL_DEBUG_LAYER=1','--env','DYLD_INSERT_LIBRARIES=','--',str(P/'native-build/candidate/slotstream'),'q2-experts-check','--pool-model','smart-q2']
with(P/'checks-launcher.log').open('x')as f:rc=subprocess.call(command,cwd=R,stdout=f,stderr=subprocess.STDOUT)
g=json.loads((P/'checks.observer.json').read_text());passed=rc==0 and g['peak_combined_bytes']<=6e9
(P/'checks-result.json').write_text(json.dumps(dict(passed=passed,command=command,guard=g,scope='Independent original compressed-byte references; ordinary and mixed Q2 schedule pool, exact failure/retry/resize and raw forecast ownership; affine fallback and prepared program boundary checks; Metal validation.'),indent=2))
print('CHECKS',passed,flush=True);assert passed
