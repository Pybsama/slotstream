from pathlib import Path
import json
P=Path(__file__).resolve().parent;rows=[]
for f in sorted(P.glob('*.observer.json')):
 d=json.loads(f.read_text());samples=d['samples'];assert samples and all('reclaimable' in s for s in samples)
 rows.append(dict(file=f.name,peak_gb=d['peak_combined_bytes']/1e9,min_headroom_gb=min(s['reclaimable']for s in samples)/1e9,swapins=d['after']['swapins']-d['before']['swapins'],swapouts=d['after']['swapouts']-d['before']['swapouts'],eligible=(not d['paging'] and not d['external_build_samples'] and d['thermal_before']==d['thermal_after']==0)))
(P/'guard-summary.json').write_text(json.dumps(rows,indent=2));print('Peak GB',max(r['peak_gb']for r in rows),'minimum headroom GB',min(r['min_headroom_gb']for r in rows))
v=json.loads((P/'candidate-validation-0-B.json').read_text())['rounds'][0]['steps'];t=json.loads((P/'trace-0-N.json').read_text())['rounds'][0]['steps'];assert len(v)==len(t)==111
assert all(a['actual_guesses']==b['actual_guesses']and a['actual_selected']==b['actual_selected']for a,b in zip(v,t))
(P/'trace-validation.json').write_text(json.dumps(dict(passed=True,cycles=111,proposals_and_selected_ids_exact=True,full_logits='Checked separately in candidate-validation-result.json; not read by timing/trace'),indent=2))
