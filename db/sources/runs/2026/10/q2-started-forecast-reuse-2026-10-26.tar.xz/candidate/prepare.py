from pathlib import Path
import json,shutil
P=Path(__file__).resolve().parent;R=P.parents[1];F=R/'.build/q2-full-cycle-20261025';H=R/'.build/q2-expert-submit-20261025';Q=R/'.build/q2-submit-read-overlap-20261025'
def replace(s,a,b):
 assert s.count(a)==1,(a[:100],s.count(a));return s.replace(a,b)
rep={}
def save(n,s):
 name=Path(n).name;rep[n]=name;(P/name).write_text(s)
n='Sources/Slotstream/ExpertPrefetch.swift';s=(R/n).read_text()
s=replace(s,'private var piecesDone = 0','''private var piecesDone = 0
    private var pieceReadStarted = false
    /// Set only after a parallel reader acquires its lane, before checked I/O.
    /// Queued closures alone do not establish that a read is in flight.
    package var hasStartedPieceRead: Bool {
        lock.lock(); defer { lock.unlock() }; return pieceReadStarted
    }''')
s=replace(s,'try reader(key, piece, owned[piece], { self.canReadPiece })','''lock.lock(); pieceReadStarted = true; lock.unlock()
                        try reader(key, piece, owned[piece], { self.canReadPiece })''')
s=replace(s,'case .reading where ticket.progress > 0:','''case .reading where ticket.progress > 0 || (stagesRawQ2 && ticket.hasStartedPieceRead):''')
s=replace(s,'// No piece complete yet: waiting for a lane or just started.\n                // The demand batch reads this key; the worker stops and frees.','''// No retained progress: the demand batch reads this key.
                // Q2 preserves an actually started piece even before its first
                // completion; queued-only forecasts still stop and free.''')
save(n,s)
n='Sources/slotstream-cli/NativePieceReaderChecks.swift';s=(R/n).read_text();a='    print("Concurrent forecast pieces:'
extra='''    // Distinguish a queued Q2 forecast from a real, incomplete read. Both
    // report zero completed pieces; only the latter should join demand.
    for started in [false, true] {
        var configuration = NativeInputReadAhead.configuration(
            reservedBytes: NativeInputReadAhead.reserveBytes, topK: 1)
        configuration.lanes = 1
        let entered = DispatchSemaphore(value: 0), release = DispatchSemaphore(value: 0)
        let scheduler = ExpertPrefetchScheduler(reader: { _, piece, destination, _ in
            if piece == 0 { entered.signal(); release.wait() }
            memset(destination, Int32(piece + 31), sizes[piece])
        }, isResident: { _ in false }, pieceBytes: sizes, configuration: configuration,
           predictor: nil, layers: 2, experts: 16, stagesRawQ2: true)
        defer { release.signal(); scheduler.lanes.endDemand(); scheduler.close() }
        if !started { scheduler.lanes.beginDemand() }
        scheduler.beginPass(id: 1, features: [])
        scheduler.forecast(target: 1, ids: [7], margins: [])
        if started { try wait(entered); scheduler.lanes.beginDemand() }
        let key = ExpertKey(1, 7), claim = scheduler.claimSplit([ExpertKey(1, 7)])
        guard claim.ready.isEmpty, (claim.reading[key] != nil) == started else {
            throw ValidationError("Q2 confused queued forecast with started I/O")
        }
        release.signal()
        if started {
            let finished = scheduler.finishReading(claim.reading)
            guard let ticket = finished[key], ticket.progress == 3, let owned = ticket.adoptRaw() else {
                throw ValidationError("Started Q2 forecast did not finish at demand priority")
            }
            for piece in sizes.indices {
                let bytes = UnsafeBufferPointer(start: owned.buffers[piece].assumingMemoryBound(to: UInt8.self), count: sizes[piece])
                guard bytes.allSatisfy({ $0 == UInt8(piece + 31) }) else {
                    throw ValidationError("Started Q2 forecast changed its bytes")
                }
            }
            owned.release()
        }
        scheduler.lanes.endDemand(); scheduler.close()
        guard scheduler.accounting.liveBytes == 0 else {
            throw ValidationError("Q2 started/queued claim leaked forecast bytes")
        }
    }
'''
assert a in s;s=s.replace(a,extra+a);save(n,s)
for n,src in [('Sources/slotstream-cli/Q2ProfileCommand.swift',F/'Q2ProfileCommand.swift'),('Sources/slotstream-cli/SmartDFlashCommand.swift',H/'SmartDFlashCommand-request-clock.swift')]:save(n,src.read_text())
for name in ['build.py','quiet_guarded_run.py','check_pool.py','check_restoration.py','timed-2.json','run.py','validate.py']:
 shutil.copy2(Q/name,P/name)
s=(P/'validate.py').read_text();s=s.replace('Expert GPU submission joins the existing Q2 demand read batch; original route readback is unchanged.','Q2 preserves already-started forecasts even before first piece completion; queued-only forecasts remain demand misses.');(P/'validate.py').write_text(s)
(P/'replacements.json').write_text(json.dumps(rep,indent=2))
(P/'plan.json').write_text(json.dumps(dict(hypothesis='Two independent traces contain 4387 and 4314 forecast pieces also read by demand; existing cancellation discards zero-completion tickets even when checked I/O has started. Direct fixed-schedule tail sensitivity is only15.8/13.1ms, so no large shared-pool port is justified. Test whether preserving started Q2 tickets reduces duplicate traffic/queue contention enough to improve whole cycles.',scope='Track actual parallel read entry after lane acquisition; retain started Q2 tickets at existing demand priority. No queued-only promotion, new reader pool, chunking, GPU submission, staging, arithmetic, memory reservation, priority or Fast production branch changes.',protocol='Deterministic queued/started and failure/ownership checks, installed pool checks, then111exact full logits/proposals/selected IDs. One clean ABBA fixed full-cycle control, one warmup and two measured rounds per arm. Advance to ordinary native baseline/candidate/Splash ABCCBA only on both-direction wins and at least1percent pooled gain. Any paging/competing heavy work excludes entire protocol; no retry. Candidate read trace separately checks duplicated reads and does not count as speed evidence.'),indent=2))
print('Prepared isolated started-forecast candidate')
