from pathlib import Path
import hashlib,json,tarfile
P=Path(__file__).resolve().parent;R=P.parents[1];sha=lambda b:hashlib.sha256(b).hexdigest();checks=[]
for folder,name,prefix,expected in [
 ('q2-full-cycle-20261025','q2-full-cycle-execution-control-2026-10-25.tar.xz','','e952a5d5563b9e1f0b36d0c924858e6cd5dff5cde278f989581cf6588fadb9a5'),
 ('q2-expert-submit-20261025','q2-expert-submission-boundary-2026-10-25.tar.xz','boundary/','b7a45e832759e08865565439bfa5ed35320654e0adffc0ae1ed0d0212aff11a0')]:
 root=P.parent/folder;a=R/'db/sources/runs/2026/10'/name;assert sha(a.read_bytes())==expected
 want=list(root.glob('trace-0-N*.csv'))+[root/'trace-0-N.json'];targets={prefix+f.name:sha(f.read_bytes())for f in want};seen={}
 with tarfile.open(a,'r|xz')as t:
  for m in t:
   if m.name in targets:seen[m.name]=sha(t.extractfile(m).read())
 assert targets==seen,(targets.keys(),seen.keys())
 checks.append(dict(archive=str(a.relative_to(R)),sha256=expected,members=targets,passed=True))
(P/'reused-evidence-verification.json').write_text(json.dumps(checks,indent=2));print('Verified',sum(len(c['members'])for c in checks),'prior trace files')
