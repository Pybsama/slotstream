from pathlib import Path
import bisect,collections,csv,json,re
P=Path(__file__).resolve().parent;R=P.parents[1]
def rows(f):
 lines=f.read_text().splitlines();footer=dict(t.split('=') for t in lines[-1][2:].split());assert int(footer['total'])<int(footer['cap']);return list(csv.DictReader(l for l in lines if not l.startswith('#')))
def union(xs):
 out=[]
 for a,b in sorted(xs):
  if b<=a:continue
  if not out or a>out[-1][1]:out.append([a,b])
  else:out[-1][1]=max(b,out[-1][1])
 return out
def length(xs):return sum(b-a for a,b in xs)
header=json.loads((R/'.build/smart-dflash-eval/gsq-header.json').read_text());extents=[]
for t in header['tensors']:
 m=re.fullmatch(r'blk\.(\d+)\.ffn_(gate|up|down)_exps\.weight',t['name'])
 if m:extents.append(dict(start=11024672+t['offset'],end=11024672+t['offset']+512*460800,layer=int(m[1]),piece={'gate':0,'up':1,'down':2}[m[2]]))
extents.sort(key=lambda x:x['start']);starts=[x['start']for x in extents];reports=[];details=[]
for folder in ['q2-full-cycle-20261025','q2-expert-submit-20261025']:
 F=P.parent/folder;label='trace-0-N';steps=json.loads((F/(label+'.json')).read_text())['rounds'][0]['steps'];bounds=[r['start_ns']/1e9 for r in steps];hi=steps[-1]['end_ns']/1e9
 rr=[];bythread=collections.defaultdict(list)
 for x in rows(next(F.glob(label+'-reads.*.csv'))):
  r={k:float(v)if k in ['start','end']else int(v)for k,v in x.items()}
  if r['result']<65536:continue
  bythread[r['thread']].append(r)
  if bounds[0]<=r['start']<hi:rr.append(r)
 for v in bythread.values():v.sort(key=lambda x:x['end'])
 ends={k:[r['end']for r in v]for k,v in bythread.items()};dest=collections.Counter(r['destination']for r in rr);forecast={k for k,v in dest.most_common(4)}
 cc=[]
 for x in rows(next(F.glob(label+'-copies.*.csv'))):
  c={k:float(v)if k in ['start','end']else v if k=='kind'else int(v)for k,v in x.items()}
  if not bounds[0]<=c['start']<hi:continue
  i=bisect.bisect_right(ends.get(c['thread'],[]),c['start'])-1
  if i<0:continue
  r=bythread[c['thread']][i]
  if not(r['destination']<=c['source'] and c['source']+c['bytes']<=r['destination']+r['result']):continue
  offset=r['offset']+c['source']-r['destination'];j=bisect.bisect_right(starts,offset)-1
  if j<0:continue
  t=extents[j]
  if not(t['start']<=offset and offset+c['bytes']<=t['end'] and c['bytes']==460800 and (offset-t['start'])%460800==0):continue
  step=bisect.bisect_right(bounds,c['start'])-1
  cc.append(dict(step=step,layer=t['layer'],expert=(offset-t['start'])//460800,piece=t['piece'],category='forecast'if r['destination']in forecast else'demand',read_start=r['start'],read_end=r['end'],copy_start=c['start'],copy_end=c['end']))
 assert sum(c['category']=='demand'for c in cc)==3*sum(r['records_fetched']for r in steps)
 groups=collections.defaultdict(list)
 for c in cc:groups[(c['step'],c['layer'],c['expert'],c['piece'])].append(c)
 duplicate=[]
 for key,vs in groups.items():
  demands=[c for c in vs if c['category']=='demand'];forecasts=[c for c in vs if c['category']=='forecast']
  for d in demands:
   prior=[f for f in forecasts if f['read_start']<d['read_end']]
   if prior:
    f=min(prior,key=lambda x:abs(x['read_start']-d['read_start']));duplicate.append(dict(key=key,forecast=f,demand=d,forecast_completed_before_demand=f['copy_end']<d['read_start'],reads_overlap=max(f['read_start'],d['read_start'])<min(f['read_end'],d['read_end'])))
 du=union((d['demand']['read_start'],d['demand']['read_end'])for d in duplicate)
 report=dict(folder=folder,demand_pieces=sum(c['category']=='demand'for c in cc),forecast_pieces=sum(c['category']=='forecast'for c in cc),same_cycle_same_piece_read_by_both=len(duplicate),duplicate_records=len(set(tuple(x['key'][:3])for x in duplicate)),duplicate_bytes=len(duplicate)*460800,forecast_copy_finished_before_demand=sum(x['forecast_completed_before_demand']for x in duplicate),concurrent_duplicate_pieces=sum(x['reads_overlap']for x in duplicate),duplicate_demand_read_service_seconds=sum(x['demand']['read_end']-x['demand']['read_start']for x in duplicate),duplicate_demand_read_union_seconds=length(du))
 reports.append(report);details.append(dict(folder=folder,duplicates=duplicate));print(report)
(P/'duplicate-analysis.json').write_text(json.dumps(dict(scope='Existing clean traces only. Match exact original GGUF row/piece via same-thread preceding read and copy source. Same-cycle overlap does not prove useful adoption, canceled-read semantics or removable critical-path time. A successful copied forecast piece can belong to an incomplete/discarded record. Counts do not include forecast reads canceled before copying.',results=reports),indent=2));(P/'duplicate-details.json').write_text(json.dumps(details))
