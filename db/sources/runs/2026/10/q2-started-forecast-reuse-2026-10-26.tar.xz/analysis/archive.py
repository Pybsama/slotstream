from pathlib import Path
import hashlib,io,json,re,tarfile,subprocess
P=Path(__file__).resolve().parent;R=P.parents[1];Q=P.parent/'q2-started-forecast-20261026';sha=lambda b:hashlib.sha256(b).hexdigest();files={}
for prefix,root in [('analysis',P),('candidate',Q)]:
 for f in root.rglob('*'):
  if not f.is_file()or'__pycache__'in f.parts or f.name in ['archive-receipt.json']:continue
  if f.suffix not in ['.py','.swift','.json','.jsonl','.csv','.log','.stderr','.txt']:continue
  files[prefix+'/'+str(f.relative_to(root))]=f
for n in ['ExpertPrefetch.swift','ExpertStore.swift','NativeInputReadAhead.swift']:
 files['baseline/'+n]=R/'Sources/Slotstream'/n
files['baseline/NativePieceReaderChecks.swift']=R/'Sources/slotstream-cli/NativePieceReaderChecks.swift'
files['baseline/LICENSE']=R/'LICENSE';files['reference/v68-build-identity.json']=R/'.build/native-replay-20261023/v68/build-identity.json'
files['reference/gsq-header.json']=R/'.build/smart-dflash-eval/gsq-header.json'
W=Path('/var/folders/d4/t1c8ltbx5s3_11cs9y6gjh8m0000gp/T/slotstream-splash-host-ugnf26pi/source')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()=='1482f6bbc2abf12375332725302019594150b6cb'
for n in ['runtime/model/SsdReaders.hpp','runtime/model/SsdReaders.cpp','runtime/model/ExpertStore.hpp','runtime/model/ExpertStore.cpp','LICENSE']:
 f=P/('reference-'+Path(n).name);f.write_bytes(subprocess.check_output(['git','show','HEAD:'+n],cwd=W));files['reference/splash/'+n]=f
secret=re.compile(rb'(?:ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{25,}|sk-(?:proj-)?[A-Za-z0-9_-]{30,}|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----)');manifest={}
for n,f in files.items():
 b=f.read_bytes();assert not secret.search(b),n;manifest[n]=dict(bytes=len(b),sha256=sha(b))
dest=R/'db/sources/runs/2026/10/q2-started-forecast-reuse-2026-10-26.tar.xz';assert not dest.exists();raw=json.dumps(manifest,indent=2).encode()
with tarfile.open(dest,'w:xz',preset=3)as t:
 for n,f in sorted(files.items()):t.add(f,arcname=n,recursive=False)
 info=tarfile.TarInfo('archive-manifest.json');info.size=len(raw);t.addfile(info,io.BytesIO(raw))
seen={}
with tarfile.open(dest,'r|xz')as t:
 for m in t:
  b=t.extractfile(m).read()
  if m.name=='archive-manifest.json':assert json.loads(b)==manifest
  else:seen[m.name]=dict(bytes=len(b),sha256=sha(b))
assert seen==manifest
receipt=dict(path=str(dest.relative_to(R)),files=len(manifest),bytes=dest.stat().st_size,sha256=sha(dest.read_bytes()),readback_verified=True,credential_pattern_matches=0,excluded='Executables, libraries, model weights, pycache and duplicate full-source archives. Existing prior trace inputs independently hash-verified against their archives. Failed parser/build sources retained. No runtime change retained.')
(P/'archive-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt,indent=2))
