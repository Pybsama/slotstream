from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'analyze_all_read_duplicates.py').read_text()
a=" report=dict(folder=folder,counts=dict(counts)"
b=""" layers=collections.defaultdict(list)
 for r in mapped:
  if r['category']=='demand':layers[(r['step'],r['layer'])].append(r)
 replacement={x['demand']['start']:x['forecast']['end'] for x in duplicates}
 tails=[]
 for key,rs in layers.items():
  actual=max(r['end'] for r in rs)
  counterfactual=max(min(r['end'],replacement.get(r['start'],r['end'])) for r in rs)
  if actual>counterfactual:tails.append([counterfactual,actual])
 stages=rows(next(F.glob(label+'-commands.*.stages.csv')))
 gpu=union((int(r['gpu_start'])/1e9,int(r['gpu_end'])/1e9) for r in stages if int(r['gpu_end'])>int(r['gpu_start'])>0)
 def intersection(a,b):
  i=j=0;out=[]
  while i<len(a) and j<len(b):
   lo,hi=max(a[i][0],b[j][0]),min(a[i][1],b[j][1])
   if hi>lo:out.append([lo,hi])
   if a[i][1]<b[j][1]:i+=1
   else:j+=1
  return out
 tail=union(tails)
 report=dict(folder=folder,demand_layers=len(layers),layers_with_tail_covered_by_earlier_forecast=len(tails),fixed_schedule_tail_seconds=length(tail),tail_outside_gpu_seconds=length(tail)-length(intersection(tail,gpu)),counts=dict(counts)"""
assert s.count(a)==1
s=s.replace(a,b).replace("all-read-duplicate-analysis.json","duplicate-tail-analysis.json").replace("all-read-duplicate-details.json","duplicate-tail-details.json")
s=s.replace("Repeated service is not a causal/removable critical-path estimate.","Replace duplicate demand completion with earlier same-piece forecast completion while holding all other starts/ends fixed. The difference in last demand completion per layer is a fixed-schedule sensitivity, not a runnable scheduler or prediction of request savings; promoted reads and publication can still dominate.")
exec(compile(s,str(p/'analyze_duplicate_tails.py'),'exec'))
