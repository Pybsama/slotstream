from pathlib import Path
import json,csv,bisect,collections,re
P=Path(__file__).resolve().parent;R=P.parents[1]
exec((P/'analyze_duplicates.py').read_text().split('for folder in')[0],globals())
reports=[];details=[]
for folder in ['q2-full-cycle-20261025','q2-expert-submit-20261025']:
 F=P.parent/folder;label='trace-0-N';steps=json.loads((F/(label+'.json')).read_text())['rounds'][0]['steps'];bounds=[r['start_ns']/1e9 for r in steps];hi=steps[-1]['end_ns']/1e9
 rr=[]
 for x in rows(next(F.glob(label+'-reads.*.csv'))):
  r={k:float(v)if k in ['start','end']else int(v)for k,v in x.items()}
  if r['result']>=65536 and bounds[0]<=r['start']<hi:rr.append(r)
 dest=collections.Counter(r['destination']for r in rr);forecast={k for k,v in dest.most_common(4)};mapped=[]
 for r in rr:
  idx=bisect.bisect_right(starts,r['offset']+16383)-1
  if idx<0:continue
  t=extents[idx];expert=(r['offset']+16383-t['start'])//460800;actual=t['start']+expert*460800
  if not(0<=expert<512 and actual//16384*16384==r['offset'] and ((actual+460800+16383)//16384*16384-r['offset'])==r['result']):continue
  r.update(layer=t['layer'],piece=t['piece'],expert=expert,step=bisect.bisect_right(bounds,r['start'])-1,category='forecast'if r['destination']in forecast else'demand');mapped.append(r)
 counts=collections.Counter(r['category']for r in mapped)
 print('unmapped', [r for r in rr if 'category'not in r][:5])
 groups=collections.defaultdict(list)
 for r in mapped:groups[(r['step'],r['layer'],r['expert'],r['piece'])].append(r)
 duplicates=[]
 for key,rs in groups.items():
  for d in [r for r in rs if r['category']=='demand']:
   fs=[r for r in rs if r['category']=='forecast' and r['start']<d['end']]
   if not fs:continue
   f=min(fs,key=lambda r:abs(r['start']-d['start']));duplicates.append(dict(key=key,demand=d,forecast=f,overlap=max(f['start'],d['start'])<min(f['end'],d['end']),forecast_finished_before_demand=f['end']<=d['start']))
 report=dict(folder=folder,counts=dict(counts),unmapped_large_reads=len(rr)-len(mapped),duplicate_pieces=len(duplicates),duplicate_records=len(set(tuple(x['key'][:3])for x in duplicates)),concurrent_duplicate_pieces=sum(x['overlap']for x in duplicates),forecast_finished_before_demand=sum(x['forecast_finished_before_demand']for x in duplicates),duplicate_demand_service_seconds=sum(x['demand']['end']-x['demand']['start']for x in duplicates),duplicate_demand_union_seconds=length(union((x['demand']['start'],x['demand']['end'])for x in duplicates)))
 reports.append(report);details.append(dict(folder=folder,duplicates=duplicates));print(report)
(P/'all-read-duplicate-analysis.json').write_text(json.dumps(dict(scope='All positive aligned expert-piece preads, including forecast reads canceled before copying. Exact file-aligned row extent and same cycle/key required. Repeated service is not a causal/removable critical-path estimate.',results=reports),indent=2));(P/'all-read-duplicate-details.json').write_text(json.dumps(details))
