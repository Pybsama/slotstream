from pathlib import Path
import json,hashlib,shutil
P=Path(__file__).resolve().parent;R=P.parents[1];V=R/'.build/native-replay-20261023/v68';Q=R/'.build/q2-aligned-forecast-request-20261026'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();base=json.loads((V/'build-identity.json').read_text());c=P/'build-C/candidate';ident=json.loads((c/'build-identity.json').read_text())
assert ident['binary_sha256']==sha(c/'slotstream')
diff=[n for n,h in ident['source'].items()if base['source'][n]!=h];assert sorted(diff)==sorted(json.loads((P/'C-paths.json').read_text()))
for n in diff:assert ident['source'][n]==sha(P/'source-C'/n)
files=[P/n for n in ['plan.json','prepare.py','prepare_controls.py','build.py','BudgetControl.swift','budget-control.log','request_run.py','quiet_guarded_run.py','q2_upstream_bench_io.py','cases.json','C.patch']]+[c/n for n in ['slotstream','mlx.metallib','build-identity.json']]
b=R/'.build/q2-sequence-20261025/native-forecast-sequence-build/candidate';s=R/'.build/smart-dflash-eval/upstream/splash-1.4.0-arm64-macos26/engine/splash'
files.extend([V/'slotstream',V/'build-identity.json',b/'slotstream',b/'build-identity.json',s]);files.extend(P.joinpath('source-C').rglob('*.swift'));files.extend(P.joinpath('source-C').rglob('*.cpp'));files.extend(P.joinpath('source-C').rglob('*.h'))
assert 'PASS 320 observations' in(P/'budget-control.log').read_text()
assert not(P/'frozen-identity.json').exists();(P/'frozen-identity.json').write_text(json.dumps({str(f):sha(f)for f in files},indent=2));(P/'identity-validation.json').write_text(json.dumps(dict(differing_sources=diff,baseline=sha(V/'slotstream'),copy=sha(b/'slotstream'),candidate=sha(c/'slotstream'),Splash=sha(s),controller_check_passed=True),indent=2));print('Frozen exact four-way executable and harness identities')
