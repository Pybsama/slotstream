from pathlib import Path
import fcntl,hashlib,io,json,os,re,sys,tarfile
P=Path(__file__).resolve().parent;R=P.parents[1];D=P.parent/'q2-adaptive-decisions-20261026';Q=P.parent/'q2-aligned-forecast-request-20261026'
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
lock=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(P/'archive-inner.lock');preflight(4)
assert json.loads((P/'analysis.json').read_text())['clean'];assert json.loads((D/'control-result.json').read_text())['timing_sensitivity_passed']
sha=lambda b:hashlib.sha256(b).hexdigest();allowed={'.py','.swift','.cpp','.h','.hpp','.json','.jsonl','.log','.stderr','.txt','.patch'};files={}
for prefix,root in [('adaptive-decisions',D),('preparation-cost',P)]:
 for f in root.rglob('*'):
  if not f.is_file()or '__pycache__'in f.parts or f.suffix not in allowed or f.name.startswith('archive-receipt')or(f.name.startswith('archive')and f.suffix=='.log'):continue
  files[prefix+'/'+str(f.relative_to(root))]=f
for n,f in [('LICENSE',R/'LICENSE'),('splash-NOTICE.txt',R/'Licenses/splash-NOTICE.txt'),('MLX-LICENSE.txt',R/'.build/checkouts/mlx-swift/LICENSE'),('THIRD_PARTY_NOTICES.md',R/'THIRD_PARTY_NOTICES.md'),('v68-identity.json',R/'.build/native-replay-20261023/v68/build-identity.json'),('copy-only-identity.json',Q/'candidate-identity.json'),('original-control-reference.json',Q/'forecast-15-0-A.json'),('prior-ordinary-analysis.json',Q/'analysis.json'),('prior-fixed-prose-analysis.json',R/'.build/q2-aligned-forecast-prose-20261026/analysis.json'),('superseded-Fast-caveat.json',Q/'fast-scope-clarification.json'),('prior-v60-review.json',R/'.build/q2-sequence-20261025/cost-trace-prior-v60-review.json')]:files['reference/'+n]=f
pattern=re.compile(rb'(?:ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{25,}|sk-(?:proj-)?[A-Za-z0-9_-]{30,}|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----)');manifest={}
for n,f in files.items():
 b=f.read_bytes();assert not pattern.search(b),n;manifest[n]=dict(bytes=len(b),sha256=sha(b))
dest=R/'db/sources/runs/2026/10/q2-adaptive-decisions-and-preparation-2026-10-26.tar.xz';assert not dest.exists()
with tarfile.open(dest,'w:xz',preset=3)as t:
 for n,f in sorted(files.items()):t.add(f,arcname=n,recursive=False)
 data=json.dumps(manifest,indent=2).encode();info=tarfile.TarInfo('archive-manifest.json');info.size=len(data);t.addfile(info,io.BytesIO(data))
seen={}
with tarfile.open(dest,'r|xz')as t:
 for m in t:
  b=t.extractfile(m).read()
  if m.name=='archive-manifest.json':assert json.loads(b)==manifest
  else:seen[m.name]=dict(bytes=len(b),sha256=sha(b))
assert seen==manifest and dest.stat().st_size<100_000_000
receipt=dict(path=str(dest.relative_to(R)),files=len(manifest),bytes=dest.stat().st_size,sha256=sha(dest.read_bytes()),readback_verified=True,credential_pattern_matches=0,excluded='Executables/libraries, modelweights, pycache and active archive output. Full changed source, harnesses, binary/source identities, all arms, references, guards, clocks, analyses and restoration included.')
(P/'archive-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt,indent=2))
