from pathlib import Path
import json,shutil
P=Path(__file__).resolve().parent;R=P.parents[1];Q=R/'.build/q2-aligned-forecast-request-20261026';D=R/'.build/q2-adaptive-decisions-20261026'
s=(Q/'request_run.py').read_text();s=s.replace("ap.add_argument('--baseline',required=True);","ap.add_argument('--baseline',required=True);ap.add_argument('--copy',required=True);")
s=s.replace("default='ABCCBA'","default='ABCSSCBA'").replace("a.order=='ABCCBA'","a.order=='ABCSSCBA'")
s=s.replace("A v68, B aligned forecast-only reads into existing128MiB reservation, C published Splash.","A v68, B aligned forecast-only, C alignedforecast plus Q2 prepared-cycle cost omission, S publishedSplash. All hypotheses/acceptance limits in frozen plan.json.")
s=s.replace("if arm in ('A','B')", "if arm in ('A','B','C')")
s=s.replace("a.native if arm=='B' else a.baseline","{'A':a.baseline,'B':a.copy,'C':a.native}[arm]")
old='''  finally:
   if child.poll() is None:terminate_child_tree(child)
   time.sleep(.5)
   if monitor.poll() is None:terminate_child_tree(monitor)'''
new='''  finally:
   try:
    if child.poll() is None:terminate_child_tree(child)
   finally:
    if monitor.poll() is None:
     import signal
     try:os.killpg(monitor.pid,signal.SIGTERM)
     except ProcessLookupError:pass
     try:monitor.wait(timeout=5)
     except subprocess.TimeoutExpired:
      try:os.killpg(monitor.pid,signal.SIGKILL)
      except ProcessLookupError:pass
      monitor.wait(timeout=5)'''
assert s.count(old)==1;s=s.replace(old,new)
# Keep the explicit original sampling defaults and same physical/slot guards.
(P/'request_run.py').write_text(s)
b=(R/'Sources/Slotstream/DFlashVerifyBudget.swift').read_text();snap=(D/'source-A/Sources/Slotstream/DFlashVerifyBudget.swift').read_text();snap=snap[snap.index('    // Temporary diagnostic snapshot'):snap.index('    package func depth')]
b=b.replace('    package func depth',snap+'    package func depth',1)
test='''
var normal = DFlashVerifyBudget(), omitted = DFlashVerifyBudget()
var checks = 0
for i in 0..<320 {
    let confidence: [Float] = [0.95, 0.8, 0.65, 0.50, 0.35, 0.2, 0.1]
    let verified = i % 8, accepted = i % (verified + 1)
    let bonus: Bool? = accepted == verified && verified < 7 ? i % 2 == 0 : nil
    let seconds = i == 0 ? 2.0 : 0.06 + Double(verified) * 0.012
    normal.observe(confidence: confidence, verified: verified, accepted: accepted,
        seconds: seconds, labelsValid: i % 13 != 12, bonusAccepted: bonus)
    omitted.observe(confidence: confidence, verified: verified, accepted: accepted,
        seconds: i == 0 ? .nan : seconds, labelsValid: i % 13 != 12, bonusAccepted: bonus)
    precondition(normal.cycleCount == omitted.cycleCount && normal.labelCount == omitted.labelCount)
    precondition(normal.diagnosticSnapshot().theta == omitted.diagnosticSnapshot().theta)
    precondition(omitted.diagnosticSnapshot().costs.allSatisfy { $0.isFinite && $0 > 0 })
    if i == 0 { precondition(normal.diagnosticSnapshot().costs != omitted.diagnosticSnapshot().costs) }
    checks += 1
}
// No skipped cost when preparation did not occur: production finite input remains exact.
var a = DFlashVerifyBudget(), b = DFlashVerifyBudget()
for i in 0..<128 {
    let c: [Float] = [0.8, 0.7, 0.6, 0.5, 0.4, 0.3, 0.2]
    a.observe(confidence: c, verified: 7, accepted: i % 8, seconds: 0.1)
    b.observe(confidence: c, verified: 7, accepted: i % 8, seconds: false ? .nan : 0.1)
    precondition(a.diagnosticSnapshot().costs == b.diagnosticSnapshot().costs)
    precondition(a.diagnosticSnapshot().theta == b.diagnosticSnapshot().theta)
    precondition(a.depth(confidence: c) == b.depth(confidence: c))
    checks += 1
}
print("PASS \\(checks) observations: labels/cycles/fitted acceptance preserved; finite observations unchanged")
'''
(P/'BudgetControl.swift').write_text(b+test)
print('Prepared guarded four-way runner and extracted actual-controller checks')
