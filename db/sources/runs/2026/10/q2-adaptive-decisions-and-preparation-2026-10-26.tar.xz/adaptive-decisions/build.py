from pathlib import Path
import json,sys,shutil,hashlib,subprocess,stat,fcntl,os
P=Path(__file__).resolve().parent;R=P.parents[1];B=R/'.build/native-replay-20261023/v68';M=R/'.build/checkouts/mlx-swift'
sys.path.insert(0,str(R/'Tools'));from optimization_build import build
arm=sys.argv[1];assert arm in ['A','B'];reservation=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(reservation,fcntl.LOCK_EX|fcntl.LOCK_NB)
paths=json.loads((P/(arm+'-paths.json')).read_text());original={n:(R/n).read_bytes()for n in paths};modes={n:stat.S_IMODE((R/n).stat().st_mode)for n in paths};result={}
assert not subprocess.check_output(['git','status','--porcelain'],cwd=M,text=True).strip()
try:
 for n in paths:(R/n).chmod(modes[n]|stat.S_IWUSR);(R/n).write_bytes((P/('source-'+arm)/n).read_bytes())
 result=build(R,P/('build-'+arm),required_gb=10,jobs=4,lock_path=str(P/'build-inner.lock'));print(json.dumps({k:v for k,v in result.items()if k in ['passed','error','elapsed_seconds']}),flush=True)
finally:
 for n,b in original.items():(R/n).chmod(modes[n]|stat.S_IWUSR);(R/n).write_bytes(b);(R/n).chmod(modes[n])
 for n in ['slotstream','slotstream-checks','mlx.metallib','build-identity.json','build-source.tar.gz']:shutil.copy2(B/n,R/'.build/release'/n)
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=M,text=True).strip()
 base=json.loads((B/'build-identity.json').read_text())['source'];assert all(hashlib.sha256((R/n).read_bytes()).hexdigest()==h for n,h in base.items())
 (P/(arm+'-restoration.json')).write_text(json.dumps(dict(runtime_source_count=len(base),sources_exact=True,dependency_clean=True,modes_exact=all(stat.S_IMODE((R/n).stat().st_mode)==modes[n]for n in paths),default_binary_sha256=hashlib.sha256((R/'.build/release/slotstream').read_bytes()).hexdigest()),indent=2))
if not result.get('passed'):raise SystemExit(1)
