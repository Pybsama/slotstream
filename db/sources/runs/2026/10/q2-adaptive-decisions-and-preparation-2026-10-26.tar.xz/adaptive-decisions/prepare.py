from pathlib import Path
import json,difflib,shutil,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1];Q=R/'.build/q2-aligned-forecast-request-20261026'
assert not(P/'plan.json').exists()
shutil.copy2(Q/'cases.json',P/'cases.json');shutil.copy2(Q/'quiet_guarded_run.py',P/'quiet_guarded_run.py')
ref=json.loads((Q/'forecast-15-0-A.json').read_text())
(P/'choices.json').write_text(json.dumps([dict(prompt_ids=r['prompt_ids'],depths=r['stats']['adaptiveDraftDepths'])for r in ref['runs']],indent=2))
s=(R/'Sources/Slotstream/DFlashGenerate.swift').read_text()
old=(R/'.build/q2-sequence-20261025/replay-choice-src/Sources/Slotstream/DFlashGenerate.swift').read_text()
replay=old[old.index('        // Diagnostic-only: replay'):old.index('        let useVerifyBudget')]
s=s.replace('        let useVerifyBudget',replay+'        let useVerifyBudget',1)
oldtrace=(R/'.build/q2-sequence-20261025/cost-trace-src/Sources/Slotstream/DFlashGenerate.swift').read_text()
insert=oldtrace[oldtrace.index('        let costTracePath'):oldtrace.index('        // Diagnostic-only: replay')]
# Fixed-width rows, bounded in memory. No per-cycle serialization.
insert=insert.replace('            let draftSeconds: Double','            let selectSeconds: Double\n            let observeSeconds: Double\n            let draftSeconds: Double')
s=s.replace('        // Diagnostic-only: replay',insert+'        // Diagnostic-only: replay',1)
marker='            let pipelinesBefore = q2Calibration ? NativeProjectionSchedule.pipelineCount : 0'
pre='''            let decision = costTracePath == nil ? nil : verifyBudget?.diagnosticSnapshot()
            let traceContext = state.tokenCount
            let traceHits = costTracePath == nil ? 0 : model.pool.hits
            let traceMisses = costTracePath == nil ? 0 : model.pool.misses
            let traceDraft = stats.draftSeconds, traceVerify = stats.verifySeconds
'''
s=s.replace(marker,pre+marker,1)
choice='            let chosen = verifyBudget.map { $0.depth(confidence: draft.proposalConfidence) } ?? guesses.count'
s=s.replace(choice,'''            let selectStart = costTracePath == nil ? UInt64(0) : RuntimeClock.now()
            let chosen: Int
            if let replayDepths {
                guard stats.verifyPasses < replayDepths.count else { throw ModelError("Diagnostic choices exhausted") }
                chosen = replayDepths[stats.verifyPasses]
                guard chosen <= guesses.count else { throw ModelError("Diagnostic choices exceed proposal extent") }
            } else {
                chosen = verifyBudget.map { $0.depth(confidence: draft.proposalConfidence) } ?? guesses.count
            }
            let selectSeconds = costTracePath == nil ? 0 : RuntimeClock.seconds(since: selectStart)''',1)
obs='''            verifyBudget?.observe(confidence: draft.proposalConfidence, verified: proposals.count,
                accepted: accepted, seconds: RuntimeClock.seconds(since: started),
                labelsValid: labelsValid, bonusAccepted: bonusAccepted)'''
new='''            let cycleSeconds = RuntimeClock.seconds(since: started)
            let observeStart = costTracePath == nil ? UInt64(0) : RuntimeClock.now()
            verifyBudget?.observe(confidence: draft.proposalConfidence, verified: proposals.count,
                accepted: accepted, seconds: cycleSeconds,
                labelsValid: labelsValid, bonusAccepted: bonusAccepted)
            let observeSeconds = costTracePath == nil ? 0 : RuntimeClock.seconds(since: observeStart)
            if let decision, costCycles.count < 8192 {
                costCycles.append(CostCycle(cycle: stats.verifyPasses - 1, context: traceContext,
                    decision: decision, confidence: draft.proposalConfidence, chosen: proposals.count,
                    accepted: accepted, emitted: out.count - emittedBefore, bonus: bonusAccepted,
                    labelsValid: labelsValid, prepared: preparedPipelines, seconds: cycleSeconds,
                    selectSeconds: selectSeconds, observeSeconds: observeSeconds,
                    draftSeconds: stats.draftSeconds - traceDraft,
                    verifySeconds: stats.verifySeconds - traceVerify,
                    hits: model.pool.hits - traceHits, misses: model.pool.misses - traceMisses))
            }'''
assert s.count(obs)==1;s=s.replace(obs,new)
ending='        }\n    }\n}\n';assert s.endswith(ending)
finish=oldtrace[oldtrace.index('        if let costTracePath {\n            let trace'):]
s=s[:-len(ending)]+'        }\n'+finish
b=(R/'Sources/Slotstream/DFlashVerifyBudget.swift').read_text();oldb=(R/'.build/q2-sequence-20261025/cost-trace-src/Sources/Slotstream/DFlashVerifyBudget.swift').read_text()
bs=oldb[oldb.index('    // Temporary diagnostic snapshot'):oldb.index('    package func depth')]
b=b.replace('    package func depth',bs+'    package func depth',1)
base={'Sources/Slotstream/DFlashGenerate.swift':s,'Sources/Slotstream/DFlashVerifyBudget.swift':b}
qid=json.loads((Q/'candidate-identity.json').read_text())['source'];bid=json.loads((Q/'baseline-identity.json').read_text())['source']
changes=[n for n,h in qid.items() if bid[n]!=h and n!='Sources/slotstream-cli/Q2ProfileCommand.swift'];assert len(changes)==7
for arm in ['A','B']:
 files=base.copy()
 if arm=='B':
  for n in changes:files[n]=(Q/'candidate-source'/n).read_text()
 for n,v in files.items():
  dest=P/('source-'+arm)/n;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(v)
 (P/(arm+'-paths.json')).write_text(json.dumps(list(files),indent=2))
 (P/(arm+'.patch')).write_text(''.join(''.join(difflib.unified_diff((R/n).read_text().splitlines(True),v.splitlines(True),fromfile='a/'+n,tofile='b/'+n))for n,v in files.items()))
(P/'plan.json').write_text(json.dumps(dict(purpose='Diagnose actual adaptive work after aligned forecast-only copy removal. No changed controller or production optimization.',baseline='v68',candidate='Exactly seven forecast-only runtime changes from prior ordinary study, plus identical bounded decision instrument.',control='A same diagnostic binary off/on/on/off with exact prior A0 choices replayed. All four requests and outputs must reproduce prior baseline, otherwise fail. Two warmup requests then code/prose384. A2percent pooled and each paired timing sensitivity bound is required for quantitative timing attribution. Shared diagnostic wrappers remain in off control; this does not establish unmodified-source sensitivity.',ordinary='A B B A, both trace-enabled, original automatic decisions. Same two warmups then code/prose384. One complete protocol, no retries. First divergence, confidence calibration, chosen/accepted/bonus, predicted cost, actual cost, refit and selection overhead. Observational trace is not shipping performance evidence.',bounds='15GB physical maximum,>=18GB preflight,4067slots,8192context,BF16activationKV,FP32state. Main lock held through protocol and gaps. Perchild inner lock. No competing build, no GPUspin, no read tracing. Any paging/thermal/externalbuild excludes timing aggregate but retains functional data.',hypotheses=['Additional anchor-only passes reflect poorly calibrated acceptance probabilities','Changed cost estimates overprice verification width','Same math and reasonable decisions lead to different trajectories, not a controller bug','Refitting CPU overhead is material'],decision='Only propose a small correction after evidence. No minimum-width forcing, cost omission or reset merely to improve fixture. Existing strict-format and Fast recall failures remain independent. No app qualification or promotion.'),indent=2))
print('Prepared two diagnostic source variants, seven candidate runtime differences')
