from pathlib import Path
import json,sys,subprocess,fcntl,os,argparse,time,hashlib,signal,statistics
P=Path(__file__).resolve().parent;R=P.parents[1];Q=R/'.build/q2-aligned-forecast-request-20261026'
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight,terminate_child_tree
sys.path.insert(0,str(R/'.build/native-q2-20261021'));from thermal import wait_nominal
ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['control','ordinary']);a=ap.parse_args()
reservation=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(reservation,fcntl.LOCK_EX|fcntl.LOCK_NB)
inner=P/(a.mode+'-child.lock');os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(inner)
frozen=json.loads((P/'frozen-identity.json').read_text());assert all(hashlib.sha256(Path(n).read_bytes()).hexdigest()==h for n,h in frozen.items())
ledger=P/(a.mode+'-ledger.json');assert not ledger.exists();events=[]
reference=json.loads((Q/'forecast-15-0-A.json').read_text())['runs']
sequence=[('A',False),('A',True),('A',True),('A',False)] if a.mode=='control'else [(x,True)for x in 'ABBA']
for i,(arm,trace) in enumerate(sequence):
 label=f'{a.mode}-{i}-{arm}';out=P/(label+'.json');tracepath=P/(label+'-trace.jsonl');assert not out.exists()and not tracepath.exists()
 wait_nominal(P/(label+'-cooldown.json'));preflight(18)
 env=['--env','SLOTSTREAM_MODEL_LOCK_PATH='+str(inner),'--env','DYLD_INSERT_LIBRARIES=']
 if trace:env+=['--env','SLOTSTREAM_Q2_COST_TRACE='+str(tracepath)]
 if a.mode=='control':env+=['--env','SLOTSTREAM_Q2_DIAGNOSTIC_CHOICES='+str(P/'choices.json')]
 cmd=[str(P/('build-'+arm)/'candidate/slotstream'),'smart-dflash-check','--native-read-ahead','on','--method','q2','--model','smart-q2','--memory-gb','15','--max-context','8192','--cases',str(P/'cases.json'),'--output',str(out)]
 full=[sys.executable,str(P/'quiet_guarded_run.py'),'--label',label,'--budget','15','--timeout','600',*env,'--',*cmd]
 print('START',label,'trace',trace,flush=True);monitor=None
 with(P/(label+'-launcher.log')).open('x')as log,(P/(label+'-frequency.jsonl')).open('x')as freq,(P/(label+'-frequency.stderr')).open('x')as ferr:
  monitor=subprocess.Popen([str(R/'.build/native-monitor/macmon'),'pipe','-s','3300','-i','200','--soc-info'],stdout=freq,stderr=ferr,start_new_session=True)
  child=subprocess.Popen(full,cwd=R,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:rc=child.wait(timeout=660)
  finally:
   try:
    if child.poll()is None:terminate_child_tree(child)
   finally:
    if monitor.poll()is None:
     try:os.killpg(monitor.pid,signal.SIGTERM)
     except ProcessLookupError:pass
     try:monitor.wait(timeout=5)
     except subprocess.TimeoutExpired:
      try:os.killpg(monitor.pid,signal.SIGKILL)
      except ProcessLookupError:pass
      monitor.wait(timeout=5)
 guard=json.loads((P/(label+'.observer.json')).read_text());event=dict(label=label,arm=arm,trace=trace,exit_code=rc,command=full,eligible=not guard['external_build_samples']and not guard['paging']and guard['thermal_before']==guard['thermal_after']==0 and guard['peak_combined_bytes']<=15e9 and rc==0)
 events.append(event);ledger.write_text(json.dumps(events,indent=2));assert rc==0
 d=json.loads(out.read_text());assert d['complete']and d['plan']['pool_slots']==4067 and len(d['runs'])==4
 for old,row in zip(reference,d['runs']):
  assert row['prompt_ids']==old['prompt_ids'] and len(row['tokens'])==384 and row['stats']['peakMemoryGB']<=15 and row['stats']['reusedPrefixTokens']==0 and row['stats'].get('runtimeError')is None
  if a.mode=='control':
   for k in ['tokens','text','streamed','tool_calls','malformed_tool_call']:assert row[k]==old[k],(label,row['id'],k)
   for k in ['verifyPasses','draftedTokens','acceptedDrafts','decodeModelTokens','adaptiveDraftDepths']:assert row['stats'][k]==old['stats'][k],(label,row['id'],k)
 if trace:
  records=[json.loads(s)for s in tracepath.read_text().splitlines()];assert len(records)==4
  for row,tr in zip(d['runs'],records):
   assert tr['prompt_ids']==row['prompt_ids']and not tr['truncated']
   assert [c['chosen']for c in tr['cycles']]==row['stats']['adaptiveDraftDepths']
   assert sum(c['accepted']for c in tr['cycles'])==row['stats']['acceptedDrafts']
   assert sum(c['emitted']for c in tr['cycles'])==383
 event['checks_passed']=True;event['runs']=[dict(id=r['id'],seconds=r['elapsed_seconds'],passes=r['stats']['verifyPasses'],anchors=r['stats']['adaptiveDraftDepths'].count(0),rows=r['stats']['decodeModelTokens'],peak_gb=r['stats']['peakMemoryGB'])for r in d['runs']]
 ledger.write_text(json.dumps(events,indent=2));print('END',label,event['eligible'],event['runs'][2:],flush=True)
if a.mode=='control':
 result=dict(clean=all(e['eligible']for e in events),functional_exact=True,tasks=[])
 for t in range(2,4):
  times=[e['runs'][t]['seconds']for e in events];ratios=[times[1]/times[0],times[2]/times[3]];pooled=(times[1]+times[2])/(times[0]+times[3]);result['tasks'].append(dict(id=events[0]['runs'][t]['id'],times=times,ratios=ratios,pooled=pooled,within_two_percent=all(abs(v-1)<=.02 for v in ratios+[pooled])))
 result['timing_sensitivity_passed']=result['clean']and all(t['within_two_percent']for t in result['tasks'])
 (P/'control-result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
print('PROTOCOL FINISHED',flush=True)
