from pathlib import Path
import json,statistics,ctypes,math
P=Path(__file__).resolve().parent
f32=lambda x:ctypes.c_float(x).value
lib=ctypes.CDLL('/usr/lib/libSystem.B.dylib')
for n in ['logf','expf']:
 f=getattr(lib,n);f.argtypes=[ctypes.c_float];f.restype=ctypes.c_float
def policy(c,costs=None,theta=None):
 d=c['decision'];costs=list(map(f32,costs or d['costs']));theta=theta or d['theta'];survival=f32(1);expected=f32(1);scores=[f32(1/costs[0])];probs=[]
 for i,confidence in enumerate(c['confidence']):
  p=max(f32(1e-6),min(f32(1-f32(1e-6)),f32(confidence)))
  z=f32(f32(f32(theta[0])*lib.logf(f32(p/f32(1-p))))+f32(theta[i+1]))
  probability=f32(1/f32(1+lib.expf(-z)));probs.append(probability)
  survival=f32(survival*probability);expected=f32(expected+survival);scores.append(f32(expected/costs[i+1]))
 choice=max(range(len(scores)),key=lambda k:scores[k])
 if d['cycles']%32==31:choice=len(c['confidence'])
 return choice,scores,probs
def mean(xs):return statistics.mean(xs)if xs else None
out=dict(scope='Decision and cost observations from actual automatic requests. Same-binary sensitivity control; no claim of a retained speedup. Different trajectories are not identical work.',arms=[],comparisons=[])
traces={};runs={}
for e in json.loads((P/'ordinary-ledger.json').read_text()):
 label=e['label'];rr=json.loads((P/(label+'.json')).read_text())['runs'];tt=[json.loads(s)for s in(P/(label+'-trace.jsonl')).read_text().splitlines()];runs[label]=rr;traces[label]=tt;tasks=[]
 for row,tr in zip(rr,tt):
  cc=tr['cycles'];s=row['stats'];assert all(policy(c)[0]==c['chosen']for c in cc)
  assert all(c['decision']['cycles']==s['dflashCalibrationCyclesBefore']+i for i,c in enumerate(cc))
  anchors=[];pred=[];obs=[]
  for c in cc:
   p=policy(c)[2]
   if c['labelsValid']:
    n=min(c['chosen'],c['accepted']+1)+(1 if c.get('bonus')is not None and c['accepted']==c['chosen']else 0)
    for i in range(n):pred.append(p[i]);obs.append(i<c['accepted']or(i==c['chosen']and c.get('bonus')is True))
   if c['chosen']==0:
    scores=policy(c)[1]
    anchors.append(dict(cycle=c['cycle'],context=c['context'],first_confidence=c['confidence'][0],predicted_first_acceptance=p[0],actual_bonus=c.get('bonus'),cost1=c['decision']['costs'][0],cost2=c['decision']['costs'][1],cost8=c['decision']['costs'][7],two_row_score_over_one=scores[1]/scores[0],best_multirow_score_over_one=max(scores[1:])/scores[0],seconds=c['seconds'],misses=c['misses']))
  groups={}
  for w in range(1,9):
   subset=[c for c in cc if c['chosen']+1==w and c['decision']['cycles']>0 and not c['prepared']]
   if subset:groups[w]=dict(count=len(subset),actual_median=statistics.median(c['seconds']for c in subset),predicted_median=statistics.median(c['decision']['costs'][w-1]for c in subset),actual_over_prediction_median=statistics.median(c['seconds']/c['decision']['costs'][w-1]for c in subset),accepted_per_pass=mean([c['accepted']for c in subset]),misses_per_pass=mean([c['misses']for c in subset]))
  tasks.append(dict(id=row['id'],elapsed=row['elapsed_seconds'],prefill=s['prefillSeconds'],decode=s['decodeSeconds'],passes=len(cc),rows=sum(c['chosen']+1 for c in cc),accepted=sum(c['accepted']for c in cc),misses=sum(c['misses']for c in cc),anchors=anchors,by_width=groups,observed_labels=len(obs),mean_predicted_label=mean(pred),mean_actual_label=mean(obs),select_seconds=sum(c['selectSeconds']for c in cc),observe_seconds=sum(c['observeSeconds']for c in cc),refit_seconds=sum(c['observeSeconds']for c in cc if(c['decision']['cycles']+1)%64==0),cycle_seconds=sum(c['seconds']for c in cc),prepared=sum(c['prepared']for c in cc)))
 out['arms'].append(dict(label=label,clean=e['eligible'],tasks=tasks))
for an,bn in [('ordinary-0-A','ordinary-1-B'),('ordinary-3-A','ordinary-2-B')]:
 for ra,rb,ta,tb in zip(runs[an],runs[bn],traces[an],traces[bn]):
  oa=ob=1;first=None
  for ca,cb in zip(ta['cycles'],tb['cycles']):
   if ca['chosen']!=cb['chosen']:
    first=dict(A=ca,B=cb,same_confidence=ca['confidence']==cb['confidence'],same_theta=ca['decision']['theta']==cb['decision']['theta'],same_output_prefix=oa==ob and ra['tokens'][:oa]==rb['tokens'][:ob],A_with_B_cost=policy(ca,cb['decision']['costs'])[0],B_with_A_cost=policy(cb,ca['decision']['costs'])[0],A_with_B_theta=policy(ca,theta=cb['decision']['theta'])[0],B_with_A_theta=policy(cb,theta=ca['decision']['theta'])[0]);break
   oa+=ca['emitted'];ob+=cb['emitted']
  token_divergence=next((i for i,(x,y)in enumerate(zip(ra['tokens'],rb['tokens']))if x!=y),None)
  out['comparisons'].append(dict(A=an,B=bn,id=ra['id'],first_different_choice=first,first_different_output_token=token_divergence))
(P/'analysis.json').write_text(json.dumps(out,indent=2))
print(json.dumps(dict(arms=[dict(label=a['label'],clean=a['clean'],tasks=[dict(id=t['id'],passes=t['passes'],anchors=len(t['anchors']),anchor_bonus_true=sum(c['actual_bonus']is True for c in t['anchors']),anchor_predicted_acceptance=mean([c['predicted_first_acceptance']for c in t['anchors']]),select_ms=1000*t['select_seconds'],observe_ms=1000*t['observe_seconds'],elapsed=t['elapsed'],prefill=t['prefill'],accepted=t['accepted'],predicted_labels=t['mean_predicted_label'],actual_labels=t['mean_actual_label'])for t in a['tasks'][2:]])for a in out['arms']],first_divergences=[dict(A=c['A'],B=c['B'],id=c['id'],token=c['first_different_output_token'],choice=None if c['first_different_choice']is None else {k:v for k,v in c['first_different_choice'].items()if k not in ['A','B']})for c in out['comparisons']]),indent=2))
