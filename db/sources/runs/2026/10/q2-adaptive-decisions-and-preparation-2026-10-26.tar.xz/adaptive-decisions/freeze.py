from pathlib import Path
import json,hashlib,shutil
P=Path(__file__).resolve().parent;R=P.parents[1];V=R/'.build/native-replay-20261023/v68';Q=R/'.build/q2-aligned-forecast-request-20261026'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();base=json.loads((V/'build-identity.json').read_text())
files=[P/n for n in ['prepare.py','build.py','run.py','plan.json','cases.json','choices.json','quiet_guarded_run.py','A.patch','B.patch']]
validation={}
for a in ['A','B']:
 d=P/('build-'+a)/'candidate';identity=json.loads((d/'build-identity.json').read_text());assert identity['binary_sha256']==sha(d/'slotstream')
 diff=[n for n,h in identity['source'].items()if base['source'][n]!=h];assert sorted(diff)==sorted(json.loads((P/(a+'-paths.json')).read_text())),diff
 for n in diff:assert identity['source'][n]==sha(P/('source-'+a)/n)
 validation[a]=dict(differing_sources=diff,binary_sha256=identity['binary_sha256'])
 files.extend([d/n for n in ['slotstream','mlx.metallib','build-identity.json']]);files.extend((P/('source-'+a)).rglob('*.swift'));files.extend((P/('source-'+a)).rglob('*.cpp'));files.extend((P/('source-'+a)).rglob('*.h'))
files.extend([V/'build-identity.json',Q/'forecast-15-0-A.json'])
assert not(P/'frozen-identity.json').exists();(P/'frozen-identity.json').write_text(json.dumps({str(f):sha(f)for f in files},indent=2));(P/'identity-validation.json').write_text(json.dumps(validation,indent=2));print('Frozen diagnostic identities and original control reference',flush=True)
