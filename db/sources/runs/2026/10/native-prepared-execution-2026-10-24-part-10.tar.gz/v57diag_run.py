from pathlib import Path
import sys,subprocess,json,time
P=Path(__file__).resolve().parent;R=P.parents[1]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
preflight(12);events=[]
for label,cmd in [('v57diag-build',['make','build','SLOTSTREAM_BUILD_JOBS=4']),('v57diag-freeze',[sys.executable,str(P/'freeze.py'),'v57diag']),('v57diag-pool',[sys.executable,str(P/'guarded_run.py'),'--label','v57diag-pool','--budget','3','--timeout','900','--',str(P/'v57diag/slotstream'),'q2-experts-check','--pool-model','smart-q2'])]:
 print('START',label,flush=True);start=time.monotonic()
 with(P/(label+'-driver.log')).open('x')as f:r=subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT)
 events.append(dict(label=label,command=cmd,exit_code=r.returncode,seconds=time.monotonic()-start));(P/'v57diag-ledger.json').write_text(json.dumps(events,indent=2)+'\n');print('END',label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
