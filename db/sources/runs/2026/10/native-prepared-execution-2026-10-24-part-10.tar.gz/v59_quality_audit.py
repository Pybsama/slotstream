import json
from pathlib import Path
P=Path(__file__).resolve().parent
out=[]
for model in ['fast','smart-q2']:
 name='v59-native-quality-'+model
 grades=json.loads((P/(name+'-grades.json')).read_text())
 upstream=json.loads((P/('matched9-splash-quality-'+model+'-grades.json')).read_text())
 before={r['id']:r for r in upstream['rows']};after={r['id']:r for r in grades['rows']}
 assert before.keys()==after.keys()
 differences=[i for i in before if any(before[i][k]!=after[i][k]for k in ['semantic','strict'])]
 d=json.loads((P/(name+'.json')).read_text());rows=d['runs']
 raw=json.loads((P/(name+'-functional.json')).read_text())
 runtime={k:v for k,v in raw['checks'].items()if k!='calibration_policy'}
 persistence=any((r['stats'].get('dflashCalibrationCyclesBefore')or 0)>0 for r in rows)
 bonus=sum(r['stats'].get('dflashBonusObservations')or 0 for r in rows)
 controller_policy=persistence if model=='smart-q2' else not persistence and bonus==0
 out.append(dict(model=model,source=name+'.json',semantic=grades['semantic'],strict=grades['strict'],quality_changes_vs_upstream=differences,
  runtime_checks=runtime,default_persistence_policy=controller_policy,bonus_observations=bonus,
  bonus_coverage_scope='Short-suite bonus coverage is reported separately, not assumed. Require actual branch proof in the selected-build long comparison.' if model=='smart-q2' else 'Fast bonus labels remain disabled.',
  runtime_and_quality_pass=all(runtime.values()) and controller_policy and not differences))
assert all(r['runtime_and_quality_pass']for r in out)
(P/'v59-quality-audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps([{k:v for k,v in r.items()if k!='runtime_checks'} for r in out],indent=2))
