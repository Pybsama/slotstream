from pathlib import Path
import sys, subprocess, json, os
P=Path(__file__).resolve().parent;R=P.parents[1]
label='v58b-calibration-q2-9-settled'
(P/'v58b-calibration-9-settled-pid.json').write_text(json.dumps(dict(pid=os.getpid()))+'\n')
cmd=[sys.executable,str(P/'calibration_ablation_settled.py'),'--label',label,'--native',str(P/'v58b/slotstream'),'--model','smart-q2','--budget','9','--cases',str(P/'short-warm-384-cases.json')]
print('START',label,flush=True)
with(P/(label+'-driver.log')).open('x')as f:r=subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT)
(P/'v58b-calibration-9-settled-controller.json').write_text(json.dumps(dict(command=cmd,exit_code=r.returncode),indent=2)+'\n')
print('END',label,r.returncode,flush=True)
raise SystemExit(r.returncode)
