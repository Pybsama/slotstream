from pathlib import Path
import json,hashlib,sys,subprocess,time
P=Path(__file__).resolve().parent;R=P.parents[1]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
preflight(12)
manifest=json.loads((P/'v57-manifest.json').read_text())
for row in manifest:
 assert hashlib.sha256((R/row['path']).read_bytes()).hexdigest()==row['before_sha256'],row['path']
for row in manifest:
 f=R/row['path'];(P/('v57-before-'+row['path'].replace('/','__'))).write_bytes(f.read_bytes());f.write_bytes((P/row['candidate']).read_bytes())
events=[]
steps=[('v57-build',['make','build','SLOTSTREAM_BUILD_JOBS=4']),('v57-freeze',[sys.executable,str(P/'freeze.py'),'v57']),('v57-pool',[sys.executable,str(P/'guarded_run.py'),'--label','v57-pool','--budget','3','--timeout','900','--',str(P/'v57/slotstream'),'q2-experts-check','--pool-model','smart-q2']),('v57-state',[sys.executable,str(P/'v57_gdn_state_probe.py')]),('v57-quality',[sys.executable,str(P/'v57_native_quality.py')])]
for label,cmd in steps:
 preflight(12)
 print('START',label,flush=True);started=time.monotonic()
 with(P/(label+'-driver.log')).open('x')as f:r=subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT)
 events.append(dict(label=label,command=cmd,exit_code=r.returncode,seconds=time.monotonic()-started));(P/'v57-core-ledger.json').write_text(json.dumps(events,indent=2)+'\n')
 print('END',label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
