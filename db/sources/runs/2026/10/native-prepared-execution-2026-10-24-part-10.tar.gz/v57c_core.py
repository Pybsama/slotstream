from pathlib import Path
import json,hashlib,sys,subprocess,time
P=Path(__file__).resolve().parent;R=P.parents[1]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
preflight(12)
events=[]
steps=[('v57c-build',['make','build','SLOTSTREAM_BUILD_JOBS=4']),('v57c-freeze',[sys.executable,str(P/'freeze.py'),'v57c']),('v57c-pool',[sys.executable,str(P/'guarded_run.py'),'--label','v57c-pool','--budget','3','--timeout','900','--',str(P/'v57c/slotstream'),'q2-experts-check','--pool-model','smart-q2']),('v57c-input-validated',[sys.executable,str(P/'guarded_run.py'),'--label','v57c-input-validated','--budget','3','--timeout','900','--env','MTL_DEBUG_LAYER=1','--env','MTL_SHADER_VALIDATION=1','--',str(P/'v57c/slotstream'),'q2-experts-check','--pool-model','smart-q2','--gdn-input-only']),('v57c-plain',[sys.executable,str(P/'v57c_plain.py')]),('v57c-state',[sys.executable,str(P/'v57c_gdn_state_probe.py')]),('v57c-quality',[sys.executable,str(P/'v57c_native_quality.py')])]
for label,cmd in steps:
 preflight(12)
 print('START',label,flush=True);started=time.monotonic()
 with(P/(label+'-driver.log')).open('x')as f:r=subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT)
 events.append(dict(label=label,command=cmd,exit_code=r.returncode,seconds=time.monotonic()-started));(P/'v57c-core-ledger.json').write_text(json.dumps(events,indent=2)+'\n')
 print('END',label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
