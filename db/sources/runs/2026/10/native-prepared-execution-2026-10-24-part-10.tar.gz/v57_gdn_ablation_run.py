from pathlib import Path
import sys,subprocess,json
P=Path(__file__).resolve().parent;R=P.parents[1]
label='v57-gdn-input-q2-15'
cmd=[sys.executable,str(P/'gdn_input_ablation.py'),'--label',label,'--native',str(P/'v57/slotstream'),'--model','smart-q2','--budget','15','--cases',str(P/'short-warm-384-cases.json')]
print('START',label,flush=True)
with(P/(label+'-driver.log')).open('x')as f:r=subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT)
(P/'v57-gdn-input-controller.json').write_text(json.dumps(dict(command=cmd,exit_code=r.returncode),indent=2)+'\n')
print('END',label,r.returncode,flush=True)
raise SystemExit(r.returncode)
