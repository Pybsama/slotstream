from pathlib import Path
import json,hashlib,sys,subprocess,time
P=Path(__file__).resolve().parent;R=P.parents[1]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
preflight(12)
manifest=json.loads((P/'v57b-manifest.json').read_text())
for row in manifest:
 assert hashlib.sha256((R/row['path']).read_bytes()).hexdigest()==row['before_sha256'],row['path']
for row in manifest:
 f=R/row['path'];(P/('v57b-before-'+row['path'].replace('/','__'))).write_bytes(f.read_bytes());f.write_bytes((P/row['candidate']).read_bytes())
events=[]
steps=[('v57b-build',['make','build','SLOTSTREAM_BUILD_JOBS=4']),('v57b-freeze',[sys.executable,str(P/'freeze.py'),'v57b']),('v57b-pool',[sys.executable,str(P/'guarded_run.py'),'--label','v57b-pool','--budget','3','--timeout','900','--',str(P/'v57b/slotstream'),'q2-experts-check','--pool-model','smart-q2']),('v57b-input-validated',[sys.executable,str(P/'guarded_run.py'),'--label','v57b-input-validated','--budget','3','--timeout','900','--env','MTL_DEBUG_LAYER=1','--env','MTL_SHADER_VALIDATION=1','--',str(P/'v57b/slotstream'),'q2-experts-check','--pool-model','smart-q2','--gdn-input-only']),('v57b-plain',[sys.executable,str(P/'v57b_plain.py')]),('v57b-state',[sys.executable,str(P/'v57b_gdn_state_probe.py')]),('v57b-quality',[sys.executable,str(P/'v57b_native_quality.py')])]
for label,cmd in steps:
 preflight(12)
 print('START',label,flush=True);started=time.monotonic()
 with(P/(label+'-driver.log')).open('x')as f:r=subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT)
 events.append(dict(label=label,command=cmd,exit_code=r.returncode,seconds=time.monotonic()-started));(P/'v57b-core-ledger.json').write_text(json.dumps(events,indent=2)+'\n')
 print('END',label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
