import json,os,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1]
(P/'v59-q2-confirm-pid.json').write_text(json.dumps(dict(pid=os.getpid()))+'\n')
label='v59-native-smart-q2-15-splash'
cmd=[sys.executable,str(P/'native_splash_compare_v59.py'),'--label',label,'--native',str(P/'v59/slotstream'),'--model','smart-q2','--budget','15','--cases',str(P/'short-warm-384-cases.json')]
print('START',label,flush=True)
with(P/(label+'-driver.log')).open('x')as f:r=subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT)
(P/'v59-q2-confirm-controller.json').write_text(json.dumps(dict(command=cmd,exit_code=r.returncode),indent=2)+'\n')
print('END',label,r.returncode,flush=True)
if r.returncode:raise SystemExit(r.returncode)
raise SystemExit(subprocess.run([sys.executable,str(P/'comparison_summary.py'),label],cwd=R).returncode)
