from pathlib import Path
import json,subprocess,sys,time
P=Path(__file__).resolve().parent;R=P.parents[1];events=[]
while True:
 s=subprocess.run(['ps','-p','25893','-o','command='],capture_output=True,text=True).stdout
 if 'after_v33_ordinary.py' not in s:break
 time.sleep(10)
ledger=json.loads((P/'v33-ordinary-qualification-ledger.json').read_text());assert len(ledger)==7 and all(x['exit_code']==0 for x in ledger)
def run(label,cmd,required=True):
 print('START',label,flush=True)
 with(P/(label+'-driver.log')).open('x')as out:r=subprocess.run(cmd,cwd=R,stdout=out,stderr=subprocess.STDOUT)
 events.append(dict(label=label,command=cmd,exit_code=r.returncode));(P/'depth32-then-kernels-ledger.json').write_text(json.dumps(events,indent=2)+'\n')
 print('END',label,r.returncode,flush=True)
 if required and r.returncode:raise SystemExit(r.returncode)
 return r.returncode
run('v33-depth32-profile',[sys.executable,str(P/'v33_target_profile_depth32.py')])
label='v33-depth32-smart-q215-splash'
run(label,[sys.executable,str(P/'native_splash_compare_v33_depth32.py'),'--cases',str(P/'short-warm-384-cases.json'),'--label',label,'--native',str(P/'v33/slotstream'),'--model','smart-q2','--budget','15'])
run(label+'-summary',[sys.executable,str(P/'comparison_summary.py'),label])
# Preserve strict v34 failures. v35 intentionally restores v33 arithmetic
# before its isolated repack experiment; it does not inherit a failed kernel.
run('v34-rescheduled',[sys.executable,str(P/'after_v33_ordinary_v34.py')],required=False)
run('v35-rescheduled',[sys.executable,str(P/'after_v34_v35.py')])
