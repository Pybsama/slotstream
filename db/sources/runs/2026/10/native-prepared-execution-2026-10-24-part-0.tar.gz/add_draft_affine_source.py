from pathlib import Path
r=Path.cwd()
p=r/'Sources/Slotstream/Q2ResidentKernelSources.swift';s=p.read_text();needle='// The GGUF format whose planes hold Bits-bit linear codes, which an MLX affine format keeps as it does\n// (metal/abi/QuantFormat.h).'
assert needle in s
code='''// The maintained draft uses only AF4G64. This is the corresponding
// FmtAffine<4, 2> definition from Splash quant_formats.h, without unrelated
// formats. Codes and BF16 scale/bias bytes are unchanged by preparation.
struct FmtAF4G64 {
  typedef FmtQ4K Planes;
  QUANT_FORMAT(GGUF_FMT_AF4G64, QuantLinear, 0, 32, false);
  typedef Planes::Payload Payload; typedef Planes::Chunk Chunk; typedef uint Meta;
  static Payload load(device uchar *p0, device uchar *p1) { return Planes::load(p0,p1); }
  static Meta loadMeta(device uchar *m) { return *((device uint *)m); }
  static Chunk chunk(Payload w, ushort c) { return Planes::chunk(w,c); }
  static Chunk loadChunk(device uchar *p0, device uchar *p1, ushort c) { return Planes::loadChunk(p0,p1,c); }
  static uint4 codes(Chunk q) { return Planes::codes(q); }
  static QuantCoef coef(Meta mt, ushort) {
    return {float2(float(as_type<bfloat>(ushort(mt & 0xFFFF)))), float2(float(as_type<bfloat>(ushort(mt >> 16))))};
  }
};
'''
s=s.replace(needle,code);p.write_text(s)
p=r/'Sources/Slotstream/NativeProjectionSchedule.swift';s=p.read_text();s=s.replace('register.\\(format.rawValue).\\(k).\\(n).\\(rows).\\(splits).\\(dtype)','register.\\(format.rawValue).\\(k).\\(n).\\(rows).\\(splits).\\(dtype).\\(p1).\\(meta)');s=s.replace('staged.\\(format.rawValue).\\(k).\\(n).\\(rows).\\(parts).\\(inputType).\\(dtype)','staged.\\(format.rawValue).\\(k).\\(n).\\(rows).\\(parts).\\(inputType).\\(dtype).\\(p1).\\(meta)');p.write_text(s)
