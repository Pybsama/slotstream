from pathlib import Path
P=Path(__file__).resolve().parent;D=P/'v26-candidate';p=D/'NativeSchedule.cpp';s=p.read_text()
s=s.replace('  void *context;\n  bool (*load)(void *, void *, const int32_t *, int, const int32_t *, const float *, int);\n  void (*release)(void *);','  void *context = nullptr;\n  bool (*load)(void *, void *, void *, const int32_t *, int, const int32_t *, const float *, int) = nullptr;\n  void (*release)(void *) = nullptr;')
s=s.replace('  ~DeferredRoute() { release(context); }','  ~DeferredRoute() { if (release) release(context); }')
s=s.replace('    encoder.commit();\n    { std::lock_guard lock(route->scope->mutex);','    encoder.get_command_buffer()->addCompletedHandler([lease = route->route_ready](MTL::CommandBuffer*) { (void)lease; });\n    encoder.commit();\n    { std::lock_guard lock(route->scope->mutex);')
s=s.replace('success = route->load(route->context, &job, route->routes.data<int32_t>()','auto borrowed = route;\n            success = route->load(route->context, &job, &borrowed, route->routes.data<int32_t>()')
pos=s.rfind('\n}');s=s[:pos]+'\n'+(P/'v26-deferred-api.inc').read_text()+s[pos:];p.write_text(s)
p=D/'NativeSchedule.h';s=p.read_text();pos=s.index('#ifdef __cplusplus\n}',s.index('const char *ss_schedule_error'))
s=s[:pos]+'''// Diagnostic deferred route schedule. Callback contexts transfer only on success.
void *ss_deferred_scope_new(void *plan);
int ss_deferred_scope_finish(void *scope, bool reset);
void ss_deferred_scope_free(void *scope);
int ss_deferred_prepare(void *plan, void *scope, void *input, void *routes, void *const *weights, int count,
    int top_k, void *forecast_ids, void *forecast_weights, void *const *forecast_arena,
    void *context, bool (*load)(void *, void *, void *, const int32_t *, int, const int32_t *, const float *, int),
    void (*release)(void *), void *stream_context, void **anchor, void **handle);
int ss_deferred_configure(void *route, const int32_t *slot_ids, int count, const int32_t *order, int rows,
    const int32_t *inverse, const int32_t *slots, const int32_t *live, const int32_t *staged, int staged_count);
int ss_deferred_compute(void *route, void *anchor, void *shared, void *stream_context, void **output);
void ss_deferred_free(void *route);
''' +s[pos:];p.write_text(s)
