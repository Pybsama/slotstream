from pathlib import Path
import json,subprocess,sys,time,statistics
P=Path(__file__).resolve().parent;R=P.parents[1]
while True:
 s=subprocess.run(['ps','-p','63849','-o','command='],capture_output=True,text=True).stdout
 if 'after_tile64_gdn.py' not in s:break
 time.sleep(10)
for v in ['v37','v38','v39','v40','v41']:
 f=P/(v+'-default-smart-q215-splash-summary.json')
 if f.exists() and json.loads(f.read_text())['parity_or_better']:
  print('Qualified candidate reached exploratory gate; skip speculative diagnostic',flush=True);raise SystemExit(0)
assert (P/'gdn-controller-result.json').exists(),'Prior controller incomplete'
# This deliberately changes only process-local MLX heuristics, for attribution.
# It is not a production default or a native/upstream speed comparison.
results=[]
for i,arm in enumerate('ABBA'):
 label='v36-submission-probe-'+str(i)+'-'+arm;out=P/(label+'.json')
 cmd=[sys.executable,str(P/'guarded_run.py'),'--label',label,'--budget','15','--timeout','420','--env','SLOTSTREAM_NATIVE_DEFERRED_ROUTES=0']
 if arm=='B':cmd+=['--env','MLX_MAX_MB_PER_BUFFER=4096','--env','MLX_MAX_OPS_PER_BUFFER=256']
 cmd+=['--',str(P/'v36/slotstream'),'q2-profile','--fixture',str(P/'v29-profile-smart-q2-fixture.json'),'--output',str(out),'--memory-gb','15','--rounds','3','--model','smart-q2']
 print('START',label,flush=True)
 with(P/(label+'-driver.log')).open('x')as log:r=subprocess.run(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT)
 row=dict(label=label,arm=arm,command=cmd,exit_code=r.returncode)
 if r.returncode==0:
  d=json.loads(out.read_text());runs=d['runs'];obs=json.loads((P/(label+'.observer.json')).read_text())
  row.update(exact=all(x['max_logit_difference']==0 and x['argmax_equal']for x in runs),paging=obs.get('paging'),medians_ms={str(w):statistics.median(x['seconds']*1000 for x in runs if x['width']==w and x['round']>0 and not x['traced'])for w in [1,2,4,8]})
 results.append(row);(P/'v36-submission-probe-ledger.json').write_text(json.dumps(results,indent=2)+'\n');print(row,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
(P/'v36-submission-probe-scope.json').write_text(json.dumps(dict(scope='Frozen v36 ordinary-routing cached fixed-input ABBA. A production MLX submission heuristics; B process-local maximum 4096 MB/256 ops. Traced arms force extra barriers and are excluded from performance summaries. This is not complete serving or Splash parity; source and product settings unchanged.',results=results),indent=2)+'\n')
