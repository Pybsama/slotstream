---
type: index
scope: type-folder
folder: records/state
updated: 2026-10-24T22:00:05.239480Z
---

# records/state

- [[records/state/home]] — Slotstream Home state and conversation history
