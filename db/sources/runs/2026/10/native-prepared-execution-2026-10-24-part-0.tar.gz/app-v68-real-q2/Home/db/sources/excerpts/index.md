---
type: index
scope: type-folder
folder: sources/excerpts
updated: 2026-10-24T21:58:52.002979Z
---

# sources/excerpts

- [[sources/excerpts/2026/10/565ae867-eaae-45c6-9d04-59f1a8188c9b-S1-99b3f474908f242ea05dae14]] — Immutable conversation event
- [[sources/excerpts/2026/10/21cfb127-e736-40d0-973d-4eb4f380837e-S2-e32c1d47ed0ae7647dffb8aa]] — Immutable conversation event
- [[sources/excerpts/2026/10/21cfb127-e736-40d0-973d-4eb4f380837e-S1-6580e39aed2d67a8ab4fb8e1]] — Immutable conversation event
- [[sources/excerpts/2026/10/2e04ea60-ee70-403b-8a19-bfd7f944aa55-S1-283f6b91d0c0d54720f92dcb]] — Immutable conversation event
- [[sources/excerpts/2026/10/ce3531c6-9305-47c6-9283-1451d37391fc-S1-8f367caa78d7ab4e03f5291e]] — Immutable conversation event
