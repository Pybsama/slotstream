from pathlib import Path
import hashlib,json,shutil,subprocess,sys,time
P=Path(__file__).resolve().parent;R=P.parents[1]
while True:
 s=subprocess.run(['ps','-p','28142','-o','command='],capture_output=True,text=True).stdout
 if 'after_v33_ordinary_v34.py' not in s:break
 time.sleep(10)
# v35 is intentionally an isolated experiment on v33, independent of v34's
# changed accumulation order. Preserve the entire v34 result before restoration.
if not (P/'v34-core-ledger.json').exists():
 raise SystemExit('v34 did not run; inspect predecessor before proceeding')
backup=P/'v34-before-v35';backup.mkdir(exist_ok=False)
for item in json.loads((P/'v34-candidate-manifest.json').read_text()):
 target=R/item['path'];assert hashlib.sha256(target.read_bytes()).hexdigest()==item['candidate_sha256']
 shutil.copy2(target,backup/item['file'])
 original=P/'v33-before-v34'/item['file'];assert hashlib.sha256(original.read_bytes()).hexdigest()==item['base_sha256']
 shutil.copy2(original,target)
manifest=json.loads((P/'v35-candidate-manifest.json').read_text())
for item in manifest:
 assert hashlib.sha256((R/item['path']).read_bytes()).hexdigest()==item['base_sha256']
 assert hashlib.sha256((P/'v35-candidate'/item['file']).read_bytes()).hexdigest()==item['candidate_sha256']
for item in manifest:
 shutil.copy2(R/item['path'],backup/('v33-'+item['file']))
 shutil.copy2(P/'v35-candidate'/item['file'],R/item['path'])
print('Restored v33 arithmetic; installed isolated combined-repack candidate',flush=True)
r=subprocess.run([sys.executable,str(P/'v35_qualification.py')],cwd=R)
raise SystemExit(r.returncode)
