"""Run only after all producers stop and final review is complete."""
import hashlib,io,json,re,shutil,tarfile
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1]
assert (P/'final-evidence-ready.json').exists(), 'Final selection and review are still pending'
ready=json.loads((P/'final-evidence-ready.json').read_text());assert ready['complete'] is True
support=P/'captured-support';support.mkdir(exist_ok=True)
for name,source in {
 'quality-and-functional-cases.json':R/'.build/fast-parity-20261022/quality-and-functional-cases.json',
 'grade_v2.py':R/'.build/native-q2-20261021/grade_v2.py',
 'quality-rubric.json':R/'.build/native-q2-20261021/quality-rubric.json',
 'thermal.py':R/'.build/native-q2-20261021/thermal.py',
 'prefill_bench.py':R/'Tools/prefill_bench.py',
 'quantization_tasks.py':R/'Tools/quantization_tasks.py',
 'fast_smart_acceptance.py':R/'Tools/fast_smart_acceptance.py',
 'splash-NOTICE.txt':R/'Licenses/splash-NOTICE.txt',
 'splash-Apache-2.0.txt':R/'Licenses/splash-Apache-2.0.txt',
}.items():shutil.copy2(source,support/name)
upstream=Path('/tmp/slotstream-splash-review.EJTswU/splash')
for relative in ['runtime/model/VerifyBudget.cpp','runtime/model/VerifyBudget.hpp',
 'runtime/metal/abi/ExecutionGeometry.h','runtime/model/ExpertStore.cpp',
 'runtime/ops/MoE.cpp','runtime/ops/LinearGguf.cpp',
 'runtime/metal/kernels/shared/moe_gguf.metal',
 'runtime/metal/kernels/common/gguf_column_tile.h',
 'runtime/metal/kernels/common/gguf_staged_tile.h',
 'runtime/model/SsdReaders.cpp','runtime/model/SsdReaders.hpp',
 'runtime/model/Runtime.cpp','runtime/metal/MetalBackend.mm',
 'runtime/model/DFlashDraft.cpp','runtime/model/DFlashDraft.hpp',
 'runtime/model/DraftCheckpoint.cpp','runtime/model/DraftCheckpoint.hpp',
 'runtime/ops/GDN.cpp','runtime/ops/GDN.hpp',
 'runtime/ops/HyperConnection.cpp','runtime/ops/HyperConnection.hpp',
 'runtime/ops/ExecutionPlans.cpp','runtime/ops/ExecutionPlans.hpp',
 'runtime/metal/abi/GDN.h','runtime/metal/abi/HyperConnection.h',
 'runtime/metal/kernels/common/gdn_primitives.h',
 'runtime/metal/kernels/decode/gdn.metal',
 'runtime/metal/kernels/shared/hyper_connection.metal',
 'runtime/metal/kernels/decode/draft.metal','runtime/metal/kernels/decode/sampling.metal',
 'dev/benchmarks/teacher_logits.mm',
 'dev/benchmarks/remaining-decode-optimizations.md']:
 shutil.copy2(upstream/relative,support/('splash-'+Path(relative).name))
mlx=R/'.build/checkouts/mlx-swift/Source/Cmlx/mlx/mlx'
for relative in ['backend/metal/device.cpp','backend/metal/eval.cpp','backend/metal/sort.cpp','scheduler.cpp','allocator.cpp']:
 source=mlx/relative
 if source.exists():shutil.copy2(source,support/('mlx-'+relative.replace('/','-')))
allowed={'.py','.json','.log','.swift','.md','.txt','.gz','.png','.pdf','.cpp','.h','.hpp','.metal','.mm','.m','.csv','.jsonl','.stderr','.u32','.f32','.kvst','.patch','.inc','.toml','.before'}
files=sorted(f for f in P.rglob('*') if f.is_file() and f.suffix in allowed
 and 'prefix-cache' not in f.parts and '__pycache__' not in f.parts
 and f.name not in {'archive-receipt.json','archive-plan.json','archive-split-receipt.json','privacy-review.json'})
assert all(f.stat().st_size<20_000_000 for f in files), 'Unexpected large evidence file'
# Report only coordinates, never a suspected value. Inspect nested source
# archives too: a clean outer filename does not prove its contents are public.
patterns={
 'provider-key':rb'\b(?:sk-(?:proj-|ant-)?[A-Za-z0-9_-]{24,}|gh[pousr]_[A-Za-z0-9]{24,}|github_pat_[A-Za-z0-9_]{24,}|hf_[A-Za-z0-9]{24,}|xox[baprs]-[A-Za-z0-9-]{20,})\b',
 'private-key':rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----',
 'credential-url':rb'https?://[^\s/:@]{2,}:[^\s/@]{3,}@',
}
findings=[];scanned=0
def scan(name,raw):
 global scanned
 scanned+=1
 for kind,pattern in patterns.items():
  if re.search(pattern,raw):findings.append(dict(path=name,kind=kind))
for f in files:
 name=str(f.relative_to(P))
 if f.suffix=='.gz':
  with tarfile.open(f)as nested:
   for member in nested.getmembers():
    if member.isfile():scan(name+'!'+member.name,nested.extractfile(member).read())
 elif f.suffix not in {'.png','.pdf','.kvst'}:scan(name,f.read_bytes())
review=dict(scanned=scanned,findings=findings,scope='Credential pattern scan plus final manual inventory review; not a proof that arbitrary text contains no private data')
(P/'privacy-review.json').write_text(json.dumps(review,indent=2)+'\n')
assert not findings, 'Inspect privacy-review coordinates before publication'
files.append(P/'privacy-review.json')
plain=[f for f in files if f.suffix!='.gz'];bundles=[f for f in files if f.suffix=='.gz'];groups=[];group=[];size=0
for f in plain+bundles:
 if size+f.stat().st_size>40_000_000 and group:groups.append(group);group=[];size=0
 group.append(f);size+=f.stat().st_size
after=groups+[group] if group else groups
receipts=[]
for index,items in enumerate(after):
 manifest=dict(scope='Native prepared-execution study, part of a complete set. All candidate verdicts and exact nested build-source archives are preserved. Executables, metallibs, model weights and disposable prefix caches are excluded.',part=index,parts=len(after),files={str(f.relative_to(P)):dict(bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest())for f in items})
 destination=R/('db/sources/runs/2026/10/native-prepared-execution-2026-10-24-part-'+str(index)+'.tar.gz')
 assert not destination.exists()
 with tarfile.open(destination,'w:gz')as tar:
  for f in items:tar.add(f,arcname=str(f.relative_to(P)),recursive=False)
  raw=(json.dumps(manifest,indent=2)+'\n').encode();info=tarfile.TarInfo('archive-manifest.json');info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
 assert destination.stat().st_size<90_000_000
 with tarfile.open(destination)as tar:
  for name,entry in manifest['files'].items():
   raw=tar.extractfile(name).read();assert len(raw)==entry['bytes'] and hashlib.sha256(raw).hexdigest()==entry['sha256']
 receipts.append(dict(path=str(destination.relative_to(R)),bytes=destination.stat().st_size,sha256=hashlib.sha256(destination.read_bytes()).hexdigest(),files=len(items)))
(P/'archive-split-receipt.json').write_text(json.dumps(receipts,indent=2)+'\n');print(json.dumps(receipts,indent=2))
