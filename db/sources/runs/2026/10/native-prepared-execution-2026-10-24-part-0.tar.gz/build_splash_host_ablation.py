import hashlib,json,shutil,subprocess,sys,tempfile
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1]
sys.path.insert(0,str(R/'Tools'));from prefill_bench import preflight
preflight(12)
upstream=Path('/tmp/slotstream-splash-review.EJTswU/splash')
assert subprocess.check_output(['git','-C',str(upstream),'rev-parse','HEAD'],text=True).strip()=='1482f6bbc2abf12375332725302019594150b6cb'
workspace=Path(tempfile.mkdtemp(prefix='slotstream-splash-host-'))/'source'
subprocess.run(['git','-C',str(upstream),'worktree','add','--detach',str(workspace),'HEAD'],check=True)
events=[]
def run(label,command):
 preflight(12)
 with(P/(label+'-build.log')).open('x')as log: result=subprocess.run(command,cwd=workspace,stdout=log,stderr=subprocess.STDOUT)
 events.append(dict(label=label,command=command,exit_code=result.returncode,worktree=str(workspace)))
 (P/'splash-host-ablation-build-ledger.json').write_text(json.dumps(events,indent=2)+'\n')
 if result.returncode:raise SystemExit(result.returncode)
for label,spin in [('splash-host-base',5),('splash-host-wait',0)]:
 source=workspace/'runtime/metal/MetalBackend.mm'
 if spin==0:
  s=source.read_text();old='kHostStepSpin = std::chrono::milliseconds(5)';assert s.count(old)==1
  source.write_text(s.replace(old,'kHostStepSpin = std::chrono::milliseconds(0)'))
  (P/'splash-host-wait.patch').write_text(subprocess.check_output(['git','diff'],cwd=workspace,text=True))
 run(label,['make','-j4','build/engine/main.o','build/engine/libsplash.a'])
 out=P/label;out.mkdir()
 run(label+'-link',['xcrun','-sdk','macosx','clang++','-std=c++20','-O3','-fobjc-arc','-mmacosx-version-min=26.4',
     'build/engine/main.o','build/engine/libsplash.a','-framework','Foundation','-framework','Metal','-framework','IOKit','-framework','IOSurface','-o',str(out/'splash')])
 # Only the CPU host waiting changes. Use byte-identical published shaders
 # for both controls, since this machine has no offline Metal compiler.
 library=R/'.build/smart-dflash-eval/upstream/splash-1.4.0-arm64-macos26/engine/splash.metallib'
 shutil.copyfile(library,out/'splash.metallib')
 shutil.copyfile(workspace/'build/engine/build-identity.json',out/'build-identity.json')
 shutil.copyfile(source,out/'MetalBackend.mm')
 receipt=dict(source_commit='1482f6bbc2abf12375332725302019594150b6cb',host_spin_ms=spin,
     binary_sha256=hashlib.sha256((out/'splash').read_bytes()).hexdigest(),shader_sha256=hashlib.sha256(library.read_bytes()).hexdigest(),
     scope='Diagnostic CPU-host ablation; rebuilt host with unchanged published shaders, not a new upstream release or an interchangeable production benchmark baseline.')
 (out/'identity.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('Both diagnostic hosts built; no model launched')
