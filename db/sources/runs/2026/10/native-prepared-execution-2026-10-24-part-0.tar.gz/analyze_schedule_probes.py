from pathlib import Path
import csv,json,statistics,sys
P=Path(__file__).resolve().parent
out=[]
for prefix in sys.argv[1:]:
 p=P/(prefix+'.json')
 d=json.loads(p.read_text());o=json.loads((P/(prefix+'.observer.json')).read_text())
 files=list(P.glob(prefix+'-timestamps.*.csv'));assert len(files)==1
 with files[0].open()as f:cmds=[{k:float(v)for k,v in r.items()}for r in csv.DictReader(x for x in f if not x.startswith('#'))]
 assert o['complete'] and all(c['status']==4 for c in cmds)
 for row in d['runs']:
  if row['traced']or row['round']==0:continue
  lo=row['started_uptime_ns']/1e9;hi=row['ended_uptime_ns']/1e9
  seq=sorted((c for c in cmds if c['start']<hi and c['end']>lo),key=lambda c:c['start'])
  previous=lo;union=host=post=0
  for c in seq:
   a=max(lo,c['start']);b=min(hi,c['end']);union+=max(0,b-max(previous,a))
   gap=max(0,a-previous);before=max(0,min(a,c['submitted'])-previous)
   host+=before;post+=gap-before;previous=max(previous,b)
  out.append(dict(label=prefix,width=row['width'],round=row['round'],seconds=row['seconds'],gpu_union_seconds=union,host_before_submission_seconds=host,after_submission_gap_seconds=post,commands=len(seq),io=row['io_seconds'],clean=not o['paging']and o['thermal_before']==o['thermal_after']==0,peak_gb=o['peak_combined_bytes']/1e9))
name='schedule-probes-'+str(len(sys.argv)-1)+'-'+sys.argv[-1]+'.json'
(P/name).write_text(json.dumps(dict(scope='Public command timestamp decomposition of fixed target-only replay. GPU intervals include waits, not ALU utilization. Instrumented, not serving speed.',rows=out),indent=2)+'\n')
for prefix in sys.argv[1:]:
 r=[x for x in out if x['label']==prefix and x['width']==8]
 print(prefix,{k:statistics.median(x[k]for x in r)for k in ['seconds','gpu_union_seconds','host_before_submission_seconds','after_submission_gap_seconds','commands','peak_gb']})
