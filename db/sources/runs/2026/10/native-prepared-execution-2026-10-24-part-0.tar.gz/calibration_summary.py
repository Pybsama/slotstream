import json,math,statistics,sys
from pathlib import Path
P=Path(__file__).resolve().parent
label=sys.argv[1]
rows=json.loads((P/(label+'-ledger.json')).read_text())
complete=len(rows)==4 and [r['arm'] for r in rows] in [list('ABBA'),list('BAAB')]
eligible=complete and all(r.get('eligible') for r in rows)
tasks={}
for key in ['timed-2','timed-3']:
 task={}
 for arm in 'AB':
  samples=[x for r in rows if r['arm']==arm for x in r['runs'] if x['id']==key]
  task[arm]={k:statistics.median(x[k] for x in samples) for k in ['tps','request_seconds']}
 task['tps_ratio']=task['B']['tps']/task['A']['tps']
 task['request_ratio']=task['B']['request_seconds']/task['A']['request_seconds']
 tasks[key]=task
geo=math.prod(x['request_ratio'] for x in tasks.values())**.5
summary=dict(complete_protocol=complete,eligible=eligible,tasks=tasks,geometric_request_ratio=geo,
 within_scope_gain_gate=eligible and all(x['request_ratio']<=1 for x in tasks.values()) and geo<=.98,
 no_regression_gate=eligible and all(x['request_ratio']<=1.05 and x['tps_ratio']>=.95 for x in tasks.values()),
 scope='Native/native ablation only. Excluded aggregates establish no speed claim.')
(P/(label+'-summary.json')).write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
