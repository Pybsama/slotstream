import json,subprocess,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];deadline=time.monotonic()+3600
while True:
 f=P/'v23-qualification-ledger.json'
 if f.exists():
  rows=json.loads(f.read_text())
  if any(r['exit_code'] for r in rows):raise SystemExit('v23 failed; inspect before proceeding')
  if rows and rows[-1]['label']=='v23-default-fast15-splash-summary':break
 if time.monotonic()>deadline:raise SystemExit('Bounded wait for v23 qualification expired')
 time.sleep(5)
print('v23 comparisons complete. Starting isolated v24 candidate.',flush=True)
result=subprocess.run([sys.executable,str(P/'v24_qualification.py')],cwd=R)
raise SystemExit(result.returncode)
