---
type: index
scope: root
updated: 2026-10-24T21:56:21.993449Z
---

# Knowledge base index

## Sources (82)
- [[sources/conversations/index|Conversations]] (78)
- [[sources/excerpts/index|Excerpts]] (4)

## Records (13)
- [[records/drafts/index|Drafts]] (6)
- [[records/state/index|State]] (1)
- [[records/threads/index|Threads]] (6)
