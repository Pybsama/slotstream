---
type: index
scope: type-folder
folder: sources/excerpts
updated: 2026-10-24T21:52:49.394050Z
---

# sources/excerpts

- [[sources/excerpts/2026/10/c2812028-fd3f-412a-ab2b-c101e6f3c534-S1-99b3f474908f242ea05dae14]] — Immutable conversation event
- [[sources/excerpts/2026/10/ef669f08-28f5-44b8-9f62-95dc07beacf9-S1-bbc1014b0c8c88d5a662503e]] — Immutable conversation event
- [[sources/excerpts/2026/10/4178eef4-a752-4eeb-9a79-3e76cb03783f-S1-283f6b91d0c0d54720f92dcb]] — Immutable conversation event
- [[sources/excerpts/2026/10/5d5752fe-77e8-415b-8a51-ab2abf9ef9c9-S1-8f367caa78d7ab4e03f5291e]] — Immutable conversation event
