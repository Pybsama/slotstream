---
type: index
scope: type-folder
folder: records/state
updated: 2026-10-24T21:56:21.993449Z
---

# records/state

- [[records/state/home]] — Slotstream Home state and conversation history
