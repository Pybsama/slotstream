from pathlib import Path
import hashlib,json,subprocess,sys,time
P=Path(__file__).resolve().parent;R=P.parents[1];events=[];B=P/'v34/slotstream'
while True:
 s=subprocess.run(['ps','-p','36161','-o','command='],capture_output=True,text=True).stdout
 if 'after_ordinary_depth32.py'not in s:break
 time.sleep(10)
ledger=json.loads((P/'v35-qualification-ledger.json').read_text());assert len(ledger)==3 and all(x['exit_code']==0 for x in ledger)
assert hashlib.sha256(B.read_bytes()).hexdigest()=='b9106fe1b4cab6eb2d25097d612e1ff74154b03d224fa68eff15110a050367e6'
def run(label,cmd):
 print('START',label,flush=True)
 with(P/(label+'-driver.log')).open('x')as out:r=subprocess.run(cmd,cwd=R,stdout=out,stderr=subprocess.STDOUT)
 events.append(dict(label=label,command=cmd,exit_code=r.returncode));(P/'v34-rounding-diagnostic-ledger.json').write_text(json.dumps(events,indent=2)+'\n')
 print('END',label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
run('v34-rounding-formats',[sys.executable,str(P/'guarded_run.py'),'--label','v34-rounding-formats','--budget','3','--timeout','300','--',str(B),'q2-format-check','--fixtures','bench/q2/formats.json','--policy-fixtures','bench/q2/verify-budget.json','--policy-fixtures','bench/q2/verify-budget-complete.json','--mix-fixtures','bench/q2/mix-quantization.json'])
run('v34-rounding-quality',[sys.executable,str(P/'v34_rounding_quality.py')])
grade=json.loads((P/'v34-rounding-quality-smart-q2-grades.json').read_text())
assert grade['total']==24 and grade['semantic']>=19 and grade['strict']>=12,'Quality dropped; inspect before speed testing'
label='v34-rounding-smart-q215-splash'
run(label,[sys.executable,str(P/'native_splash_compare_v34.py'),'--cases',str(P/'short-warm-384-cases.json'),'--label',label,'--native',str(B),'--model','smart-q2','--budget','15'])
run(label+'-summary',[sys.executable,str(P/'comparison_summary.py'),label])
(P/'v34-rounding-diagnostic-scope.json').write_text(json.dumps(dict(summary=label+'-summary.json',production_qualified=False,reason='Original strict row-permutation qualification failed on two BF16 rounding differences. Format arithmetic and complete quality passed before collecting diagnostic speed. No production source changed and no test expectation was weakened.',quality=grade['semantic'],strict=grade['strict']),indent=2)+'\n')
