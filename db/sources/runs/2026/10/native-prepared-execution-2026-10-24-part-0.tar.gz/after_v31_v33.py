import hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1]
# Wait only for this task's existing controller; no unrelated process is touched.
while True:
 command=subprocess.run(['ps','-p','2575','-o','command='],capture_output=True,text=True).stdout
 if 'after_v29b_v31.py' not in command:break
 time.sleep(10)
rows=json.loads((P/'v31-qualification-ledger.json').read_text())
assert len(rows)==8 and all(x['exit_code']==0 for x in rows), 'Prior sequence did not complete; inspect before installing another candidate'
if all(json.loads((P/('v31-default-'+model+str(budget)+'-splash-summary.json')).read_text())['parity_or_better'] for model,budget in [('smart-q2',15),('fast',15),('smart-q2',9)]):
 print('v31 already meets all tested parity gates; leave v33 unbuilt',flush=True);raise SystemExit(0)
print('Running preceding native binary on the same fixed target replay',flush=True)
with(P/'v29b-target-profile-controller.log').open('x')as log:
 previous=subprocess.run([sys.executable,str(P/'v29b_target_profile.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
if previous.returncode:raise SystemExit(previous.returncode)
print('Running bounded upstream target attribution before the next candidate',flush=True)
with(P/'splash-target-profile-controller.log').open('x')as log:
 profile=subprocess.run([sys.executable,str(P/'splash_target_profile.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
if profile.returncode:raise SystemExit(profile.returncode)
manifest=json.loads((P/'v33-candidate-manifest.json').read_text());backup=P/'v31-before-v33';assert not backup.exists()
for item in manifest:
 assert hashlib.sha256((R/item['path']).read_bytes()).hexdigest()==item['base_sha256'],item['path']+' changed'
 assert hashlib.sha256((P/'v33-candidate'/item['file']).read_bytes()).hexdigest()==item['candidate_sha256']
backup.mkdir()
for item in manifest:
 shutil.copy2(R/item['path'],backup/item['file']);shutil.copy2(P/'v33-candidate'/item['file'],R/item['path'])
print('Installed v33 candidate with default still off',flush=True)
r=subprocess.run([sys.executable,str(P/'v33_qualification.py')],cwd=R)
raise SystemExit(r.returncode)
