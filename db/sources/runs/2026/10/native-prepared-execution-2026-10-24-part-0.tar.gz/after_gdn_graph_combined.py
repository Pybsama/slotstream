from pathlib import Path
import hashlib,json,subprocess,sys,tarfile,time
P=Path(__file__).resolve().parent;R=P.parents[1]
while True:
    s=subprocess.run(['ps','-p','76507','-o','command='],capture_output=True,text=True).stdout
    if 'after_isolated_gdn_graph.py' not in s:break
    time.sleep(10)
for v in ['v41','v43']:
    f=P/(v+'-default-smart-q215-splash-summary.json')
    if f.exists() and json.loads(f.read_text())['parity_or_better']:
        print('Prior candidate passed; retain it for final qualification',flush=True)
        raise SystemExit(0)
assert (P/'v43-controller-result.json').exists(),'Graph controller did not finish'
for v in ['v39','v40','v41','v42']:
    rows=json.loads((P/(v+'-core-ledger.json')).read_text())
    assert len(rows)==8 and all(x['exit_code']==0 for x in rows),(v,'incomplete component gates')
    for model in (['smart-q2'] if v=='v40' else ['fast','smart-q2']):
        assert json.loads((P/(v+'-native-quality-'+model+'-functional.json')).read_text())['passed']
# Restore only the installed graph experiment and files in the combination.
# Read originals from the frozen v36 build, verifying every hash first.
graph=json.loads((P/'v43-candidate-manifest.json').read_text())
combined=json.loads((P/'v44-candidate-manifest.json').read_text())
rows={x['path']:x for x in graph+combined}
with tarfile.open(P/'v36/build-source.tar.gz','r:gz')as archive:
    members=archive.getnames()
    restored={}
    for path,row in rows.items():
        matches=[m for m in members if m==path or m.endswith('/'+path)]
        assert len(matches)==1,(path,matches)
        data=archive.extractfile(matches[0]).read()
        assert hashlib.sha256(data).hexdigest()==row['base_sha256'],path
        restored[path]=data
    # Check installed source before touching any file.
    for row in graph:
        assert hashlib.sha256((R/row['path']).read_bytes()).hexdigest()==row['candidate_sha256'],row['path']
    for path,row in rows.items():
        if path not in {x['path']for x in graph}:
            assert hashlib.sha256((R/path).read_bytes()).hexdigest()==row['base_sha256'],path
    backup=P/'v44-before-combination';backup.mkdir()
    for path,data in restored.items():
        f=R/path;(backup/f.name).write_bytes(f.read_bytes());f.write_bytes(data)
for row in combined:
    data=(P/'v44-candidate'/row['file']).read_bytes()
    assert hashlib.sha256(data).hexdigest()==row['candidate_sha256']
    (R/row['path']).write_bytes(data)
with(P/'v44-serial-qualification-driver.log').open('x')as log:
    result=subprocess.run([sys.executable,str(P/'v44_qualification.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
(P/'v44-controller-result.json').write_text(json.dumps(dict(exit_code=result.returncode),indent=2)+'\n')
print('v44 complete',result.returncode,flush=True)
raise SystemExit(result.returncode)
