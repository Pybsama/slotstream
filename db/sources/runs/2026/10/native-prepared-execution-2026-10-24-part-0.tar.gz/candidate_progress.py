import json
from pathlib import Path
P=Path(__file__).resolve().parent
out={}
for v in ['v33','v34-rounding','v35','v36','v37','v38','v39','v40','v41','v42']:
 item={}
 core=P/(v+'-core-ledger.json')
 if core.exists():
  rows=json.loads(core.read_text());item['core']=[(x['label'],x['exit_code'])for x in rows]
 comparisons=[]
 for f in sorted(P.glob(v+'-*-splash-summary.json')):
  d=json.loads(f.read_text());comparisons.append(dict(file=f.name,eligible=d['all_arms_eligible'],parity=d['parity_or_better'],tasks={k:dict(native=round(t['A']['tps'],3),splash=round(t['B']['tps'],3),request_ratio=round(t['native_request_ratio'],4))for k,t in d['tasks'].items()}))
 item['comparisons']=comparisons
 for model in ['fast','smart-q2']:
  f=P/(v+'-native-quality-'+model+'-grades.json')
  if f.exists():
   d=json.loads(f.read_text());item[model+'_quality']={k:d[k]for k in ['semantic','strict','total']}
 out[v]=item
(P/'comparison-progress.json').write_text(json.dumps(out,indent=2)+'\n')
for v,item in out.items():
 if item.get('core'):print(v,'core',item['core'][-1],len(item['core']))
 for c in item['comparisons']:
  print(c['file'],'eligible',c['eligible'],'parity',c['parity'],c['tasks'])
 for model in ['fast','smart-q2']:
  if model+'_quality' in item:print(v,model,item[model+'_quality'])
