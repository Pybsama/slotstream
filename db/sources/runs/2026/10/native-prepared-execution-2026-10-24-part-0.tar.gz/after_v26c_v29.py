import hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1]
# Wait only for this task's existing controller; no unrelated process is touched.
while True:
 command=subprocess.run(['ps','-p','86728','-o','command='],capture_output=True,text=True).stdout
 if 'v26c_qualification.py' not in command:break
 time.sleep(10)
rows=json.loads((P/'v26c-qualification-ledger.json').read_text())
assert len(rows)==7 and all(x['exit_code']==0 for x in rows), 'Prior sequence did not complete; inspect before installing another candidate'
manifest=json.loads((P/'v29-candidate-manifest.json').read_text());backup=P/'v26c-before-v29';assert not backup.exists()
for item in manifest:
 assert hashlib.sha256((R/item['path']).read_bytes()).hexdigest()==item['base_sha256'],item['path']+' changed'
 assert hashlib.sha256((P/'v29-candidate'/item['file']).read_bytes()).hexdigest()==item['candidate_sha256']
backup.mkdir()
for item in manifest:
 shutil.copy2(R/item['path'],backup/item['file']);shutil.copy2(P/'v29-candidate'/item['file'],R/item['path'])
print('Installed v29 candidate with default still off',flush=True)
r=subprocess.run([sys.executable,str(P/'v29_qualification.py')],cwd=R)
raise SystemExit(r.returncode)
