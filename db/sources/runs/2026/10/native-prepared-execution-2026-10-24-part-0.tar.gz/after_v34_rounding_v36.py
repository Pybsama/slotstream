from pathlib import Path
import hashlib,json,subprocess,sys,time
P=Path(__file__).resolve().parent;R=P.parents[1]
while True:
 s=subprocess.run(['ps','-p','43696','-o','command='],capture_output=True,text=True).stdout
 if 'after_v35_rounding_diagnostic.py' not in s:break
 time.sleep(10)
assert all(x['exit_code']==0 for x in json.loads((P/'v35-core-ledger.json').read_text()))
manifest=json.loads((P/'v36-candidate-manifest.json').read_text())
for row in manifest:
 assert hashlib.sha256((R/row['path']).read_bytes()).hexdigest()==row['base_sha256'],row['path']
 assert hashlib.sha256((P/'v36-candidate'/row['file']).read_bytes()).hexdigest()==row['candidate_sha256']
for row in manifest:(R/row['path']).write_bytes((P/'v36-candidate'/row['file']).read_bytes())
print('Installed isolated M16 candidate on qualified v35 repack base; ordinary routing',flush=True)
raise SystemExit(subprocess.run([sys.executable,str(P/'v36_qualification.py')],cwd=R).returncode)
