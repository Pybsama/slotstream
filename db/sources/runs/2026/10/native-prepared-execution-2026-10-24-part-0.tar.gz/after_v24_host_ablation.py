import json,subprocess,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];deadline=time.monotonic()+7200
while True:
 f=P/'v24-qualification-ledger.json'
 if f.exists():
  rows=json.loads(f.read_text())
  if any(r['exit_code'] for r in rows):raise SystemExit('v24 failed; inspect before proceeding')
  if rows and rows[-1]['label']=='v24-default-fast15-splash-summary':break
 if time.monotonic()>deadline:raise SystemExit('Bounded wait for v24 expired')
 time.sleep(5)
for label,script in [('host-build','build_splash_host_ablation.py'),('host-ablation','splash_host_ablation.py')]:
 print('START',label,flush=True)
 r=subprocess.run([sys.executable,str(P/script)],cwd=R)
 print('END',label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
