import json,subprocess,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];deadline=time.monotonic()+3600
while True:
 f=P/'splash-host-wait-q215-ledger.json'
 if f.exists():
  rows=json.loads(f.read_text())
  if any(x['exit_code']!=0 for x in rows):raise SystemExit('Host ablation failed; inspect first')
  if len(rows)==4 and all(x['complete']for x in rows):break
 if time.monotonic()>deadline:raise SystemExit('Bounded wait for host ablation expired')
 time.sleep(5)
print('Host ablation complete. Beginning isolated deferred-route candidate.',flush=True)
raise SystemExit(subprocess.run([sys.executable,str(P/'v26_qualification.py')],cwd=R).returncode)
