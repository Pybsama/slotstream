import hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1]
print('Resuming upstream attribution after fixing the harness lock order',flush=True)
with(P/'splash-target-profile-resume-controller.log').open('x')as log:
 profile=subprocess.run([sys.executable,str(P/'splash_target_profile_resume.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
if profile.returncode:raise SystemExit(profile.returncode)
manifest=json.loads((P/'v33-candidate-manifest.json').read_text());backup=P/'v31-before-v33';assert not backup.exists()
for item in manifest:
 assert hashlib.sha256((R/item['path']).read_bytes()).hexdigest()==item['base_sha256'],item['path']+' changed'
 assert hashlib.sha256((P/'v33-candidate'/item['file']).read_bytes()).hexdigest()==item['candidate_sha256']
backup.mkdir()
for item in manifest:
 shutil.copy2(R/item['path'],backup/item['file']);shutil.copy2(P/'v33-candidate'/item['file'],R/item['path'])
print('Installed v33 candidate with default still off',flush=True)
r=subprocess.run([sys.executable,str(P/'v33_qualification.py')],cwd=R)
raise SystemExit(r.returncode)
