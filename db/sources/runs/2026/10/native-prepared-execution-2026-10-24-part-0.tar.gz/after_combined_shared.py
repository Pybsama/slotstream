from pathlib import Path
import hashlib,json,subprocess,sys,time
P=Path(__file__).resolve().parent;R=P.parents[1]
while True:
    s=subprocess.run(['ps','-p','93118','-o','command='],capture_output=True,text=True).stdout
    if 'after_gdn_graph_combined.py' not in s:break
    time.sleep(10)
for v in ['v41','v43','v44']:
    f=P/(v+'-default-smart-q215-splash-summary.json')
    if f.exists() and json.loads(f.read_text())['parity_or_better']:
        print('Prior candidate passed; retain for final qualification',flush=True)
        raise SystemExit(0)
assert json.loads((P/'v44-controller-result.json').read_text())['exit_code']==0,'Combined candidate incomplete'
core=json.loads((P/'v44-core-ledger.json').read_text())
assert len(core)==8 and all(x['exit_code']==0 for x in core)
rows=json.loads((P/'v45-candidate-manifest.json').read_text())
for row in rows:
    f=R/row['path']
    if row['base_sha256'] is None:assert not f.exists(),row['path']
    else:assert hashlib.sha256(f.read_bytes()).hexdigest()==row['base_sha256'],row['path']
backup=P/'v45-before-shared';backup.mkdir()
for row in rows:
    f=R/row['path'];data=(P/'v45-candidate'/row['file']).read_bytes()
    assert hashlib.sha256(data).hexdigest()==row['candidate_sha256']
    if f.exists():(backup/f.name).write_bytes(f.read_bytes())
    f.write_bytes(data)
with(P/'v45-serial-qualification-driver.log').open('x')as log:
    result=subprocess.run([sys.executable,str(P/'v45_qualification.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
(P/'v45-controller-result.json').write_text(json.dumps(dict(exit_code=result.returncode),indent=2)+'\n')
print('v45 complete',result.returncode,flush=True)
raise SystemExit(result.returncode)
