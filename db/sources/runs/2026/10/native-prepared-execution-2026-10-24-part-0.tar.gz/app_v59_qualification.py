import hashlib, io, json, subprocess, sys, tarfile
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1]
sys.path.insert(0,str(R/'Tools'))
from prefill_bench import preflight
rows=[]
def run(label,command):
 preflight(13)
 print('START',label,flush=True)
 with (P/(label+'-driver.log')).open('x')as log:
  result=subprocess.run(command,cwd=R,stdout=log,stderr=subprocess.STDOUT)
 rows.append(dict(label=label,command=command,exit_code=result.returncode))
 (P/'app-v59-qualification-ledger.json').write_text(json.dumps(rows,indent=2)+'\n')
 print('END',label,result.returncode,flush=True)
 return result.returncode
if run('app-v59-scripted',['bash','Tools/check_slotstream_mac.sh']):raise SystemExit(1)
if run('app-v59-bundle',['bash','Tools/build_slotstream_mac.sh']):raise SystemExit(1)
bundle=R/'.build/Slotstream.app'
identity=json.loads((bundle/'Contents/Resources/build-inputs.json').read_text())
for path,digest in identity['files'].items():
 assert hashlib.sha256((R/path).read_bytes()).hexdigest()==digest,path
identity['check_sources']={str(path.relative_to(R)):hashlib.sha256(path.read_bytes()).hexdigest()for path in sorted((R/'apps/macos/Checks').rglob('*.swift'))}
identity['built_files']={str(path.relative_to(R)):hashlib.sha256(path.read_bytes()).hexdigest()for path in [bundle/'Contents/MacOS/Slotstream',bundle/'Contents/Helpers/slotstream-home',bundle/'Contents/Helpers/slotstream-extract',R/'apps/macos/.build/release/slotstream-mac-checks']}
identity['codesign_exit']=subprocess.run(['codesign','--verify','--deep','--strict',str(bundle)]).returncode
assert identity['codesign_exit']==0
(P/'app-v59-final-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
with tarfile.open(P/'app-v59-final-source.tar.gz','w:gz')as tar:
 for name in list(identity['files'])+list(identity['check_sources']):
  if not name.endswith('.metallib'):tar.add(R/name,arcname=name)
for model in ['fast','q2']:run('app-v59-real-'+model,[sys.executable,str(P/('app-v59-bench-'+model+'.py'))])
raise SystemExit(int(any(row['exit_code']for row in rows)))
