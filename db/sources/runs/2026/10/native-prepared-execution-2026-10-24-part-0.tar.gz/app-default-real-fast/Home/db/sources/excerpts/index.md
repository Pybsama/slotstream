---
type: index
scope: type-folder
folder: sources/excerpts
updated: 2026-10-24T03:22:30.091657Z
---

# sources/excerpts

- [[sources/excerpts/2026/10/190a0324-b409-495a-8e7e-453c381274bd-S1-99b3f474908f242ea05dae14]] — Immutable conversation event
- [[sources/excerpts/2026/10/839563ea-23ae-488a-a8eb-18da311c6ffb-S1-bbc1014b0c8c88d5a662503e]] — Immutable conversation event
- [[sources/excerpts/2026/10/e8fbf601-85dd-4067-ad1e-821b7b70f480-S1-283f6b91d0c0d54720f92dcb]] — Immutable conversation event
- [[sources/excerpts/2026/10/49f87475-669b-4630-8a03-4cfc5f7e259b-S1-8f367caa78d7ab4e03f5291e]] — Immutable conversation event
