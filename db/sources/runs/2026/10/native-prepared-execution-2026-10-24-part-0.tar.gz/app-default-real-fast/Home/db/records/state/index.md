---
type: index
scope: type-folder
folder: records/state
updated: 2026-10-24T03:24:53.303672Z
---

# records/state

- [[records/state/home]] — Slotstream Home state and conversation history
