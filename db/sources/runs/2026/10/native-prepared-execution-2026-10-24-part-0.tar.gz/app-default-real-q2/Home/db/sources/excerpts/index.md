---
type: index
scope: type-folder
folder: sources/excerpts
updated: 2026-10-24T03:27:22.107512Z
---

# sources/excerpts

- [[sources/excerpts/2026/10/6095cc6f-d5b0-4bf8-b742-22aa322be685-S1-99b3f474908f242ea05dae14]] — Immutable conversation event
- [[sources/excerpts/2026/10/3df0129a-4ac7-4a43-b1e8-6ba524ad7929-S2-e32c1d47ed0ae7647dffb8aa]] — Immutable conversation event
- [[sources/excerpts/2026/10/3df0129a-4ac7-4a43-b1e8-6ba524ad7929-S1-6580e39aed2d67a8ab4fb8e1]] — Immutable conversation event
- [[sources/excerpts/2026/10/e434b528-4915-47a0-adb2-c3d06593baf4-S1-283f6b91d0c0d54720f92dcb]] — Immutable conversation event
- [[sources/excerpts/2026/10/96c00c26-a224-45c4-9fc4-a9cbea414455-S1-8f367caa78d7ab4e03f5291e]] — Immutable conversation event
