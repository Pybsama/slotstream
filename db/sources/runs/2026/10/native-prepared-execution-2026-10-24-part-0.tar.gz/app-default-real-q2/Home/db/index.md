---
type: index
scope: root
updated: 2026-10-24T03:28:22.094891Z
---

# Knowledge base index

## Sources (79)
- [[sources/conversations/index|Conversations]] (74)
- [[sources/excerpts/index|Excerpts]] (5)

## Records (13)
- [[records/drafts/index|Drafts]] (6)
- [[records/state/index|State]] (1)
- [[records/threads/index|Threads]] (6)
