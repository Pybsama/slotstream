from pathlib import Path
import hashlib,json,subprocess,sys,time
P=Path(__file__).resolve().parent;R=P.parents[1]
while True:
 s=subprocess.run(['ps','-p','53093','-o','command='],capture_output=True,text=True).stdout
 if 'after_v36_isolated.py' not in s:break
 time.sleep(10)
# Observe the result before deciding whether this extra candidate is needed.
for v in ['v37','v38','v39']:
 f=P/(v+'-default-smart-q215-splash-summary.json')
 if f.exists() and json.loads(f.read_text())['parity_or_better']:
  print(v+' met the exploratory parity gate; leave its source for final qualification',flush=True);raise SystemExit(0)
# Repair v36's incomplete harness comparison with a new complete ABBA label.
label='v36-ordinary-retry-smart-q215-splash'
with(P/(label+'-driver.log')).open('x')as log:
 r=subprocess.run([sys.executable,str(P/'native_splash_compare_v36.py'),'--cases',str(P/'short-warm-384-cases.json'),'--label',label,'--native',str(P/'v36/slotstream'),'--model','smart-q2','--budget','15'],cwd=R,stdout=log,stderr=subprocess.STDOUT)
print('v36 corrected comparison',r.returncode,flush=True)
if r.returncode==0:
 subprocess.run([sys.executable,str(P/'comparison_summary.py'),label],cwd=R,check=True)
# Verify source remains the last controller-installed candidate, then restore v36.
results=json.loads((P/'isolated-next-candidates-ledger.json').read_text());last=results[-1]['version']
last_changes={x['path']:x for x in json.loads((P/(last+'-candidate-manifest.json')).read_text())}
all_paths={x['path']for v in ['v37','v38','v39']for x in json.loads((P/(v+'-candidate-manifest.json')).read_text())}
backup=P/'v36-before-further';preserve=P/'before-v40';preserve.mkdir()
for f in all_paths:
 current=(R/f).read_bytes();base=(backup/Path(f).name).read_bytes()
 expected=last_changes[f]['candidate_sha256'] if f in last_changes else hashlib.sha256(base).hexdigest()
 assert hashlib.sha256(current).hexdigest()==expected,f
 (preserve/Path(f).name).write_bytes(current)
for f in all_paths:(R/f).write_bytes((backup/Path(f).name).read_bytes())
manifest=json.loads((P/'v40-candidate-manifest.json').read_text())
for row in manifest:
 assert hashlib.sha256((R/row['path']).read_bytes()).hexdigest()==row['base_sha256'],row['path']
 assert hashlib.sha256((P/'v40-candidate'/row['file']).read_bytes()).hexdigest()==row['candidate_sha256']
 (preserve/('v36-'+row['file'])).write_bytes((R/row['path']).read_bytes())
for row in manifest:(R/row['path']).write_bytes((P/'v40-candidate'/row['file']).read_bytes())
with(P/'v40-controller.log').open('x')as log:r=subprocess.run([sys.executable,str(P/'v40_qualification.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
(P/'tile64-controller-result.json').write_text(json.dumps(dict(exit_code=r.returncode),indent=2)+'\n')
print('v40 candidate completed',r.returncode,flush=True)
