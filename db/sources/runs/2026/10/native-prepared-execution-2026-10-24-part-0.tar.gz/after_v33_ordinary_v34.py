import hashlib,json,shutil,subprocess,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1]
while True:
 s=subprocess.run(['ps','-p','25893','-o','command='],capture_output=True,text=True).stdout
 if 'after_v33_ordinary.py'not in s:break
 time.sleep(10)
ledger=json.loads((P/'v33-ordinary-qualification-ledger.json').read_text())
assert len(ledger)==7 and all(x['exit_code']==0 for x in ledger)
models=[('smart-q2',15),('fast',15),('smart-q2',9)]
if all(json.loads((P/('v33-ordinary-'+m+str(b)+'-splash-summary.json')).read_text())['parity_or_better']for m,b in models):
 print('Ordinary v33 meets all speed gates; leave v34 unbuilt',flush=True);raise SystemExit(0)
manifest=json.loads((P/'v34-candidate-manifest.json').read_text());backup=P/'v33-before-v34';assert not backup.exists()
for item in manifest:
 assert hashlib.sha256((R/item['path']).read_bytes()).hexdigest()==item['base_sha256'],item['path']+' changed'
 assert hashlib.sha256((P/'v34-candidate'/item['file']).read_bytes()).hexdigest()==item['candidate_sha256']
backup.mkdir()
for item in manifest:
 shutil.copy2(R/item['path'],backup/item['file']);shutil.copy2(P/'v34-candidate'/item['file'],R/item['path'])
print('Installed isolated staggered-walk candidate; existing numerical tests unchanged',flush=True)
r=subprocess.run([sys.executable,str(P/'v34_qualification.py')],cwd=R)
raise SystemExit(r.returncode)
