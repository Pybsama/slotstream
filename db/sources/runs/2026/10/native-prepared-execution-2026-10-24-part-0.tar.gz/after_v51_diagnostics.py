from pathlib import Path
import json,subprocess,sys
P=Path(__file__).resolve().parent;R=P.parents[1]
assert json.loads((P/'v51c-controller-result.json').read_text())['exit_code']==0
events=[]
def run(label,cmd):
 print('START',label,flush=True)
 with(P/(label+'-driver.log')).open('x')as f:r=subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT)
 events.append(dict(label=label,command=cmd,exit_code=r.returncode));(P/'after-v51-ledger.json').write_text(json.dumps(events,indent=2)+'\n')
 print('END',label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
run('splash-fixed-replay-c',[sys.executable,str(P/'run_fixed_splash_replay_c.py')])
sys.path.insert(0,str(R/'.build/native-q2-20261021'));from thermal import wait_nominal
wait_nominal(P/'v51-fixed-target-cooldown.json')
run('v51-fixed-target',[sys.executable,str(P/'guarded_run.py'),'--label','v51-fixed-target','--budget','15','--timeout','600','--env','SLOTSTREAM_NATIVE_DEFERRED_ROUTES=0','--env','DYLD_INSERT_LIBRARIES='+str(P/'metal_command_observer_mrc.dylib'),'--env','SLOTSTREAM_METAL_OBSERVER='+str(P/'v51-fixed-target-timestamps'),'--',str(P/'v51/slotstream'),'q2-profile','--model','smart-q2','--memory-gb','15','--rounds','3','--fixture',str(P/'v29-profile-smart-q2-fixture.json'),'--output',str(P/'v51-fixed-target.json')])
