from pathlib import Path
import hashlib,json,subprocess,sys,time
P=Path(__file__).resolve().parent;R=P.parents[1];events=[]
while True:
 s=subprocess.run(['ps','-p','47509','-o','command='],capture_output=True,text=True).stdout
 if 'after_v34_rounding_v36.py' not in s:break
 time.sleep(10)
core=json.loads((P/'v36-core-ledger.json').read_text())
assert len(core)==8 and all(x['exit_code']==0 for x in core),'M16 base did not qualify; inspect before continuing'
versions=['v37','v38','v39']
all_paths={x['path']for version in versions for x in json.loads((P/(version+'-candidate-manifest.json')).read_text())}
original={f:(R/f).read_bytes()for f in all_paths};expected={f:hashlib.sha256(v).hexdigest()for f,v in original.items()}
backup=P/'v36-before-further';backup.mkdir()
for f,raw in original.items():(backup/Path(f).name).write_bytes(raw)
for version in versions:
 for f in all_paths:
  assert hashlib.sha256((R/f).read_bytes()).hexdigest()==expected[f],f
 for f,raw in original.items():(R/f).write_bytes(raw)
 manifest=json.loads((P/(version+'-candidate-manifest.json')).read_text())
 for row in manifest:
  assert hashlib.sha256((R/row['path']).read_bytes()).hexdigest()==row['base_sha256'],row['path']
  assert hashlib.sha256((P/(version+'-candidate')/row['file']).read_bytes()).hexdigest()==row['candidate_sha256']
 for row in manifest:(R/row['path']).write_bytes((P/(version+'-candidate')/row['file']).read_bytes())
 expected={f:hashlib.sha256((R/f).read_bytes()).hexdigest()for f in all_paths}
 print('START',version,flush=True)
 with(P/(version+'-controller.log')).open('x')as log:r=subprocess.run([sys.executable,str(P/(version+'_qualification.py'))],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 events.append(dict(version=version,exit_code=r.returncode));(P/'isolated-next-candidates-ledger.json').write_text(json.dumps(events,indent=2)+'\n')
 print('END',version,r.returncode,flush=True)
 summary=P/(version+'-default-smart-q215-splash-summary.json')
 if r.returncode==0 and summary.exists() and json.loads(summary.read_text())['parity_or_better']:
  print('Candidate passed Q2 parity; final app and repeated-condition qualification still required',flush=True)
  break
