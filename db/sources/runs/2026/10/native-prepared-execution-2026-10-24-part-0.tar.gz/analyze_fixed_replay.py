from pathlib import Path
import csv,json,re,statistics
P=Path(__file__).resolve().parent

def commands(prefix):
 files=list(P.glob(prefix+'.*.csv'));assert len(files)==1,files
 with files[0].open()as f:r=[{k:float(v)for k,v in x.items()}for x in csv.DictReader(line for line in f if not line.startswith('#'))]
 assert all(x['status']==4 and 0<x['start']<=x['end']<=x['completed']for x in r)
 assert len(r)<262144
 return r

def metric(r,start,end):
 intervals=sorted((max(start,c['start']),min(end,c['end']))for c in r if c['end']>start and c['start']<end)
 union=0;last=start
 for a,b in intervals:union+=max(0,b-max(a,last));last=max(last,b)
 return dict(commands=len(intervals),gpu_interval_union_seconds=union,outside_gpu_intervals_seconds=end-start-union)
log=(P/'splash-fixed-replay-c.log').read_text();r=commands('splash-fixed-replay-c-timestamps');rows=[]
for line in log.splitlines():
 if not line.startswith('fixed round='):continue
 d={k:float(v)for k,v in re.findall(r'(\w+)=([0-9.]+)',line)}
 assert d['exact']==1
 rows.append(dict(engine='Splash',**d,**metric(r,d['start'],d['end'])))
assert len(rows)==4
scope='Fixed 84-token prefix and eight forced inputs at 4164 slots. Splash includes draft + target verify + output handling; native profile is target-only. Observed GPU intervals include waits and cannot be called ALU utilization. Splash read-ahead remains active, so its zero-demand warm passes are not zero-I/O cached computation. Instrumented diagnostics are not serving benchmarks.'
if (P/'v51-fixed-target.json').exists():
 d=json.loads((P/'v51-fixed-target.json').read_text());r=commands('v51-fixed-target-timestamps')
 assert d['complete']
 for x in d['runs']:
  assert x['max_logit_difference']==0 and x['argmax_equal']
  if x['width']!=8 or x['traced']:continue
  start=x['started_uptime_ns']/1e9;end=x['ended_uptime_ns']/1e9
  rows.append(dict(engine='Slotstream',round=x['round'],seconds=x['seconds'],io_seconds=x['io_seconds'],paging=bool(x['swapins_delta']or x['swapouts_delta']),**metric(r,start,end)))
result=dict(scope=scope,rows=rows)
(P/'fixed-replay-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
