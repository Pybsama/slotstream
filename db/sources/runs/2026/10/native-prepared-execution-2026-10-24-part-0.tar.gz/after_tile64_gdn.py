from pathlib import Path
import hashlib,json,subprocess,sys,time
P=Path(__file__).resolve().parent;R=P.parents[1]
while True:
 s=subprocess.run(['ps','-p','61743','-o','command='],capture_output=True,text=True).stdout
 if 'after_isolated_tile64.py' not in s:break
 time.sleep(10)
for v in ['v37','v38','v39','v40']:
 f=P/(v+'-default-smart-q215-splash-summary.json')
 if f.exists() and json.loads(f.read_text())['parity_or_better']:
  print(v+' passed exploratory parity; retain source for final qualification',flush=True);raise SystemExit(0)
assert (P/'tile64-controller-result.json').exists(),'tile64 controller did not finish; inspect before mutating source'
manifest=json.loads((P/'v40-candidate-manifest.json').read_text());backup=P/'before-v40';preserve=P/'before-v41';preserve.mkdir()
for row in manifest:
 current=(R/row['path']).read_bytes();base=(backup/('v36-'+row['file'])).read_bytes()
 assert hashlib.sha256(current).hexdigest()==row['candidate_sha256'],row['path']
 assert hashlib.sha256(base).hexdigest()==row['base_sha256'],row['path']
 (preserve/row['file']).write_bytes(current)
for row in manifest:(R/row['path']).write_bytes((backup/('v36-'+row['file'])).read_bytes())
manifest=json.loads((P/'v41-candidate-manifest.json').read_text())
for row in manifest:
 assert hashlib.sha256((R/row['path']).read_bytes()).hexdigest()==row['base_sha256'],row['path']
 assert hashlib.sha256((P/'v41-candidate'/row['file']).read_bytes()).hexdigest()==row['candidate_sha256']
 (preserve/('v36-'+row['file'])).write_bytes((R/row['path']).read_bytes())
for row in manifest:(R/row['path']).write_bytes((P/'v41-candidate'/row['file']).read_bytes())
with(P/'v41-controller.log').open('x')as log:r=subprocess.run([sys.executable,str(P/'v41_qualification.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
(P/'gdn-controller-result.json').write_text(json.dumps(dict(exit_code=r.returncode),indent=2)+'\n')
print('v41 completed',r.returncode,flush=True)
