from pathlib import Path
import json,subprocess,sys,statistics
P=Path(__file__).resolve().parent;R=P.parents[1]
sys.path.insert(0,str(R/'.build/native-q2-20261021'));from thermal import wait_nominal
arms=[]
for i,barrier in enumerate([1,0,0,1]):
 label=f'v51-arc-isolation-{i}-{barrier}'
 wait_nominal(P/(label+'-cooldown.json'))
 cmd=[sys.executable,str(P/'guarded_run.py'),'--label',label,'--budget','15','--timeout','600','--env','SLOTSTREAM_NATIVE_DEFERRED_ROUTES=0','--env','SLOTSTREAM_DECODE_BARRIER_LAYERS=4','--env','SLOTSTREAM_ADAPTIVE_REPLACEMENT='+str(barrier),'--env','DYLD_INSERT_LIBRARIES='+str(P/'metal_command_observer_mrc.dylib'),'--env','SLOTSTREAM_METAL_OBSERVER='+str(P/(label+'-timestamps')),'--',str(P/'v51/slotstream'),'q2-profile','--model','smart-q2','--memory-gb','15','--rounds','3','--fixture',str(P/'v29-profile-smart-q2-fixture.json'),'--output',str(P/(label+'.json'))]
 print('START',label,flush=True)
 with(P/(label+'-driver.log')).open('x')as f:r=subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT)
 if r.returncode:raise SystemExit(r.returncode)
 d=json.loads((P/(label+'.json')).read_text());o=json.loads((P/(label+'.observer.json')).read_text())
 assert len(d['runs'])==32 and all(x['max_logit_difference']==0 and x['argmax_equal']for x in d['runs'])
 rows=[x for x in d['runs']if x['round']>0 and not x['traced']]
 clean=not o['paging'] and o['thermal_before']==o['thermal_after']==0 and all(not x['swapins_delta']and not x['swapouts_delta']and x['io_seconds']==0 for x in rows)
 arm=dict(label=label,barrier=barrier,clean=clean,peak=o['peak_combined_bytes']/1e9,latencies={str(w):statistics.median(x['seconds']for x in rows if x['width']==w)for w in [1,2,4,8]})
 arms.append(arm)
 summary=dict(complete=len(arms)==4,arms=arms,scope='ARC bookkeeping isolation, fixed cached target-only replay. Zero I/O required. No permission to disable production cache policy. Instrumented diagnostic, not serving performance.')
 if len(arms)==4:summary['ratios']={str(w):statistics.median(a['latencies'][str(w)]for a in arms if a['barrier']==0)/statistics.median(a['latencies'][str(w)]for a in arms if a['barrier']==1)for w in [1,2,4,8]}
 (P/'v51-arc-isolation-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 print('END',arm,flush=True)
