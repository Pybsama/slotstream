import hashlib,io,json,shutil,tarfile
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1]
support=P/'captured-support';support.mkdir(exist_ok=True)
for name,source in {
 'quality-and-functional-cases.json':R/'.build/fast-parity-20261022/quality-and-functional-cases.json',
 'grade_v2.py':R/'.build/native-q2-20261021/grade_v2.py',
 'quality-rubric.json':R/'.build/native-q2-20261021/quality-rubric.json',
 'thermal.py':R/'.build/native-q2-20261021/thermal.py',
 'prefill_bench.py':R/'Tools/prefill_bench.py',
 'quantization_tasks.py':R/'Tools/quantization_tasks.py',
 'fast_smart_acceptance.py':R/'Tools/fast_smart_acceptance.py',
 'splash-VerifyBudget.cpp':Path('/tmp/slotstream-splash-review.EJTswU/splash/runtime/model/VerifyBudget.cpp'),
 'splash-VerifyBudget.hpp':Path('/tmp/slotstream-splash-review.EJTswU/splash/runtime/model/VerifyBudget.hpp'),
 'splash-ExecutionGeometry.h':Path('/tmp/slotstream-splash-review.EJTswU/splash/runtime/metal/abi/ExecutionGeometry.h'),
 'splash-ExpertStore.cpp':Path('/tmp/slotstream-splash-review.EJTswU/splash/runtime/model/ExpertStore.cpp'),
 'splash-remaining-decode-optimizations.md':Path('/tmp/slotstream-splash-review.EJTswU/splash/dev/benchmarks/remaining-decode-optimizations.md'),
 'splash-NOTICE.txt':R/'Licenses/splash-NOTICE.txt',
 'splash-Apache-2.0.txt':R/'Licenses/splash-Apache-2.0.txt',
}.items():shutil.copy2(source,support/name)
allowed={'.py','.json','.log','.swift','.md','.txt','.gz','.png','.cpp','.h','.hpp','.metal','.mm','.kvst','.patch','.inc'}
files=sorted(f for f in P.rglob('*') if f.is_file() and f.suffix in allowed
 and 'prefix-cache' not in f.parts and '__pycache__' not in f.parts
 and f.name not in {'archive-receipt.json'})
assert all(f.stat().st_size<20_000_000 for f in files), 'Unexpected large evidence file'
manifest=dict(scope='Native MLX prepared-execution investigation: all completed, rejected and excluded versions, exact component and full-model checks, matched speed and quality, actual app workflows and source identities. Every v*/build-source archive is the authority for its tested binary. Standalone source files are intermediate experiments. Executables, metallibs, model weights and disposable prefix caches are excluded; identities and source reconstruction remain.',files={str(f.relative_to(P)):dict(bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest())for f in files})
destination=R/'db/sources/runs/2026/10/native-prepared-execution-2026-10-23.tar.gz'
assert not destination.exists()
with tarfile.open(destination,'w:gz')as tar:
 for f in files:tar.add(f,arcname=str(f.relative_to(P)),recursive=False)
 raw=(json.dumps(manifest,indent=2)+'\n').encode();info=tarfile.TarInfo('archive-manifest.json');info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
assert destination.stat().st_size < 90_000_000, 'Split the evidence archive before Git publication'
with tarfile.open(destination)as tar:
 for name,entry in manifest['files'].items():
  raw=tar.extractfile(name).read();assert len(raw)==entry['bytes'] and hashlib.sha256(raw).hexdigest()==entry['sha256']
receipt=dict(path=str(destination.relative_to(R)),bytes=destination.stat().st_size,sha256=hashlib.sha256(destination.read_bytes()).hexdigest(),files=len(files))
(P/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
