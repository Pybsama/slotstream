from pathlib import Path
import hashlib,json,subprocess,sys,time
P=Path(__file__).resolve().parent;R=P.parents[1]
while True:
 s=subprocess.run(['ps','-p','68238','-o','command='],capture_output=True,text=True).stdout
 if 'post_v39_candidates.py' not in s:break
 time.sleep(10)
for v in ['v39','v40','v41','v42']:
 f=P/(v+'-default-smart-q215-splash-summary.json')
 if f.exists() and json.loads(f.read_text())['parity_or_better']:
  print('Prior candidate met exploratory parity; do not replace it',flush=True);raise SystemExit(0)
ledger=json.loads((P/'post-v39-ledger.json').read_text())
assert ledger[-1]['label']=='v36-submission-probe','Previous pipeline incomplete'
# The last installed isolated candidate was v41, on the unchanged v36 base.
# Restore that one file before applying this independent topology candidate.
gdn=json.loads((P/'v41-candidate-manifest.json').read_text())[0]
f=R/gdn['path'];assert hashlib.sha256(f.read_bytes()).hexdigest()==gdn['candidate_sha256']
base=P/'post-v39-source-backup'/gdn['file'];assert hashlib.sha256(base.read_bytes()).hexdigest()==gdn['base_sha256']
(P/'v43-before-gdn.swift').write_bytes(f.read_bytes());f.write_bytes(base.read_bytes())
for row in json.loads((P/'v43-candidate-manifest.json').read_text()):
 f=R/row['path'];assert hashlib.sha256(f.read_bytes()).hexdigest()==row['base_sha256']
 data=(P/'v43-candidate'/row['file']).read_bytes();assert hashlib.sha256(data).hexdigest()==row['candidate_sha256']
 f.write_bytes(data)
with(P/'v43-serial-qualification-driver.log').open('x')as log:
 r=subprocess.run([sys.executable,str(P/'v43_qualification.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
(P/'v43-controller-result.json').write_text(json.dumps(dict(exit_code=r.returncode),indent=2)+'\n')
print('v43 finished',r.returncode,flush=True)
raise SystemExit(r.returncode)
