import json,subprocess,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];deadline=time.monotonic()+3600
while True:
 f=P/'v22c-resume-ledger.json'
 if f.exists():
  rows=json.loads(f.read_text())
  if rows and rows[-1]['label']=='v22-app':break
  if rows and rows[-1]['exit_code']:raise SystemExit('Earlier capacity step failed; inspect before continuing')
 if time.monotonic()>deadline:raise SystemExit('Bounded wait for existing app qualification expired')
 time.sleep(5)
app=json.loads((P/'app-default-qualification-ledger.json').read_text())
assert app[-1]['label']=='app-default-real-q2','App build/scripted qualification did not reach real-model controls'
assert all(r['exit_code']==0 for r in app[:2]),'App build/scripted qualification failed'
print('Existing app controls complete. Starting isolated next candidate.',flush=True)
r=subprocess.run([sys.executable,str(P/'v23_qualification.py')],cwd=R)
raise SystemExit(r.returncode)
