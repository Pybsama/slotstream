from pathlib import Path
import bisect,collections,json
P=Path(__file__).resolve().parent;L=P.parent/'q2-demand-lifecycle-20261025'
s=(L/'analyze_lane_tail.py').read_text().split('data=json.loads')[0];exec(compile(s,str(L/'analyze_lane_tail.py'),'exec'),globals());P=Path(__file__).resolve().parent
data=json.loads((H/(label+'.json')).read_text());out=[]
for r in data['runs']:
 if not r['id'].startswith('timed'):continue
 lo,hi=r['request_started_mach_ns']/1e9,r['request_ended_mach_ns']/1e9
 ss=[x for x in signals if lo<=x<hi]
 ff=sorted([x for x in reads if lo<=x['start']<hi and x['destination']in forecast],key=lambda x:x['start']);groups=collections.defaultdict(list);frontier=-1
 for x in ff:
  layer=x['layer']; candidates=[48*p+layer for p in range(max(0,frontier//48-1),frontier//48+3)]
  i=min(candidates,key=lambda i:abs(i-frontier))
  assert i>=frontier-1,('nonadjacent old layer',frontier,i,x)
  frontier=max(frontier,i);groups[i].append(x)
 assert sum(map(len,groups.values()))==len(ff)
 batches=[]
 for i,rr in sorted(groups.items()):
  start,end=min(x['start']for x in rr),max(x.get('copy_end',x['end'])for x in rr)
  active=union([[x['start'],x.get('copy_end',x['end'])]for x in rr]);span=[[start,end]]
  hole=end-start-length(active)
  # Per-queue unknown: observe any forecast read/copy, not worker-idle accounting.
  batches.append(dict(index=i,layer=i%48,reads=len(rr),read_copy_span=end-start,read_copy_union=length(active),gaps=hole,gaps_outside_gpu=hole-(length(inter(span,gpu))-length(inter(active,gpu))),initial_launch_delay=None,throughput_bytes=sum(x['result']for x in rr)))
 gaps=sum(b['gaps']for b in batches);report=dict(id=r['id'],signals=len(ss),forecast_reads=len(ff),forecast_groups=len(groups),grouping='physical extent layer, chronological nearest pass, no more than one layer of overlap',totals={k:sum(b[k]for b in batches)for k in ['read_copy_span','read_copy_union','gaps','gaps_outside_gpu']},mean_reads_per_group=len(ff)/len(groups),batch_data=batches)
 out.append(report);print(json.dumps({k:v for k,v in report.items()if k!='batch_data'},indent=2),flush=True)
(P/'forecast-gap-analysis.json').write_text(json.dumps(dict(scope='Offline forecast bursts in clean ordinary trace. Four scratch destinations independently validated against demand counts in prior study. Forecast layers come from original physical extents, grouped by chronological pass/layer. Host signals are not emitted for fully ready layers and cannot be indexed as all layer boundaries. Gaps between any observed forecast read/copy are not measured queue wait or recoverable delay; missing CPU copy on cancelled read uses read end. No scheduler change/causal speed claim.',requests=out),indent=2))
