from pathlib import Path
import fcntl, hashlib, json, os, shlex, shutil, subprocess, sys

P = Path(__file__).resolve().parent
R = P.parents[1]
D = P / 'fixed-check'
assert not D.exists()
D.mkdir()
sys.path.insert(0, str(R / 'Tools'))
from prefill_bench import preflight

lock = open(f'/tmp/slotstream-model-{os.getuid()}.lock', 'a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(P/'fixed-build-child.lock')
before = preflight(4)
source = (P.parent / 'q2-sequence-20261025/Q2ProfileCommand-v4.swift').read_text()
source += '\n@main struct FrozenMain { static func main() { Q2ProfileCheck.main() } }\n'
src = D / 'FrozenCheck.swift'
src.write_text(source)
release = R / '.build/release'
objects = [shlex.split(s)[0] for s in (release / 'slotstream.product/Objects.LinkFileList').read_text().splitlines() if '/slotstream_cli.build/' not in s]
(D / 'objects.txt').write_text('\n'.join(shlex.quote(o) for o in objects) + '\n')
desc = json.loads((release / 'description.json').read_text())
module = next(v for v in desc['swiftCommands'].values() if v.get('moduleName') == 'Slotstream')
args = module['otherArguments']
cc = []
for i, arg in enumerate(args[:-1]):
    if arg == '-Xcc': cc.extend([arg, args[i+1]])
binary = D / 'piece-checks'
cmd = ['xcrun', 'swiftc', '-O', '-parse-as-library', '-swift-version', '5', '-package-name', 'slotstream', '-target', 'arm64-apple-macosx14.0', '-I', str(release / 'Modules'), *cc, str(src), '@' + str(D / 'objects.txt'), '-lc++', '-framework', 'Metal', '-framework', 'Accelerate', '-o', str(binary)]
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
receipt = dict(command=cmd, before=before, source_sha256=sha(src), objects={str(Path(o).relative_to(R)):sha(o) for o in objects}, scope='Actual candidate engine objects; unchanged frozen target-sequence harness. Build only, no timing claim.')
(D / 'build-inputs.json').write_text(json.dumps(receipt, indent=2))
with (D / 'build.log').open('w') as log:
    subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT, check=True, timeout=120)
shutil.copy2(release / 'mlx.metallib', D / 'mlx.metallib')
print(json.dumps(dict(binary=str(binary),built=True)))
