from pathlib import Path
import hashlib,io,json,re,tarfile,shutil
P=Path(__file__).resolve().parent;R=P.parents[1];sha=lambda b:hashlib.sha256(b).hexdigest()
refs=[]
for dirname,name,patterns in [('q2-host-profile-20261025','q2-ordinary-copies-attribution-2026-10-25.tar.xz',['ordinary-copies-15-0-A*.csv','ordinary-copies-15-0-A.json']),('q2-demand-lifecycle-20261025','q2-demand-lifecycle-triage-2026-10-25.tar.xz',['analyze_lane_tail.py'])]:
 archive=R/'db/sources/runs/2026/10'/name
 with tarfile.open(archive)as t:
  manifest=json.load(t.extractfile('archive-manifest.json'));verified={}
  for pattern in patterns:
   for f in(R/'.build'/dirname).glob(pattern):
    key=f.name if f.name in manifest else 'demand-lifecycle/'+f.name
    assert key in manifest,(key,name)
    h=sha(f.read_bytes());assert h==manifest[key]['sha256'];verified[key]=h
  assert verified
 refs.append(dict(archive=str(archive.relative_to(R)),sha256=sha(archive.read_bytes()),files=verified))
(P/'prior-evidence.json').write_text(json.dumps(refs,indent=2))
files={}
for f in P.rglob('*'):
 if not f.is_file()or'__pycache__'in f.parts or f.name=='archive-receipt.json':continue
 if f.suffix not in ['.py','.swift','.json','.csv','.log','.stderr','.txt']:continue
 if f.name=='objects.txt':continue
 files[str(f.relative_to(P))]=f
W=Path('/var/folders/d4/t1c8ltbx5s3_11cs9y6gjh8m0000gp/T/slotstream-splash-host-ugnf26pi/source')
for n in ['runtime/model/ExpertStore.cpp','runtime/metal/MetalBackend.mm']:
 files['upstream/'+n]=W/n
for n in ['Sources/Slotstream/Layers.swift','Sources/Slotstream/ExpertPrefetch.swift','Sources/Slotstream/NativeExpertSchedule.swift']:
 files['baseline/'+n]=R/n
for name,path in [('frozen-baseline.json',R/'.build/q2-sequence-20261025/frequency-untraced-0-N.json'),('fixture.json',R/'.build/q2-sequence-20261025/timed-2.json'),('gguf-header.json',R/'.build/smart-dflash-eval/gsq-header.json')]:files['reference/'+name]=path
secret=re.compile(rb'(?:ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{25,}|sk-(?:proj-)?[A-Za-z0-9_-]{30,}|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----)');manifest={}
for n,f in files.items():
 b=f.read_bytes();assert not secret.search(b),n;manifest[n]=dict(bytes=len(b),sha256=sha(b))
dest=R/'db/sources/runs/2026/10/q2-forecast-launch-control-2026-10-25.tar.xz';assert not dest.exists();raw=json.dumps(manifest,indent=2).encode()
with tarfile.open(dest,'w:xz',preset=3)as t:
 for n,f in sorted(files.items()):t.add(f,arcname=n,recursive=False)
 info=tarfile.TarInfo('archive-manifest.json');info.size=len(raw);t.addfile(info,io.BytesIO(raw))
seen={}
with tarfile.open(dest,'r|xz')as t:
 for m in t:
  b=t.extractfile(m).read()
  if m.name=='archive-manifest.json':assert json.loads(b)==manifest
  else:seen[m.name]=dict(bytes=len(b),sha256=sha(b))
assert seen==manifest
receipt=dict(path=str(dest.relative_to(R)),files=len(manifest),bytes=dest.stat().st_size,sha256=sha(dest.read_bytes()),readback_verified=True,credential_pattern_matches=0,prior_refs=refs,excluded='Executables/libraries/weights and duplicate full source archives; exact candidate patch, build identity, correctness sources, guards and complete-request outputs preserved.')
(P/'archive-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps({k:v for k,v in receipt.items()if k!='prior_refs'},indent=2))
