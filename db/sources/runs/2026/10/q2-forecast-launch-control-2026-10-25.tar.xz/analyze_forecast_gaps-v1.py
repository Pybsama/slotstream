from pathlib import Path
import bisect,collections,json
P=Path(__file__).resolve().parent;L=P.parent/'q2-demand-lifecycle-20261025'
s=(L/'analyze_lane_tail.py').read_text().split('data=json.loads')[0];exec(compile(s,str(L/'analyze_lane_tail.py'),'exec'),globals());P=Path(__file__).resolve().parent
data=json.loads((H/(label+'.json')).read_text());out=[]
for r in data['runs']:
 if not r['id'].startswith('timed'):continue
 lo,hi=r['request_started_mach_ns']/1e9,r['request_ended_mach_ns']/1e9
 ss=[x for x in signals if lo<=x<hi];expected=r['stats']['decodeForwardPasses']*48
 print(r['id'],'signals',len(ss),'expected',expected,flush=True);assert len(ss)==expected
 ff=[x for x in reads if lo<=x['start']<hi and x['destination']in forecast];groups=collections.defaultdict(list);mismatch=[]
 for x in ff:
  i=bisect.bisect_left(ss,x['start'])
  if i>=len(ss)or i%48!=x['layer']:mismatch.append(x);continue
  groups[i].append(x)
 assert not mismatch,('layer mismatch',len(mismatch),mismatch[:2])
 batches=[]
 for i,rr in sorted(groups.items()):
  start,end=min(x['start']for x in rr),max(x.get('copy_end',x['end'])for x in rr)
  active=union([[x['start'],x.get('copy_end',x['end'])]for x in rr]);span=[[start,end]]
  hole=end-start-length(active)
  # Per-queue unknown: observe any forecast read/copy, not worker-idle accounting.
  batches.append(dict(index=i,layer=i%48,reads=len(rr),read_copy_span=end-start,read_copy_union=length(active),gaps=hole,gaps_outside_gpu=hole-(length(inter(span,gpu))-length(inter(active,gpu))),initial_launch_delay=start-ss[i-1]if i else None,throughput_bytes=sum(x['result']for x in rr)))
 gaps=sum(b['gaps']for b in batches);report=dict(id=r['id'],signals=len(ss),forecast_reads=len(ff),forecast_groups=len(groups),all_read_start_layers_match_next_publication=True,totals={k:sum(b[k]for b in batches)for k in ['read_copy_span','read_copy_union','gaps','gaps_outside_gpu']},mean_reads_per_group=len(ff)/len(groups),batch_data=batches)
 out.append(report);print(json.dumps({k:v for k,v in report.items()if k!='batch_data'},indent=2),flush=True)
(P/'forecast-gap-analysis.json').write_text(json.dumps(dict(scope='Offline forecast bursts in clean ordinary trace. Four scratch destinations independently validated against demand counts in prior study. Each forecast start maps exactly to target layer via next expert publication. Gaps between any observed forecast read/copy are not measured queue wait or recoverable delay; missing CPU copy on cancelled read uses read end. No scheduler change/causal speed claim.',requests=out),indent=2))
