from pathlib import Path
import fcntl,os,sys,subprocess,json,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1]
lock=open(f'/tmp/slotstream-model-{os.getuid()}.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
inner=P/'correctness-child.lock';os.environ['SLOTSTREAM_MODEL_LOCK_PATH']=str(inner)
binary=P/'native-build/candidate/slotstream'
base=[sys.executable,str(P/'quiet_guarded_run.py'),'--budget','15','--env','SLOTSTREAM_MODEL_LOCK_PATH='+str(inner)]
commands=[('original-check',base+['--label','original-check','--env','MTL_DEBUG_LAYER=1','--',str(binary),'q2-experts-check','--pool-model','smart-q2']),('frozen-check',base+['--label','frozen-check','--',str(P/'fixed-check/piece-checks'),'--fixture',str(P.parent/'q2-sequence-20261025/timed-2.json'),'--output',str(P/'frozen-result.json'),'--rounds','1','--memory-gb','15','--ahead','1'])]
for name,cmd in commands:
 print('START',name,flush=True)
 with(P/(name+'-launcher.log')).open('x')as log:subprocess.run(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=1800)
 print('PASS',name,flush=True)
a=json.loads((P/'frozen-result.json').read_text());ref=P.parent/'q2-sequence-20261025/frequency-untraced-0-N.json';b=json.loads(ref.read_text());gold={r['step']:r['logits_sha256']for r in b['runs']if r['round']==0}
assert a['complete'] and len(a['runs'])==len(gold)==111
assert all(r['logits_sha256']==gold[r['step']]for r in a['runs'])
assert all(r['scheduled_passes']==48 and r['gpu_forecast_records']>0 for r in a['runs'])
receipt=dict(complete=True,passes=111,all_logits_exact=True,scheduled_layers=sum(r['scheduled_passes']for r in a['runs']),gpu_forecast_records=sum(r['gpu_forecast_records']for r in a['runs']),baseline=str(ref),baseline_sha256=hashlib.sha256(ref.read_bytes()).hexdigest(),scope='Unchanged frozen sequential target-only replay and rollback, original-weight/cache/lifetime checks. No complete-request timing or semantic-quality claim.')
(P/'correctness.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt),flush=True)
