#import "MetalBackend.hpp"
#include "AwakeClock.hpp"
#include "CommandWatchdog.hpp"
#include "Residency.hpp"
#include "StderrLine.hpp"
#ifdef SPLASH_BACKEND_INSTRUMENTATION
#include "BackendInstrumentation.hpp"
#endif

#import <Foundation/Foundation.h>
#import <Metal/Metal.h>

#include <IOKit/IOKitLib.h>
#include <dispatch/dispatch.h>

#include <algorithm>
#include <atomic>
#include <bit>
#include <chrono>
#include <cmath>
#include <condition_variable>
#include <cstring>
#include <deque>
#include <filesystem>
#include <iomanip>
#include <limits>
#include <mutex>
#include <new>
#include <optional>
#include <sstream>
#include <string_view>
#include <thread>
#include <unordered_map>
#include <utility>

#include <pthread.h>
#include <unistd.h>

namespace splash::metal {
namespace {

// The accelerator entry that backs a Metal device publishes gpu-core-count.
// The device's registry ID names that entry or a child of it; the first
// IOAccelerator service is the fallback, since Apple silicon Macs have one
// GPU. Zero means the property was not found anywhere.
uint32_t gpuCoreCountForDevice(uint64_t registryId) noexcept {
    uint32_t count = 0;
    const auto read = [&](io_registry_entry_t entry) {
        if (!entry) return false;
        CFTypeRef value = IORegistryEntryCreateCFProperty(
            entry, CFSTR("gpu-core-count"), kCFAllocatorDefault, 0);
        if (value) {
            int64_t number = 0;
            if (CFGetTypeID(value) == CFNumberGetTypeID() &&
                CFNumberGetValue(static_cast<CFNumberRef>(value),
                                 kCFNumberSInt64Type, &number) &&
                number > 0 && number <= 4096) {
                count = static_cast<uint32_t>(number);
            }
            CFRelease(value);
        }
        return count != 0;
    };
    io_registry_entry_t entry = IOServiceGetMatchingService(
        kIOMainPortDefault, IORegistryEntryIDMatching(registryId));
    for (int depth = 0; entry && depth < 4 && !read(entry); ++depth) {
        io_registry_entry_t parent = MACH_PORT_NULL;
        if (IORegistryEntryGetParentEntry(entry, kIOServicePlane, &parent) !=
            KERN_SUCCESS) {
            parent = MACH_PORT_NULL;
        }
        IOObjectRelease(entry);
        entry = parent;
    }
    if (entry) IOObjectRelease(entry);
    if (!count) {
        io_registry_entry_t accelerator = IOServiceGetMatchingService(
            kIOMainPortDefault, IOServiceMatching("IOAccelerator"));
        if (accelerator) {
            read(accelerator);
            IOObjectRelease(accelerator);
        }
    }
    return count;
}

std::string stringFromNSString(NSString *value) {
    if (!value) return {};
    const char *utf8 = value.UTF8String;
    return utf8 ? utf8 : "";
}

std::string errorDescription(NSError *error) {
    if (!error) return "unknown Metal error";
    std::string result = stringFromNSString(error.localizedDescription);
    return result.empty() ? "unknown Metal error" : result;
}

void readMacosVersion(DeviceCapabilities &capabilities) {
    const NSOperatingSystemVersion os =
        NSProcessInfo.processInfo.operatingSystemVersion;
    const auto component = [](NSInteger value) {
        return value > 0 ? static_cast<uint32_t>(value) : 0U;
    };
    capabilities.macosMajor = component(os.majorVersion);
    capabilities.macosMinor = component(os.minorVersion);
    capabilities.macosPatch = component(os.patchVersion);
}

// The backend and probeDeviceCapabilities() share one reading of the device,
// so the probe judges a Mac by the values the engine validates.
void readDeviceCapabilities(id<MTLDevice> device,
                            DeviceCapabilities &capabilities) {
    capabilities.deviceName = stringFromNSString(device.name);
    capabilities.gpuCoreCount = gpuCoreCountForDevice(device.registryID);
    // Apple GPU families nest, so the device's is the last one supported
    // counting up from Apple7.
    uint32_t family = 0;
    for (uint32_t next = 7;
         [device supportsFamily:static_cast<MTLGPUFamily>(1000 + next)]; ++next)
        family = next;
    capabilities.appleGpuFamily = family;
    capabilities.physicalMemoryBytes = NSProcessInfo.processInfo.physicalMemory;
    capabilities.recommendedMaxWorkingSetBytes =
        device.recommendedMaxWorkingSetSize;
    capabilities.maxBufferLengthBytes = device.maxBufferLength;
    capabilities.maxThreadgroupMemoryBytes = device.maxThreadgroupMemoryLength;
    MTLSize maximumThreads = device.maxThreadsPerThreadgroup;
    capabilities.maxThreadgroupWidth = maximumThreads.width;
    capabilities.hasUnifiedMemory = device.hasUnifiedMemory;
}

// Every uint64_t size, offset and length passes to Metal as it is.
static_assert(sizeof(NSUInteger) == sizeof(uint64_t),
              "Splash builds for arm64 only");

MTLSize metalSize(const DispatchSize &size, std::string_view field) {
    if (!size.x || !size.y || !size.z) {
        throw MetalBackendError(std::string(field) + " must be non-zero");
    }
    return MTLSizeMake(size.x, size.y, size.z);
}

bool multiplyOverflows(uint64_t left, uint64_t right) {
    return right && left > std::numeric_limits<uint64_t>::max() / right;
}

// Entries of a kernel's buffer argument table on every Apple GPU family.
constexpr uint32_t kBufferArgumentEntries = 31;
// How long a ticket waits for its command before it asks the watchdog.
constexpr auto kTicketWaitSlice = std::chrono::seconds(1);
// The queue's outstanding command buffers; a command takes one, and one more
// per buffer its event steps add (addedBuffers).
constexpr NSUInteger kMaximumCommandBuffers = 512;
// The most loads host_step_wait spins for: 60-190 ms on the M5 Max (0.23-0.71
// us a load), longer than nearly every step's work.
constexpr uint32_t kHostStepWaitLoads = 1u << 18;
// Where in the spin's release buffer (HostStepSpin) host_step_wait writes the
// release it saw and the loads it made before: a cache line past the counter
// the CPU raises (word 0).
constexpr NSUInteger kHostStepSeenOffset = 128;
// The library of host_step_wait, beside the backend's own: built apart, as
// its compiler may refuse it (Makefile), and loaded only for awake steps.
constexpr std::string_view kHostStepLibrary = "host-step.metallib";
// How long after a spin check that decided nothing (every spin started after
// its release, the GPU busy with other work) awake steps check it again.
constexpr auto kHostStepSpinRecheck = std::chrono::seconds(10);

// The command buffers an event step adds to its command: a signal ends one,
// and a host step one more for the GPU's spin when it keeps the GPU awake.
NSUInteger addedBuffers(const EventStep &step) noexcept {
    switch (step.kind) {
    case EventStep::Kind::Signal: return 1;
    case EventStep::Kind::Wait: return 0;
    case EventStep::Kind::Host: return step.gpu == HostStepGpu::Awake ? 2 : 1;
    }
    return 0;
}

// The command buffers a command of `dispatches` dispatches and these event
// steps takes: one, and those its steps add. Refuses the steps when its
// submission cannot encode them.
NSUInteger checkEvents(std::span<const EventStep> events, size_t dispatches) {
    size_t before = 0;
    NSUInteger buffers = 1;
    for (const EventStep &step : events) {
        if (step.kind == EventStep::Kind::Host ? !step.work : !step.event || !step.value)
            throw MetalBackendError(step.kind == EventStep::Kind::Host
                                        ? "host step needs work"
                                        : "event step needs an event and a nonzero value");
        if (step.gpu == HostStepGpu::Awake && step.kind != EventStep::Kind::Host)
            throw MetalBackendError("only a host step keeps the GPU awake");
        if (step.before < before)
            throw MetalBackendError("event steps are out of dispatch order");
        if (step.before > dispatches)
            throw MetalBackendError(
                "event step follows more dispatches than its command has");
        before = step.before;
        buffers += addedBuffers(step);
    }
    if (buffers > kMaximumCommandBuffers)
        throw MetalBackendError("Metal command's event steps take more command "
                                "buffers than its queue holds");
    return buffers;
}

// Raises the release counter of host steps (word 0 of `releases`) to
// `value`, which ends the GPU's spin through the step of that value
// (host_step_wait).
void release(id<MTLBuffer> releases, uint32_t value) noexcept {
    static_cast<std::atomic<uint32_t> *>(releases.contents)->store(value, std::memory_order_release);
}

double awakeSeconds() noexcept {
    return std::chrono::duration<double>(AwakeClock::now().time_since_epoch()).count();
}

const char *commandStatusName(MTLCommandBufferStatus status) noexcept {
    switch (status) {
    case MTLCommandBufferStatusNotEnqueued: return "not_enqueued";
    case MTLCommandBufferStatusEnqueued: return "enqueued";
    case MTLCommandBufferStatusCommitted: return "committed";
    case MTLCommandBufferStatusScheduled: return "scheduled";
    case MTLCommandBufferStatusCompleted: return "completed";
    case MTLCommandBufferStatusError: return "error";
    }
    return "unknown";
}

template <typename T>
void raisePeak(std::atomic<T> &peak, T value) noexcept {
    T current = peak.load(std::memory_order_relaxed);
    while (value > current &&
           !peak.compare_exchange_weak(current, value,
                                       std::memory_order_relaxed)) {}
}

// Hashes pipeline names as views, so a cache lookup builds no string.
struct PipelineNameHash {
    using is_transparent = void;
    size_t operator()(std::string_view name) const noexcept {
        return std::hash<std::string_view>{}(name);
    }
};

NSString *checkedNSString(std::string_view value, std::string_view field) {
    NSString *result = [[NSString alloc]
        initWithBytes:value.data()
        length:value.size()
        encoding:NSUTF8StringEncoding];
    if (!result) {
        throw MetalBackendError(std::string(field) + " is not UTF-8");
    }
    return result;
}

id<MTLLibrary> loadLibrary(id<MTLDevice> device, const std::string &metallibPath) {
    NSString *path = checkedNSString(metallibPath, "metallib path");
    NSError *error = nil;
    NSData *fileData = [NSData dataWithContentsOfFile:path
                                             options:0
                                               error:&error];
    if (!fileData) {
        throw MetalBackendError(
            "unable to read metallib " + metallibPath + ": " +
            errorDescription(error));
    }
    // The library keeps the bytes read here, whatever later replaces the
    // path; the dispatch data retains them rather than copying them.
    dispatch_data_t data = dispatch_data_create(
        fileData.bytes, fileData.length, nullptr, ^{ (void)fileData; });
    error = nil;
    id<MTLLibrary> library = [device newLibraryWithData:data error:&error];
    if (!library) {
        throw MetalBackendError(
            "unable to load metallib " + metallibPath + ": " +
            errorDescription(error));
    }
    return library;
}

}  // namespace

struct AllocationAccounting {
    std::atomic<uint64_t> allocatedBytes{0};
    std::atomic<uint64_t> peakAllocatedBytes{0};
};

struct MetalAllocation {
    // Nil while the memory is released (MetalBackend::releaseMemory).
    __strong id<MTLBuffer> buffer = nil;
    std::shared_ptr<AllocationAccounting> accounting;
    // What the buffer adds to the accounting: its allocated size, or zero
    // while released.
    uint64_t bytes = 0;
    // The length, storage and label a restored buffer is allocated with, and
    // how kernels reach it.
    uint64_t length = 0;
    BufferStorage storage = BufferStorage::Shared;
    __strong NSString *label = nil;
    BufferReach reach = BufferReach::Bound;
    // The owner of wrapped memory (MetalBackend::wrapSharedMemory), which is
    // never released: our views keep it as well as Metal's deallocator.
    std::shared_ptr<void> owner;
    // The residency set the buffer belongs to, held weakly as allocations
    // may outlive the backend. The set retains the buffer, and with it its
    // memory, so the last view takes it out.
    std::weak_ptr<Residency> residency;

    // Takes the buffer, which joins the residency set and the accounting.
    void attach(id<MTLBuffer> allocated) {
        buffer = allocated;
        bytes = allocated.allocatedSize;
        if (auto kept = residency.lock()) kept->add(buffer, reach);
        raisePeak(accounting->peakAllocatedBytes,
                  accounting->allocatedBytes.fetch_add(
                      bytes, std::memory_order_relaxed) + bytes);
    }
    // Lets the buffer go: it leaves the residency set and the accounting.
    void detach() noexcept {
        if (!buffer) return;
        if (auto kept = residency.lock()) kept->remove(buffer, reach);
        accounting->allocatedBytes.fetch_sub(bytes, std::memory_order_relaxed);
        buffer = nil;
        bytes = 0;
    }

    ~MetalAllocation() { detach(); }
};

// Every Impl has an allocation, whose buffer is nil only while its memory is
// released: only allocateBuffer, wrapSharedMemory and view create one.
struct MetalBuffer::Impl {
    std::shared_ptr<MetalAllocation> allocation;
    uint64_t offsetBytes = 0;
    uint64_t lengthBytes = 0;
};

struct SharedEvent::Impl {
    __strong id<MTLSharedEvent> event = nil;
    // The listener of the backend that created the event, which runs its
    // notify() callbacks; the backend and each of its events hold it.
    __strong MTLSharedEventListener *listener = nil;
};

struct BackendAsyncState {
    explicit BackendAsyncState(double commandTimeoutSeconds)
        : commandWatchdog(commandTimeoutSeconds) {}

    __strong id<MTLDevice> device = nil;
    mutable std::atomic<uint64_t> deviceCurrentAllocatedBytes{0};
    mutable std::atomic<uint64_t> devicePeakAllocatedBytes{0};
    std::atomic<bool> healthy{true};
    mutable std::mutex healthMutex;
    std::string healthReason;
    mutable std::mutex gateMutex;
    uint64_t nextSequence = 0;
    uint64_t activeSequence = 0;
    size_t activeDispatchCount = 0;
    __weak id<MTLCommandBuffer> activeCommand = nil;
    std::function<void(id<MTLCommandBuffer>)> activeCompletion;
    CommandWatchdog commandWatchdog;
    bool stopping = false;
    // MetalBackend::setWaitInterrupt's predicate.
    std::function<bool()> waitInterrupt;

    void sampleDeviceMemory() const noexcept {
        if (!device) return;
        uint64_t current = static_cast<uint64_t>(device.currentAllocatedSize);
        deviceCurrentAllocatedBytes.store(current, std::memory_order_relaxed);
        raisePeak(devicePeakAllocatedBytes, current);
    }

    [[noreturn]] void throwUnhealthy() const {
        std::lock_guard lock(healthMutex);
        throw MetalBackendError("Metal backend is unhealthy: " + healthReason);
    }

    void ensureHealthy() const {
        if (!healthy.load(std::memory_order_acquire)) throwUnhealthy();
    }

    void markUnhealthy(std::string reason) {
        {
            std::lock_guard lock(healthMutex);
            if (healthReason.empty()) healthReason = std::move(reason);
        }
        healthy.store(false, std::memory_order_release);
    }

    uint64_t beginSubmission(size_t dispatchCount) {
        ensureHealthy();
        std::lock_guard lock(gateMutex);
        if (stopping)
            throw MetalBackendError("Metal backend is stopping");
        if (activeSequence) {
            throw MetalBackendError(
                "Metal backend already has an in-flight command");
        }
        activeSequence = ++nextSequence;
        activeDispatchCount = dispatchCount;
        return activeSequence;
    }

    // Commits a command's last buffer, the buffers before it committed as
    // their encoding ended (Impl::commit).
    void commitSubmission(uint64_t sequence, id<MTLCommandBuffer> command,
                          std::function<void(id<MTLCommandBuffer>)> completion) {
        std::lock_guard lock(gateMutex);
        activeCommand = command;
        activeCompletion = std::move(completion);
        commandWatchdog.start(sequence, awakeSeconds());
        [command commit];
    }

    void releaseSubmission(uint64_t sequence) noexcept {
        std::lock_guard lock(gateMutex);
        commandWatchdog.complete(sequence);
        if (activeSequence == sequence) {
            activeSequence = 0;
            activeCommand = nil;
            activeCompletion = {};
        }
    }

    void completeSubmission(uint64_t sequence) noexcept {
        std::lock_guard lock(gateMutex);
        commandWatchdog.complete(sequence);
    }

    // A host step of the command was taken up or returned at nowSeconds
    // (CommandWatchdog).
    void progressSubmission(uint64_t sequence, double nowSeconds) noexcept {
        std::lock_guard lock(gateMutex);
        commandWatchdog.progress(sequence, nowSeconds);
    }

    // Runs the command watchdog. A terminal command whose callback is late
    // is completed here; one still running past its timeout marks the
    // backend unhealthy, and the answer is then true: the backend gave up on
    // that command.
    [[nodiscard]] bool commandAbandoned() noexcept {
        id<MTLCommandBuffer> command = nil;
        std::function<void(id<MTLCommandBuffer>)> complete;
        {
            std::lock_guard lock(gateMutex);
            if (!commandWatchdog.expired(awakeSeconds())) return false;
            command = activeCommand;
            const auto status = command ? command.status
                                        : MTLCommandBufferStatusNotEnqueued;
            // Recover terminal results even if the driver has not delivered
            // its callback. Finish outside the gate: it takes the ticket lock.
            if (command && (status == MTLCommandBufferStatusCompleted ||
                            status == MTLCommandBufferStatusError)) {
                complete = activeCompletion;
            } else {
                // Waits that must not throw run this too: the reason drops
                // its details when they cannot be formatted.
                std::string reason = "Metal command completion timed out";
                try {
                    std::ostringstream message;
                    message << reason << " after "
                            << commandWatchdog.timeoutSeconds()
                            << " seconds (sequence=" << activeSequence
                            << ", status=" << (command ? commandStatusName(status)
                                                       : "unavailable")
                            << ", dispatches=" << activeDispatchCount << ')';
                    reason = message.str();
                } catch (const std::bad_alloc &) {
                }
                markUnhealthy(std::move(reason));
                return true;
            }
        }
        if (complete) complete(command);
        return false;
    }

    void checkCommandHealth() {
        static_cast<void>(commandAbandoned());
        ensureHealthy();
    }

    // True when the process is shutting down; the waiter decides whether
    // that gives its command up.
    [[nodiscard]] bool waitInterrupted() const noexcept {
        return waitInterrupt && waitInterrupt();
    }

    [[nodiscard]] bool hasActiveSubmission() const noexcept {
        std::lock_guard lock(gateMutex);
        return activeSequence != 0;
    }
};

// The host steps of one command (EventStep::Kind::Host), which the backend
// raises through two events of their own, each written by one side: the GPU
// raises readyEvent to i + 1 once the work before step i has completed, and
// the runner raises ranEvent to i + 1 once step i ran or was skipped, which
// the work after it waits for. A shared event holds the value written last,
// and a GPU signal can land after a later value the CPU wrote to the same
// event (M5 Max, macOS 27: about once in a million steps), which puts it back
// and holds the work waiting for the CPU's value until Metal fails it after 5
// s ("Caused GPU Timeout Error"). Past ranEvent of a step that keeps the GPU
// awake the runner raises the backend's release counter to the step's value,
// which ends the GPU's spin through it (host_step_wait), and then runs the
// step's `then` once its work returned. Each step runs unless the command
// buffer before it failed or an earlier step of its command did not run or
// threw (halted); the first step that throws names the command's failure, and
// a `then` that throws marks the backend unhealthy (EventStep). The runner
// notes when it took each step up and when its work returned, which the
// command's completion reports (timed) against the GPU times of the buffers
// before and after the step, and each is the command's progress for the
// watchdog (CommandWatchdog).
struct HostSteps {
    struct Step {
        uint64_t ready = 0;
        std::function<void()> work;
        std::function<void(const HostStepTiming &)> timed;
        std::function<void()> then;
        __weak id<MTLCommandBuffer> before = nil;
        __weak id<MTLCommandBuffer> after = nil;
        // AwakeClock seconds, zero while the step has not run.
        double pickup = 0.0;
        double done = 0.0;
        // The release counter's value past the step, when the GPU spins
        // through it.
        std::optional<uint32_t> release;
    };
    __strong id<MTLSharedEvent> readyEvent = nil, ranEvent = nil;
    std::shared_ptr<BackendAsyncState> backend;
    // The command's submission (BackendAsyncState::beginSubmission).
    uint64_t sequence = 0;
    // The spin's release buffer (HostStepSpin), once a step spins.
    __strong id<MTLBuffer> releases = nil;
    // A deque, so that the runner holds on to a step while the submission
    // appends the next.
    std::deque<Step> steps;
    std::mutex mutex;
    std::string failure;
    // Whether report() handed the round trips on: a command whose late
    // callback the watchdog recovered finishes twice.
    bool reported = false;
    // Whether a step did not run or threw, after which the runner runs none
    // of the command's steps (the runner's alone).
    bool halted = false;

    void fail(std::string message) {
        std::lock_guard lock(mutex);
        if (failure.empty()) failure = std::move(message);
    }
    [[nodiscard]] std::string firstFailure() {
        std::lock_guard lock(mutex);
        return failure;
    }
    void ran(Step &step, double pickup, double done) {
        std::lock_guard lock(mutex);
        step.pickup = pickup;
        step.done = done;
    }
    // Hands each step that ran its round trip, once every buffer of the
    // command completed, and returns how long the command's GPU work waited
    // on them (CommandTiming::hostSeconds).
    double report() {
        std::lock_guard lock(mutex);
        if (reported) return 0.0;
        reported = true;
        double waited = 0.0;
        for (const Step &step : steps) {
            id<MTLCommandBuffer> before = step.before, after = step.after;
            if (!step.done || !before || !after) continue;
            waited += std::max(0.0, after.GPUStartTime - before.GPUEndTime);
            if (!step.timed) continue;
            HostStepTiming timing;
            timing.pickupSeconds = std::max(0.0, step.pickup - before.GPUEndTime);
            timing.workSeconds = step.done - step.pickup;
            timing.resumeSeconds = std::max(0.0, after.GPUStartTime - step.done);
            step.timed(timing);
        }
        return waited;
    }
    // A failed command's account of the steps that ran: how many, the longest
    // work, and the longest pickup (from the end of the GPU work before a
    // step to its start, which a runner held up by earlier work lengthens),
    // each with its step, counted from 1; empty when none ran.
    std::string longest() {
        std::lock_guard lock(mutex);
        double work = 0.0, pickup = 0.0;
        size_t ran = 0, workStep = 0, pickupStep = 0;
        for (size_t index = 0; index < steps.size(); ++index) {
            const Step &step = steps[index];
            if (!step.done) continue;
            ++ran;
            if (!workStep || step.done - step.pickup > work) {
                work = step.done - step.pickup;
                workStep = index + 1;
            }
            id<MTLCommandBuffer> before = step.before;
            const double ended = before ? before.GPUEndTime : 0.0;
            if (ended > 0.0 && (!pickupStep || step.pickup - ended > pickup)) {
                pickup = step.pickup - ended;
                pickupStep = index + 1;
            }
        }
        if (!ran) return {};
        std::ostringstream text;
        text << std::fixed << std::setprecision(3) << " (host steps: " << ran << " of " << steps.size()
             << " ran; the longest worked " << work << " s, step " << workStep;
        if (pickupStep) text << "; the longest pickup " << pickup << " s, step " << pickupStep;
        text << ')';
        return text.str();
    }
};

// Runs the host steps of committed command buffers in order, on a thread of
// its own: for each step it waits for the step's event to reach its value, runs
// the step and raises the event, then the release counter, past it. The
// value shows 15-40 us after the GPU ended the buffer before the step; the
// runner spins on it for up to kHostStepSpin, longer than the GPU work
// between two decode steps (about 1 ms), so it takes a step up as soon as the
// value shows, and past that blocks on the event (long prefill work), which
// wakes it 30-60 us later: at most 1% of a step behind more than 5 ms of GPU
// work. Streamed decode runs 4% faster than with a runner that blocks at once
// (M5 Max, ISTA Q2_0 with 16G of experts: pickup 26 against 70 us), for
// about half a core while a streamed command runs; waking through
// MTLSharedEventListener took about 0.3 ms. Once stopping it no longer waits:
// a step whose work before it has completed still runs, and the others are
// raised without running, so their commands drain; it waits for the work of a
// step that is running, which nothing can interrupt.
class HostStepRunner final {
public:
    HostStepRunner() : thread_([this] { run(); }) {}
    ~HostStepRunner() {
        {
            std::lock_guard lock(mutex_);
            stopping_ = true;
        }
        queued_.notify_all();
        thread_.join();
    }
    HostStepRunner(const HostStepRunner &) = delete;
    HostStepRunner &operator=(const HostStepRunner &) = delete;

    // Queues `step` of `steps` once the buffer before it is committed.
    void add(std::shared_ptr<HostSteps> steps, HostSteps::Step &step) {
        {
            std::lock_guard lock(mutex_);
            queue_.push_back({std::move(steps), &step});
        }
        queued_.notify_one();
    }

private:
    static constexpr auto kHostStepSpin = std::chrono::milliseconds(0);
    // How often a blocked runner looks whether it is stopping.
    static constexpr uint64_t kStopCheckMilliseconds = 10;

    // Whether `event` reached `value`, which `before` signals, before the
    // runner was stopped. A buffer that fails may end without its signal, so
    // the wait also ends at its failure.
    bool reached(id<MTLSharedEvent> event, uint64_t value, id<MTLCommandBuffer> before) const {
        const auto ended = [&] { return stopping_ || before.status == MTLCommandBufferStatusError; };
        const auto spinEnd = AwakeClock::now() + kHostStepSpin;
        while (event.signaledValue < value) {
            if (ended()) return false;
            if (AwakeClock::now() < spinEnd) continue;
            while (![event waitUntilSignaledValue:value timeoutMS:kStopCheckMilliseconds])
                if (ended()) return false;
            return true;
        }
        return true;
    }

    void run() {
        pthread_set_qos_class_self_np(QOS_CLASS_USER_INTERACTIVE, 0);
        for (;;) {
            Queued queued;
            {
                std::unique_lock lock(mutex_);
                queued_.wait(lock, [&] { return stopping_ || !queue_.empty(); });
                if (queue_.empty()) return;
                queued = std::move(queue_.front());
                queue_.pop_front();
            }
            @autoreleasepool {
                HostSteps &steps = *queued.steps;
                HostSteps::Step &step = *queued.step;
                id<MTLCommandBuffer> before = step.before;
                bool worked = false;
                std::optional<double> returned;
                // A halted command's step still waits for the work before
                // it, which the event's value then follows.
                const bool ready = before && reached(steps.readyEvent, step.ready, before) &&
                                   before.status != MTLCommandBufferStatusError;
                if (ready && !steps.halted) {
                    const double pickup = awakeSeconds();
                    steps.backend->progressSubmission(steps.sequence, pickup);
                    try {
                        step.work();
                        worked = true;
                    } catch (const std::exception &error) {
                        steps.fail(std::string("host step failed: ") + error.what());
                    } catch (...) {
                        steps.fail("host step failed");
                    }
                    returned = awakeSeconds();
                    steps.ran(step, pickup, *returned);
                } else if (stopping_) {
                    steps.fail("host step not run: the backend stopped");
                }
                if (!worked) steps.halted = true;
                steps.ranEvent.signaledValue = step.ready;
                if (step.release) release(steps.releases, *step.release);
                // The step's return moves the deadline once the GPU went on.
                if (returned) steps.backend->progressSubmission(steps.sequence, *returned);
                if (worked && step.then) {
                    try {
                        step.then();
                    } catch (...) {
                        steps.backend->markUnhealthy("Metal host step's then threw an exception");
                    }
                }
            }
        }
    }

    struct Queued {
        std::shared_ptr<HostSteps> steps;
        HostSteps::Step *step = nullptr;
    };

    std::mutex mutex_;
    std::condition_variable queued_;
    std::deque<Queued> queue_;
    std::atomic<bool> stopping_{false};
    std::thread thread_; // last: it starts once the members it uses exist
};

// The GPU's spin through awake host steps: host_step_wait, and the buffer it
// looks at, whose counter (word 0) the runner raises past each awake step and
// where the spin writes the last release it saw (kHostStepSeenOffset).
struct HostStepSpin {
    __strong id<MTLComputePipelineState> pipeline = nil;
    __strong id<MTLBuffer> releases = nil;
    // The release value of the last spin encoded.
    uint32_t sequence = 0;
};

struct CommandTicket::State {
    std::shared_ptr<BackendAsyncState> backend;
    std::vector<std::shared_ptr<MetalAllocation>> retainedAllocations;
    CommandCompletion completion;
    mutable std::mutex mutex;
    std::condition_variable condition;
    uint64_t sequence = 0;
    CommandTiming timing;
    AwakeClock::time_point wallStart;
    // Command buffers committed before the last one, split at event signals
    // and host steps.
    std::vector<id<MTLCommandBuffer>> leadingCommands;
    std::shared_ptr<HostSteps> hostSteps;
    std::string error;
    bool completed = false;
    bool released = false;

    void finishCommand(id<MTLCommandBuffer> command) {
        auto wallEnd = AwakeClock::now();
        CommandTiming timing;
        const double gpuStart = leadingCommands.empty()
            ? command.GPUStartTime : leadingCommands.front().GPUStartTime;
        timing.gpuSeconds = command.GPUEndTime - gpuStart;
        if (!std::isfinite(timing.gpuSeconds) || timing.gpuSeconds < 0.0) {
            timing.gpuSeconds = 0.0;
        }
        timing.wallSeconds =
            std::chrono::duration<double>(wallEnd - wallStart).count();

        std::string error;
        // The first buffer that failed names the error: the buffers after a
        // failed one still run, as its signal is delivered (EventStep). A
        // host step that threw comes first: it ran only after the buffers
        // before it succeeded, and the work after it may then fail on what
        // it left.
        id<MTLCommandBuffer> failed =
            command.status != MTLCommandBufferStatusCompleted ? command : nil;
        for (id<MTLCommandBuffer> earlier : leadingCommands) {
            if (earlier.status == MTLCommandBufferStatusError) {
                failed = earlier;
                break;
            }
        }
        const std::string host = hostSteps ? hostSteps->firstFailure() : std::string();
        if (failed || !host.empty()) {
            std::ostringstream message;
            message << "Metal command " << sequence << " failed";
            if (!host.empty()) message << ": " << host;
            if (failed && !host.empty()) message << "; then a command buffer failed";
            if (failed && failed.error) {
                message << ": " << errorDescription(failed.error);
            }
            if (hostSteps) message << hostSteps->longest();
            error = message.str();
        }
        if (hostSteps && error.empty()) {
            try {
                timing.hostSeconds = hostSteps->report();
            } catch (...) {
                backend->markUnhealthy("Metal host step timing callback threw an exception");
            }
        }

        finish(timing, std::move(error));
    }

    void finish(CommandTiming result, std::string failure) {
        CommandCompletion notify;
        {
            std::lock_guard lock(mutex);
            // Host recovery, late callbacks, and discarded commands all share
            // this completion path; only the first result may publish or notify.
            if (completed) return;
            backend->completeSubmission(sequence);
            if (!failure.empty()) backend->markUnhealthy(failure);
            timing = result;
            error = std::move(failure);
            completed = true;
            notify = completion;
        }
        if (notify) {
            try {
                notify();
            } catch (...) {
                backend->markUnhealthy(
                    "Metal completion callback threw an exception");
            }
        }
        condition.notify_all();
    }

    void release() noexcept {
        bool shouldRelease = false;
        {
            std::lock_guard lock(mutex);
            if (!released) {
                released = true;
                retainedAllocations.clear();
                shouldRelease = true;
            }
        }
        if (shouldRelease && backend) {
            // Refresh the cached device telemetry, which status reports, on
            // the consuming thread after GPU completion; admission samples
            // its own (refreshMemoryStats).
            if (backend->healthy.load(std::memory_order_acquire))
                backend->sampleDeviceMemory();
            backend->releaseSubmission(sequence);
        }
    }

    // Waits for the command in kTicketWaitSlice slices. Between them, outside
    // `mutex` (the watchdog may finish this ticket through finishCommand), it
    // asks the backend whether to stop, and with honorShutdown also whether
    // the process is shutting down. False when the backend gave up on a
    // command that never completed: the GPU may still use the retained
    // allocations, which the command's completion handler keeps alive with
    // this state.
    [[nodiscard]] bool awaitCompletion(bool honorShutdown) noexcept {
        std::unique_lock lock(mutex);
        while (!condition.wait_until(lock, AwakeClock::now() + kTicketWaitSlice,
                                     [this] { return completed; })) {
            lock.unlock();
            const bool abandoned = backend->commandAbandoned();
            const bool interrupted =
                !abandoned && honorShutdown && backend->waitInterrupted();
            lock.lock();
            if (completed) break;
            // A shutdown gives the command up only here, where the lock shows
            // it unfinished: one that completed meanwhile leaves the backend
            // healthy.
            if (interrupted) backend->markUnhealthy(shutdownReason());
            if (abandoned || interrupted) return false;
        }
        return true;
    }

    // Why the backend is unhealthy once a shutdown gave this command up.
    [[nodiscard]] std::string shutdownReason() const noexcept {
        std::string reason = "shutdown requested while waiting for a Metal command";
        try {
            reason = "shutdown requested while waiting for Metal command " +
                     std::to_string(sequence);
        } catch (const std::bad_alloc &) {
        }
        return reason;
    }

    // An abandoned command keeps its allocations until its completion
    // handler lets go of this state; the unhealthy backend admits no more.
    // A shutdown does not give up this wait: teardown waits for the command,
    // as long as the watchdog lets it.
    void abandon() noexcept {
        if (awaitCompletion(false)) release();
    }
};

struct MetalBackend::Impl {
    explicit Impl(double commandTimeoutSeconds)
        : asyncState(std::make_shared<BackendAsyncState>(commandTimeoutSeconds)) {}

    // One dispatch of a command, validated and resolved to its pipeline.
    struct PreparedDispatch {
        const ComputeDispatch *source = nullptr;
        MTLSize groups{};
        MTLSize threads{};
        uint64_t threadCount = 0;
        // The argument table entries its buffers take, one bit each.
        uint32_t bufferIndices = 0;
        __strong id<MTLComputePipelineState> pipeline = nil;
    };

    // A command as submission encodes it: its dispatches and every
    // allocation they bind, which its ticket retains.
    struct PreparedCommand {
        std::vector<PreparedDispatch> dispatches;
        std::vector<std::shared_ptr<MetalAllocation>> retainedAllocations;
    };

    std::function<void()> operationGuard;

#ifdef SPLASH_BACKEND_INSTRUMENTATION
    bool dispatchProfiling = false;
    std::vector<DispatchTiming> dispatchProfile;
    uint64_t lastCommandBuffers = 0;
#endif
    __strong id<MTLDevice> device = nil;
    __strong id<MTLCommandQueue> queue = nil;
    // Runs the notify() callbacks of the backend's shared events, on a
    // serial dispatch queue.
    __strong MTLSharedEventListener *eventListener = nil;
    // Allocations hold it weakly: they may outlive the backend.
    std::shared_ptr<Residency> residency;
    __strong id<MTLLibrary> library = nil;
    // Looked up for every dispatch when its command is prepared, which the
    // GPU may be waiting for; a hit allocates nothing. Used only by the
    // submitting thread.
    std::unordered_map<std::string, id<MTLComputePipelineState>,
                       PipelineNameHash, std::equal_to<>>
        pipelines;

    DeviceCapabilities capabilities;
    std::shared_ptr<AllocationAccounting> accounting =
        std::make_shared<AllocationAccounting>();
    std::shared_ptr<BackendAsyncState> asyncState;

    void sampleDeviceMemory() const noexcept {
        asyncState->sampleDeviceMemory();
    }

    void ensureHealthy() const {
        asyncState->ensureHealthy();
    }

    void markUnhealthy(std::string reason) {
        asyncState->markUnhealthy(std::move(reason));
    }

    id<MTLBuffer> newBuffer(uint64_t bytes, BufferStorage storage,
                            NSString *label) {
        MTLResourceOptions options = storage == BufferStorage::Shared
            ? MTLResourceStorageModeShared : MTLResourceStorageModePrivate;
        id<MTLBuffer> buffer = [device newBufferWithLength:bytes
                                                   options:options];
        if (!buffer)
            throw MetalAllocationError("Metal buffer allocation failed");
        if (label) buffer.label = label;
        return buffer;
    }

    // The base allocation of a buffer, which must be a whole buffer of this
    // backend.
    MetalAllocation &baseAllocation(const MetalBuffer &buffer) const {
        if (!buffer.impl_ ||
            buffer.impl_->allocation->accounting.get() != accounting.get())
            throw MetalBackendError("Metal buffer is not a buffer of this backend");
        MetalAllocation &allocation = *buffer.impl_->allocation;
        if (buffer.impl_->offsetBytes ||
            buffer.impl_->lengthBytes != allocation.length)
            throw MetalBackendError("a view's memory is its base buffer's");
        return allocation;
    }

    id<MTLComputePipelineState> pipeline(std::string_view name) {
        if (name.empty()) {
            throw MetalBackendError("Metal pipeline name must not be empty");
        }
        if (const auto cached = pipelines.find(name); cached != pipelines.end())
            return cached->second;
        id<MTLComputePipelineState> result = newPipeline(library, name);
        pipelines.emplace(name, result);
        sampleDeviceMemory();
        return result;
    }

    id<MTLComputePipelineState> newPipeline(id<MTLLibrary> source, std::string_view name) {
        NSString *key = checkedNSString(name, "pipeline name");
        id<MTLFunction> function = [source newFunctionWithName:key];
        if (!function) {
            throw MetalBackendError(
                "missing Metal function: " + std::string(name));
        }
        NSError *error = nil;
        id<MTLComputePipelineState> result =
            [device newComputePipelineStateWithFunction:function error:&error];
        if (!result) {
            throw MetalBackendError(
                "unable to create Metal pipeline " + std::string(name) +
                ": " + errorDescription(error));
        }
        return result;
    }

    PreparedCommand prepare(std::span<const ComputeDispatch> dispatches) {
        if (dispatches.empty()) {
            throw MetalBackendError("Metal command must contain a dispatch");
        }
        PreparedCommand command;
        command.dispatches.reserve(dispatches.size());
        size_t bindings = 0;
        for (const ComputeDispatch &dispatch : dispatches) {
            PreparedDispatch item;
            item.source = &dispatch;
            item.groups = metalSize(dispatch.threadgroups, "threadgroups");
            item.threads = metalSize(
                dispatch.threadsPerThreadgroup, "threadsPerThreadgroup");
            if (multiplyOverflows(dispatch.threadsPerThreadgroup.x,
                                  dispatch.threadsPerThreadgroup.y) ||
                multiplyOverflows(dispatch.threadsPerThreadgroup.x *
                                      dispatch.threadsPerThreadgroup.y,
                                  dispatch.threadsPerThreadgroup.z)) {
                throw MetalBackendError("threadsPerThreadgroup size overflows");
            }
            item.threadCount = dispatch.threadsPerThreadgroup.x *
                dispatch.threadsPerThreadgroup.y *
                dispatch.threadsPerThreadgroup.z;

            // Each binding takes its own entry of the argument table.
            uint32_t indices = 0;
            const auto claim = [&](uint32_t index) {
                if (index >= kBufferArgumentEntries) {
                    throw MetalBackendError(
                        "compute binding index exceeds the argument table");
                }
                if (indices & (uint32_t{1} << index)) {
                    throw MetalBackendError("duplicate compute binding index");
                }
                indices |= uint32_t{1} << index;
            };
            for (const BufferBinding &binding : dispatch.buffers) {
                if (!binding.buffer.impl_) {
                    std::ostringstream message;
                    message << "compute dispatch '" << dispatch.pipelineName
                            << "' contains an empty buffer at index "
                            << binding.index;
                    throw MetalBackendError(message.str());
                }
                if (binding.buffer.impl_->allocation->accounting.get() !=
                    accounting.get()) {
                    throw MetalBackendError(
                        "compute dispatch buffer belongs to another backend");
                }
                if (!binding.buffer.impl_->allocation->buffer) {
                    std::ostringstream message;
                    message << "compute dispatch '" << dispatch.pipelineName
                            << "' binds released memory at index "
                            << binding.index;
                    throw MetalBackendError(message.str());
                }
                claim(binding.index);
                item.bufferIndices |= uint32_t{1} << binding.index;
            }
            for (const BytesBinding &binding : dispatch.bytes) {
                if (!binding.data || !binding.sizeBytes) {
                    throw MetalBackendError("compute byte binding is empty");
                }
                claim(binding.index);
            }
            // Metal reads an indirect grid's three counts at a multiple of 4
            // bytes, counted from the allocation's start, not the view's.
            const IndirectGrid &grid = dispatch.indirectThreadgroups;
            if (grid.buffer) {
                const MetalBuffer::Impl &arguments = *grid.buffer.impl_;
                if (arguments.allocation->accounting.get() != accounting.get() ||
                    !arguments.allocation->buffer ||
                    (arguments.offsetBytes + grid.offsetBytes) %
                        sizeof(uint32_t) ||
                    grid.offsetBytes > arguments.lengthBytes ||
                    arguments.lengthBytes - grid.offsetBytes <
                        3 * sizeof(uint32_t)) {
                    throw MetalBackendError(
                        "compute dispatch '" + dispatch.pipelineName +
                        "' reads its grid outside a buffer of this backend");
                }
                ++bindings;
            }
            bindings += dispatch.buffers.size();
            command.dispatches.push_back(item);
        }

        for (PreparedDispatch &item : command.dispatches) {
            item.pipeline = pipeline(item.source->pipelineName);
            if (item.threadCount >
                item.pipeline.maxTotalThreadsPerThreadgroup) {
                throw MetalBackendError(
                    "threadsPerThreadgroup exceeds pipeline capability");
            }
        }

        // Each allocation the command binds, once.
        std::vector<const std::shared_ptr<MetalAllocation> *> bound;
        bound.reserve(bindings);
        for (const ComputeDispatch &dispatch : dispatches) {
            for (const BufferBinding &binding : dispatch.buffers)
                bound.push_back(&binding.buffer.impl_->allocation);
            if (dispatch.indirectThreadgroups.buffer)
                bound.push_back(
                    &dispatch.indirectThreadgroups.buffer.impl_->allocation);
        }
        const auto allocation =
            [](const std::shared_ptr<MetalAllocation> *owner) {
                return owner->get();
            };
        std::ranges::sort(bound, {}, allocation);
        const auto repeated = std::ranges::unique(bound, {}, allocation);
        bound.erase(repeated.begin(), repeated.end());
        command.retainedAllocations.reserve(bound.size());
        for (const std::shared_ptr<MetalAllocation> *owner : bound)
            command.retainedAllocations.push_back(*owner);
        return command;
    }

    // Ends `command` with host step `step` (EventStep::Kind::Host) of a
    // command's `steps`, creating them with its first, appends it (and the
    // buffer that spins through an awake step) to `leading` and commits it,
    // hands the step to the runner (HostStepRunner), and returns the command
    // buffer after them, which waits for the step: the GPU raises readyEvent
    // to i + 1 once the work before step i has completed (a failure skips the
    // step); the runner then runs the step and raises ranEvent to i + 1, which
    // the buffer after it waits for (HostSteps). Between the two, for an awake
    // step, a buffer of one host_step_wait spins until the runner raises the
    // release counter past the step, which keeps the GPU awake: a GPU idle
    // through a step starts the work after it 75-80 us after the release (M5
    // Max, M5 Pro; M3 Max 100 us), and after 3-10 ms of idling 0.4-0.7 ms
    // after it, at low clocks for 2-3 ms more; awake it starts in 12-22 us
    // (M3 Max 70-80 us). The spin orders nothing: the work after the step
    // starts in a buffer of its own that waits for ranEvent, and only a
    // buffer's start makes what the CPU wrote visible (a wait inside a buffer
    // that the GPU reaches after the signal leaves stale lines). An awake step
    // spins only once the spin was seen to end at its release
    // (checkHostStepSpin).
    template <class Fail>
    id<MTLCommandBuffer> encodeHostStep(id<MTLCommandBuffer> command, std::vector<id<MTLCommandBuffer>> &leading,
                                        std::shared_ptr<HostSteps> &steps, uint64_t sequence, const EventStep &step,
                                        Fail &&failEncoding) {
        if (!steps) {
            steps = std::make_shared<HostSteps>();
            steps->backend = asyncState;
            steps->sequence = sequence;
            steps->readyEvent = [device newSharedEvent];
            steps->ranEvent = [device newSharedEvent];
            if (!steps->readyEvent || !steps->ranEvent) failEncoding("unable to create Metal shared event");
        }
        const uint64_t ready = steps->steps.size() + 1;
        [command encodeSignalEvent:steps->readyEvent value:ready];
        leading.push_back(command);
        std::optional<uint32_t> released;
        if (step.gpu == HostStepGpu::Awake && hostStepSpin) {
            id<MTLCommandBuffer> awake = [queue commandBuffer];
            if (!awake) failEncoding("unable to create Metal command buffer");
            released = encodeSpin(*hostStepSpin, awake, failEncoding);
            steps->releases = hostStepSpin->releases;
            leading.push_back(awake);
        }
        id<MTLCommandBuffer> next = [queue commandBuffer];
        if (!next) failEncoding("unable to create Metal command buffer");
        [next encodeWaitForEvent:steps->ranEvent value:ready];
        steps->steps.push_back({ready, step.work, step.timed, step.then, command, next, 0.0, 0.0, released});
        for (auto buffer = leading.end() - (released ? 2 : 1); buffer != leading.end(); ++buffer)
            [*buffer commit];
        hostStepRunner->add(steps, steps->steps.back());
        return next;
    }

    // Encodes into `buffer` one host_step_wait thread, which spins until the
    // release counter reaches the spin's next release value, and returns that
    // value.
    template <class Fail>
    static uint32_t encodeSpin(HostStepSpin &spin, id<MTLCommandBuffer> buffer, Fail &&fail) {
        id<MTLComputeCommandEncoder> encoder = [buffer computeCommandEncoder];
        if (!encoder) fail("unable to create Metal compute encoder");
        const uint32_t release[2] = {++spin.sequence, kHostStepWaitLoads};
        [encoder setComputePipelineState:spin.pipeline];
        [encoder setBuffer:spin.releases offset:0 atIndex:0];
        [encoder setBytes:release length:sizeof(release) atIndex:1];
        [encoder setBuffer:spin.releases offset:kHostStepSeenOffset atIndex:2];
        [encoder dispatchThreadgroups:MTLSizeMake(1, 1, 1) threadsPerThreadgroup:MTLSizeMake(1, 1, 1)];
        [encoder endEncoding];
        return release[0];
    }

    // How a check of the spin ended (checkHostStepSpin): a spin ended at its
    // release, or ran past it, or every spin started after its release.
    enum class SpinCheck : uint8_t { Seen, Unseen, Late };

    // Runs spins on a queue of their own, each released while it spins, as
    // checkHostStepSpin describes.
    SpinCheck runSpinCheck(HostStepSpin &spin) {
        const auto fail = [](std::string message) { throw MetalBackendError(std::move(message)); };
        id<MTLCommandQueue> checkQueue = [device newCommandQueue];
        if (!checkQueue) fail("unable to create Metal command queue");
        const auto *seen = reinterpret_cast<const uint32_t *>(
            static_cast<const uint8_t *>(spin.releases.contents) + kHostStepSeenOffset);
        // A spin that starts after its release sees it at its first load
        // and shows nothing, so a late one runs again, released later.
        for (const auto delay : {std::chrono::milliseconds(2), std::chrono::milliseconds(20),
                                 std::chrono::milliseconds(100)}) {
            id<MTLCommandBuffer> buffer = [checkQueue commandBuffer];
            if (!buffer) fail("unable to create Metal command buffer");
            const uint32_t value = encodeSpin(spin, buffer, fail);
            [buffer commit];
            std::this_thread::sleep_for(delay);
            const double released = awakeSeconds();
            release(spin.releases, value);
            [buffer waitUntilCompleted];
            if (buffer.status != MTLCommandBufferStatusCompleted)
                fail("a GPU spin failed: " + errorDescription(buffer.error));
            if (buffer.GPUStartTime >= released) continue;
            // A spin that saw its release at its first load proves nothing:
            // a release that came before that load shows to any load.
            if (seen[0] == value && seen[1] == 0) continue;
            return seen[0] == value ? SpinCheck::Seen : SpinCheck::Unseen;
        }
        return SpinCheck::Late;
    }

    // Whether a GPU thread spinning through an awake host step sees the CPU
    // raise the release counter. host_step_wait looks through a memory scope
    // that Metal's public headers leave out (host_step.metal), and should a
    // Metal release stop honoring it, the work after every awake step would
    // wait out the spin's bound, 60 ms or more. So before the first command
    // with an awake step is encoded, the backend builds the spin
    // (HostStepSpin), and one spin runs on a queue of its own and is released
    // 2 ms after its commit, while it spins: it must end at that release, not
    // at its bound. A spin that started only after its release shows
    // nothing, and runs again, released 20 and then 100 ms after its commit.
    // Once a spin ended at its release, awake steps spin. If one ran past its
    // release, or the spin cannot be built or run, awake steps run as plain
    // ones (encodeHostStep), which only gives up the spin's head start, and a
    // warning says so. If every spin started late, the GPU busy with other
    // work, the check decides nothing: awake steps run as plain ones for
    // kHostStepSpinRecheck, and the first command with one after that checks
    // again.
    void checkHostStepSpin() {
        @autoreleasepool {
            try {
                HostStepSpin spin = newHostStepSpin();
                switch (runSpinCheck(spin)) {
                case SpinCheck::Seen:
                    hostStepSpin = std::move(spin);
                    nextSpinCheck = AwakeClock::time_point::max();
                    return;
                case SpinCheck::Unseen:
                    logWarning("Metal host steps run without keeping the GPU awake: a GPU spin did not see the "
                               "CPU's release (host_step_wait), so the work after each step starts later");
                    nextSpinCheck = AwakeClock::time_point::max();
                    return;
                case SpinCheck::Late:
                    nextSpinCheck = AwakeClock::now() + kHostStepSpinRecheck;
                    return;
                }
            } catch (const std::exception &error) {
                logWarning("Metal host steps run without keeping the GPU awake (", error.what(),
                           "), so the work after each step starts later");
                nextSpinCheck = AwakeClock::time_point::max();
            }
        }
    }

    // The spin of awake host steps, from host_step_wait of the library beside
    // the backend's, with a release buffer whose counter starts at zero.
    HostStepSpin newHostStepSpin() {
        HostStepSpin spin;
        spin.pipeline = newPipeline(loadLibrary(device, hostStepLibraryPath), "host_step_wait");
        spin.releases = newBuffer(kHostStepSeenOffset + 2 * sizeof(uint32_t), BufferStorage::Shared,
                                  @"host-step releases");
        std::memset(spin.releases.contents, 0, spin.releases.length);
        return spin;
    }

    // Encodes and commits prepared dispatches and the event steps between
    // them; the ticket retains `retained` until it is consumed.
    CommandTicket commit(std::span<const PreparedDispatch> dispatches,
                         std::span<const EventStep> events,
                         std::vector<std::shared_ptr<MetalAllocation>> retained,
                         CommandCompletion completion) {
        if (!hostStepSpin && AwakeClock::now() >= nextSpinCheck &&
            std::ranges::any_of(events, [](const EventStep &step) { return step.gpu == HostStepGpu::Awake; }))
            checkHostStepSpin();
        // The runner starts with the first command that has a host step,
        // before the submission: one that cannot start leaves nothing held.
        if (!hostStepRunner &&
            std::ranges::any_of(events, [](const EventStep &step) { return step.kind == EventStep::Kind::Host; }))
            hostStepRunner = std::make_unique<HostStepRunner>();
        auto ticketState = std::make_shared<CommandTicket::State>();
        ticketState->backend = asyncState;
        ticketState->completion = std::move(completion);
        ticketState->retainedAllocations = std::move(retained);
        ticketState->sequence =
            asyncState->beginSubmission(dispatches.size());

        auto failEncoding = [](std::string message) { throw MetalBackendError(std::move(message)); };

        auto wallStart = AwakeClock::now();
        // The buffers before the last commit as their encoding ends, so the
        // GPU starts the command's work while the rest is still encoded.
        residency->use();
        // Metal may autorelease the command and its encoder, and the serving
        // loop's pool never drains, so their temporary ownership ends with
        // this submission (under the validation layer an autoreleased
        // command holds every member of its queue's residency set). The
        // command retains everything the GPU still needs.
        @autoreleasepool {
            // The buffers before `command`, each ended by an event signal or
            // a host step.
            std::vector<id<MTLCommandBuffer>> leading;
            // Any failure while encoding, such as Metal creating no buffer or
            // encoder, marks the backend unhealthy. The buffers already
            // committed run on, with the host steps after them, so the backend
            // keeps their command's state, and with it its allocations.
            try {
                id<MTLCommandBuffer> command = [queue commandBuffer];
                if (!command) {
                    failEncoding("unable to create Metal command buffer");
                }
                ticketState->wallStart = wallStart;
                id<MTLComputeCommandEncoder> encoder = nil;
                // Encodes the event steps that follow the first `encoded`
                // dispatches.
                auto step = events.begin();
                const auto encodeSteps = [&](size_t encoded) {
                    for (; step != events.end() && step->before == encoded; ++step) {
                        if (encoder) {
                            [encoder endEncoding];
                            encoder = nil;
                        }
                        if (step->kind == EventStep::Kind::Host) {
                            command = encodeHostStep(command, leading, ticketState->hostSteps,
                                                     ticketState->sequence, *step, failEncoding);
                            continue;
                        }
                        id<MTLSharedEvent> event =
                            (__bridge id<MTLSharedEvent>)step->event.nativeHandle();
                        if (step->kind == EventStep::Kind::Wait) {
                            [command encodeWaitForEvent:event value:step->value];
                            continue;
                        }
                        [command encodeSignalEvent:event value:step->value];
                        // A buffer that fails may end without its signal; the
                        // work after it, waiting on an agent that waits on the
                        // signal, would then stall until a timeout ends it. The
                        // CPU delivers the signal instead, so the command ends
                        // with the failure at once.
                        const SharedEvent signaled = step->event;
                        const uint64_t value = step->value;
                        [command addCompletedHandler:^(id<MTLCommandBuffer> ended) {
                            if (ended.status == MTLCommandBufferStatusError)
                                signaled.signal(value);
                        }];
                        leading.push_back(command);
                        [command commit];
                        command = [queue commandBuffer];
                        if (!command) {
                            failEncoding("unable to create Metal command buffer");
                        }
                    }
                };
                // Indexed by argument table entry. The ticket and the dispatches
                // keep the buffers alive.
                __unsafe_unretained id<MTLBuffer> buffers[kBufferArgumentEntries];
                NSUInteger offsets[kBufferArgumentEntries];
                for (size_t index = 0; index < dispatches.size(); ++index) {
                    encodeSteps(index);
                    const PreparedDispatch &item = dispatches[index];
                    const ComputeDispatch &dispatch = *item.source;
                    if (!encoder) {
                        encoder = [command computeCommandEncoder];
                        if (!encoder) {
                            failEncoding("unable to create Metal compute encoder");
                        }
                    }
                    [encoder setComputePipelineState:item.pipeline];
                    for (const BufferBinding &binding : dispatch.buffers) {
                        const MetalBuffer::Impl &buffer = *binding.buffer.impl_;
                        buffers[binding.index] = buffer.allocation->buffer;
                        offsets[binding.index] = buffer.offsetBytes;
                    }
                    // One call per run of consecutive entries: a command graph's
                    // dispatch binds a single run.
                    for (uint32_t unbound = item.bufferIndices; unbound;) {
                        const uint32_t first = std::countr_zero(unbound);
                        const uint32_t count = std::countr_one(unbound >> first);
                        [encoder setBuffers:buffers + first
                                    offsets:offsets + first
                                  withRange:NSMakeRange(first, count)];
                        unbound &= ~(((uint32_t{1} << count) - 1) << first);
                    }
                    for (const BytesBinding &binding : dispatch.bytes) {
                        [encoder setBytes:binding.data
                                   length:binding.sizeBytes
                                  atIndex:binding.index];
                    }
                    const IndirectGrid &grid = dispatch.indirectThreadgroups;
                    if (grid.buffer) {
                        const MetalBuffer::Impl &arguments = *grid.buffer.impl_;
                        [encoder
                            dispatchThreadgroupsWithIndirectBuffer:
                                arguments.allocation->buffer
                                              indirectBufferOffset:
                                arguments.offsetBytes + grid.offsetBytes
                                             threadsPerThreadgroup:item.threads];
                    } else {
                        [encoder dispatchThreadgroups:item.groups
                                 threadsPerThreadgroup:item.threads];
                    }
                }
                encodeSteps(dispatches.size());
                if (encoder) [encoder endEncoding];
                ticketState->leadingCommands = leading;

                // Driver callbacks only complete the ticket. Device-wide memory
                // telemetry is sampled on the host when consuming the result. The
                // handler holds the ticket's state strongly: once a waiter gives
                // up on the command, it keeps the retained allocations until the
                // GPU ends.
                [command addCompletedHandler:^(id<MTLCommandBuffer> completed) {
                    ticketState->finishCommand(completed);
                }];
                asyncState->commitSubmission(ticketState->sequence, command,
                    [weakTicket = std::weak_ptr(ticketState)](
                        id<MTLCommandBuffer> completed) {
                        if (auto ticket = weakTicket.lock())
                            ticket->finishCommand(completed);
                    });
            } catch (...) {
                std::string reason = "Metal command encoding failed";
                try {
                    throw;
                } catch (const std::exception &error) {
                    reason += std::string(": ") + error.what();
                } catch (...) {
                }
                markUnhealthy(std::move(reason));
                asyncState->releaseSubmission(ticketState->sequence);
                // The state holds the committed buffers too: a host step's
                // runner reaches the buffer before it only through that.
                if (!leading.empty()) {
                    ticketState->leadingCommands = leading;
                    abandonedCommands.push_back(ticketState);
                }
                throw;
            }
        }
        return CommandTicket(std::move(ticketState));
    }

#ifdef SPLASH_BACKEND_INSTRUMENTATION
    // Commits every dispatch of the command as its own command and waits
    // for it, then hands back an already-completed ticket with the summed
    // timing, so callers observe the usual asynchronous contract.
    // Host steps run between the dispatches, in order, each `then` after its
    // work (EventStep::Kind::Host); a command with other event steps is
    // refused.
    CommandTicket submitProfiled(std::span<const ComputeDispatch> dispatches,
                                 std::span<const EventStep> events,
                                 CommandCompletion completion) {
        if (std::ranges::any_of(events, [](const EventStep &step) { return step.kind != EventStep::Kind::Host; }))
            throw MetalBackendError("dispatch profiling does not replay event steps");
        const PreparedCommand command = prepare(dispatches);
        CommandTiming total;
        auto step = events.begin();
        const auto runSteps = [&](size_t before) {
            for (; step != events.end() && step->before == before; ++step) {
                step->work();
                if (step->then) step->then();
            }
        };
        for (size_t index = 0; index < command.dispatches.size(); ++index) {
            runSteps(index);
            const PreparedDispatch &item = command.dispatches[index];
            const CommandTiming timing =
                commit({&item, 1}, {}, command.retainedAllocations, {}).wait();
            dispatchProfile.push_back(
                {item.source->pipelineName, timing.gpuSeconds});
            total.gpuSeconds += timing.gpuSeconds;
            total.wallSeconds += timing.wallSeconds;
        }
        runSteps(command.dispatches.size());
        auto ticketState = std::make_shared<CommandTicket::State>();
        ticketState->backend = asyncState;
        ticketState->sequence =
            asyncState->beginSubmission(command.dispatches.size());
        ticketState->timing = total;
        ticketState->completed = true;
        if (completion) completion();
        return CommandTicket(std::move(ticketState));
    }
#endif

    // host-step.metallib beside the backend's library (kHostStepLibrary).
    std::string hostStepLibraryPath;
    // The spin of awake host steps, once checked (checkHostStepSpin); until
    // then they run as plain ones.
    std::optional<HostStepSpin> hostStepSpin;
    // When a command with an awake step checks the spin: the first, or one
    // kHostStepSpinRecheck after a check that decided nothing; never once a
    // check decided.
    AwakeClock::time_point nextSpinCheck{};
    // Commands whose encoding failed after their first buffers were
    // committed (commit): those buffers, which these hold, still run on these
    // commands' allocations, with the host steps after them.
    std::vector<std::shared_ptr<CommandTicket::State>> abandonedCommands;
    // Last, so that it stops first, raising the steps it holds.
    std::unique_ptr<HostStepRunner> hostStepRunner;
};

SharedEvent::SharedEvent() = default;
SharedEvent::~SharedEvent() = default;
SharedEvent::SharedEvent(const SharedEvent &) = default;
SharedEvent &SharedEvent::operator=(const SharedEvent &) = default;
SharedEvent::SharedEvent(SharedEvent &&) noexcept = default;
SharedEvent &SharedEvent::operator=(SharedEvent &&) noexcept = default;
SharedEvent::SharedEvent(std::shared_ptr<Impl> impl) : impl_(std::move(impl)) {}

SharedEvent::operator bool() const noexcept { return impl_ && impl_->event; }

void *SharedEvent::nativeHandle() const noexcept {
    return impl_ ? (__bridge void *)impl_->event : nullptr;
}

// Metal ignores a value below the event's, so the write alone raises it.
void SharedEvent::signal(uint64_t value) const noexcept {
    if (*this) impl_->event.signaledValue = value;
}

void SharedEvent::notify(uint64_t value, std::function<void()> callback) const {
    if (!*this) throw MetalBackendError("an empty shared event cannot notify");
    [impl_->event notifyListener:impl_->listener
                         atValue:value
                           block:^(id<MTLSharedEvent>, uint64_t) { callback(); }];
}

MetalBuffer::MetalBuffer() = default;
MetalBuffer::~MetalBuffer() = default;
MetalBuffer::MetalBuffer(const MetalBuffer &) = default;
MetalBuffer &MetalBuffer::operator=(const MetalBuffer &) = default;
MetalBuffer::MetalBuffer(MetalBuffer &&) noexcept = default;
MetalBuffer &MetalBuffer::operator=(MetalBuffer &&) noexcept = default;

MetalBuffer::MetalBuffer(std::shared_ptr<Impl> impl)
    : impl_(std::move(impl)) {}

MetalBuffer::operator bool() const noexcept {
    return impl_ != nullptr;
}

uint64_t MetalBuffer::sizeBytes() const noexcept {
    return impl_ ? impl_->lengthBytes : 0;
}

uint64_t MetalBuffer::allocatedBytes() const noexcept {
    return impl_ ? impl_->allocation->bytes : 0;
}

bool MetalBuffer::sameView(const MetalBuffer &other) const noexcept {
    if (impl_ == other.impl_) return true;
    return impl_ && other.impl_ &&
           impl_->allocation == other.impl_->allocation &&
           impl_->offsetBytes == other.impl_->offsetBytes &&
           impl_->lengthBytes == other.impl_->lengthBytes;
}

BufferStorage MetalBuffer::storage() const noexcept {
    return impl_ ? impl_->allocation->storage : BufferStorage::Shared;
}

void *MetalBuffer::contents() const noexcept {
    if (!impl_ || impl_->allocation->storage != BufferStorage::Shared ||
        !impl_->allocation->buffer) {
        return nullptr;
    }
    return static_cast<uint8_t *>(impl_->allocation->buffer.contents) +
           impl_->offsetBytes;
}

uint64_t MetalBuffer::gpuAddress() const {
    if (impl_ && impl_->allocation->reach != BufferReach::Addressed)
        throw MetalBackendError("only a Metal buffer allocated BufferReach::Addressed has a GPU address");
    if (!impl_ || !impl_->allocation->buffer) return 0;
    return impl_->allocation->buffer.gpuAddress + impl_->offsetBytes;
}

CommandTicket::CommandTicket() = default;

CommandTicket::CommandTicket(std::shared_ptr<State> state)
    : state_(std::move(state)) {}

CommandTicket::~CommandTicket() {
    if (state_) state_->abandon();
}

CommandTicket::CommandTicket(CommandTicket &&) noexcept = default;

CommandTicket &CommandTicket::operator=(CommandTicket &&other) noexcept {
    if (this == &other) return *this;
    if (state_) state_->abandon();
    state_ = std::move(other.state_);
    return *this;
}

bool CommandTicket::ready() const noexcept {
    if (!state_) return false;
    std::lock_guard lock(state_->mutex);
    return state_->completed;
}

CommandTiming CommandTicket::wait() {
    if (!state_) throw MetalBackendError("Metal command ticket is empty");
    if (!state_->awaitCompletion(true)) {
        // Let go first, so that unwinding does not wait again.
        auto backend = state_->backend;
        state_.reset();
        backend->throwUnhealthy();
    }
    CommandTiming timing;
    std::string error;
    {
        std::lock_guard lock(state_->mutex);
        timing = state_->timing;
        error = state_->error;
    }
    state_->release();
    if (!error.empty()) throw MetalBackendError(error);
    return timing;
}

MetalBackend::MetalBackend(std::string metallibPath, double residencyKeepAliveSeconds,
                           double commandTimeoutSeconds)
    : impl_(std::make_unique<Impl>(commandTimeoutSeconds)) {
    @autoreleasepool {
        if (metallibPath.empty()) {
            throw MetalBackendError("metallib path must not be empty");
        }
        if (!(residencyKeepAliveSeconds > 0.0)) {
            throw MetalBackendError("residency keep-alive must be positive");
        }
        impl_->device = MTLCreateSystemDefaultDevice();
        if (!impl_->device) {
            throw MetalBackendError("Metal device unavailable");
        }
        // Check the OS floor before loading Metal resources so an unsupported
        // system reports the version requirement first, in a message that
        // names the device as the device check does.
        readMacosVersion(impl_->capabilities);
        readDeviceCapabilities(impl_->device, impl_->capabilities);
        if (!impl_->capabilities.meetsMinimumMacos()) {
            throw MetalBackendError(*impl_->capabilities.validationMessage());
        }
        impl_->asyncState->device = impl_->device;
        // A command takes one Metal command buffer, and one more per buffer
        // its event steps add (addedBuffers), and creating one waits while
        // the queue's limit of them is outstanding. The buffers a command
        // committed stay outstanding while they wait on its later steps, so
        // the queue holds as many as a command may take: at the default of
        // 64, a 64-layer prefill with a Neural Engine step each would wait on
        // itself.
        impl_->queue = [impl_->device
            newCommandQueueWithMaxCommandBufferCount:kMaximumCommandBuffers];
        if (!impl_->queue) {
            throw MetalBackendError("unable to create Metal command queue");
        }
        impl_->eventListener = [[MTLSharedEventListener alloc]
            initWithDispatchQueue:dispatch_queue_create(
                "splash.metal.events",
                dispatch_queue_attr_make_with_autorelease_frequency(
                    DISPATCH_QUEUE_SERIAL,
                    DISPATCH_AUTORELEASE_FREQUENCY_WORK_ITEM))];

        impl_->library = loadLibrary(impl_->device, metallibPath);
        impl_->hostStepLibraryPath =
            std::filesystem::path(metallibPath).replace_filename(kHostStepLibrary).string();
        // Ending residency dispatches a kernel built here, so no pipeline or
        // driver program is compiled when a keep-alive lapses.
        impl_->residency = std::make_shared<Residency>(
            impl_->device, impl_->queue,
            impl_->newPipeline(impl_->library, Residency::kKickPipeline), residencyKeepAliveSeconds);
    }
    impl_->sampleDeviceMemory();
}

MetalBackend::~MetalBackend() = default;

void MetalBackend::stop() noexcept {
    std::lock_guard lock(impl_->asyncState->gateMutex);
    impl_->asyncState->stopping = true;
}

const DeviceCapabilities &MetalBackend::capabilities() const noexcept {
    return impl_->capabilities;
}

DeviceCapabilities probeDeviceCapabilities() {
    @autoreleasepool {
        DeviceCapabilities capabilities;
        readMacosVersion(capabilities);
        id<MTLDevice> device = MTLCreateSystemDefaultDevice();
        if (!device) throw MetalBackendError("Metal device unavailable");
        readDeviceCapabilities(device, capabilities);
        return capabilities;
    }
}

void MetalBackend::checkOperation() const {
    impl_->ensureHealthy();
    if (impl_->operationGuard) impl_->operationGuard();
}

void MetalBackend::setOperationGuard(std::function<void()> guard) {
    impl_->operationGuard = std::move(guard);
}

void MetalBackend::setWaitInterrupt(std::function<bool()> shuttingDown) {
    impl_->asyncState->waitInterrupt = std::move(shuttingDown);
}

MetalBuffer MetalBackend::allocateBuffer(uint64_t bytes,
                                         BufferStorage storage,
                                         std::string_view label,
                                         BufferReach reach) {
    checkOperation();
    if (!bytes) throw MetalBackendError("Metal buffer size must be positive");
    if (bytes > impl_->capabilities.maxBufferLengthBytes) {
        throw MetalBackendError("Metal buffer exceeds maxBufferLength");
    }
    if (reach == BufferReach::Addressed && storage != BufferStorage::Shared)
        throw MetalBackendError("only a Shared Metal buffer is reached by its address");
    auto allocation = std::make_shared<MetalAllocation>();
    allocation->accounting = impl_->accounting;
    allocation->length = bytes;
    allocation->storage = storage;
    allocation->reach = reach;
    if (!label.empty()) allocation->label = checkedNSString(label, "buffer label");
    allocation->residency = impl_->residency;
    allocation->attach(impl_->newBuffer(bytes, storage, allocation->label));
    impl_->sampleDeviceMemory();
    auto result = std::make_shared<MetalBuffer::Impl>();
    result->lengthBytes = bytes;
    result->allocation = std::move(allocation);
    return MetalBuffer(std::move(result));
}

MetalBuffer MetalBackend::wrapSharedMemory(void *address, uint64_t bytes,
                                           std::shared_ptr<void> owner,
                                           std::string_view label) {
    checkOperation();
    const uint64_t page = static_cast<uint64_t>(getpagesize());
    if (!address || !bytes || !owner ||
        reinterpret_cast<uintptr_t>(address) % page || bytes % page) {
        throw MetalBackendError(
            "wrapped memory needs an owner and whole pages");
    }
    if (bytes > impl_->capabilities.maxBufferLengthBytes) {
        throw MetalBackendError("Metal buffer exceeds maxBufferLength");
    }
    auto allocation = std::make_shared<MetalAllocation>();
    allocation->accounting = impl_->accounting;
    allocation->length = bytes;
    allocation->owner = owner;
    if (!label.empty()) allocation->label = checkedNSString(label, "buffer label");
    allocation->residency = impl_->residency;
    // Metal may keep the buffer past our last view, so its deallocator holds
    // the owner too.
    id<MTLBuffer> buffer = [impl_->device
        newBufferWithBytesNoCopy:address
                          length:bytes
                         options:MTLResourceStorageModeShared
                     deallocator:^(void *, NSUInteger) { (void)owner; }];
    if (!buffer)
        throw MetalAllocationError("zero-copy Metal buffer creation failed");
    if (allocation->label) buffer.label = allocation->label;
    allocation->attach(buffer);
    impl_->sampleDeviceMemory();
    auto result = std::make_shared<MetalBuffer::Impl>();
    result->lengthBytes = bytes;
    result->allocation = std::move(allocation);
    return MetalBuffer(std::move(result));
}

void MetalBackend::releaseMemory(const MetalBuffer &buffer) {
    MetalAllocation &allocation = impl_->baseAllocation(buffer);
    if (allocation.owner)
        throw MetalBackendError("wrapped memory is its owner's to release");
    if (!allocation.buffer)
        throw MetalBackendError("Metal buffer memory is already released");
    if (commandInFlight())
        throw MetalBackendError(
            "Metal buffer memory is released while a command is in flight");
    allocation.detach();
    impl_->sampleDeviceMemory();
}

void MetalBackend::restoreMemory(const MetalBuffer &buffer) {
    checkOperation();
    MetalAllocation &allocation = impl_->baseAllocation(buffer);
    if (allocation.buffer)
        throw MetalBackendError("Metal buffer memory is not released");
    allocation.attach(impl_->newBuffer(allocation.length, allocation.storage,
                                       allocation.label));
    impl_->sampleDeviceMemory();
}

MetalBuffer MetalBackend::view(const MetalBuffer &base,
                               uint64_t offsetBytes,
                               uint64_t lengthBytes) const {
    impl_->ensureHealthy();
    if (!base.impl_) {
        throw MetalBackendError("cannot view an empty Metal buffer");
    }
    if (base.impl_->allocation->accounting.get() != impl_->accounting.get()) {
        throw MetalBackendError("Metal buffer belongs to another backend");
    }
    if (!lengthBytes || offsetBytes > base.impl_->lengthBytes ||
        lengthBytes > base.impl_->lengthBytes - offsetBytes) {
        std::ostringstream message;
        message << "Metal buffer view is out of range: offset=" << offsetBytes
                << " length=" << lengthBytes
                << " base_length=" << base.impl_->lengthBytes;
        throw MetalBackendError(message.str());
    }
    auto result = std::make_shared<MetalBuffer::Impl>();
    result->allocation = base.impl_->allocation;
    result->offsetBytes = base.impl_->offsetBytes + offsetBytes;
    result->lengthBytes = lengthBytes;
    return MetalBuffer(std::move(result));
}

SharedEvent MetalBackend::newSharedEvent() {
    checkOperation();
    auto result = std::make_shared<SharedEvent::Impl>();
    result->event = [impl_->device newSharedEvent];
    if (!result->event) {
        throw MetalBackendError("unable to create Metal shared event");
    }
    result->listener = impl_->eventListener;
    return SharedEvent(std::move(result));
}

CommandTiming MetalBackend::submit(const ComputeDispatch &dispatch) {
    return submitCommandAsync({&dispatch, 1}).wait();
}

CommandTicket MetalBackend::submitCommandAsync(
    std::span<const ComputeDispatch> dispatches,
    CommandCompletion completion) {
    return submitCommandAsync(Command{dispatches, {}}, std::move(completion));
}

CommandTicket MetalBackend::submitCommandAsync(const Command &command,
                                               CommandCompletion completion) {
    checkOperation();
    [[maybe_unused]] const NSUInteger buffers = checkEvents(command.events, command.dispatches.size());
#ifdef SPLASH_BACKEND_INSTRUMENTATION
    impl_->lastCommandBuffers = buffers;
    if (impl_->dispatchProfiling)
        return impl_->submitProfiled(command.dispatches, command.events, std::move(completion));
#endif
    Impl::PreparedCommand prepared = impl_->prepare(command.dispatches);
    return impl_->commit(prepared.dispatches, command.events,
                         std::move(prepared.retainedAllocations),
                         std::move(completion));
}

void MetalBackend::preparePipelines(
    std::span<const ComputeDispatch> dispatches) {
    checkOperation();
    static_cast<void>(impl_->prepare(dispatches));
}

MetalMemoryStats MetalBackend::memoryStats() const noexcept {
    // Reading MTLDevice.currentAllocatedSize can synchronize with an active
    // command on some Apple GPUs. Every allocation and command lifecycle
    // boundary already samples it, so status must use the cached atomic value
    // rather than turning a control-plane query into a GPU barrier.
    return {
        impl_->accounting->allocatedBytes.load(std::memory_order_relaxed),
        impl_->accounting->peakAllocatedBytes.load(std::memory_order_relaxed),
        impl_->asyncState->deviceCurrentAllocatedBytes.load(
            std::memory_order_relaxed),
        impl_->asyncState->devicePeakAllocatedBytes.load(
            std::memory_order_relaxed),
    };
}

MetalMemoryStats MetalBackend::refreshMemoryStats() const noexcept {
    impl_->sampleDeviceMemory();
    return memoryStats();
}

void MetalBackend::restartPeaks() noexcept {
    impl_->accounting->peakAllocatedBytes.store(
        impl_->accounting->allocatedBytes.load(std::memory_order_relaxed),
        std::memory_order_relaxed);
    impl_->asyncState->devicePeakAllocatedBytes.store(0, std::memory_order_relaxed);
    impl_->sampleDeviceMemory();
}

bool MetalBackend::commandInFlight() const noexcept {
    return impl_->asyncState->hasActiveSubmission();
}

void MetalBackend::checkHealth() {
    impl_->asyncState->checkCommandHealth();
}

bool MetalBackend::healthy() const noexcept {
    return impl_->asyncState->healthy.load(std::memory_order_acquire);
}

std::string MetalBackend::unhealthyReason() const {
    std::lock_guard lock(impl_->asyncState->healthMutex);
    return impl_->asyncState->healthReason;
}

#ifdef SPLASH_BACKEND_INSTRUMENTATION
uint64_t BackendInstrumentation::submittedCommands(
    const MetalBackend &backend) {
    std::lock_guard lock(backend.impl_->asyncState->gateMutex);
    return backend.impl_->asyncState->nextSequence;
}

size_t BackendInstrumentation::cachedPipelines(const MetalBackend &backend) {
    return backend.impl_->pipelines.size();
}

uint64_t BackendInstrumentation::lastCommandBuffers(const MetalBackend &backend) {
    return backend.impl_->lastCommandBuffers;
}

void BackendInstrumentation::setDispatchProfiling(MetalBackend &backend,
                                                  bool enabled) {
    backend.impl_->dispatchProfiling = enabled;
}

std::vector<DispatchTiming>
BackendInstrumentation::takeDispatchProfile(MetalBackend &backend) {
    return std::exchange(backend.impl_->dispatchProfile, {});
}

std::optional<bool> BackendInstrumentation::awakeHostStepsSpin(MetalBackend &backend) {
    MetalBackend::Impl &impl = *backend.impl_;
    if (!impl.hostStepSpin && impl.nextSpinCheck != AwakeClock::time_point::max())
        impl.checkHostStepSpin();
    if (impl.hostStepSpin) return true;
    if (impl.nextSpinCheck == AwakeClock::time_point::max()) return false;
    return std::nullopt;
}
#endif

}  // namespace splash::metal
