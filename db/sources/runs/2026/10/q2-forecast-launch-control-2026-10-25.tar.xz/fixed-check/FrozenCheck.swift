import ArgumentParser
import Foundation
import CryptoKit
import MLX
import Slotstream

struct Q2ProfileCheck: ParsableCommand {
    static let configuration = CommandConfiguration(commandName: "q2-profile", abstract: "Frozen Q2 verification sequence diagnostic")
    @Option var fixture: String
    @Option var output: String
    @Option var memoryGB: Double = 15
    @Option var rounds: Int = 3
    @Option var ahead: Int = 1
    struct Step: Decodable { let position: Int; let tokens: [Int]; let kept: Int }
    struct Fixture: Decodable { let prompt_ids: [Int]; let steps: [Step] }
    func run() throws {
        guard memoryGB == 15, (1...4).contains(rounds), (0...1).contains(ahead), !FileManager.default.fileExists(atPath: output) else { throw ValidationError("Frozen diagnostic settings or fresh receipt required") }
        let input=try JSONDecoder().decode(Fixture.self,from:Data(contentsOf:URL(fileURLWithPath:fixture)))
        guard input.prompt_ids.count <= 256, input.steps.count <= 512 else {throw ValidationError("Bounded sequence required")}
        var position=input.prompt_ids.count
        for step in input.steps {
            guard step.position==position,(1...8).contains(step.tokens.count),(1...step.tokens.count).contains(step.kept),step.tokens.allSatisfy({(0..<248320).contains($0)}) else {throw ValidationError("Invalid frozen sequence")}
            position+=step.kept
        }
        let machine=Machine.current()
        guard (machine.availableGB ?? 0)>=memoryGB+3 else {throw ModelError("Budget plus 3 GB required")}
        let plan=try Planner.plan(resources:.q2,expertsPerLayer:nil,poolGB:nil,memoryGB:memoryGB,
            ramGB:machine.ramGB,workingSetGB:machine.workingSetGB,availableGB:machine.availableGB,
            mtp:.off,mtpAvailable:false,vision:.off,visionAvailable:false,maxContextTokens:8192,
            qualification:false,decodeLookahead:.reserved(bytes:NativeInputReadAhead.reserveBytes),mtpExperts:.automatic)
        let sem=DispatchSemaphore(value:0);var outcome:Result<Void,Error> = .success(())
        Task {
            do {
                let engine=try await Engine(modelDir:ModelLocator.resolve("smart-q2"),plan:plan)
                let model=engine.model
                var rows:[[String:Any]]=[],reference:[Int:String]=[:]
                for round in 0..<rounds {
                    model.lookahead?.requestFinished();model.lookahead=nil
                    model.capturesDraftFeatures=false
                    let state=model.makeState()
                    eval(try model.lastLogitsChecked(input.prompt_ids,state:state))
                    model.capturesDraftFeatures=true
                    if ahead==1 {try model.enableNativeInputReadAhead(reservedBytes:plan.lookaheadReserveBytes)}
                    try Data(String(RuntimeClock.now()).utf8).write(to: URL(fileURLWithPath: output+".verify-\(round).start"))
                    for (index,step) in input.steps.enumerated() {
                        guard state.tokenCount==step.position else {throw ModelError("Frozen state position changed")}
                        let checkpoint=state.checkpoint();state.setRecording(true)
                        model.pool.resetStats();model.lookahead?.prefetch?.resetObservation()
                        let retirement=model.nativeRouterRetirementPasses
                        let scheduled=model.nativeExpertScheduledPasses,repacked=model.nativeGPURepackedRecords,forecasted=model.nativeGPUForecastRecords
                        let started=RuntimeClock.now()
                        model.lookahead?.beginPass(phase:.mainVerify,tokens:step.tokens,features:[])
                        let result=try model.allLogitsWithMultiChecked(step.tokens,state:state)
                        let built=RuntimeClock.now();eval(result.logits);let evaluated=RuntimeClock.now()
                        let values=result.logits.asType(.float32).asArray(Float.self)
                        let raw=values.withUnsafeBytes{Data($0)}
                        let top1=(0..<step.tokens.count).map { row in
                            let lo=row*248320,hi=lo+248320
                            return values[lo..<hi].indices.max(by:{values[$0]<values[$1]})! - lo
                        }
                        let hash=SHA256.hash(data:raw).map{String(format:"%02x",$0)}.joined()
                        if let old=reference[index] {guard hash==old else {throw ModelError("Cache/round changed frozen logits at step \(index)")}} else {reference[index]=hash}
                        let commitStart=RuntimeClock.now()
                        try state.rollbackChecked(keeping:step.kept,of:step.tokens,from:checkpoint,ngramWindow:model.cfg.ngramSize-1)
                        model.lookahead?.passReconciled(kept:step.kept);model.lookahead?.endPass()
                        let ended=RuntimeClock.now()
                        rows.append(["round":round,"step":index,"width":step.tokens.count,"kept":step.kept,
                            "seconds":Double(evaluated-started)/1e9,"call_seconds":Double(built-started)/1e9,
                            "eval_seconds":Double(evaluated-built)/1e9,"commit_seconds":Double(ended-commitStart)/1e9,
                            "start_ns":started,"end_ns":evaluated,"records_fetched":model.pool.recordsFetched,
                            "records_adopted":model.pool.recordsAdopted,"io_seconds":model.pool.ioSeconds,
                            "adopt_seconds":model.pool.adoptSeconds,"router_retirement_passes":model.nativeRouterRetirementPasses-retirement,
                            "logits_sha256":hash,"top1":top1,"scheduled_passes":model.nativeExpertScheduledPasses-scheduled,"gpu_repacked_records":model.nativeGPURepackedRecords-repacked,"gpu_forecast_records":model.nativeGPUForecastRecords-forecasted,"read_handles":model.readHandleCount])
                    }
                    model.lookahead?.requestFinished()
                    guard ProcessMemory.peakResidentGB<=memoryGB,(ProcessMemory.vmActivity()?.reclaimableBytes ?? 0)>1_000_000_000 else {throw ModelError("Memory ceiling/headroom violated")}
                    let receipt:[String:Any]=["plan":plan.json(),"fixture":fixture,"ahead":ahead,"runs":rows,"complete":round==rounds-1,"peak_gb":ProcessMemory.peakResidentGB,
                        "scope":"Target-only sequential replay with frozen inputs and kept prefixes. Real recurrent rollback and natural cache evolution. No proposal generation/sampling/controller; not complete-request timing. Logit hashing and commit excluded from verification seconds."]
                    try JSONSerialization.data(withJSONObject:receipt,options:[.prettyPrinted,.sortedKeys]).write(to:URL(fileURLWithPath:output),options:.atomic)
                    print("round \(round) completed \(input.steps.count) frozen passes")
                }
            }catch {outcome = .failure(error)}
            sem.signal()
        }
        sem.wait();try outcome.get()
    }
}

@main struct FrozenMain { static func main() { Q2ProfileCheck.main() } }
