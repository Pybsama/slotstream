from pathlib import Path
import json
P=Path(__file__).resolve().parent;out=[]
for e in json.loads((P/'ordinary-forecast-launch-15-ledger.json').read_text()):
 a=json.loads((P/(e['label']+'.json')).read_text());rows=[]
 for r in a['runs'][2:]:
  if e['arm']in 'AB':
   s=r['stats'];v=dict(passes=s['decodeForwardPasses'],demand_records=s['decodeRecords'],adopted=s['expertPrefetch']['adopted'],issued=s['expertPrefetch']['issued'])
  else:
   b=r['status_before']['streamed_experts']['decode'];s=r['status_after']['streamed_experts']['decode'];d={k:s[k]-b[k]for k in s if isinstance(s[k],(int,float))};assert d['loads']%48==0
   v=dict(passes=d['loads']//48,demand_records=d['read']-d['prefetched'],adopted=d['prefetched'],completed_ahead=d['read_ahead'],read_bytes=d['read_bytes'])
  rows.append(dict(id=r['id'],seconds=r['elapsed_seconds'],**v))
 out.append(dict(arm=e['arm'],label=e['label'],requests=rows))
(P/'work-counts.json').write_text(json.dumps(dict(scope='Request-local native counters and Splash status deltas. Splash read includes prefetched. Loads/48 includes anchor-only passes. Issued native tickets and completed upstream forecasts are different counters. Different outputs/adaptive work; no equal-work time normalization or causal attribution.',arms=out),indent=2))
for e in out:print(e['label'],[(r['id'],r['passes'],r['demand_records'])for r in e['requests']])
