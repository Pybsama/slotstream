from pathlib import Path
import json,subprocess
P=Path(__file__).resolve().parent;R=P.parents[1];DB=R/'db';tool='/Users/carlos/.dbmd/bin/dbmd'
def write(path,kind,title,fields,body):
 f=P/(Path(path).name+'.body.md');f.write_text(body.strip()+'\n')
 cmd=[tool,'write',path,'--dir',str(DB),'--json','--type',kind,'--summary',title,'--fm','title='+title,'--body-file',str(f)]
 for k,v in fields.items():cmd+=['--fm',k+'='+str(v)]
 print(subprocess.run(cmd,check=True,capture_output=True,text=True).stdout.strip())
 if not(DB/path).exists():
  found=list(DB.rglob(Path(path).name));assert len(found)==1
  print(subprocess.run([tool,'rename',str(found[0].relative_to(DB)),path,'--dir',str(DB),'--json'],check=True,capture_output=True,text=True).stdout.strip())

a=json.loads((P/'archive-receipt.json').read_text());result=json.loads((P/'analysis.json').read_text());name=Path(a['path']).name
assert not result['retention_gate'], 'Retained candidate requires implementation review, not rejected-candidate documentation'
source='sources/runs/2026/10/2026-10-25-q2-forecast-launch-control.md'
write(source,'run','Q2 forecast launch boundary control evidence',dict(tool='Offline physical-read correlation, Swift/MLX exact-target replay and original-weight checks, complete ABCCBA requests',command='Archived plan/build/check_candidate/run/analyze scripts and exact identities',binary='Frozen v68; isolated Q2 after-combine forecast candidate; published Splash1.4.0',captured_at='2026-10-25',machines='[[records/machines/macbook-pro-m5-pro-48gb]]',discarded=str(not result['eligible']).lower()),f"""
[Raw archive]({name}): {a['files']} files, {a['bytes']} bytes, SHA-256 `{a['sha256']}`.
Every member was read back and hash-checked; credential-pattern matches are zero.
Prior ordinary read/copy traces and their classifier are referenced by verified
archive/member hashes. Exact sources, build identities, baseline logits,
fixture, candidate checks, guard logs, outputs and all six comparison arms are
preserved. Executables and model weights are identified rather than embedded.

The first two offline grouping attempts incorrectly assumed every expert layer
emits a host signal. Their failures remain. Source review confirms fully ready
layers need no event. The repaired analysis uses each read's original physical
layer and chronological wrap, asserting no more than one layer of overlap.
It accounts for every classified forecast read without indexing signals as
layers. This is observational attribution, not proof of worker utilization.

Original-weight, mixed forecast/demand, cache, failure/retry and ownership checks
pass with Metal validation. A frozen sequential replay preserves all logits
at 111 passes with recurrent rollback, exercises 5,328 scheduled expert layers
and adopts 20,789 forecast records. Both checks complete without paging or
thermal violations; the model replay's sampled peak is 11.696 GB. This is
arithmetic/correctness evidence, not complete app or semantic-quality evidence.

The timing protocol is fixed before execution and includes every arm. Its
whole-protocol eligibility is `{result['eligible']}`. There is no favorable-arm
selection or benchmark retry. Runtime sources and default artifacts are restored.
""")
rows=[]
for r in result['requests']:
 m=r['median'];pairs=r['candidate_over_baseline_pairs']
 rows.append(f"| {'Code' if r['id']=='timed-2' else 'Prose'} | {m['A']:.3f} | {m['B']:.3f} | {m['C']:.3f} | {pairs[0]:.4f} / {pairs[1]:.4f} | {r['candidate_over_splash_median']:.4f} |")
body="""
Q2 parity remains unachieved. No runtime change is retained, and Fast stays
unchanged. This follows [[records/measurements/q2-demand-lifecycle-triage]];
raw evidence is in [[sources/runs/2026/10/2026-10-25-q2-forecast-launch-control]].

## Forecast dispatch gaps are small

Offline correlation of the existing clean ordinary traces identifies
115,097/120,524 code/prose forecast reads, using the original GGUF extents and
four independently validated scratch destinations. Grouping by physical layer
and chronological pass accounts for every read. A layer's forecast reads can
overlap its neighbor, which the grouping explicitly permits.

Across 5,263/5,536 observed groups, gaps inside the union of forecast reads and
their following copies total only 0.501/0.466 milliseconds. The corresponding
read/copy spans total 6.183/6.477 seconds. This weakens the hypothesis of large
global dispatch gaps once a burst starts. It does not measure per-worker idle
time, initial dispatch latency, or prove that overlapping reads cause no
contention. No batch scheduler rewrite follows.

Host publication counts are not layer counts: fully ready layers can omit
the event. The initial incorrect indexing assumptions and repaired analyzer
are preserved; no mismatched reads are silently dropped.

## A one-call-site launch-boundary control

Native starts forecasts immediately after publishing expert input readiness,
before constructing/submitting the final combine. Splash has the following
step work queued before its host callback starts read-ahead. This is a source
ordering difference, not a proven speed cause or identical execution graph.

The isolated candidate passes no forecast callback at that Q2 call site. The
existing fallback submits the combine result before starting forecast reads.
Reader count, ranks, cache policy/capacity, precision and arithmetic are unchanged.
Fast's branch is untouched. This trades later forecast availability for less
concurrent reader work during combine construction/submission; it also changes
a submission boundary. It therefore cannot isolate CPU contention alone.

Original-weight and cache/lifetime checks pass with Metal validation. The
candidate's fixed-input replay matches all baseline logits for 111 sequential
passes and rollback boundaries, while exercising actual forecast adoption.
This does not resolve known Fast recall or Q2 strict-format failures.

One untraced ABCCBA compares v68, candidate and published Splash. Each fresh
process uses two warmups then the same 384-token code/prose requests, normal
adaptive verification and read-ahead, 15 GB ceiling, 4,067 actual cache slots,
8,192 context, BF16 activations/KV and FP32 recurrent state. Work can differ
because adaptation and generated outputs remain part of ordinary requests.

| Task | Baseline median s | Candidate median s | Splash median s | Candidate/baseline forward / reverse | Candidate/Splash median |
| --- | ---: | ---: | ---: | ---: | ---: |
"""+'\n'.join(rows)+f"""

Whole-protocol environmental eligibility is `{result['eligible']}`; frozen
repeatability retention is `{result['retention_gate']}`. All arms remain in the
analysis. The result does not justify moving the production launch boundary.
This tests the specific after-combine fallback, not every possible schedule.

The unchanged baseline itself has median native/Splash ratios of 1.0415 for
code and 0.9862 for prose in this protocol. That meets the numerical five-percent
median target here, without the candidate. It does not erase earlier clean gaps
or establish consistent parity. Code baseline times range from 11.733 to 13.097
seconds; Splash ranges from 11.437 to 12.404. Candidate code improves 3.66% in
the forward pair and regresses 4.65% in reverse; prose improves 1.20% then
regresses 1.59%. Selecting only the first pair would retain an unsupported fix.

Actual work also moves. The unchanged native code requests perform 110/105
passes and read 27,050/23,291 demanded records; Splash performs 108/115 passes
and reads 23,354/25,133 demanded records. These counters do not prove the full
cause of timing variation. They do show why wall-time differences between
open-ended adaptive generations are insufficient to locate execution overhead.

The next controlled attribution should preserve the complete proposal/target
workload while fixing inputs, verification widths and accepted prefixes in
both engines. It must include real draft computation: previous target-only
replays changed the load pattern and showed clock behavior absent in ordinary
requests, as recorded in [[records/measurements/q2-frequency-and-cache-diagnosis]].
Use that control to select a fix, then retain the ordinary user-request gate.
Do not repeat the six arms merely to obtain a favorable average.

All 509 runtime inputs and five default artifacts match v68. There is no Smart
promotion, release or app-readiness claim. The remaining investigation must
use attributable ordinary-request work and preserve the matched cache/precision
conditions; neither continuous reads nor native language choice proves parity.
"""
write('records/measurements/q2-forecast-launch-control.md','measurement','Q2 forecast dispatch and launch-boundary control',dict(date='2026-10-25',doc='measurements',level=2,machines='[[records/machines/macbook-pro-m5-pro-48gb]]',order=1907,runs='[['+source[:-3]+']]',status='measured'),body)
