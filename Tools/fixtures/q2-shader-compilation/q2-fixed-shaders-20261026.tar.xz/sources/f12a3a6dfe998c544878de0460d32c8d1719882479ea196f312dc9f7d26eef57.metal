#include <metal_stdlib>
using namespace metal;
#pragma clang fp reassociate(off)

kernel void run(device const float* x [[buffer(0)]],
device bfloat* y [[buffer(1)]],
constant int* dispatchValues [[buffer(2)]],
uint3 thread_position_in_grid [[thread_position_in_grid]],
uint3 threadgroup_position_in_grid [[threadgroup_position_in_grid]],
uint thread_index_in_threadgroup [[thread_index_in_threadgroup]],
uint thread_index_in_simdgroup [[thread_index_in_simdgroup]],
uint simdgroup_index_in_threadgroup [[simdgroup_index_in_threadgroup]]) {

uint i=thread_position_in_grid.x;if(i>=uint(dispatchValues[0]))return;
float sum=0;for(uint p=0;p<16;++p)sum+=x[p*2560+i];
float v=float(bfloat(sum))/4.0f;
y[i]=bfloat(v/(1.0f+fast::exp2(-1.44269504089f*v)));
}
