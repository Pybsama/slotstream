#include <metal_stdlib>
using namespace metal;
#pragma clang fp reassociate(off)

kernel void run(device const float* x [[buffer(0)]],
device const float* norm [[buffer(1)]],
device const float* inject [[buffer(2)]],
device bfloat* normalized [[buffer(3)]],
device float* weights [[buffer(4)]],
uint3 thread_position_in_grid [[thread_position_in_grid]],
uint3 threadgroup_position_in_grid [[threadgroup_position_in_grid]],
uint thread_index_in_threadgroup [[thread_index_in_threadgroup]],
uint thread_index_in_simdgroup [[thread_index_in_simdgroup]],
uint simdgroup_index_in_threadgroup [[simdgroup_index_in_threadgroup]]) {
constexpr int H=2560;constexpr bool INJECT=false;
uint row=threadgroup_position_in_grid.x, ti=thread_index_in_threadgroup;
uint lane=thread_index_in_simdgroup, sg=simdgroup_index_in_threadgroup;
uint q=ti/256, tid=ti%256;
constexpr uint V=H/256, W=4*H;
const device float* input=x+size_t(row)*W;
float mine[V],sum=0;
for(uint i=0;i<V;++i)mine[i]=input[q*H+tid+i*256];
for(uint i=0;i<V;++i)sum+=mine[i]*mine[i];
threadgroup float scratch[32],scales[4];
sum=simd_sum(sum);if(lane==0)scratch[sg]=sum;
threadgroup_barrier(mem_flags::mem_threadgroup);
if(tid==0){float total=0;for(uint g=0;g<8;++g)total+=scratch[q*8+g];scales[q]=rsqrt(total/H+1e-6f);}
threadgroup_barrier(mem_flags::mem_threadgroup);
float dot=0;
if constexpr(INJECT){
  for(uint s=0;s<4;++s){
    float xv[V],ns[V],ws[V];
    for(uint i=0;i<V;++i){uint c=s*H+tid+i*256;xv[i]=input[c];ns[i]=norm[c];ws[i]=inject[size_t(q)*W+c];}
    for(uint i=0;i<V;++i){uint c=s*H+tid+i*256;float v=(xv[i]*scales[s])*ns[i];
      if(s==q)normalized[size_t(row)*W+c]=bfloat(v);dot+=ws[i]*v;}
  }
}else{
  for(uint i=0;i<V;++i){uint c=q*H+tid+i*256;normalized[size_t(row)*W+c]=bfloat((mine[i]*scales[q])*norm[c]);}
}
dot=simd_sum(dot);
threadgroup_barrier(mem_flags::mem_threadgroup);
if(lane==0)scratch[sg]=dot;
threadgroup_barrier(mem_flags::mem_threadgroup);
if(tid==0){float total=0;for(uint g=0;g<8;++g)total+=scratch[q*8+g];weights[row*4+q]=2.0f*(1.0f/(1.0f+fast::exp2(-1.44269504089f*(total/4.0f))));}
}
