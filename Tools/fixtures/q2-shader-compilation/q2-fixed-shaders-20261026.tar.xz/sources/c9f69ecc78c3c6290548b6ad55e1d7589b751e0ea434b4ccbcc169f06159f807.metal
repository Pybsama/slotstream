#include <metal_stdlib>
using namespace metal;
#pragma clang fp reassociate(off)
#pragma clang fp contract(off)

kernel void run(device const float* streams [[buffer(0)]],
device const bfloat* branch [[buffer(1)]],
device const float* weights [[buffer(2)]],
device float* output [[buffer(3)]],
uint3 thread_position_in_grid [[thread_position_in_grid]],
uint3 threadgroup_position_in_grid [[threadgroup_position_in_grid]],
uint thread_index_in_threadgroup [[thread_index_in_threadgroup]],
uint thread_index_in_simdgroup [[thread_index_in_simdgroup]],
uint simdgroup_index_in_threadgroup [[simdgroup_index_in_threadgroup]]) {

uint d=thread_position_in_grid.x,row=thread_position_in_grid.y;
if(d>=2560)return;
float value=float(branch[row*2560+d]);
for(uint s=0;s<4;++s){
    uint i=row*10240+s*2560+d;
    float product=value*weights[row*4+s];
    output[i]=streams[i]+product;
}
}
