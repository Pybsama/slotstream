#include <metal_stdlib>
using namespace metal;
#pragma clang fp reassociate(off)

kernel void run(device const float* x1 [[buffer(0)]],
device bfloat* y1 [[buffer(1)]],
constant int* dispatchValues [[buffer(2)]],
uint3 thread_position_in_grid [[thread_position_in_grid]],
uint3 threadgroup_position_in_grid [[threadgroup_position_in_grid]],
uint thread_index_in_threadgroup [[thread_index_in_threadgroup]],
uint thread_index_in_simdgroup [[thread_index_in_simdgroup]],
uint simdgroup_index_in_threadgroup [[simdgroup_index_in_threadgroup]]) {

uint i=thread_position_in_grid.x;
if(i<6144*uint(dispatchValues[0])){float sum=0;for(uint p=0;p<2;++p)sum+=x1[p*(6144*dispatchValues[0])+i];y1[i]=bfloat(sum);}

}
