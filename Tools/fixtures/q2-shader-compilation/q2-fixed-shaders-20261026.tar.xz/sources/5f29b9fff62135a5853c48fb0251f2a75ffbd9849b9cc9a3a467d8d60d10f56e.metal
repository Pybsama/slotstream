#include <metal_stdlib>
using namespace metal;
#pragma clang fp reassociate(off)

kernel void run(device const bfloat* x [[buffer(0)]],
device const bfloat* gate [[buffer(1)]],
device bfloat* y [[buffer(2)]],
uint3 thread_position_in_grid [[thread_position_in_grid]],
uint3 threadgroup_position_in_grid [[threadgroup_position_in_grid]],
uint thread_index_in_threadgroup [[thread_index_in_threadgroup]],
uint thread_index_in_simdgroup [[thread_index_in_simdgroup]],
uint simdgroup_index_in_threadgroup [[simdgroup_index_in_threadgroup]]) {
constexpr int H=2560;
uint d=thread_position_in_grid.x,row=thread_position_in_grid.y;if(d>=H)return;
float sum=0;
for(uint s=0;s<4;++s){uint i=row*4*H+s*H+d;sum+=float(x[i])*(1.0f/(1.0f+fast::exp2(-1.44269504089f*float(gate[i]))));}
y[row*H+d]=bfloat(sum/4);
}
